# Checks of the numerical hypothesis `ReceiptGap.Numerical`

The Lean theorem in `../lean` takes as a hypothesis the structure `PrimeGap180.ReceiptGap.Numerical` (`../lean/proof/TrialReceiptGap180.lean`). Its 14 fields are finite numerical statements. The programs in this folder check, in exact rational and integer arithmetic, that archived numerical certificates imply each field as Lean states it. Before comparing numbers, they match each field statement and the definitions it uses textually against the Lean sources in `../lean/proof`, and they record or verify the SHA-256 of the certificate files they read.

The checks do not recompute the certificates, except for the optional exact replay of the `pair` certificate (below). The certificates rest on floating-point error analyses and on modelling arguments that the paper describes; those arguments are not machine-checked.

This folder also holds two programs that check parameter conditions used in the paper, and a numerical test of Hypothesis A4.

## Layout

| Path | Contents |
|---|---|
| `verify_certificates.sh` | Runs the checks in order |
| `proof/` | The checking programs, the certificates they read, and seven Lean files that `certify_numerical_high.py` reads and that are not part of the build in `../lean` |
| `data/` | Certificates of the original computations, and the programs of those computations that the checks import |
| `data/archived/` | Programs whose SHA-256 values the certificates record, byte for byte (see "Recorded file names") |
| `sensitivity/`, `restoration/` | Three further modules that the programs in `data/` import |
| `hypothesis_a4/` | A numerical test of Hypothesis A4 |
| `MANIFEST.sha256` | SHA-256 of every other file here. Check with `shasum -a 256 -c MANIFEST.sha256` |

The programs find each other, the Lean sources and the data by relative paths, so keep this folder next to `../lean` and keep the layout unchanged. The Lean sources and the tables of `../lean/proof` are read from there and are not copied here. Five files in `data/` are identical to files in `../lean/data`: `cap_law_transfer.json`, `repriced_covers.json`, `h1_dickman_native_bounds.json`, `h1_multilevel_strip_free.json` and `h1_priced_168_table.json`.

## What each program checks

The programs are in `proof/` unless another folder is named.

| Fields | Program | What it checks |
|---|---|---|
| `capMass` | `certify_numerical_roles.py` | For each of the nine changing caps, the exact mass interval in `../lean/proof/mass_span_external_intervals.json` lies inside the Lean bounds `CoarseMassTargets.lower/upper`. It cross-checks the intervals against two independent computations at 256 and 160 bits. |
| `pair` | `certify_numerical_roles.py`; optionally `../lean/proof/check_exact_endpoint_pair.py` | The exact endpoint-pair charges in `exact_native_pair.json` are below `RoundedCaps.dyad c 4` at every changing cap. `check_exact_endpoint_pair.py` regenerates those charges from the frozen spline tables with directed integer arithmetic, and the result is compared bit for bit. |
| `core`, `first`, `last` | `certify_numerical_roles.py`, `check_slack_uncut.py` | The certified lower ends of the three single-site forms are above the Lean targets `SlackUncut.dyad'` at all 34 unsettled caps. `check_slack_uncut.py` checks the targets `SlackUncut.target'` themselves and the terminal excess. |
| `debitCore`, `debitFirst`, `debitLast` | `certify_numerical_roles.py` | The summed positive debits are below the Lean ceilings `SlackDebit.coreCeiling`, `firstCeiling` and `lastCeiling`. |
| `highRows` | `certify_numerical_high.py` | An exact integer cross-check of the 444 high-edge rows. Its docstring states which equalities it does not establish. |
| `lowImage`, `highImage` | `certify_numerical_high.py` | Recombines the outer-image certificates exactly, at the floor used in Lean, and checks them against the constants of `CertifiedBudget.LowImage` and `CertifiedBudget.HighImage`. |
| `middleRaw`, `middlePair`, `middleJoint` | `certify_numerical_middle.py` | Checks the 22 middle rows against `SlackRows`, `SlackBudget` and `CertifiedBudget`, and the transfer constants. By default it also re-executes four aggregation steps of the original computations from their saved outputs and requires identical results. |

`check_worker_inputs.py` checks that the inputs of the per-cap computations behind `core`, `first`, `last` and the three debits (spline, ranges, grid, prices and erased-field banks) equal the Lean definitions. It needs the external data described below.

Two programs check parameter conditions rather than fields of `Numerical`:

- `data/check_distribution_routes.py` checks, on every modulus band of the construction, the hypotheses of the distribution estimates that the band uses. Its output is `data/distribution_routes.json`.
- `check_slot_selection.py` checks the slot-selection hypotheses at the 13 parameter rows of `data/distribution_routes.json`, and an interior example for each.

The paper also cites `build_sampled_slot_proof.py` and `build_sifted_families.py`. They are generators of the Lean build and are in `../lean/proof`.

## Requirements

- Python 3.10 or newer. The checks were run with Python 3.14.7.
- The following packages, at the versions used:

  ```
  numpy==2.5.4
  scipy==1.18.1
  python-flint==0.9.0
  gmpy2==2.3.2
  scs==3.3.1
  ```

  `certify_numerical_roles.py`, `check_slack_uncut.py` and `check_slot_selection.py` use only the standard library.
- For `check_exact_endpoint_pair.py` only: the GMP shared library (`libgmp`), loaded through `ctypes`.
- For the replays in `certify_numerical_middle.py` and for `check_distribution_routes.py`: programs from the public numerical package of the 182 development, release `external-numerics-20260909` of `romyar1/prime-gaps-lean`. They are not included here. `data/fetch_h1_backend.py` downloads that archive (about 245 MB), checks its SHA-256 (`2960729efa8996538731820ce6cadc202831c8e98b2c0bdb14cfd19f33726f3b`) and extracts it into `deps/h1-182/` in this folder. It executes nothing from the archive.

## How to run

From this folder:

```sh
python3 -m venv /path/to/venv
/path/to/venv/bin/pip install numpy==2.5.4 scipy==1.18.1 python-flint==0.9.0 gmpy2==2.3.2 scs==3.3.1
/path/to/venv/bin/python data/fetch_h1_backend.py
PY=/path/to/venv/bin/python ./verify_certificates.sh --quick
```

This takes about 30 seconds and 0.4 GB of memory. It stops at the first failure. The end of a passing run reads:

```
== summary (reports in …)
  pass          0s  roles (certificates and Lean constants)
  pass          0s  slack uncut targets
  pass          8s  high rows and outer images
  pass          2s  middle groups (with aggregation replays)
  pass         10s  distribution routes
  pass          0s  distribution routes equal data/distribution_routes.json
  pass          1s  slot selection
…
All selected checks passed.
```

The line `worker inputs: skipped in --quick mode (PAYLOAD is not set)` is expected without the external data. Reports are written to `$WORK`, a new temporary directory by default.

Without downloading the 182 package, run the exact middle checks without the replays:

```sh
cd proof && $PY certify_numerical_middle.py --no-replay
```

Optional exact replay of the `pair` certificate for its two largest changing caps, 78,116 and 65,536 (about 5.5 minutes, 1.2 GB):

```sh
PY=/path/to/venv/bin/python ./verify_certificates.sh --quick --pair-replay
```

Each program can also be run on its own; `--help` lists its options.

## Checks that need external data

The following need the 3.1 GB archive of the per-cap computations (the "payload"; its `manifest.json` has SHA-256 `6490035124bbfdd43b22e4313e1d67dfeaaf2a592e4ce137895ba0515ad7735a`). The archive is not included and is available from the authors on request. Give its directory in the environment variable `PAYLOAD` or with `--payload`; there is no default.

- `certify_numerical_roles.py --payload DIR --hash-payload`: binds the archived prices to the payload and checks the hashes of its files.
- `check_worker_inputs.py --payload DIR`: the input check described above. With `--banks none` it skips the bank recomputation (about 10 seconds). With `--hash-banks` it also hashes the nine banks (about 7 minutes and 6.5 GB in all). With `--shards DIR2` it also compares the grid shards generated by the Lean build (`<build-dir>/generated/historical_site_rows`).
- `PAYLOAD=DIR ./verify_certificates.sh --quick` adds the input check with `--banks none`.
- `PAYLOAD=DIR ./verify_certificates.sh` runs these checks in full.

Full reruns of the original computations take from tens of minutes to many hours each. `./verify_certificates.sh --list-heavy` lists them. Not all of their programs are included.

## Recorded file names

Several certificates record the SHA-256 of the programs that computed them, and of some data files. They record these files under names that begin with `h1_b2_`, for example `h1_b2_quotient_inputs.py`, and the recorded programs import one another by those names. The working files in `data/` have the same names without the prefix.

`data/archived/` holds the recorded programs byte for byte under their recorded names. When a check compares a recorded hash, `data/archived_sources.py` hashes the archived file, and it also requires that the working file equals the archived file with every occurrence of `h1_b2_` removed. For this reason the working copies of the archived programs differ from them in that prefix only. Two archived programs have no working copy: `certify_quotient_and_debit.py`, which computed the 160-bit certificate, and `h1_b2_cap_worker.py`, which computed the 256-bit per-cap certificates.

The certificates are distributed byte for byte, so the recorded names also appear inside the JSON files.

## Numerical test of Hypothesis A4

`hypothesis_a4/four_cycle_scan.py` evaluates the four-cycle Fourier transform of Proposition 3.1 in floating point at small primes. `hypothesis_a4/scan_101_1009.jsonl` is its output at ten primes from 101 to 1009, and `hypothesis_a4/brute_check.py` compares the program with a direct evaluation of the defining sums at \(p=7\). This is numerical evidence and not a proof. Rerunning the scan can list points of equal magnitude in a different order.

## Licence

The code and data are licensed under the Apache License 2.0 (`../LICENSE-CODE`).
