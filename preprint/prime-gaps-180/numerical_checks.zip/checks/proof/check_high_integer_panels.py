"""Reproduce all 444 panel payments from tail bounds using exact rational and integer arithmetic."""

import argparse
from fractions import Fraction as Q
from functools import cache
from hashlib import sha256
import json
from math import ceil, lcm, perm, prod
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ARCHIVE = HERE.parent / "data"
sys.path.insert(0, str(ARCHIVE))

from global_amplitude import N, S, SIGS, radial_blocks
from positive_angular import _partitions, _splits

STEP = S / N
INPUT_BITS = 768
TAIL_BITS = 160
SITE_BITS = 224
TILT_BITS = 320
RATES = (55, 75)
CENTERS = ((Q(1, 4),) * 4, (1, 0, 0, 0), (0, 0, 0, 1))
CHANNELS = [(a, b, sig) for a in range(3) for b in range(3) for sig in SIGS]


def add(a, b):
    return a[0] + b[0], a[1] + b[1]


def sub(a, b):
    return a[0] - b[1], a[1] - b[0]


def scale(q, a):
    u, v = q*a[0], q*a[1]
    return min(u, v), max(u, v)


def ceil_div(n, d):
    return -(-n // d)


def native_index(threshold):
    return min(N, int(threshold // STEP))


class Moments:
    def __init__(self, book, bands, rate):
        self.bands = bands
        step = 1 << (INPUT_BITS - TAIL_BITS)
        self.tails = {int(j): [(Q(l//step, 1 << TAIL_BITS), Q(ceil_div(u, step), 1 << TAIL_BITS))
                               for l, u in row] for j, row in book[str(rate)].items()}

    @cache
    def ramp(self, threshold, degree, squared=False):
        row = self.tails[native_index(threshold)]
        offset = STEP/2 - threshold
        if squared:
            return add(add(row[degree+2], scale(2*offset, row[degree+1])),
                       scale(offset**2, row[degree]))
        return add(row[degree+1], scale(offset, row[degree]))

    @cache
    def clipped(self, tags, degree):
        if not tags:
            return self.tails[0][degree]
        a, b = self.bands[tags[0]]
        if len(tags) == 1:
            return scale(1/a, sub(self.ramp(a, degree), self.ramp(b, degree)))
        c, d = self.bands[tags[1]]
        ac, bc, ad, bd = (self.ramp(x, degree, True) for x in (a+c, b+c, a+d, b+d))
        return scale(1/(2*a*c), add(sub(sub(ac, bc), ad), bd))

    @staticmethod
    def round_site(bounds):
        lo, hi = (x * (1 << SITE_BITS) for x in bounds)
        lower, upper = max(0, lo.numerator // lo.denominator), ceil(hi)
        if upper < lower:
            raise ValueError("A nonnegative site moment has an empty interval")
        return lower, upper

    @cache
    def power(self, tags, degree):
        return self.round_site(add(add(self.clipped(tags, degree),
                                       scale(600, self.clipped(tags, degree+1))),
                                   scale(90000, self.clipped(tags, degree+2))))

    @cache
    def endpoint(self, tags, a, b):
        factors = (((0, Q(1)), (1, Q(300))), ((2, 1/S**2), (3, 300/S**2)), ((0, Q(1)),))
        bounds = (Q(0), Q(0))
        for i, u in factors[a]:
            for j, v in factors[b]:
                bounds = add(bounds, scale(u*v, self.clipped(tags, i+j)))
        return self.round_site(bounds)

    @cache
    def core(self, count, marked, powers, side):
        if marked:
            first, *rest = marked
            return sum(m * self.power(first, k)[side] * self.core(count, tuple(rest), remain, side)
                       for remain, k, m in _splits(powers))
        return sum(m * perm(count, len(parts)) * self.power((), 0)[side]**(count-len(parts))
                   * prod(self.power((), p)[side] for p in parts)
                   for parts, m in _partitions(powers))

    @cache
    def gram(self, i, j, first, last, powers):
        a, b, c, empty = (i,), (j,), (j, i), ()
        roles = ((a,b,(),1), (b,a,(),1), (a,empty,(b,),37), (b,empty,(a,),37),
                 (empty,a,(b,),37), (empty,b,(a,),37), (empty,empty,(a,b),37*36),
                 (c,empty,(),1), (empty,c,(),1), (empty,empty,(c,),37))
        return tuple(sum(mult * self.endpoint(ends_a, *first)[side] * self.endpoint(ends_b, *last)[side]
                         * self.core(37-len(core), core, powers, side)
                         for ends_a, ends_b, core, mult in roles)
                     for side in (0, 1))


def panel_controls(lo, hi, suffix, width):
    for start in range(lo, hi+1, width):
        for right, block in radial_blocks(start, min(hi, start+width-1), suffix):
            yield ceil(right / STEP - Q(39, 2)), [[block[a, k][row] for a in range(9)
                                                    for k in range(len(SIGS))] for row in range(4)]


def clear_denominators(matrix):
    den = lcm(*(v.denominator for row in matrix for v in row))
    return [[int(v*den) for v in row] for row in matrix], den


def dot_coefficients(C, code, q):
    if code == -1:
        Z = [[Q(i == j) for j in range(4)] for i in range(4)]
    else:
        w = CENTERS[code]
        Z = [[(1+q)*w[i]*w[j] + (1+1/q)*(int(i == j)-2*w[j]+4*w[i]*w[j])
              for j in range(4)] for i in range(4)]
    rows, dc = clear_denominators(C)
    z, dz = clear_denominators(Z)
    zc = [[sum(z[i][j]*rows[j][p] for j in range(4)) for p in range(99)] for i in range(4)]
    return ([sum(rows[i][p]*zc[i][t] for i in range(4)) for p in range(99) for t in range(99)], dc*dc*dz)


@cache
def group_keys():
    return [(*sorted((tuple(sorted((a,c))), tuple(sorted((b,d))))), tuple(sorted(s+t)))
            for a, b, s in CHANNELS for c, d, t in CHANNELS]


def signed_upper(coefficients, moments, i, j):
    groups = {}
    for key, coefficient in zip(group_keys(), coefficients, strict=True):
        groups[key] = groups.get(key, 0) + coefficient
    return sum(coef * moments.gram(i, j, *key)[int(coef >= 0)] for key, coef in groups.items() if coef)


def lower_tilt(rate, n):
    """Downward integer powering of the positive rational tilt."""
    r = 1-rate*STEP
    unit = 1 << TILT_BITS
    base = r.numerator*unit // r.denominator
    result = unit
    for bit in f"{n:b}":
        result = result*result // unit
        if bit == "1":
            result = result*base // unit
    if result <= 0:
        raise ValueError("Tilt must have a positive lower endpoint")
    return result


def calculate(book_path, schedule_path, panel_output=None):
    archive = json.loads((ARCHIVE / "signed_pair_gram.json").read_text())
    frozen = json.loads((HERE.parents[1] / "lean" / "proof" / "frozen_band_tables.json").read_text())
    # The physical working ticks per unit of native radius are exactly 2,624,990.
    edges = [Q(x)/2624990 for x in archive["maximum_band_edges_ticks"]]
    bands = list(zip(edges, edges[1:]))
    book_bytes, schedule_bytes = book_path.read_bytes(), schedule_path.read_bytes()
    book = json.loads(book_bytes)
    schedule = iter(json.loads(schedule_bytes))
    measures = {r: Moments(book, bands, r) for r in RATES}
    payment = Q(archive["ordinary_mass_floor"]) / 10**15
    reps = (11,12,20,29,32,36,39,40,43)
    bands_units = [0]*len(bands)
    completion = []
    max_control_bits = 0
    for i, (a, _) in enumerate(bands):
        hi = frozen["maxIndex"][reps[i]]
        suffix = frozen["suffix"][reps[i]]
        for j, (b, _) in enumerate(bands[:i+1]):
            lo = max(102994, native_index(a)+native_index(b))
            if lo > hi:
                continue
            for k, (end, C) in enumerate(panel_controls(lo, hi, suffix, archive["radial_span"])):
                inc_i, inc_j, inc_k, inc_end, rate, code, q_n, q_d, _ = next(schedule)
                if (inc_i, inc_j, inc_k, inc_end) != (i, j, k, end) or code not in (-1, 0, 1, 2):
                    raise ValueError(f"Wrong panel selector for {(i, j, k, end)}")
                q = Q(q_n, q_d)
                if q <= 0:
                    raise ValueError("Young parameter must be positive")
                coeffs, control_den = dot_coefficients(C, code, q)
                max_control_bits = max(max_control_bits, control_den.bit_length())
                numerator = signed_upper(coeffs, measures[rate], i, j)
                scale = (control_den << (39*SITE_BITS)) * (2 if i == j else 1)
                units = ceil(Q(numerator << TILT_BITS, scale*lower_tilt(rate, end))/payment)
                if units < 0:
                    raise ValueError("Negative bound on a positive energy")
                bands_units[i] += units
                completion.append([i, j, k, end, units])
    if next(schedule, None) is not None or len(completion) != 444:
        raise ValueError("Expected 444 panel calculations")
    allowed = sum(archive["per_maximum_band_upper_quadrillionths"])
    if sum(bands_units) > allowed:
        raise ValueError("The integer panel sum exceeds the high-mass allowance")
    if panel_output:
        panel_output.write_text(json.dumps(completion, separators=(",", ":"))+"\n")
    return {"scope": "Independent rational and integer panel bounds for the compact two-tilt high-mass calculation.",
            "input_sha256": sha256(book_bytes).hexdigest(), "schedule_sha256": sha256(schedule_bytes).hexdigest(),
            "panel_bounds_sha256": sha256(json.dumps(completion, separators=(",", ":")).encode()).hexdigest(),
            "panels": len(completion), "site_bits": SITE_BITS, "tilt_bits": TILT_BITS,
            "largest_control_denominator_bits": max_control_bits,
            "angular_groups": len(set(group_keys())), "band_units": bands_units,
            "total_units": sum(bands_units), "allowed_units": allowed}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("enclosing_book", type=Path)
    parser.add_argument("schedule", type=Path)
    parser.add_argument("--verify", type=Path)
    parser.add_argument("--write-panel-units", type=Path)
    args = parser.parse_args()
    report = calculate(args.enclosing_book, args.schedule, args.write_panel_units)
    if args.verify and json.loads(args.verify.read_text()) != report:
        raise SystemExit("Integer panel certificate did not reproduce")
    print(json.dumps(report, indent=2))
