"""Check the lower uncut target and the slack per-cap targets of TrialSlackUncut180.lean.

The single-site targets of RoundedCaps.target (columns 1-3: core, first, last) are floors
of the 256-bit certificates and leave only a fraction of one 2^-20 unit per cap. Lowering the
relaxed uncut target from 1.00117224 to 1.0011666 frees part of the terminal excess for
per-cap slack. Every inequality below is recomputed with exact rationals.

  python3 check_slack_uncut.py           # check the Lean table and every inequality
  python3 check_slack_uncut.py --emit    # print the Lean table of target'

Allocation rule (columns 1-3, non-settled caps c; v = 2^20 * certificate lower end):
  required slack  core:  max(EPS*|v|, 2 units) at the nine changing caps,
                         max(EPS*|v|, 1/4 unit) at the other caps;
                  first, last: max(EPS*|v|, 8 units);
  target'(c, r) = the largest integer at least `required` below v.
Columns 0 and 4 and the settled caps 0, 3, 35 keep the values of RoundedCaps.target.
One unit of core slack costs 37 units in the aggregate, because all 37 interior sites
share the core bound; first and last cost one unit each.
"""
import argparse
from fractions import Fraction as F
from math import ceil, floor
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
LEAN = HERE.parents[1] / 'lean' / 'proof'
RECEIPTS = HERE.parent / 'data' / 'parallel_quotient_debit.json'
S = 2 ** 20
FORMS = {1: 'core', 2: 'a', 3: 'b'}
SETTLED = {0, 3, 35}
CHANGING = {7, 8, 15, 23, 26, 30, 33, 34, 36}  # InactiveCaps.changes
EPS = F(72, 10 ** 7)
FLOOR_CORE_CHANGING = F(2)
FLOOR_CORE_OTHER = F(1, 4)
FLOOR_END = F(8)

# Constants of the relaxed route (TrialUncutDrift180, TrialRelaxedMargin180, TrialSlackMargin180).
NATIVE_Q = F(91869339798531727264443072987184332662192823082517,
             91756122093510361124395735367397088325482944921600)
K = F(1429497779624109, 131072000000000)
P = F(627, 2000)
H = F(6159, 10 ** 12)
DELTA = F(37, 20000000)
RELAXED_TARGET = F('1.00117224')
REMOVED = F('0.001121271547')
DEBIT = F('0.0000443013')
# Constants of the slack route (TrialSlackUncut180).
TARGET = F('1.0011666')
NQ = NATIVE_Q - F('0.00002564')
GAIN = F('0.000001')


def table(src, name):
    body = src.split(f'def {name} : Fin 37 → Fin 5 → ℤ := ![', 1)[1].split(']]', 1)[0]
    rows = [[int(x) for x in r] for r in re.findall(r'!\[(-?\d+),(-?\d+),(-?\d+),(-?\d+),(-?\d+)', body)]
    if len(rows) != 37:
        raise ValueError(f'{name}: expected 37 rows, found {len(rows)}')
    return rows


def receipts():
    data = json.loads(RECEIPTS.read_text())
    if len(data['receipts']) != 37:
        raise ValueError('expected 37 certificates')
    out = {}
    for i, r in enumerate(data['receipts']):
        if r['cap'] != data['caps'][i] or r['bits'] != 256:
            raise ValueError('certificate order or precision differs')
        out[36 - i] = {k: (F(v[0]), F(v[1])) for k, v in r['forms'].items()}
    return out


def required(r, c, v):
    if r == 1:
        base = FLOOR_CORE_CHANGING if c in CHANGING else FLOOR_CORE_OTHER
    else:
        base = FLOOR_END
    return max(EPS * abs(v), base)


def build(old, rec):
    new = [row[:] for row in old]
    for c in range(37):
        if c in SETTLED:
            continue
        for r in (1, 2, 3):
            v = rec[c][FORMS[r]][0] * S
            new[c][r] = floor(v - required(r, c, v))
    return new


def emit(rows):
    lines = ',\n'.join('  ![' + ','.join(str(x) for x in row) + ']' for row in rows)
    return 'def target\' : Fin 37 → Fin 5 → ℤ := ![\n' + lines + ']'


def check(cond, msg):
    if not cond:
        raise SystemExit('FAILED: ' + msg)
    print('ok  ', msg)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--emit', action='store_true', help='print the Lean table and stop')
    args = parser.parse_args()
    old = table((LEAN / 'TrialRoundedNumbers180.lean').read_text(), 'target')
    rec = receipts()
    new = build(old, rec)
    if args.emit:
        print(emit(new))
        return
    lean = (LEAN / 'TrialSlackUncut180.lean').read_text()
    check(table(lean, "target'") == new, "target' in TrialSlackUncut180.lean equals the allocation rule")

    # Columns 0 and 4, settled rows, zero outer targets at inactive caps.
    check(all(new[c][0] == old[c][0] and new[c][4] == old[c][4] for c in range(37)), 'columns 0 and 4 unchanged')
    check(all(new[c] == old[c] for c in SETTLED), 'rows of the settled caps 0, 3, 35 unchanged (all zero in columns 1-3)')
    check(all(new[c][r] == 0 for c in SETTLED for r in (1, 2, 3)), 'settled caps have zero single-site targets')
    check(all(new[c][0] == 0 and new[c][4] == 0 for c in range(37) if c not in CHANGING), 'zero_targets\' holds')

    # Column sums, as stated in the Lean file.
    sums = [sum(new[c][r] for c in range(37)) for r in range(5)]
    for r, name in enumerate(['mass', 'core', 'first', 'last', 'pair']):
        stmt = re.search(rf"theorem sum_{name}' : \(∑ c : Fin 37,target' c {r}\) = (-?\d+)", lean)
        check(stmt is not None and int(stmt[1]) == sums[r], f'sum of column {r} is {sums[r]}')
    m_b, c_b, a_b, b_b, p_b = (F(x, S) for x in sums)
    for name, val in [('mBound', sums[0]), ('cBound', sums[1]), ('aBound', sums[2]), ('bBound', sums[3]),
                      ('pBound', sums[4])]:
        check(re.search(rf"def {name}' : ℝ := {val}/1048576", lean) is not None, f"{name}' = {val}/2^20")

    # Role bounds: weighted inequality, drift, margin.
    lhs = NQ * m_b
    rhs = 37 * c_b + a_b + b_b - p_b
    check(lhs <= rhs, f"weighted': nQ'*mBound' <= 37cBound'+aBound'+bBound'-pBound', room {float((rhs - lhs) * S):.3f} units")
    drift = (2 * K + 4 * P) * H + 2 * (K + P) * DELTA
    check(F('1.00119224') <= NATIVE_Q - drift, 'closed_constants: 1.00119224 <= nativeQ - drift')
    check(TARGET <= NQ - drift, f"drift': target <= nQ' - drift (room {float(NQ - drift - TARGET):.3e})")
    check(TARGET + F('0.00002564') == F('1.00119224'), "nQ' lowers nativeQ by exactly 1.00119224 - target")
    check(NQ >= 0, "nQ' >= 0")
    excess = TARGET - 1 - REMOVED - DEBIT
    old_excess = RELAXED_TARGET - 1 - REMOVED - DEBIT
    check(excess > GAIN, f'margin: excess {float(excess):.6e} > gain {float(GAIN):.0e}')
    check(excess - F(1, 10 ** 6) >= 0, 'excess keeps at least 1e-6 of the original mass')
    print(f'     relaxed excess {float(old_excess):.6e}, spent {float(old_excess - excess):.6e}')

    # The aggregate with the table RoundedCaps.target, for comparison.
    old_sums = [sum(old[c][r] for c in range(37)) for r in range(5)]
    old_room = 37 * old_sums[1] + old_sums[2] + old_sums[3] - old_sums[4] - (NATIVE_Q - F(2, 10 ** 5)) * old_sums[0]
    print(f'     old exact aggregate room {float(old_room):.3f} units; new {float((rhs - lhs) * S):.3f} units')

    # Per-cap slack against the certificates.
    for r in (1, 2, 3):
        rows = []
        for c in range(37):
            v = rec[c][FORMS[r]][0] * S
            slack = v - new[c][r]
            if slack < 0:
                raise SystemExit(f'FAILED: column {r} cap {c} exceeds the certificate lower end')
            if c not in SETTLED:
                rows.append((slack, c, v))
        rows.sort()
        lo = rows[0]
        changing = min(x for x in rows if x[1] in CHANGING)
        rel = min(rows, key=lambda x: x[0] / abs(x[2]) if x[2] else F(10 ** 9))
        print(f'ok   {FORMS[r]:4s}: all 37 caps below the certificate lower ends; min slack {float(lo[0]):.4f} units '
              f'(cap {lo[1]}), min at changing caps {float(changing[0]):.4f} (cap {changing[1]}), '
              f'min relative {float(rel[0] / abs(rel[2])):.3e} (cap {rel[1]})')
        print('       ' + ' '.join(f'{c}:{float(s):.2f}' for s, c, _ in sorted(rows, key=lambda x: x[1])))
    for c in sorted(SETTLED):
        print(f'     settled cap {c}: slack core/first/last ' +
              '/'.join(f'{float(rec[c][FORMS[r]][0] * S - new[c][r]):.3g}' for r in (1, 2, 3)) +
              ' (proved by PositiveCap.bound, not by the certificates)')
    print('All checks passed.')


if __name__ == '__main__':
    main()
