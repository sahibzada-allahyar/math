"""Exact data for the 444 scheduled high-edge rows, read from the Lean sources.

Everything the generated Lean modules state as a literal is computed here with
exact integer and rational arithmetic, mirroring the Lean definitions:
`HighPanelSchedule.data`, `HighPanelTiltBook.table`, `HighPanelCensus.lo/hi`,
`HighLinearControls.basisControl`, `HighRawSpline.signedRow`,
`HighMethodWords.word`, `HighDotArithmetic.coefficient/row/subtotal` and
`HighGramArithmetic.interiorValue/reduced/down/up`.
"""
from fractions import Fraction as Q
from functools import cache
import json
from math import lcm
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ARCHIVE = HERE.parent / "data"
LEAN = HERE.parents[1] / "lean" / "proof"
STAGE = HERE / "high_rows"
# Lean modules that are read here and are not part of the build in ../../lean; they are in this directory.
LOCAL_LEAN = {"TrialHighCachedControl180.lean", "TrialHighDotArithmetic180.lean", "TrialHighLinearControls180.lean",
              "TrialHighPanelCoefficients180.lean", "TrialHighRawPlanBook180.lean", "TrialHighRoundedPair180.lean",
              "TrialHighScheduledComparison180.lean"}
sys.path.insert(0, str(ARCHIVE))
sys.path.insert(0, str(HERE))

STORED_DEN = 2361183241434822606848  # HighLinearControlWords.storedDenominator = coeffDen
SITE_BITS = 224
SIGS = ((), (2,), (3,), (4,), (2, 2), (5,), (2, 3), (6,), (2, 4), (3, 3), (2, 2, 2))
RATES = (55, 75)


def lean_path(name):
    return (HERE if name in LOCAL_LEAN else LEAN) / name


def lean(name):
    return lean_path(name).read_text()


@cache
def schedule():
    """Rows of `HighPanelSchedule.data`: (a, b, d, s, tilt, method, qn, qd, units)."""
    text = lean("TrialHighPanelSchedule180.lean")
    rows = re.findall(r"⟨\((\d+),(\d+),(\d+),(\d+)\), (\d+), (\d+), (\d+), (\d+), (\d+)⟩", text)
    rows = [tuple(map(int, r)) for r in rows]
    assert len(rows) == 444
    return rows


@cache
def tilt_book():
    text = lean("TrialHighPanelTiltBook180.lean")
    body = text.split("def table : Array Row := #[", 1)[1].split("\n]", 1)[0]
    rows = [tuple(map(int, r)) for r in re.findall(r"⟨(\d+), (\d+), (\d+)⟩", body)]
    return rows


def symmetry(a, b):
    return 2 if a == b else 1


# ---------------------------------------------------------------- geometry
RADIUS = (130964, 130964, 130825, 130825, 129997, 125536, 124707, 123370, 117732)
LOWER_INDEX = (44022, 46567, 47096, 58332, 60089, 61104, 63177, 64599, 65536)


@cache
def knots():
    text = lean("TrialMassSplineSpan180.lean")
    body = text.split("def records", 1)[1].split("\n\n", 1)[0]
    pairs = re.findall(r"#\[(\d+),(\d+)\]", body)
    return [Q(int(a), int(b)) for a, b in pairs]


def knot(i):
    k = knots()
    return k[i] if i < len(k) else Q(0)


def sample(j):
    return (Q(j) + Q(39, 2)) * Q(1399373467, 172031279104000)


def ends(a, b, d, s):
    first = max(102994, LOWER_INDEX[a] + LOWER_INDEX[b])
    start = first + d * 4096
    last = min(start + 4095, RADIUS[b])
    return max(sample(start), knot(s)), min(sample(last), knot(s + 1))


def controls(span, left, right):
    from global_amplitude import controls as c, source
    ks, _ = source()
    return c(ks, span, left, right)


@cache
def basis(i):
    a, b, d, s = schedule()[i][:4]
    left, right = ends(a, b, d, s)
    rows = controls(s, left, right)
    den = lcm(*(x.denominator for r in rows for x in r))
    return [[int(x * den) for x in r] for r in rows], den


# ---------------------------------------------------------------- radial rows
@cache
def frozen():
    return json.loads((LEAN / "frozen_band_tables.json").read_text())


BAND_SUFFIX = (0, 1, 1, 2, 2, 2, 2, 2, 2)


@cache
def radial_rows(suffix):
    """`HighRawSpline.signedRow suffix (p/11) (p%11) (6+k)` for 24 knot rows."""
    f = frozen()
    assert f["coeffDen"] == STORED_DEN
    out = []
    for knot_ in range(6, 30):
        row = []
        for pair in range(9):
            for sig, powers in enumerate(SIGS):
                word = sum(f["coeff"][((pair * 3 + c) * 11 + sig) * 30 + knot_] for c in range(suffix, 3))
                row.append(word * 39 ** (sum(powers) - len(powers)))
        out.append(row)
    return out


def radial(i):
    a, b, d, s = schedule()[i][:4]
    rows = radial_rows(BAND_SUFFIX[b])
    return [rows[s - 3 + k - 6] for k in range(4)]


# ---------------------------------------------------------------- method
def center(code, i):
    if code == 1:
        return 1
    if code == 2:
        return 4 if i == 0 else 0
    return 4 if i == 3 else 0


def method_words(code, n, d):
    if code == 0:
        return [[int(i == j) for j in range(4)] for i in range(4)], 1
    Z = []
    for i in range(4):
        row = []
        for j in range(4):
            u, v = center(code, i), center(code, j)
            row.append((n + d) * (n * u * v + d * (16 * int(i == j) - 8 * v + 4 * u * v)))
        Z.append(row)
    return Z, 16 * n * d


# ---------------------------------------------------------------- dot arithmetic
END_LIST = [
    [((0,0),(0,0))],
    [((0,0),(0,1)),((0,0),(1,0)),((0,1),(0,0)),((1,0),(0,0))],
    [((0,0),(0,2)),((0,0),(2,0)),((0,2),(0,0)),((2,0),(0,0))],
    [((0,1),(0,1)),((1,0),(1,0))],
    [((0,1),(0,2)),((0,2),(0,1)),((1,0),(2,0)),((2,0),(1,0))],
    [((0,2),(0,2)),((2,0),(2,0))],
    [((0,0),(1,1)),((0,1),(1,0)),((1,0),(0,1)),((1,1),(0,0))],
    [((0,0),(1,2)),((0,0),(2,1)),((0,1),(2,0)),((0,2),(1,0)),((1,0),(0,2)),((1,2),(0,0)),((2,0),(0,1)),((2,1),(0,0))],
    [((0,1),(1,1)),((1,0),(1,1)),((1,1),(0,1)),((1,1),(1,0))],
    [((0,1),(1,2)),((0,2),(1,1)),((1,0),(2,1)),((1,1),(0,2)),((1,1),(2,0)),((1,2),(0,1)),((2,0),(1,1)),((2,1),(1,0))],
    [((0,2),(1,2)),((1,2),(0,2)),((2,0),(2,1)),((2,1),(2,0))],
    [((0,0),(2,2)),((0,2),(2,0)),((2,0),(0,2)),((2,2),(0,0))],
    [((0,1),(2,1)),((1,0),(1,2)),((1,2),(1,0)),((2,1),(0,1))],
    [((0,1),(2,2)),((0,2),(2,1)),((1,0),(2,2)),((1,2),(2,0)),((2,0),(1,2)),((2,1),(0,2)),((2,2),(0,1)),((2,2),(1,0))],
    [((0,2),(2,2)),((2,0),(2,2)),((2,2),(0,2)),((2,2),(2,0))],
    [((1,1),(1,1))],
    [((1,1),(1,2)),((1,1),(2,1)),((1,2),(1,1)),((2,1),(1,1))],
    [((1,2),(1,2)),((2,1),(2,1))],
    [((1,1),(2,2)),((1,2),(2,1)),((2,1),(1,2)),((2,2),(1,1))],
    [((1,2),(2,2)),((2,1),(2,2)),((2,2),(1,2)),((2,2),(2,1))],
    [((2,2),(2,2))]]


@cache
def power_list():
    text = lean("TrialHighDotArithmetic180.lean")
    body = text.split("def powerList", 1)[1].split(": Array (List PowerChoice)", 1)[0]
    rows = body.split("\n")
    out = []
    for r in rows:
        if "[" in r and "(" in r:
            out.append([tuple(map(int, x)) for x in re.findall(r"\((\d+),(\d+)\)", r)])
    assert len(out) == 53
    return out


@cache
def check_end_list():
    text = lean("TrialHighDotArithmetic180.lean")
    body = text.split("def endList", 1)[1].split(": Array (List EndChoice)", 1)[0]
    rows = [r for r in body.split("\n") if "((" in r]
    parsed = [[((int(a), int(b)), (int(c), int(d))) for a, b, c, d in
               re.findall(r"\(\((\d),(\d)\),\((\d),(\d)\)\)", r)] for r in rows]
    assert parsed == END_LIST
    return True


def channel(a, b, s):
    return (3 * a + b) * 11 + s


def coefficients(C, W):
    check_end_list()
    P = power_list()
    out = []
    for e in range(21):
        row = []
        for s in range(53):
            total = 0
            for u in END_LIST[e]:
                for v in P[s]:
                    p = channel(u[0][0], u[0][1], v[0])
                    q = channel(u[1][0], u[1][1], v[1])
                    total += sum(C[i][p] * W[i][q] for i in range(4))
            row.append(total)
        out.append(row)
    return out


def subtotal(T, G, upper):
    return sum(sum((T[e][s] * G[e][s] if (T[e][s] >= 0) == upper else 0) for s in range(53)) for e in range(21))


# ---------------------------------------------------------------- Gram words
@cache
def gram_table():
    rows = json.loads((STAGE / "high-compact-gram-words.json").read_text())
    return {tuple(r[:3]): (r[3], r[4], r[5]) for r in rows}


def grid(words):
    return [words[j:j + 53] for j in range(0, 1113, 53)]


@cache
def plans():
    text = lean("TrialHighRawPlanBook180.lean")
    out = []
    for n in range(53):
        body = text.split(f"private def row{n} : HighPlanArithmetic.Plan := [", 1)[1].split("\n]", 1)[0]
        out.append([(list(map(int, a.split(","))) if a.strip() else [], int(c))
                    for a, c in re.findall(r"\(\[([^\]]*)\], (\d+)\)", body)])
    return out


FIRST = (0, 1, 2, 1, 3)
SECOND = (0, 0, 0, 2, 0)
OWNERS = ((1,2,0,1),(2,1,0,1),(1,0,2,37),(2,0,1,37),(0,1,2,37),(0,2,1,37),(0,0,3,1332),(3,0,0,1),(0,3,0,1),(0,0,4,37))
END_CODES = ((0,0),(0,1),(0,2),(0,4),(0,5),(0,8),(1,1),(1,2),(1,4),(1,5),(1,8),
             (2,2),(2,4),(2,5),(2,8),(4,4),(4,5),(4,8),(5,5),(5,8),(8,8))


def interior(Kside, plan, i):
    """`HighGramArithmetic.interiorValue`; Kside[m][n] for n < 13, zero beyond."""
    def K(m, n):
        return Kside[m][n] if n < 13 else 0
    def atom(n):
        q, r = divmod(n, 3)
        return K(FIRST[i], q) if r == 0 else K(SECOND[i], q) if r == 1 else K(0, q)
    total = 0
    for powers, c in plan:
        prod = 1
        for x in powers:
            prod *= atom(x)
        total += c * prod
    return total


def reduced(Eside, V, e, s):
    a, b = END_CODES[e]
    return sum(n * (Eside[l][a] * Eside[r][b] * V[j][s]) for l, r, j, n in OWNERS)


@cache
def moments(rate):
    from check_high_integer_panels import Moments
    band_archive = json.loads((ARCHIVE / "signed_pair_gram.json").read_text())
    edges = [Q(tick) / 2624990 for tick in band_archive["maximum_band_edges_ticks"]]
    book = json.loads((STAGE / "high-tail-book.json").read_text())
    return Moments(book, list(zip(edges, edges[1:])), rate)


@cache
def pair_data(rate, a, b):
    """Site words, interiors and rounded reduced Grams for one triple."""
    m = moments(rate)
    tags = ((), (a,), (b,), (a, b))
    core = [[list(m.power(t, p)) for p in range(13)] for t in tags]
    endw = [[list(m.endpoint(t, x, y)) for x in range(3) for y in range(3)] for t in tags]
    shifts, lo, hi = gram_table()[(rate, a, b)]
    P = plans()
    out = {}
    for side, words, name in ((0, lo, "lower"), (1, hi, "upper")):
        Kside = [[core[t][n][side] for n in range(13)] for t in range(4)]
        Eside = [[endw[t][n][side] for n in range(9)] for t in range(4)]
        V = [[interior(Kside, P[s], i) for s in range(53)] for i in range(5)]
        sh = shifts[side]
        red = [[reduced(Eside, V, e, s) for s in range(53)] for e in range(21)]
        if side == 0:
            mine = [[x >> sh for x in r] for r in red]
        else:
            mine = [[(x + (1 << sh) - 1) >> sh for x in r] for r in red]
        if mine != grid(words):
            raise ValueError(f"Reduced Gram differs from the archived words at {rate, a, b, name}")
        out[name] = dict(V=V, words=mine, shift=sh, factor=Kside[0][0] ** 29 << sh)
    out["core"] = core
    out["ends"] = endw
    return out


def rate_of(i):
    return RATES[tilt_book()[schedule()[i][4]][0]]


def triple(i):
    a, b = schedule()[i][:2]
    return rate_of(i), a, b


# ---------------------------------------------------------------- row
@cache
def row(i):
    a, b, d, s, tilt, code, qn, qd, units = schedule()[i]
    rate = rate_of(i)
    B, bden = basis(i)
    R = radial(i)
    C = [[sum(R[k][p] * B[k][j] for k in range(4)) for p in range(99)] for j in range(4)]
    Z, mden = method_words(code, qn, qd)
    W = [[sum(Z[j][k] * C[k][p] for k in range(4)) for p in range(99)] for j in range(4)]
    T = coefficients(C, W)
    g = pair_data(rate, a, b)
    lo, hi = g["lower"], g["upper"]
    total = lo["factor"] * subtotal(T, lo["words"], False) + hi["factor"] * subtotal(T, hi["words"], True)
    full = STORED_DEN * bden
    tiltw = tilt_book()[tilt][2]
    rhs = units * (full * full * mden * 2 ** (224 * 39) * symmetry(a, b)) * tiltw * 446
    lhs = total * 2 ** 320 * 10 ** 94
    return dict(i=i, a=a, b=b, d=d, s=s, rate=rate, code=code, qn=qn, qd=qd, units=units, tilt=tiltw,
                B=B, bden=bden, R=R, C=C, Z=Z, mden=mden, W=W, T=T, lhs=lhs, rhs=rhs, ok=lhs <= rhs,
                slack=float(Q(rhs - lhs, rhs)) if rhs else None)
