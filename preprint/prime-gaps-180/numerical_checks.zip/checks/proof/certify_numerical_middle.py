"""Exact-rational certificate check for the middle-group fields of `ReceiptGap.Numerical`.

The fields are `middleRaw i` for the 22 middle groups and the two certified decompositions
`middlePair` (`CertifiedBudget.MiddlePair`) and `middleJoint` (`CertifiedBudget.MiddleJoint`).
Their worker bounds are stated for the tabulated fields at the frozen `RestorationRows`, with an
L² transfer of tolerance 2.5e-7 to Lean's actual fields; `CertifiedBudget.middlePair` and
`CertifiedBudget.middleJoint` prove the `SlackBudget.Bounds` fields from them.
This script

1. pins the archived worker certificates by SHA-256 and checks their cross-pins;
2. re-aggregates the Jackson/ellipsoid mass book from its exact rational panels;
3. re-derives the frozen rows of `RestorationRows` (`book_row`) and every constant of
   `SlackRows` (absolute masses, tick masses, pair images, joint charges, integer Young
   parameters and costs) from the certificates, and compares them with the Lean source;
4. re-checks the rational inequalities proved in `SlackRows`, the totals and outer
   constant used in `SlackBudget`, and the integer rows `CertifiedBudget.joint_rows` and
   `CertifiedBudget.pair_rows` together with their exact rational meaning;
5. measures the headroom of each field over its certificate, including the transfer from the
   archived tabulated single and pair fields to the actual fields used in Lean;
6. optionally re-executes the producer aggregation code (`--no-replay` skips this).

All arithmetic is in `fractions.Fraction` and integers. The script exits with status 1 if
any check fails. The replays need numpy, scipy, python-flint, gmpy2 and scs, and the
external package that `../data/fetch_h1_backend.py` downloads.
"""
from fractions import Fraction as Q
from hashlib import sha256
from math import isqrt
from pathlib import Path
import argparse
import json
import re
import sys

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent / "data"
LEAN_DIR = ROOT.parents[1] / "lean" / "proof"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(WORK))
from archived_sources import PREFIX  # noqa: E402
from audit_signed_restoration_rows import book_row, ceil, ceil_sqrt  # noqa: E402

PINS = {
    "middle_restoration_progress.json": "887fc01b08d8aa87041427ba372075fa33eb9c27890f0ecd6328f59839e35c59",
    "middle_charge_full.json": "408f565f74639ccee90b2a4b22af5fb56b08c4b3038d839c3aa9d79973488dfb",
    "middle_pair_union.json": "00a01ea5b1d003dce87e2ee5d3d89c1350ffcfaf729ad1cfb9dcc1cdc3b5fc04",
    "localized_operator.json": "b932eb0e47c5e3342c91a62faa0ac23b63fa4c48eabda48cf15efee2f91f2d17",
    "endpoint_symmetry.json": "bbc69c4be9125cbb546927b0e7390ecd0217748279c1d697aaa98a39140d5502",
    "cap_law_transfer.json": "ed9488dd445fac92da256d97f8c3f53684906823529875c033d6d6248072f7b3",
    "middle_singles/manifest.json": "a6e1d4fdf0df774d2d32648a5d627915992ce5f5f05f0059a47cb0338e1d0829",
}
LEAN = ["TrialSlackRows180.lean", "TrialSlackBudget180.lean", "TrialRestorationRows180.lean", "TrialCertifiedBudget180.lean",
        "TrialRemovalReceipts180.lean", "TrialReceiptGap180.lean", "TrialRestorationBudget180.lean",
        "TrialRestorationCharge180.lean", "TrialNegativePriceRuns180.lean"]
EDGES = list(range(90_000, 940_000, 40_000))
TICK = 10**12
FLOOR = Q("94.17312")             # SlackBudget.Bounds.floor, from Numerical.capMass
EPS = Q(1, 4_000_000)             # 2.5e-7, the field-norm tolerance in book_row and RestorationCombined
RAW_HEAD, PAIR_HEAD, JOINT_HEAD = Q(105, 100), Q(13, 10), Q(101, 100)
T_JOINT = Q(1, 20_000)            # one Young weight for the joint transfer, all 22 rows
LAMBDA_PAIR = Q(29, 100)          # (a)^2 <= (1+l) b^2 + (1+1/l) (a-b)^2 for the pair transfer

failures = []


def check(ok, message):
    if not ok:
        failures.append(message)
    return ok


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def upper_decimal(x, places=18):
    scale = 10**places
    n = -(-x.numerator * scale // x.denominator)
    return Q(n, scale)


def sqrt_up(x, scale=10**18):
    return ceil_sqrt(Q(x), scale)


def sqrt_down(x, scale=10**18):
    x = Q(x)
    return Q(isqrt(x.numerator * scale**2 // x.denominator), scale)


def lean_rows(name):
    text = (LEAN_DIR / name).read_text()
    return [tuple(map(int, r.split(","))) for r in re.findall(r"^  ⟨([\d, ]+)⟩", text, re.M)]


def lean_absolute():
    text = (LEAN_DIR / "TrialSlackRows180.lean").read_text()
    block = text.split("def absolute : Fin 22 → ℚ := ![", 1)[1].split("]", 1)[0]
    return [Q(int(a), int(b)) for a, b in re.findall(r"(\d+)/(\d+)", block)]


def lean_literal(name, pattern):
    match = re.search(pattern, (LEAN_DIR / name).read_text(), re.M)
    check(match is not None, f"{name}: pattern {pattern!r} not found")
    return match


def statement_guard():
    """The Lean statements this certificate is about must not have drifted."""
    gap = (LEAN_DIR / "TrialReceiptGap180.lean").read_text()
    budget = (LEAN_DIR / "TrialSlackBudget180.lean").read_text()
    certified = (LEAN_DIR / "TrialCertifiedBudget180.lean").read_text()
    raw = "middleRaw (i : Fin 22) : (100:ℝ)^39 * StructuralRun.layerMass (middle i) ≤ (SlackRows.absolute i : ℝ)"
    check(raw in gap, "ReceiptGap.Numerical field changed: middleRaw")
    # The slack fields proved by CertifiedBudget.bounds.
    for s in [raw,
              "middlePair (i : Fin 22) : restrictedSq (middle i) negativePair ≤\n    RestorationRows.ticks (SlackRows.rows i).pairImage * originalMass",
              "middleJoint (i : Fin 22) : joint (middle i) ≤ RestorationRows.ticks (SlackRows.rows i).joint * originalMass"]:
        check(s in budget, f"SlackBudget.Bounds field changed: {s.splitlines()[0]}")
    # The certified decompositions assumed by ReceiptGap.Numerical.
    for s in ["middlePair : ∃ (P : SignedErasure.Full → ℝ) (ν : Fin 22 → Measure SignedErasure.Full)\n    (E : Fin 22 → Set SignedErasure.Full),\n    CertifiedBudget.MiddlePair P ν E",
              "middleJoint : ∃ (V : SignedErasure.Full → ℝ) (S : Fin 22 → SignedErasure.Full → ℝ), CertifiedBudget.MiddleJoint V S",
              "CertifiedBudget.bounds (floor n)"]:
        check(s in gap, f"ReceiptGap.Numerical certified field changed: {s.splitlines()[0]}")
    for s in ["  bank (i : Fin 22) : prod 39 ≤ ν i",
              "  superset (i : Fin 22) : {x | GateDeletion.layer (.group (middle i)) x ≠ 0} ⊆ E i",
              "  transfer : ∫ x, (negativePair x - P x)^2 ∂prod 39 ≤ (0.00000025:ℝ)^2 * originalMass",
              "  worker (i : Fin 22) : ∫ x in E i, (P x)^2 ∂ν i ≤\n    RestorationRows.ticks (RestorationRows.rows i).pairImage * originalMass",
              "  transfer : ∫ x, (singles x - V x)^2 ∂prod 39 ≤ (0.00000025:ℝ)^2 * originalMass",
              "  schur (i : Fin 22) (x : Full) : GateDeletion.layer (.group (middle i)) x ≠ 0 → multiplier x ≤ S i x",
              "  worker (i : Fin 22) : 2*(∫ x, GateDeletion.layer (.group (middle i)) x * V x ∂prod 39) +\n"
              "      (∫ x, S i x * (GateDeletion.layer (.group (middle i)) x)^2 ∂prod 39) -\n"
              "      0.6865*StructuralRun.layerMass (middle i) ≤\n"
              "    RestorationRows.ticks (RestorationRows.rows i).joint * originalMass",
              "20000*(RestorationRows.rows i).joint + (SlackRows.rows i).mass + 25000000 ≤\n    20000*(SlackRows.rows i).joint",
              "59856*(RestorationRows.rows i).pairImage + 12900 ≤\n    46400*(SlackRows.rows i).pairImage",
              "have y := young (middle i) (fun x => singles x - V x) W (1/20000) (by norm_num)",
              "split ((prod 39).restrict (E i)) pair_reg' c.regular (l := 29/100) (by norm_num)"]:
        check(s in certified, f"CertifiedBudget changed: {s.splitlines()[0]}")
    defs = (LEAN_DIR / "TrialRestorationBudget180.lean").read_text()
    for s in ["def negativePair (x : Full) := -RestorationField.pair x",
              "def singles (x : Full) := rho*(∑ i : Fin 39, ∑ s : Fin 521,RestorationField.single i s x)",
              "def joint (g : Fin 24) := 2*(∫ x : Full,GateDeletion.layer (.group g) x * singles x ∂prod 39) +\n  weightGroup g - 0.6865*StructuralRun.layerMass g"]:
        check(s in defs, f"RestorationBudget definition changed: {s.splitlines()[0]}")
    budget_const = lean_literal("TrialNegativePriceRuns180.lean", r"^def budget : ℝ := (\d+)/(\d+)$")
    if budget_const:
        check(Q(int(budget_const[1]), int(budget_const[2])) - Q("0.6865") == Q("1.312522"),
              "uniform_group constant 1.312522 is not budget - 0.6865")


def jackson_book(book):
    """Exact re-aggregation of the mass book from its rational panels."""
    sums, negative, schemes = {}, {}, {}
    for row in book["groups"]:
        values = []
        for option in row["inputs"]:
            d = sum((Q(x) for _, _, x in option["panels"]), Q(0))
            check(upper_decimal(d) == Q(option["scaled_deleted_upper"]),
                  f"mass option {row['cap']},{row['edge']} is not the upward decimal of its panels")
            check(all(Q(x) > 0 for _, _, x in option["panels"]), "nonpositive panel")
            values.append((d, option["scheme"]))
        d, scheme = min(values)
        check(upper_decimal(d) == Q(row["scaled_deleted_upper"]), f"group {row['cap']},{row['edge']} minimum")
        sums[row["edge"]] = sums.get(row["edge"], Q(0)) + d
        negative[row["edge"]] = negative.get(row["edge"], Q(0)) + Q(row["scaled_negative_upper"])
        schemes[scheme] = schemes.get(scheme, Q(0)) + d
    check(sorted(sums) == EDGES, "mass book does not cover the 22 middle groups")
    totals = {}
    for start, stop, dtot, ntot in book["edge_totals"]:
        check(stop == min(start + 40_000, 940_000), "edge total window")
        check(Q(dtot) == upper_decimal(sums[start]), f"edge total {start} is not the upward decimal of the exact sum")
        check(Q(dtot) >= sums[start], f"edge total {start} below the exact sum")
        totals[start] = Q(dtot), Q(ntot)
    return sums, totals, schemes


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--no-replay", action="store_true", help="skip re-execution of the producer aggregation code")
    ap.add_argument("--json", type=Path, help="write the summary here")
    args = ap.parse_args()

    hashes = {}
    for name, pin in PINS.items():
        hashes[name] = digest(WORK / name)
        check(hashes[name] == pin, f"{name} changed: {hashes[name]}")
    for name in LEAN:
        hashes[name] = digest(LEAN_DIR / name)
    statement_guard()

    progress = json.loads((WORK / "middle_restoration_progress.json").read_bytes())
    book = json.loads((WORK / "middle_charge_full.json").read_bytes())
    pair_union = json.loads((WORK / "middle_pair_union.json").read_bytes())
    operator = json.loads((WORK / "localized_operator.json").read_bytes())
    symmetry = json.loads((WORK / "endpoint_symmetry.json").read_bytes())
    cap_law = json.loads((WORK / "cap_law_transfer.json").read_bytes())

    pinned_inputs = progress["input_sha256"]
    for name in ("middle_charge_full.json", "middle_pair_union.json",
                 "localized_operator.json", "endpoint_symmetry.json", "cap_law_transfer.json"):
        check(pinned_inputs.get(PREFIX + name) == hashes[name], f"restoration certificate does not pin {name}")
    check(operator["cap_law_receipt_sha256"] == hashes["cap_law_transfer.json"], "operator certificate cap-law pin")
    middle = progress["middle"]
    check([r["start"] for r in middle] == EDGES, "restoration certificate groups")
    check(progress["complete_restoration_inputs"] and not any(r["required_inputs_missing"] for r in middle),
          "restoration certificate incomplete")
    check(all(r["pair_source"] == "local" for r in middle) and progress["middle_pair_union_edges"] == [],
          "a middle group uses the whole-union pair fallback")
    continuum = Q(progress["continuum_scaled_ordinary_floor"])
    fr = continuum / FLOOR
    check(1 <= fr <= Q("1.00000011"), "floor ratio")

    # 2. Mass book.
    exact_mass, edge_totals, schemes = jackson_book(book)
    for r in middle:
        e = r["start"]
        check(Q(r["deleted_upper"]) * continuum == edge_totals[e][0], f"deleted_upper {e} differs from the mass book")
        check(Q(r["weighted_schur_upper"]) * continuum == edge_totals[e][1], f"weighted_schur_upper {e} differs")
        check(Q(r["pair_squared_upper"]) * continuum == Q(pair_union["edges"][str(e)]["raw_upper"]),
              f"pair_squared_upper {e} differs from the pair union")
        check(pair_union["edges"][str(e)]["complete"] and pair_union["edges"][str(e)]["cases"] == 13, f"pair cases {e}")
    check(pair_union["complete"] == pair_union["expected"] == 286, "pair union coverage")

    # 3. Frozen rows and slack rows.
    old = lean_rows("TrialRestorationRows180.lean")
    check(old == [book_row(r, fr) for r in middle], "RestorationRows differ from book_row")
    slack = lean_rows("TrialSlackRows180.lean")
    absolute = lean_absolute()
    check(len(slack) == len(absolute) == len(old) == 22, "row counts")
    removal = (LEAN_DIR / "TrialRemovalReceipts180.lean").read_text().split("def middle : Fin 22 → ℚ := ![", 1)[1].split("]", 1)[0]
    removal = [Q(int(a), int(b)) for a, b in re.findall(r"(\d+)/(\d+)", removal)]

    def joint_cost(J, D, P, t):
        return Q(J) + Q(t * D, 10**6) + Q(10**6 * P, t)

    derived_rows, per_row = [], []
    for i, (r, o, s, a) in enumerate(zip(middle, old, slack, absolute)):
        e = r["start"]
        total = edge_totals[e][0]
        A = Q(ceil(RAW_HEAD * total * 10**17), 10**17)
        D = ceil(A * TICK / FLOOR)
        P = ceil(PAIR_HEAD * o[1])
        J = ceil(JOINT_HEAD * o[2])
        lo = isqrt(P * 10**12 // D)
        y = min(range(max(1, lo - 2), lo + 3), key=lambda t: joint_cost(J, D, P, t))
        check(all(joint_cost(J, D, P, y) <= joint_cost(J, D, P, t) for t in (y - 1, y + 1)), f"row {i} Young not locally optimal")
        C = ceil(joint_cost(J, D, P, y))
        derived_rows.append((D, P, J, y, C))
        check(A == a, f"SlackRows.absolute {i} differs: derived {A}")
        check((D, P, J, y, C) == s, f"SlackRows.rows {i} differs: derived {(D, P, J, y, C)}, Lean {s}")
        check(removal[i] == total, f"RemovalReceipts.middle {i} differs from the book edge total")

        # 4. SlackRows theorems.
        Dl, Pl, Jl, yl, Cl = s
        check(yl > 0 and Jl * yl * 10**6 + yl**2 * Dl + Pl * 10**12 <= Cl * yl * 10**6, f"SlackRows.arithmetic {i}")
        check(a <= Q(Dl, TICK) * FLOOR, f"SlackRows.absolute_price {i}")

        # 5. Headroom and field transfers, in ticks of the original mass.
        raw_margin = a / exact_mass[e]
        p_rec = fr * Q(r["pair_squared_upper"]) * TICK
        j_rec = fr * Q(r["joint_singles_and_schur_upper"]) * TICK
        per_row.append(dict(group=i, start=e, raw_receipt=exact_mass[e], raw_ratio=raw_margin,
                            pair_receipt=p_rec, joint_receipt=j_rec, mass_ticks=Dl, pair=Pl, joint=Jl))
        check(raw_margin >= RAW_HEAD, f"middleRaw {i}: allowance below 1.05 x exact Jackson sum")

    # CertifiedBudget.joint_rows / pair_rows and their rational meaning:
    # ticks J + t ticks D + eps^2/t <= ticks J'  with t = 1/20000, and
    # (1+l) ticks P + (1+1/l) eps^2 <= ticks P'   with l = 29/100.
    check(EPS == Q("0.00000025"), "eps literal")
    check(EPS**2 * TICK / T_JOINT * 20_000 == 25_000_000, "joint_rows constant")
    check((1 + LAMBDA_PAIR) * 46_400 == 59_856 and (1 + 1 / LAMBDA_PAIR) * EPS**2 * TICK * 46_400 == 12_900,
          "pair_rows constants")
    for i, (o, s) in enumerate(zip(old, slack)):
        check(20_000 * o[2] + s[0] + 25_000_000 <= 20_000 * s[2], f"CertifiedBudget.joint_rows {i}")
        check(59_856 * o[1] + 12_900 <= 46_400 * s[1], f"CertifiedBudget.pair_rows {i}")
        check(Q(o[2]) + T_JOINT * s[0] + EPS**2 * TICK / T_JOINT <= s[2], f"CertifiedBudget.joint_key {i}")
        check((1 + LAMBDA_PAIR) * o[1] + (1 + 1 / LAMBDA_PAIR) * EPS**2 * TICK <= s[1], f"CertifiedBudget.pair_key {i}")

    check(sum(s[4] for s in slack) == 1047071290, "SlackRows.total")
    check(sum(s[0] for s in slack) == 160362542, "SlackRows.mass_total")

    # SlackBudget totals.
    low = Q(3303228195853457002671, 905631431450000000000000000)
    check(Q(int(lean_literal("TrialRemovalReceipts180.lean", r"^def low : ℚ := (\d+)/(\d+)$")[1]),
            int(lean_literal("TrialRemovalReceipts180.lean", r"^def low : ℚ := (\d+)/(\d+)$")[2])) == low, "RemovalReceipts.low")
    check(low <= Q(3647432, TICK), "SlackBudget.low_ticks")
    low_image, high_image, high_mass = 1375543, 206889941, 4135470
    outer = (Q(3, 5) + Q("1.312522")) * 3647432 + Q(5, 3) * low_image + (7 + Q("1.312522")) * high_mass + Q(1, 7) * high_image
    check(outer <= 73200257, f"SlackBudget.outer: {float(outer)}")
    payment = 1047071290 + 73200257
    check(payment == 1120271547, "SlackBudget.payment")
    check(Q(payment, TICK) <= Q("0.001121271547"), "SlackBudget.removed")
    check(Q(3647432 + 160362542 + high_mass, TICK) <= Q("0.00017"), "SlackBudget.removed_mass")

    # Field-transfer constants (the paper's appendix on error analyses).
    H = Q(operator["true_single_site_chi_upper"])
    check(H**2 * (1 - Q(cap_law["relative_bin_bound"])) > Q(cap_law["squared_hellinger_bound"]), "H versus cap-law certificate")
    eps_single = Q(operator["single_error_over_chi_upper"]) * H
    eps_pair = Q(operator["pair_bare_norm_upper"]) * (2 * H + H * H)
    check(Q(pair_union["pair_norm_transfer"]) == eps_pair, "pair norm transfer differs from operator certificate")
    eps_swap = Q(symmetry["norm_of_F_minus_swapped_F_over_norm_of_F_upper"]) * Q("0.28") * (1 + H)
    check(eps_swap < Q("0.0000000005881"), "swap error")
    check(eps_single + eps_pair <= Q(operator["relative_image_norm_error_upper"]), "combined field error")
    eps_s = eps_single + eps_swap
    check(eps_s <= EPS and eps_pair <= EPS, "a field error exceeds 2.5e-7")

    worst_cauchy = Q(0)
    for row in per_row:
        m, p, J = row["mass_ticks"], row["pair_receipt"], row["joint_receipt"]
        # Pair: sqrt(restrictedSq actual) <= sqrt(restrictedSq tabulated) + eps_pair * sqrt(M).
        need_pair_tight = (sqrt_up(p / TICK) + eps_pair) ** 2 * TICK
        need_pair_book = (sqrt_up(p / TICK) + EPS) ** 2 * TICK
        need_pair_lemma = (1 + LAMBDA_PAIR) * p + (1 + 1 / LAMBDA_PAIR) * EPS**2 * TICK
        # Joint: |2 int layer (singles - V)| <= t m + eps^2/t (Young, per group), or 2 eps sqrt(m) (Cauchy).
        cauchy = 2 * eps_s * sqrt_up(Q(m, TICK)) * TICK
        cauchy_book = 2 * EPS * sqrt_up(Q(m, TICK)) * TICK
        young = T_JOINT * m + EPS**2 * TICK / T_JOINT
        worst_cauchy = max(worst_cauchy, cauchy_book)
        row.update(pair_need_tight=need_pair_tight, pair_ratio=row["pair"] / need_pair_tight,
                   pair_need_lemma=need_pair_lemma, joint_cauchy=cauchy, joint_cauchy_eps=cauchy_book,
                   joint_young=young, joint_spare=row["joint"] - J - young)
        i = row["group"]
        check(need_pair_book <= old[i][1] + 1, f"pair book row {i} does not cover the 2.5e-7 transfer")
        check(row["pair"] >= need_pair_lemma, f"middlePair {i}: slack row below (1+l)p + (1+1/l)eps^2")
        check(row["pair"] >= PAIR_HEAD * need_pair_book, f"middlePair {i}: below 1.3 x transferred certificate")
        check(row["joint"] >= J + young, f"middleJoint {i}: slack row below certificate + Young transfer")
        check(row["joint"] >= JOINT_HEAD * (J + 10_000), f"middleJoint {i}: below 1.01 x (certificate + 10,000)")
        check(old[i][2] - J >= cauchy_book, f"joint book row {i}: 10,000-tick allowance below Cauchy transfer")
        # The approximation fields use the frozen RestorationRows as targets for the
        # tabulated fields; the slack rows must then absorb the Lean transfer lemmas.
        check(J <= old[i][2] and p <= old[i][1], f"row {i}: certificate above the frozen RestorationRows target")
        check(old[i][2] + T_JOINT * m + EPS**2 * TICK / T_JOINT <= row["joint"],
              f"middleJoint {i}: frozen joint + Young transfer exceeds the slack row")
        check((1 + LAMBDA_PAIR) * old[i][1] + (1 + 1 / LAMBDA_PAIR) * EPS**2 * TICK <= row["pair"],
              f"middlePair {i}: (1+l) frozen pair + (1+1/l) eps^2 exceeds the slack row")
        row["joint_spare_from_frozen"] = row["joint"] - old[i][2] - young

    union = 2 * EPS * sqrt_up(Q(sum(r[0] for r in slack), TICK)) * TICK
    replay = {}
    if not args.no_replay:
        sys.path.insert(0, str(WORK))
        import os
        cwd = os.getcwd()
        os.chdir(WORK)
        try:
            from localized_operator import constants
            replay["operator_constants"] = constants() == operator
            from middle_charge_aggregate import verify
            replay["mass_book_with_jackson_inventory"] = verify(book, WORK / "middle_charge_full_inputs")[0] == 286
            from check_middle_pair_union import summarize
            replay["pair_union"] = all(pair_union[k] == v for k, v in summarize(pair_union["manifest"], pair_union["receipts"]).items())
            from cap_share_ledger import joint_uppers
            joint = joint_uppers([WORK / "middle_charge_full.json"], [WORK / "middle_singles"],
                                 replay=progress["joint_weight_witnesses"])
            replay["joint_from_singles_receipts"] = all(Q(r["joint_singles_and_schur_upper"]) == joint[r["start"]] / continuum
                                                        for r in middle)
        finally:
            os.chdir(cwd)
        for name, ok in replay.items():
            check(ok, f"producer replay failed: {name}")

    f = lambda x: float(x)
    summary = dict(
        status="pass" if not failures else "fail", failures=failures, sha256=hashes,
        floor_ratio=str(fr), field_errors=dict(single=f(eps_single), swap=f(eps_swap), pair=f(eps_pair),
                                               single_plus_swap=f(eps_s), tolerance=f(EPS)),
        mass_book_scheme_share={k: f(v / sum(schemes.values())) for k, v in schemes.items()},
        totals=dict(cost=sum(s[4] for s in slack), mass=sum(s[0] for s in slack), outer_bound=f(outer),
                    payment=payment, union_transfer_alternative_ticks=f(union),
                    worst_row_cauchy_transfer_ticks=f(worst_cauchy)),
        rows=[dict(group=r["group"], start=r["start"], raw_ratio=round(f(r["raw_ratio"]), 9),
                   pair_ratio_over_tight_transfer=round(f(r["pair_ratio"]), 6),
                   joint_receipt=f(r["joint_receipt"]), joint_spare_after_transfer=f(r["joint_spare"]),
                   joint_spare_from_frozen=f(r["joint_spare_from_frozen"]),
                   joint_cauchy_ticks=round(f(r["joint_cauchy"]), 1)) for r in per_row],
        replays=replay or "skipped")
    text = json.dumps(summary, indent=1)
    if args.json:
        args.json.write_text(text + "\n")
    print(text)
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
