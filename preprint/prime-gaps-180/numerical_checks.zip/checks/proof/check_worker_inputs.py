"""Exact link between the inputs of the native cap workers and the Lean definitions.

The single-site and debit fields of `ReceiptGap.Numerical` are certified by the
per-cap worker certificates (256 bits; the program is archived as
`../data/archived/h1_b2_cap_worker.py`) and the 160-bit run.
Those workers read their spline from `ts_s39a6.npz` through
`global_amplitude.source()`, their erased fields from binary64
center/radius banks, their marks from `quotient_inputs.cap_cdf` and their
weights from per-cap price files. The Lean definitions read
`frozen_band_tables.json`, the 57-bit grid `PositiveCap.physicalGrid` and the
archived price rows. This program checks, in exact arithmetic, that the two
sides are the same objects:

  spline   coefficients, knots, component rows, step, offset and B-spline basis
  ranges   T.maxIndex, the component suffix, capAt and capIndices against the
           worker geometry, active indices and bank assignment
  grid     every worker CDF array equals the 57-bit column of physicalGrid
  prices   at every native index of all 37 caps, the exact Lean value of
           (rho/100)*keyPrice, its cap jump, (rho/100)*debitPrice, its jump and
           NativeRoleTotals.q lies inside the worker's binary64 ball
  banks    for all 9 geometry banks and every native index J < 131033, the
           exact Lean field
               bank (fun c => erasedCoefficient grid i J c z) k
           (TrialPackedSingleFields180.lean, TrialPackedRoleKernels180.lean),
           summed over the terms that the worker groups into one row, lies in
           the worker's center/radius ball, for i = 0, 1 and 38
           (worker roles `a`, `core`, `b`)

Exact means: integers and rationals throughout. The bank check encloses each Lean
value between two integers over 2^(P+Q) with P = 400 and Q = 340, using an exact
FLINT integer convolution; the enclosure width is below 1e-97 absolute. The
comparison with the binary64 balls is done first with outward-rounded floats and,
for any index where that is inconclusive, again with exact rationals.

  python3 check_worker_inputs.py --payload DIR                 # everything (about 7 minutes, 4.4 GB)
  python3 check_worker_inputs.py --payload DIR --banks none    # skip the bank recomputation
  python3 check_worker_inputs.py --payload DIR --banks 78116,66501
  python3 check_worker_inputs.py --payload DIR --shards DIR2   # also compare generated grid shards

The payload directory is given by `--payload` or by the environment variable
`PAYLOAD`; there is no default. Its manifest hash must equal the certificates' `manifest_sha256`. A cap without its own bank
(an unchanged cap) selects the bank of its geometry cap. Exit status is nonzero
on any failure.
"""
import argparse
import ast
import importlib
import os
from decimal import Decimal
from fractions import Fraction as F
from hashlib import sha256
import json
from math import ceil, lcm
from pathlib import Path
import re
import struct
import sys
import time
from zipfile import ZipFile

import numpy as np

HERE = Path(__file__).resolve().parent
NATIVE = HERE.parent / 'data'
LEAN = HERE.parents[1] / 'lean' / 'proof'
sys.path.insert(0, str(NATIVE))
from archived_sources import PREFIX, recorded_bytes, recorded_digest  # noqa: E402
RECEIPT_256 = NATIVE / 'parallel_quotient_debit.json'
RECEIPT_160 = HERE / 'quotient_and_debit_cert.json'
FROZEN = LEAN / 'frozen_band_tables.json'
FROZEN_SHA = '785527884ca340d8ca12909f3076b422fddf4922e234cdd3a574f74bc70de6ef'

N = 131072
COUNT = N - 39          # worker native indices 0..131032
TICKS = 130965          # Lean `Tick := Fin 130965`
S = F(1399373467, 1312494500)
STEP = F(1399373467, 172031279104000)
RHO = F(2624989, 10**7)
LEDGER = F(4999, 10000)
SIGS = ((), (2,), (3,), (4,), (2, 2), (5,), (2, 3), (6,), (2, 4), (3, 3), (2, 2, 2))
P_BITS, Q_BITS = 400, 340   # kernel and row quantization of the exact bank check

FAILURES = []
T0 = time.monotonic()


def ok(cond, msg):
    print(('ok    ' if cond else 'FAIL  ') + msg, flush=True)
    if not cond:
        FAILURES.append(msg)
    return cond


def note(msg):
    print(f'      [{time.monotonic() - T0:7.1f}s] {msg}', flush=True)


def digest(path):
    h = sha256()
    with open(path, 'rb') as f:
        while chunk := f.read(1 << 23):
            h.update(chunk)
    return h.hexdigest()


def fine_cap(c):
    """`DebitNativeClasses.capAt` (TrialDebitCapMap180.lean)."""
    return c + 4 if c < 10 else c + 5 if c < 17 else c + 6 if c < 36 else 43


# ------------------------------------------------------------------ Lean text anchors

LEAN_TEXT = {
    'TrialFrozenData180.lean': [
        'private def raw : String := include_str "frozen_band_tables.json"',
        '(archive.coeff[((p*3+l)*11+s)*30+k]?.getD 0 : ℚ)/(archive.coeffDen:ℚ)',
        '∑ l : Fin 3, if get archive.suffix c.val ≤ l.val then coefficient p.val l.val s.val k.val else 0',
        '(get a 0:ℚ)/(get a 1:ℚ)',
        '| 0,i => if knot i ≤ x ∧ x < knot (i+1) then 1 else 0',
        '| d+1,i => (x-knot i)*basis x d i/(knot (i+d+1)-knot i) +\n      (knot (i+d+2)-x)*basis x d (i+1)/(knot (i+d+2)-knot (i+1))',
        'let x := ((J:ℚ)+39/2)*(1399373467/172031279104000)\n  if knot 3 ≤ x ∧ x < knot 33 then basis x 3 k.val else 0',
        'maxIndex c := min 130964 (get archive.maxIndex c.val)',
        'if Native.adverse (d := 38) (n-1) ≤ Book.capR s then some s else none',
    ],
    'TrialFrozenProfile180.lean': [
        'def signatures : Fin 11 → List ℕ := ![[],[2],[3],[4],[2,2],[5],[2,3],[6],[2,4],[3,3],[2,2,2]]',
        'def siteFactor (u : ℝ) := (21/200)/(1+u/100)+(179/200)/(1+(907/5)*u)',
        'def shapes (u : ℝ) : Fin 3 → ℝ := ![1,(u/(131072*Native.step))^2,1/(1+300*u)]',
    ],
    'TrialFrozenChannels180.lean': [
        'def center (k : ℕ) : ℝ := ((k:ℝ)+1/2)*Native.step',
        '(39:ℝ)^((signatures σ).sum-(signatures σ).length) *\n    ∑ k : Fin 30, T.spline J k * T.row c ⟨3*z.1.val+z.2.1.val,by omega⟩ σ k',
        'siteFactor (center k) *\n    (if i = 0 then shapes (center k) z.1 else 1) *\n    (if i = Fin.last 38 then shapes (center k) z.2.1 else 1) *\n'
        '    ∏ l : Fin (signatures σ).length, if (t l).castSucc.succ = i\n      then (center k)^((signatures σ).get l) else 1',
    ],
    'TrialPackedSingleFields180.lean': [
        'if J>min 130964 (T.maxIndex c) then 0 else coefficient T J c z',
        'radialCoeff J c.val z-radialCoeff J (c.val+1) z',
        '100*coefficientChange (j+J) c z*siteChannel z i j',
        '∑ j : Tick,Native.step*((g j c:ℝ)/(base:ℝ))*pointFactor i J c z j.val',
    ],
    'TrialPackedRoleKernels180.lean': ['bank (fun c => erasedCoefficient g i J c z) k'],
    'TrialPackedLaw180.lean': ['abbrev Tick := Fin 130965', 'def base : ℤ := 2^57'],
    'TrialNativeRadius180.lean': ['def step : ℝ := 1399373467/172031279104000',
                                  'def adverse {d : ℕ} (J : ℕ) : ℝ := rho*((J:ℝ)+d)*step'],
    'TrialDebitCapMap180.lean': [
        '⟨if k.val < 10 then k.val+4 else if k.val < 17 then k.val+5 else if k.val < 36 then k.val+6 else 43'],
    'TrialHistoricalSiteArithmetic180.lean': ['def bits : Nat := 58',
                                              'def numerator57 (row : Nat) (c : Nat) : Nat := (row >>> (bits*c)) % 2^bits'],
    'TrialVerifiedCapMarks180.lean': [
        'def physicalGrid (j : Tick) (c : Cap) : ℤ := numerator57 (chooseRow gridChunks j.val) c.val'],
    'TrialSiteShardBook180.lean': ['if j < 45067 then allOnes else',
                                   'match arr[(j-45067)/128]? with',
                                   'p.rows[(j-45067)%128]?.getD 0'],
    'TrialSignedCapContractions180.lean': [
        'NativeContractions.price ((if J>T.maxIndex c then none else T.sector c (J+1)).getD 170) J'],
    'TrialNativeContractions180.lean': [
        '((AdverseScore.oldPrice s).1 + (AdverseScore.oldPrice s).2 * primePrice (Native.adverse (d := 38) j))/10^14'],
    'TrialNativeRadialScore180.lean': [
        'PhysicalDebit.rate ((if J>CoarseLaw.T.maxIndex c then none else CoarseLaw.T.sector c (J+1)).getD 170) J'],
    'TrialPhysicalDebit180.lean': [
        'def inv (a : ℝ) := 1/(ledger - min 0.2801 (max 0 a))',
        'max 0 ((((oldPrice s).1 : ℝ) + (oldPrice s).2*q)/10^14 -\n    (((archivedPrice s).1 : ℝ) + (archivedPrice s).2*q)/10^14)',
        'def rate (s : Fin 521) (j : ℕ) := diff s (inv (Native.adverse (d := 38) j))'],
    'TrialPrimeRadialPrice180.lean': ['def primePrice (q : ℝ) := 1/(0.4999-q)'],
    'TrialEndpointPhysical180.lean': ['abbrev ledger : ℝ := 4999/10000'],
    'TrialNativeRoleTotals180.lean': [
        'def q (j : ℕ) := 2*(rho/100)^2/(EndpointPhysical.ledger-Native.adverse (d:=37) j)^2',
        '(keyPrice j.val c.val*singleGram g i c j.val c.val-keyPrice j.val (c.val+1)*singleGram g i c j.val (c.val+1))'],
    'TrialApplyBook180.lean': ['let ticks := (10000*n.mantissa.toNat + den-1)/den+1',
                               'def capR (s : Label) : ℝ := (radiusTicks[s.val]!:ℝ)/10000'],
    'TrialAdverseScore180.lean': ['archiveRows% (include_str "../data/h1_multilevel_strip_free.json")'],
    'TrialArchivedGap180.lean': ['archiveRows% (include_str "../data/repriced_covers.json")'],
}


def check_lean_text():
    print('== Lean definitions this program models')
    missing = [(name, t[:60]) for name, texts in LEAN_TEXT.items()
               for t in texts if t not in (LEAN / name).read_text()]
    ok(not missing, f'{sum(map(len, LEAN_TEXT.values()))} definition texts found verbatim in '
       f'{len(LEAN_TEXT)} Lean files' + (f'; missing {missing}' if missing else ''))
    src = (LEAN / 'TrialHistoricalSiteArithmetic180.lean').read_text()
    caps = [int(x) for x in re.search(r'def capIndices : List Nat := \[([\d,\s]+)\]', src)[1].split(',')]
    ok(len(caps) == 37 and caps == sorted(caps), 'capIndices has 37 increasing caps (Hist c is the c-th)')
    return caps


# ------------------------------------------------------------------ authentication

def import_payload(payload):
    # The payload's own modules, under the names recorded in its manifest.
    sys.path.insert(0, str(payload))
    GA, QI, PP = (importlib.import_module(PREFIX + name)
                  for name in ('global_amplitude', 'quotient_inputs', 'portable_partitions'))
    for mod in (GA, QI, PP):
        assert Path(mod.__file__).resolve().parent == payload.resolve(), mod.__file__
    return GA, QI, PP


def authenticate(payload, caps):
    print('\n== authentication')
    ok(digest(FROZEN) == FROZEN_SHA, 'frozen_band_tables.json has the hash used by the Lean build')
    d256 = json.loads(RECEIPT_256.read_text())
    raw = (payload / 'manifest.json').read_bytes()
    ok(sha256(raw).hexdigest() == d256['manifest_sha256'],
       f'payload manifest sha256 {d256["manifest_sha256"][:16]}… equals the 256-bit certificates\' manifest_sha256')
    m = json.loads(raw)
    small = [n for n in m['files'] if not n.startswith('bank-')]
    ok(all(digest(payload / n) == m['files'][n] for n in small),
       f'{len(small)} payload code, spline, CDF and price files have their manifest hashes')
    recorded = ['ts_s39a6.npz', 'h1_band_retrained.json', 'h1_dickman_native_bounds.json']
    recorded += [PREFIX + n for n in ('cap_law_transfer.json', 'global_amplitude.py', 'quotient_inputs.py',
                                      'cap_worker.py', 'quotient_poly.py', 'packed_poly.cpp')]
    same = [n for n in recorded if (payload / n).read_bytes() == recorded_bytes(n)]
    ok(len(same) == 9, 'the payload copies of the spline, CDF certificates and worker code equal the files '
       'in ../data byte for byte')
    ok(m['caps'] == sorted(caps, reverse=True) and m['n'] == COUNT and m['core'] == 37,
       'manifest caps are capIndices in decreasing order, n = 131033, 37 core sites')
    srcs = m['source_sha256']
    ok(all(recorded_digest(k) == v for k, v in srcs.items()) and len(srcs) == 10,
       'all 10 source hashes recorded in the manifest (bank producer and spline) match the files in ../data')
    return m


# ------------------------------------------------------------------ item 1: spline

def npz_vector(path):
    """Read vector.npy exactly as global_amplitude.source() does (lines 37-43)."""
    with ZipFile(path) as z:
        data = z.read('vector.npy')
    assert data[:8] == b'\x93NUMPY\x01\x00'
    start = 10 + int.from_bytes(data[8:10], 'little')
    header = ast.literal_eval(data[10:start].decode('ascii'))
    assert header == {'descr': '<f8', 'fortran_order': False, 'shape': (8910,)}
    return [F(v) for v in struct.unpack('<8910d', data[start:])]


def lean_knots(d):
    return [F(a, b) for a, b in d['knots']]


def lean_basis(knots, x, deg, i):
    """`FrozenData.basis`; Lean's rational a/0 is 0."""
    def knot(j):
        return knots[j] if j < len(knots) else F(0)
    if deg == 0:
        return F(1) if knot(i) <= x < knot(i + 1) else F(0)
    d = deg - 1
    left_den = knot(i + d + 1) - knot(i)
    right_den = knot(i + d + 2) - knot(i + 1)
    left = (x - knot(i)) * lean_basis(knots, x, d, i) / left_den if left_den else F(0)
    right = (knot(i + d + 2) - x) * lean_basis(knots, x, d, i + 1) / right_den if right_den else F(0)
    return left + right


def lean_spline(knots, J, k):
    """`FrozenData.splineQ J k`."""
    x = (J + F(39, 2)) * STEP
    return lean_basis(knots, x, 3, k) if knots[3] <= x < knots[33] else F(0)


def span_range(knots, s, lo=0, hi=TICKS):
    """Native indices J with knots[s] <= (J+39/2)*STEP < knots[s+1], within [lo,hi)."""
    a = max(lo, ceil(knots[s] / STEP - F(39, 2)))
    b = min(hi, ceil(knots[s + 1] / STEP - F(39, 2)))
    return a, b


def check_spline(payload, d, GA, QI):
    print('\n== item 1: spline data used by the workers against frozen_band_tables.json')
    den = d['coeffDen']
    lean_coef = [F(v, den) for v in d['coeff']]
    vec = npz_vector(payload / 'ts_s39a6.npz')
    ok(len(vec) == len(lean_coef) == 8910 and vec == lean_coef,
       'all 8910 archived binary64 coefficients equal coeff[i]/coeffDen exactly, same flat index ((p*3+l)*11+s)*30+k')
    ok(den == lcm(*(v.denominator for v in vec)),
       f'coeffDen = 2^{den.bit_length() - 1} is the least common denominator of the archived values')
    shape = json.loads((payload / 'h1_band_retrained.json').read_text())['shape_spec']['knots']
    knots = lean_knots(d)
    ok([F(x) for x in shape] == knots and len(knots) == 34, 'the 34 knots of h1_band_retrained.json equal the archived [num,den] knots')
    wk, row = GA.source()        # the worker's own reader, with its hash checks
    ok(list(wk) == knots, 'global_amplitude.source() returns exactly these knots')
    ok(GA.S == S and GA.N == N and QI.STEP == STEP and QI.COUNT == COUNT and GA.SIGS == SIGS,
       'worker S, N, STEP = S/N = 1399373467/172031279104000, COUNT and signature order equal the Lean constants')

    def coefficient(p, l, s, k):        # FrozenData.coefficient
        return lean_coef[((p * 3 + l) * 11 + s) * 30 + k]
    good = all(row(suf, p, s) == [sum((coefficient(p, l, s, k) for l in range(3) if suf <= l), F(0)) for k in range(30)]
               for suf in range(3) for p in range(9) for s in range(11))
    ok(good, 'source() row(suffix,pair,sig) equals Lean rowQ for every suffix 0..2, 9 pairs, 11 signatures, 30 coefficients')
    good = True
    for p in range(9):
        for s in range(11):
            for c in range(3):
                w = row(c, p, s)
                if c < 2:
                    w = [a - b for a, b in zip(w, row(c + 1, p, s))]
                good &= w == [coefficient(p, c, s, k) for k in range(30)]
    ok(good, 'the per-component coefficients of _radial_controls (row(c)-row(c+1), quotient_inputs.py:83-86) '
       'equal the Lean component coefficients')
    ok(knots[0] == knots[3] and knots[30] == knots[33] == S and all(a <= b for a, b in zip(knots, knots[1:])),
       'knots 0..3 coincide, knots 30..33 equal S, nondecreasing')
    x_last = (COUNT - 1 + F(39, 2)) * STEP
    first = ceil(knots[3] / STEP - F(39, 2))
    ok(x_last < knots[33] and first > 0,
       f'every worker index has x < knot 33; Lean and worker both vanish exactly for J < {first} (x < knot 3)')
    # Basis: Lean Cox-de Boor against the worker's Bernstein controls on every nonempty span.
    checked = spans = 0
    good = True
    from math import comb
    for s in range(3, 30):
        if knots[s] == knots[s + 1]:
            continue
        a, b = span_range(knots, s, 0, COUNT)
        if a >= b:
            continue
        left, right = knots[s], knots[s + 1]
        ctrl = GA.controls(knots, s, left, right)
        spans += 1
        pts = sorted({min(b - 1, max(a, J)) for J in (a, a + 1, (a + b) // 3, (2 * a + b) // 3 + 7, (a + 2 * b) // 3, b - 2, b - 1)})
        good &= len(pts) >= 4
        for J in pts:
            x = (J + F(39, 2)) * STEP
            t = (x - left) / (right - left)
            bern = [comb(3, m) * t**m * (1 - t)**(3 - m) for m in range(4)]
            for k in range(30):
                lean = lean_spline(knots, J, k)
                worker = sum(c * w for c, w in zip(ctrl[k - (s - 3)], bern)) if s - 3 <= k <= s else F(0)
                good &= lean == worker
                checked += 1
    ok(good, f'on all {spans} nonempty spans the worker Bernstein form (global_amplitude.controls, quotient_inputs._bernstein) '
       f'equals Lean splineQ at {checked} (J,k) points, at least 4 distinct points per span, so the cubic pieces are identical')
    return knots, lean_coef


# ------------------------------------------------------------------ item 1: index ranges, suffix and geometry

def lean_ranges(d):
    """Delta_c^l: the J range on which coefficientChange (Hist c) carries component l (1 or 0 times)."""
    M = [min(130964, d['maxIndex'][fine_cap(c)]) for c in range(37)]
    suf = [d['suffix'][fine_cap(c)] for c in range(37)]

    def R(c, l):
        return (0, M[c] + 1) if c < 37 and l >= suf[c] else (0, 0)
    out = {}
    nested = True
    for c in range(37):
        for l in range(3):
            (_, hc), (_, hn) = R(c, l), R(c + 1, l)
            nested &= hn <= hc
            if hc > hn:
                out[c, l] = (hn, hc)
    return M, suf, out, nested


def check_ranges(d, m, caps):
    print('\n== item 1: maxIndex, suffix and geometry')
    M, suf, delta, nested = lean_ranges(d)
    ok(nested, 'for every component the Lean radial support at Hist c+1 is contained in that at Hist c, '
       'so coefficientChange is the component spline on one interval and zero elsewhere')
    ok(all(m['rows'][str(caps[c])]['last'] == M[c] for c in range(37)),
       'manifest active last index of every cap = min 130964 (T.maxIndex (capAt c))')
    geo = {int(g): rows for g, rows in m['geometry'].items()}
    good = True
    for c in range(37):
        for l in range(3):
            ranges = sorted((a, b) for comp, a, b in geo.get(caps[c], []) if comp == l)
            merged = []
            for a, b in ranges:
                if merged and merged[-1][1] == a:
                    merged[-1] = (merged[-1][0], b)
                else:
                    merged.append((a, b))
            want = [delta[c, l]] if (c, l) in delta else []
            good &= merged == want
    ok(good, 'the worker geometry (component, start, stop) of each of the 9 changing caps is exactly the Lean '
       'coefficientChange support; the 28 other caps have none')
    order = m['caps']
    good = True
    for i, cap in enumerate(order):
        row = m['rows'][str(cap)]
        good &= row['bank'] == min(g for g in geo if g >= cap)
        good &= row['prior_bank'] == (min(g for g in geo if g >= order[i - 1]) if i else None)
    ok(good, 'each cap uses the bank of the least geometry cap >= it, as the Lean bank sum over c >= k does '
       '(inactive classes contribute erasedCoefficient = 0, InactiveCaps.lean:30)')
    return M, delta


# ------------------------------------------------------------------ item 3: grid

def check_grid(QI, caps, shards):
    print('\n== item 3: the 57-bit historical grid')
    sys.path.insert(1, str(LEAN))
    import build_historical_site_rows as B
    cols = B.columns()
    transfer = json.loads((NATIVE / 'cap_law_transfer.json').read_text())
    ok([r['cap'] for r in transfer['bins']] == caps, 'transfer certificate bins are in capIndices order, so column c is Hist c')
    good = True
    for c, cap in enumerate(caps):
        cdf, cdf2 = QI.cap_cdf(cap)       # asserts the same per-cap binary64 SHA-256
        scaled = cdf[:TICKS] * 2.0**57    # exact: power-of-two scaling of dyadics below 2^57
        good &= cdf is cdf2 and bool(np.all(scaled == np.floor(scaled)))
        good &= bool(np.array_equal(scaled.astype(np.int64), np.frombuffer(cols[c], dtype=np.uint64).astype(np.int64)))
    ok(good, 'for all 37 caps the worker CDF (quotient_inputs.cap_cdf) at every Tick j < 130965 equals '
       'physicalGrid j c / 2^57 exactly (build_historical_site_rows.columns, check_refined_site_bins.frozen_native)')
    if shards:
        rows_ok, count = True, 0
        for path in sorted(Path(shards).glob('TrialSiteShard[0-9][0-9][0-9]180.lean')):
            text = path.read_text()
            start, size = map(int, re.search(r'checkedChunk (\d+) (\d+)', text).groups())
            hexes = re.search(r':= #\[\n(.*?)\n\]', text, re.S)[1].replace(',', '').split()
            idx = int(path.name[14:17])
            rows_ok &= start == 45067 + 128 * idx and len(hexes) == size
            for i, h in enumerate(hexes):
                rows_ok &= int(h, 16) == B.packed_row(cols, start + i)
                count += 1
        ok(rows_ok and count == TICKS - 45067,
           f'{count} packed rows in the generated Lean shards {shards} equal the columns (shard k starts at 45067+128k)')
    return cols


# ------------------------------------------------------------------ item 3: prices

def lean_label_table(d):
    book = json.loads((NATIVE / 'h1_priced_168_table.json').read_text(), parse_float=Decimal)
    radii = [int(-((-10000 * Decimal(x)) // 1)) + 1 for x in book['physical_upper']]   # decodeRadii

    def labels(c, last):
        """`(if J>T.maxIndex c then none else T.sector c (J+1)).getD 170` for J <= last."""
        runs = d['sectorRuns'][fine_cap(c)]
        out, run = [], 0
        for j in range(last + 1):
            n = j + 1
            while run < len(runs) and runs[run][0] <= n:
                run += 1
            code = runs[run][1] if run < len(runs) else 0
            label = 170
            if 0 < code <= 521:
                s = code - 1
                if 2624989 * (j + 38) * 1399373467 * 10000 <= radii[s] * 10**7 * 172031279104000:
                    label = s
            out.append(label)
        return out
    return labels


def int_rows(path):
    data = json.loads(Path(path).read_text())
    assert int(data['scale']) == 10**14 and len(data['sector_prices']) == 521
    assert all(isinstance(a, int) and isinstance(b, int) and b <= 0 and c == 0 for a, b, c in data['sector_prices'])
    return [(a, b) for a, b, _ in data['sector_prices']]


WORST = {}


def contains(num, den, x, r, tag=None):
    """Exact test |num/den - x| <= r for binary64 x, r and den > 0.

    With a tag, also record the largest |num/den - x| / r seen (exact ratio rounded to binary64).
    """
    xn, xd = float(x).as_integer_ratio()
    rn, rd = float(r).as_integer_ratio()
    lhs = abs(num * xd - xn * den) * rd
    rhs = rn * xd * den
    if tag is not None and rhs:
        WORST[tag] = max(WORST.get(tag, 0.), lhs / rhs)
    return lhs <= rhs


def check_prices(d, m, payload, caps, M):
    print('\n== item 3: price, debit and pair weights against the Lean definitions, exactly, at every index')
    old = int_rows(NATIVE / 'h1_multilevel_strip_free.json')
    new = int_rows(NATIVE / 'repriced_covers.json')
    labels = lean_label_table(d)
    R = RHO * STEP
    Rn, Rd = R.numerator, R.denominator
    Dd = 10000 * Rd                            # LEDGER - R*(j+d) = (4999*Rd - 10000*Rn*(j+d)) / Dd

    def dj(j, off):
        return 4999 * Rd - 10000 * Rn * (j + off)
    top = R * (TICKS - 1 + 38)
    ok(top <= F(2801, 10000) and dj(COUNT - 1, 38) > 0,
       'adverse(d=38) <= 0.2801 on every Tick, so PhysicalDebit.inv is the unclamped 1/(0.4999-adverse)')
    K = 2624989                                # rho/100 * x/1e14 = 2624989*x/1e23
    big = 10**23
    stats = {'price': 0, 'jump': 0, 'debit': 0, 'debit_jump': 0}
    bad = []
    prev = None
    for c in range(36, -1, -1):                # certificate order: decreasing caps
        cap = caps[c]
        last = m['rows'][str(cap)]['last']
        lab = labels(c, last)
        with np.load(payload / m['rows'][str(cap)]['price_file'], allow_pickle=False) as z:
            w = {k: (z[k + '0'], z[k + '1']) for k in stats}
        zero_above = all(not np.any(a[last + 1:]) for pair in w.values() for a in pair)
        if not zero_above:
            bad.append((c, 'nonzero above maxIndex'))
        keyv, debv = [], []
        for j in range(last + 1):
            A, B = old[lab[j]]
            a2, b2 = new[lab[j]]
            dd = dj(j, 38)
            kv = A * dd + B * Dd                   # numerator of keyPrice*1e14*dd
            dv = max(0, (A - a2) * dd + (B - b2) * Dd)
            keyv.append(kv)
            debv.append(dv)
            den = big * dd
            if not contains(K * kv, den, w['price'][0][j], w['price'][1][j], 'price'):
                bad.append((c, 'price', j))
            if not contains(K * dv, den, w['debit'][0][j], w['debit'][1][j], 'debit'):
                bad.append((c, 'debit', j))
            stats['price'] += 1
            stats['debit'] += 1
        # Jumps: keyPrice J c - keyPrice J (c+1). Above the next cap's maxIndex the
        # preceding field vanishes (its bank sum covers only caps with smaller maxIndex),
        # so the jump multiplies H^2 = 0 there and is immaterial in both computations.
        if prev is None:
            pkey = pdeb = [0] * (last + 1)
            top_j = last
        else:
            plast, pkey, pdeb = prev
            top_j = min(last, plast)
        for j in range(top_j + 1):
            den = big * dj(j, 38)
            if not contains(K * (keyv[j] - pkey[j]), den, w['jump'][0][j], w['jump'][1][j], 'jump'):
                bad.append((c, 'jump', j))
            if not contains(K * (debv[j] - pdeb[j]), den, w['debit_jump'][0][j], w['debit_jump'][1][j], 'debit_jump'):
                bad.append((c, 'debit_jump', j))
            stats['jump'] += 1
            stats['debit_jump'] += 1
        prev = (last, keyv, debv)
    ok(not bad, 'all 37 caps: the exact Lean values (rho/100)*keyPrice, (rho/100)*debitPrice and their cap jumps lie '
       'inside the worker balls at ' + ', '.join(f'{v} {k}' for k, v in stats.items()) +
       ' indices (labels with the radius test and sentinel 170); all weights vanish above maxIndex; '
       'largest |Lean - center|/radius: ' + ', '.join(f'{k} {WORST.get(k, 0.):.3f}' for k in stats)
       + (f'; failures {bad[:10]}' if bad else ''))
    with np.load(payload / 'pair.npz', allow_pickle=False) as z:
        x, r = z['v0'], z['v1']
    good = all(contains(2 * K * K * Dd * Dd, 10**18 * dj(j, 37)**2, x[j], r[j], 'pair') for j in range(COUNT))
    ok(good, f'the exact NativeRoleTotals.q(J) = 2(rho/100)^2/(0.4999-adverse(d=37) J)^2 lies inside the pair ball '
       f'at all {COUNT} indices (largest |Lean - center|/radius {WORST.get("pair", 0.):.3f})')


# ------------------------------------------------------------------ item 2: banks

class Spline:
    """Exact cubic pieces of Lean splineQ in the native index J, per nonempty span."""

    def __init__(self, knots):
        self.pieces = []
        for s in range(3, 30):
            if knots[s] == knots[s + 1]:
                continue
            a, b = span_range(knots, s)
            if a >= b:
                continue
            nodes = [a, a + (b - a) // 3, a + 2 * (b - a) // 3, b - 1]
            assert len(set(nodes)) == 4
            polys = {}
            for k in range(s - 3, s + 1):
                vals = [lean_spline(knots, J, k) for J in nodes]
                polys[k] = lagrange(nodes, vals)
                for J in (a + 1, (a + b) // 2 + 1, b - 2):     # extra exact checks of the piece
                    assert peval(polys[k], J) == lean_spline(knots, J, k)
            den = lcm(*(c.denominator for p in polys.values() for c in p))
            ints = {k: [int(c * den) for c in p] for k, p in polys.items()}
            for k in (s - 5, s + 2):                           # outside the span's four functions
                if 0 <= k < 30:
                    assert lean_spline(knots, (a + b) // 2, k) == 0
            self.pieces.append((s, a, b, den, ints))


def lagrange(xs, ys):
    """Coefficients c0..c3 of the cubic through (xs, ys)."""
    coeffs = [F(0)] * 4
    for i, (xi, yi) in enumerate(zip(xs, ys)):
        if not yi:
            continue
        basis = [F(1)]
        denom = F(1)
        for j, xj in enumerate(xs):
            if j == i:
                continue
            basis = [F(0)] + basis
            for t in range(len(basis) - 1):
                basis[t] -= xj * basis[t + 1]
            denom *= xi - xj
        for t in range(4):
            coeffs[t] += yi * basis[t] / denom
    return coeffs


def peval(c, x):
    return ((c[3] * x + c[2]) * x + c[1]) * x + c[0]


def kernels(column, hi):
    """floor(2^P * K(j)) for the eight insertion kernels of Lean pointFactor at j < hi.

    K_e(j)     = 100*step*(g j c/2^57)*siteFactor(u)*u^e,  u = center j = (j+1/2)*step
    K_shape1   = 100*step*(g/2^57)*siteFactor(u)*(u/(131072*step))^2
    K_shape2   = 100*step*(g/2^57)*siteFactor(u)/(1+300u)
    siteFactor(u) = NS/DS with w = 2j+1, step = A/B.
    """
    A, B = STEP.numerator, STEP.denominator
    Ae = {e: A**e for e in range(7)}
    Be = {e: B**e for e in range(7)}
    names = [('p', e) for e in (0, 2, 3, 4, 5, 6)] + [('s', 1), ('s', 2)]
    out = {k: [0] * hi for k in names}
    shift = P_BITS - 57
    for j in range(hi):
        w = 2 * j + 1
        g = column[j]
        ns = 21 * B * 20 * (10 * B + 907 * w * A) + 179 * B * (200 * B + w * A)
        ds = 20 * (200 * B + w * A) * (10 * B + 907 * w * A)
        base_num = 100 * A * g * ns
        base_den = B * ds
        for e in (0, 2, 3, 4, 5, 6):
            out['p', e][j] = ((base_num * w**e * Ae[e]) << (shift - e)) // (base_den * Be[e])
        out['s', 1][j] = ((base_num * w * w) << shift) // (base_den * 4 * N * N)
        out['s', 2][j] = ((base_num * 2 * B) << shift) // (base_den * (2 * B + 300 * w * A))
    return out


def check_banks(payload, m, d, caps, cols, lean_coef, knots, delta, PP, which):
    import flint
    print('\n== item 2: erased-field banks against the exact Lean fields (roles a = site 0, core = site 1, b = site 38)')
    geo_caps = sorted((int(g) for g in m['geometry']), reverse=True)        # 78116 first
    unchanged = []
    if which != 'all':
        wanted = {int(x) for x in which.split(',')}
        for cap in list(wanted):
            if cap not in geo_caps:
                bank = m['rows'][str(cap)]['bank']
                unchanged.append((cap, bank))
                wanted.add(bank)
        # The triangle-inequality step needs each geometry bank's predecessors.
        last = max(geo_caps.index(g) for g in wanted if g in geo_caps)
        todo = geo_caps[:last + 1]
    else:
        todo = geo_caps
        unchanged = [(c, m['rows'][str(c)]['bank']) for c in m['caps'] if c not in geo_caps]
    spl = Spline(knots)
    den = d['coeffDen']
    sh = 3
    coef = np.array(d['coeff'], dtype=object).reshape(9, 3, 11, 30)
    scale = [39**(sum(s) - len(s)) for s in SIGS]
    DEN = 1 << (P_BITS + Q_BITS)
    splits = {z: PP.fiber_splits(s) for z, s in enumerate(SIGS)}
    rest_index = {s: z for z, s in enumerate(SIGS)}
    hist = {cap: c for c, cap in enumerate(caps)}
    prev_bank = None
    summary = []
    for g in todo:
        tic = time.monotonic()
        c = hist[g]
        comps = {l: rng for (cc, l), rng in delta.items() if cc == c}
        lo = min(a for a, _ in comps.values())
        hi = max(b for _, b in comps.values())
        # Exact increment rows: 39^sc * sum_k splineQ(J,k) * sum_{active l} coeff/coeffDen, floored at 2^-Q.
        rows = {}
        rabs = {}
        for z in range(11):
            for p in range(9):
                vals = np.zeros(hi - lo, dtype=object)
                for s, a, b, sden, ints in spl.pieces:
                    for (l, (la, lb)) in comps.items():
                        ja, jb = max(a, la), min(b, lb)
                        if ja >= jb:
                            continue
                        cv = {k: int(coef[p, l, z, k]) for k in ints}
                        if not any(cv.values()):
                            continue
                        n = [scale[z] * sum(cv[k] * ints[k][t] for k in ints) for t in range(4)]
                        J = np.arange(ja, jb).astype(object)
                        num = ((n[3] * J + n[2]) * J + n[1]) * J + n[0]
                        vals[ja - lo:jb - lo] += (num * (1 << Q_BITS)) // (den * sden)
                if any(v != 0 for v in vals):
                    rows[z, p] = flint.fmpz_poly([int(v) for v in vals[::-1]])
                    rabs[z, p] = int(sum(abs(v) for v in vals))
        # Overlapping pieces from two components on the same index would floor twice;
        # every row has at most one floor per (component, index), so theta < number of components.
        ncomp = len(comps)
        kern = kernels(cols[c], hi)
        kpoly = {k: flint.fmpz_poly(v) for k, v in kern.items()}
        ksum = {k: sum(v) for k, v in kern.items()}
        count = hi - lo
        note(f'bank {g}: Hist {c}, components {sorted(comps)}, J < {hi}, {len(rows)} nonzero rows, kernels ready')

        def corr(rpoly, key):
            return kpoly[key].mul_low(rpoly, hi)

        # Accumulate the Lean fields in the worker's row layout, with integer error bounds.
        acc = {}

        def add(role, ix, poly, rabs_v, mult, key):
            if role not in acc:
                acc[role] = {}
            cur = acc[role].get(ix)
            err_lo = rabs_v
            err_hi = rabs_v + mult * ncomp * (ksum[key] + count)
            if cur is None:
                acc[role][ix] = [poly, err_lo, err_hi]
            else:
                cur[0] += poly
                cur[1] += err_lo
                cur[2] += err_hi
        for a in range(sh):
            for b in range(sh):
                p = a * sh + b
                # core: row (rest,a,b) += m * corr(row(s,a,b), power e)
                combos = {}
                for z in range(11):
                    if (z, p) not in rows:
                        continue
                    for rest, e, mult in splits[z]:
                        key = (rest_index[rest], e)
                        poly, ra, mt = combos.get(key, (None, 0, 0))
                        term = rows[z, p] * mult
                        combos[key] = (term if poly is None else poly + term, ra + mult * rabs[z, p], mt + mult)
                for (r, e), (poly, ra, mt) in combos.items():
                    add('core', r * sh * sh + p, corr(poly, ('p', e)), ra, mt, ('p', e))
                # a (site 0): row (s,b) += corr(row(s,a,b), shape a); b (site 38): row (s,a) += corr(.., shape b)
                for z in range(11):
                    if (z, p) not in rows:
                        continue
                    ka = ('p', 0) if a == 0 else ('s', a)
                    kb = ('p', 0) if b == 0 else ('s', b)
                    add('a', z * sh + b, corr(rows[z, p], ka), rabs[z, p], 1, ka)
                    add('b', z * sh + a, corr(rows[z, p], kb), rabs[z, p], 1, kb)
        del rows, kern, kpoly, combos
        note(f'bank {g}: exact convolutions done')
        with np.load(payload / m['banks'][str(g)], allow_pickle=False) as zb:
            cur = {role: (zb[role + '0'], zb[role + '1']) for role in ('core', 'a', 'b')}
        stats = compare_bank(acc, cur, prev_bank, hi, DEN)
        prev_bank = cur
        ok(stats['fail'] == 0,
           f'bank {g} (Hist {c}): {stats["entries"]} entries (165 rows x {COUNT} indices); the exact Lean increment '
           f'lies in [c-c_prev -/+ (r-r_prev)] everywhere, so by induction the cumulative Lean field lies in the ball; '
           f'{stats["exact"]} entries needed the exact-rational comparison; least slack (r-r_prev-|D-(c-c_prev)|)/(r-r_prev) '
           f'= {stats["slack"]:.3g}; enclosure width <= {stats["width"]:.1e}, least radius increment where the '
           f'Lean increment is nonzero {stats["radius"]:.1e}; {time.monotonic() - tic:.0f} s' + (f'; failures {stats["examples"]}' if stats['fail'] else ''))
        summary.append((g, stats))
        del acc
    for cap, bank in unchanged:
        c = hist[cap]
        ok(all((c, l) not in delta for l in range(3)) and bank in [g for g, _ in summary],
           f'unchanged cap {cap} (Hist {c}): coefficientChange vanishes identically, so its Lean field equals that of '
           f'bank {bank}, which was checked above')
    return summary


def compare_bank(acc, cur, prev, hi, DEN):
    """Check |D - (c - c0)| <= r - r0 for every row and index; D is the exact Lean increment."""
    stats = {'entries': 0, 'fail': 0, 'exact': 0, 'slack': float('inf'), 'examples': [], 'width': 0.,
             'radius': float('inf')}
    for role, (cg, rg) in cur.items():
        nrow = cg.shape[0]
        for ix in range(nrow):
            c1, r1 = cg[ix].astype(np.float64), rg[ix].astype(np.float64)
            if prev is None:
                c0, r0 = np.zeros_like(c1), np.zeros_like(r1)
            else:
                c0, r0 = prev[role][0][ix], prev[role][1][ix]
            lo = np.zeros(COUNT)
            hi_v = np.zeros(COUNT)
            entry = acc.get(role, {}).get(ix)
            if entry is not None:
                poly, elo, ehi = entry
                stats['width'] = max(stats['width'], (elo + ehi) / DEN)
                co = [int(v) for v in poly.coeffs()]
                co += [0] * (hi - len(co))
                S = co[hi - 1::-1]                 # coefficient m belongs to J = hi-1-m
                lo[:hi] = [(v - elo) / DEN for v in S]
                hi_v[:hi] = [(v + ehi) / DEN for v in S]
                lo = np.nextafter(lo, -np.inf)
                hi_v = np.nextafter(hi_v, np.inf)
                lo[hi:] = 0.
                hi_v[hi:] = 0.
            else:
                S = None
            up, down = (lambda x: np.nextafter(x, np.inf)), (lambda x: np.nextafter(x, -np.inf))
            dc = c1 - c0
            dr_lo = down(r1 - r0)
            left = up(up(dc) - dr_lo)              # >= (c-c0) - (r-r0)
            right = down(down(dc) + dr_lo)         # <= (c-c0) + (r-r0)
            good = (left <= lo) & (hi_v <= right) & (dr_lo >= 0)
            live = (lo != 0) | (hi_v != 0)
            if live.any():
                stats['radius'] = min(stats['radius'], float(np.min(dr_lo[live])))
            stats['entries'] += COUNT
            mid = 0.5 * (lo + hi_v)
            with np.errstate(divide='ignore', invalid='ignore'):
                slack = (dr_lo - np.abs(mid - dc)) / dr_lo
            stats['slack'] = min(stats['slack'], float(np.nanmin(np.where(dr_lo > 0, slack, np.inf))))
            for J in np.flatnonzero(~good):
                stats['exact'] += 1
                C = F(float(c1[J])) - F(float(c0[J]))
                R = F(float(r1[J])) - F(float(r0[J]))
                if S is not None and J < hi:
                    v = S[J]
                    dlo, dhi = F(v - entry[1], DEN), F(v + entry[2], DEN)
                else:
                    dlo = dhi = F(0)
                if not (R >= 0 and C - R <= dlo and dhi <= C + R):
                    stats['fail'] += 1
                    if len(stats['examples']) < 5:
                        stats['examples'].append((role, ix, int(J), float(dlo), float(C), float(R)))
    return stats


# ------------------------------------------------------------------ main

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--payload', type=Path, default=os.environ.get('PAYLOAD'),
                    help='directory of the per-cap computation payload (default: the environment variable PAYLOAD)')
    ap.add_argument('--banks', default='all', help="'all', 'none', or comma-separated caps")
    ap.add_argument('--hash-banks', action='store_true', help='also hash the 3 GB of banks against the manifest')
    ap.add_argument('--shards', type=Path, help='directory of generated TrialSiteShardNNN180.lean files')
    args = ap.parse_args()
    if args.payload is None or not (args.payload / 'manifest.json').exists():
        sys.exit('The payload directory is required: set PAYLOAD or pass --payload DIR (it must contain manifest.json).')
    caps = check_lean_text()
    m = authenticate(args.payload, caps)
    GA, QI, PP = import_payload(args.payload)
    d = json.loads(FROZEN.read_text())
    knots, lean_coef = check_spline(args.payload, d, GA, QI)
    M, delta = check_ranges(d, m, caps)
    cols = check_grid(QI, caps, args.shards)
    check_prices(d, m, args.payload, caps, M)
    if args.banks != 'none':
        if args.hash_banks:
            ok(all(digest(args.payload / n) == m['files'][n] for n in m['banks'].values()),
               '9 bank files have their manifest hashes')
        check_banks(args.payload, m, d, caps, cols, lean_coef, knots, delta, PP, args.banks)
    note('done')
    if FAILURES:
        print(f'\n{len(FAILURES)} check(s) FAILED')
        sys.exit(1)
    print('\nAll checks passed.')


if __name__ == '__main__':
    main()
