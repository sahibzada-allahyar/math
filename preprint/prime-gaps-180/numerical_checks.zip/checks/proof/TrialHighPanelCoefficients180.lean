import TrialHighSplineControls180

/-! Evaluate the signed Bernstein controls directly at rational points.
The kernel can check the archived controls without constructing a
polynomial at every occurrence of every channel. -/
noncomputable section
open scoped BigOperators Polynomial
namespace PrimeGap180.HighPanelCoefficients
open Polynomial MassSplineSpan MassCubicFields HighSplineControls FrozenProfile FrozenData

def atPoint (s : ℕ) (x : ℚ) : ℕ → ℕ → ℚ
  | 0,i => if i=s then 1 else 0
  | d+1,i =>
    (x-knot i)*atPoint s x d i/(knot (i+d+1)-knot i) +
      (knot (i+d+2)-x)*atPoint s x d (i+1)/(knot (i+d+2)-knot (i+1))

private theorem eval_eq (s : ℕ) (x : ℚ) (d i : ℕ) :
    (piece s d i).eval x = atPoint s x d i := by
  induction d generalizing i with
  | zero => simp only [piece,atPoint]; split <;> simp
  | succ d ih => simp only [piece,atPoint,eval_add,eval_mul,eval_sub,eval_X,eval_C,ih,div_eq_mul_inv]

private theorem outside (s : ℕ) (x : ℚ) (d i : ℕ) (h : ¬ (i ≤ s ∧ s ≤ i+d)) :
    atPoint s x d i = 0 := by
  induction d generalizing i with
  | zero =>
    have neq : i ≠ s := by omega
    simp [atPoint,neq]
  | succ d ih =>
    rw [atPoint,ih i (by omega),ih (i+1) (by omega)]
    simp

def point (s : ℕ) (c : Fine) (u : FullNativeTicks.Key) (x : ℚ) : ℚ :=
  39^((signatures u.2.2).sum-(signatures u.2.2).length) *
    ∑ k : Fin 30, if k.val ≤ s ∧ s ≤ k.val+3 then
      rowQ c ⟨3*u.1.val+u.2.1.val,by omega⟩ u.2.2 k*atPoint s x 3 k.val else 0

private theorem tickPoint (x : ℚ) : (ticks 0).eval (index x) = x := by
  unfold ticks sample index
  simp only [eval_add,eval_mul,eval_C,eval_X,Nat.cast_zero,zero_add]
  ring

private theorem evaluate (s : ℕ) (c : Fine) (u : FullNativeTicks.Key) (x : ℚ) :
    (cubic s 0 c u).eval (index x) = 2^64*point s c u x := by
  unfold cubic point
  simp only [eval_C_mul,eval_finsetSum,←mul_assoc]
  apply congrArg (fun t => (2^64*39^((signatures u.2.2).sum-(signatures u.2.2).length):ℚ)*t)
  apply Finset.sum_congr rfl
  intro k _
  rw [eval_comp,tickPoint,eval_eq]
  split
  · rfl
  · rw [outside s x 3 k.val (by assumption),mul_zero]

def control (s : ℕ) (c : Fine) (u : FullNativeTicks.Key) (a b : ℚ) (i : Fin 4) : ℚ :=
  four (point s c u a) (point s c u (a+(b-a)/3)) (point s c u (a+2*(b-a)/3)) (point s c u b) i

theorem original (s : ℕ) (c : Fine) (u : FullNativeTicks.Key) (a b : ℚ) (i : Fin 4) :
    control s c u a b i = row s c u a b i := by
  have e1 : index a+(index b-index a)/3 = index (a+(b-a)/3) := by unfold index; ring
  have e2 : index a+2*(index b-index a)/3 = index (a+2*(b-a)/3) := by unfold index; ring
  unfold control row fromPolynomial
  rw [e1,e2]
  simp only [evaluate]
  fin_cases i <;> simp [four] <;> ring

#print axioms original
end PrimeGap180.HighPanelCoefficients
