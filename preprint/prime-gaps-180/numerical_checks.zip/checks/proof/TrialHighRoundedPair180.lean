import TrialHighDyadicGram180

/-! Turn the certified marked-site words into two short integer tables
and scale each one back to the original Gram with a single factor. -/
noncomputable section
namespace PrimeGap180.HighRoundedPair
open HighPairGram HighIntegerGram HighAngularIndex HighDyadicGram
open HighPackedGram (Tag mark)
open MassAngularPlan (Plan)

def factor (K : Tag→ℕ→ℕ) (shift : ℕ) := (K 0 0)^29*2^shift

theorem lower (r : HighTailTiles.Rate) (a b : Fin 9) (K E : Tag→ℕ→ℕ)
    (P : Fin 53→Plan) (V : Interior→Fin 53→ℕ) (shift : ℕ) (L : Fin 21→Fin 53→ℕ)
    (checkK : ∀ m n, K m n=powWord false r (mark a b m) n)
    (checkE : ∀ m n, n<9 → E m n=endWord false r (mark a b m) n)
    (checkP : ∀ s, P s=HighCorePlan.fixed sigTable[s.val]!)
    (checkV : ∀ t s, interiorValue K (P s) t=V t s)
    (checkL : ∀ e s, L e s=down shift (reduced E V e s))
    (e : Fin 21) (s : Fin 53) :
    factor K shift*L e s ≤ gramWord false r a b (atSlot (e,s)) := by
  rw [checkL,HighPairGram.exact false r a b K E P V checkK checkE checkP checkV]
  exact HighDyadicGram.lower _ _ le_rfl _ _

theorem upper (r : HighTailTiles.Rate) (a b : Fin 9) (K E : Tag→ℕ→ℕ)
    (P : Fin 53→Plan) (V : Interior→Fin 53→ℕ) (shift : ℕ) (U : Fin 21→Fin 53→ℕ)
    (checkK : ∀ m n, K m n=powWord true r (mark a b m) n)
    (checkE : ∀ m n, n<9 → E m n=endWord true r (mark a b m) n)
    (checkP : ∀ s, P s=HighCorePlan.fixed sigTable[s.val]!)
    (checkV : ∀ t s, interiorValue K (P s) t=V t s)
    (checkU : ∀ e s, U e s=up shift (reduced E V e s))
    (e : Fin 21) (s : Fin 53) :
    gramWord true r a b (atSlot (e,s)) ≤ factor K shift*U e s := by
  rw [checkU,HighPairGram.exact true r a b K E P V checkK checkE checkP checkV]
  exact HighDyadicGram.upper _ _ le_rfl _ _

#print axioms lower
#print axioms upper
end PrimeGap180.HighRoundedPair
