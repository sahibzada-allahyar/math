"""Check the frozen restoration targets against directed rational worker certificates."""
from fractions import Fraction
from hashlib import sha256
from math import isqrt
from pathlib import Path
import json
import re


ROOT = Path(__file__).resolve().parent
LEAN = ROOT.parents[1] / "lean" / "proof"
RECEIPT = ROOT.parent / "data" / "middle_restoration_progress.json"
RECEIPT_HASH = "887fc01b08d8aa87041427ba372075fa33eb9c27890f0ecd6328f59839e35c59"
SCALE = 10**12


def ceil(value):
    return -(-value.numerator // value.denominator)


def ceil_sqrt(value, scale):
    k = isqrt(value.numerator * scale**2 // value.denominator)
    return Fraction(k + (k**2 * value.denominator < value.numerator * scale**2), scale)


def book_row(entry, floor_ratio):
    mass = ceil(floor_ratio * Fraction(entry["deleted_upper"]) * SCALE)
    rms = ceil_sqrt(floor_ratio * Fraction(entry["pair_squared_upper"]), SCALE)
    pair = ceil((rms + Fraction(1, 4_000_000))**2 * SCALE)
    joint = ceil(floor_ratio * Fraction(entry["joint_singles_and_schur_upper"]) * SCALE) + 10_000
    young = ceil(ceil_sqrt(Fraction(pair, mass), 10**8) * 10**6)
    cost = ceil(joint + Fraction(young, 10**6) * mass + Fraction(10**6 * pair, young))
    return (mass, pair, joint, young, cost)


def check():
    data = RECEIPT.read_bytes()
    if sha256(data).hexdigest() != RECEIPT_HASH:
        raise ValueError("The archived certificate has changed")
    receipt = json.loads(data)
    middle = receipt["middle"]
    if [entry["start"] for entry in middle] != list(range(90_000, 940_000, 40_000)):
        raise ValueError("The archived edge groups have changed")
    if not receipt["complete_restoration_inputs"] or any(row["required_inputs_missing"] for row in middle):
        raise ValueError("The restoration certificate is incomplete")
    floor_ratio = Fraction(receipt["continuum_scaled_ordinary_floor"]) / Fraction("94.17312")
    if not 1 <= floor_ratio <= Fraction("1.00000011"):
        raise ValueError("Unexpected normalization of the restoration certificate")
    rows = (LEAN / "TrialRestorationRows180.lean").read_text()
    source_rows = re.findall(r"^  ⟨([\d, ]+)⟩", rows, re.MULTILINE)
    lean_rows = [tuple(map(int, row.split(","))) for row in source_rows]
    if lean_rows != [book_row(entry, floor_ratio) for entry in middle]:
        raise ValueError("The Lean middle targets differ from the directed certificate")

    bounds = (LEAN / "TrialRestorationBudget180.lean").read_text()
    for group in ("low", "high"):
        row = receipt["fixed_groups"][group]
        for label, key in (("Mass", "deleted_upper"), ("Image", "squared_image_upper")):
            ticks = ceil(floor_ratio * Fraction(row[key]) * SCALE)
            match = re.search(rf"^  {group}{label} : .*?≤ ticks (\d+) \* originalMass$", bounds, re.MULTILINE)
            if match is None or int(match[1]) != ticks:
                raise ValueError(f"The {group} {label} target differs from the directed certificate")
    return {"outer_groups": 2, "middle_groups": len(middle), "middle_cost_ticks": sum(r[-1] for r in lean_rows),
            "scale": SCALE, "source_sha256": RECEIPT_HASH}


if __name__ == "__main__":
    print(json.dumps(check(), indent=2))
