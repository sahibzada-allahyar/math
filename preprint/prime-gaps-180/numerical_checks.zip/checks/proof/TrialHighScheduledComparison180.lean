import TrialHighScheduledPhysical180
import TrialHighCachedControl180
import TrialHighMethodWords180
import TrialHighFactoredInterval180

/-! Bind each integer comparison to the original archived coefficients,
the exact advertised geometry, and the scheduled mass payment. -/
noncomputable section
namespace PrimeGap180.HighScheduledComparison
open HighScheduledPhysical HighPanelSchedule HighCachedControl HighLinearControls
open HighLinearControlWords (signedRow storedDenominator denominator_pos)
open HighMethodWords (method denominator word pos)
open HighFiniteSignedDot (weighted)
open HighFactoredDot (subtotal)
open HighFrozenPanel (chart)
open HighAngularGram (Channels)
open HighMassBands (capClass)
open HighGroupedPayment (scale symmetry)
open HighAngularIndex (atSlot)

def rate (i : Row) := (HighPanelTiltBook.read (fee i).tilt).rate
def tilt (i : Row) := (HighPanelTiltBook.read (fee i).tilt).bound
def methodWords (i : Row) := word (fee i).method (fee i).qNumerator (fee i).qDenominator
def methodDen (i : Row) := denominator (fee i).method (fee i).qNumerator (fee i).qDenominator
def controlDen (d : ℕ) := storedDenominator*d

def comparison (i : Row) (C : HighSignedControls.Words) (d l h : ℕ)
    (L U : Fin 21→Fin 53→ℕ) :=
  let W := weighted C (methodWords i)
  let dot := (l:ℤ)*subtotal C W L false+(h:ℤ)*subtotal C W U true
  dot*(2^320:ℤ)*10^94 ≤ ((fee i).units:ℤ)*
    (controlDen d*controlDen d*methodDen i*scale*symmetry (lowerBand i) (upperBand i):ℕ)*tilt i*446

attribute [local irreducible] HighPanelSchedule.fee HighPanelSchedule.data

theorem paid (i : Row) (R : Fin 4→Channels→ℤ) (B : Fin 4→Fin 4→ℤ) (d : ℕ)
    (dp : 0<d)
    (radial : ∀ k p, signedRow (capClass (upperBand i)) (chart.symm p) (knotIndex (span i) k)=R k p)
    (basis : ∀ k j, basisControl (span i).val (knotIndex (span i) k).val (leftEnd i) (rightEnd i) j=(B k j:ℚ)/d)
    (L U : Fin 21→Fin 53→ℕ) (l h : ℕ)
    (lo : ∀ e s, l*L e s ≤ HighIntegerGram.gramWord false (rate i) (lowerBand i) (upperBand i) (atSlot (e,s)))
    (hi : ∀ e s, HighIntegerGram.gramWord true (rate i) (lowerBand i) (upperBand i) (atSlot (e,s)) ≤ h*U e s)
    (check : comparison i (matrix R B) d l h L U) : RowPaid i := by
  have live : (fee i).panel ∈ HighPanelCensus.panels := by
    rw [←covers]
    exact Finset.mem_image_of_mem _ (Finset.mem_univ _)
  have start : 3 ≤ (span i).val :=
    (of_decide_eq_true (Finset.mem_filter.mp live).2 : lowerBand i ≤ upperBand i ∧ _).2.1
  obtain ⟨_,hn,hd⟩ := verified i
  let m := method (fee i).method (fee i).qNumerator (fee i).qDenominator hn hd
  apply from_integer i m (matrix R B) (methodWords i) (den:=controlDen d) (e:=methodDen i)
    (Nat.mul_pos denominator_pos dp) (pos _ _ _ hn hd)
  · exact HighCachedControl.exact (span i) start _ _ _ R B dp radial basis
  · exact HighMethodWords.exact _ _ _ hn hd
  · change HighGroupedPayment.sumWord (rate i) (lowerBand i) (upperBand i)
      (HighSignedControls.coeff (matrix R B) (methodWords i))*(2^320:ℤ)*10^94 ≤
      ((fee i).units:ℤ)*(controlDen d*controlDen d*methodDen i*scale*symmetry (lowerBand i) (upperBand i):ℕ)*tilt i*446
    have bound := HighFactoredInterval.bound (rate i) (lowerBand i) (upperBand i) (matrix R B) (methodWords i) L U l h lo hi
    exact (mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right bound (by positivity : (0:ℤ) ≤ 2^320))
      (by positivity : (0:ℤ) ≤ 10^94)).trans check

#print axioms paid
end PrimeGap180.HighScheduledComparison
