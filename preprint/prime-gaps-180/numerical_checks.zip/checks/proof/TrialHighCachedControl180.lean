import TrialHighLinearControlWords180
import TrialHighFrozenPanel180
import TrialHighSignedControls180

/-! Reuse the four frozen radial coefficient rows across every panel
clipped from the same knot span and cap class. Only sixteen basis values
depend on the actual endpoints of a panel. -/
noncomputable section
open scoped BigOperators
namespace PrimeGap180.HighCachedControl
open FrozenProfile HighFrozenPanel HighLinearControlWords HighLinearControls
open HighSignedControls (Words)
open HighAngularGram (Channels)

def knotIndex (s : Fin 30) (k : Fin 4) : Fin 30 :=
  ⟨min (s.val-3+k.val) 29,by omega⟩

private theorem index_val (s : Fin 30) (k : Fin 4) (h : 3 ≤ s.val) :
    (knotIndex s k).val=s.val-3+k.val := by
  unfold knotIndex
  exact Nat.min_eq_left (by omega)

private theorem index_inj (s : Fin 30) (h : 3 ≤ s.val) : Function.Injective (knotIndex s) := by
  intro a b same
  have e := congrArg Fin.val same
  rw [index_val _ _ h,index_val _ _ h] at e
  exact Fin.ext (by omega)

private theorem basis_index (s : Fin 30) (h : 3 ≤ s.val) :
    Finset.univ.filter (fun k : Fin 30 => active s.val k.val) = Finset.univ.image (knotIndex s) := by
  ext k
  simp only [Finset.mem_filter,Finset.mem_univ,true_and,Finset.mem_image]
  constructor
  · intro hk
    let j : Fin 4 := ⟨k.val-(s.val-3),by unfold active at hk; omega⟩
    refine ⟨j,?_⟩
    apply Fin.ext
    rw [index_val _ _ h]
    change s.val-3+(k.val-(s.val-3))=k.val
    unfold active at hk
    omega
  · rintro ⟨j,rfl⟩
    rw [index_val _ _ h]
    unfold active
    omega

def matrix (R : Fin 4→Channels→ℤ) (B : Fin 4→Fin 4→ℤ) : Words :=
  fun i p => ∑ k : Fin 4, R k p * B k i

theorem exact (s : Fin 30) (start : 3 ≤ s.val) (c : Fine) (l h : ℚ)
    (R : Fin 4→Channels→ℤ) (B : Fin 4→Fin 4→ℤ) {d : ℕ} (positive : 0 < d)
    (row : ∀ k p, signedRow c (chart.symm p) (knotIndex s k) = R k p)
    (basis : ∀ k i, basisControl s.val (knotIndex s k).val l h i = (B k i:ℚ)/d)
    (i : Fin 4) (p : Channels) :
    HighFrozenPanel.control s.val c l h i p = (matrix R B i p:ℝ)/(storedDenominator*d:ℕ) := by
  let W : Fin 30→Fin 4→ℤ := fun k i => B ⟨(k.val-(s.val-3))%4,by omega⟩ i
  have W_eq (k : Fin 4) (j : Fin 4) : W (knotIndex s k) j = B k j := by
    change B ⟨(((knotIndex s k).val-(s.val-3))%4),_⟩ j = _
    congr 1
    apply Fin.ext
    change ((knotIndex s k).val-(s.val-3))%4=k.val
    rw [index_val _ _ start]
    simp [Nat.mod_eq_of_lt k.isLt]
  have all (k : Fin 30) (a : active s.val k.val) :
      basisControl s.val k.val l h i = (W k i:ℚ)/d := by
    have mem : k ∈ Finset.univ.filter (fun k : Fin 30 => active s.val k.val) :=
      Finset.mem_filter.mpr ⟨Finset.mem_univ _,a⟩
    rw [basis_index s start] at mem
    obtain ⟨k,_,rfl⟩ := Finset.mem_image.mp mem
    rw [W_eq,basis]
  have sum : panelWord s.val c (chart.symm p) i W = matrix R B i p := by
    unfold panelWord matrix
    rw [basis_index s start,Finset.sum_image (index_inj s start).injOn]
    simp only [row,W_eq]
  unfold HighFrozenPanel.control
  rw [HighLinearControlWords.control _ _ _ _ _ _ W positive all,sum]
  push_cast
  rfl

#print axioms exact
end PrimeGap180.HighCachedControl
