"""Check the role fields of `ReceiptGap.Numerical` against their external certificates.

Fields covered (TrialReceiptGap180.lean, structure `Numerical`):

  capMass    CoarseMassTargets.Bounds grid           lower c <= 2^27 m(c) <= upper c, 9 changing caps
  pair       changes c -> p(c) <= RoundedCaps.dyad c 4 = target(c,4)/2^20
  core       not settled c -> target'(c,1)/2^20 <= s(1,c)
  first      not settled c -> target'(c,2)/2^20 <= s(0,c)
  last       not settled c -> target'(c,3)/2^20 <= s(38,c)
  debitCore  positiveDebit grid 1  <= DebitRoleBounds.coreCeiling  * 1.025
  debitFirst positiveDebit grid 0  <= DebitRoleBounds.firstCeiling * 1.025
  debitLast  positiveDebit grid 38 <= DebitRoleBounds.lastCeiling  * 1.025

Every Lean constant is read from the Lean sources, every certificate endpoint is an exact
rational, and every comparison uses `fractions.Fraction`. The program also checks that
the independent enclosures of the same quantity intersect, that the certificates are
internally consistent, and the hashes of their authenticated inputs. With the exported
worker payload present (`--payload DIR`, or the environment variable `PAYLOAD`; there is
no default) it also compares the worker's
price, debit and pair weights with the Lean definitions `keyPrice`, `debitPrice` and
`NativeRoleTotals.q` at every native index of all 37 caps.

  python3 certify_numerical_roles.py
  python3 certify_numerical_roles.py --payload DIR --hash-payload
  python3 certify_numerical_roles.py --replay-pair /path/to/partial-native-pair.json

`--replay-pair` compares a partial replay of `check_exact_endpoint_pair.py --stop-at CAP`
with `exact_native_pair.json` (bit-for-bit for every cap the replay computed).
Exit status is nonzero on any failure.
"""
import argparse
from decimal import Decimal
from fractions import Fraction as F
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
NATIVE = HERE.parent / 'data'
LEAN = HERE.parents[1] / 'lean' / 'proof'
sys.path.insert(0, str(NATIVE))
from archived_sources import recorded_digest  # noqa: E402

RECEIPT_256 = NATIVE / 'parallel_quotient_debit.json'
RECEIPT_160 = HERE / 'quotient_and_debit_cert.json'
RECEIPT_SPAN = LEAN / 'mass_span_external_intervals.json'
RECEIPT_PAIR = HERE / 'exact_native_pair.json'

# Inputs authenticated by the certificates themselves.
INPUT_HASHES = {
    LEAN / 'frozen_band_tables.json': '785527884ca340d8ca12909f3076b422fddf4922e234cdd3a574f74bc70de6ef',
    NATIVE / 'cap_law_transfer.json': 'ed9488dd445fac92da256d97f8c3f53684906823529875c033d6d6248072f7b3',
    NATIVE / 'h1_dickman_native_bounds.json': '7c0671c33da312ef4b718f2aa3c6f403ea9f9986447b33e64fa1cf652145535d',
    NATIVE / 'h1_multilevel_strip_free.json': '54ebbdfc333e758986488536810fa712fef7507d45e51c3eb8764be164ca58b3',
    NATIVE / 'repriced_covers.json': 'ba9a8a618e056751dd3f5ac230a28c3453933f9f00072e1dadce57b3548fec45',
}

# The exact statement of each covered field, as it must appear in `Numerical`.
FIELD_TEXT = {
    'capMass': 'capMass : CoarseMassTargets.Bounds grid',
    'pair': 'pair (c : PackedSingleFields.Hist) : InactiveCaps.changes c = true → RoundedCaps.p grid c ≤ RoundedCaps.dyad c 4',
    'core': 'core (c : PackedSingleFields.Hist) : ¬PositiveCap.settled c → SlackUncut.dyad\' c 1 ≤ RoundedCaps.s grid 1 c',
    'first': 'first (c : PackedSingleFields.Hist) : ¬PositiveCap.settled c → SlackUncut.dyad\' c 2 ≤ RoundedCaps.s grid 0 c',
    'last': 'last (c : PackedSingleFields.Hist) : ¬PositiveCap.settled c → SlackUncut.dyad\' c 3 ≤ RoundedCaps.s grid (Fin.last 38) c',
    'debitCore': 'debitCore : NativeRoleTotals.positiveDebit grid 1 ≤ SlackDebit.coreCeiling',
    'debitFirst': 'debitFirst : NativeRoleTotals.positiveDebit grid 0 ≤ SlackDebit.firstCeiling',
    'debitLast': 'debitLast : NativeRoleTotals.positiveDebit grid (Fin.last 38) ≤ SlackDebit.lastCeiling',
}
# Definitions whose text the certificates' interpretation depends on.
DEF_TEXT = {
    'TrialReceiptGap180.lean': ['abbrev grid := PositiveCap.physicalGrid'],
    'TrialRoundedCaps180.lean': [
        'def scale : ℝ := 1048576',
        'def m (g : Grid) (c : Hist) : ℝ := 100^39 * ∑ j : Tick,',
        'def s (g : Grid) (i : Fin 39) (c : Hist) : ℝ := (rho/100)*100^38 * ∑ j : Tick,',
        'def p (g : Grid) (c : Hist) : ℝ := 100^37 * ∑ j : Tick,',
        'def dyad (c : Hist) (r : Fin 5) : ℝ := (target c r : ℝ)/scale'],
    'TrialSlackUncut180.lean': ["def dyad' (c : Hist) (r : Fin 5) : ℝ := (target' c r : ℝ)/RoundedCaps.scale"],
    'TrialCoarseMassTargets180.lean': [
        '(lower c:ℝ) ≤ 2^27*RoundedCaps.m g c ∧ 2^27*RoundedCaps.m g c ≤ (upper c:ℝ)'],
    'TrialNativeRoleTotals180.lean': [
        'def q (j : ℕ) := 2*(rho/100)^2/(EndpointPhysical.ledger-Native.adverse (d:=37) j)^2',
        'def positiveDebit (g : Grid) (i : Fin 39) : ℝ :=\n  (rho*100^37)*∑ j : Tick,∑ c : Hist,'],
    'TrialPositiveCap180.lean': ['def settled (c : Hist) := c=0 ∨ c=3 ∨ c=35'],
    'TrialPhysicalDebit180.lean': ['def inv (a : ℝ) := 1/(ledger - min 0.2801 (max 0 a))',
                                   'def rate (s : Fin 521) (j : ℕ) := diff s (inv (Native.adverse (d := 38) j))'],
    'TrialNativeRadius180.lean': ['def adverse {d : ℕ} (J : ℕ) : ℝ := rho*((J:ℝ)+d)*step',
                                  'def step : ℝ := 1399373467/172031279104000'],
    'TrialEndpointPhysical180.lean': ['abbrev ledger : ℝ := 4999/10000'],
    'TrialPrimeRadialPrice180.lean': ['def primePrice (q : ℝ) := 1/(0.4999-q)'],
    'TrialAdverseScore180.lean': ['archiveRows% (include_str "../data/h1_multilevel_strip_free.json")'],
    'TrialArchivedGap180.lean': ['archiveRows% (include_str "../data/repriced_covers.json")'],
}

RHO = F(2624989, 10**7)
STEP = F(1399373467, 172031279104000)
LEDGER = F(4999, 10000)
TICKS = 130965

FAILURES = []
REPORT = {}


def ok(cond, msg):
    if cond:
        print('ok    ' + msg)
    else:
        print('FAIL  ' + msg)
        FAILURES.append(msg)
    return cond


def digest(path):
    h = sha256()
    with open(path, 'rb') as f:
        while chunk := f.read(1 << 23):
            h.update(chunk)
    return h.hexdigest()


# ------------------------------------------------------------------ Lean constants

def lean(name):
    return (LEAN / name).read_text()


def table(src, name):
    body = src.split(f'def {name} : Fin 37 → Fin 5 → ℤ := ![', 1)[1].split(']]', 1)[0]
    rows = [[int(x) for x in r] for r in re.findall(r'!\[(-?\d+),(-?\d+),(-?\d+),(-?\d+),(-?\d+)', body)]
    if len(rows) != 37:
        raise ValueError(f'{name}: expected 37 rows, found {len(rows)}')
    return rows


def match_table(src, name):
    body = src.split(f'def {name} (c : Hist) : ℤ := match c.val with', 1)[1].split('| _ => 0', 1)[0]
    return {int(a): int(b) for a, b in re.findall(r'\| (\d+) => (\d+)', body)}


def lean_constants():
    gap = lean('TrialReceiptGap180.lean')
    numerical = gap.split('structure Numerical : Prop where', 1)[1].split('theorem massFloor', 1)[0]
    flat = ' '.join(numerical.split())
    for field, text in FIELD_TEXT.items():
        ok(' '.join(text.split()) in flat, f'Numerical.{field} reads exactly `{text}`')
    for name, texts in DEF_TEXT.items():
        src = lean(name)
        for t in texts:
            ok(t in src, f'{name} contains `{t.splitlines()[0]}`')
    final = lean('TrialFinalGap180.lean')
    ok('(numerical : ReceiptGap.Numerical)' in final and 'ReceiptGap.gap_of_cited prime rank4 prop31' in final,
       'h1_le_180_of_numerical takes ReceiptGap.Numerical')

    caps = [int(x) for x in re.search(r'def capIndices : List Nat := \[([\d,\s]+)\]',
                                      lean('TrialHistoricalSiteArithmetic180.lean'))[1].replace('\n', '').split(',')]
    ok(len(caps) == 37 and caps == sorted(caps), 'capIndices: 37 increasing historical caps (Hist c <-> caps[c])')
    flags = re.search(r'def changes : Hist → Bool := !\[([a-z,]+)\]', lean('TrialInactiveCaps180.lean'))[1].split(',')
    changing = [c for c, f in enumerate(flags) if f == 'true']
    ok(changing == [7, 8, 15, 23, 26, 30, 33, 34, 36], f'InactiveCaps.changes is true exactly at {changing}')
    settled = {0, 3, 35}

    coarse = lean('TrialCoarseMassTargets180.lean')
    lower, upper = match_table(coarse, 'lower'), match_table(coarse, 'upper')
    ok(sorted(lower) == sorted(upper) == changing, 'CoarseMassTargets.lower/upper are nonzero only at changing caps')
    target = table(lean('TrialRoundedNumbers180.lean'), 'target')
    slack = lean('TrialSlackUncut180.lean')
    target2 = table(slack, "target'")
    ok(all(target2[c][0] == target[c][0] and target2[c][4] == target[c][4] for c in range(37)),
       "target' and target agree in columns 0 and 4 (SlackUncut.outer_cols)")

    deb = lean('TrialDebitRoleBounds180.lean')
    ceil = {k: F(int(a), int(b)) for k, a, b in
            re.findall(r'def (\w+Ceiling) : ℝ := (\d+)/(\d+)', deb)}
    floor = re.search(r'def massFloor : ℝ := (\d+)/(\d+)', deb)
    mass_floor = F(int(floor[1]), int(floor[2]))
    sd = lean('TrialSlackDebit180.lean')
    factor = {k: F(v) for k, v in re.findall(r'def (\w+Ceiling) : ℝ := DebitRoleBounds\.\w+Ceiling \* ([\d.]+)', sd)}
    ok(set(ceil) == set(factor) == {'coreCeiling', 'firstCeiling', 'lastCeiling'},
       'SlackDebit ceilings are DebitRoleBounds ceilings times a decimal factor')
    slack_ceil = {k: ceil[k] * factor[k] for k in ceil}
    return dict(caps=caps, changing=changing, settled=settled, lower=lower, upper=upper,
                target=target, target2=target2, ceil=ceil, factor=factor, slack_ceil=slack_ceil,
                mass_floor=mass_floor)


# ------------------------------------------------------------------ certificates

def pair_of(v):
    return F(v[0]), F(v[1])


def load_256(caps):
    d = json.loads(RECEIPT_256.read_text())
    ok(d['caps'] == list(reversed(caps)), '256-bit certificate: caps in decreasing order, equal to reversed capIndices')
    forms = {}
    headers = True
    for i, r in enumerate(d['receipts']):
        headers &= (r['cap'] == d['caps'][i] and r['bits'] == 256 and r['manifest_sha256'] == d['manifest_sha256']
                    and r['prior_cap'] == (d['caps'][i - 1] if i else None)
                    and r['compiled_library_sha256'] == d['compiled_library_sha256'])
        f = {k: pair_of(v) for k, v in r['forms'].items()}
        headers &= set(f) == {'full', 'core', 'a', 'b', 'pair', 'debit_core', 'debit_a', 'debit_b'}
        headers &= all(lo <= hi for lo, hi in f.values())
        forms[36 - i] = f
    ok(headers, '256-bit certificate: all 37 per-cap headers (cap, bits=256, manifest, predecessor, library, '
       'eight forms, ordered endpoints) agree')
    # Internal consistency: totals and the reducer's derived ratios.
    total_ok = True
    for k, v in d['raw_forms'].items():
        s = (sum(forms[c][k][0] for c in range(37)), sum(forms[c][k][1] for c in range(37)))
        total_ok &= s == pair_of(v)
    ok(total_ok, '256-bit certificate: raw_forms are exactly the sums of the 37 per-cap intervals')
    v = {k: pair_of(x) for k, x in d['raw_forms'].items()}
    mass = v['full']
    lo = 37 * v['core'][0] + v['a'][0] + v['b'][0] - v['pair'][1]
    hi = 37 * v['core'][1] + v['a'][1] + v['b'][1] - v['pair'][0]
    q = [x / y for x in (lo, hi) for y in mass]
    deb = [sum((37 if k == 'debit_core' else 1) * v[k][i] for k in ('debit_core', 'debit_a', 'debit_b')) for i in (0, 1)]
    pd = [x / y for x in deb for y in mass]
    ok([str(min(q)), str(max(q))] == d['quotient'] and [str(min(pd)), str(max(pd))] == d['positive_debit'],
       '256-bit certificate: quotient and positive_debit re-derive exactly from raw_forms')
    return d, forms


def load_160(caps):
    d = json.loads(RECEIPT_160.read_text())
    rows = d['per_cap_results']
    ok(len(rows) == 37 and [r['cap'] for r in rows] == list(reversed(caps)) and d['bits'] == 160,
       '160-bit certificate: 37 caps in decreasing order, 160 bits')
    forms = {36 - r['index']: {k: pair_of(v) for k, v in r['integrals'].items()} for r in rows}
    keys = ['full', 'pair', 'core', 'a', 'b', 'debit_core', 'debit_a', 'debit_b']
    same = all((sum(forms[c][k][0] for c in range(37)), sum(forms[c][k][1] for c in range(37)))
               == pair_of(d['totals_100pow39'][k]) for k in keys)
    ok(same, '160-bit certificate: totals_100pow39 are exactly the sums of the 37 per-cap intervals')
    hashes = True
    for name, h in d['source_hashes'].items():
        try:
            hashes &= recorded_digest(name) == h
        except (OSError, ValueError) as error:
            print(f'      {error}')
            hashes = False
    ok(hashes, f'160-bit certificate: all {len(d["source_hashes"])} recorded source hashes match the files in ../data')
    return d, forms


def load_span(lc):
    d = json.loads(RECEIPT_SPAN.read_text())
    out = {}
    for r in d['caps']:
        c = r['class']
        out[c] = (F(r['lower']), F(r['upper']))
        ok(r['cap'] == lc['caps'][c] and r['strict_integer_targets_at_27_bits'] == [lc['lower'][c], lc['upper'][c]],
           f'span certificate class {c}: cap {r["cap"]} and its 27-bit targets equal CoarseMassTargets.lower/upper')
    ok(sorted(out) == lc['changing'], 'span certificate covers exactly the nine changing caps')
    ok((sum(v[0] for v in out.values()), sum(v[1] for v in out.values())) == (F(d['total_lower']), F(d['total_upper'])),
       'span certificate: total_lower/total_upper are the exact sums of the nine cap intervals')
    ok(F(d['frozen_floor']) == lc['mass_floor'], 'span certificate frozen_floor equals DebitRoleBounds.massFloor')
    return d, out


def load_pair(lc):
    d = json.loads(RECEIPT_PAIR.read_text())
    out = {}
    for r in d['caps']:
        c = r['class']
        out[c] = (F(r['lower']), F(r['upper']))
        ok(r['cap'] == lc['caps'][c] and F(r['cap_upper']) == F(lc['target'][c][4], 2**20),
           f'exact pair certificate class {c}: cap {r["cap"]}, cap_upper = target({c},4)/2^20')
    ok(sorted(out) == lc['changing'] and d['zero_caps'] == 28, 'exact pair certificate: nine changing caps, 28 zero caps')
    ok(d['table_sha256'] == INPUT_HASHES[LEAN / 'frozen_band_tables.json']
       and d['site_grid_manifest_sha256'] == INPUT_HASHES[NATIVE / 'cap_law_transfer.json'],
       'exact pair certificate: spline table and site grid hashes are the authenticated inputs')
    return d, out


# ------------------------------------------------------------------ the field checks

def units(x, k):
    return float(x * 2**k)


def check_cap_mass(lc, span, r256, r160):
    print('\n== capMass: lower c <= 2^27 m(c) <= upper c at the nine changing caps')
    rows = []
    for c in lc['changing']:
        lo_t, hi_t = F(lc['lower'][c]), F(lc['upper'][c])
        # The span and 256-bit enclosures are certificates. The 160-bit run is too wide at
        # cap 36 (about 31 units of 2^-27) and is used only for the intersection test below.
        for name, src in (('span', span[c]), ('256', r256[c]['full']), ('160', r160[c]['full'])):
            lo, hi = src[0] * 2**27, src[1] * 2**27
            line = (f'cap {c:2d} [{name:4s}] {lc["lower"][c]} <= [{float(lo):.4f}, {float(hi):.4f}] <= '
                    f'{lc["upper"][c]}  margins {float(lo - lo_t):.4f} / {float(hi_t - hi):.4f} units of 2^-27')
            if name == '160':
                print(('info  ' if lo_t <= lo and hi <= hi_t else 'info  (not a certificate here) ') + line)
                continue
            ok(lo_t <= lo and hi <= hi_t, line)
            if name == 'span':
                rows.append((c, float(lo - lo_t), float(hi_t - hi)))
        a, b = max(span[c][0], r256[c]['full'][0], r160[c]['full'][0]), min(span[c][1], r256[c]['full'][1], r160[c]['full'][1])
        ok(a <= b, f'cap {c:2d}: span, 256-bit and 160-bit mass enclosures intersect')
    m = min(min(x[1], x[2]) for x in rows)
    REPORT['capMass'] = dict(certificate='mass_span_external_intervals.json', min_margin_units_2_27=m,
                             min_margin_absolute=m / 2**27,
                             per_cap={c: [l, u] for c, l, u in rows})


def check_pair(lc, exact, r256, r160):
    print('\n== pair: p(c) <= target(c,4)/2^20 at the nine changing caps')
    rows = []
    for c in lc['changing']:
        t = F(lc['target'][c][4], 2**20)
        for name, src in (('exact', exact[c]), ('256', r256[c]['pair']), ('160', r160[c]['pair'])):
            ok(src[1] <= t, f'cap {c:2d} [{name:5s}] upper {units(src[1], 20):.4f} <= {lc["target"][c][4]}  '
               f'margin {units(t - src[1], 20):.4f} units of 2^-20 ({float((t - src[1]) / t):.2e} rel)')
            if name == 'exact':
                rows.append((c, units(t - src[1], 20), float((t - src[1]) / t)))
        a = max(exact[c][0], r256[c]['pair'][0], r160[c]['pair'][0])
        b = min(exact[c][1], r256[c]['pair'][1], r160[c]['pair'][1])
        ok(a <= b, f'cap {c:2d}: exact, 256-bit and 160-bit pair enclosures intersect')
    REPORT['pair'] = dict(certificate='exact_native_pair.json', min_margin_units_2_20=min(r[1] for r in rows),
                          min_relative=min(r[2] for r in rows), per_cap={c: u for c, u, _ in rows})


def check_singles(lc, r256, r160):
    names = {1: ('core', ('core',)), 2: ('first', ('a', 'b')), 3: ('last', ('a', 'b'))}
    for col, (field, keys) in names.items():
        print(f"\n== {field}: target'(c,{col})/2^20 <= s(c) at the 34 non-settled caps")
        worst = None
        rows = {}
        for c in range(37):
            if c in lc['settled']:
                continue
            t = F(lc['target2'][c][col], 2**20)
            # First and last use the smaller of the two endpoint forms, so the result does not
            # depend on which worker label ('a' or 'b') is site 0.
            lo256 = min(r256[c][k][0] for k in keys)
            lo160 = min(r160[c][k][0] for k in keys)
            good = t <= lo256 and t <= lo160
            margin = units(lo256 - t, 20)
            rows[c] = margin
            if not good:
                ok(False, f'{field} cap {c}: target {lc["target2"][c][col]} exceeds a certificate lower end')
            if worst is None or margin < worst[1]:
                worst = (c, margin)
            for k in keys:
                if not max(r256[c][k][0], r160[c][k][0]) <= min(r256[c][k][1], r160[c][k][1]):
                    ok(False, f'{field} cap {c}: 256-bit and 160-bit `{k}` enclosures are disjoint')
        changing = min(rows[c] for c in lc['changing'])
        ok(all(lc['target2'][c][col] * F(1) <= min(r256[c][k][0] for k in keys) * 2**20
               and lc['target2'][c][col] <= min(r160[c][k][0] for k in keys) * 2**20 for c in rows),
           f'{field}: all 34 caps below both the 256-bit and 160-bit lower ends; min margin '
           f'{worst[1]:.4f} units of 2^-20 (cap {worst[0]}), min at changing caps {changing:.4f}')
        if col > 1:
            gap = max(abs(r256[c]['a'][0] - r256[c]['b'][0]) for c in range(37))
            ok(units(gap, 20) < 0.01, f'{field}: forms a and b differ by at most {units(gap, 20):.2e} units of 2^-20 '
               'per cap (site-0/site-38 labelling is immaterial)')
        REPORT[field] = dict(certificate='parallel_quotient_debit.json (256-bit); quotient_and_debit_cert.json (160-bit)',
                             min_margin_units_2_20=worst[1], min_margin_cap=worst[0],
                             min_margin_changing_caps=changing, per_cap=rows)


def check_debit(lc, r256, r160):
    print('\n== debit: positiveDebit grid i <= SlackDebit ceiling (sum over all 37 caps)')
    roles = (('debitCore', 'coreCeiling', ('debit_core',)), ('debitFirst', 'firstCeiling', ('debit_a', 'debit_b')),
             ('debitLast', 'lastCeiling', ('debit_a', 'debit_b')))
    for field, name, keys in roles:
        ceil = lc['slack_ceil'][name]
        hi = {}
        for tag, src in (('256', r256), ('160', r160)):
            # First/last: the larger of the two endpoint forms, again independent of labelling.
            hi[tag] = max(sum(src[c][k][1] for c in range(37)) for k in keys)
            ok(hi[tag] <= ceil, f'{field} [{tag}] upper {float(hi[tag]):.12e} <= {float(ceil):.12e} '
               f'(DebitRoleBounds.{name} * {lc["factor"][name]}); relative margin {float((ceil - hi[tag]) / ceil):.4%}')
        for k in keys:
            a = max(sum(r256[c][k][0] for c in range(37)), sum(r160[c][k][0] for c in range(37)))
            b = min(sum(r256[c][k][1] for c in range(37)), sum(r160[c][k][1] for c in range(37)))
            ok(a <= b, f'{field}: 256-bit and 160-bit `{k}` totals intersect')
        unscaled = lc['ceil'][name]
        same = [k for k in keys if unscaled == sum(r160[c][k][1] for c in range(37))]
        print(f'      note: DebitRoleBounds.{name} itself equals the 160-bit upper end of {same or "no form"}; '
              f'the 256-bit upper end exceeds it by {float((hi["256"] - unscaled) / unscaled):.2e} relative')
        REPORT[field] = dict(certificate='quotient_and_debit_cert.json (160-bit); parallel_quotient_debit.json (256-bit)',
                             upper_256=float(hi['256']), upper_160=float(hi['160']), ceiling=float(ceil),
                             relative_margin=float((ceil - max(hi.values())) / ceil))
    # PhysicalDebit.inv clamps the adverse exponent to [0, 0.2801]; the workers do not clamp.
    top = RHO * (TICKS - 1 + 38) * STEP
    ok(top <= F(2801, 10000), f'clamp inactive: adverse(d=38) at the last tick {TICKS - 1} is {float(top):.6f} <= 0.2801, '
       'so debitPrice uses the unclamped 1/(0.4999 - adverse) of the workers')


# ------------------------------------------------------------------ price binding with the worker payload

def fine_cap(c):
    return c + 4 if c < 10 else c + 5 if c < 17 else c + 6 if c < 36 else 43


def lean_labels(tables, radii, c, last):
    """`T.sector (capAt c) (J+1)` with the radius test of FrozenData.sector, sentinel 170."""
    runs = tables['sectorRuns'][fine_cap(c)]
    out = []
    run = 0
    for j in range(last + 1):
        n = j + 1
        while run < len(runs) and runs[run][0] <= n:
            run += 1
        code = runs[run][1] if run < len(runs) else 0
        label = 170
        if 0 < code <= 521:
            s = code - 1
            if 2624989 * (j + 38) * 1399373467 * 10000 <= radii[s] * 10**7 * 172031279104000:
                label = s
        out.append(label)
    return out


def check_payload(lc, payload, d256, hash_all):
    import numpy as np
    print(f'\n== worker payload {payload}: weights against the Lean definitions')
    raw = (payload / 'manifest.json').read_bytes()
    ok(sha256(raw).hexdigest() == d256['manifest_sha256'], 'payload manifest.json hash equals the 256-bit certificates\' manifest_sha256')
    m = json.loads(raw)
    names = [n for n in m['files'] if hash_all or not n.startswith('bank-')]
    ok(all(digest(payload / n) == m['files'][n] for n in names),
       f'payload: {len(names)} file hashes match the manifest' + ('' if hash_all else ' (banks skipped; use --hash-payload)'))
    tables = json.loads((LEAN / 'frozen_band_tables.json').read_text())
    ok(all(m['rows'][str(lc['caps'][c])]['last'] == tables['maxIndex'][fine_cap(c)] for c in range(37)),
       'payload: each cap\'s active last index equals T.maxIndex (capAt c)')
    old = json.loads((NATIVE / 'h1_multilevel_strip_free.json').read_text())['sector_prices']
    new = json.loads((NATIVE / 'repriced_covers.json').read_text())['sector_prices']
    book = json.loads((NATIVE / 'h1_priced_168_table.json').read_text(), parse_float=Decimal)
    radii = [int(-((-10000 * Decimal(x)) // 1)) + 1 for x in book['physical_upper']]
    scale = 10**14
    n = m['n']

    def inv(d):
        j = np.arange(n, dtype=float)
        return 1.0 / (4999 / 10000 - float(RHO * STEP) * (j + d))

    inv38, inv37 = inv(38), inv(37)
    rho100 = float(RHO / 100)

    def lean_weight(rows, labels, positive=False):
        a = np.array([rows[s][0] for s in labels], dtype=float)
        b = np.array([rows[s][1] for s in labels], dtype=float)
        return a, b

    def compare(lean_value, ball, last, size, top):
        # Indices 0..top are compared, where top = last for price and debit, and
        # top = min(last, maxIndex of the next cap) for the jumps: above the next cap's
        # maxIndex the preceding field H vanishes, so the jump weight multiplies H^2 = 0
        # and the worker and Lean choices of the next cap's price there are both immaterial.
        x, r = ball
        diff = np.abs(lean_value[:top + 1] - x[:top + 1])
        tol = r[:top + 1] + 1e-12 * size[:top + 1] + 1e-300
        beyond = not np.any(x[last + 1:]) and not np.any(r[last + 1:])
        return bool(np.all(diff <= tol)) and beyond, float(np.max(diff / np.maximum(size[:top + 1], 1e-30)))

    prev = None
    worst = {'price': 0., 'jump': 0., 'debit': 0., 'debit_jump': 0.}
    all_good = True
    for c in range(36, -1, -1):  # certificate order: decreasing caps
        cap = lc['caps'][c]
        row = m['rows'][str(cap)]
        last = row['last']
        labels = lean_labels(tables, radii, c, last)
        with np.load(payload / row['price_file'], allow_pickle=False) as z:
            w = {k: (z[k + '0'], z[k + '1']) for k in ('price', 'jump', 'debit', 'debit_jump')}
        oa, ob = lean_weight(old, labels)
        na, nb = lean_weight(new, labels)
        q = inv38[:last + 1]
        key = rho100 * (oa + ob * q) / scale
        debit = rho100 * np.maximum(0., ((oa - na) + (ob - nb) * q) / scale)
        if prev is None:
            # Hist 36: keyPrice(J, 37) = debitPrice(J, 37) = 0 and the cap-37 field is empty.
            jump, djump, top = key, debit, last
            pk = pd = np.zeros(last + 1)
        else:
            plast, plabels, pkey, pdebit = prev
            top = min(last, plast)
            pk = np.zeros(last + 1)
            pd = np.zeros(last + 1)
            pk[:top + 1], pd[:top + 1] = pkey[:top + 1], pdebit[:top + 1]
            jump, djump = key - pk, debit - pd
        sizes = {'price': np.abs(key), 'debit': np.abs(debit),
                 'jump': np.abs(key) + np.abs(pk), 'debit_jump': np.abs(debit) + np.abs(pd)}
        for name, val in (('price', key), ('debit', debit), ('jump', jump), ('debit_jump', djump)):
            good, rel = compare(val, w[name], last, sizes[name], last if name in ('price', 'debit') else top)
            worst[name] = max(worst[name], rel)
            if not good:
                all_good = False
                ok(False, f'cap {c} ({cap}): worker `{name}` weight differs from the Lean definition (max rel {rel:.2e})')
        prev = (last, labels, key, debit)
    ok(all_good, 'all 37 caps: worker price, jump, debit and debit_jump balls contain the Lean keyPrice/debitPrice '
       f'values (times rho/100, jumps up to the next cap\'s maxIndex) within 1e-12 relative, and vanish above maxIndex; '
       f'max deviation relative to the operands '
       + ', '.join(f'{k} {v:.1e}' for k, v in worst.items()))
    with np.load(payload / 'pair.npz', allow_pickle=False) as z:
        x, r = z['v0'], z['v1']
    qj = 2 * rho100**2 * inv37**2
    rel = float(np.max(np.abs(qj - x) / x))
    ok(bool(np.all(np.abs(qj - x) <= r + 1e-12 * x)), f'pair weight ball contains NativeRoleTotals.q(J) at all {n} indices '
       f'(max relative deviation {rel:.1e})')
    # Exact spot check: the Lean value lies inside the ball (no tolerance) at a sample of indices.
    exact_ok = True
    for c in (36, 15, 7, 0):
        cap = lc['caps'][c]
        row = m['rows'][str(cap)]
        labels = lean_labels(tables, radii, c, row['last'])
        with np.load(payload / row['price_file'], allow_pickle=False) as z:
            xc, rc = z['price0'], z['price1']
        for j in list(range(0, row['last'] + 1, 4099)) + [row['last']]:
            a, b = old[labels[j]][:2]
            val = RHO / 100 * (F(a) + F(b) / (LEDGER - RHO * STEP * (j + 38))) / scale
            exact_ok &= abs(val - F(float(xc[j]))) <= F(float(rc[j]))
    ok(exact_ok, 'exact rational keyPrice lies inside the worker price ball at sampled indices of caps 36, 15, 7, 0')


def check_replay(path, exact):
    print(f'\n== replay {path} against exact_native_pair.json')
    d = json.loads(Path(path).read_text())
    for r in d['caps']:
        c = r['class']
        ok((F(r['lower']), F(r['upper'])) == exact[c], f'replayed cap {c} ({r["cap"]}) equals the certificate bit for bit')
    REPORT['pair_replay'] = [r['class'] for r in d['caps']]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--payload', type=Path, default=os.environ.get('PAYLOAD'),
                    help='directory of the per-cap computation payload (default: the environment variable PAYLOAD)')
    ap.add_argument('--hash-payload', action='store_true', help='also hash the 3 GB of geometry banks')
    ap.add_argument('--replay-pair', type=Path, help='output of check_exact_endpoint_pair.py --stop-at CAP')
    ap.add_argument('--json', type=Path, help='write the margin report here')
    args = ap.parse_args()

    print('== Lean statements and constants')
    lc = lean_constants()
    print('\n== certificates')
    for p in (RECEIPT_256, RECEIPT_160, RECEIPT_SPAN, RECEIPT_PAIR):
        print(f'      sha256 {digest(p)}  {p.relative_to(HERE.parents[1])}')
    for p, h in INPUT_HASHES.items():
        ok(digest(p) == h, f'input {p.name} has the authenticated hash')
    d256, r256 = load_256(lc['caps'])
    d160, r160 = load_160(lc['caps'])
    _, span = load_span(lc)
    _, exact = load_pair(lc)

    check_cap_mass(lc, span, r256, r160)
    check_pair(lc, exact, r256, r160)
    check_singles(lc, r256, r160)
    check_debit(lc, r256, r160)
    if args.payload and (args.payload / 'manifest.json').exists():
        check_payload(lc, args.payload, d256, args.hash_payload)
    else:
        print('\n-- no payload' + (f' at {args.payload}' if args.payload else ' given (set PAYLOAD or pass --payload)')
              + '; price binding check skipped')
    if args.replay_pair:
        check_replay(args.replay_pair, exact)

    print('\n== summary of margins')
    for k in ('capMass', 'pair', 'core', 'first', 'last', 'debitCore', 'debitFirst', 'debitLast'):
        v = {a: b for a, b in REPORT[k].items() if a != 'per_cap'}
        print(f'  {k:10s} ' + ', '.join(f'{a}={b:.6g}' if isinstance(b, float) else f'{a}={b}' for a, b in v.items()))
    if args.json:
        args.json.write_text(json.dumps(REPORT, indent=1, default=str) + '\n')
    if FAILURES:
        print(f'\n{len(FAILURES)} check(s) FAILED')
        sys.exit(1)
    print('\nAll checks passed.')


if __name__ == '__main__':
    main()
