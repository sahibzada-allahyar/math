import TrialHighPanelCoefficients180

/-! Compute the sixteen Bernstein basis controls of a panel once. Each
signed channel then uses those same basis controls in a four-term dot. -/
noncomputable section
open scoped BigOperators
namespace PrimeGap180.HighLinearControls
open HighPanelCoefficients HighSplineControls FrozenProfile FrozenData

abbrev active (s k : ℕ) := k ≤ s ∧ s ≤ k+3

def basisControl (s k : ℕ) (a b : ℚ) (i : Fin 4) : ℚ :=
  if active s k then
    four (atPoint s a 3 k) (atPoint s (a+(b-a)/3) 3 k)
      (atPoint s (a+2*(b-a)/3) 3 k) (atPoint s b 3 k) i
  else 0

def channelScale (u : FullNativeTicks.Key) : ℚ :=
  39^((signatures u.2.2).sum-(signatures u.2.2).length)

def rowNum (c : Fine) (u : FullNativeTicks.Key) (k : Fin 30) : ℚ :=
  rowQ c ⟨3*u.1.val+u.2.1.val,by omega⟩ u.2.2 k

private theorem linear (c : ℚ) (S : Finset (Fin 30)) (F : Fin 4→Fin 30→ℚ) (v : Fin 30→ℚ)
    (t : Fin 4) :
    four (c*∑ k ∈ S,v k*F 0 k) (c*∑ k ∈ S,v k*F 1 k)
      (c*∑ k ∈ S,v k*F 2 k) (c*∑ k ∈ S,v k*F 3 k) t =
      c*(∑ k ∈ S,v k*four (F 0 k) (F 1 k) (F 2 k) (F 3 k) t) := by
  fin_cases t
  · rfl
  · simp only [four,Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.cons_val_succ]
    simp only [div_eq_mul_inv,Finset.mul_sum,Finset.sum_mul,←Finset.sum_sub_distrib,←Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro k _
    change _ = c * (v k * ((2*(27*F 1 k-8*F 0 k-F 3 k)-
      (27*F 2 k-F 0 k-8*F 3 k))/18))
    ring
  · simp only [four,Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.cons_val_succ]
    simp only [div_eq_mul_inv,Finset.mul_sum,Finset.sum_mul,←Finset.sum_sub_distrib,←Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro k _
    change _ = c * (v k * ((2*(27*F 2 k-F 0 k-8*F 3 k)-
      (27*F 1 k-8*F 0 k-F 3 k))/18))
    ring
  · rfl

theorem formula (s : ℕ) (c : Fine) (u : FullNativeTicks.Key) (l h : ℚ) (t : Fin 4) :
    HighSplineControls.row s c u l h t =
      channelScale u * ∑ k ∈ Finset.univ.filter (fun k : Fin 30 => active s k.val),
        rowNum c u k * basisControl s k.val l h t := by
  rw [←HighPanelCoefficients.original]
  let S := Finset.univ.filter (fun k : Fin 30 => active s k.val)
  have e (x : ℚ) : point s c u x = channelScale u * ∑ k ∈ S,rowNum c u k*atPoint s x 3 k.val := by
    unfold point channelScale rowNum S
    rw [Finset.sum_filter]
  unfold HighPanelCoefficients.control
  simp only [e]
  let F (i : Fin 4) (k : Fin 30) := atPoint s (![l,l+(h-l)/3,l+2*(h-l)/3,h] i) 3 k.val
  have h0 := linear (channelScale u) S F (rowNum c u) t
  apply h0.trans
  apply congrArg (fun v => channelScale u*v)
  apply Finset.sum_congr rfl
  intro k hk
  have qa := (Finset.mem_filter.mp hk).2
  unfold basisControl
  rw [if_pos qa]
  rfl

#print axioms formula
end PrimeGap180.HighLinearControls
