"""Verify the variable-endpoint slot-selection hypotheses and interior examples."""
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
import json


ROUTES = Path(__file__).resolve().parents[1] / 'data' / 'distribution_routes.json'


def geometry(a, long_slot, cut):
    # Relative log-scale errors for a fixed mesh and sufficiently large x.
    e = Q(1, 10**12)
    lower = a-4*e
    upper = 1-a+4*e
    threshold = long_slot-4*e
    gap = upper-lower
    zeta = 1-a-long_slot
    assert lower < upper and upper > 0 and gap > Q('.09')+e
    assert lower <= 3*gap and lower <= upper/2+gap
    assert lower <= 2*(upper-threshold)
    assert a+e < upper and lower < 1-e-(a+e)
    assert 1+e-(zeta-e) < 4*upper/3
    assert upper-threshold > Q(1, 5)
    assert 1+e-3*upper/2 < 1-3*(1-a)/2
    if cut is not None:
        assert 1+e-2*upper+cut+e < 1-2*(1-a)+cut
    return lower, upper, threshold


def interior_example(a, long_slot, cut):
    lower, upper, threshold = geometry(a, long_slot, cut)
    eta = Q(1, 10**7)
    if cut is None:
        singles = [upper/2+eta]*3
        residual = [Q(1, 3)-s for s in singles]
        cap = 1-3*(1-a)/2
    else:
        small = cut-2*eta
        singles = [small, upper-small+eta, upper-small+eta]
        rest = 1-sum(singles)-eta
        residual = [eta, rest/2, rest/2]
        cap = 1-2*(1-a)+cut
    parents = [s+r for s, r in zip(singles, residual, strict=True)]
    assert all(1-a-long_slot < p < a for p in parents)
    assert cut is None or parents[0] < cut < min(parents[1:])
    assert all(Q(1, 5) < s < threshold for s in singles)
    assert all(0 < r < Q('.09') for r in residual)
    slots = singles+residual
    assert sum(slots) == 1
    for k in range(7):
        assert all(not lower <= sum(subset) <= upper for subset in combinations(slots, k))
    assert 0 < cap-sum(residual) < Q(1, 10**6)
    return sum(residual)


if __name__ == '__main__':
    rows = json.loads(ROUTES.read_text())
    assert len(rows) == 13
    for row in rows:
        p = row['parameters']
        interior_example(Q(p['a']), Q(p['I']), Q(p['parent_cut']) if p['parent_cut'] else None)
    print('13 parameter rows pass. All 64 subsets avoid the middle interval in each interior example.')
