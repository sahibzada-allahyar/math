"""Exact certificate for three fields of `PrimeGap180.ReceiptGap.Numerical`.

    highRows  : ∀ i, HighScheduledPhysical.RowPaid i
    lowImage  : ∃ G E, CertifiedBudget.LowImage G E
    highImage : ∃ G E, CertifiedBudget.HighImage G E

The two image fields are certified decompositions (TrialCertifiedBudget180.lean): a
tabulated image G on a worker event E containing Lean's lowRegion/highRegion, the worker
bound  ∫_E G² ≤ ticks U · originalMass  at the certificate image values U = 1196124 and
179904296, and the transfer  ∫_E (field - G)² ≤ δ² · originalMass  with δ = FIELD + SWAP
(low) and δ = FIELD (high).  `CertifiedBudget.lowImage/highImage` prove the slack fields
    imageSq 0  ≤ RestorationRows.ticks 1375543   * originalMass
    imageSq 23 ≤ RestorationRows.ticks 206889941 * originalMass
of `SlackBudget.Bounds` with the (1+λ) step at λ = 1/10.

Run with a Python that has numpy and scipy:

    python3 certify_numerical_high.py [--json report.json]

All arithmetic is exact (integers and `fractions.Fraction`); square roots are
rounded upward with integer square roots. The script exits with status 1 on
the first failed check.

highRows.  `HighScheduledComparison.paid` turns five hypotheses into
`RowPaid i`: `radial`, `basis`, `lo`, `hi` and `check` (the integer
inequality `comparison`).  For each of the 444 rows this script

  * re-derives the radial rows `R` from `frozen_band_tables.json` (the file the
    Lean archive includes verbatim) by the formula of
    `HighLinearControlWords.signedRow`, with suffix `archive.suffix[capClass b]`,
    the channel chart `(3a+b)*11+sig` and `knotIndex s k = s-3+k`;
  * re-derives the basis `B/d` by the Cox-de Boor recursion of
    `HighPanelCoefficients.atPoint`, the conversion `HighSplineControls.four`,
    the knots of `MassSplineSpan.records` and the endpoints
    `HighPanelCensus.lo/hi`, all parsed from the Lean sources;
  * re-derives the method words and denominator of `HighMethodWords`;
  * evaluates the left and right sides of `comparison` exactly
    (via `high_rows_data.row`, which reads the schedule, the tilt table, the
    plan book and the coefficient lists from the Lean sources and recomputes
    the outward-rounded reduced Grams `L`, `U` and factors `l`, `h` from the
    one-site words);
  * cross-checks the Lean schedule against the archived Python schedule,
    payments and the 96-bit compact-Gram certificate.

What this script does NOT establish for highRows: that the Python one-site
words `K`, `E` (from `check_high_integer_panels.Moments` on the tail book in
`high_rows/`) equal Lean's `HighIntegerGram.powWord/endWord`, and that the Python
interior/plan evaluation equals `HighGramArithmetic.interiorValue`.  Those
equalities are the `core`/`ends`/`interior` hypotheses of
`HighRowKit.linkLower/linkUpper`; they are not checked here.

lowImage / highImage.  The script re-derives the worker's squared-image
uppers from the archived certificates in exact arithmetic, using Lean's proved
floor 94.17312 instead of the worker's larger native floor, and checks the
Lean constants.  The worker certificates themselves are binary64/Arb outputs, and
the error analyses that relate them to the Lean fields are in the paper.
"""
import argparse
from fractions import Fraction as Q
from hashlib import sha256
import json
from math import isqrt
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ARCHIVE = HERE.parent / "data"
LEAN = HERE.parents[1] / "lean" / "proof"
STAGE = HERE / "high_rows"
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ARCHIVE))
from archived_sources import PREFIX  # noqa: E402
from high_rows_data import lean_path  # noqa: E402

FAILURES = []


def require(condition, message):
    if not condition:
        FAILURES.append(message)
        print("FAIL:", message, file=sys.stderr)
        raise SystemExit(1)


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def lean(name):
    return lean_path(name).read_text()


def nat_vector(text, name):
    m = re.search(rf"def {name} : Fin \d+ → [^:]+:= !\[([0-9,\s]+)\]", text)
    require(m is not None, f"cannot parse {name}")
    return [int(x) for x in m.group(1).split(",")]


def div(a, b):
    """Lean's rational division: x / 0 = 0."""
    return Q(0) if b == 0 else Q(a) / Q(b)


def sqrt_up(x, bits=200):
    """Upper rational bound on sqrt(x) with denominator 2^bits."""
    x = Q(x)
    require(x >= 0, "negative square root argument")
    scale = 1 << bits
    a = x.numerator * scale * scale
    k = isqrt(a // x.denominator)
    while k * k * x.denominator < a:
        k += 1
    return Q(k, scale)


# ====================================================================== highRows
def lean_geometry():
    span = lean("TrialMassSplineSpan180.lean")
    require("def sample (j : Nat) : ℚ := ((j:ℚ)+39/2)*(1399373467/172031279104000)" in span,
            "MassSplineSpan.sample changed")
    body = span.split("private def records", 1)[1].split("\n\n", 1)[0]
    records = [(int(a), int(b)) for a, b in re.findall(r"#\[(\d+),(\d+)\]", body)]
    census = lean("TrialHighPanelCensus180.lean")
    for line in ("def first (a b : Band) := max 102994 (lowerIndex a + lowerIndex b)",
                 "def start (a b : Band) (d : Block) := first a b + d.val*4096",
                 "def last (a b : Band) (d : Block) := min (start a b d+4095) (radius b)",
                 "def lo (a b : Band) (d : Block) (s : Span) : ℚ := max (sample (start a b d)) (knot s.val)",
                 "def hi (a b : Band) (d : Block) (s : Span) : ℚ := min (sample (last a b d)) (knot (s.val+1))"):
        require(line in census, f"HighPanelCensus changed: {line}")
    support = lean("TrialHighPanelSupport180.lean")
    radius, lower = nat_vector(support, "radius"), nat_vector(support, "lowerIndex")
    coeffs = lean("TrialHighPanelCoefficients180.lean")
    require("(x-knot i)*atPoint s x d i/(knot (i+d+1)-knot i) +" in coeffs and
            "(knot (i+d+2)-x)*atPoint s x d (i+1)/(knot (i+d+2)-knot (i+1))" in coeffs,
            "HighPanelCoefficients.atPoint changed")
    controls = lean("TrialHighSplineControls180.lean")
    require("let u := 27*b-8*a-d" in controls and "let v := 27*c-a-8*d" in controls and
            "![a,(2*u-v)/18,(2*v-u)/18,d]" in controls, "HighSplineControls.four changed")
    linear = lean("TrialHighLinearControls180.lean")
    require("four (atPoint s a 3 k) (atPoint s (a+(b-a)/3) 3 k)" in linear and
            "(atPoint s (a+2*(b-a)/3) 3 k) (atPoint s b 3 k) i" in linear and
            "abbrev active (s k : ℕ) := k ≤ s ∧ s ≤ k+3" in linear, "HighLinearControls.basisControl changed")
    cached = lean("TrialHighCachedControl180.lean")
    require("⟨min (s.val-3+k.val) 29,by omega⟩" in cached, "HighCachedControl.knotIndex changed")
    return records, radius, lower


def make_basis(records, radius, lower):
    def knot(i):
        if i >= len(records):
            return Q(0)
        n, d = records[i]
        return div(n, d)

    def sample(j):
        return (Q(j) + Q(39, 2)) * Q(1399373467, 172031279104000)

    def at_point(s, x, d, i):
        if d == 0:
            return Q(int(i == s))
        d -= 1
        return (div((x - knot(i)) * at_point(s, x, d, i), knot(i + d + 1) - knot(i)) +
                div((knot(i + d + 2) - x) * at_point(s, x, d, i + 1), knot(i + d + 2) - knot(i + 1)))

    def four(a, b, c, d):
        u, v = 27 * b - 8 * a - d, 27 * c - a - 8 * d
        return [a, (2 * u - v) / 18, (2 * v - u) / 18, d]

    def basis_control(s, k, a, b):
        if not (k <= s <= k + 3):
            return [Q(0)] * 4
        return four(at_point(s, a, 3, k), at_point(s, a + (b - a) / 3, 3, k),
                    at_point(s, a + 2 * (b - a) / 3, 3, k), at_point(s, b, 3, k))

    def ends(a, b, d, s):
        first = max(102994, lower[a] + lower[b])
        start = first + d * 4096
        last = min(start + 4095, radius[b])
        return max(sample(start), knot(s)), min(sample(last), knot(s + 1))

    def basis(a, b, d, s):
        left, right = ends(a, b, d, s)
        return [basis_control(s, min(s - 3 + k, 29), left, right) for k in range(4)]

    return basis


def radial_rows_mine(frozen, cap_class, signatures):
    coeff, suffix = frozen["coeff"], frozen["suffix"]

    def rows(upper_band, span):
        c = cap_class[upper_band]
        out = []
        for k in range(4):
            knot_row = min(span - 3 + k, 29)
            row = []
            for p in range(99):
                a3, b3, sig = p // 33, (p // 11) % 3, p % 11
                pair = 3 * a3 + b3
                word = sum(coeff[((pair * 3 + l) * 11 + sig) * 30 + knot_row]
                           for l in range(3) if suffix[c] <= l)
                sg = signatures[sig]
                row.append(39 ** (sum(sg) - len(sg)) * word)
            out.append(row)
        return out
    return rows


def method_mine(code, n, d):
    def center(i):
        if code == 1:
            return 1
        if code == 2:
            return 4 if i == 0 else 0
        return 4 if i == 3 else 0
    if code == 0:
        return [[int(i == j) for j in range(4)] for i in range(4)], 1
    words = [[(n + d) * (n * center(i) * center(j) + d * (16 * int(i == j) - 8 * center(j) + 4 * center(i) * center(j)))
              for j in range(4)] for i in range(4)]
    return words, 16 * n * d


def check_high_rows():
    import high_rows_data as H

    report = {}
    # ---- pinned inputs
    compact = json.loads((HERE / "high_compact_gram_verification.json").read_text())
    integer = json.loads((HERE / "high_mass_integer_payments.json").read_text())
    book = STAGE / "high-tail-book.json"
    words = STAGE / "high-compact-gram-words.json"
    units_file = STAGE / "high-panel-units.json"
    sched_file = HERE / "high_mass_panel_schedule.json"
    require(digest(book) == compact["input_sha256"] == integer["input_sha256"], "tail book hash")
    require(digest(sched_file) == compact["schedule_sha256"] == integer["schedule_sha256"], "schedule hash")
    payments = json.loads(units_file.read_text())
    canon = json.dumps(payments, separators=(",", ":")).encode()
    require(sha256(canon).hexdigest() == compact["panel_bounds_sha256"] == integer["panel_bounds_sha256"],
            "panel units hash")
    raw_words = words.read_bytes()
    require(sha256(raw_words.rstrip(b"\n")).hexdigest() == compact["compact_gram_words_sha256"],
            "compact Gram words hash")
    report["inputs_sha256"] = {
        "high_rows/high-tail-book.json": digest(book),
        "high_mass_panel_schedule.json": digest(sched_file),
        "high_rows/high-compact-gram-words.json": digest(words),
        "frozen_band_tables.json": digest(LEAN / "frozen_band_tables.json"),
        "TrialHighPanelSchedule180.lean": digest(lean_path("TrialHighPanelSchedule180.lean")),
        "TrialHighPanelTiltBook180.lean": digest(lean_path("TrialHighPanelTiltBook180.lean")),
        "TrialHighScheduledComparison180.lean": digest(lean_path("TrialHighScheduledComparison180.lean")),
        "high_rows_data.py": digest(HERE / "high_rows_data.py"),
    }

    # ---- the Lean statement being certified
    comp = lean("TrialHighScheduledComparison180.lean")
    for line in ("let dot := (l:ℤ)*subtotal C W L false+(h:ℤ)*subtotal C W U true",
                 "dot*(2^320:ℤ)*10^94 ≤ ((fee i).units:ℤ)*",
                 "(controlDen d*controlDen d*methodDen i*scale*symmetry (lowerBand i) (upperBand i):ℕ)*tilt i*446",
                 "def controlDen (d : ℕ) := storedDenominator*d"):
        require(line in comp, f"HighScheduledComparison.comparison changed: {line}")
    require("def scale : ℕ := 2^(224*39)" in lean("TrialHighGroupedPayment180.lean"), "scale changed")
    require("def factor (K : Tag→ℕ→ℕ) (shift : ℕ) := (K 0 0)^29*2^shift" in lean("TrialHighRoundedPair180.lean"),
            "HighRoundedPair.factor changed")

    # ---- schedule parity: Lean rows vs archived Python rows
    lean_rows = H.schedule()
    tilts = H.tilt_book()
    py_rows = json.loads(sched_file.read_text())
    require(len(lean_rows) == len(py_rows) == len(payments) == 444, "row count")
    for i, (L, P, U) in enumerate(zip(lean_rows, py_rows, payments)):
        a, b, d, s, tilt, code, qn, qd, units = L
        rate_index, stop, _ = tilts[tilt]
        require((b, a) == (P[0], P[1]) and stop == P[3] and H.RATES[rate_index] == P[4], f"row {i} geometry parity")
        # P[8] is the original four-tilt certificate; Lean pays the smaller exact integer units U[4].
        require(code == P[5] + 1 and (qn, qd) == (P[6], P[7]) and units == U[4] <= P[8], f"row {i} method/units parity")
        require(qn > 0 and qd > 0, f"row {i} Young parameter")
    bands = lean("TrialHighMassBands180.lean")
    allowance = sum(nat_vector(bands, "units"))
    cap_class = nat_vector(bands, "capClass")
    total = sum(r[8] for r in lean_rows)
    require(total == compact["total_units"] == integer["total_units"], "total units")
    require(allowance == compact["allowed_units"] == 8732065023 and total <= allowance, "allowance")

    # ---- independent radial, basis and method words; exact comparison
    frozen = json.loads((LEAN / "frozen_band_tables.json").read_text())
    require(frozen["coeffDen"] == H.STORED_DEN, "stored coefficient denominator")
    sig_text = lean("TrialFrozenProfile180.lean")
    m = re.search(r"def signatures : Fin 11 → List ℕ := !\[(.*)\]\n", sig_text)
    signatures = [tuple(int(x) for x in re.findall(r"\d+", g)) for g in re.findall(r"\[([0-9,]*)\]", m.group(1))]
    require(len(signatures) == 11 and tuple(signatures) == H.SIGS, "signatures")
    radial = radial_rows_mine(frozen, cap_class, signatures)
    basis = make_basis(*lean_geometry())
    tightest, slacks = None, []
    for i in range(444):
        a, b, d, s, tilt, code, qn, qd, units = lean_rows[i]
        r = H.row(i)
        require(radial(b, s) == r["R"], f"row {i}: radial words differ from HighLinearControlWords.signedRow")
        mine = basis(a, b, d, s)
        require(all(mine[k][j] == Q(r["B"][k][j], r["bden"]) for k in range(4) for j in range(4)) and r["bden"] > 0,
                f"row {i}: basis words differ from HighLinearControls.basisControl")
        Z, mden = method_mine(code, qn, qd)
        require(Z == r["Z"] and mden == r["mden"], f"row {i}: method words differ from HighMethodWords")
        rhs = units * ((H.STORED_DEN * r["bden"]) ** 2 * mden * 2 ** (224 * 39) * (2 if a == b else 1)) \
            * tilts[tilt][2] * 446
        require(rhs == r["rhs"], f"row {i}: right side")
        require(r["lhs"] <= rhs, f"row {i}: comparison fails")
        slack = Q(rhs - r["lhs"], rhs)
        slacks.append(slack)
        if tightest is None or slack < tightest[1]:
            tightest = (i, slack)
    report.update(rows=444, total_units=total, allowed_units=allowance,
                  aggregate_margin=float(Q(allowance - total, allowance)),
                  tightest_row=tightest[0], tightest_relative_slack=float(tightest[1]),
                  rows_with_relative_slack_below_1e_6=sum(x < Q(1, 10**6) for x in slacks),
                  rate_band_pairs=len({H.triple(i) for i in range(444)}))
    return report


# ====================================================================== images
LEAN_FLOOR = Q("94.17312")
FIELD = Q("0.00000024726961")
SWAP = Q("0.0000000005881")
BASE = Q("46.1984860121")
LOW_TICKS, HIGH_TICKS = 1375543, 206889941
LOW_WORKER, HIGH_WORKER = 1196124, 179904296   # CertifiedBudget.LowImage/HighImage.worker
LAMBDA_IMAGE = Q(1, 10)                         # CertifiedBudget.lowImage/highImage


def certified_guard():
    text = lean("TrialCertifiedBudget180.lean")
    for line in ("  region : RestorationOuterEnergy.lowRegion ⊆ E",
                 "  transfer : ∫ x in E, (RestorationField.field x - G x)^2 ∂prod 39 ≤\n"
                 "    (0.00000024726961 + 0.0000000005881:ℝ)^2 * originalMass",
                 f"  worker : ∫ x in E, (G x)^2 ∂prod 39 ≤ RestorationRows.ticks {LOW_WORKER} * originalMass",
                 "  region : RestorationOuterEnergy.highRegion ⊆ E",
                 "  transfer : ∫ X in E, (RestorationField.field (RemovedHighMass.bands X) - G (RemovedHighMass.bands X))^2\n"
                 "      ∂(RemovedHighMass.law) ≤ (0.00000024726961:ℝ)^2 * originalMass",
                 "  worker : ∫ X in E, (G (RemovedHighMass.bands X))^2 ∂(RemovedHighMass.law) ≤\n"
                 f"    RestorationRows.ticks {HIGH_WORKER} * originalMass",
                 "split ((prod 39).restrict E) RestorationField.field_reg c.regular (l := 1/10) (by norm_num)",
                 "split (RemovedHighMass.law.restrict E) fb gb (l := 1/10) (by norm_num)"):
        require(line in text, f"CertifiedBudget image statement changed: {line.splitlines()[0]}")
    gap = lean("TrialReceiptGap180.lean")
    for line in ("lowImage : ∃ (G : SignedErasure.Full → ℝ) (E : Set SignedErasure.Full), CertifiedBudget.LowImage G E",
                 "highImage : ∃ (G : SignedErasure.Full → ℝ) (E : Set RemovedHighMass.Config), CertifiedBudget.HighImage G E"):
        require(line in gap, f"ReceiptGap.Numerical image field changed: {line}")


def q_float(x):
    """Exact rational value of a JSON number or numeric string."""
    return Q(x) if isinstance(x, str) else Q(float(x))


def check_images():
    report = {}
    certified_guard()
    progress = json.loads((ARCHIVE / "middle_restoration_progress.json").read_text())
    pins = progress["input_sha256"]
    names = ("localized_operator", "joint_margin", "localized_low_singles", "localized_low_pair",
             "high_tag_ledger", "endpoint_symmetry", "bottom_angular_norm", "cap_law_transfer")
    data = {}
    for n in names:
        path = ARCHIVE / f"{n}.json"
        require(digest(path) == pins[PREFIX + path.name], f"{path.name} differs from the pinned ledger input")
        data[n] = json.loads(path.read_text())
    report["inputs_sha256"] = {f"{n}.json": pins[f"{PREFIX}{n}.json"] for n in names}
    report["inputs_sha256"]["middle_restoration_progress.json"] = digest(
        ARCHIVE / "middle_restoration_progress.json")
    lean_slack = lean("TrialSlackBudget180.lean")
    require(f"imageSq 0 ≤ RestorationRows.ticks {LOW_TICKS} * originalMass" in lean_slack and
            f"imageSq 23 ≤ RestorationRows.ticks {HIGH_TICKS} * originalMass" in lean_slack, "Lean constants changed")
    require("noncomputable def ticks (n : ℕ) : ℝ := n / 10^12" in lean("TrialRestorationRows180.lean"), "ticks changed")
    require("(94.17312:ℝ) ≤ 100^39 * originalMass" in lean("TrialReceiptGap180.lean"), "Lean floor changed")

    # ---- shared transfer constants
    op = data["localized_operator"]
    require(Q(op["relative_image_norm_error_upper"]) <= FIELD, "FIELD")
    chi = Q(op["true_single_site_chi_upper"])
    anti = Q(data["endpoint_symmetry"]["norm_of_F_minus_swapped_F_over_norm_of_F_upper"])
    require((Q("0.28") + Q("0.28") * chi) * anti <= SWAP, "SWAP")
    single, pair_norm = Q(op["single_error_over_chi_upper"]), Q(op["pair_bare_norm_upper"])
    require((single + pair_norm * (2 + chi)) * chi <= FIELD, "FIELD composition")

    # ---- low: first two edges (conditional probability times spectral ceiling squared)
    p12 = Q(op["first_probability_upper"]) + Q(op["second_probability_upper"])
    cfirst = Q(data["joint_margin"]["two_low_edge_localized_charge_upper"])
    require(cfirst >= p12 * Q("2.314") ** 2, "first-two-edge charge below p*(2.314)^2")
    # ---- low: 12 Chernoff edges, singles and pair
    ls, lp = data["localized_low_singles"], data["localized_low_pair"]
    require(ls["case_count"] == 108 and len(ls["cases"]) == 108, "low singles cases")
    core_frac, a_frac = Q(ls["upper_fractions"]["core"]), Q(ls["upper_fractions"]["a"])
    sums = {r: sum(q_float(c[r]["fraction_over_norm_floor"]) for c in ls["cases"].values()) for r in ("core", "a")}
    require(sums["core"] <= core_frac and sums["a"] <= a_frac, "low singles case sum exceeds upper_fractions")
    rms = 37 * sqrt_up(core_frac) + 2 * sqrt_up(a_frac)
    require(rms <= q_float(ls["two_singles_combined_rms_before_endpoint_symmetry"]) * (1 + Q(1, 10**12)),
            "low singles rms")
    rms = max(rms, q_float(ls["two_singles_combined_rms_before_endpoint_symmetry"]))
    pair_frac = q_float(lp["fraction_upper"])
    pair_sum = sum(q_float(v) for row in lp["cases"].values() for v in row.values())
    require(pair_sum <= pair_frac * (1 + Q(1, 10**12)), "low pair case sum exceeds fraction_upper")
    low_norm = (rms + sqrt_up(pair_frac)) * sqrt_up(BASE / LEAN_FLOOR)
    clow = cfirst + (low_norm + FIELD + SWAP) ** 2
    lean_low = Q(LOW_TICKS, 10**12)
    require(clow <= lean_low, f"lowImage: {float(clow)} > {float(lean_low)}")
    # CertifiedBudget.LowImage.worker: the tabulated part alone, at the Lean floor.
    glow = cfirst + low_norm ** 2
    require(glow <= Q(LOW_WORKER, 10**12), f"LowImage.worker: {float(glow)} > {LOW_WORKER} ticks")
    require(FIELD + SWAP == Q("0.00000024726961") + Q("0.0000000005881"), "LowImage.transfer constant")
    blow = (1 + LAMBDA_IMAGE) * Q(LOW_WORKER, 10**12) + (1 + 1 / LAMBDA_IMAGE) * (FIELD + SWAP) ** 2
    require(blow <= lean_low, "CertifiedBudget.low_key")
    worker_low = Q(progress["fixed_groups"]["low"]["squared_image_upper"])
    report["lowImage"] = dict(first_two_edges=float(cfirst), twelve_edge_norm_lean_floor=float(low_norm),
                              rederived=float(clow), worker_receipt=float(worker_low),
                              certified_worker_part=float(glow), certified_worker_ticks=LOW_WORKER,
                              bridge_bound=float(blow), bridge_margin=float(1 - blow / lean_low),
                              lean_constant=float(lean_low), margin=float(1 - clow / lean_low),
                              transfer_share_of_rederived=float((clow - cfirst - low_norm ** 2) / clow))

    # ---- high: 28 role rows
    hh = data["high_tag_ledger"]
    rows = hh["rows"]
    caps = sorted(hh["summary"]["geometries"])
    require(len(rows) == 28 and all(r["edge"] == 940000 for r in rows), "high rows")
    base = [[Q(0)] * 3 for _ in range(3)]
    pair = Q(0)
    seen = set()
    for row in rows:
        c, m = row["retained"][1], row["bare_count"]
        typ = "pair" if "pair" in row["role_bounds"] else m
        require(c in caps and (c, typ) not in seen, "duplicate high row")
        seen.add((c, typ))
        if typ == "pair":
            pair += q_float(row["role_bounds"]["pair"]["scaled_upper"])
        else:
            require(typ in (0, 1, 2) and (typ != 2 or c == caps[0]), "high bare count")
            for i, role in enumerate(("core", "a", "b")):
                base[m][i] += q_float(row["role_bounds"][role]["scaled_upper"])
    require(seen == {(c, m) for c in caps for m in (0, 1, "pair")} | {(caps[0], 2)}, "high coverage")
    mult = (37, 1, 1)
    regular = sum(n * sqrt_up(x) for n, x in zip(mult, base[0]))
    owners = sqrt_up(sum(n * (2 * x + y) for n, x, y in zip(mult, base[1], base[2])))
    raw = (regular + owners + sqrt_up(pair)) ** 2
    archived_raw = q_float(hh["summary"]["combined_scaled_squared_upper"])
    require(raw <= archived_raw * (1 + Q(1, 10**12)), "high combined raw")
    raw = max(raw, archived_raw)
    chigh = (sqrt_up(raw / LEAN_FLOOR) + FIELD) ** 2
    lean_high = Q(HIGH_TICKS, 10**12)
    require(chigh <= lean_high, f"highImage: {float(chigh)} > {float(lean_high)}")
    # CertifiedBudget.HighImage.worker: the tabulated part alone, at the Lean floor.
    ghigh = raw / LEAN_FLOOR
    require(ghigh <= Q(HIGH_WORKER, 10**12), f"HighImage.worker: {float(ghigh)} > {HIGH_WORKER} ticks")
    bhigh = (1 + LAMBDA_IMAGE) * Q(HIGH_WORKER, 10**12) + (1 + 1 / LAMBDA_IMAGE) * FIELD ** 2
    require(bhigh <= lean_high, "CertifiedBudget.high_key")
    worker_high = Q(progress["fixed_groups"]["high"]["squared_image_upper"])
    report["highImage"] = dict(combined_scaled_squared=float(raw), rederived=float(chigh),
                               worker_receipt=float(worker_high), lean_constant=float(lean_high),
                               certified_worker_part=float(ghigh), certified_worker_ticks=HIGH_WORKER,
                               bridge_bound=float(bhigh), bridge_margin=float(1 - bhigh / lean_high),
                               margin=float(1 - chigh / lean_high),
                               field_share_of_rederived=float(1 - raw / LEAN_FLOOR / chigh))
    return report


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--json", type=Path)
    ap.add_argument("--skip-rows", action="store_true", help="only the two image fields")
    args = ap.parse_args()
    out = {"images": check_images()}
    if not args.skip_rows:
        out["highRows"] = check_high_rows()
    out["status"] = "all checks passed"
    text = json.dumps(out, indent=2)
    if args.json:
        args.json.write_text(text + "\n")
    print(text)


if __name__ == "__main__":
    main()
