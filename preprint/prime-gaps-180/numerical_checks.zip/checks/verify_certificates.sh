#!/usr/bin/env bash
# Run the programs that check the numerical hypothesis ReceiptGap.Numerical of
# PrimeGap180.h1_le_180_of_numerical, and the parameter checks cited in the paper.
# README.md says what each step establishes.
#
#   ./verify_certificates.sh                 # every check in full (about 8 minutes, 6.5 GB of memory); needs PAYLOAD
#   ./verify_certificates.sh --quick         # no bank recomputation and no payload hashing (about 30 s, 0.4 GB);
#                                            # the payload price binding is skipped, and the input check
#                                            # runs with --banks none only if PAYLOAD is set
#   ./verify_certificates.sh --pair-replay   # also regenerate two caps of the exact pair certificate (about 5.5 min, 1.2 GB)
#   ./verify_certificates.sh --list-heavy    # print the computations that are not rerun here, then exit
#
# Environment:
#   PY       Python interpreter (default: python3 on PATH; README.md lists the packages)
#   PAYLOAD  directory of the per-cap computation payload, 3.1 GB. There is no default. Its
#            manifest.json must have SHA-256 6490035124bbfdd43b22e4313e1d67dfeaaf2a592e4ce137895ba0515ad7735a
#   SHARDS   directory of generated TrialSiteShardNNN180.lean files (optional; no default;
#            set it to <build-dir>/generated/historical_site_rows of the Lean build
#            described in ../lean/README.md)
#   WORK     directory for reports (default: a new temporary directory)
#
# The script stops at the first failing step and prints a summary. Steps marked [HEAVY] need
# more than about 10 minutes or 8 GB; none of them runs here.
set -uo pipefail

CHECKS="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LEAN="$CHECKS/../lean/proof"
cd "$CHECKS/proof"
PY="${PY:-$(command -v python3)}"
PAYLOAD="${PAYLOAD:-}"
SHARDS="${SHARDS:-}"
WORK="${WORK:-$(mktemp -d "${TMPDIR:-/tmp}/verify-h1-180.XXXXXX")}"
mkdir -p "$WORK"
export PYTHONDONTWRITEBYTECODE=1

QUICK=0; PAIR=0
for arg in "$@"; do
  case "$arg" in
    --quick) QUICK=1 ;;
    --pair-replay) PAIR=1 ;;
    --list-heavy) LIST=1 ;;
    -h|--help) sed -n '2,23p' "$CHECKS/verify_certificates.sh"; exit 0 ;;
    *) echo "unknown option: $arg" >&2; exit 2 ;;
  esac
done

heavy() {
  cat <<'EOF'
Computations that this script does not rerun (each marked [HEAVY]):

[HEAVY] 256-bit per-cap computations (core, first, last, debits, mass and pair cross-checks).
        970-2,900 s per nonzero cap, about 2.5 GB each; they need PAYLOAD (3.1 GB).
        The program is archived as data/archived/h1_b2_cap_worker.py.
[HEAVY] 160-bit independent run: data/archived/certify_quotient_and_debit.py.
        1,420 s on 37 processes.
[HEAVY] Span mass certificate: ../lean/proof/check_span_mass_dots.py --class C --workspace DIR --output OUT
        for C in 7 8 15 23 26 30 33 34 36. It reuses the 256-bit directed angular intermediates;
        its running time was not recorded.
[HEAVY] Full exact pair replay: ../lean/proof/check_exact_endpoint_pair.py --output OUT (all nine caps).
        The two-cap replay (--pair-replay) takes 320 s and 1.2 GB.
[HEAVY] Middle groups: the 32 Jackson kernel computations, and the 286 single and 286 pair
        computations (data/localized_middle_sweep.py, data/localized_pair_sweep.py).
[HEAVY] Outer images: 108 single and 108 pair low-edge cases, and 28 high-edge role rows.
[HEAVY] Lean build (about 3 hours on 32 cores; about 110 GB of memory with 8 jobs).
        See ../lean/README.md.
EOF
}
if [ "${LIST:-0}" = 1 ]; then heavy; exit 0; fi

NAMES=(); STATES=(); TIMES=()
summary() {
  echo
  echo "== summary (reports in $WORK)"
  local i
  for i in "${!NAMES[@]}"; do
    printf '  %-8s %6ss  %s\n' "${STATES[$i]}" "${TIMES[$i]}" "${NAMES[$i]}"
  done
}

step() {  # step NAME CMD...
  local name="$1"; shift
  local log="$WORK/step$(( ${#NAMES[@]} + 1 )).log"
  echo
  echo "== $name"
  echo "   $*"
  local t0=$(date +%s)
  "$@" >"$log" 2>&1
  local rc=$?
  local dt=$(( $(date +%s) - t0 ))
  NAMES+=("$name"); TIMES+=("$dt")
  if [ $rc -ne 0 ]; then
    STATES+=("FAIL")
    tail -n 30 "$log"
    echo "FAILED: $name (exit $rc, log $log)"
    summary
    exit 1
  fi
  STATES+=("pass")
  tail -n 3 "$log" | sed 's/^/   | /'
}

in_lean() { (cd "$LEAN" && "$@"); }

need_payload() {
  if [ -z "$PAYLOAD" ] || [ ! -f "$PAYLOAD/manifest.json" ]; then
    echo "FAILED: the payload is required for the full run. Set PAYLOAD to its directory (it must" >&2
    echo "        contain manifest.json), or use --quick." >&2
    NAMES+=("payload present"); STATES+=("FAIL"); TIMES+=(0)
    summary
    exit 1
  fi
}

[ -x "$PY" ] || { echo "Python not found at $PY (set PY)" >&2; exit 2; }
[ -f "$LEAN/TrialReceiptGap180.lean" ] || { echo "Lean sources not found at $LEAN (keep checks/ next to lean/)" >&2; exit 2; }

# 1. Role fields: capMass, pair, core, first, last, debitCore/First/Last.
if [ $QUICK = 1 ]; then
  step "roles (certificates and Lean constants)" env -u PAYLOAD "$PY" certify_numerical_roles.py --json "$WORK/roles.json"
else
  need_payload
  step "roles (with payload price binding and bank hashes)" \
    "$PY" certify_numerical_roles.py --payload "$PAYLOAD" --hash-payload --json "$WORK/roles.json"
fi

# 2. Per-cap targets of SlackUncut.target' and the terminal excess.
step "slack uncut targets" "$PY" check_slack_uncut.py

# 3. highRows, lowImage, highImage.
step "high rows and outer images" "$PY" certify_numerical_high.py --json "$WORK/high.json"

# 4. middleRaw, middlePair, middleJoint (with replays of four aggregation steps).
step "middle groups (with aggregation replays)" "$PY" certify_numerical_middle.py --json "$WORK/middle.json"

# 5. Inputs of the per-cap computations against the Lean definitions.
if [ $QUICK = 1 ]; then
  if [ -n "$PAYLOAD" ] && [ -f "$PAYLOAD/manifest.json" ]; then
    step "worker inputs (spline, ranges, grid, prices; no banks)" "$PY" check_worker_inputs.py --payload "$PAYLOAD" --banks none
  else
    echo; echo "== worker inputs: skipped in --quick mode (PAYLOAD is not set)"
  fi
else
  if [ -n "$SHARDS" ] && [ -d "$SHARDS" ]; then
    step "worker inputs, all nine banks, bank hashes, grid shards (about 7 min, 6.5 GB)" \
      "$PY" check_worker_inputs.py --payload "$PAYLOAD" --hash-banks --shards "$SHARDS"
  else
    echo "   note: SHARDS is not set; the generated Lean grid shards are not compared"
    step "worker inputs, all nine banks, bank hashes (about 7 min, 6.5 GB)" \
      "$PY" check_worker_inputs.py --payload "$PAYLOAD" --hash-banks
  fi
fi

# 6. Parameter conditions of the distribution estimates and of the slot selection.
step "distribution routes" "$PY" ../data/check_distribution_routes.py --output "$WORK/distribution_routes.json"
step "distribution routes equal data/distribution_routes.json" cmp "$WORK/distribution_routes.json" ../data/distribution_routes.json
step "slot selection" "$PY" check_slot_selection.py

# 7. Optional: regenerate caps 78116 and 65536 of exact_native_pair.json and compare bit for bit.
if [ $PAIR = 1 ]; then
  mkdir -p "$WORK/pairwork"
  step "exact pair replay, caps 78116 and 65536 (about 5.5 min, 1.2 GB)" \
    in_lean "$PY" check_exact_endpoint_pair.py --output "$WORK/pair_partial.json" --workdir "$WORK/pairwork" --stop-at 65536
  step "compare pair replay with exact_native_pair.json" \
    env -u PAYLOAD "$PY" certify_numerical_roles.py --replay-pair "$WORK/pair_partial.json"
fi

summary
echo
echo "The Lean proof is not checked here; see ../lean/README.md."
echo "Run ./verify_certificates.sh --list-heavy for the computations that are not rerun."
echo "All selected checks passed."
