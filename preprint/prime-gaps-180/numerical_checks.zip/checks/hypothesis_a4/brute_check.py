"""Check four_cycle_scan.py against a direct evaluation of the defining sums at p = 7.

Prints the brute-force and FFT values of |What(h, k)| at one point; they agree to about 1e-12.
Usage: python3 brute_check.py
"""
import cmath

import four_cycle_scan as f

p = 7


def e(x):
    return cmath.exp(2j * cmath.pi * (x % p) / p)


def inv(x):
    return pow(x, p - 2, p)


def kl3(t):
    return sum(e(u + v + t * inv(u * v)) for u in range(1, p) for v in range(1, p)) / p


def corr(A, B):
    return sum(kl3(A * h) * kl3(B * h).conjugate() * e(h) for h in range(1, p))


def K(a, m, n, r1, r2):
    return corr(a * r2 * inv(m * r1 * r1) % p, a * r1 * inv(n * r2 * r2) % p)


a, m, m2, n, n2 = 3, 1, 2, 4, 5
h, k = 2, 3


def W(r1, r2):
    return (K(a, m, n, r1, r2) * K(a, m2, n, r1, r2).conjugate()
            * K(a, m2, n2, r1, r2) * K(a, m, n2, r1, r2).conjugate())


brute = abs(sum(W(r1, r2) * e(h * r1 + k * r2) for r1 in range(1, p) for r2 in range(1, p)))
_, I, C = f.tables(p)
fft = abs(f.four_cycle(p, I, C, a, m, m2, n, n2)[h, k])
print(f"brute {brute:.12f}  fft {fft:.12f}  difference {abs(brute - fft):.2e}")
assert abs(brute - fft) < 1e-8
