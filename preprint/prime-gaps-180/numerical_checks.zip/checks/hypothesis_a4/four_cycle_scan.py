"""Numerical scan of the four-cycle Fourier transform in Proposition 3.1.

Definitions follow PrimeGap182.TypeIII (formal/TypeIIILocal.lean at b77bf175):
  Kl3(t)   = p^-1 sum_{u,v != 0} e_p(u + v + t/(uv))
  Corr(A,B)= sum_{h != 0} Kl3(A h) conj(Kl3(B h)) e_p(h)
  K_mn(r1,r2) = Corr(alpha r2/(m r1^2), alpha r1/(n r2^2))   (zero off the torus)
  W = K_mn conj(K_m'n) K_m'n' conj(K_mn')
  What(h,k) = sum_{r1,r2} W(r1,r2) e_p(h r1 + k r2)

This is evidence, not proof: floating point at small primes. The claim is
|What| <= C p^3 off a set of at most C points, <= C p^3.5 on it, when m != m'
and n != n'. A family of points of size about p^4, or a curve of points of size
about p^3.5, would contradict it.

Usage: python3 four_cycle_scan.py P1 P2 ...   (prints one JSON line per case)
"""
import json
import sys

import numpy as np


def tables(p):
    e = np.exp(2j * np.pi * np.arange(p) / p)
    inv = np.zeros(p, dtype=np.int64)
    inv[1:] = [pow(int(x), p - 2, p) for x in range(1, p)]
    units = np.arange(1, p)
    # Unnormalized Kloosterman sum S(w) = sum_{u != 0} e_p(u + w/u).
    S = np.zeros(p, dtype=complex)
    for w in range(p):
        S[w] = e[(units + w * inv[units]) % p].sum()
    # Kl3(t) = p^-1 sum_{w != 0} S(w) e_p(t/w).
    kl3 = np.zeros(p, dtype=complex)
    for t in range(p):
        kl3[t] = (S[units] * e[(t * inv[units]) % p]).sum() / p
    # X[A, h] = Kl3(A h) for A, h units.
    X = kl3[np.outer(units, units) % p]
    corr = np.zeros((p, p), dtype=complex)
    corr[1:, 1:] = (X * e[units][None, :]) @ X.conj().T
    return e, inv, corr


def four_cycle(p, inv, corr, alpha, m, m2, n, n2):
    r = np.arange(1, p)
    r1, r2 = np.meshgrid(r, r, indexing="ij")

    def K(mm, nn):
        A = alpha * r2 % p * inv[mm * r1 * r1 % p] % p
        B = alpha * r1 % p * inv[nn * r2 * r2 % p] % p
        return corr[A, B]

    W = np.zeros((p, p), dtype=complex)
    W[1:, 1:] = K(m, n) * K(m2, n).conj() * K(m2, n2) * K(m, n2).conj()
    # Positive-sign unnormalized transform: sum W(r) e_p(h r1 + k r2).
    return np.fft.ifft2(W) * p * p


def summary(p, F, label):
    a = np.abs(F).ravel()
    order = np.argsort(a)[::-1]
    top = a[order[:12]]
    pts = [divmod(int(i), p) for i in order[:6]]
    return dict(
        p=p, case=label,
        origin_over_p3=round(float(abs(F[0, 0]) / p**3), 3),
        top_over_p3=[round(float(x / p**3), 2) for x in top],
        top_over_p35=round(float(top[0] / p**3.5), 3),
        top_over_p4=round(float(top[0] / p**4), 4),
        rms_over_p3=round(float(np.sqrt((a**2).mean()) / p**3), 3),
        count_gt_8rms=int((a > 8 * np.sqrt((a**2).mean())).sum()),
        top_points=pts,
    )


def main():
    rng = np.random.default_rng(20261121)
    for p in map(int, sys.argv[1:]):
        e, inv, corr = tables(p)
        cases = []
        for _ in range(3):
            alpha, m, m2, n, n2 = (int(x) for x in rng.integers(1, p, 5))
            while m2 == m:
                m2 = int(rng.integers(1, p))
            while n2 == n:
                n2 = int(rng.integers(1, p))
            cases.append(("distinct", alpha, m, m2, n, n2))
        # Distinct indices with m/n = m'/n' (opposite entries share a cube root).
        alpha, m, n = (int(x) for x in rng.integers(1, p, 3))
        c = int(rng.integers(2, p))
        cases.append(("distinct-shared-ratio", alpha, m, m * c % p, n, n * c % p))
        # Repeated row index: the origin should be of size p^4.
        alpha, m, n, n2 = (int(x) for x in rng.integers(1, p, 4))
        while n2 == n:
            n2 = int(rng.integers(1, p))
        cases.append(("repeated-row", alpha, m, m, n, n2))
        for label, alpha, m, m2, n, n2 in cases:
            F = four_cycle(p, inv, corr, alpha, m, m2, n, n2)
            out = summary(p, F, label)
            out["params"] = [alpha, m, m2, n, n2]
            print(json.dumps(out), flush=True)


if __name__ == "__main__":
    main()
