"""Fit one-coordinate perturbations and bounded operator residuals on the 38-shift trial."""
import argparse
from fractions import Fraction as Q
from hashlib import sha256
import json
from pathlib import Path
import numpy as np
from h1_harmonic_sector_probe import SectorOperator,fit,forms,sample
from h1_fit_pairing_sectors import uniform_weights
from h1_pairing_sectors import HERE,Sectors,trial_model


class Shapes:
    def __init__(self,op,base):
        self.op,self.base=op,base
        r=op.r
        self.knots=np.log1p(np.array([0,.003,.009,.02,.04,.07,.12,.2,.32,.48,.7,1.1])/.015)
        self.thresholds=[Q(i,1000) for i in (25,50,75,95,115,140,160)]
        physical_step=r.exact_step*r.geometry['parameters']['rho_star']
        self.cuts=[int(z//physical_step) for z in self.thresholds]
        self.rescale=[.01,.04,.12,.4,1.5,5.]
        self.labels=['base','radius','outer_ramp']
        self.labels+=['tile_'+str(i) for i in range(1,len(self.knots))]
        self.labels+=['count_'+str(z) for z in self.thresholds]+['excess_'+str(z) for z in self.thresholds]
        self.labels+=['pairs_'+str(z) for z in self.thresholds[:3]]
        self.labels+=['outer_count_'+str(z) for z in self.thresholds[::2]]
        self.labels+=['residual_'+str(z) for z in self.rescale]+['outer_residual']
        op.caps=np.union1d(op.caps,self.cuts)
        assert op.caps[-1]==op.global_cap
        op.survival=np.array([r.survival(int(c)) for c in op.caps])
        if np.min(np.diff(op.survival,axis=0))<0:raise ValueError('Invalid marked-coordinate survival law')
        op.category_cdf=op.survival/op.survival[-1]

    def __call__(self,idx,cat,F,CF=None):
        op=self.op;r=op.r
        if CF is None:_,CF,_=op.evaluate(idx,cat)
        rate=np.divide(r.rho*CF,F,out=np.zeros_like(F),where=F!=0)-self.base
        t=r.t[idx];q=r.rho*t;total=q.sum(axis=1);outer=np.clip((total-.245)/.03,0,1)
        z=np.log1p(t/.015);ends=self.knots
        j=np.clip(np.searchsorted(ends,z,side='right')-1,0,len(ends)-2)
        u=np.clip((z-ends[j])/(ends[j+1]-ends[j]),0.,1.)
        b=j+len(ends)*np.arange(len(F))[:,None]
        size=len(F)*len(ends)
        hats=(np.bincount(b.ravel(),weights=(1-u).ravel(),minlength=size)+
              np.bincount((b+1).ravel(),weights=u.ravel(),minlength=size)).reshape(len(F),len(ends))
        counts=[];excess=[]
        for c,w in zip(self.cuts,self.thresholds):
            mask=cat>c
            counts.append(mask.sum(axis=1))
            excess.append((mask*np.maximum(q-float(w),0.)).sum(axis=1))
        col=[np.ones(len(F)),total,outer,hats[:,1:],*counts,*excess]
        col.extend(n*(n-1)/2 for n in counts[:3]);col.extend((outer-.5)*n for n in counts[::2])
        col.extend(np.tanh(rate/s) for s in self.rescale);col.append((outer-.5)*np.tanh(rate/.12))
        return np.column_stack(col)


def configured(dual):
    sol=json.loads(dual.read_text());c=json.loads((HERE/sol['source']).read_text())
    P,prior,_,r,limits,dom=trial_model(c['intervals'],c['trial_refit'])
    sec=Sectors(r,dom,[v['radius'] for v in c['sources']],c['max_radius'])
    assert sec.codes==c['codes']
    e=np.array(c['sector_energies']);weights=uniform_weights(e,sol,c['kappa_upper'])
    base=float(np.sum(e*weights))
    assert abs(base-sol['lower'])<1e-7
    vector=np.array(P['best_coefficients']).reshape(len(limits),r.nb)
    op=SectorOperator(r,vector,limits,dom,prior['kappa'],P['rows'][P['best_index']]['hybrid_lambda'])
    op.configure(sec,weights);features=Shapes(op,base);r.clear_cache()
    return op,features,c


def compare(training,test,features):
    G,B=forms(training.mean(0),features.base)
    t,b=forms(test.mean(0),features.base)
    L=features.labels
    groups={'radial':['radius','outer_ramp'],'coordinate':['tile_'],'fragment':['tile_','count_','excess_'],
            'fragment_pairs':['tile_','count_','excess_','pairs_','outer_count_'],
            'residual':['residual_','outer_residual'],'all':L[1:]}
    rows={}
    for key,names in groups.items():
        ix=[0]+[j for j in range(1,len(L)) if any(L[j].startswith(s) for s in names) and G[j,j]>1e-14]
        v=fit(G,B,ix);scores=[]
        for one in test:
            a,c=forms(one,features.base);scores.append(float(v@c@v/(v@a@v)))
        rows[key]=dict(vector=v.tolist(),score=float(v@b@v/(v@t@v)),scores=scores,
                       descriptive_se=float(np.std(scores,ddof=1)/np.sqrt(len(scores))))
    return rows


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('dual',type=Path)
    p.add_argument('--power',type=int,default=17);p.add_argument('--seed',type=int,default=22501)
    p.add_argument('--runs',type=int,default=6);p.add_argument('--tilt',type=float,default=15.)
    p.add_argument('--training',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    assert a.power>=9 and a.runs>=4
    op,features,c=configured(a.dual)
    runs=[];seeds=list(range(a.seed,a.seed+a.runs))
    for seed in seeds:
        runs.append(sample(op,seed,a.power,a.tilt,features.base,False,features=features))
        print(json.dumps(dict(seed=seed,raw_mass=runs[-1][0,0,0])),flush=True)
    raw=np.array(runs);mid=len(raw)//2
    out=dict(scope='Sampled largest-fragment cap scores at a frozen dual; no integration enclosure or restoration.',
             dual=a.dual.name,dual_sha256=sha256(a.dual.read_bytes()).hexdigest(),base=features.base,
             intervals=op.r.N,labels=features.labels,thresholds=list(map(str,features.thresholds)),cuts=features.cuts,
             seeds=seeds,power=a.power,tilt=a.tilt,raw=raw.tolist(),
             held_out=compare(raw[:mid],raw[mid:],features),reverse=compare(raw[mid:],raw[:mid],features))
    if a.training:
        old=json.loads(a.training.read_text())
        assert old['dual_sha256']==out['dual_sha256'] and old['labels']==out['labels'] and old['cuts']==out['cuts']
        assert not {s+x for s in seeds for x in (0,100000)}&{s+x for s in old['seeds'] for x in (0,100000)}
        out.update(training=a.training.name,training_sha256=sha256(a.training.read_bytes()).hexdigest(),
                   frozen=compare(np.array(old['raw']),raw,features))
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v['score'] for k,v in out.get('frozen',out['held_out']).items()}))


if __name__=='__main__':main()
