"""Construct adverse finite prime and three-prime Gram matrices at a proposed extra level."""
import argparse
from decimal import Decimal
from fractions import Fraction as Q
from hashlib import sha256
import json
from math import ceil
from pathlib import Path
import sys
import numpy as np
from scipy import sparse
from h1_cross_ladders import apply_permissions
from h1_pairing_sdp import scs
from verify_pairing_envelope import SCALE,quantize,strict_pd


def lower_radii(data):
    codes=np.array(data['codes'])>>(4*len(data['sources']))
    edges=[Q(0),Q(1,5)]+[Q(x,10000) for x in range(2100,2951,50)]
    assert data['intervals']==131072 and Q(str(data['max_radius']))<=Q('.29')
    return np.array([max(Q(0),edges[max(0,i)]-38*Q('.29')/data['intervals']-Q('1e-12')) for i in codes],dtype=object)


def masks(data,level):
    known=np.array(data['prime_mask'],bool)|np.array(data['minorant_mask'],bool)
    lo=lower_radii(data)
    grant=(lo[:,None]+lo[None,:]<=level)|known
    return known,grant


def ladder_mask(data,path,level,outward=False):
    j=json.loads(path.read_text())
    original=path.with_name(j['control']);assert sha256(original.read_bytes()).hexdigest()==j['control_sha256']
    other=json.loads(original.read_text())
    assert Q(j['level'])==level and Q(data['fragment_cap'])<=Q(j['cap'])
    if 'subdivision' in data:
        assert data['ladder_sha256']==sha256(path.read_bytes()).hexdigest()
        key='refined_outward_grant' if outward else 'refined_grant'
        g=np.array([[x=='1' for x in row] for row in data[key]],bool)
        assert np.array_equal(g,g.T)
        return g
    assert all(other[k]==data[k] for k in ('intervals','sources','codes'))
    prefix='outward_' if outward else ''
    g=np.array([[x=='1' for x in row] for row in j[prefix+'mask']],bool)
    assert np.array_equal(g,g.T) and int(np.triu(g).sum())==j[prefix+'pairs']
    return g


def apply_old(data,path):
    if 'band_base' in data:
        from h1_direct_bands import verify
        source=path.with_name(data['band_base'])
        assert sha256(source.read_bytes()).hexdigest()==data['band_base_sha256']
        base=json.loads(source.read_text())
        apply_old(base,path)
        assert all(data[k]==base[k] for k in ('parent_sectors','codes','intervals','cells_sha256','ladder_sha256'))
        assert list(map(lambda x:Q(str(x)),data['physical_upper']))==list(map(lambda x:Q(str(x)),base['physical_upper']))
        assert Q(str(data['fragment_cap']))==Q(str(base['fragment_cap']))
        verify(data,base,source)
        return
    if 'subdivision' not in data:
        apply_permissions(data,path);return
    assert data['old_permissions_sha256']==sha256(path.read_bytes()).hexdigest()
    parent=path.with_name(data['cells'])
    assert data['cells_sha256']==sha256(parent.read_bytes()).hexdigest()
    original=json.loads(parent.read_text());apply_permissions(original,path)
    if 'historical' in data:
        from h1_rectangle_cover import verify_historical
        verify_historical(data,original,path);return
    pr=np.array(data['parent_sectors'])
    for name in ('prime_mask','minorant_mask'):
        assert np.array_equal(np.array(original[name])[np.ix_(pr,pr)],data[name])


def solve(e,cap,known,grant,d,seconds,extra_budget,shared=None):
    n=len(e);i,j=np.triu_indices(n);l=len(i);scale=np.where(i==j,1.,np.sqrt(2.))
    pack=lambda x:x[i,j]*scale
    def unpack(v):
        x=np.zeros((n,n));x[i,j]=v/scale;x[j,i]=x[i,j];return x
    eye=sparse.eye(l,format='csc');z=sparse.csc_matrix((l,l))
    p=sparse.hstack([eye,z],format='csr');h=sparse.hstack([z,eye],format='csr')
    k=known[i,j];g=grant[i,j];diag=(i==j).astype(float)
    # Scale H by its mean d, so the diagonal fallback is (P,H/d)=(I,I).
    rows=[p[k],(p-d*h)[g],-p,p,-h,h]
    b=np.r_[diag[k],(1-d)*diag[g],np.zeros(l),pack(np.diag(cap)),np.zeros(l),extra_budget[i]/d*diag]
    if shared is not None:
        rows.append(p+(d/2)*h);b=np.r_[b,shared[i]*diag]
    A=sparse.vstack(rows,format='csc')
    w=np.sqrt(e);obj=np.r_[pack(np.outer(w,w)),np.zeros(l)]
    sol=scs.solve(dict(A=A,b=b,c=obj),dict(z=int(k.sum()+g.sum()),s=[n]*(4+int(shared is not None))),
                  eps_abs=5e-7,eps_rel=5e-7,max_iters=100000,time_limit_secs=seconds,verbose=False)
    return unpack(sol['x'][:l]),d*unpack(sol['x'][l:]),sol['info']['status']


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('control',type=Path);p.add_argument('permissions',type=Path)
    p.add_argument('--level',default='.5291');p.add_argument('--deficit',default='.2308')
    p.add_argument('--seconds',type=int,default=70);p.add_argument('--global-grant',action='store_true')
    p.add_argument('--ladder-receipt',type=Path);p.add_argument('--any-subcell',action='store_true');p.add_argument('--check',action='store_true')
    p.add_argument('--local-budgets',type=Path,help='Use certified lower radial edges of the single-prime marking kernel.')
    p.add_argument('--shared-roughness',action='store_true',help='Also require the shared Selberg upper budgets for the mutually disjoint prime and composite supports.')
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    data=json.loads(a.control.read_text(),parse_float=Decimal);apply_old(data,a.permissions)
    known,grant=masks(data,Q(a.level))
    if a.global_grant:grant[:]=True
    if a.ladder_receipt:
        assert not a.global_grant
        grant=ladder_mask(data,a.ladder_receipt,Q(a.level),a.any_subcell)
    raw=np.array([[Q(x) for x in row] for row in data['sector_energies']],dtype=object)
    # Only combine identical permission rows. The matrix is lifted to each
    # individual sector as the identity on its orthogonal complements.
    # Tiny negative quadrature entries are removed and reported explicitly.
    keep=raw[:,0]>0;ids=np.flatnonzero(keep);omitted=np.flatnonzero(~keep)
    raw_keep=raw[ids];known=known[np.ix_(ids,ids)];grant=grant[np.ix_(ids,ids)]
    fixed=known.all(axis=1);fc=sum(raw_keep[fixed,0]);ix=np.flatnonzero(~fixed)
    known=known[np.ix_(ix,ix)];grant=grant[np.ix_(ix,ix)]
    _,labels=np.unique(np.column_stack([known,grant]),axis=0,return_inverse=True)
    groups=[np.flatnonzero(labels==t) for t in range(labels.max()+1)]
    representatives=[g[0] for g in groups];k=known[np.ix_(representatives,representatives)];g=grant[np.ix_(representatives,representatives)]
    E=np.array([sum(raw_keep[ix[group],0]) for group in groups],dtype=object)
    # Use the least upper budget among the constituents, for the lifted witness.
    U=np.array([min(raw_keep[ix[group],1]/raw_keep[ix[group],0]) for group in groups],dtype=object)
    assert np.all(raw_keep[:,1]>=raw_keep[:,0]) and np.all(raw_keep[:,2]>=Q('.000093307088324062')*raw_keep[:,0])
    d=Q(a.deficit)
    n=len(E)
    caps=np.full(n,Q('1.45'),dtype=object)
    shared=None
    if a.shared_roughness:assert a.local_budgets
    if a.local_budgets:
        sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'sensitivity'))
        from bilinear_minorant import kernel
        j=next(x for x in json.loads(a.local_budgets.read_text())['rows'] if Q(x['theta'])==Q(a.level))
        assert d<=Q(j['three_mass']['lower_millionths'],10**6)<=Q(j['three_mass']['upper_millionths'],10**6)<d+Q('.01')
        lo=lower_radii(data)
        safe={q:Q(kernel(Q(j['zeta']),Q(j['a']),q,bins=128)[0],10**12)-Q('.01') for q in set(lo)}
        caps=np.array([min(safe[lo[t]] for t in ids[ix[group]]) for group in groups],dtype=object)
        # A root's diagonal prime budget is >=1/(1/2-q_lower) throughout the cell.
        U=np.array([min(1/(Q(1,2)-lo[t]) for t in ids[ix[group]]) for group in groups],dtype=object)
        if a.shared_roughness:
            zeta=Q(j['zeta']);rough=Q(j['rough']);five=Q(j['five_mass']['upper'])
            shift=Q(j['three_mass']['upper_millionths'],10**6)-d
            def budget(t):
                root=Q(1,2)-lo[t]
                return min(1/min(zeta,root),1/min(rough,root)-five/24)-shift/2
            shared=np.array([min(budget(t) for t in ids[ix[group]]) for group in groups],dtype=object)
            assert min(shared)>1+d/2
            assert max(U)+Q('.000093307088324062')/24<=1/Q('.17278')
    rat=lambda x:np.array([[Q(int(v),SCALE) for v in row] for row in quantize(x)],dtype=object)
    if a.check:
        record=json.loads(a.output.read_text());P,H=[np.array(record[k],dtype=object)*Q(1,SCALE) for k in ('primal_prime','primal_extra')]
        assert record['level']==a.level and record['global_grant']==a.global_grant and Q(record['deficit'])==d
        assert record['source_sha256']==sha256(a.control.read_bytes()).hexdigest() and record['permissions_sha256']==sha256(a.permissions.read_bytes()).hexdigest()
        assert record.get('ladder_sha256')==(sha256(a.ladder_receipt.read_bytes()).hexdigest() if a.ladder_receipt else None)
        assert record.get('any_subcell',False)==a.any_subcell
        assert record.get('shared_roughness',False)==a.shared_roughness
        assert record.get('local_budget_sha256')==(sha256(a.local_budgets.read_bytes()).hexdigest() if a.local_budgets else None)
    else:
        joint=None if shared is None else shared.astype(float)
        P,H,status=solve(E.astype(float),U.astype(float),k,g,float(d),a.seconds,caps.astype(float),joint);P,H=rat(P),rat(H)
    I=np.diag(np.full(n,Q(1),dtype=object))
    P[k]=I[k];H[g]=(P-(1-d)*I)[g]
    blend=Q(record['blend']) if a.check else Q(1,10**7)
    while blend<1:
        X=(1-blend)*P+blend*I;Y=(1-blend)*H+blend*d*I
        checks=[X,np.diag(U)-X,Y,np.diag(caps)-Y]
        if shared is not None:checks.append(np.diag(shared)-X-Y/2)
        if all(strict_pd(m) for m in checks):break
        if a.check:raise ArithmeticError('Archived PSD witness failed')
        blend*=4
    else:raise ArithmeticError('Could not certify an adverse model')
    assert np.all(X[k]==I[k]) and np.all((X-Y)[g]==(1-d)*I[g])
    # Round sqrt(E) only for evaluating the cost. Bound the resulting error
    # via ||X|| <= max U and an outward bound on each Euclidean norm.
    from math import isqrt
    unit=10**16;v=np.array([Q(isqrt(int(x*unit**2)),unit) for x in E],dtype=object)
    err=max(U)*(2*sum(v)*n/unit+Q(n*n,unit**2))
    score=fc+v@X@v+err
    if a.check:
        assert ceil(score*10**9)==record['upper_billionths']
        print('Verified',n,record['upper_billionths']);return
    digest=lambda f:sha256(f.read_bytes()).hexdigest()
    out=dict(scope='Exact adverse upper for the retained finite sector energies, hypothetical high-level identities, and specified three-prime deficit; no integral enclosure.',
             source=a.control.name,source_sha256=digest(a.control),permissions=a.permissions.name,permissions_sha256=digest(a.permissions),
             level=a.level,global_grant=a.global_grant,deficit=str(d),budget=('local' if a.local_budgets else '29/20'),solver_status=status,
             groups=[[int(ids[ix[j]]) for j in group] for group in groups],fixed=ids[fixed].tolist(),omitted=omitted.tolist(),
             omitted_abs_energy=str(sum(abs(raw[omitted,0]))),known_pairs=int(np.triu(k).sum()),higher_pairs=int(np.triu(g).sum()),
             blend=str(blend),scale=SCALE,primal_prime=quantize(P).tolist(),primal_extra=quantize(H).tolist(),
             upper_billionths=ceil(score*10**9),rounding_allowance=str(err))
    if a.ladder_receipt:out.update(ladder=a.ladder_receipt.name,ladder_sha256=digest(a.ladder_receipt),any_subcell=a.any_subcell)
    if a.local_budgets:out.update(local_budget_sha256=digest(a.local_budgets),group_extra_budgets=list(map(str,caps)))
    if shared is not None:out.update(shared_roughness=True,group_shared_budgets=list(map(str,shared)))
    a.output.write_text(json.dumps(out,indent=2)+'\n');print(len(E),status,out['upper_billionths'])


if __name__=='__main__':main()
