"""Exact scalar ledger on the disjoint highest-failure groups of the frozen 180 trial."""
import argparse
from fractions import Fraction as Q
from hashlib import sha256
import json
from math import isqrt
from pathlib import Path

HERE=Path(__file__).resolve().parent
MIDDLE=tuple(range(90000,940000,40000))
CAPS=(9764,19529,29293,39058,46567,47096,58332,60089,61104,63177,64599,65536,78116)
GEOMETRIES=CAPS[4:]
LOW=(300,1000,3000,6000,10000,20000,30000,40000,50000,60000,70000,80000)
BASE=Q('46.1984860121')
PHI=Q('.3135')
ALPHA=1-PHI
UNIFORM=1+PHI
FIELD=Q('.00000024726961')
SWAP=Q('.0000000005881')
SCALE=10**24
NATIVE_PIN='6490035124bbfdd43b22e4313e1d67dfeaaf2a592e4ce137895ba0515ad7735a'
MASS_PIN='c9d947bdea94e048f532d88f88bdb6030b964ba92e6ace3a2b225594b3406229'
MIDDLE_PAIR_FILE='00a01ea5b1d003dce87e2ee5d3d89c1350ffcfaf729ad1cfb9dcc1cdc3b5fc04'


def root(x):
    x=Q(x);assert x>=0
    a=x.numerator*SCALE*SCALE;b=x.denominator;k=isqrt(a//b)
    return Q(k+(k*k*b<a),SCALE)


def value(d,c):
    """Upper on max(2*sqrt(x*c)-ALPHA*x, 0<=x<=d)."""
    assert 0<=d<=1 and c>=0
    return c/ALPHA if c<ALPHA*ALPHA*d else 2*root(d*c)-ALPHA*d


def cost(d,c,b=None):
    uniform=UNIFORM*d+2*root(d*c)
    return uniform if b is None else min(uniform,b+value(d,c))


def positive_debit(d,u,distance):
    return (root(u)+root(Q('.01815'))*(root(d)+distance))**2


def charge_middle(rows,pair,epsilon,joint=None):
    """All values are normalized. A missing pair row uses one global pair bound."""
    no_pair={};with_pair={};missing=set()
    for edge,(d,s,p,b) in rows.items():
        singles_options=[] if s is None else [cost(d,s,b)]
        direct=(joint or {}).get(edge)
        if direct is not None:singles_options.append(direct)
        no_pair[edge]=min(singles_options)
        if p is None:
            missing.add(edge);continue
        both=[] if s is None else [cost(d,(root(s)+root(p))**2,b)]
        if direct is not None:both.append(direct+2*root(d*p))
        with_pair[edge]=min(both)
    # Every enumerated split is valid. With the exact square root the optimal
    # fallback sets are prefixes in decreasing (local extra cost)/d, since
    # 2 sqrt(P*x)=inf_{lambda>0}(lambda*x+P/lambda).
    eligible=sorted((g for g in with_pair if rows[g][0]>0),
                    key=lambda g:(with_pair[g]-no_pair[g])/rows[g][0],reverse=True)
    def evaluate(fallback):
        d=min(Q(1),sum(rows[g][0] for g in fallback));pcharge=2*root(d*pair)
        used={g:(no_pair[g] if g in fallback else with_pair[g]) for g in rows}
        return sum(used.values())+pcharge,pcharge,used
    fallback=set(missing);v,pcharge,groups=evaluate(fallback);best=(v,set(fallback),pcharge,groups)
    for g in eligible:
        fallback.add(g);v,pcharge,groups=evaluate(fallback)
        if v<best[0]:best=(v,set(fallback),pcharge,groups)
    d=min(Q(1),sum(row[0] for row in rows.values()));transfer=2*root(d)*epsilon
    return dict(cost=best[0]+transfer,fallback=sorted(best[1]),pair_cost=best[2],group_cost=best[3],transfer=transfer)


def read(path,hashes):
    path=Path(path);raw=path.read_bytes();fingerprint=sha256(raw).hexdigest();name=path.name
    if name in hashes and hashes[name]!=fingerprint:name=f'{name}@{fingerprint[:16]}'
    hashes[name]=fingerprint
    return json.loads(raw)


def basics(hashes):
    return {name:read(HERE/(''+name+'.json'),hashes) for name in (
        'bottom_angular_norm','joint_margin','direct_cap_transfer','cap_law_transfer','localized_operator',
        'positive_angular','localized_low_singles','localized_low_pair','signed_pair_gram','high_tag_ledger',
        'whole_pair_transfer','endpoint_symmetry')}


def native_receipt(path,hashes):
    if path is None:return None
    from cap_worker import FORMS,combined
    obj=read(path,hashes);caps=obj['caps'];rows=obj['receipts']
    assert len(rows)==len(set(caps))==len(caps)==37 and caps==sorted(caps,reverse=True)
    pin_path=HERE/'cap_workers_manifest.json';manifest=read(pin_path,hashes)
    assert hashes[pin_path.name]==obj['manifest_sha256']==NATIVE_PIN
    assert caps==manifest['caps'] and manifest['core']==37 and manifest['n']==131033
    for name,fingerprint in manifest['source_sha256'].items():assert sha256((HERE/name).read_bytes()).hexdigest()==fingerprint
    assert sha256((HERE/'cap_worker.py').read_bytes()).hexdigest()==manifest['files']['cap_worker.py']
    assert len(obj['compiled_library_sha256'])==64 and all(ch in '0123456789abcdef' for ch in obj['compiled_library_sha256'])
    for i,(c,row) in enumerate(zip(caps,rows,strict=True)):
        assert row['cap']==c and row['prior_cap']==(caps[i-1] if i else None)
        assert row['manifest_sha256']==obj['manifest_sha256'] and row['compiled_library_sha256']==obj['compiled_library_sha256']
        assert row['version']==1 and row['bits']==256 and set(row['forms'])==set(FORMS)
        assert all(Q(l)<=Q(h) for l,h in row['forms'].values())
    known=read(HERE/'cap_worker_native_78116.json',hashes)
    assert known['manifest_sha256']==NATIVE_PIN and known['cap']==rows[0]['cap']==78116
    for k in FORMS:
        a,b=map(Q,known['forms'][k]);c,d=map(Q,rows[0]['forms'][k]);assert max(a,c)<=min(b,d)
    assert rows[1]['cap']==66501 and all(list(map(Q,v))==[0,0] for v in rows[1]['forms'].values())
    numerics=combined([r['forms'] for r in rows])
    assert all(obj[k]==v for k,v in numerics.items())
    return tuple(map(Q,obj['quotient'])),Q(obj['positive_debit'][1]),Q(obj['raw_forms']['full'][0])


def fixed_parts(data,native):
    norm=data['bottom_angular_norm'];floor=Q(norm['continuum_scaled_lower'])
    transfer=data['direct_cap_transfer'];deficit=Q('0.0000000003266')
    assert 0<=Q(transfer['relative_deficit'])<deficit<Q(data['cap_law_transfer']['relative_bin_bound'])
    qlo,qhi=map(Q,data['joint_margin']['native_quotient_hypothesis']);u=Q(data['joint_margin']['native_debit_hypothesis'])
    if native:
        (qlo,qhi),u,mass=native
        last=data['localized_operator'];assert 3*last['first_changed_site_index']>last['last_full_index']
        floor=max(floor,(1-deficit)**2*mass)
    upper=Q(data['joint_margin']['simplex_upper_on_signed_spectrum']);negative=Q('2.314')
    assert 0<qlo<=qhi<=upper and upper-negative<2*qlo and u>=0
    distance=Q(transfer['centered_normalized_distance_upper'])
    loss=Q(transfer['operator_change_upper'])+2*distance*root((upper-qlo)*(qlo+negative))+(negative+qhi)*distance**2
    lo=data['localized_operator'];pa=data['positive_angular'];ls=data['localized_low_singles'];lp=data['localized_low_pair']
    assert list(LOW)==ls['edges'] and tuple(ls['caps'])==GEOMETRIES and ls['case_count']==108
    assert sorted(map(int,lp['cases']))==list(GEOMETRIES) and all(sorted(map(int,v))==list(LOW) for v in lp['cases'].values())
    assert [z['edge'] for z in pa['edges']]==[100,*LOW] and pa['edges'][-1]['next_edge']==90000
    assert Q(lo['relative_image_norm_error_upper'])<=FIELD
    H=Q(lo['true_single_site_chi_upper']);anti=Q(data['endpoint_symmetry']['norm_of_F_minus_swapped_F_over_norm_of_F_upper'])
    assert (Q('.28')+Q('.28')*H)*anti<=SWAP
    dlow=min(Q(1),Q(lo['first_probability_upper'])+Q(pa['whole_union_raw_upper'])*10**78/floor)
    cfirst=Q(data['joint_margin']['two_low_edge_localized_charge_upper'])
    # These two subsets are disjoint by the threshold of the highest failure.
    low_norm=(Q(ls['two_singles_combined_rms_before_endpoint_symmetry'])+root(Q(lp['fraction_upper'])))*root(BASE/floor)
    clow=cfirst+(low_norm+FIELD+SWAP)**2
    ph=data['signed_pair_gram'];hh=data['high_tag_ledger'];hs=hh['summary']
    assert ph['cutoff']==940000 and Q(ph['ordinary_mass_floor'])*10**78==Q('44.6')
    assert tuple(hs['geometries'])==GEOMETRIES and hs['source_rows']==len(hh['rows'])==28
    ids={(row['retained'][1],'pair' if 'pair' in row['role_bounds'] else row['bare_count']) for row in hh['rows']}
    assert ids=={(g,i) for g in GEOMETRIES for i in (0,1,'pair')}|{(GEOMETRIES[0],2)}
    assert all(row['edge']==940000 for row in hh['rows'])
    dhigh=min(Q(1),Q(ph['total_relative_upper'])*Q('44.6')/floor)
    chigh=min(Q(hs['continuum_fraction_upper_with_field_transfer']),(root(Q(hs['combined_scaled_squared_upper'])/floor)+FIELD)**2)
    pair=Q(data['whole_pair_transfer']['true_squared_norm_over_trial_squared_norm_upper'])
    residual_transfer=Q(transfer['operator_change_upper'])+(negative+qhi)*distance
    return dict(floor=floor,qg=(qlo,qhi),qc=qlo-loss,u=u,distance=distance,residual_transfer=residual_transfer,
                low=(dlow,clow),high=(dhigh,chigh),pair=pair)


def masses(paths,hashes,pointwise=True,audit=False):
    out={}
    for path in paths:
        d=read(path,hashes);manifest=d['source_manifest']
        assert d['baseline_pin']==manifest['pin']==MASS_PIN and d['legacy_extra_gram_radius']=='2^-146'
        raw=json.dumps(manifest['record'],sort_keys=True).encode();assert sha256(raw).hexdigest()==MASS_PIN
        assert {(c,e) for c,e in manifest['pairs']}=={(c,e) for c in CAPS for e in MIDDLE}
        groups=d['groups'];ids=[(z['cap'],z['edge']) for z in groups]
        assert len(set(ids))==len(ids)==d['cases'] and set(ids)<={tuple(v) for v in manifest['pairs']}
        if audit:
            from middle_charge_aggregate import subtotals,upper_decimal,verify
            if len(ids)==d['expected_in_window']:verify(d)
            else:
                # A live aggregate may omit some cases outside the individual
                # edges it has already finished. Reprice all rows that exist.
                lower=dict(zip(CAPS,(0,*CAPS[:-1])))
                witness=subtotals(groups,lower)
                assert d['edge_totals']==[[e,min(e+40000,940000),upper_decimal(x),upper_decimal(y)]
                                        for e,(x,y) in sorted(witness.items())]
        edges=set()
        for e,stop,raw_d,raw_b in d['edge_totals']:
            assert e not in edges and e in MIDDLE and stop==min(e+40000,940000);edges.add(e)
            if {c for c,k in ids if k==e}!=set(CAPS):continue
            a,b=Q(raw_d),Q(raw_b) if raw_b is not None and pointwise else None
            assert a>=0 and (b is None or b>=0)
            # Each group row is rounded upward to 18 places and so is the
            # exact group sum. These two simple independent checks catch
            # understated edge totals or a misplaced cap/group association.
            for field,upper in [('scaled_deleted_upper',a),('scaled_negative_upper',b)]:
                if upper is None:continue
                listed=sum(Q(z[field]) for z in groups if z['edge']==e)
                assert listed-Q(len(CAPS),10**18)<=upper<=listed
            old=out.get(e,(a,b))
            bs=[x for x in (old[1],b) if x is not None];out[e]=(min(old[0],a),min(bs) if bs else None)
        assert edges=={e for _,e in ids}
    return out


def sweeps(paths,role,hashes,floor):
    out={};bare_dirs=[]
    for path in paths:
        if path.is_dir():
            if role=='singles':
                from localized_middle_sweep import ledger
                manifest=read(path/'manifest.json',hashes)
                record={k:v for k,v in manifest.items() if k!='calculation'}
                assert sha256(json.dumps(record,sort_keys=True).encode()).hexdigest()==manifest['calculation']
                doc=ledger(path,manifest,floor)
                if manifest['options']['owner_weight']==0:bare_dirs.append(path)
            else:
                from localized_pair_sweep import collect
                manifest=read(path/'pair-manifest.json',hashes)
                record={k:v for k,v in manifest.items() if k!='pin'}
                assert sha256(json.dumps(record,sort_keys=True).encode()).hexdigest()==manifest['pin']
                doc=collect(path,manifest)
            assert {(c,e) for c,e in manifest['tasks']}=={(c,e) for c in CAPS for e in MIDDLE}
        else:doc=read(path,hashes)
        assert doc['expected']==len(CAPS)*len(MIDDLE)
        rows=doc['by_edge'] if role=='singles' else doc['edges']
        assert set(map(int,rows))==set(MIDDLE)
        count=0
        for g,row in rows.items():
            if role=='singles':
                caps=row['caps'];assert len(caps)==len(set(caps)) and set(caps)<=set(CAPS);n=len(caps)
                assert Q(row['raw_core'])>=0 and Q(row['raw_endpoint'])>=0
            else:n=row['cases'];assert 0<=n<=len(CAPS)
            count+=n;assert row['complete']==(n==len(CAPS))
            if n!=len(CAPS):continue
            raw=Q(row['raw_singles_upper' if role=='singles' else 'raw_upper'])
            assert raw>=0
            edge=int(g);out[edge]=min(out.get(edge,raw),raw)
        assert count==doc['complete']
    if bare_dirs:
        from bare_index_singles import summarize
        bare=summarize(bare_dirs)
        hashes['bare_index_receipts_combined']=sha256(json.dumps(bare['evidence'],sort_keys=True).encode()).hexdigest()
        for edge,row in bare['by_edge'].items():
            if row['complete']:
                v=Q(row['raw_singles_upper']);out[edge]=min(out.get(edge,v),v)
    return out


def residual_target(base,dm,edges,available):
    """Sufficient strict native residual threshold on any union of unpaid middle groups."""
    d=sum(dm[g][0] for g in edges)/base['floor']
    if not 0<d<Q(1,2):return None
    schur=sum(min(2*x,y) if y is not None else 2*x for x,y in (dm[g] for g in edges))/base['floor']
    numerator=available-(2*base['qc']-ALPHA)*d-schur
    if numerator<=0:return None
    ceiling=numerator/(2*root(d*(1-d)))-base['residual_transfer']
    if ceiling<=0:return None
    return dict(edges=sorted(edges),deleted_upper=str(d),schur_upper=str(schur),
                native_residual_norm_strict_threshold=str(ceiling),
                native_second_moment_strict_threshold=str(base['qg'][0]**2+ceiling**2))


def scalar_ledger(base,dm,singles,pairs,joint=None):
    floor=base['floor'];rows={};missing={}
    for e in MIDDLE:
        absent=[]
        if e not in dm:absent.append('deleted mass')
        if e not in singles and e not in (joint or {}):absent.append('single-root image')
        if absent:missing[e]=absent;continue
        d,b=dm[e];p=pairs.get(e)
        rows[e]=min(Q(1),d/floor),singles[e]/floor if e in singles else None,p/floor if p is not None else None,b/floor if b is not None else None
    chosen=charge_middle(rows,base['pair'],FIELD+SWAP,{e:v/floor for e,v in (joint or {}).items()})
    low_d,low_c=base['low'];hi_d,hi_c=base['high']
    fixed=cost(low_d,low_c)+cost(hi_d,hi_c)
    coverage=len(rows)==len(MIDDLE)
    D=min(Q(1),low_d+hi_d+sum(v[0] for v in rows.values()))
    def edge_row(e):
        d,b=dm.get(e,(None,None));s=singles.get(e);p=pairs.get(e)
        row=dict(start=e,stop=min(940000,e+40000),deleted_upper=None if d is None else str(d/floor),
                 weighted_schur_upper=None if b is None else str(b/floor),singles_squared_upper=None if s is None else str(s/floor),
                 pair_squared_upper=None if p is None else str(p/floor),required_inputs_missing=missing.get(e,[]))
        if e in (joint or {}):row['joint_singles_and_schur_upper']=str(joint[e]/floor)
        if e in rows:row.update(cost_upper=str(chosen['group_cost'][e]),pair_source='whole union' if e in chosen['fallback'] else 'local')
        return row
    out=dict(complete_restoration_inputs=coverage,middle_groups_used=len(rows),middle_groups_required=len(MIDDLE),
        middle_deleted_groups_available=sorted(dm),middle_singles_groups_available=sorted(singles),middle_pair_groups_available=sorted(pairs),
        middle=[edge_row(e) for e in MIDDLE],fixed_groups={name:dict(deleted_upper=str(d),squared_image_upper=str(c),cost_upper=str(cost(d,c)))
        for name,(d,c) in [('low',base['low']),('high',base['high'])]},
        known_groups_deleted_upper=str(D),known_groups_restoration_cost_upper=str(fixed+chosen['cost']),
        middle_pair_union_edges=chosen['fallback'],middle_pair_union_cross_upper=str(chosen['pair_cost']),
        middle_field_and_swap_cross_upper=str(chosen['transfer']))
    if set(dm)==set(MIDDLE):
        all_d=min(Q(1),low_d+hi_d+sum(d for d,_ in dm.values())/floor)
        debit=positive_debit(all_d,base['u'],base['distance'])
        allowance=base['qc']-1-fixed-debit
        out.update(all_thresholds_deleted_upper=str(all_d),global_portable_debit_upper=str(debit),
                   middle_cost_allowance_lower=str(allowance),covered_middle_cost_upper=str(chosen['cost']))
        targets=[residual_target(base,dm,set(MIDDLE),allowance)]
        if rows and not coverage:
            targets.append(residual_target(base,dm,set(MIDDLE)-set(rows),allowance-chosen['cost']))
        out['alternative_residual_targets']=[v for v in targets if v is not None]
        if coverage:
            margin=allowance-chosen['cost']
            out.update(restored_excess_lower=str(margin),strictly_positive=margin>0)
    return out


def run(args):
    hashes={};fixed=basics(hashes);native=native_receipt(args.native,hashes);const=fixed_parts(fixed,native)
    dm=masses(args.mass,hashes,not args.uniform_schur,args.audit_mass)
    s=sweeps(args.singles,'singles',hashes,const['floor']);p=sweeps(args.pairs,'pair',hashes,const['floor'])
    if set(dm)==set(MIDDLE)==set(s) and not args.audit_mass and not args.uniform_schur:
        # A final weighted score always checks the pointwise Schur prices
        # against the underlying directed panels, even on partial files.
        assert masses(args.mass,{},True,True)==dm
    joint=None;witnesses={}
    replay_path=getattr(args,'replay_weights',None)
    if getattr(args,'joint_weights',False) or replay_path:
        from cap_share_ledger import joint_uppers
        replay=json.loads(replay_path.read_bytes())['joint_weight_witnesses'] if replay_path else None
        joint=joint_uppers(args.mass,args.singles,args.uniform_schur,witnesses=witnesses,replay=replay)
        if replay is not None:assert set(replay)==set(witnesses)
    for path in args.pairs:
        if path.is_file() and sha256(path.read_bytes()).hexdigest()==MIDDLE_PAIR_FILE:
            middle_pair=json.loads(path.read_bytes())
            const['pair']=min(const['pair'],Q(middle_pair['continuum_squared_upper']))
            break
    out=scalar_ledger(const,dm,s,p,joint);out.update(input_sha256=hashes,continuum_scaled_ordinary_floor=str(const['floor']),
                native_inputs='directed 37-cap receipt' if native else 'conditional thresholds',
                native_quotient=list(map(str,const['qg'])),native_positive_debit_upper=str(const['u']),continuum_quotient_lower=str(const['qc']))
    if joint is not None:out['joint_weight_witnesses']=witnesses
    if out['complete_restoration_inputs'] and native:
        from bare_index_singles import PRODUCTION_PIN
        if any(not path.is_dir() or read(path/'manifest.json',hashes)['calculation']!=PRODUCTION_PIN for path in args.singles):
            raise ValueError('A final score requires the original single-prime receipts from the frozen trial.')
        if any(not path.is_file() or sha256(path.read_bytes()).hexdigest()!=MIDDLE_PAIR_FILE for path in args.pairs):
            raise ValueError('Supply the authenticated middle pair union or omit it to use the whole-domain bound.')
        assert masses(args.mass,{},not args.uniform_schur,True)==dm
    if args.conditional and native:raise ValueError('Select the directed native receipt or the explicit conditional threshold calculation.')
    if args.require_complete and not out['complete_restoration_inputs']:raise ValueError('Full coverage requires 22 complete deleted-mass and localized-single groups.')
    if out['complete_restoration_inputs'] and not native and not args.conditional:
        if args.require_complete:raise ValueError('A complete numerical proof requires --native with the pinned 37 receipts. Use --conditional for a threshold-only result.')
        out.pop('restored_excess_lower');out.pop('strictly_positive')
        out['global_score_status']='Awaiting a pinned native receipt or explicit conditional evaluation.'
    else:
        out['global_score_status']=('certified numerical inputs' if native else 'explicit conditional thresholds') if out['complete_restoration_inputs'] else 'incomplete middle coverage'
    if args.output:args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k in ('native_inputs','complete_restoration_inputs','middle_groups_used',
          'middle_groups_required','middle_deleted_groups_available','middle_singles_groups_available','middle_pair_groups_available',
          'restored_excess_lower','strictly_positive','continuum_scaled_ordinary_floor')}))
    return out


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--mass',nargs='*',type=Path,default=[HERE/'middle_charge_frozen_130k_530k.json'])
    ap.add_argument('--singles',nargs='*',type=Path,default=[]);ap.add_argument('--pairs',nargs='*',type=Path,default=[])
    ap.add_argument('--native',type=Path);ap.add_argument('--output',type=Path);ap.add_argument('--uniform-schur',action='store_true')
    ap.add_argument('--audit-mass',action='store_true');ap.add_argument('--require-complete',action='store_true')
    ap.add_argument('--joint-weights',action='store_true',help='Check cap and erased-radius Young bounds from the complete classes in input directories.')
    ap.add_argument('--replay-weights',type=Path,help='Recompute a saved ledger from its rational weights without running the conic search.')
    ap.add_argument('--conditional',action='store_true',help='Explicitly allow a threshold-only global margin without a directed native receipt.')
    run(ap.parse_args())
