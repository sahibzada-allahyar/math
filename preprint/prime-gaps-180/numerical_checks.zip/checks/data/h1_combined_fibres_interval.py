"""Directed single-coordinate erasures of the fixed combined cell trial.

Assemble exact rational cumulative-cap differences before any integration.
Signed correlations use GMP integer packing, without FLINT polynomials.
Cached arrays are reproducible intermediates; the JSON certificate pins them.
"""
import argparse
from bisect import bisect_right
from collections import defaultdict
from fractions import Fraction as Q
import itertools
import json
import math
from pathlib import Path
import random
import time

import gmpy2
import numpy as np

from h1_combined_mass_interval import CellMoments, P, load_trial, digest
from h1_dickman_taylor import rat, horner
from h1_exact_convolution import convolution, scaled_endpoint


def signed_convolution(a, b):
    """Exact balanced packing, with a proved output coefficient bound."""
    if not a or not b:
        return []
    length = len(a)+len(b)-1
    bound = min(len(a), len(b))*max(map(abs, a))*max(map(abs, b))
    if not bound:
        return [gmpy2.mpz(0)]*length
    bits = int(2*bound).bit_length()
    assert 2*bound < 1 << bits
    def pack(row):
        return (gmpy2.pack([max(0, v) for v in row], bits)-
                gmpy2.pack([max(0, -v) for v in row], bits))
    # Every true output coefficient lies in [-bound,bound]. Adding bound
    # to each digit places it in [0,2*bound], so unpacking has no carries.
    shifted = pack(a)*pack(b)+gmpy2.pack([bound]*length, bits)
    assert shifted >= 0
    out = gmpy2.unpack(shifted, bits)
    out.extend([gmpy2.mpz(0)]*(length-len(out)))
    assert len(out) == length
    return [v-bound for v in out]


def interval_correlation(a, b, bits):
    """Enclose sum_j a[r+j]*b[j] at the same 2^bits scale.

    b is nonnegative. For midpoint/radius pairs A,R and B,S,
    |a*b-A*B| <= |A|*S+R*b_upper, coefficientwise after convolution.
    """
    alo, ahi = a
    blo, bhi = b
    n = len(alo)
    assert n == len(ahi) == len(blo) == len(bhi) and n > 0
    assert all(x <= y for x, y in zip(alo, ahi))
    assert all(0 <= x <= y for x, y in zip(blo, bhi))
    A = [(x+y)//2 for x, y in zip(alo, ahi)]
    R = [max(m-x, y-m) for x, y, m in zip(alo, ahi, A)]
    B = [(x+y)//2 for x, y in zip(blo, bhi)]
    S = [max(m-x, y-m) for x, y, m in zip(blo, bhi, B)]
    middle = signed_convolution(A, list(reversed(B)))[n-1:]
    error1 = convolution(list(map(abs, A)), list(reversed(S)))[n-1:]
    error2 = convolution(R, list(reversed(bhi)))[n-1:]
    assert len(middle) == len(error1) == len(error2) == n
    lo = [(v-x-y) >> bits for v, x, y in zip(middle, error1, error2)]
    hi = [-((-v-x-y) >> bits) for v, x, y in zip(middle, error1, error2)]
    return lo, hi


def binary64_signed(pair, bits):
    def lower(value):
        # Current inputs stay far below the binary64 overflow range.
        value = int(value)
        assert value.bit_length() < 1000
        if value == 0:
            return 0.
        return np.nextafter(math.ldexp(float(value), -bits), -np.inf)
    lo = np.fromiter((lower(x) for x in pair[0]), dtype=float, count=len(pair[0]))
    hi = np.fromiter((-lower(-x) for x in pair[1]), dtype=float, count=len(pair[1]))
    assert np.isfinite(lo).all() and np.isfinite(hi).all() and np.all(lo <= hi)
    return lo, hi


def self_check():
    rng = random.Random(1820381)
    cases = []
    for n in (1, 2, 7, 16, 65):
        for bits in (1, 53, 192, 510):
            cases.append(([rng.getrandbits(bits)*rng.choice((-1, 1)) for _ in range(n)],
                          [rng.getrandbits(bits)*rng.choice((-1, 1)) for _ in range(n+3)]))
    cases += [([0]*4, [1, -1]), ([1, -1]*16, [1, 1]*16)]
    a, b = (1 << 509)-1, (1 << 510)-1
    cases.append(([a]*16, [-b]*16))
    for left, right in cases:
        expected = [0]*(len(left)+len(right)-1)
        for i, x in enumerate(left):
            for j, y in enumerate(right):
                expected[i+j] += x*y
        assert signed_convolution(left, right) == expected
    count = 0
    for n in (1, 2, 7, 16):
        for _ in range(8):
            al = [rng.randrange(-2**40, 2**40) for _ in range(n)]
            ah = [x+rng.randrange(2**36) for x in al]
            bl = [rng.randrange(2**35) for _ in range(n)]
            bh = [x+rng.randrange(2**36) for x in bl]
            low, high = interval_correlation((al, ah), (bl, bh), 32)
            for r in range(n):
                minima, maxima = [], []
                for j in range(n-r):
                    products = [x*y for x in (al[r+j], ah[r+j]) for y in (bl[j], bh[j])]
                    minima.append(min(products)); maxima.append(max(products))
                assert low[r]*(1 << 32) <= sum(minima)
                assert high[r]*(1 << 32) >= sum(maxima)
                count += 1
    return dict(signed_schoolbook_cases=len(cases), exact_interval_correlation_checks=count,
                gmpy2=gmpy2.version(), gmp=gmpy2.mp_version())


def atoms(trial, e):
    edges = list(map(Q, trial['tiles']['radius_edges']))
    breaks = trial['combined'][0, 0][0].breaks
    endpoints = {0, e.n}
    endpoints |= {max(0, min(e.n, int(x//e.hq)-e.k+1)) for x in edges}
    endpoints |= {max(0, min(e.n, int(x//e.hq)-e.k+1)) for sh in trial['shells'] for x in sh[:2]}
    endpoints |= {max(0, min(e.n, math.ceil(x/e.hq-Q(e.k, 2)))) for x in breaks}
    return tuple(zip(sorted(endpoints), sorted(endpoints)[1:])), edges, breaks


def profile_at(trial, e, index, cap, span, edges):
    if cap is None:
        return None
    active = any(cap <= ceiling and int(lo//e.hq) < index+e.k <= int(hi//e.hq)
                 for lo, hi, ceiling in trial['shells'])
    if not active:
        return None
    cap_edges = trial['tiles']['cap_edges']
    leaf = [j for j, (x, y, c, d) in enumerate(trial['tiles']['tiles'])
            if cap_edges[c] < cap <= cap_edges[d] and
            int(edges[x]//e.hq) < index+e.k <= int(edges[y]//e.hq)]
    assert len(leaf) == 1
    first = next(j for j, limit in enumerate(trial['limits']) if cap <= limit)
    return [p.coefficients[span] for p in trial['combined'][leaf[0], first]]


def radial_inputs(trial, e, cap, next_cap):
    """Fixed integer enclosures grouped by (retained signature, erased power)."""
    intervals, edges, breaks = atoms(trial, e)
    result = {}
    for start, stop in intervals:
        s = (Q(start)+Q(e.k, 2))*e.hq
        if not breaks[0] <= s < breaks[-1]:
            continue
        span = bisect_right(breaks, s)-1
        left, right = breaks[span:span+2]
        current = profile_at(trial, e, start, cap, span, edges)
        following = profile_at(trial, e, start, next_cap, span, edges)
        zero = [(Q(0),)*4]*len(trial['signatures'])
        current = zero if current is None else current
        following = zero if following is None else following
        grouped = defaultdict(lambda: [Q(0)]*4)
        for signature, a, b in zip(trial['signatures'], current, following):
            difference = [x-y for x, y in zip(a, b)]
            for rest, exponent, multiplicity in P.fiber_splits(signature):
                row = grouped[rest, exponent]
                for j, x in enumerate(difference):
                    row[j] += multiplicity*x
        points = [rat(((Q(j)+Q(e.k, 2))*e.hq-left)/(right-left)) for j in range(start, stop)]
        for key, coefficient in grouped.items():
            if not any(coefficient):
                continue
            if key not in result:
                result[key] = [gmpy2.mpz(0)]*e.n, [gmpy2.mpz(0)]*e.n
            polynomial = tuple(map(rat, coefficient))
            for j, point in zip(range(start, stop), points):
                value = horner(polynomial, point)
                result[key][0][j] = gmpy2.mpz(scaled_endpoint(value.lower(), e.fixed_bits, False))
                result[key][1][j] = gmpy2.mpz(scaled_endpoint(value.upper(), e.fixed_bits, True))
    return result


def verify_radial_telescoping(trial, e):
    """Check the exact polynomial telescope on every radial/cap atom."""
    intervals, edges, breaks = atoms(trial, e)
    tests = 0
    for start, _ in intervals:
        s = (Q(start)+Q(e.k, 2))*e.hq
        if not breaks[0] <= s < breaks[-1]:
            continue
        span = bisect_right(breaks, s)-1
        rows = [profile_at(trial, e, start, cap, span, edges) for cap in trial['caps']]
        zero = [(Q(0),)*4]*len(trial['signatures'])
        rows = [zero if row is None else row for row in rows]+[zero]
        accumulated = [[Q(0)]*4 for _ in trial['signatures']]
        for a, b in reversed(list(zip(rows, rows[1:]))):
            for j, (aa, bb) in enumerate(zip(a, b)):
                accumulated[j] = [z+x-y for z, x, y in zip(accumulated[j], aa, bb)]
                assert accumulated[j] == list(aa)
                tests += 1
    return tests


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--cache', type=Path, default=Path(__file__).resolve().parents[1]/'deps/h1-cell-integrals')
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    checks = self_check()
    print('signed correlation checks', checks, flush=True)
    if args.check_only:
        args.output.write_text(json.dumps(checks, indent=2)+'\n', newline='\n')
        return
    fit = Path('h1_decoupled_coarsened_1e14_fit.json')
    t = load_trial(fit)
    e = CellMoments(38, 131072, t['S'], minimum_cap=min(t['caps']))
    checks['exact_radial_telescope_checks'] = verify_radial_telescoping(t, e)
    paths = [Path(__file__), Path('h1_combined_mass_interval.py'), Path('h1_exact_convolution.py'),
             Path('h1_dickman_taylor.py'), *t['paths']]
    out = dict(status='INCOMPLETE_ERASED_AMPLITUDES',
               scope='Directed erased cell amplitudes only; no erased energies or prime-gap bound.',
               inputs={p.name: digest(p) for p in paths}, checks=checks,
               cache_directory=str(args.cache.resolve()), dimension=e.k, intervals=e.intervals,
               precision=e.precision, fixed_bits=e.fixed_bits, step=str(e.hq),
               normalization='Erased amplitude divided by h and by the retained coordinate g factors.',
               inventory_inputs=t['inventory_inputs'], signatures=[list(s) for s in t['signatures']],
               caps=t['caps'], layers=[])
    args.cache.mkdir(parents=True, exist_ok=True)
    def save():
        args.output.write_text(json.dumps(out, indent=2)+'\n', newline='\n')
    save()
    for cap, next_cap in zip(t['caps'], t['caps'][1:]+[None]):
        started = time.monotonic()
        radials = radial_inputs(t, e, cap, next_cap)
        D = e.survival(cap*e.hq)
        kernels = {}
        sums = {}
        for index, ((rest, power), radial) in enumerate(sorted(radials.items())):
            if power not in kernels:
                values = [g*d*p for g, d, p in zip(e.root_values, D, e.midpoint_power(power))]
                kernels[power] = ([gmpy2.mpz(max(0, scaled_endpoint(v.lower(), e.fixed_bits, False))) for v in values],
                                  [gmpy2.mpz(max(0, scaled_endpoint(v.upper(), e.fixed_bits, True))) for v in values])
            value = interval_correlation(radial, kernels[power], e.fixed_bits)
            if rest not in sums:
                sums[rest] = value
            else:
                sums[rest] = ([a+b for a, b in zip(sums[rest][0], value[0])],
                              [a+b for a, b in zip(sums[rest][1], value[1])])
            print('cap', cap, 'correlation', index+1, '/', len(radials), flush=True)
        arrays = np.zeros((len(t['signatures']), 2, e.n))
        for j, sig in enumerate(t['signatures']):
            if sig in sums:
                arrays[j] = binary64_signed(sums[sig], e.fixed_bits)
        file = args.cache/('erased_increment_'+str(cap)+'.npz')
        np.savez_compressed(file, bounds=arrays)
        out['layers'].append(dict(cap=cap, next_cap=next_cap, file=file.name, sha256=digest(file),
                                  bytes=file.stat().st_size, correlation_count=len(radials),
                                  maximum_binary64_width=float((arrays[:, 1]-arrays[:, 0]).max()),
                                  maximum_absolute_endpoint=float(abs(arrays).max()),
                                  seconds=time.monotonic()-started))
        save()
        e._survival.clear()
        print('erased cap complete', cap, out['layers'][-1], flush=True)
    out['status'] = 'ERASED_AMPLITUDES_ENCLOSED'
    save()


if __name__ == '__main__':
    main()
