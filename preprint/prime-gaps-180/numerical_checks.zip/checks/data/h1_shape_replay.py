"""Deterministic mass and erasure integrals for a fitted symmetric coordinate sum."""
import argparse
from collections import defaultdict
from fractions import Fraction as Q
from hashlib import sha256
import json
from pathlib import Path
import numpy as np
from endpoint_asymmetric_trial import original_rows
from h1_harmonic_sector_probe import fit,forms
from h1_pairing_sectors import HERE,Sectors,trial_model,first_fibres,radial,coefficients


MARK=32   # the underlying angular degree in a squared amplitude is at most twelve


class MarkLaw:
    def __init__(self,r,fitdata,family):
        G,A=forms(np.mean(fitdata['raw'],axis=0),fitdata['base'])
        labels=fitdata['labels']
        prefixes=('tile_',) if family=='coordinate' else ('tile_','count_','excess_')
        ids=[0]+[i for i,s in enumerate(labels) if s.startswith(prefixes) and G[i,i]>1e-14]
        self.vector=v=fit(G,A,ids)
        coord=[v[i] for i,s in enumerate(labels) if s.startswith('tile_')]
        knots=np.array([0,.003,.009,.02,.04,.07,.12,.2,.32,.48,.7,1.1])
        val=np.interp(np.log1p(r.t/.015),np.log1p(knots/.015),np.r_[0.,coord])
        H=r.exact_step*r.geometry['parameters']['rho_star']
        thresholds=list(map(Q,fitdata['thresholds'])) if family=='fragment' else []
        self.cuts=[int(z//H) for z in thresholds]
        values=[val]
        for w in thresholds:
            values.append(values[-1]+v[labels.index('count_'+str(w))]+
                          v[labels.index('excess_'+str(w))]*np.maximum(r.rho*r.t-float(w),0.))
        self.shift=min(row.min() for row in values)
        self.scale=max(row.max() for row in values)-self.shift
        assert self.scale>0
        self.pieces=[(row-self.shift)/self.scale for row in values]
        self.survival=r.survival
        self.r=r

    def kernel(self,cap,power):
        if not power:return self.survival(cap)
        prev=0.;result=np.zeros(self.r.n)
        for i,lim in enumerate([*self.cuts,cap]):
            end=min(lim,cap);now=self.survival(end)
            result+=(now-prev)*self.pieces[i]**power
            if end==cap:break
            prev=now
        return result

    def install_moments(self):
        r=self.r;old=r.weighted
        def weighted(cap,encoded):
            p,j=divmod(encoded,MARK)
            if not p:return old(cap,j)
            key=(cap,encoded)
            if key not in r.weighted_cache:
                r.weighted_cache[key]=r.w*self.kernel(cap,p)*r.t**j
            return r.weighted_cache[key]
        r.weighted=weighted;r.clear_cache()


def field(rows,extra,b,d,n):
    out=defaultdict(lambda:defaultdict(lambda:np.zeros(n)))
    for cap,terms in rows.items():
        for sig,value in terms.items():
            out[cap][sig]+=b*value
            out[cap][tuple(sorted((*sig,MARK)))]+=d*value
    if extra is not None:
        for cap,terms in extra.items():
            for sig,value in terms.items():out[cap][sig]+=d*value
    return out


def integrate(r,functions,order,sec=None):
    n=len(functions);prev={};G=np.zeros((n,n));mats=None
    if sec is not None:
        mats=np.zeros((sec.n,3,n,n))
        # j retained cell indices sum to a physical total at least j*step.
        step=r.exact_step*r.geometry['parameters']['rho_star']*25000
        ticks=np.arange(r.n,dtype=np.int64)*step.numerator//step.denominator
        ticks[ticks<5000]=0
        edges,bins=np.unique(ticks,return_inverse=True)
        hist=np.zeros((len(edges),n,n))
    cuts=set(functions[0])
    if sec is not None:cuts|=set(map(int,sec.caps))
    pref=(r.outer_exp if order==0 else r.rho*r.norm*r.inner_exp)
    for cap in sorted(c for c in cuts if c<=max(functions[0])):
        F=[radial(f,cap,r.n) for f in functions];now={};diff={}
        if sec is not None:ids=sec.index[np.searchsorted(sec.caps,cap),:r.n]
        for i in range(n):
            for j in range(i,n):
                density=np.zeros(r.n)
                for sig,v in coefficients(F[i],F[j]).items():
                    if sig not in now:
                        now[sig]=r.moment(cap,r.k-order,sig).copy()
                        diff[sig]=now[sig]-prev.get(sig,0.)
                    density+=v*diff[sig]
                density*=pref
                G[i,j]+=density.sum()
                if mats is not None:
                    hist[:,i,j]+=np.bincount(bins,weights=density,minlength=len(edges))
                    for h,w in enumerate((1.,sec.prime_upper[:r.n],sec.kernel[:r.n])):
                        mats[:,h,i,j]+=np.bincount(ids,weights=density*w,minlength=sec.n)
        prev=now;r.clear_cache()
    if mats is None:return G+np.triu(G,1).T
    return (mats+np.triu(mats,1).swapaxes(-1,-2),edges,
            hist+np.triu(hist,1).swapaxes(-1,-2))


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('training',type=Path)
    p.add_argument('--family',choices=('coordinate','fragment'),default='coordinate')
    p.add_argument('--intervals',type=int,choices=(32768,131072),default=32768)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    fitdata=json.loads(a.training.read_text())
    cp=HERE/f'h1_refit280_step2_sectors_{a.intervals}.json';c=json.loads(cp.read_text())
    P,_,_,r,limits,dom=trial_model(a.intervals,c['trial_refit'])
    v=np.array(P['best_coefficients']);sec=Sectors(r,dom,[x['radius'] for x in c['sources']],c['max_radius'])
    assert sec.codes==c['codes']
    law=MarkLaw(r,fitdata,a.family);law.install_moments()
    b,d=1+r.k*law.shift,law.scale
    mass_rows=original_rows(r,v,limits);prime=first_fibres(r,v,limits)
    try:
        r.survival=lambda cap:law.kernel(cap,1)
        extra=first_fibres(r,v,limits)
    finally:r.survival=law.survival
    G=integrate(r,[mass_rows,field(mass_rows,None,b,d,r.n)],0)
    print(json.dumps(dict(mass=G.tolist())),flush=True)
    E,edges,hist=integrate(r,[prime,field(prime,extra,b,d,r.n)],1,sec)
    np.testing.assert_allclose(hist.sum(axis=0),E[:,0].sum(axis=0),rtol=1e-11)
    baseline_error=np.max(abs(E[:,:,0,0]/G[0,0]-c['sector_energies']))
    assert baseline_error<2e-8 and np.linalg.eigvalsh(G)[0]>0,baseline_error
    np.savez_compressed(a.output,training=a.training.name,training_sha256=sha256(a.training.read_bytes()).hexdigest(),
                        control=cp.name,control_sha256=sha256(cp.read_bytes()).hexdigest(),mass=G,
                        energies=E,coefficients=law.vector,family=a.family,shift=law.shift,scale=law.scale,
                        baseline_error=baseline_error,lower_edge_ticks=edges,edge_denominator=25000,histogram=hist)
    print(json.dumps(dict(baseline_error=float(baseline_error),minimum=np.min(E[:,:,1,1]))))


if __name__=='__main__':main()
