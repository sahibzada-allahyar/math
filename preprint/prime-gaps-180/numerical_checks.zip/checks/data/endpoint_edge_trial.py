"""Test a quadratic interaction on the graph of pairs wider than 180.

This computes floating cap-model pencils. Arithmetic control of simultaneous
primality and support restoration are separate open requirements.
"""
import argparse
from collections import defaultdict
from itertools import combinations,permutations
import json
from math import prod
from pathlib import Path

import numpy as np
from scipy.linalg import eigh
from endpoint_asymmetric_trial import face_weights, original_rows
from endpoint_pair_scan import HERE, BACKEND, setup, first_fibres, double_fibres, double_fibre_form, scalar_replay


# A product of distinct labelled totals, averaged over injective assignments.
# Each numerator term is (integer coefficient, power of total, power sums).
DISTINCT = {
    (): [(1,0,())],
    (1,): [(1,1,())],
    (2,): [(1,0,(2,))],
    (1,1): [(1,2,()),(-1,0,(2,))],
    (1,2): [(1,1,(2,)),(-1,0,(3,))],
    (1,1,1): [(1,3,()),(-3,1,(2,)),(2,0,(3,))],
    (2,2): [(1,0,(2,2)),(-1,0,(4,))],
    (1,1,2): [(1,2,(2,)),(-1,0,(2,2)),(-2,1,(3,)),(2,0,(4,))],
    (1,1,1,1): [(1,4,()),(-6,2,(2,)),(3,0,(2,2)),(8,1,(3,)),(-6,0,(4,))],
}


def overlaps(left,right):
    """Count products by their index coincidences. Pair arrays are upper triangular."""
    if left.ndim>right.ndim:
        return overlaps(right,left)
    total = left.sum()*right.sum()
    if left.ndim==0:
        return {tuple([1]*right.ndim):total}
    if right.ndim==1:
        same = left@right
        return {(2,):same,(1,1):total-same}
    degree = (right+right.T).sum(axis=1)
    if left.ndim==1:
        shared = left@degree
        return {(1,2):shared,(1,1,1):total-shared}
    same = (left*right).sum()
    one = (left+left.T).sum(axis=1)@degree-2*same
    return {(2,2):same,(1,1,2):one,(1,1,1,1):total-one-same}


def graph_coefficients(size,edges):
    adjacency = np.zeros((size,size))
    for i,j in edges:
        adjacency[i,j] = adjacency[j,i] = 1.
    degree = adjacency.sum(axis=1)
    centered = adjacency-(degree[:,None]+degree[None,:])/(size-2)+2*len(edges)/((size-1)*(size-2))
    np.fill_diagonal(centered,0.)
    assert np.max(abs(centered.sum(axis=1)))<1.e-12
    return degree-degree.mean(),centered


def erased_terms(a,graph,erased):
    left = [i for i in range(len(a)) if i not in erased]
    block = np.triu(graph[np.ix_(left,left)],1)
    # First item indexes the fibre integrated with 0, 1, or 2 marked
    # coordinate factors. Second item is a polynomial on the retained labels.
    groups = [[(0,np.array(1.))],[(0,a[left])],[(0,block)]]
    if erased:
        groups[1].append((1,np.array(sum(a[i] for i in erased))))
        groups[2].append((1,graph[np.ix_(left,erased)].sum(axis=1)))
    if len(erased)>=2:
        groups[2].append((2,np.array(sum(graph[i,j] for i,j in combinations(erased,2)))))
    return groups


def contraction_rules(a,graph,erased_sets):
    result = defaultdict(lambda: defaultdict(lambda: np.zeros((3,3))))
    for erased in erased_sets:
        groups = erased_terms(a,graph,erased)
        for i,left in enumerate(groups):
            for j in range(i,3):
                for u,p in left:
                    for v,q in groups[j]:
                        key = tuple(sorted((u,v)))
                        for pattern,value in overlaps(p,q).items():
                            result[key][pattern][i,j] += value/len(erased_sets)
    return result


def moment_numerator(t,pattern):
    return sum(c*sum(t)**degree*prod(sum(t**e) for e in powers)
               for c,degree,powers in DISTINCT[pattern])


def check_label_average():
    # Compare every matrix entry against direct labelling of five
    # coordinates. The three different tagged fibres are arbitrary scalars.
    k=5
    edges=[(0,3),(0,4),(1,4)]
    a,graph = graph_coefficients(k,edges)
    largest_error=0.
    for erased_sets in [[()],[(i,) for i in range(k)],edges,[(0,1,3),(2,3,4)]]:
        count = k-len(erased_sets[0])
        t = np.array([.11,.23,.31,.52,.73])[:count]
        fibres = np.array([.91,.27,.19])
        expected=np.zeros((3,3))
        for erased in erased_sets:
            kept=[i for i in range(k) if i not in erased]
            for perm in permutations(kept):
                tt=dict(zip(perm,t))
                lin=sum(a[i]*u for i,u in tt.items())*fibres[0]+sum(a[i] for i in erased)*fibres[1]
                quadratic=0.
                for i in range(k):
                    for j in range(i+1,k):
                        marked=int(i in erased)+int(j in erased)
                        quadratic+=graph[i,j]*tt.get(i,1.)*tt.get(j,1.)*fibres[marked]
                vector=np.array([fibres[0],lin,quadratic])
                expected+=np.outer(vector,vector)
        expected/=len(erased_sets)*prod(range(1,count+1))
        observed=np.zeros((3,3))
        for (u,v), patterns in contraction_rules(a,graph,erased_sets).items():
            for pattern,matrix in patterns.items():
                den=prod(range(count-len(pattern)+1,count+1))
                # Four disjoint retained indices are impossible at count=3.
                if den==0:
                    assert np.max(abs(matrix))<1.e-12
                    continue
                observed+=matrix*fibres[u]*fibres[v]*moment_numerator(t,pattern)/den
        largest_error=max(largest_error,np.max(abs(np.triu(expected)-observed)))
    assert largest_error<1.e-12,largest_error
    return float(largest_error)


def contract_form(r,order,amplitudes,rules,domains,ell,kappa,radial_weights=None,*,all_prime_faces=False,radial_bins=None,layer_weight=None,extra_caps=()):
    count=r.k-order
    total=(np.arange(r.n)+count/2)*r.h
    total_powers=[total**i for i in range(5)]
    tilt=np.exp(r.tilt*(total-r.center))
    caps=set(amplitudes[0])|set(extra_caps)
    if order==1 and not all_prime_faces:
        caps.update(r.caps)
        caps.update(sh[2] for domain in domains.values() for sh in domain)
    caps=sorted(c for c in caps if c<=max(amplitudes[0]))
    previous={}
    if radial_bins is None:
        radial_masks=np.ones((1,r.n)) if radial_weights is None else np.asarray(radial_weights)
        assert radial_masks.ndim==2 and radial_masks.shape[1]==r.n and np.all(np.isfinite(radial_masks))
        bands=len(radial_masks)
    else:
        assert radial_weights is None and radial_bins.shape==(r.n,) and radial_bins.min()>=0
        bands=int(radial_bins.max())+1
    shape=next(iter(next(iter(rules.values())).values())).shape
    assert len(shape) in (2,3) and shape[-2]==shape[-1]
    result=np.zeros((bands,*shape))
    for cap in caps:
        parts=[]
        for amplitude in amplitudes:
            rows=defaultdict(lambda:np.zeros(r.n))
            for limit,part in amplitude.items():
                if limit>=cap:
                    for sig,value in part.items():
                        rows[sig]+=value
            parts.append(rows)
        current={}
        increments={}
        def layer(sig):
            if sig not in current:
                current[sig]=r.moment(cap,count,sig).copy()
                increments[sig]=current[sig]-previous.get(sig,0.)
            return increments[sig]
        weight=tilt*face_weights(r,cap,domains,ell,kappa) if order==1 and not all_prime_faces else tilt
        if layer_weight is not None:weight=weight*layer_weight(cap)
        for (u,v),patterns in rules.items():
            active={p:mat for p,mat in patterns.items() if np.max(abs(mat))>1.e-13}
            if not active:
                continue
            products=defaultdict(lambda:np.zeros(r.n))
            for first,values in parts[u].items():
                for second,coeffs in parts[v].items():
                    products[tuple(sorted(first+second))]+=values*coeffs
            for signature,poly in products.items():
                weighted=weight*poly if radial_bins is not None else radial_masks*(weight*poly)
                for pattern,mat in active.items():
                    value=0.
                    for factor,degree,extra in DISTINCT[pattern]:
                        moment=layer(tuple(sorted(signature+extra)))
                        term=total_powers[degree]*moment
                        if radial_bins is None:
                            value+=factor*(weighted @ term)
                        else:
                            value+=factor*np.bincount(radial_bins,weights=weighted*term,minlength=bands)
                    value/=prod(range(count-len(pattern)+1,count+1))
                    result+=value.reshape((-1,)+(1,)*len(shape))*mat
        previous=current
        r.clear_cache()
    result=(result+np.triu(result,1).swapaxes(-1,-2))*(r.rho*r.h/r.Z)**order*(r.k if order==1 else 1)
    return result[0] if radial_weights is None and radial_bins is None else result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('reference',type=Path)
    p.add_argument('--profile',type=Path,help='Re-evaluate using a profile fitted at the specified dimension')
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    reference=json.loads(args.reference.read_text())
    k,N=reference['dimension'],reference['intervals']
    source_path=args.profile or HERE/'h1_k39_control_n32768.json'
    source=json.loads(source_path.read_text())
    prior=json.loads((BACKEND/'results/incidence_multicap_spline_a6_n32768.json').read_text())
    scan=json.loads((HERE/f'endpoint_pair_scan_n{N}.json').read_text())
    ell=next(row['ell'] for row in scan['rows'] if row['k']==k)
    if args.profile:
        assert source['dimension']==k and source['specification']==json.loads((HERE/'h1_k39_control_n32768.json').read_text())['specification']
        ell=source['rows'][source['best_index']]['hybrid_lambda']
    shifts=json.loads((HERE/'endpoint_tuple_inputs.json').read_text())[str(k)]['shifts']
    edges=[tuple(shifts.index(s) for s in e) for e in reference['bad_pairs']]
    a,graph=graph_coefficients(k,edges)
    r,limits,domains=setup(k,N,source,prior)
    coefficients=np.array(source['best_coefficients'])
    common=(domains,ell,prior['kappa'])
    error=check_label_average()
    def form(order,amplitudes,marked):
        val=contract_form(r,order,amplitudes,contraction_rules(a,graph,marked),*common)
        print(json.dumps({'event':'EDGE_FORM','order':order}),flush=True)
        return val
    mass=form(0,[original_rows(r,coefficients,limits)],[()])
    first=first_fibres(r,coefficients,limits)
    marked_first=first_fibres(r,coefficients,limits,marked_power=1)
    prime=form(1,[first,marked_first],[(i,) for i in range(k)])
    second,total=double_fibres(r,coefficients,limits,first=first)
    marked_second,_=double_fibres(r,coefficients,limits,marked_power=1,first=first)
    both,_=double_fibres(r,coefficients,limits,marked_power=1,first=marked_first)
    pair=form(2,[second,marked_second,both],edges)*len(edges)
    errors={}
    if args.profile:
        scalar_mass,forms=scalar_replay(r,coefficients,limits,domains)
        scalar_prime=r.rho*(forms[0]+(1-ell)*forms[1]+(1-1/ell)*prior['kappa']*forms[2])
        scalar_pair=r.rho**2*len(edges)*double_fibre_form(r,second,total)
        for name,matrix,value in [('mass',mass,scalar_mass),('prime',prime,scalar_prime),('pair',pair,scalar_pair)]:
            errors[name]=float(abs(matrix[0,0]/value-1))
    else:
        for name,matrix in [('mass',mass),('prime_form',prime),('sum_of_pair_forms',pair)]:
            old=np.array(reference[name])
            scale=np.sqrt(np.diag(old))
            errors[name]=float(np.max(abs(matrix[:2,:2]-old)/scale[:,None]/scale[None,:]))
    assert max(errors.values())<2.e-7,errors
    assert min(eigh(mass,eigvals_only=True))>0 and min(eigh(pair,eigvals_only=True))>0
    e,v=eigh(prime-mass,pair)
    cases=[]
    for cost in [3,4,8]:
        ev,vec=eigh(prime-cost*pair,mass)
        cases.append({'multiplier':cost,'cap_score':float(ev[-1]),
                      'coefficients':(vec[:,-1]/vec[0,-1]).tolist()})
    out=dict(status='UNCERTIFIED_GRAPH_EDGE_INTERACTION_NO_PRIME_GAP_CERTIFICATE',
             integration='Deterministic floating grid',
             dimension=k,intervals=N,reference=args.reference.name,profile=source_path.name,ell=ell,edges=edges,
             basis=['F','F sum_i a_i t_i','F sum_i<j b_ij t_i t_j'],
             label_average_error=error,submatrix_errors=errors,
             mass=mass.tolist(),prime_form=prime.tolist(),sum_of_pair_forms=pair.tolist(),
             endpoint_only_critical=float(eigh(prime[:2,:2]-mass[:2,:2],pair[:2,:2],eigvals_only=True)[-1]),edge_critical=float(e[-1]),
             critical_coefficients=(v[:,-1]/v[0,-1]).tolist(),cases=cases,
             limitations=['Floating cap integrals without interval bounds.',
                          'No arithmetic pair multiplier or support restoration has been established.'])
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'critical':out['edge_critical'],'cost_four':cases[1]}),flush=True)


if __name__=='__main__':
    main()
