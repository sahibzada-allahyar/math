"""Transfer the twelve-level rational sector prices to the full native cap integral."""
import argparse
from fractions import Fraction as Q
import gzip
import hashlib
import json
from math import ceil,floor
from pathlib import Path
import numpy as np

from h1_combined_margin import margin
from h1_mass_band_prices import FIT,FORMS,NORM,PRICES,TABLE,digest,geom,mixture_energies,read
from h1_native_cap_total import OUTPUT as TOTAL,enclosure,interval
from h1_native_sector_replay import OUTPUT as SECTORS,DIRECTORY
from h1_sunrise_boundary import geometry

DATA=Path('../../lean/minorants/data')
NEW=DATA/'ml12_w25_prices.json'
CERT=DATA/'ml12_w25.json.gz'
POST=DATA/'ml12_w25_post.json'
OUT=Path('h1_multilevel_native_cap.json')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--check',action='store_true')
    args=ap.parse_args()
    new,post,sector,total,old,norm=map(read,(NEW,POST,SECTORS,TOTAL,PRICES,NORM))
    raw=gzip.decompress(CERT.read_bytes())
    proof=json.loads(raw)
    assert hashlib.sha256(raw).hexdigest()==new['certificate_sha256']==post['certificate_sha256']
    assert len(proof['levels'])==12 and proof['fit']==FIT.name and proof['groups']==445
    assert proof['lower']==post['lower']
    assert post['prices_file']==NEW.name and new['certificate']==post['certificate']==CERT.stem
    assert new['scale']==old['scale']==10**14 and all(r[2]==0 for r in new['sector_prices']+old['sector_prices'])
    for p in (FIT,PRICES,NORM,TABLE):
        assert total['inputs'][p.name]==digest(p) and sector['inputs'][p.name]==digest(p)
    assert sector['inputs'][TOTAL.name]==digest(TOTAL) and sector['cap_quotient']==total['cap_quotient']
    for p,hash0 in sector['boundaries'].items():
        assert digest(DIRECTORY/p)==hash0
    newp=np.array(new['sector_prices'],dtype=object);oldp=np.array(old['sector_prices'],dtype=object)
    assert newp.shape==oldp.shape==(521,3) and len(sector['boundaries'])==total['layers']==44
    finite=sum((newp*mixture_energies(FORMS,FIT)).ravel())/new['scale']
    floored=floor(finite*10**9)
    assert floored==new['reference_lower_billionths']==post['prices_lower_billionths']==1000120404
    finite=Q(floored,10**9)
    en=sector['normalized_sector_energies']
    assert len(en)==len(newp)
    def contract(prices):
        lo=hi=Q(0)
        for p,row in zip(prices,en):
            assert len(row)==2
            for w,e in zip(p,row):
                a,b=enclosure(e);assert a>=0
                lo+=min(w*a,w*b);hi+=max(w*a,w*b)
        return lo/new['scale'],hi/new['scale']
    direct=contract(newp)
    delta=contract(newp-oldp)
    ca=enclosure(total['cap_quotient'])
    anchored=ca[0]+delta[0],ca[1]+delta[1]
    lo=max(direct[0],anchored[0]);hi=min(direct[1],anchored[1])
    assert 1<lo<=hi
    # Test the effective signed price, with both coefficients evaluated
    # at the SAME radial index. Include sectors of zero original energy
    # because deleting part of a signed profile can expose cancellation.
    control,original,layout=geometry(TABLE)
    with np.load(original['cell_bins'],allow_pickle=False) as arc:
        caps=np.unique(arc['cells'][:,1])
    index=np.arange(norm['intervals']-norm['dimension'])
    bottom=np.full(len(newp)+1,len(index),int);top=np.full(len(newp)+1,-1,int)
    for c in caps:
        own=layout(c,index);assert min(own)>=-1 and max(own)<len(newp)
        np.minimum.at(bottom,own,index);np.maximum.at(top,own,index)
    step=Q(norm['step'])
    def K(j):
        return 1/(Q(1,2)-geom.RS*(int(j)+37)*step-Q('.0001'))
    effective=[]
    for i,p in enumerate(newp):
        assert bottom[i]<=top[i]
        v=[(p[0]+p[1]*K(j))/new['scale'] for j in (bottom[i],top[i])]
        effective.append((min(v),max(v)))
    lower=min(v[0] for v in effective);upper=max(v[1] for v in effective)
    assert upper==1
    expenses=[]
    for cut in (1,10,100,1000,10000,100000):
        ids=[i for i,(a,b) in enumerate(effective) if a<-cut]
        cost=sum(max(0,-effective[i][0])*enclosure(en[i][0])[1] for i in ids)
        expenses.append(dict(cut=cut,sectors=len(ids),original_negative_income_upper_trillionths=ceil(cost*10**12)))
    benchmark=margin(finite,lo,Q(0),1)
    paths=[Path(__file__),NEW,POST,CERT,TOTAL,SECTORS,PRICES,NORM,FIT,TABLE,FORMS,FORMS.with_suffix('.npz')]
    out=dict(scope='Full continuous quotient at the supplied twelve-level prices for the frozen mixed trial. The arithmetic divisor loss for these multipliers remains unbounded by this calculation.',
             inputs={p.name:digest(p) for p in paths},sectors=len(en),layers=total['layers'],
             direct=interval(*direct),price_difference=interval(*delta),anchored=interval(*anchored),
             cap_quotient=interval(lo,hi),lower_trillionths=floor(lo*10**12),upper_trillionths=ceil(hi*10**12),
             benchmark=benchmark,effective_price_range=interval(lower,upper),
             most_negative_sector=min(range(len(newp)),key=lambda i:effective[i][0]),negative_price_tails=expenses)
    if args.check:
        assert read(OUT)==out
    else:
        OUT.write_text(json.dumps(out,indent=2)+'\n',newline='\n')
    print('continuous twelve-level quotient in trillionths',out['lower_trillionths'],out['upper_trillionths'],
          'positive price upper',upper,'minimum',float(lower),flush=True)


if __name__=='__main__':
    main()
