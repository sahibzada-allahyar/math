"""Positive fixed-point polynomial intervals using exact GMP integer packing.

If 0 <= a_i <= A and 0 <= b_j <= B, each convolution coefficient is
at most min(len(a),len(b))*A*B. Pack at a power of two strictly larger
than that bound. Integer multiplication then has no inter-coefficient
carries. Truncation, flooring and ceiling below are exact integer steps.
No FLINT polynomial multiplication is used.
"""
from dataclasses import dataclass
import itertools
import math
import random

import gmpy2
import numpy as np


def convolution(a, b, length=None):
    if not a or not b:
        return []
    assert min(a) >= 0 and min(b) >= 0
    full_length = len(a)+len(b)-1
    length = full_length if length is None else min(length, full_length)
    bound = min(len(a), len(b))*max(a)*max(b)
    bits = max(1, int(bound).bit_length())
    assert bound < 1 << bits
    product = gmpy2.pack(list(a), bits)*gmpy2.pack(list(b), bits)
    out = gmpy2.unpack(product, bits)[:length]
    out.extend([gmpy2.mpz(0)]*(length-len(out)))
    return out


def scaled_endpoint(value, bits, upper):
    assert value.is_exact() and value.is_finite()
    m, e = map(int, value.man_exp())
    shift = e+bits
    if shift >= 0:
        return m << shift
    return -((-m) >> -shift) if upper else m >> -shift


@dataclass(frozen=True)
class PositivePolynomial:
    lower: list
    upper: list
    bits: int
    length: int

    def __post_init__(self):
        assert self.bits >= 32 and self.length >= 1
        assert len(self.lower) == len(self.upper) <= self.length
        assert all(0 <= a <= b for a, b in zip(self.lower, self.upper))

    @classmethod
    def from_arb(cls, values, bits, length):
        low, high = [], []
        for value in values:
            assert value.is_finite() and value.upper() >= 0
            low.append(gmpy2.mpz(max(0, scaled_endpoint(value.lower(), bits, False))))
            high.append(gmpy2.mpz(max(0, scaled_endpoint(value.upper(), bits, True))))
        return cls(low, high, bits, length)

    @classmethod
    def one(cls, bits, length):
        return cls([gmpy2.mpz(1) << bits], [gmpy2.mpz(1) << bits], bits, length)

    @classmethod
    def zero(cls, bits, length):
        return cls([], [], bits, length)

    def compatible(self, other):
        assert (self.bits, self.length) == (other.bits, other.length)

    def multiply(self, other):
        self.compatible(other)
        low = convolution(self.lower, other.lower, self.length)
        high = convolution(self.upper, other.upper, self.length)
        shift = (1 << self.bits)-1
        return type(self)([v >> self.bits for v in low],
                          [(v+shift) >> self.bits for v in high], self.bits, self.length)

    def add(self, other):
        self.compatible(other)
        return type(self)([a+b for a, b in itertools.zip_longest(self.lower, other.lower, fillvalue=0)],
                          [a+b for a, b in itertools.zip_longest(self.upper, other.upper, fillvalue=0)],
                          self.bits, self.length)

    def scale_integer(self, factor):
        assert factor == int(factor) and factor >= 0
        return type(self)([v*factor for v in self.lower], [v*factor for v in self.upper], self.bits, self.length)

    def binary64_intervals(self):
        out = []
        for upper, row in enumerate((self.lower, self.upper)):
            values = np.zeros(self.length)
            for j, v in enumerate(row):
                value = int(v)
                if not value:
                    continue
                shift = max(0, value.bit_length()-1000)
                if shift:
                    value = (value+(1 << shift)-1) >> shift if upper else value >> shift
                nearest = math.ldexp(float(value), shift-self.bits)
                values[j] = max(0., np.nextafter(nearest, np.inf if upper else -np.inf))
            assert np.isfinite(values).all()
            out.append(values)
        assert np.all(out[0] <= out[1])
        return tuple(out)


def check_convolution():
    rng = random.Random(182038)
    cases = [([0], [0]), ([1, 0, 2], [0, 5])]
    for length in (1, 2, 7, 16, 65):
        for bits in (1, 53, 192, 510):
            cases.append(([rng.getrandbits(bits) for _ in range(length)],
                          [rng.getrandbits(bits) for _ in range(length+3)]))
    for a, b in cases:
        exact = [0]*(len(a)+len(b)-1)
        for i, x in enumerate(a):
            for j, y in enumerate(b):
                exact[i+j] += x*y
        assert convolution(a, b) == exact
        assert convolution(a, b, len(a)) == exact[:len(a)]
    # Magnitudes from the public source's failing signed-FFT example.
    a, b = (1 << 509)-1, (1 << 510)-1
    got = [-v for v in convolution([a]*16, [b]*16)]
    assert got == [-min(j+1, 31-j, 16)*a*b for j in range(31)]
    a = [rng.getrandbits(192) for _ in range(4096)]
    b = [rng.getrandbits(192) for _ in range(4096)]
    result = convolution(a, b)
    def evaluate(row, x, modulus):
        out = 0
        for value in reversed(row):
            out = (out*x+int(value)) % modulus
        return out
    for modulus in (1000000007, 1000000009, 2147483647):
        assert evaluate(result, 182, modulus) == evaluate(a, 182, modulus)*evaluate(b, 182, modulus) % modulus
    return dict(exact_schoolbook_cases=len(cases), full_and_truncated=True,
                signed_regression_magnitudes='passed', long_product_modular_checks=3,
                gmpy2=gmpy2.version(), gmp=gmpy2.mp_version())
