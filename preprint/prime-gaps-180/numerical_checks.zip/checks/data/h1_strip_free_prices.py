"""Remove all three evaluated semiprime identities from the fixed H1 dual witness."""
import argparse
from fractions import Fraction
from math import floor
from pathlib import Path
import json

import numpy as np

from h1_cover_convergence import mixture_energies
from h1_raw_rectangle_cover import CERT, FIT, PRICES, TABLE, digest, read
from h1_semiprime_budget import density

FORMS = Path('h1_cover_native_mixed.json')
FROZEN = Path('h1_cover_72_semiprime_mixed_fit.json')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    certificate, prices, fit = map(read, (CERT, PRICES, FIT))
    scale = prices['scale']
    assert scale == 10**14
    assert prices['inputs'][CERT.name] == digest(CERT)
    for path in (TABLE, FORMS, FORMS.with_suffix('.npz'), FROZEN):
        assert prices['inputs'][path.name] == digest(path)
    assert fit['inputs'][PRICES.name] == digest(PRICES)
    base = mixture_energies(FORMS, FROZEN)
    current = mixture_energies(FORMS, FIT)
    cuts = list(map(Fraction, certificate['cuts']))
    intervals = [density(a,b) for a,b in zip(cuts,cuts[1:])]
    assert cuts == list(map(Fraction, ('.2857','.36','.416407','.5')))
    # The four shared constraints have prime coefficients (1,1,1,0).
    # add_strips copies each one to EVERY strip and appends coefficient 1
    # for each strip in the last joint constraint. Each remaining strip
    # residual with zero affine multiplier is a sum of Gram matrices.
    coefficients = [1,1,1,0,1]
    assert len(certificate['factors']) == len(coefficients)
    groups = certificate['groups']
    assert all(len(F)==len(groups) for F in certificate['factors'])
    assert len(certificate['affine'])==6
    original = np.asarray(prices['sector_prices'],dtype=object)
    modified = original.copy()
    two_strip = np.zeros(len(original),dtype=object)
    all_ids = [s for g in groups for s in g]
    assert len(set(all_ids)) == len(all_ids) and set(range(len(original)))-set(all_ids) == {170,171,172,173}
    for i, sectors in enumerate(groups):
        mass = sum(base[sectors,0])
        assert mass>0
        earned = []
        for matrix,(low,high) in zip(certificate['affine'][3:],intervals):
            a = matrix[i][i]
            earned.append(min(low*a,high*a)/mass)
        # earned is already in units of 1/scale. Existing prices were
        # rounded down. Rounding a removed positive credit upwards preserves
        # a lower witness. We keep every old nonnegative residual penalty.
        two_strip[sectors] = max(0,-((-sum(earned[:2]))//1))
        removed = max(0,-((-sum(earned))//1))
        modified[sectors,0] -= removed
        assert all(Fraction(v) >= sum(earned) for v in original[sectors,0]-modified[sectors,0])
    assert np.array_equal(modified[:,1:],original[:,1:]) and (modified<=original).all()
    def score(raw, coefficients):
        return sum((raw*coefficients).ravel())/scale
    old_score = score(current,original)
    new_score = score(current,modified)
    assert floor(old_score*10**9)==fit['families']['mixed']['lower_billionths']
    assert new_score>1 and new_score<=old_score
    document = dict(scope='Sector lower prices with all three semiprime affine multipliers zero. The positive semiprime upper constraints and the other three arithmetic inputs are retained.',
            inputs={p.name:digest(p) for p in (Path(__file__),CERT,PRICES,FIT,TABLE,FORMS,FORMS.with_suffix('.npz'),FROZEN,
                    Path('h1_cover_prices.py'),Path('h1_cover_pairings.py'),Path('h1_joint_semiprime_strips.py'),
                    Path('h1_decoupled_type3.py'),Path('h1_semiprime_budget.py'),Path('verify_pairing_envelope.py'))},
            scale=scale,retained_affine_channels=[0,1,2],zero_affine_channels=[3,4,5],
            positive_gram_coefficients_per_removed_strip=coefficients,
            two_strip_uniform_loss_per_unit_energy=str(Fraction(max(two_strip),scale)),
            old_finite_lower_billionths=floor(old_score*10**9),
            new_finite_lower_billionths=floor(new_score*10**9),finite_score_difference=str(old_score-new_score),
            sector_prices=modified.tolist())
    if args.check:
        assert document==read(args.output)
    else:
        args.output.write_text(json.dumps(document,indent=2)+'\n',newline='\n')
    print('finite lower billionths',document['new_finite_lower_billionths'],
          'lost',float(old_score-new_score),flush=True)


if __name__=='__main__':
    main()
