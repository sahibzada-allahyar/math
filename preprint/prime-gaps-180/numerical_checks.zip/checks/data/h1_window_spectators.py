"""Four overlapping 38-shift trials with softly localized spectator coordinates."""
import argparse,json
from collections import defaultdict,Counter
from functools import lru_cache
from itertools import combinations,product
from pathlib import Path
import numpy as np
from scipy.fft import rfft,irfft,next_fast_len
from h1_matrix_detector import HERE,BACKEND,setup,original_rows,first_fibres,scalar_replay,solve
from endpoint_asymmetric_trial import face_weights


@lru_cache(None)
def splits(sig,groups):
    # Expand each power sum across disjoint coordinate groups.
    out=Counter()
    for assign in product(groups,repeat=len(sig)):
        key=tuple(tuple(e for e,g in zip(sig,assign) if g==j) for j in groups)
        out[key]+=1
    return list(out.items())


def radial(rows,cap,n):
    result=defaultdict(lambda:np.zeros(n))
    for limit,part in rows.items():
        if limit>=cap:
            for sig,values in part.items():
                result[sig]+=values
    return result


def coefficients(left,right):
    out=defaultdict(lambda:0.)
    for a,u in left.items():
        for b,v in right.items():
            key=tuple(sorted(a+b))
            out[key]=out[key]+u*v
    return out


def compute(N,beta):
    prior=json.loads((BACKEND/'results/incidence_multicap_spline_a6_n32768.json').read_text())
    source=json.loads((HERE/'h1_k38_knn6_n32768.json').read_text())
    r,limits,domains=setup(41,N,source,prior)
    ell=source['rows'][source['best_index']]['hybrid_lambda'];kappa=prior['kappa']
    # Use the actual 38-dimensional polynomial amplitudes while constructing
    # the support and cell offsets at the full dimension of the 41-tuple.
    v=np.array(source['best_coefficients']).reshape(-1,r.nb)
    v*=np.array([(38./41.)**(sum(sig)-len(sig)) for sig,_ in r.desc])[None,:]
    v=v.ravel()
    g=r.g.copy();plain=original_rows(r,v,limits)
    regular=first_fibres(r,v,limits)
    r.g=g*np.exp(-beta*r.t);marked=first_fibres(r,v,limits);r.g=g
    Z=[np.sum(g*g*np.exp(-(r.tilt+j*beta)*r.t)) for j in range(3)]
    length=next_fast_len(3*r.n-2)
    # d is how many of the three spectators in one window differ from
    # those in the other. role is the number of factors damping the erased coordinate.
    cases={}
    for d in range(4):
        counts=[38-d,2*d,3-d]
        cases[d,-1]=tuple(counts)
        for role in range(3):
            if counts[role]:
                left=counts.copy();left[role]-=1
                cases[d,role]=tuple(left)
    caps=sorted(set(plain)|set(regular)|set(marked)|set(r.caps)|
                {sh[2] for domain in domains.values() for sh in domain})
    caps=[c for c in caps if c<=max(plain)]
    values={case:0. for case in cases};prev={case:{} for case in cases}
    for cap in caps:
        P=radial(plain,cap,r.n);F=radial(regular,cap,r.n);H=radial(marked,cap,r.n)
        polys={-1:coefficients(P,P),0:coefficients(F,F),1:coefficients(F,H),2:coefficients(H,H)}
        mask=face_weights(r,cap,domains,ell,kappa)
        weights={-1:r.outer_exp,0:r.inner_exp*mask,1:r.inner_exp*mask,2:r.inner_exp*mask}
        # One transform for each required group moment. Padding to 3n-2
        # makes products of three truncated spectra linear convolutions.
        needed=[defaultdict(set) for _ in range(3)]
        for case,counts in cases.items():
            groups=tuple(i for i,n in enumerate(counts) if n)
            for sig in polys[case[1]]:
                for parts,_ in splits(sig,groups):
                    for group,part in zip(groups,parts):
                        needed[group][counts[group]].add(part)
        transforms={}
        for group,counts in enumerate(needed):
            r.g=g*np.exp(-.5*group*beta*r.t);r.set_moment_tilt(r.tilt)
            for count,signatures in counts.items():
                for sig in signatures:
                    transforms[group,count,sig]=rfft(r.moment(cap,count,sig),length)
            r.clear_cache()
        for case,counts in cases.items():
            d,role=case
            groups=tuple(i for i,n in enumerate(counts) if n)
            current={};partial=0.
            for sig,poly in polys[role].items():
                spectrum=0.
                for parts,mult in splits(sig,groups):
                    term=transforms[groups[0],counts[groups[0]],parts[0]]
                    for group,part in zip(groups[1:],parts[1:]):
                        term=term*transforms[group,counts[group],part]
                    spectrum=spectrum+mult*term
                density=irfft(spectrum,length)[:r.n]
                partial+=weights[role]@(poly*(density-prev[case].get(sig,0.)))
                current[sig]=density
            prev[case]=current
            values[case]+=partial
        del transforms
    for (d,role),value in values.items():
        scale=(Z[1]**2/(Z[0]*Z[2]))**d
        values[d,role]=float(value*scale*(r.rho*r.h/Z[role] if role>=0 else 1.))
    # Active endpoints are three consecutive labels among the six ordered labels.
    windows=[set(range(i,i+3)) for i in range(4)]
    mass=np.zeros((4,4));core=mass.copy();forms=[mass.copy() for _ in range(6)]
    for i,wa in enumerate(windows):
        for j,wb in enumerate(windows):
            d=len(wa-wb)
            mass[i,j]=values[d,-1];core[i,j]=values[d,0]
            for label,out in enumerate(forms):
                role=int(label not in wa)+int(label not in wb)
                out[i,j]=values[d,role]
    # Same-coordinate-weight limit is an independent calibration of every
    # overlap class even when the two choices of spectator indices differ.
    check=None
    if beta==0:
        r.g=g;r.set_moment_tilt(r.tilt)
        old,components=scalar_replay(r,v,limits,domains)
        numerator=r.rho*(components[0]+(1-ell)*components[1]+(1-1/ell)*kappa*components[2])
        check=max(float(np.max(abs(mass/old-1))),float(np.max(abs(41*core/numerator-1))),
                  *[float(np.max(abs(41*A/numerator-1))) for A in forms])
        assert check<2e-7,check
    fit=solve(mass,core,forms)
    return dict(beta=beta,intervals=N,normalization=Z,control=check,mass=mass.tolist(),common_form=core.tolist(),
                endpoint_forms=[D.tolist() for D in forms],fit=fit)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--intervals',type=int,default=4096)
    p.add_argument('--betas',type=float,nargs='+',default=[0.,128.,512.,2048.]);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    out=dict(status='UNCERTIFIED_OVERLAPPING_WINDOW_SINGLE_PRIME_DETECTORS',rows=[],
             scope='Deterministic floating cap forms with no restoration or integration enclosure.')
    for beta in args.betas:
        row=compute(args.intervals,beta);out['rows'].append(row)
        args.output.write_text(json.dumps(out,indent=2)+'\n')
        print(json.dumps({'beta':beta,'control':row['control'],'rank':row['fit']['rank'],
                          'window':max(row['fit']['window_scores']),'matrix':row['fit']['best_matrix']['score']}),flush=True)


if __name__=='__main__':
    main()
