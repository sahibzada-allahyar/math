"""Find disjoint missing group pairings that already obstruct the frozen finite H1 trial."""
import argparse
from fractions import Fraction as Q
import json
from math import isqrt
from pathlib import Path

import numpy as np
from scipy.optimize import linear_sum_assignment

from h1_graded_cross_block import native_layout
from h1_raw_diagonal_bound import CERT,FIBRES,FIT,NORM,UNIT,ceil,digest,geom,mixture_energies,read
from h1_strip_free_prices import FORMS

OBSTRUCTION=Path('h1_outer_pair_obstruction.json')
OUTPUT=Path('h1_outer_matching.json')
RES=10**15


def maximize(weights, limit):
    """Exact upper certificate for maximum weight with at most limit disjoint real edges."""
    n,cols=weights.shape
    bonus=int(weights.max())+1
    W=np.column_stack((weights,np.full((n,n-limit),bonus,np.int64)))
    rows,chosen=linear_sum_assignment(W,maximize=True)
    assert np.array_equal(rows,np.arange(n)) and len(set(chosen))==n
    w=W[rows,chosen]
    # Columns are allowed to go unmatched. Zero prices on unused columns
    # plus equality on chosen edges certify the assignment LP bound exactly.
    q=np.zeros(W.shape[1],np.int64)
    assert 4*n*(bonus+1)<2**62
    for _ in range(n+1):
        new=np.maximum(q,np.max(W+(q[chosen]-w)[:,None],axis=0))
        if np.array_equal(new,q):
            break
        q=new
    p=w-q[chosen]
    assert min(q)>=0 and (p[:,None]+q[None,:]>=W).all()
    assert int(p.sum())+int(q.sum())==int(w.sum())
    assert np.count_nonzero(chosen>=cols)==n-limit
    picked=[(i,int(j)) for i,j in enumerate(chosen) if j<cols and weights[i,j]>0]
    upper=int(w.sum())-(n-limit)*bonus
    assert upper==sum(int(weights[i,j]) for i,j in picked)
    return upper,picked


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    cert,fibres,norm,prior=map(read,(CERT,FIBRES,NORM,OBSTRUCTION))
    for f in (CERT,FIBRES,NORM,FIT,FORMS,FORMS.with_suffix('.npz')):
        assert prior['inputs'][f.name]==digest(f)
    x,y=[np.array(prior['frozen_full'][k],int) for k in ('left_groups','right_groups')]
    _,last,top,_=native_layout(fibres,cert)
    h=Q(norm['step'])*geom.RHO*UNIT
    radius=np.array([int(ceil((int(i)+37)*h)) for i in last])
    sums=radius[x,None]+radius[None,y]
    raw=mixture_energies(FORMS,FIT)
    ideal=sum(raw[:,0])
    e=[sum(raw[g,0]) for g in cert['groups']]
    assert str(ideal)==prior['ideal_frozen_score'] and ideal>1
    lo=np.empty(sums.shape,np.int64)
    hi=lo.copy()
    for i,a in enumerate(x):
        for j,b in enumerate(y):
            gain=4*e[a]*e[b]*RES**2
            low=isqrt(gain.numerator//gain.denominator)
            lo[i,j]=low
            hi[i,j]=low+int(low*low<gain)

    def solve(mask, limit):
        upper,chosen=maximize(np.where(mask,hi,0),limit)
        lower=sum(int(lo[i,j]) for i,j in chosen)
        assert upper-lower<=limit
        return lower,upper,chosen

    def crosses(mask,k):
        lower,upper,_=solve(mask,k)
        if Q(lower,RES)>ideal-1:
            return True
        assert Q(upper,RES)<ideal-1
        return False

    def record(mask,n):
        low,high,pairs=solve(mask,n)
        return dict(pairs=[[int(x[i]),int(y[j])] for i,j in pairs],maximum_gain_numerators=[low,high],
                    upper_score_trillionths=int(ceil((ideal-Q(low,RES))*10**12)))

    def fewest(mask):
        low,high=0,len(x)
        assert crosses(mask,high)
        while high-low>1:
            mid=(low+high)//2
            if crosses(mask,mid):high=mid
            else:low=mid
        assert not crosses(mask,low)
        return dict(minimum_disjoint_pairs=high,previous_maximum_gain_upper=solve(mask,low)[1],
                    **record(mask,high))

    # Grant the entire proposed staircase exactly, regardless of its error
    # allowance. This makes the following adverse example more demanding.
    stair=[(2510000,2630000),(2525000,2625000),(2540000,2610000),(2555000,2600000)]
    available=np.ones(sums.shape,bool)
    for a,b in stair:
        available &= ~((radius[x,None]<=a)&(radius[None,y]<=b)&(top[None,y]<=47317))
    ticks=sorted(set(map(int,sums.flat)))
    low,high=0,len(ticks)-1
    assert crosses(sums>ticks[low],len(x)) and not crosses(sums>ticks[high],len(x))
    while high-low>1:
        mid=(low+high)//2
        if crosses(sums>ticks[mid],len(x)):low=mid
        else:high=mid
    paths=[Path(__file__),OBSTRUCTION,CERT,FIBRES,NORM,FIT,FORMS,FORMS.with_suffix('.npz'),
           Path('h1_graded_cross_block.py'),Path('h1_cover_convergence.py')]
    out=dict(scope='Finite adverse assignments on matched pairs for the frozen trial only. Every other affine entry may be ideal. These ceilings do not bound the true arithmetic forms.',
             inputs={p.name:digest(p) for p in paths},gain_scale=RES,
             group_radius_tick='1e-7 nominal',all_outer=fewest(np.ones_like(available)),
             staircase_radius_limits=stair,staircase_right_fragment_limit=47317,after_staircase=fewest(available),
             last_obstructed_cutoff=ticks[high]-1,first_nonobstructed_cutoff=ticks[high],
             critical_witness=record(sums>ticks[high]-1,len(x)),
             first_nonobstructed_maximum_gain_upper=solve(sums>ticks[high],len(x))[1])
    out=json.loads(json.dumps(out))
    if args.check:assert out==read(OUTPUT)
    else:OUTPUT.write_text(json.dumps(out,indent=2)+'\n',newline='\n')
    print('minimum disjoint pairs',out['all_outer']['minimum_disjoint_pairs'],out['after_staircase']['minimum_disjoint_pairs'],
          'critical radius sum',ticks[high],'after-staircase ceiling',out['after_staircase']['upper_score_trillionths'],flush=True)


if __name__=='__main__':
    main()
