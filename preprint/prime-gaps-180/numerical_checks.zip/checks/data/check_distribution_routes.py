"""Identify sufficient Type II and III estimates on the 180 trial's frozen modulus bands."""
from bisect import bisect_left
from collections import Counter
from fractions import Fraction as Q
import argparse
import gzip
import json
from math import ceil

import numpy as np
from pathlib import Path

from check_b2_arithmetic_permissions import HERE, DATA, TAU, UNIT, source_tests
from h1_bilinear_ladders import weak_engine
from h1_mass_band_prices import geom
from h1_multilevel_anchor_audit import refinement


def check_incidence_window(omega, delta, low, high, retreat=Q(1, 10**14)):
    """Check the hypotheses of the individual 182 dyadic lemmas at working parameters."""
    eps_cap = Q(1, 10**120)
    w, d = omega + retreat, delta + retreat
    assert 0 < Q(1, 2)-low < Q(1, 4) and low < high
    assert eps_cap < min(retreat, d/10**100, Q(1, 1000))
    assert w < Q(1, 16) and d < Q(1, 8)
    assert 12*w+6*d < low and high < Q(1, 2)-2*w
    assert 2*high+4*w+2*d < 1 and 16*w+7*d < low
    assert Q(3, 2)+40*w+16*d < 5*low
    assert max(Q(1, 4)+4*w+d, 8*w+2*d)+100*eps_cap < low
    assert high < Q(1, 2)-2*w-50*eps_cap
    assert 68*w+20*d < 1 and Q(1, 4)+14*w+4*d+100*eps_cap < high


def check_sharp_source(order, omega, delta, a, smooth, high):
    """Check the stricter constants in the complete sharp-minorant assembly."""
    tau = TAU/4
    sigma_dist = Q(1, 2)-a+TAU
    sigma_three = Q(2159, 25000)-TAU/2
    w, d = omega+Q(1, 10**14), delta+Q(1, 10**14)
    assert a == Q('.41361') and smooth == Q('.34941')
    assert 0 < tau <= TAU and Q(1, 2)-a+tau < sigma_dist < Q(1, 4)
    assert 0 < sigma_three < Q(2159, 25000)-tau
    assert w < Q(1, 12) and Q(1, 2)+2*w < Q('.53')
    assert Q(1, 4)+7*w+2*d < smooth-tau
    assert min(source_tests(order, w, d, a, smooth, high).values()) > 0
    # The literal lower-order alternatives in SharpGuards are order-specific.
    if order in (1, 2):
        assert 68*w+14*d < 1
        lhs = 54*w+15*d+5*sigma_dist if order == 1 else 56*w+16*d+4*sigma_dist
        assert lhs < 1
    if order == 3:
        # The source theorem needs the bilinear estimate at the retreated w,d.
        # Its incidence proof takes a second, strictly larger working pair.
        check_incidence_window(w, d, Q(1, 2)-sigma_dist, high)
        assert w < Q(3, 200) and Q(1, 2)-sigma_dist <= Q('.41361')
    lifted = max(w, (1-2*d)/108+TAU)
    assert 108*lifted+2*d > 1
    assert Q(1, 30)+56*lifted/15+4*d/15 < sigma_three < Q(1, 6)


def classify(order, hi, ticks, a, smooth, cut, handoff):
    delta = Q(ticks, UNIT)
    omega = (Q(hi, UNIT) - Q(1, 2)) / 2
    assert Q(23, 100) < 1-a-smooth < a < Q(42, 100) and Q(hi, UNIT) < Q(53, 100)
    if cut is None:
        check_sharp_source(order, omega, delta, a, smooth, handoff)
    assert 0 < omega < Q(1, 12) and delta > 0
    assert min(source_tests(order, omega, delta, a, smooth, handoff).values()) > 0
    upper = 1-a
    zeta = upper - smooth
    sigma = Q(1, 2)-a-TAU
    # The literal theorems require all three pair and individual size bounds.
    assert 0 < sigma < Q(1, 6) and 2*sigma < zeta and smooth < Q(1, 2)-sigma
    assert Q(1, 2)+sigma < upper
    bilinear = Q(1, 2)-a+TAU
    # Leave room to attach a subpower presieve before the internal dyadic retreat.
    padding = Q(1, 2*10**14)
    w_outer, d_outer = omega+padding, delta+padding
    if cut is not None:
        # FamilyGuards.gap is strict. Its collar can be smaller than the
        # displacement defining the bilinear exponent.
        family_collar = TAU/2
        assert 1 <= order and 0 < omega and 0 < delta and 0 < padding
        assert 0 < family_collar <= Q(1, 10**10)
        assert Q(1, 2)-a+family_collar < bilinear
        assert w_outer < Q(1, 12)
        assert Q(1, 4)+7*w_outer+2*d_outer < smooth-family_collar
    assert 68*w_outer+14*d_outer < 1
    assert Q(1, 4)+7*w_outer+2*d_outer < smooth-TAU
    assert Q(1, 2)+2*w_outer < upper-TAU and w_outer < Q(1, 12)
    lower_order = 54*omega+15*delta+5*bilinear < 1
    if order >= 2:
        lower_order |= 56*omega+16*delta+4*bilinear < 1
    assert lower_order or order == 3
    if not lower_order:
        check_incidence_window(omega, delta, a-TAU, handoff)
        # Directly supply the FamilyGuards bilinear estimate at the first
        # positive retreat. Its WorkingWindow takes one more half-step.
        check_incidence_window(w_outer, d_outer, a-TAU, handoff, retreat=padding)
    else:
        assert (54*w_outer+15*d_outer+5*bilinear < 1 or
                (order >= 2 and 56*w_outer+16*d_outer+4*bilinear < 1))

    # Raising the level is permitted for the Type III subproblem alone.
    enlarged = max(omega, (1-2*delta)/108 + TAU)
    assert enlarged < Q(1, 12) and 108*enlarged+2*delta > 1
    if sigma > Q(1, 18)+28*omega/9+2*delta/9:
        route = 'Polymath 2.8(v)'
    elif sigma > Q(1, 30)+56*enlarged/15+4*delta/15:
        route = 'companion Theorem 1.1'
    else:
        route = 'decoupled extraction'

    assert zeta > Q(1, 5) and smooth < Q(2, 5)
    if cut is None:
        mu = 1+Q(1, 10**6)-3*upper/2
    else:
        assert zeta < cut < upper/2
        mu = 1+Q(1, 10**6)-2*upper+cut
        # CoefficientGuards for the localized product at the nominal exponent.
        collar = Q(1, 10**12)
        selected_sigma = Q(2, 3) * (Q(1, 4)-mu)
        lifted = max(omega, (1-2*delta)/108 + Q(1, 10**14))
        assert 0 < a-4*collar and a+collar <= Q(1, 2)
        assert 0 < Q(1, 2)-(a-4*collar) < bilinear < Q(1, 2)
        assert 0 < smooth-4*collar <= Q(1, 2)
        assert Q(1, 4)+7*omega+2*delta < smooth-4*collar
        assert omega <= lifted < Q(1, 12) and 108*lifted+2*delta > 1
        assert Q(1, 30)+56*lifted/15+4*delta/15 < selected_sigma < Q(1, 6)
        assert Q(3, 4)+3*selected_sigma/2 <= 2*(1-a)-cut
    theta = max(Q(13, 25), Q(hi, UNIT))
    s = (4-mu-4*theta+2*delta)/6
    assert 0 < mu < Q(1, 4) and 0 < s < Q(1, 2)
    A = 8-5*mu-14*theta-2*delta
    B = 27*theta+delta-14
    extra = 3*mu/8+3*theta/4+3*s/16-Q(1, 2)
    assert extra == -(11*A+2*B+10*delta)/160
    saving = matrix_saving(mu, theta, delta, s)
    if route == 'decoupled extraction':
        assert min(A, B, saving) > 0
    sampled_route, sampled_margin = sampled_product_range(omega, delta, mu)
    retreat = Q(1, 10**14)
    working_theta, working_delta = theta+2*retreat, delta+retreat
    scale = (4-mu-4*working_theta+2*working_delta)/6
    assert 0 < scale < Q(1, 2)
    working_saving = matrix_saving(mu, working_theta, working_delta, scale)
    assert working_saving > 0
    gram = elementary_gram_feasible(mu, working_theta, working_delta)
    return ('classical bilinear' if lower_order else 'incidence Type II', route, saving,
            sampled_route, sampled_margin, working_saving, gram,
            axis_completion(mu, working_theta, working_delta, gram))


def matrix_saving(mu, theta, delta, s):
    terms = (mu/2+3*theta/2+s/2-1, mu+3*theta/2-1,
             3*mu/8+theta-s/4-Q(1, 2)+delta/4, mu/2+3*theta/4+s/8-Q(1, 2),
             mu/2+theta-5*s/16-Q(1, 2)+5*delta/16, 3*mu/8+3*theta/4+3*s/16-Q(1, 2))
    return -max(terms)


def elementary_gram_feasible(mu, theta, delta):
    """Solve the seven strict extraction inequalities for a common scale."""
    # Entries for each decreasing or increasing term, plus the scale endpoints.
    lower = max(0, 3*mu/2+4*theta-2+delta, (8*mu+16*theta-8+5*delta)/5,
                (4*mu+16*theta-8+3*delta)/3)
    upper = min(Q(1, 2), 2-mu-3*theta, 4-4*mu-6*theta, (8-6*mu-12*theta)/3)
    feasible = lower < upper and mu+3*theta/2 < 1
    if feasible:
        s = (lower+upper)/2
        assert matrix_saving(mu, theta, delta, s) > 0
        assert mu/4+theta-3*s/16-Q(1, 2)+3*delta/16 < 0
    return feasible


def axis_completion(mu, theta, delta, elementary):
    """Largest axis loss allowed by the strict moment and extraction inequalities."""
    lower = max(Q(0), 3*mu/2+4*theta-2+delta, (8*mu+16*theta-8+5*delta)/5)
    upper = min(Q(1, 2), 2-mu-3*theta, 4-4*mu-6*theta, (8-6*mu-12*theta)/3)
    assert lower < upper and delta < upper and mu+3*theta/2 < 1
    critical_beta = 1-(4*mu+7*theta-4)/(upper-delta)
    # beta is a loss above p^3 on a nonzero coordinate axis.
    def select(beta, use_elementary):
        floor = max(lower, delta, delta+(4*mu+7*theta-4)/(1-beta))
        if use_elementary:
            floor = max(floor, (4*mu+16*theta-8+3*delta)/3)
        if floor >= upper:
            return False
        scale = (floor+upper)/2
        assert matrix_saving(mu, theta, delta, scale) > 0
        assert mu/2+7*theta/8-(1-beta)*(scale-delta)/8 < Q(1, 2)
        if use_elementary:
            assert mu/4+theta-3*(scale-delta)/16 < Q(1, 2)
        return True

    assert select(Q(3, 8), False)
    assert select(Q(3, 8), True) == elementary
    coarse = select(Q(1, 2), False)
    assert coarse == (Q(1, 2) < critical_beta)
    assert select(Q(1, 2), True) == coarse
    return coarse, critical_beta


def sampled_product_range(omega, delta, mu):
    """Test the product-length input of both sampled fine-band theorems."""
    retreat = Q(1, 10**14)
    w, d = omega + retreat, delta + retreat
    sigma = Q(2, 3) * (Q(1, 4) - mu)
    assert Q(3, 4) + 3*sigma/2 == 1-mu
    assert 0 < sigma < Q(1, 6) and 0 < w < Q(1, 12) and 0 < d
    v = max(w, (1-2*d)/108 + retreat)
    assert 1 < 108*v + 2*d
    margin = sigma - (Q(1, 30) + 56*v/15 + 4*d/15)
    assert margin > 0
    if sigma > Q(1, 18) + 28*w/9 + 2*d/9:
        return '186 sampled theorem', margin
    return '182 sampled theorem with local Fourier hypothesis', margin


def retained_radius_bounds():
    """Enclose the largest nominal physical erasure in each group of the B2 trial."""
    from h1_degree6_native_schur_support import replay_limits
    from h1_signed_gate_fibre import GROUPS, stored_frame

    frame = stored_frame()
    groups = json.loads(GROUPS.read_bytes())['groups']
    owner = np.full(len(frame['energies']), len(groups))
    for i, sectors in enumerate(groups):
        owner[sectors] = i
    limits = replay_limits(2)
    step = frame['step'] * geom.RHO * UNIT
    radius = np.zeros(len(groups)+1, dtype=np.int64)
    lower_cap = 0
    for cap in frame['caps']:
        last = next(j for c, j in limits if c >= cap)
        # The full maximum can exceed the retained maximum. Its radial cutoff
        # is then smaller, so using this retained class's own cutoff is safe.
        indices = np.arange(lower_cap, last+1)
        sectors = frame['layout'](cap, indices+1)
        valid = sectors >= 0
        largest = np.full(len(radius), -1, dtype=np.int64)
        np.maximum.at(largest, owner[sectors[valid]], indices[valid])
        for i in np.flatnonzero(largest >= 0):
            top = ceil((int(largest[i])+38)*step)
            radius[i] = max(radius[i], top)
        lower_cap = int(cap)
    return radius[:-1]


def check_prime_source(schedule, refined):
    """Literal PrimeAnalyticGuards182 at the stored and adaptive P endpoints."""
    assert schedule['channel'] == refined['channel'] == 'P'
    widths = {row[1]: row[2:] for row in schedule['rows']}
    mesh = refinement(geom.fixed.old_input_slacks)[0]
    assert len(widths) == refined['bands'] and widths.keys().isdisjoint(refined['extra_endpoints'])
    widths.update({hi: mesh(hi) for hi in refined['extra_endpoints']})
    retreat = Q(1, 10**12)
    sigma = Q(1, 10) + retreat
    counts = Counter()
    for hi, ds in widths.items():
        for order, ticks in enumerate(ds, 1):
            if ticks == 0:
                continue
            # Literal natural-number hypothesis of prime_guards_of_ticks.
            assert UNIT == 10**7 and hi > UNIT//2 and ticks > 0
            c1, c2, limit = ((54,30,UNIT), (140,80,3*UNIT), (120,80,3*UNIT))[order-1]
            assert c1*(hi-UNIT//2) + c2*ticks <= limit-1
            omega = (Q(hi, UNIT) - Q(1, 2)) / 2
            delta = Q(ticks, UNIT)
            u, v = omega + retreat, delta + retreat
            assert 0 < omega and 0 < delta and 0 < retreat
            assert u < Q(1, 4) and v < Q(1, 4) + u and 2*u < sigma < Q(1, 2)
            if order == 3:
                assert 240*u + 80*v < 3
            else:
                assert 68*u + 14*v < 1 and Q(1, 18) + 28*u/9 + 2*v/9 < sigma
                if order == 1:
                    assert 54*u + 15*v + 5*sigma < 1
                else:
                    assert order == 2 and 56*u + 16*v + 4*sigma < 1
            counts[order] += 1
    return len(widths), dict(sorted(counts.items()))


def run():
    schedules = json.loads((HERE.parents[1]/'lean'/'data'/'h1_multilevel_order_schedules.json').read_bytes())['channels']
    refined = json.loads((HERE/'arithmetic_gate_check.json').read_bytes())
    with gzip.open(DATA/'ml12_w25.json.gz') as f:
        cert = json.load(f)
    prime_endpoints, prime_orders = check_prime_source(schedules[0], refined[0])
    print('Genuine-prime source guards:', prime_endpoints, 'endpoints, orders', prime_orders)
    book = json.loads((DATA/'book_port.json').read_bytes())
    indexed = {Q(r['theta']): r for r in book['rows']}
    params = [(Q('.41361'), Q('.34941'), None, Q('.45'), geom.fixed.new_input_slacks)]
    for level, cut in zip(cert['levels'], cert['cuts'], strict=True):
        row = indexed[Q(level)]
        guard = weak_engine(book, Q(level), Q('.1668')).fixed.new_input_slacks
        params.append((Q(row['a']), Q(row['I']), Q(cut), Q('.46'), guard))

    radius = retained_radius_bounds()
    pair_radius = radius[:, None]+radius[None, :]
    output = []
    for ch, extra, (a, smooth, cut, handoff, guard), affine in zip(
            schedules[1:], refined[1:], params, cert['affine'][1:14], strict=True):
        assert ch['channel'] == extra['channel']
        # Literal ordinary and signed smoothness hypotheses. The central
        # subset interval is widened symmetrically before selecting a block.
        assert Q('.1668') + 2*a < 1 and a <= Q('.417')
        assert cut is None or Q('.1668') <= cut
        edge = a - Q(1, 10**12)
        assert edge <= Q(1, 2) and Q(1, 2)-edge < Q(1, 2)-a+TAU
        zeta = 1-smooth-a
        assert Q('.41361') <= a <= Q('.41657')
        assert Q('.23') < zeta < Q('.24') and 4*a-1 < 3*zeta
        mesh = refinement(guard)[0]
        widths = {r[1]: r[2:] for r in ch['rows']}
        assert len(widths) == extra['bands'] and widths.keys().isdisjoint(extra['extra_endpoints'])
        widths.update({hi: mesh(hi) for hi in extra['extra_endpoints']})
        counts = Counter()
        sampled_counts = Counter()
        smallest_sampled_margin = None
        smallest_matrix_saving = None
        gram_counts = Counter()
        axis_counts = Counter()
        weakest_axis = None
        worst = None
        first = None
        ends = [r[1] for r in ch['rows']]
        for hi, ds in sorted(widths.items()):
            for order, ticks in enumerate(ds, 1):
                if not ticks:
                    continue
                ii, iii, saving, sampled, margin, matrix, gram, axis = classify(
                    order, hi, ticks, a, smooth, cut, handoff)
                counts[ii+' / '+iii] += 1
                sampled_counts[sampled] += 1
                gram_counts[(sampled, gram)] += 1
                coarse_axis, critical_beta = axis
                axis_counts[(sampled, coarse_axis)] += 1
                axis_point = (critical_beta, hi, ticks, order)
                if weakest_axis is None or axis_point < weakest_axis:
                    weakest_axis = axis_point
                matrix_point = (matrix, hi, ticks, order)
                if smallest_matrix_saving is None or matrix_point < smallest_matrix_saving:
                    smallest_matrix_saving = matrix_point
                point = (margin, hi, ticks, order)
                if smallest_sampled_margin is None or point < smallest_sampled_margin:
                    smallest_sampled_margin = point
                if iii == 'decoupled extraction':
                    start = ch['rows'][bisect_left(ends, hi)][0]
                    first = start if first is None else min(first, start)
                if iii == 'decoupled extraction' and (worst is None or saving < worst[0]):
                    worst = saving, hi, ticks, order
        used = np.asarray(affine, dtype=np.int64) != 0
        assert np.array_equal(used, used.T)
        live = used & (radius[:, None] > 0) & (radius[None, :] > 0)
        reaching = live & (pair_radius > first) if first is not None else np.zeros_like(live)
        output.append(dict(first_potential_decoupled_band_start=first,
                           nonzero_unordered_pairs=int(np.triu(used).sum()),
                           potentially_decoupled_unordered_pairs=int(np.triu(reaching).sum()),
                           maximum_nominal_pair_ticks=int(pair_radius[live].max()),
                           channel=ch['channel'], parameters=dict(a=str(a), I=str(smooth),
                           parent_cut=str(cut) if cut else None), endpoints=len(widths),
                           counts=dict(sorted(counts.items())),
                           sampled_counts=dict(sorted(sampled_counts.items())),
                           elementary_gram_counts=[dict(sampled_source=src, feasible=ok, count=n)
                               for (src, ok), n in sorted(gram_counts.items())],
                           coarse_axis_counts=[dict(sampled_source=src, feasible=ok, count=n)
                               for (src, ok), n in sorted(axis_counts.items())],
                           least_axis_loss_ceiling=dict(beta=str(weakest_axis[0]), hi=weakest_axis[1],
                               delta_ticks=weakest_axis[2], order=weakest_axis[3]),
                           least_working_matrix_saving=dict(saving=str(smallest_matrix_saving[0]),
                             hi=smallest_matrix_saving[1], delta_ticks=smallest_matrix_saving[2],
                             order=smallest_matrix_saving[3]),
                           least_sampled_182_margin=dict(margin=str(smallest_sampled_margin[0]),
                             hi=smallest_sampled_margin[1], delta_ticks=smallest_sampled_margin[2],
                             order=smallest_sampled_margin[3]),
                           least_decoupled_saving=(dict(saving=str(worst[0]), hi=worst[1],
                             delta_ticks=worst[2], order=worst[3]) if worst else None)))
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    output = run()
    totals = Counter()
    for row in output:
        totals.update(row['counts'])
    print(dict(sorted(totals.items())))
    if args.output:
        args.output.write_text(json.dumps(output, indent=2)+'\n')
