"""Uncertified floating-point H1 hybrid cap-form optimization with a graph Hamiltonian.

No quadrature enclosure or support-restoration certificate is supplied here.
The public backend is the checksum-pinned external numerical release of
romyar1/prime-gaps-lean. It remains unchanged in ../deps.
"""
from pathlib import Path
from fractions import Fraction as Q
import argparse
import hashlib
import json
import sys
import time
import numpy as np
from scipy.linalg import eigh
from scipy.optimize import minimize_scalar
from scipy.spatial.distance import cdist

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BACKEND = ROOT / 'deps/h1-182/prime-gaps-external-182/snapshot/prime_gaps_20260903'
sys.path.insert(0, str(BACKEND / 'experiments/fragment_ritz'))
from incidence_spline_ritz import SplineRitz
from incidence_source_cap_ritz import Ritz
from incidence_multicap_spline_ritz import basis_components, multicap_forms, scalar_replay
from incidence_subtraction_tail_scan import cap_shells


def make_model(dimension, intervals, specification, harmonic_beta=0.):
    # SourceRitz fixes k=39 in its call to Ritz. Override just this constructor
    # argument during initialization, then restore the unchanged backend method.
    # Subsequent geometry is constructed with the resulting r.k, including all
    # dimension-dependent cell offsets, moments, and normalization factors.
    original = Ritz.__init__
    def constructor(self, *args, **kwargs):
        kwargs['k'] = dimension
        original(self, *args, **kwargs)
    Ritz.__init__ = constructor
    try:
        r = SplineRitz(intervals, **{**specification,
            'radius_shift': Q(specification['radius_shift']),
            'old_total': Q(specification['old_total'])})
    finally:
        Ritz.__init__ = original
    assert r.k == dimension and r.n == intervals - dimension
    if harmonic_beta:
        assert harmonic_beta >= 0
        # exp[-(beta/k) sum_{i<j}(t_i-t_j)^2]
        # = exp[beta*(sum_i t_i)^2/k] product_i exp[-beta*t_i^2].
        # Apply BOTH factors, so this is an actual global harmonic interaction.
        r.g *= np.exp(-harmonic_beta*r.t*r.t)
        r.radial_values *= np.exp(harmonic_beta*r.sf*r.sf/r.k)[None,:]
        r.radial_products = np.array([r.radial_values[d]*r.radial_values[e]
                                     for d,e in r.radial_pairs])
        r.set_moment_tilt(r.tilt)
    return r


def graph_hamiltonian(r, limits, neighbours):
    # Node = (cap layer, angular signature, radial B-spline). Greville points
    # locate radial splines; signature multiplicities locate angular factors.
    features = []
    for limit in limits:
        for signature, radial in r.desc:
            greville = sum(float(x) for x in r.knots[radial+1:radial+1+r.spline_degree]) / r.spline_degree
            features.append([float(limit*r.exact_step), greville] +
                            [signature.count(j) for j in range(2, 9)])
    x = np.array(features)
    scales = np.std(x, axis=0)
    x = (x - np.mean(x, axis=0)) / np.where(scales > 0, scales, 1)
    dist = cdist(x, x, metric='sqeuclidean')
    np.fill_diagonal(dist, np.inf)
    ids = np.argsort(dist, axis=1)[:, :neighbours]
    sigma2 = float(np.median(np.take_along_axis(dist, ids, axis=1)))
    adjacency = np.zeros_like(dist)
    for i, js in enumerate(ids):
        adjacency[i, js] = np.exp(-dist[i, js] / max(sigma2, 1e-12))
    adjacency = np.maximum(adjacency, adjacency.T)
    laplacian = np.diag(adjacency.sum(axis=1)) - adjacency
    # All nodes couple to their common mean; add a harmonic well in normalized
    # node-feature space. Both terms, like the graph Laplacian, are PSD.
    n = len(x)
    global_coupling = np.eye(n) - np.ones((n,n))/n
    potential = np.diag(np.sum(x*x, axis=1) / x.shape[1])
    hamiltonian = laplacian + 0.1*global_coupling + 0.1*potential
    return hamiltonian, {'nodes': n, 'nearest_neighbours': neighbours,
        'edges': int(np.count_nonzero(np.triu(adjacency,1))),
        'global_coupling': 0.1, 'harmonic_potential': 0.1,
        'minimum_eigenvalue': float(eigh(hamiltonian, eigvals_only=True, subset_by_index=[0,0])[0])}


def optimize(gram, forms, hamiltonian, rho, kappa, cutoff, strengths):
    assert np.all(np.isfinite(gram)) and np.all(np.diag(gram)>0), 'Invalid mass matrix'
    diagonal = np.sqrt(np.diag(gram))
    normalized = gram / diagonal[:,None] / diagonal[None,:]
    ev, vec = eigh((normalized + normalized.T)/2)
    if ev[0] < -1e-8*ev[-1]:
        raise ArithmeticError('Mass matrix is significantly indefinite; quotient rejected')
    keep = ev > cutoff*ev[-1]
    W = vec[:,keep] / np.sqrt(ev[keep]) / diagonal[:,None]
    small = [(W.T@mat@W + (W.T@mat@W).T)/2 for mat in forms]
    # Graph acts on dimensionless coefficient amplitudes, after each basis
    # function has been normalized in the mass form.
    HW = diagonal[:,None]*W
    H = HW.T@hamiltonian@HW
    H = (H+H.T)/2
    h_scale = float(np.trace(H) / len(H))
    H /= h_scale
    size = len(H)
    rows, vectors = [], []
    for strength in strengths:
        def operator(ell):
            return rho*(small[0]+(1-ell)*small[1]+(1-1/ell)*kappa*small[2])-strength*H
        def objective(ell):
            return -float(eigh(operator(ell), eigvals_only=True, subset_by_index=[size-1,size-1])[0])
        grid = np.geomspace(.0001,.3,22)
        values = [objective(ell) for ell in grid]
        j = int(np.argmin(values))
        fit = minimize_scalar(objective, bounds=(grid[max(0,j-1)],grid[min(len(grid)-1,j+1)]),
                              method='bounded', options={'xatol':1e-10})
        ell = float(fit.x)
        eigenvalue, eigvector = eigh(operator(ell), subset_by_index=[size-1,size-1])
        v = W@eigvector[:,0]
        mass = float(v@gram@v)
        component = [float(v@M@v) for M in forms]
        raw = rho*(component[0]+(1-ell)*component[1]+(1-1/ell)*kappa*component[2])/mass
        row = {'strength':strength, 'cap_quotient_without_penalty':raw,
               'hybrid_lambda':ell, 'penalized_eigenvalue':float(eigenvalue[0]),
               'gap_from_one_before_restoration':raw-1, 'mass':mass,
               'forms':component}
        print(json.dumps({'event':'HARMONIC_OPTIMIZATION',**row}), flush=True)
        rows.append(row);vectors.append(v)
    return rows, vectors, {'rank':int(keep.sum()), 'basis':len(gram),
        'gram_min_eigenvalue':float(ev[0]), 'gram_max_eigenvalue':float(ev[-1]),
        'gram_relative_cutoff':cutoff, 'hamiltonian_scale':h_scale}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dimension', type=int, choices=range(38,47), default=38)
    p.add_argument('--intervals', type=int, default=8192)
    p.add_argument('--angular', type=int, default=6)
    p.add_argument('--neighbours', type=int, default=6)
    p.add_argument('--harmonic-beta', type=float, default=0.)
    p.add_argument('--caps', nargs='+', default=['.3788','.4745'])
    p.add_argument('--cutoff', type=float, default=1e-8)
    p.add_argument('--strengths', type=float, nargs='+', default=[0,1e-8,1e-6,1e-4,.01])
    p.add_argument('--load', type=Path)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args(); start = time.monotonic()
    prior_path = BACKEND / 'results/incidence_multicap_spline_a6_n32768.json'
    prior = json.loads(prior_path.read_text())
    spec = {**prior['specification'], 'angular':args.angular}
    r = make_model(args.dimension,args.intervals,spec,args.harmonic_beta)
    maximum = max(sh[2] for sh in r.shells['outer'])
    limits = sorted({min(maximum,int(Q(c)//r.exact_step)) for c in args.caps}|{maximum})
    assert min(limits)>0
    domains = {'L1':r.shells['enlarged']}
    for row in prior['supplied_domains']['domains']:
        domains[row['name']] = cap_shells(r,row['physical_radius'],row['delta'])
    identity = {'dimension':r.k,'intervals':r.N,'specification':spec,'limits':limits}
    if args.harmonic_beta:
        identity['harmonic_beta'] = args.harmonic_beta
    if args.caps!=['.3788','.4745']:
        identity['cap_thresholds'] = args.caps
    if args.load:
        saved = np.load(args.load)
        assert json.loads(str(saved['identity'])) == identity
        gram = saved['I']; forms = [saved[key] for key in ['J0','Jplus','KtailC']]
    else:
        gram, components, axes = basis_components(r, limits)
        forms = multicap_forms(r, components, axes, domains)
        del components
        np.savez_compressed(args.output.with_suffix('.npz'), I=gram,
            J0=forms[0],Jplus=forms[1],KtailC=forms[2],identity=json.dumps(identity))
    H, graph = graph_hamiltonian(r,limits,args.neighbours)
    rows,vectors,conditioning = optimize(gram,forms,H,r.rho,prior['kappa'],args.cutoff,args.strengths)
    best = int(np.argmax([row['cap_quotient_without_penalty'] for row in rows]))
    I, check_forms = scalar_replay(r,vectors[best],limits,domains)
    ell = rows[best]['hybrid_lambda']
    replay = r.rho*(check_forms[0]+(1-ell)*check_forms[1]+(1-1/ell)*prior['kappa']*check_forms[2])/I
    differences = [abs(a-b) for a,b in zip(check_forms,rows[best]['forms'])]
    assert abs(replay-rows[best]['cap_quotient_without_penalty']) < 2e-6
    out = {'status':'HEURISTIC_CAP_FORMS_ONLY_NOT_A_PRIME_GAP_PROOF',**identity,
           'graph':graph,'conditioning':conditioning,'rows':rows,'best_index':best,
           'independent_scalar_replay':float(replay),'scalar_form_differences':differences,
           'best_coefficients':vectors[best].tolist(),
           'source_release':'https://github.com/romyar1/prime-gaps-lean/releases/tag/external-numerics-20260909',
           'source_archive_sha256':'2960729efa8996538731820ce6cadc202831c8e98b2c0bdb14cfd19f33726f3b',
           'prior_sha256':hashlib.sha256(prior_path.read_bytes()).hexdigest(),
           'limitations':['No interval error enclosure.','Nonlargest support-restoration losses omitted.',
                          'Using the geometry at a new dimension requires a separate analytic audit.',
                          'A PSD penalty cannot increase the exact unpenalized optimum in a fixed basis.'],
           'seconds':time.monotonic()-start}
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'event':'COMPLETE','dimension':r.k,'quotient':float(replay),'seconds':out['seconds']}),flush=True)


if __name__ == '__main__':
    main()
