"""Lift coarse and fine dual certificates to their common refinement and optimize newly priced entries."""
import argparse
from decimal import Decimal
from fractions import Fraction as Q
from hashlib import sha256
import json
from math import floor,isqrt
from pathlib import Path
import numpy as np
from scipy.linalg import eigh
from scipy.optimize import minimize
from verify_pairing_envelope import SCALE,lower_factor,quantize


def digest(f):return sha256(f.read_bytes()).hexdigest()


def read(f,decimal=False):
    return json.loads(f.read_text(),parse_float=Decimal if decimal else float)


def owners(sol,n,fixed):
    index=np.full(n,-2,int);index[sol.get('resolved',fixed)]=-1
    for i,g in enumerate(sol['groups']):index[g]=i
    assert min(index)>=-1
    return index


def model(oldpath,newpath,oldd,newd):
    old,new=read(oldpath),read(newpath,True);s0,s1=read(oldd),read(newd)
    for file,sol in ((oldpath,s0),(newpath,s1)):
        if 'affine' in sol:assert sol['inputs'][file.name]==digest(file)
        else:assert sol['source']==file.name
    assert old['cells_sha256']==new['cells_sha256'] and old['band_rule']==new['band_rule']=='transfer'
    assert [(a['group'],a['axis'],a['threshold']) for a in new['targeted_splits'][:len(old['targeted_splits'])]]==[
        (a['group'],a['axis'],a['threshold']) for a in old['targeted_splits']]
    parent=list(range(len(old['codes'])))
    for row in new['targeted_splits'][len(old['targeted_splits']):]:
        parent.append(parent[row['group']])
    assert len(parent)==len(new['codes']);parent=np.array(parent)
    raw=np.array([[Q(x) for x in row] for row in new['sector_energies']],dtype=object)
    assert min(raw[:,0])>0
    masks=[np.array(new[k],bool) for k in ('prime_mask','minorant_mask')]
    for m,k in zip(masks,('prime_mask','minorant_mask')):
        assert np.all(~np.array(old[k],bool)[np.ix_(parent,parent)]|m)
    fixed=masks[0].all(1);active=np.flatnonzero(~fixed)
    oldfixed=np.flatnonzero(np.array(old['prime_mask'],bool).all(1))
    oldid=owners(s0,len(old['codes']),oldfixed)[parent];newid=owners(s1,len(raw),np.flatnonzero(fixed))
    assert min(oldid[active])>=0 and min(newid[active])>=0
    key=np.column_stack([oldid[active],newid[active]]+[m[np.ix_(active,active)] for m in masks])
    _,idx=np.unique(key,axis=0,return_inverse=True)
    groups=[active[idx==i] for i in range(idx.max()+1)];rep=np.array([g[0] for g in groups])
    e=np.array([raw[g].sum(0) for g in groups]);w=np.sqrt(e[:,0].astype(float))
    def lift(sol,ids,energy):
        if 'affine' in sol:
            A,R=[np.asarray(x,float)/SCALE for x in sol['affine']]
        else:
            L,B,H=[np.array(sol[k]) for k in ('dual_prime','dual_exceptional','dual_minorant')]
            A,R=L+H,H-B
        norm=np.sqrt([sum(energy[g]) for g in sol['groups']])
        v=w/norm[ids[rep]];ix=np.ix_(ids[rep],ids[rep])
        return (A[ix]*np.outer(v,v),R[ix]*np.outer(v,v))
    ref0=lift(s0,oldid,np.array(old['sector_energies'])[:,0]);ref1=lift(s1,newid,raw[:,0].astype(float))
    masks=[m[np.ix_(rep,rep)] for m in masks]
    return (e,masks,sum(raw[fixed,0])),ref0,ref1,groups


def bound(data,A,R):
    e,(p,m),fixed=data
    assert np.array_equal(A,A.T) and np.array_equal(R,R.T)
    assert not A[~(p|m)].any() and not R[~m].any() and not (A-R)[~p].any()
    w=np.array([isqrt(int(x*SCALE**2)) for x in e[:,0]],dtype=object)
    U,K=(e[:,1:]/e[:,0,None]).T
    cost=Q(0)
    for mat,cap in [(np.outer(w,w)-SCALE*A,U),(SCALE*R,K)]:
        correction,_=lower_factor(mat,cap);cost+=sum(correction*cap)
    tr=lambda v:Q(int(np.trace(v)),SCALE)
    err=max(U)*Q(2*sum(w)*len(w)+len(w)**2,SCALE**2)
    return fixed+tr(A)-max(k*tr(R) for k in (Q('.000093307088324061'),Q('.000093307088324062')))-cost-err


def splitting(data,A,R,steps):
    # Douglas-Rachford on the two scaled remainders. One proximal map is
    # a projection onto the entry constraints with a diagonal trace shift.
    # The other soft-thresholds only negative eigenvalues.
    e,(p,m),fixed=data;e=e.astype(float);w=np.sqrt(e[:,0]);I=np.eye(len(w))
    U,K=(e[:,1:]/e[:,0,None]).T;su=np.sqrt(np.outer(U,U));sk=np.sqrt(np.outer(K,K))
    D=su*np.outer(w,w);k=.0000933070883240615
    both=p&m;only=m&~p;mask=p|m
    def score(A,R):
        return (float(fixed)+A.trace()-k*R.trace()+
                np.minimum(eigh(D-su*A,eigvals_only=True,check_finite=False),0).sum()+
                np.minimum(eigh(sk*R,eigvals_only=True,check_finite=False),0).sum())
    def prox(X,t):
        ev,V=eigh(X,check_finite=False)
        v=V[:,ev<0]
        return X+(v*np.minimum(-ev[ev<0],t))@v.T
    best=(score(A,R),A,R);history=[]
    prices=None
    for tau in (1e-4,2e-5,4e-6,8e-7):
        _,A,R=best;X=D-su*A;Y=sk*R
        if prices is not None:X=X+tau*prices[0];Y=Y+tau*prices[1]
        for it in range(steps):
            a=(su*(D-X)+tau*I);r=sk*Y-tau*k*I
            A=np.where(mask,a/(su*su),0);R=np.where(both,r/(sk*sk),0)
            A[only]=R[only]=(a[only]+r[only])/(su[only]**2+sk[only]**2)
            H=D-su*A;J=sk*R
            if it%40==0 or it==steps-1:
                value=score(A,R)
                if value>best[0]:
                    best=(value,A,R);prices=((X-H)/tau,(Y-J)/tau)
            X+=1.65*(prox(2*H-X,tau)-H)
            Y+=1.65*(prox(2*J-Y,tau)-J)
        history.append(dict(stage='splitting',tau=tau,iterations=steps,best=best[0]))
        print(history[-1],flush=True)
    return best[1],best[2],history


def optimize(data,ref0,ref1,iterations,steps):
    e,(p,m),fixed=data;e=e.astype(float);w=np.sqrt(e[:,0]);ww=np.outer(w,w)
    n=len(w);I=np.eye(n);k=.0000933070883240615
    U,K=(e[:,1:]/e[:,0,None]).T
    su=np.sqrt(np.outer(U,U));sk=np.sqrt(np.outer(K,K))
    i,j=np.triu_indices(n);a=(p|m)[i,j];both=(p&m)[i,j];only=(m&~p)[i,j]
    iA,jA=i[a],j[a];iR,jR=i[both],j[both];iM,jM=i[only],j[only]
    # A multiplies the prime form after both affine identities are added;
    # R multiplies the exceptional form and must equal A on minorant-only entries.
    amp=np.maximum(np.outer(w,w),1e-9)
    sa=np.sqrt(amp[iA,jA]);sr=np.sqrt(amp[iR,jR]);nc=len(iA)
    def pack(A,R):return np.r_[A[iA,jA]/sa,R[iR,jR]/sr]
    def matrices(x):
        A=np.zeros_like(ww);R=A.copy()
        A[iA,jA]=A[jA,iA]=x[:nc]*sa;R[iR,jR]=R[jR,iR]=x[nc:]*sr
        R[iM,jM]=R[jM,iM]=A[iM,jM]
        return A,R
    def objective(x,tau):
        A,R=matrices(x)
        obj=float(fixed)+A.trace()-k*R.trace()
        grads=[]
        for M,scale,sgn,c in [(ww-A,su,-1,1),(R,sk,1,-k)]:
            ev,V=eigh(M*scale,check_finite=False,driver='evr')
            if not tau:
                obj+=ev[ev<0].sum()
                continue
            low=ev<=-tau;mid=(ev>-tau)&(ev<tau)
            obj+=ev[low].sum()-np.square(tau-ev[mid]).sum()/(4*tau)
            W=V[:,ev<tau]
            grad=(W*np.minimum(1,(tau-ev[ev<tau])/(2*tau)))@W.T
            grads.append(c*I+sgn*scale*grad)
        if not tau:return obj
        gA,gR=grads;gA[iM,jM]+=gR[iM,jM]
        grad=np.r_[gA[iA,jA]*np.where(iA==jA,1,2)*sa,gR[iR,jR]*np.where(iR==jR,1,2)*sr]
        return -obj,-grad
    x0=pack(*ref0);x1=pack(*ref1)
    best=max((x0,x1),key=lambda x:objective(x,0))
    history=[dict(stage='coarse',lower=objective(x0,0)),dict(stage='fine',lower=objective(x1,0))]
    # New entries can be valuable even if the cold fit has not converged
    # on all the old entries. Fit their scale separately before descent.
    dirs=[]
    for sl in (slice(0,nc),slice(nc,None)):
        for mask in (x0[sl]==0,x0[sl]!=0):
            v=np.zeros_like(x0);v[sl]=np.where(mask,x1[sl]-x0[sl],0.)
            dirs.append(v)
    dirs=np.array(dirs)
    def small(y):
        f,g=objective(x0+y@dirs,3e-9)
        return f,dirs@g
    res=minimize(small,np.zeros(4),jac=True,method='L-BFGS-B',bounds=[(-2,4)]*4,options={'ftol':1e-14,'maxiter':60})
    warm=x0+res.x@dirs
    if objective(warm,0)>objective(best,0):best=warm
    history.append(dict(stage='mixed',lower=objective(best,0),parameters=res.x.tolist()))
    for tau in (3e-7,3e-8,2e-9):
        if iterations<=0:break
        res=minimize(lambda x:objective(x,tau),best,jac=True,method='L-BFGS-B',
                     options={'ftol':1e-16,'gtol':1e-10,'maxiter':iterations,'maxcor':12,'maxls':35})
        score=objective(res.x,0)
        if score>objective(best,0):best=res.x
        history.append(dict(stage='smooth',tau=tau,iterations=int(res.nit),lower=score,best=objective(best,0)))
        print(history[-1],flush=True)
    A,R=matrices(best)
    if steps:
        A,R,extra=splitting(data,A,R,steps)
        history+=extra
    return [quantize(A),quantize(R)],history


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('old','new','oldfit','newfit'):p.add_argument(name,type=Path)
    p.add_argument('--iterations',type=int,default=150);p.add_argument('--splitting',type=int,default=0)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--check',action='store_true')
    a=p.parse_args();files=(a.old,a.new,a.oldfit,a.newfit);data,ref0,ref1,groups=model(*files)
    hashes={f.name:digest(f) for f in files}
    if a.check:
        j=read(a.output);assert j['inputs']==hashes and j['groups']==[g.tolist() for g in groups]
        A,R=[np.array(v,dtype=object) for v in j['affine']]
        assert j['lower_billionths']==floor(10**9*bound(data,A,R))
    else:
        (A,R),history=optimize(data,ref0,ref1,a.iterations,a.splitting)
        j=dict(scope='Lower certificate on the finite sector energies; source predicates and quadrature are separate.',
               inputs=hashes,groups=[g.tolist() for g in groups],history=history,
               lower_billionths=floor(10**9*bound(data,A,R)),affine=[A.tolist(),R.tolist()])
        a.output.write_text(json.dumps(j,separators=(',',':'))+'\n')
    print('states',len(groups),'lower',j['lower_billionths'],flush=True)


if __name__=='__main__':main()
