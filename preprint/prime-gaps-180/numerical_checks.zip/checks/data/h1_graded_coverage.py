"""Assemble a disjoint partial H1 restoration budget and audit its uncovered pairs."""
import argparse
from fractions import Fraction as Q
from itertools import combinations, product
from pathlib import Path
import json

import numpy as np

from h1_graded_cross_block import native_layout
from h1_raw_diagonal_bound import CERT,FIBRES,NORM,TABLE,UNIT,ceil,ceiling_sqrt,digest,geom,read,sci_upper

GLOBAL=Path('h1_strip_free_continuous_cost.json')


def monotone_trace(tails,opposite):
    """Upper-bound sum sqrt(e_j M_j) when suffix sums of the e_j are bounded."""
    assert len(tails)==len(opposite) and all(a>=b>=0 for a,b in zip(tails,tails[1:]))
    active=next((i for i,v in enumerate(tails) if not v),len(tails))
    tails,opposite=tails[:active],opposite[:active]
    pools=[]
    for i,(b,m) in enumerate(zip(tails,opposite)):
        difference=b-(tails[i+1] if i+1<len(tails) else 0)
        pools.append((difference,m))
        # The optimal AM-GM comparison weights sqrt(m/d) must be increasing.
        while len(pools)>1:
            d0,m0=pools[-2]; d1,m1=pools[-1]
            if m0*d1<=m1*d0:break
            pools[-2:]=[(d0+d1,m0+m1)]
    return sum((ceiling_sqrt(d*m) for d,m in pools),Q(0))


def optimized_square(row,total_energy):
    levels={int(t):Q(v) for t,v in row['threshold_energy_uppers'].items()}
    W=row['common_budget']
    offsets=row['offsets'][1:]
    best=None
    for size in range(len(offsets)+1):
        for subset in combinations(offsets,size):
            breaks=(0,*subset)
            positive=[levels[W+d] for d in breaks]
            light=[levels[W-d] for d in subset]+[total_energy]
            candidate=monotone_trace(positive,light)
            if best is None or candidate<best[0]:best=candidate,breaks
    mixed,used=best
    bound=Q(0)
    for k,C,mu in zip(map(Q,row['signed_multiplier_bounds']),map(Q,row['operator_bounds']),map(Q,row['mean_bounds'])):
        bound+=k*(2*ceiling_sqrt(mu*C)*mixed+(C+mu)*levels[W])
    return min(bound,Q(row['three_channel_loss_upper'])),dict(offsets=list(used),mixed_upper=sci_upper(mixed))


def direct_trace_checks():
    # Square integer masses turn the actual mixed sum into an integer.
    # Slack in individual suffix bounds exercises adjacent pooling.
    checks=0
    for roots in product(range(3),repeat=3):
        actual=[Q(v*v) for v in roots]
        suffix=[sum(actual[i:]) for i in range(3)]
        for slack in product(range(2),repeat=3):
            tails=[suffix[i]+sum(slack[i:]) for i in range(3)]
            for other in ((1,2,4),(3,1,2),(0,3,1)):
                bound=monotone_trace(tails,[Q(v*v) for v in other])
                assert sum(x*y for x,y in zip(roots,other))<=bound
                checks+=1
    return checks


def optimized_cross(row):
    breaks=row['grade_breaks']
    left={int(k):Q(v) for k,v in row['left_tail'].items()}
    right={int(k):Q(v) for k,v in row['right_tail'].items()}
    W=row['common_budget']
    assert max(row['actual_fragment_ticks']) < min(breaks[0], 2*W-breaks[-1])
    def solve(points,tails,other):
        # Shortest-path candidate and the full partition, in either direction.
        # The final bound uses the disjoint masses of the chosen first side.
        best=[(Q(0),[points[0]])]
        for j,b in enumerate(points[1:],1):
            val,path=min(((v+ceiling_sqrt(tails[points[i]]*other[2*W-b]),p+[b])
                         for i,(v,p) in enumerate(best)),key=lambda x:x[0])
            best.append((val,path))
        candidates=[points,best[-1][1]]
        for stride in (2,3,4):
            candidates.append(sorted(set(points[::stride]+[points[-1]])))
        return min((monotone_trace([tails[t] for t in p[:-1]],[other[2*W-t] for t in p[1:]]),p)
                   for p in candidates)
    mixed,path=solve(breaks,left,right)
    reverse,rpath=solve([2*W-t for t in reversed(breaks)],right,left)
    direction='left'
    if reverse<mixed:mixed,path,direction=reverse,rpath,'right'
    previous=Q(row['three_channel_loss_upper'])
    stored=row['mixed_energy_upper']
    if stored=='0':return Q(0),dict(direction=direction,grade_breaks=path)
    # sci_upper rounds upwards to an integer multiple of the printed
    # power of ten. The producer's charge before rounding is exactly
    # proportional to its mixed sum, so this is an upper coefficient.
    unit=Q(10)**int(stored.split('e')[1])
    lower=Q(stored)-unit
    assert lower>0
    return min(previous,previous*mixed/lower),dict(direction=direction,grade_breaks=path,mixed_upper=sci_upper(mixed))


def provenance(row,root):
    for name,expected in row['inputs'].items():
        path=root/name
        if name=='bilinear_minorant.json':path=root.parent/'sensitivity'/name
        assert digest(path)==expected,(name,expected)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--square',type=Path,required=True)
    parser.add_argument('--crosses',type=Path,nargs='*',default=[])
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    cert,full,fibres,norm=map(read,(CERT,GLOBAL,FIBRES,NORM))
    provenance(full,Path.cwd())
    _,last,_,_=native_layout(fibres,cert)
    step=Q(norm['step'])*geom.RHO*UNIT
    radii=np.array([int(ceil((int(x)+37)*step)) for x in last])
    risk=radii[:,None]+radii[None,:]>UNIT//2
    covered=np.zeros_like(risk)
    quantum=Q(full['erasure_constant_upper'])
    rows=[]
    loss=Q(full['all_layers_loss_upper'])
    for path in [args.square,*args.crosses]:
        row=read(path)
        provenance(row,Path.cwd())
        mask=np.zeros_like(risk)
        if path==args.square:
            ids=row['selected_groups']
            mask[np.ix_(ids,ids)]=True
            budget,detail=optimized_square(row,quantum)
            count=row['ordered_pairs_above_half']
        else:
            left,right=row['left_groups'],row['right_groups']
            assert set(left).isdisjoint(right)
            mask[np.ix_(left,right)]=True
            mask|=mask.T.copy()
            count=row['ordered_above_half']
            budget,detail=optimized_cross(row)
        mask&=risk
        assert not (mask&covered).any() and int(mask.sum())==count
        covered|=mask
        loss+=budget
        rows.append(dict(receipt=path.name,ordered_pairs=count,charge_upper=sci_upper(budget),**detail))
    statistics=[]
    for name,M in zip(('prime','sharp','higher'),cert['affine'][:3]):
        A=np.abs(np.asarray(M,dtype=np.int64))
        all_weight=sum(map(int,A[risk]))
        included=sum(map(int,A[covered]))
        statistics.append(dict(channel=name,active_ordered=int(np.count_nonzero(A[risk])),
                               covered_ordered=int(np.count_nonzero(A[covered])),
                               absolute_integer_weight=all_weight,covered_absolute_integer_weight=included))
    paths=[Path(__file__),GLOBAL,args.square,*args.crosses,CERT,NORM,FIBRES,TABLE,Path('h1_graded_cross_block.py')]
    out=dict(scope='Global semiprime price change plus raw error on the listed disjoint blocks only. Absolute coefficient weights describe coverage and do not bound errors outside it.',
             inputs={p.name:digest(p) for p in paths},global_price_cost=full['all_layers_loss_upper'],
             blocks=rows,combined_upper=sci_upper(loss),coverage=statistics,trace_checks=direct_trace_checks(),
             unresolved_ordered_pairs=int(np.count_nonzero(risk&~covered&np.any(np.asarray(cert['affine'][:3])!=0,axis=0))))
    if args.check:assert out==read(args.output)
    else:args.output.write_text(json.dumps(out,indent=2)+'\n',newline='\n')
    print('covered ordered pairs',int(covered.sum()),'partial allowance',out['combined_upper'],
          'unresolved active pairs',out['unresolved_ordered_pairs'],flush=True)


if __name__=='__main__':
    main()
