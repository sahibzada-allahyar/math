"""Exact B2 support and gate reachability on the native 39-shift lattice."""
import argparse
from fractions import Fraction as Q
import hashlib
import json
from math import ceil
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np

from h1_degree6_native_schur_support import replay_limits
from h1_labelled_restoration_mc import GATE_MINRAD,GATE_UNIT
from h1_signed_gate_fibre import GROUPS,geom,profiles,rebuild,stored_frame


HASHES={
    'fine':'968a623e31f6e9c920cab5e45e13af51cd69af007932e28dcd30294a737dfdcb',
    'ls':'be98aa740529935afa8bafeaccba42a0667bddfed2d5e9652c680133b6d718e1',
    'gates':'66b6aed9133c8f14988b90717b6418127030d89fa76a035056fb1f6efdc5aa8f',
    'edges':'cb921c8aa51e3b0c0364807dbc09be65e2265ef14e81768a56fdb2ea015e2205',
    'R':'d9ba00778f0736669fcd6f2b0eca1cf1ac75a00f5016f2e42217f4f95543d415',
    'radial_step':'f3df896830df06dd8776fdee81c344884cb6cfbfd2d849ec2123ca43bafd6fd6',
}
INFINITY=10**12


class Gates:
    def __init__(self,path):
        frame=stored_frame()
        self.tick=frame['step']*geom.RHO*GATE_UNIT
        self.limits=replay_limits(2)
        last=self.limits[0][1]
        num,den=self.tick.as_integer_ratio()
        # The unscaled products can exceed int64, so first use Python integers.
        self.low=np.array([j*num//den for j in range(last+1)])
        self.high=np.array([-(-((j+38)*num)//den) for j in range(last+1)])
        with np.load(path,allow_pickle=False) as z:
            data={k:z[k] for k in HASHES}
        for k,v in data.items():
            assert hashlib.sha256(np.ascontiguousarray(v,dtype='<i8').tobytes()).hexdigest()==HASHES[k]
        self.fine,self.ls,self.gates,self.edges,self.R,self.step=(data[k] for k in HASHES)
        self.step=int(self.step)
        self.base=GATE_MINRAD//self.step
        assert np.all(np.diff(self.gates,axis=1)<=0)
        groups=json.loads(GROUPS.read_text())['groups']
        group_for=np.full(len(frame['energies']),len(groups))
        for group,sectors in enumerate(groups):
            group_for[sectors]=group
        self.group=[]
        self.lasts=[]
        for c in self.fine:
            last=next(j for cc,j in self.limits if cc>=c)
            owner=frame['caps'][np.searchsorted(frame['caps'],c)]
            ids=frame['layout'](owner,np.arange(1,last+2))
            self.group.append(np.where(ids<0,-1,group_for[np.maximum(0,ids)]))
            self.lasts.append(last)

    def upper_edge(self,i):
        return int(np.searchsorted(self.edges,int(int(self.fine[i])*self.tick),side='right')-1)

    def tile(self,i,start=None,stop=None):
        """Cover feasible retained sums and radial bins by exact integer lookups."""
        lower=int(self.fine[i-1]) if i else 0
        if start is None:start=lower
        if stop is None:stop=self.lasts[i]
        j=np.arange(start,stop+1)
        grp=self.group[i][j]
        assert np.all(grp>=0)
        assert np.all(self.high[j]<=self.R[i,grp])
        lo=np.maximum(self.base,(self.low[j]+self.step-1)//self.step)-self.base
        hi=np.maximum(self.base,(self.high[j]+self.step-1)//self.step)-self.base
        assert np.all((lo>=0)&(hi<self.ls.shape[-1])&(hi-lo<=1))
        keys=[self.ls[i,grp,rc] for rc in (lo,hi)]
        assert all(np.all(k>=0) for k in keys)
        tops=[np.minimum(self.high[j],(rc+self.base)*self.step) for rc in (lo,hi)]
        return j,keys,tops

    def prefix(self,i,edge):
        """An integer threshold for the full tail, indexed by the full 39-site J.

        The fine maximum class i and edge are zero-based array indices.
        For each retained j retain a gate value only if its radial bin could
        contain a total strictly exceeding it. A prefix minimum then covers
        every possible erased site without multiplying by the number of sites.
        """
        j,keys,tops=self.tile(i)
        values=np.full(self.lasts[i]+1,INFINITY,dtype=np.int64)
        if edge<=self.upper_edge(i):
            for k,top in zip(keys,tops):
                g=self.gates[k,edge]
                values[j]=np.minimum(values[j],np.where(top>g,g,INFINITY))
        return np.minimum.accumulate(values)

    def verify(self):
        count=0
        first=[]
        for i in range(len(self.fine)):
            j,keys,tops=self.tile(i)
            e=self.upper_edge(i)
            bad=np.logical_or.reduce([top>self.gates[k,e] for k,top in zip(keys,tops)])
            first.append(int(j[np.flatnonzero(bad)[0]]) if bad.any() else INFINITY)
            count+=len(j)
        assert count==3359637
        assert first==[110019,108520]+[102994]*42
        max_erased=max(self.lasts)-min(first)
        assert max_erased==27970

        # If erasing the largest mark changes its fine class, the erased site
        # has index at least the previous cap. Prove equality on the only
        # transitions with enough retained total to fail.
        comparisons=[]
        for large in range(1,len(first)):
            lower=int(self.fine[large-1])
            for small in range(large):
                stop=self.lasts[large]-lower
                if stop<first[small]:continue
                j,small_keys,small_tops=self.tile(small,first[small],stop)
                _,full_keys,full_tops=self.tile(large,int(j[0]),stop)
                assert np.array_equal(small_tops,full_tops)
                edges=self.upper_edge(small)+1
                pairs=np.unique(np.vstack([np.column_stack((a,b)) for a,b in zip(small_keys,full_keys)]),axis=0)
                assert np.array_equal(self.gates[pairs[:,0],:edges],self.gates[pairs[:,1],:edges])
                comparisons.append([int(self.fine[large]),int(self.fine[small]),len(j),len(pairs),edges])
        assert [v[:2] for v in comparisons]==[[19529,9764],[29293,9764],[29293,19529]]
        return dict(reachable_retained_pairs=count,missing_lookup_pairs=0,over_radius_pairs=0,
                    first_potential_failure=first,max_index_of_failing_erasure=max_erased,
                    full_class_substitutions=comparisons)

    def virtual_root_example(self):
        """A passing virtual root with a truly failing one-site erasure."""
        idx=[46050,16000,16000,16000,1]+[493]*33+[498]
        totals=[(j+Q(1,2))*self.tick for j in idx]
        # Each site has one large mark. Every remaining mark is at most
        # .01 tick and hence contributes nothing to any displayed tail.
        marks=[v-Q(1,100) for v in totals]
        def root(keep):
            j=sum(idx[n] for n in keep)
            y=sum(totals[n] for n in keep)
            selected=[marks[n] for n in keep]
            i=np.searchsorted(self.fine,ceil(max(selected)/self.tick))
            assert int(self.fine[i])==46099 and j<=self.lasts[i]
            grp=self.group[i][j]
            assert grp>=0 and y<int(self.R[i,grp])
            key=int(self.ls[i,grp,max(self.base,ceil(y/self.step))-self.base])
            assert key>=0
            tails=[sum((v for v in selected if v>=int(edge)),Q(0)) for edge in self.edges[:-1]]
            gates=list(map(int,self.gates[key]))
            assert all(v!=g for v,g in zip(tails,gates,strict=True))
            bad=[n for n,(v,g) in enumerate(zip(tails,gates,strict=True)) if v>g]
            return key,bad,tails[36],gates[36]
        full=root(range(39))
        erased=root([i for i in range(39) if i!=4])
        assert full[:2]==(7129,[]) and erased[:2]==(7052,[6,*range(29,40)])
        assert full[2]==erased[2] and full[3]==2380000 and erased[3]==1930000
        value=profiles(stored_frame(),totals)['0,1']
        assert value!=0
        return dict(indices=idx,virtual_key=full[0],erased_key=erased[0],
                    failed_edges=erased[1],tail_at_310000_ticks=str(full[2]),
                    full_profile_approx=float(value))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--gates',type=Path,help='Existing frozen gate NPZ. Without it rebuild from the stored inputs.')
    args=p.parse_args()
    with TemporaryDirectory() as tmp:
        g=Gates(args.gates or rebuild(Path(tmp)))
        print(json.dumps(dict(**g.verify(),virtual_root_example=g.virtual_root_example())))


if __name__=='__main__':main()
