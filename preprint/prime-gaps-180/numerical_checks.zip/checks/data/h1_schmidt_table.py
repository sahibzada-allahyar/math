"""Fit a free real coupling across two halves of the tuple against a product control."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import numpy as np
from scipy.linalg import eigh
from scipy.optimize import minimize
from h1_coordinate_shape import configured
from h1_markov_resolvent import Cells,draw,gain


EDGES=(.085,.1025,.116,.130)
LARGE=.038
N=2*(len(EDGES)+1)
LO,HI=np.tril_indices(N)
INDEX=LO*(LO+1)//2+HI
assert np.array_equal(INDEX,np.arange(len(INDEX)))


class HalfTypes(Cells):
    size=len(INDEX)

    def values(self,idx,cat):
        h=(1+self.profile[idx].sum(axis=1))/self.center
        q=(self.r.rho*self.r.t[idx]).reshape(len(idx),2,self.r.k//2)
        u=2*np.searchsorted(EDGES,q.sum(axis=2))+(q.max(axis=2)>=LARGE)
        high=u.max(axis=1);low=u.min(axis=1)
        return h,high*(high+1)//2+low


def controls(m,B):
    assert m.min()>0
    ones=np.ones(len(m));baseline=B.sum()/m.sum()
    G=np.diag(m)
    def ritz(T):
        _,u=eigh(T.T@B@T,T.T@G@T)
        v=T@u[:,-1]
        return v/(m@v/m.sum())
    incidence=np.eye(N)[LO]+np.eye(N)[HI]
    additive=ritz(incidence)
    products={}
    for key,start in [('constant',np.ones(N)),('additive',np.linalg.lstsq(incidence,additive,rcond=None)[0]*2)]:
        def objective(s):
            v=s[LO]*s[HI];den=m@(v*v);num=v@B@v
            if den<1e-20:return 0.,np.zeros(N)
            gradient=2*((B@v)-num/den*m*v)/den
            ds=np.bincount(LO,weights=gradient*s[HI],minlength=N)+np.bincount(HI,weights=gradient*s[LO],minlength=N)
            return -num/den,-ds
        sol=minimize(objective,start,jac=True,method='L-BFGS-B',bounds=[(-3.,3.)]*N,
                     options=dict(ftol=1e-15,gtol=1e-10,maxiter=500))
        v=sol.x[LO]*sol.x[HI];products[key]=(float(-sol.fun),v/(m@v/m.sum()))
    best=max(products,key=lambda k:products[k][0])
    product=products[best][1]
    joint=ritz(np.eye(len(m)))
    assert joint@B@joint/(m@(joint*joint))>=baseline-1e-12
    return dict(coordinate=ones,additive=additive,product=product,joint=joint)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('dual',type=Path)
    p.add_argument('coordinate',type=Path);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--seed',type=int,required=True);p.add_argument('--power',type=int,default=15)
    p.add_argument('--runs',type=int,default=8);a=p.parse_args()
    coord=json.loads(a.coordinate.read_text());digest=lambda f:sha256(f.read_bytes()).hexdigest()
    assert coord['dual_sha256']==digest(a.dual) and a.power>=9 and a.runs>=6
    op,feature,_=configured(a.dual);cells=HalfTypes(op.r,coord)
    seeds=list(range(a.seed,a.seed+a.runs));half=len(seeds)//2
    assert {s+c for s in seeds for c in (0,100000)}.isdisjoint(s+c for s in coord['seeds'] for c in (0,100000))
    blocks=[]
    for j,seed in enumerate(seeds):
        blocks.append(draw(op,cells,feature.base,seed,a.power,15. if j<half else 13.))
        print(json.dumps(dict(seed=seed,empty_cells=int(np.sum(blocks[-1][0]==0)))),flush=True)
    mass,B,flow=(np.stack(x) for x in zip(*blocks))
    m,curvature=mass[:half].mean(0),B[:half].mean(0)
    test,A=mass[half:].mean(0),B[half:].mean(0)
    fitted=controls(m,curvature);rows={}
    for name,v in fitted.items():
        pairs=np.array([gain(w,br,v) for w,br in zip(mass[half:],B[half:])])
        M=np.zeros((N,N));M[LO,HI]=M[HI,LO]=v
        rows[name]=dict(gain=float(gain(test,A,v)),gains=pairs.tolist(),
                        descriptive_se=float(pairs.std(ddof=1)/np.sqrt(len(pairs))),
                        multiplier=v.tolist(),singular_values=np.linalg.svd(M,compute_uv=False).tolist())
    _,eig=eigh(A,np.diag(test))
    absbase=feature.base+A.sum()/test.sum()
    best=eig[:,-1]
    sample=a.output.with_suffix('.npz')
    np.savez_compressed(sample,mass=mass,correction=B,flow=flow)
    out=dict(scope='Held-out classical sieve fit of the rank-one product, additive half profiles, and unrestricted symmetric two-half multiplier.',
             dual=a.dual.name,dual_sha256=digest(a.dual),coordinate=a.coordinate.name,coordinate_sha256=digest(a.coordinate),
             sample=sample.name,sample_sha256=digest(sample),seeds=seeds,training_count=half,power=a.power,edges=EDGES,
             large_coordinate=LARGE,types_per_half=N,states=len(test),original_score=feature.base,sampled_coordinate_score=absbase,
             pooled_unrestricted_score=float(feature.base+best@A@best/(test@(best*best))),rows=rows)
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v['gain'] for k,v in rows.items()}))


if __name__=='__main__':main()
