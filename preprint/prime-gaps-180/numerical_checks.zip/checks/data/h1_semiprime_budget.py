"""Use an evaluated strip of semiprimes in the prime upper-sieve budget."""
import argparse
from decimal import Decimal
from fractions import Fraction as Q
from hashlib import sha256
import json
from math import floor,isqrt
from pathlib import Path

import numpy as np
from scipy import sparse
from scipy.linalg import eigh
from scipy.optimize import minimize
from h1_direct_bands import classify,corners,source_rows
from h1_pairing_sdp import scs
from h1_third_measure import lower_radii
from verify_pairing_envelope import SCALE,lower_factor,quantize


def density(b,u):
    # log(v) = 2 atanh((v-1)/(v+1)), with a geometric remainder.
    v=(1-b)*u/(b*(1-u));z=(v-1)/(v+1)
    assert 0<z<1
    lo=sum(2*z**(2*i+1)/(2*i+1) for i in range(40))
    hi=lo+2*z**81/(81*(1-z*z))
    D=10**15
    return Q(int(lo*D),D),Q(-int((-hi*D)//1),D)


def strip_mask(table,path,b):
    owner,s,z=corners(table,path);n=len(table['codes'])
    sigma=Q(1,2)-b+Q(1,10**6)
    def guard(order,omega,delta):
        a,c,d=(54,15,5) if order==1 else (56,16,4)
        return dict(high=1-68*omega-14*delta,bilinear=1-a*omega-c*delta-d*sigma)
    rows=source_rows(guard,5294100,500)
    fail=np.zeros((n,n),bool)
    for j in range(0,len(s),96):
        ix=np.arange(j,min(j+96,len(s)))
        passed=classify(s[ix,None],s[None,:],z[ix,None],z[None,:],rows,'transfer')
        a,c=np.nonzero(~passed)
        fail[owner[ix[a]],owner[c]]=True
    result=~fail
    # The higher minorant's Type II inputs cover [a,1/2] on its rectangles.
    book=path.resolve().parent.parent/'sensitivity'/'bilinear_minorant.json'
    assert sha256(book.read_bytes()).hexdigest()==table['band_minorant_sha256']
    row=next(t for t in json.loads(book.read_text())['rows'] if Q(t['theta'])==Q('.5291'))
    if b>=Q(row['a'])+Q(1,10**6):
        result|=np.array([[c=='1' for c in r] for r in table['refined_grant']])
    assert np.array_equal(result,result.T)
    return result


def model(path,legacy,b,u):
    table=json.loads(path.read_text(),parse_float=Decimal);old=json.loads(legacy.read_text())
    assert old['source']==path.name and table.get('band_rule')=='transfer'
    assert Q(str(table['fragment_cap']))<b<u<=Q(1,2)
    raw=np.array([[Q(x) for x in row] for row in table['sector_energies']],dtype=object)
    groups=old['groups'];fixed=old['resolved']
    assert sorted(fixed+sum(groups,[]))==list(range(len(raw))) and min(raw[:,0])>0
    def grouped(a):
        return np.array([[a[np.ix_(g,h)].all() for h in groups] for g in groups])
    p=np.array(table['prime_mask'],bool)
    assert p[fixed].all()
    masks=[grouped(a) for a in (p,np.array(table['minorant_mask'],bool),strip_mask(table,path,b))]
    e=np.array([raw[g].sum(0) for g in groups])
    eps=Q('.0001')
    # Bound the difference between the rough and prime caps at the lower edge.
    delta=np.array([max(Q(0),1/(b-eps)-1/(Q(1,2)-q-eps)) for q in lower_radii(table)])
    U=e[:,1]/e[:,0];K=e[:,2]/e[:,0]
    H=U+np.array([sum(raw[g,0]*delta[g]) for g in groups])/e[:,0]
    k=(Q('.000093307088324061'),Q('.000093307088324062'))
    return (e[:,0],masks,[U,K,H],sum(raw[fixed,0]),k,density(b,u)),old


def proposals(data,seconds):
    energy,masks,caps,_,k,mu=data;n=len(energy);i,j=np.triu_indices(n);l=len(i)
    fac=np.where(i==j,1.,np.sqrt(2.));diag=(i==j).astype(float)
    def unpack(v):
        A=np.zeros((n,n));A[i,j]=v/fac;A[j,i]=A[i,j];return A
    eye=sparse.eye(l,format='csc');zero=sparse.csc_matrix(eye.shape)
    P,Bn,C=[sparse.hstack([eye if t==s else zero for t in range(3)],format='csr') for s in range(3)]
    p,m,h=[a[i,j] for a in masks];both=p&m;only=m&~p
    kb=float(sum(k)/2);mass=float(sum(mu)/2)
    z=np.where((masks[0]&masks[1]).diagonal(),np.sqrt(kb),1.)
    zz=z[i]*z[j];B=sparse.diags(zz)@Bn
    mats=[P[p],Bn[both],(P-B)[only],C[h]]
    rhs=[diag[p],kb*diag[both]/zz[both],(1-kb)*diag[only],mass*diag[h]]
    a0=sum(map(len,rhs));U,K,H=[a.astype(float) for a in caps]
    mats.extend([-P,P,-Bn,B,-C,P+C])
    rhs.extend([0*diag,U[i]*diag,0*diag,K[i]*diag,0*diag,H[i]*diag])
    w=np.sqrt(energy.astype(float))
    problem=dict(A=sparse.vstack(mats,format='csc'),b=np.concatenate(rhs),c=np.r_[fac*w[i]*w[j],np.zeros(2*l)])
    sol=scs.solve(problem,dict(z=a0,s=[n]*6),verbose=False,time_limit_secs=seconds,
                  eps_abs=3e-7,eps_rel=3e-7,max_iters=200000)
    y=sol['y'];start=0;dual=[]
    for mask in (p,both,only,h):
        v=np.zeros(l);size=int(mask.sum())
        v[mask]=-y[start:start+size];start+=size;dual.append(v)
    a,b,r,s=dual
    affine=[unpack(v) for v in (a+b/zz,r-b/zz,s)]
    ev,V=eigh(unpack(y[a0+5*l:]))
    primal=[unpack(sol['x'][t*l:(t+1)*l]) for t in range(3)]
    primal[1]*=np.outer(z,z)
    return affine,V[:,ev>0]*np.sqrt(ev[ev>0]),primal,sol['info']['status']


def exact(data,affine,factor):
    e,masks,caps,fixed,k,mu=data;n=len(e);L,R,M=affine
    assert all(np.array_equal(a,a.T) and not a[~m].any() for a,m in zip(affine,masks))
    w=np.array([isqrt(int(x*SCALE**2)) for x in e],dtype=object)
    T=factor@factor.T
    mats=[np.outer(w,w)-SCALE*(L+R)+T,SCALE*R,T-SCALE*M]
    cost=sum(T.diagonal()*caps[2])/SCALE**2
    for mat,cap in zip(mats,caps):
        diag,_=lower_factor(mat,cap);cost+=sum(diag*cap)
    tr=lambda a:Q(int(a.trace()),SCALE)
    retreat=max(caps[0])*Q(2*sum(w)*n+n*n,SCALE**2)
    return fixed+tr(L)+min((1-v)*tr(R) for v in k)+min(v*tr(M) for v in mu)-cost-retreat


def polish(data,old,affine,F):
    e,_,caps,fixed,k,mu=data;w=np.sqrt(e.astype(float));n=len(e)
    p,b,r=[np.array(old[k]) for k in ('dual_prime','dual_exceptional','dual_minorant')]
    base=[p+b,r-b,np.zeros_like(p)]
    change=[a-v for a,v in zip(affine,base)];T=F@F.T
    start=[np.outer(w,w)-base[0]-base[1],base[1],np.zeros_like(T)]
    axes=np.zeros((4,3,n,n))
    axes[0,0]=-change[0];axes[1,0]=-change[1];axes[1,1]=change[1];axes[2,2]=-change[2]
    axes[3,0]=axes[3,2]=T
    co=[1,1-float(sum(k)/2),float(sum(mu)/2)]
    const=float(fixed)+sum(t*a.trace() for t,a in zip(co,base))
    linear=np.array([t*a.trace() for t,a in zip(co,change)]+[-T.diagonal()@caps[2].astype(float)])
    for j,cap in enumerate(caps):
        s=np.sqrt(cap.astype(float));outer=np.outer(s,s);start[j]=start[j]*outer;axes[:,j]*=outer
    def objective(x):
        value=const+linear@x;grad=linear.copy()
        for j in range(3):
            a=start[j]+np.einsum('i,ijk->jk',x,axes[:,j])
            ev,V=eigh((a+a.T)/2);v=V[:,ev<0]
            value+=ev[ev<0].sum();grad+=np.einsum('ijk,jk->i',axes[:,j],v@v.T)
        return -value,-grad
    choices=[np.zeros(4),np.ones(4)]
    for x in list(choices):
        res=minimize(objective,x,jac=True,method='L-BFGS-B',bounds=[(-1,3)]*3+[(0,5)],
                     options={'maxiter':80,'ftol':1e-15})
        choices.append(res.x)
    x=min(choices,key=lambda v:objective(v)[0])
    A=[quantize(a+t*b) for a,b,t in zip(base,change,x)]
    return A,quantize(np.sqrt(x[3])*F),x.tolist()


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('table',type=Path);p.add_argument('legacy',type=Path)
    p.add_argument('--lower-factor',required=True,type=Q);p.add_argument('--upper-factor',type=Q,default=Q(1,2))
    p.add_argument('--output',type=Path,required=True);p.add_argument('--seconds',type=int,default=150);p.add_argument('--check',action='store_true')
    a=p.parse_args();b,u=a.lower_factor,a.upper_factor;data,old=model(a.table,a.legacy,b,u)
    hashes={f.name:sha256(f.read_bytes()).hexdigest() for f in (a.table,a.legacy)}
    if a.check:
        out=json.loads(a.output.read_text());assert out['inputs']==hashes and Q(out['b'])==b and Q(out['u'])==u
        A=[np.array(v,dtype=object) for v in out['affine']];F=np.array(out['factor'],dtype=object)
        assert out['lower_billionths']==floor(exact(data,A,F)*10**9)
    else:
        affine,F,prim,status=proposals(data,a.seconds)
        A,F,x=polish(data,old,affine,F)
        out=dict(scope='Finite cap-model lower bound for the specified semiprime strip.',inputs=hashes,
                 b=str(b),u=str(u),density=list(map(str,data[-1])),pairs=int(np.triu(data[1][2]).sum()),
                 solver_status=status,lower_billionths=floor(exact(data,A,F)*10**9),weights=x,
                 affine=[v.tolist() for v in A],factor=F.tolist(),primal_proposal=[quantize(v).tolist() for v in prim])
        a.output.write_text(json.dumps(out,separators=(',',':'))+'\n')
    print(str(b),str(u),out['pairs'],out['lower_billionths'],flush=True)


if __name__=='__main__':main()
