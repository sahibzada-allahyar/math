"""Fetch the pinned public numerical package of the 182 development into ../deps/.

Downloads about 245 MB; no downloaded program or installer is executed.
The mathematical scope and authorship remain those of the upstream project.
"""
from pathlib import Path, PurePosixPath
import hashlib
import json
import shutil
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT / 'deps/h1-182'
NAME = 'prime-gaps-external-182-verified-20260909.zip'
URL = 'https://github.com/romyar1/prime-gaps-lean/releases/download/external-numerics-20260909/' + NAME
SHA = '2960729efa8996538731820ce6cadc202831c8e98b2c0bdb14cfd19f33726f3b'


def main():
    CACHE.mkdir(parents=True, exist_ok=True)
    archive = CACHE / NAME
    if not archive.exists():
        temp = archive.with_suffix('.download')
        with urllib.request.urlopen(URL) as response, temp.open('wb') as dest:
            shutil.copyfileobj(response, dest)
        with temp.open('rb') as source:
            assert hashlib.file_digest(source,'sha256').hexdigest() == SHA
        temp.replace(archive)
    with archive.open('rb') as source:
        assert hashlib.file_digest(source,'sha256').hexdigest() == SHA
    count = 0
    with zipfile.ZipFile(archive) as bundle:
        for item in bundle.infolist():
            if not item.filename.startswith('prime-gaps-external-182/snapshot/'):
                continue
            rel = PurePosixPath(item.filename)
            assert not rel.is_absolute() and '..' not in rel.parts
            target = CACHE.joinpath(*rel.parts)
            assert target.resolve().is_relative_to(CACHE.resolve())
            if item.is_dir():
                target.mkdir(parents=True,exist_ok=True)
            else:
                target.parent.mkdir(parents=True,exist_ok=True)
                data = bundle.read(item)
                if target.exists():
                    assert target.read_bytes() == data, f'Edited backend: {rel}'
                else:
                    target.write_bytes(data)
            count += 1
    print(json.dumps({'archive_sha256':SHA,'snapshot_files':count}))


if __name__ == '__main__':
    main()
