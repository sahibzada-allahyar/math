"""Labelled-endpoint trial in the stored 521-sector two-source table (floating point, uncertified).

The table h1_priced_168_table.json fixes a partition of the retained roots of a 38-coordinate
erased profile into 521 sectors, with the prime and sharp-minorant masks of the two-source
model (five-radius permissions, rectangle unions, per-band transfer rows) on the geometry of
radius .2798746934 with fragment cap 417/2500 and 131072 cells.  Every permission there is a
condition on the upper retained total and the largest fragment of a root, so it applies to a
root of a k-coordinate trial with the same upper total and fragment: a retained cell y of a
k-coordinate grid with 131072/m cells is the stored cell m(y+k-1)-37, and a cap layer c is
covered by the smallest stored cap at least m(c+1)-1.

The trial is the class of h1_native_endpoints.py on that geometry: k-2 symmetric core
coordinates and two coordinates (a, b) with their own shapes.  Its three kinds of face (core,
a, b) are priced separately in the stored table with the priced-sector dual, solved
by h1_refine_prices.splitting from the stored certificate, and with --pair the two-coordinate
lift cost of the pair (a, b) is subtracted.

Multipliers found for one profile are admissible for another only on sectors where they are
defined.  Each dual is therefore solved for the sector energies plus a small multiple (--epsilon)
of a reference table that is positive on every sector the grid can reach, with every reachable
group kept.  For fixed unnormalised multipliers the dual value is a function of the table
(energy, Selberg-weighted energy, kernel-weighted energy) of the form linear plus two terms
negeig(D^(1/2) M D^(1/2)) = min over 0 <= Y <= D of <Y, M>, which are convex and homogeneous
of degree one in the diagonal D.  h1_fit_pairing_sectors.affine_weights returns a subgradient
of that function at the regularised table, so the resulting price field lies above it nowhere:
price . table' <= dual value at table' <= model value, for every table' on the reachable
sectors.  The number reported for a profile (event VALUE, key value) is that field evaluated at
the profile's own energies; the refit maximises the same field, so its eigenvalue (event REFIT)
is a bound for the refitted profile in this floating model, and the alternation is monotone.
value_exact_corrections recomputes the corrections for the profile alone after dropping groups
of negligible energy; it is a diagnostic, not a bound.

Not a certificate: floating duals on binary64 sector energies, no enclosure of quadrature, no
restoration of raw predicates, and the sector permissions are those of the stored model.

    python h1_two_source_endpoints.py --gate dual
    python h1_two_source_endpoints.py --gate shift --intervals 32768
    python h1_two_source_endpoints.py --gate symmetric --intervals 8192
    python h1_two_source_endpoints.py --gate labels
    python h1_two_source_endpoints.py --gate prices --price-table ../../lean/minorants/data/ml12_w25_prices.json
    python h1_two_source_endpoints.py --dimension 39 --pair --angular 6 --shapes 0,100 --intervals 32768 --rounds 2 --save v.npz
    python h1_two_source_endpoints.py --dimension 39 --pair --angular 6 --shapes 0,100 --intervals 131072 --rounds 0 --start v.npz
"""
import argparse
import contextlib
import io
import json
import sys
import time
from fractions import Fraction as Q
from pathlib import Path

import numpy as np
from scipy.linalg import eigvalsh

_saved = list(sys.argv)
sys.argv = sys.argv[:1]
with contextlib.redirect_stdout(io.StringIO()):
    import h1_native_endpoints as E
    import h1_pairing_sectors as PS
    import h1_sunrise_boundary as SB
    import h1_refine_prices as RP
    import h1_fit_pairing_sectors as FP
    from h1_geometry_scan import instantiate
    from verify_pairing_envelope import SCALE
sys.argv = _saved

HERE = Path(__file__).resolve().parent
TABLE = HERE / 'h1_priced_168_table.json'
DUAL = HERE / 'h1_priced_nested.json'
TYPES = ('core', 'a', 'b')
KAPPA = .0000933070883240615          # the value used inside h1_refine_prices.splitting


def quiet(fn, *args, **kwargs):
    with contextlib.redirect_stdout(io.StringIO()):
        return fn(*args, **kwargs)


def say(**row):
    print(json.dumps(row), flush=True)


# ---- the stored table and its certificate -------------------------------------------------
def stored_frame(table=TABLE, dual=DUAL):
    control, original, layout = SB.geometry(table)             # checks the stored hashes
    with np.load(table.with_name(original['cell_bins']), allow_pickle=False) as archive:
        cells, step = archive['cells'], Q(str(archive['step']))
    caps = np.unique(cells[:, 1]).astype(np.int64)
    energies = np.array(control['sector_energies'], float)
    prime = np.array(control['prime_mask'], bool)
    minorant = np.array(control['minorant_mask'], bool)
    resolved = np.flatnonzero(prime.all(1))
    nested = json.loads(dual.read_text())
    groups = [list(map(int, g)) for g in nested['groups']]
    assert sorted(resolved.tolist() + sum(groups, [])) == list(range(len(energies)))
    # the certificate must belong to this table, and a group must consist of sectors with identical permissions
    assert nested['inputs'][table.name] == SB.digest(table)
    for g in groups:
        assert not (prime[g] != prime[g[0]]).any() and not (minorant[g] != minorant[g[0]]).any()
    A0, R0 = [np.asarray(v, float) / SCALE for v in nested['affine']]
    stored = np.array([energies[g].sum(0) for g in groups])
    w0 = np.sqrt(stored[:, 0])
    scale = np.where(w0 > 0, 1.0 / np.where(w0 > 0, w0, 1.0), 0.0)     # groups without stored energy start at zero
    scale = np.outer(scale, scale)
    return dict(control=control, original=original, layout=layout, caps=caps, last=int(cells[:, 3].max()), step=step,
                energies=energies, prime=prime, minorant=minorant, resolved=resolved, groups=groups,
                rep=np.array([g[0] for g in groups]), kappa=float(control['kappa_upper']),
                A0=A0, R0=R0, Au=A0 * scale, Ru=R0 * scale,
                certified=nested['lower_billionths'] / 1e9)


def spectral_value(e, p, m, fixed, A, R):
    """The dual value of h1_refine_prices.splitting for group data e (n, 3)."""
    w = np.sqrt(e[:, 0])
    U, K = (e[:, 1:] / e[:, 0, None]).T
    su, sk = np.sqrt(np.outer(U, U)), np.sqrt(np.outer(K, K))
    assert not A[~(p | m)].any() and not R[~m].any() and not (A - R)[~p].any()
    return float(fixed + A.trace() - KAPPA * R.trace()
                 + np.minimum(eigvalsh(su * (np.outer(w, w) - A)), 0).sum()
                 + np.minimum(eigvalsh(sk * R), 0).sum())


def dual_face(energies, frame, steps, warm=None, reference=None, epsilon=0.0):
    """Dual value and per-sector prices for one table of sector energies (521, 3).

    Starts from unnormalised multipliers (the stored certificate by default) and improves them
    by Douglas-Rachford splitting.  With a reference table the dual is solved for
    energies + epsilon * total * reference, so that every reachable group is present and the
    price field is admissible for every profile on the grid; the value returned is then that
    field at the given energies.  Without it, groups of zero energy are dropped and the field
    is admissible for the given profile only.
    """
    groups = frame['groups']
    table = energies if reference is None else energies + epsilon * energies[:, 0].sum() * reference
    e = np.array([table[g].sum(0) for g in groups])
    if reference is None:
        keep = np.flatnonzero(e[:, 0] > 1e-14 * e[:, 0].max())
    else:
        # every group the grid can reach is kept, whatever its energy, so that no reachable sector goes unpriced
        reachable = np.array([reference[g, 0].sum() > 0 for g in groups])
        keep = np.flatnonzero(reachable)
        assert not e[~reachable, 0].any()
    ek = e[keep]
    assert ek.min() > 0
    rep = frame['rep'][keep]
    p = frame['prime'][np.ix_(rep, rep)]
    m = frame['minorant'][np.ix_(rep, rep)]
    fixed = float(table[frame['resolved'], 0].sum())
    Au, Ru = warm if warm is not None else (frame['Au'], frame['Ru'])
    w = np.sqrt(ek[:, 0])
    ww = np.outer(w, w)
    A, R = Au[np.ix_(keep, keep)] * ww, Ru[np.ix_(keep, keep)] * ww
    start = spectral_value(ek, p, m, fixed, A, R)
    if steps:
        A, R, _ = quiet(RP.splitting, (ek, (p, m), fixed), A, R, steps)
    solved = spectral_value(ek, p, m, fixed, A, R)
    prices = FP.affine_weights(table, [groups[i] for i in keep], frame['resolved'], A, R, frame['kappa'])
    n = len(groups)
    Au2, Ru2 = np.zeros((n, n)), np.zeros((n, n))
    Au2[np.ix_(keep, keep)] = A / ww
    Ru2[np.ix_(keep, keep)] = R / ww
    value = float((energies * prices).sum())
    info = dict(start=start, value=value, solved_value=solved, groups=int(len(keep)),
                price_sum_residual=abs(float((table * prices).sum()) - solved),
                fixed=float(energies[frame['resolved'], 0].sum()), total_energy=float(energies[:, 0].sum()))
    if reference is not None:
        # the same multipliers with the corrections recomputed for this profile alone
        actual = np.array([energies[g].sum(0) for g in groups])[keep]
        own = np.flatnonzero(actual[:, 0] > 1e-14 * actual[:, 0].max())
        scale = np.sqrt(actual[own, 0]) / w[own]
        info['value_exact_corrections'] = spectral_value(actual[own], p[np.ix_(own, own)], m[np.ix_(own, own)], info['fixed'],
                                                         A[np.ix_(own, own)] * np.outer(scale, scale),
                                                         R[np.ix_(own, own)] * np.outer(scale, scale))
        info['groups_with_energy'] = int(len(own))
    return value, prices, (Au2, Ru2), info


# ---- model on the stored geometry, labels and auxiliary kernels ----------------------------
def stored_model(k, intervals, angular, frame):
    original = frame['original']
    fit = json.loads((HERE / original['trial_refit']).read_text())
    P = json.loads((HERE / 'h1_k38_knn6_n32768.json').read_text())
    P = dict(P, specification=dict(P['specification'], angular=angular))
    r, limits, domains, spec, record = instantiate(P, dict(radius=fit['radius'], extra_knots=fit.get('extra_knots', ())), k, intervals)
    if angular == fit['shape_spec']['angular']:
        assert spec == fit['shape_spec']
    if fit['flat']:
        r.shells['outer'] = [(Q(0), r.geometry['parameters']['S'], max(limits))]
    m = original['intervals'] // intervals
    assert original['intervals'] == m * intervals and r.exact_step == m * frame['step']
    cut = (original['cutoff'] + 1) // m - 1                  # the fragment cap, kept inside the stored cap range
    limits = [min(int(x), cut) for x in limits]
    assert len(set(limits)) == 3
    if m == 1:
        assert limits == list(original['component_limits'])
    sub = next(shells for key, shells in domains.items() if key != 'L1')
    return r, limits, sub, domains, fit, m


def labeller(r, frame, m, outward=0, outward_caps=0):
    """labels(cap) -> stored sector of every retained cell in the layer ending at cap (-1: none).

    outward > 0 moves every cell that many stored indices outward and outward_caps > 0 moves
    every layer that many stored cut caps outward (tests of sensitivity; a stored cut cap is a
    whole fragment layer, not a cell).
    """
    caps, layout, last = frame['caps'], frame['layout'], frame['last']
    index = m * (np.arange(r.n) + r.k - 1) - 37
    assert index[0] >= 0 and index[-1] <= last
    index = np.minimum(index + outward, last)
    cache = {}

    def labels(cap):
        if cap not in cache:
            pos = int(np.searchsorted(caps, m * (cap + 1) - 1))
            if pos < len(caps):
                pos = min(pos + outward_caps, len(caps) - 1)
            cache[cap] = np.full(r.n, -1, dtype=np.int64) if pos == len(caps) else np.asarray(layout(caps[pos], index), dtype=np.int64)
        return cache[cap]
    return labels


def layer_caps(frame, m):
    """Stored cut caps on a grid m times coarser, each rounded down to a whole coarse layer."""
    return sorted({int((c + 1) // m - 1) for c in frame['caps'] if (c + 1) // m - 1 > 0})


def aux(r, max_radius):
    """Selberg and exceptional kernels at the upper total of each cell, as in h1_pairing_sectors.Sectors."""
    n = r.k - 1
    count = int(Q(str(max_radius)) / (Q(str(r.rho)) * r.exact_step)) + 1
    assert count >= r.n
    q = (np.arange(count) + n) * r.h * r.rho
    prime_upper = 1 / (.5 - q - .0001)
    qbin = np.ceil(q * 10000).astype(int)
    qtab = np.arange(max(qbin) + 1) / 10000
    rough = 1 - 2 * .41361
    ds = (.41361 - 2 * rough) / 1024
    weight = np.zeros(len(qtab))
    for j in range(1, 1025):
        x = 2 * rough + j * ds
        bottom = np.minimum(rough - .0001, (1 - x) / 2 - qtab - .0001)
        assert min(bottom) > 0
        weight += ds * (12 / 5) * max(0., x - .38) / (.4 - .38) * (x - 2 * rough) / (x * rough * bottom)
    return prime_upper[:r.n], weight[qbin][:r.n]


def bin_energies(density, labels_at_cap, PU, KER, out):
    ids = np.where(labels_at_cap < 0, len(out) - 1, labels_at_cap)
    for j, mult in enumerate((1.0, PU, KER)):
        out[:, j] += np.bincount(ids, weights=density * mult, minlength=len(out))


def face_energies(L, vector, labels, PU, KER, extra, sectors, with_pair=False):
    """Per face type, (sectors+1, 3) energies times rho; the last row collects unlabelled cells.

    With with_pair the third value is the lift cost of the pair (a, b) for this vector, computed
    without the pair matrix; otherwise it is None.
    """
    rho = float(L.r.rho)
    out = {t: np.zeros((sectors + 1, 3)) for t in TYPES}
    negative = 0.0
    if with_pair:
        densities, pair_value = quiet(L.densities_and_pair, vector, extra)
    else:
        densities, pair_value = quiet(L.densities, vector, extra), None
    for cap, triple in densities.items():
        ids = labels(cap)
        for t, density in zip(TYPES, triple):
            bin_energies(rho * density, ids, PU, KER, out[t])
            negative += float(-np.minimum(density, 0).sum()) * rho
    return out, negative, pair_value


def symmetric_energies(r, coefficients, limits, mass, cuts, labels, PU, KER, sectors):
    """Sector energies of a symmetric coefficient vector, by the loop of h1_pairing_sectors.main."""
    from endpoint_pair_scan import first_fibres
    from h1_window_spectators import radial, coefficients as products
    fibres = first_fibres(r, np.asarray(coefficients, float), limits)
    out = np.zeros((sectors + 1, 3))
    previous = {}
    pref = r.rho * r.norm * r.inner_exp / mass
    for cap in sorted(set(map(int, cuts)) | set(fibres)):
        if cap > max(fibres):
            continue
        rows = radial(fibres, cap, r.n)
        poly = products(rows, rows)
        density = np.zeros(r.n)
        current = {}
        for sig, v in poly.items():
            current[sig] = r.moment(cap, r.k - 1, sig).copy()
            density += v * (current[sig] - previous.get(sig, 0.))
        bin_energies(density * pref, labels(cap), PU, KER, out)
        previous = current
        r.clear_cache()
    return out


def price_roles(prices, labels, PU, KER):
    """One role per face type: the stored-style price field w0 + w1 PU + w2 KER of each cell's sector."""
    def role_weights(cap):
        ids = labels(cap)
        ok = ids >= 0
        out = []
        for t in TYPES:
            W = prices[t]
            w = np.zeros(len(ids))
            w[ok] = W[ids[ok], 0] + W[ids[ok], 1] * PU[ok] + W[ids[ok], 2] * KER[ok]
            out.append(w)
        return out
    return role_weights


# ---- gates ----------------------------------------------------------------------------------
def gate_dual(frame, steps):
    energies, groups = frame['energies'], frame['groups']
    prices = FP.affine_weights(energies, groups, frame['resolved'], frame['A0'], frame['R0'], frame['kappa'])
    value, _, _, info = dual_face(energies, frame, 0)
    more, _, _, info2 = dual_face(energies, frame, steps)
    say(event='GATE_DUAL', certified=frame['certified'], stored_price_sum=float((energies * prices).sum()),
        stored_spectral_value=value, after_more_steps=more, steps=steps, groups=info['groups'],
        resolved_energy=info['fixed'], total_energy=info['total_energy'], residual=info2['price_sum_residual'])
    assert abs(float((energies * prices).sum()) - frame['certified']) < 1e-7 and value >= frame['certified'] - 1e-9 and more >= value - 1e-12


def gate_shift(frame, intervals):
    """Compare the five-radius sector codes built natively at k=39 with those at k=38.

    A k=39 cell y has the upper total of the k=38 cell y+1, so the radial-bin part of the code
    must agree after a shift of one cell.  The source masks are generated with the retained
    dimension subtracted twice (once on the source grid, once in the conversion), so native
    k=39 membership at y equals k=38 membership at y+2: the frame-shifted stored masks (shift
    one) must contain the native k=39 ones and differ from them by one cell.
    """
    original = frame['original']
    radii = [s['radius'] for s in original['sources']]
    bits = 4 * len(radii)
    codes = {}
    for k in (38, 39):
        r, limits, sub, domains, fit, m = quiet(stored_model, k, intervals, 6, frame)
        sec = quiet(PS.Sectors, r, domains, radii, original['max_radius'])
        codes[k] = (np.array(sec.caps), np.array(sec.codes, dtype=np.int64)[sec.index], sec.count)
    same_caps = bool(np.array_equal(codes[38][0], codes[39][0]))
    width = min(codes[38][2], codes[39][2]) - 2
    c39 = codes[39][1][:, :width]
    one = codes[38][1][:, 1:width + 1]
    two = codes[38][1][:, 2:width + 2]
    valid = (c39 >= 0) & (one >= 0) & (two >= 0)
    low = (1 << bits) - 1
    bins_shift_one = bool(np.array_equal((c39 >> bits)[valid], (one >> bits)[valid]))
    masks_shift_two = bool(np.array_equal((c39 & low)[valid], (two & low)[valid]))
    contained = bool(np.all(((c39 & low) & ~(one & low))[valid] == 0))
    differing = int(np.count_nonzero(((c39 & low) != (one & low)) & valid))
    say(event='GATE_SHIFT', intervals=intervals, same_caps=same_caps, columns_compared=int(width),
        radial_bins_equal_after_shift_one=bins_shift_one, masks_equal_after_shift_two=masks_shift_two,
        native39_masks_contained_in_shift_one=contained, cells_where_shift_one_differs=differing,
        cells_compared=int(valid.sum()))
    assert same_caps and bins_shift_one and contained and masks_shift_two


def gate_labels(frame):
    """The stored trial through the labeller and kernels of this file reproduces the stored sector energies."""
    original = frame['original']
    r, limits, sub, domains, fit, m = quiet(stored_model, 38, original['intervals'], 6, frame)
    from h1_knn_harmonic import scalar_replay
    coefficients = np.array(fit['coefficients'])
    mass, forms = quiet(scalar_replay, r, coefficients, limits, domains)
    PU, KER = aux(r, original['max_radius'])
    sectors = len(frame['energies'])
    got = symmetric_energies(r, coefficients, limits, mass, frame['caps'], labeller(r, frame, m), PU, KER, sectors)
    error = float(np.abs(got[:sectors] - frame['energies']).max())
    say(event='GATE_LABELS', max_abs_difference=error, unlabelled_energy=float(got[sectors, 0]), total=float(got[:sectors, 0].sum()),
        baseline=original['baseline'])
    assert error < 1e-10 and abs(got[sectors, 0]) < 1e-12


def gate_reference(frame, intervals, steps):
    """Dual value of the stored symmetric trial when its energies are binned on a coarser grid."""
    original = frame['original']
    r, limits, sub, domains, fit, m = quiet(stored_model, 38, intervals, 6, frame)
    from h1_knn_harmonic import scalar_replay
    coefficients = np.array(fit['coefficients'])
    mass, forms = quiet(scalar_replay, r, coefficients, limits, domains)
    PU, KER = aux(r, original['max_radius'])
    sectors = len(frame['energies'])
    got = symmetric_energies(r, coefficients, limits, mass, layer_caps(frame, m), labeller(r, frame, m), PU, KER, sectors)
    value, _, _, info = dual_face(got[:sectors], frame, steps)
    say(event='GATE_REFERENCE', intervals=intervals, coarsening=m, stored_trial_value=value, start=info['start'],
        groups=info['groups'], unlabelled_energy=float(got[sectors, 0]), total=float(got[:sectors, 0].sum()))


def gate_prices(frame, path):
    """A stored price table must reproduce its own certified value on its own trial's energies.

    The multilevel table is checked against the exact sector energies of its 21-coefficient
    trial, which h1_cover_convergence.mixture_energies ties to the same 521-sector table by hash.
    """
    from math import floor
    import h1_cover_convergence as CC
    raw = CC.mixture_energies(HERE / 'h1_cover_native_mixed.json', HERE / 'h1_decoupled_coarsened_1e14_fit.json')
    record = json.loads(Path(path).read_text())
    prices = np.array([[int(x) for x in row] for row in record['sector_prices']], dtype=object)
    assert prices.shape == raw.shape == (len(frame['energies']), 3)
    total = sum((prices * raw).ravel()) / Q(int(record['scale']))
    unpriced = int(sum(1 for row in prices if not any(row)))
    say(event='GATE_PRICES', table=Path(path).name, value_on_own_trial=float(total), billionths=floor(total * 10**9),
        recorded_billionths=record['reference_lower_billionths'], sectors_without_price=unpriced,
        lowest_price=float(min(prices.ravel())) / int(record['scale']))
    assert floor(total * 10**9) == record['reference_lower_billionths'] and unpriced == 0


def gate_symmetric(frame, intervals):
    """With one shape and no angular terms the labelled class is the symmetric one: compare the two density routes."""
    original = frame['original']
    r, limits, sub, domains, fit, m = quiet(stored_model, 38, intervals, 0, frame)
    L = quiet(E.Labelled, 38, intervals, 0, [0.0], model=(r, limits, sub))
    extra = layer_caps(frame, m)
    labels = labeller(r, frame, m)
    PU, KER = aux(r, original['max_radius'])
    sectors = len(frame['energies'])
    gram = quiet(L.mass)
    rng = np.random.default_rng(20261113)
    rows = []
    for trial in range(2):
        vector = rng.normal(size=L.N) if trial else np.r_[1.0, np.zeros(L.N - 1)]
        mass = float(vector @ gram @ vector)
        from h1_knn_harmonic import scalar_replay
        native_mass = quiet(scalar_replay, r, vector, limits, domains)[0]
        by_face, negative, _ = face_energies(L, vector / np.sqrt(mass), labels, PU, KER, extra, sectors)
        total = by_face['core'] + by_face['a'] + by_face['b']
        reference = symmetric_energies(r, vector, limits, native_mass, extra, labels, PU, KER, sectors)
        rows.append(dict(mass_relative_difference=abs(mass - native_mass) / native_mass,
                         max_abs_difference=float(np.abs(total - reference).max()),
                         a_minus_b=float(np.abs(by_face['a'] - by_face['b']).max()),
                         core_minus_36a=float(np.abs(by_face['core'] - 36 * by_face['a']).max()),
                         total=float(reference[:, 0].sum()), unlabelled=float(reference[sectors, 0])))
    say(event='GATE_SYMMETRIC', intervals=intervals, rows=rows)
    assert all(row['mass_relative_difference'] < 1e-9 and row['max_abs_difference'] < 1e-9 and row['a_minus_b'] < 1e-9
               and row['core_minus_36a'] < 1e-9 for row in rows)


# ---- the run --------------------------------------------------------------------------------
def reference_table(L, labels, PU, KER, extra, sectors):
    """A table positive on every sector that some (layer, cell) of the grid can reach.

    Each reachable sector carries the same energy (their total is one), with the two kernel
    columns at the mean of the kernels over its cells, so that the regularised energy of a
    sector does not depend on how many cells reach it.
    """
    out = np.zeros((sectors + 1, 3))
    ones = np.ones(L.r.n)
    for cap in L.layer_caps(extra):
        bin_energies(ones, labels(cap), PU, KER, out)
    out = out[:sectors]
    reached = out[:, 0] > 0
    table = np.zeros_like(out)
    table[reached] = out[reached] / out[reached, 0][:, None] / reached.sum()
    return table


def load_price_table(path, sectors):
    record = json.loads(Path(path).read_text())
    prices = np.array([[float(Q(int(x), int(record['scale']))) for x in row] for row in record['sector_prices']])
    assert prices.shape == (sectors, 3)
    return prices


def fixed_price_value(by_face, path, sectors):
    """Evaluate a stored per-sector price table (sector_prices, scale) on the three face energy tables.

    Such a table is a lower bound for any profile only if its prices come from multipliers with
    profile-independent caps and the profile has no energy in sectors the table leaves unpriced;
    the energy in unpriced sectors is returned so that this can be seen.
    """
    prices = load_price_table(path, sectors)
    unpriced = ~prices.any(1)
    total = sum(float((by_face[t][:sectors] * prices).sum()) for t in TYPES)
    stray = sum(float(by_face[t][:sectors][unpriced, 0].sum()) for t in TYPES)
    return total, stray, int(unpriced.sum())


def run(dimension, intervals, angular, shapes, rounds, with_pair, steps, start=None, save=None, outward=0, check=False,
        epsilon=1e-9, outward_caps=0, price_table=None, fixed_refit=False, cutoff=1e-8):
    t0 = time.time()
    frame = stored_frame()
    original = frame['original']
    sectors = len(frame['energies'])
    r, limits, sub, domains, fit, m = quiet(stored_model, dimension, intervals, angular, frame)
    L = quiet(E.Labelled, dimension, intervals, angular, shapes, model=(r, limits, sub))
    rho = float(r.rho)
    extra = layer_caps(frame, m)
    labels = labeller(r, frame, m, outward, outward_caps)
    PU, KER = aux(r, original['max_radius'])
    reference = reference_table(L, labels, PU, KER, extra, sectors)
    gram = quiet(L.mass)
    only_evaluate = rounds == 0 and start is not None
    if only_evaluate:
        # a fixed vector is evaluated in full coefficient space: no reduction, no dense forms
        class Identity:
            W = None
            rank = L.N
        red = Identity()
    else:
        # directions of relative mass below the cutoff are dropped: there the discrete forms are not
        # resolved against the mass (densities turn negative) and a refit can return a spurious eigenvalue
        red = E.Reducer(gram, cutoff)
    say(event='MODEL', dimension=dimension, cells=intervals, coarsening=m, angular=angular, shapes=[str(a) for a in shapes],
        pair=with_pair, unknowns=L.N, rank=red.rank, limits=limits, layers=len(L.layer_caps(extra)), outward=outward,
        outward_caps=outward_caps, reachable_sectors=int(np.count_nonzero(reference[:, 0])), epsilon=epsilon, mass_cutoff=cutoff,
        physical_outer=float(Q(str(r.geometry['parameters']['physical_outer']))), seconds=round(time.time() - t0, 1))
    pair_small = None
    if with_pair and not only_evaluate:
        _, pair = quiet(L.forms, lambda cap: [np.zeros(r.n)], extra_caps=extra, pair_kernels=('lift',))
        pair_small = red.small(pair[0])
        del pair
        say(event='PAIR_FORM', seconds=round(time.time() - t0, 1))

    def refit(prices):
        face, _ = quiet(L.forms, price_roles(prices, labels, PU, KER), extra_caps=extra, pair_kernels=(), role_faces=list(TYPES))
        small = [red.small(M) for M in face]
        operator = rho * (small[0] + small[1] + small[2])
        if with_pair:
            operator = operator - pair_small
        value, vec = E.top(operator)
        return value, vec, small

    fixed_vector = None
    if start is not None:
        with np.load(start, allow_pickle=False) as archive:
            vector = archive['vector']
            meta = json.loads(str(archive['meta'])) if 'meta' in archive else None
        assert vector.shape == (L.N,)
        if meta is not None:
            # the coefficient count does not identify the class: compare what was saved with what is asked
            asked = dict(dimension=dimension, angular=angular, shapes=[str(a) for a in shapes], pair=with_pair)
            assert all(meta[key] == value for key, value in asked.items()), (meta, asked)
        if only_evaluate:
            fixed_vector = vector / np.sqrt(float(vector @ gram @ vector))
            vec = None
            say(event='START', source=str(start), mode='fixed vector in full coefficient space', seconds=round(time.time() - t0, 1))
        else:
            vec = red.W.T @ (gram @ vector)
            captured = float(vec @ vec) / float(vector @ gram @ vector)
            vec = vec / np.sqrt(vec @ vec)
            say(event='START', source=str(start), mass_share_in_reduced_space=captured, seconds=round(time.time() - t0, 1))
    elif fixed_refit:
        # the trial of this class that is best for the stored price table itself (one eigenproblem)
        table = load_price_table(price_table, sectors)
        value, vec, _ = refit({t: table for t in TYPES})
        say(event='REFIT', round=-1, prices='stored price table %s on all faces' % Path(price_table).name, eigenvalue=value,
            pair_cost=float(vec @ pair_small @ vec) if with_pair else 0.0, seconds=round(time.time() - t0, 1))
    else:
        # prices for the stored trial's energies, regularised so that they are admissible on this grid
        _, stored_prices, stored_warm, info = dual_face(frame['energies'], frame, steps, None, reference, epsilon)
        value, vec, _ = refit({t: stored_prices for t in TYPES})
        say(event='REFIT', round=-1, prices='dual of the stored energies, regularised, on all faces',
            stored_energy_value=info['value'], eigenvalue=value,
            pair_cost=float(vec @ pair_small @ vec) if with_pair else 0.0, seconds=round(time.time() - t0, 1))

    warm = {t: None for t in TYPES}
    history = []
    for it in range(rounds + 1):
        t1 = time.time()
        vector = fixed_vector if only_evaluate else red.W @ vec
        by_face, negative, pair_free = face_energies(L, vector, labels, PU, KER, extra, sectors, with_pair and (only_evaluate or check))
        # every cell carrying energy must have a stored sector, and densities must be nonnegative up to rounding
        unlabelled = max(abs(float(by_face[t][sectors, 0])) for t in TYPES)
        if unlabelled >= 1e-12 or negative >= 1e-9:
            say(event='DENSITY_CHECK_FAILED', round=it, unlabelled_energy=unlabelled, negative_energy=negative,
                face_totals={t: float(by_face[t][:sectors, 0].sum()) for t in TYPES})
        assert unlabelled < 1e-12 and negative < 1e-6 * sum(float(by_face[t][:sectors, 0].sum()) for t in TYPES)
        prices, total, details = {}, 0.0, {}
        exact = 0.0
        for t in TYPES:
            value_t, prices[t], warm[t], info = dual_face(by_face[t][:sectors], frame, steps, warm[t], reference, epsilon)
            total += value_t
            exact += info['value_exact_corrections']
            details[t] = dict(info, unlabelled_energy=float(by_face[t][sectors, 0]))
        if only_evaluate:
            pair_cost = pair_free if with_pair else 0.0
        else:
            pair_cost = float(vec @ pair_small @ vec) if with_pair else 0.0
            if with_pair and check:
                say(event='CHECK_PAIR', round=it, from_matrix=pair_cost, matrix_free=pair_free, difference=abs(pair_cost - pair_free))
        extra_row = {}
        if price_table:
            fixed_total, stray, unpriced = fixed_price_value(by_face, price_table, sectors)
            extra_row = dict(fixed_price_table=Path(price_table).name, fixed_price_one_prime=fixed_total,
                             fixed_price_value=fixed_total - pair_cost, energy_in_unpriced_sectors=stray,
                             unpriced_sectors=unpriced)
        row = dict(round=it, value=total - pair_cost, value_exact_corrections=exact - pair_cost, one_prime_value=total,
                   pair_cost=pair_cost, negative_energy=negative, **extra_row,
                   faces=details, dual_seconds=round(time.time() - t1, 1), seconds=round(time.time() - t0, 1))
        history.append(row)
        say(event='VALUE', **row)
        if save:
            np.savez_compressed(save, vector=vector, value=total - pair_cost,
                                meta=json.dumps(dict(dimension=dimension, cells=intervals, angular=angular,
                                                     shapes=[str(a) for a in shapes], pair=with_pair, round=it)))
        if it == rounds:
            break
        eigenvalue, new_vec, small = refit(prices)
        if check:
            # the price forms at the old profile must reproduce the dual value
            replay = rho * sum(float(vec @ M @ vec) for M in small) - pair_cost
            say(event='CHECK_REPLAY', round=it, replay=replay, value=total - pair_cost, difference=abs(replay - (total - pair_cost)))
        vec = new_vec
        say(event='REFIT', round=it, eigenvalue=eigenvalue, pair_cost=float(vec @ pair_small @ vec) if with_pair else 0.0,
            seconds=round(time.time() - t0, 1))
    return dict(status='floating dual values on binary64 sector energies in the stored two-source table; cap level only; not a certificate',
                dimension=dimension, cells=intervals, coarsening=m, angular=angular, shapes=[str(a) for a in shapes], pair=with_pair,
                steps=steps, outward=outward, outward_caps=outward_caps, epsilon=epsilon, table=TABLE.name, dual=DUAL.name,
                certified_stored_value=frame['certified'],
                history=history)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gate', choices=['dual', 'shift', 'labels', 'symmetric', 'reference', 'prices'])
    parser.add_argument('--dimension', type=int, default=39)
    parser.add_argument('--pair', action='store_true', help='subtract the lift cost of the pair (a, b)')
    parser.add_argument('--intervals', type=int, default=32768)
    parser.add_argument('--angular', type=int, default=6)
    parser.add_argument('--shapes', default='0,100')
    parser.add_argument('--rounds', type=int, default=2)
    parser.add_argument('--steps', type=int, default=320, help='splitting steps per stage in each dual solve')
    parser.add_argument('--start', help='npz with a coefficient vector of the same class')
    parser.add_argument('--save', help='npz for the coefficient vector after each evaluation')
    parser.add_argument('--outward', type=int, default=0, help='sensitivity test: move labels outward by this many stored cells')
    parser.add_argument('--outward-caps', type=int, default=0, help='sensitivity test: move layers outward by this many stored cut caps')
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--epsilon', type=float, default=1e-9, help='weight of the reference table in each dual')
    parser.add_argument('--cutoff', type=float, default=1e-8, help='relative mass eigenvalue below which directions are dropped in refits')
    parser.add_argument('--price-table', help='also evaluate this stored per-sector price table (sector_prices, scale)')
    parser.add_argument('--fixed-refit', action='store_true', help='start from the trial that is best for --price-table')
    parser.add_argument('--output')
    args = parser.parse_args()
    if args.gate:
        frame = stored_frame()
        if args.gate == 'dual':
            gate_dual(frame, args.steps)
        elif args.gate == 'shift':
            gate_shift(frame, args.intervals)
        elif args.gate == 'labels':
            gate_labels(frame)
        elif args.gate == 'reference':
            gate_reference(frame, args.intervals, args.steps)
        elif args.gate == 'prices':
            gate_prices(frame, args.price_table)
        else:
            gate_symmetric(frame, args.intervals)
        return
    shapes = [x if x[0] in 'pqc' else float(x) for x in args.shapes.split(',')]
    result = run(args.dimension, args.intervals, args.angular, shapes, args.rounds, args.pair, args.steps,
                 start=args.start, save=args.save, outward=args.outward, check=args.check, epsilon=args.epsilon,
                 outward_caps=args.outward_caps, price_table=args.price_table, fixed_refit=args.fixed_refit,
                 cutoff=args.cutoff)
    if args.output:
        with open(args.output, 'w') as handle:
            json.dump(result, handle, indent=1)
            handle.write('\n')


if __name__ == '__main__':
    main()
