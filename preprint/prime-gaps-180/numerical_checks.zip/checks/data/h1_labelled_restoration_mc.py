"""Monte Carlo restoration inputs for the labelled 39-shift trial (floating, heuristic, not a proof).

This ports a marked-pair Monte Carlo written for the symmetric 38-shift trial (its
library is ../restoration/rlib.py) to the class of h1_native_endpoints.py: k-2 symmetric core coordinates and two
endpoint coordinates a, b with their own shapes, on the stored geometry of
h1_two_source_endpoints.py.  The price field is a stored per-sector price table (by default
the multilevel table), applied through the stored sector labels as there.

Steps (the first needs the pinned backend, the others numpy and scipy only):

  export    build the trial on the stored geometry from a saved coefficient vector and write
            its point-evaluation tables, the price field, the predicate rows of the geometry
            and the cap-level targets used by the validation
  validate  importance-sample full and retained configurations; estimate the mass I and the
            three face energies and the priced one-prime value, and compare them with the
            exported targets (this checks the point evaluation and the normalisation)
  outer     outer predicate failures by the exact (largest, second largest) marking: deleted
            mass A, cap-operator energy M, signed cross term X, by failure class
  inner     inner predicate failures of retained roots: their plain and price-weighted energy
  filter    the projection of the ledger: delete every full configuration in which some
            single-coordinate erasure fails the one-root tests that h1_multilevel_root_filter.json
            compiles for the twelve-level certificate (radius cap and tail tests of its group);
            unmarked importance sampling of full configurations, reporting the deleted mass and
            <e, C_+ F> in units of the sampled mass
  gates     build the per-root-class tail gates T(u) <= max(z, A, S - 2u) of the pairwise tail
            allowances: the class radius bounds and
            cap tops of h1_multilevel_partner_caps.cap_types and the common plateaus of
            h1_multilevel_plateau_screen.budgets, ported unchanged; needs the stored table and the
            small JSON inputs named in the arguments
  gate      the projection by those gates, applied to every erasure of sampled full configurations
  project   full configurations with at least one erasure failing its inner predicates, the set
            removed by projecting onto configurations whose every erasure passes: its mass and the
            cross term <e, C_+ F> of the positive part of the price field

Endpoint positions are drawn uniformly among ordered pairs of distinct coordinates for every
sample; the integrals are invariant under relabelling, so this averages over the owners of the
marked fragments correctly.  All results are normalised by the Monte Carlo mass I.

    python h1_labelled_restoration_mc.py export --dimension 39 --pair --angular 4 --shapes 0,p2,300 \\
        --intervals 32768 --start ts_g39a4.npz --out lrmc_39.npz
    python h1_labelled_restoration_mc.py validate lrmc_39.npz --seed 1 --batches 40
    python h1_labelled_restoration_mc.py outer lrmc_39.npz --seed 1 --batches 20 --region rank2 --mass I
    python h1_labelled_restoration_mc.py inner lrmc_39.npz --seed 1 --batches 20 --mass I
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'restoration'))
import rlib                                                    # noqa: E402  (Dickman functions, proposals, fragments)

UMIN = 0.002
PER = 20000


# ---------------------------------------------------------------- export (backend)
def export(args):
    import contextlib
    import io
    from fractions import Fraction as Q
    saved = list(sys.argv)
    sys.argv = sys.argv[:1]
    with contextlib.redirect_stdout(io.StringIO()):
        import h1_native_endpoints as E
        import h1_two_source_endpoints as TS
        from h1_geometry_scan import fit_geometry
        import flexible_fragment_geometry as geo
    sys.argv = saved
    t0 = time.time()
    shapes = [x if x[0] in 'pqc' else float(x) for x in args.shapes.split(',')]
    frame = TS.stored_frame()
    original = frame['original']
    sectors = len(frame['energies'])
    r, limits, sub, domains, fit, m = TS.stored_model(args.dimension, args.intervals, args.angular, frame)
    L = E.Labelled(args.dimension, args.intervals, args.angular, shapes, model=(r, limits, sub))
    with np.load(args.start, allow_pickle=False) as archive:
        vector = archive['vector']
        meta_saved = json.loads(str(archive['meta'])) if 'meta' in archive else None
    if meta_saved is not None:
        asked = dict(dimension=args.dimension, angular=args.angular, shapes=[str(a) for a in shapes], pair=args.pair)
        assert all(meta_saved[key] == value for key, value in asked.items()), (meta_saved, asked)
    gram = L.mass()
    vector = vector / np.sqrt(float(vector @ gram @ vector))
    extra = TS.layer_caps(frame, m)
    labels = TS.labeller(r, frame, m)
    PU, KER = TS.aux(r, original['max_radius'])
    rests, tables = L.fibre_tables(vector, extra)
    caps = sorted(tables)
    W_core = np.stack([tables[c][0] for c in caps]).astype(np.float64)
    W_a = np.stack([tables[c][1] for c in caps]).astype(np.float64)
    W_b = np.stack([tables[c][2] for c in caps]).astype(np.float64)
    # price field of the stored table on every layer
    prices = TS.load_price_table(args.price_table, sectors)
    field = np.zeros((len(caps), r.n))
    for i, cap in enumerate(caps):
        ids = labels(cap)
        ok = ids >= 0
        field[i, ok] = prices[ids[ok], 0] + prices[ids[ok], 1] * PU[ok] + prices[ids[ok], 2] * KER[ok]
    # group of the root filter for every retained cell of every layer (len(groups) = fixed sectors, -1 = none)
    certificate = json.loads(Path(args.groups).read_text())
    group_of = np.full(sectors, len(certificate['groups']), dtype=np.int64)
    for gi, members in enumerate(certificate['groups']):
        group_of[np.asarray(members, dtype=np.int64)] = gi
    group_table = np.full((len(caps), r.n), -1, dtype=np.int16)
    for i, cap in enumerate(caps):
        ids = labels(cap)
        ok = ids >= 0
        group_table[i, ok] = group_of[ids[ok]]
    from h1_geometry_scan import geometry as geom
    # amplitudes of the full profile
    amp = np.zeros((len(L.pairs), L.ncomp, len(L.sigs), r.n))
    for i in range(len(L.pairs)):
        for c in range(L.ncomp):
            block = vector[L.offset(i, c):L.offset(i, c) + L.nbase] * r.scale
            amp[i, c] = block.reshape(len(L.sigs), L.nr) @ r.radial_values
    full_cap = np.full(r.n, -1)
    for shell in r.shells['outer']:
        full_cap[r.mask(shell, r.k)] = shell[2]
    # cap-level targets on this grid (densities of the same vector)
    by_face, negative, pair_value = TS.face_energies(L, vector, labels, PU, KER, extra, sectors, with_pair=args.pair)
    fixed_total, stray, unpriced = TS.fixed_price_value(by_face, args.price_table, sectors)
    targets = {t: float(by_face[t][:sectors, 0].sum()) for t in TS.TYPES}
    # predicate rows of the geometry
    g, subs, self_source = fit_geometry(dict(radius=fit['radius']), args.dimension, 16384)
    rows = []
    for name in ('old_rows', 'new_rows'):
        for row in g[name]:
            if not row['retained']:
                continue
            rows.append(dict(ladder=row['ladder'], order=row['order'], xi=float(row['xi']), a=float(row['a']), b=float(row['b']),
                             A=float(row['A']), C=float(row['C']), L=float(row['L'])))
    chosen = next(d for d in subs['domains'] if d['id'] == subs['recommended_id'])
    groups = {G['id']: float(G['split']) for G in g['source_groups'] if not G.get('empty') and 'split' in G}
    shells = lambda lst: [(float(x), float(y), int(c)) for x, y, c in lst]
    meta = dict(dimension=args.dimension, cells=args.intervals, n=r.n, h=float(r.exact_step), S=float(r.geometry['parameters']['S']),
                rho=float(r.rho), zeta=float(r.geometry['parameters']['normalized_prime_cap']), shapes=[str(a) for a in shapes],
                pairs=[list(p) for p in L.pairs], sigs=[list(s) for s in L.sigs], rests=[list(s) for s in rests],
                limits=[int(x) for x in L.limits], caps=[int(c) for c in caps], pair=args.pair,
                rho_ticks=float(geom.RHO), groups_file=Path(args.groups).name, ngroups=len(certificate['groups']),
                start=str(args.start), price_table=Path(args.price_table).name,
                targets=dict(faces=targets, priced_one_prime=fixed_total, pair_cost=pair_value, negative_energy=negative,
                             unpriced_energy=stray),
                rows=rows, groups=groups,
                subtraction={kk: str(v) for kk, v in chosen.items() if not isinstance(v, (list, dict))},
                shells_outer=shells(r.shells['outer']), shells_base=shells(r.shells['base']),
                shells_enlarged=shells(r.shells['enlarged']), shells_sub=shells(sub), seconds=round(time.time() - t0, 1))
    np.savez_compressed(args.out, amp=amp, full_cap=full_cap, W_core=W_core, W_a=W_a, W_b=W_b, field=field, group_table=group_table,
                        g=r.g, t=r.t, psi=np.stack(L.psi), prime_upper=PU, kernel=KER, meta=json.dumps(meta))
    print(json.dumps(dict(event='EXPORT', out=args.out, layers=len(caps), rests=meta['rests'], targets=meta['targets'],
                          rows=len(rows), groups=groups, seconds=meta['seconds'])), flush=True)


# ---------------------------------------------------------------- point evaluation
class Trial:
    def __init__(self, path):
        z = np.load(path, allow_pickle=False)
        self.m = json.loads(str(z['meta']))
        m = self.m
        self.k, self.n, self.h, self.S, self.rho, self.zeta = m['dimension'], m['n'], m['h'], m['S'], m['rho'], m['zeta']
        self.amp, self.full_cap = z['amp'], z['full_cap']
        self.W_core, self.W_a, self.W_b, self.field = z['W_core'], z['W_a'], z['W_b'], z['field']
        self.g, self.tm, self.psi = z['g'], z['t'], z['psi']
        self.group_table = z['group_table'] if 'group_table' in z.files else None
        self.caps = np.array(m['caps'])
        self.limits = np.array(m['limits'])
        self.pairs = [tuple(p) for p in m['pairs']]
        self.sigs = [tuple(s) for s in m['sigs']]
        self.rests = [tuple(s) for s in m['rests']]
        self.B = self.psi.shape[0]
        self.powers = sorted({p for s in self.sigs + self.rests for p in s}) or [2]

    def negate(self):
        """F -> -F (and every erased profile with it): quadratic quantities are unchanged, and the
        sign-dependent estimates, which take the majority sign to be negative, become applicable to a
        trial whose majority is positive."""
        self.amp = -self.amp
        self.W_core, self.W_a, self.W_b = -self.W_core, -self.W_a, -self.W_b

    def gfun(self, x):
        return np.interp(x, self.tm, self.g)

    def cells(self, t):
        return np.minimum(np.floor(t / self.h).astype(np.int64), self.n - 1)

    def sigval(self, ps, sig):
        out = 1.0
        for p in sig:
            out = out * ps[p]
        return out

    def core_sums(self, tm, core):
        return {p: (np.where(core, tm ** p, 0.0)).sum(axis=-1) for p in self.powers}

    def F(self, t, M0, pa, pb):
        """Full profile; t (n,k), M0 (n,), endpoint positions pa, pb (n,)."""
        n_, k = t.shape
        rows = np.arange(n_)
        j = self.cells(t)
        r = j.sum(axis=1)
        inside = r <= self.n - 1
        rr = np.where(inside, r, 0)
        tm = self.tm[j]
        core = np.ones(t.shape, bool)
        core[rows, pa] = False
        core[rows, pb] = False
        ps = self.core_sums(tm, core)
        ja, jb = j[rows, pa], j[rows, pb]
        mc = M0 / self.h
        ok = inside & (mc <= self.full_cap[rr])
        val = np.zeros(n_)
        for c in range(len(self.limits)):
            act = ok & (mc <= self.limits[c])
            if not act.any():
                continue
            acc = np.zeros(n_)
            for i, (ma, mb) in enumerate(self.pairs):
                shape = self.psi[ma][ja] * self.psi[mb][jb]
                inner = np.zeros(n_)
                for si, sig in enumerate(self.sigs):
                    inner += self.amp[i, c, si][rr] * self.sigval(ps, sig)
                acc += shape * inner
            val += np.where(act, acc, 0.0)
        val *= np.prod(self.g[j], axis=1)
        return np.where(ok, val, 0.0)

    def layer(self, M0):
        lay = np.searchsorted(self.caps, M0 / self.h, side='left')
        return lay, lay < len(self.caps)

    def V(self, kind, j, M0, pa=None, pb=None):
        """Erased profile at retained configurations: j (n,d) cell indices of the retained coordinates.

        kind 'core': endpoints at retained positions pa, pb; 'a': endpoint a erased, b at position pb;
        'b': endpoint b erased, a at position pa.  Returns (V, price at the root)."""
        n_, d = j.shape
        rows = np.arange(n_)
        r = j.sum(axis=1)
        inside = (r >= 0) & (r <= self.n - 1)
        rr = np.where(inside, r, 0)
        lay, okl = self.layer(M0)
        ll = np.where(okl, lay, 0)
        tm = self.tm[j]
        core = np.ones(j.shape, bool)
        if pa is not None:
            core[rows, pa] = False
        if pb is not None:
            core[rows, pb] = False
        ps = self.core_sums(tm, core)
        acc = np.zeros(n_)
        if kind == 'core':
            ja, jb = j[rows, pa], j[rows, pb]
            for ri, rest in enumerate(self.rests):
                pv = self.sigval(ps, rest)
                for ma in range(self.B):
                    for mb in range(self.B):
                        acc += self.W_core[ll, ri, ma, mb, rr] * self.psi[ma][ja] * self.psi[mb][jb] * pv
        elif kind == 'a':
            jb = j[rows, pb]
            for si, sig in enumerate(self.sigs):
                pv = self.sigval(ps, sig)
                for mb in range(self.B):
                    acc += self.W_a[ll, si, mb, rr] * self.psi[mb][jb] * pv
        else:
            ja = j[rows, pa]
            for si, sig in enumerate(self.sigs):
                pv = self.sigval(ps, sig)
                for ma in range(self.B):
                    acc += self.W_b[ll, si, ma, rr] * self.psi[ma][ja] * pv
        acc *= self.h * np.prod(self.g[j], axis=1)
        good = inside & okl
        price = np.where(good, self.field[ll, rr], 0.0)
        return np.where(good, acc, 0.0), price


def positions(rng, n_, d, count):
    """count distinct positions per row, uniform among ordered tuples of distinct indices of range(d)."""
    keys = rng.random((n_, d))
    return np.argsort(keys, axis=1)[:, :count].T


# ---------------------------------------------------------------- validation
def validate(args):
    T = Trial(args.trial)
    rng = np.random.default_rng(args.seed)
    k, S, zeta = T.k, T.S, T.zeta
    prop = rlib.Proposal(S, T.gfun, np.linspace(0, 120, 25), zeta)
    t0 = time.time()

    def mixture(dim):
        use = np.flatnonzero((prop.mean * dim > .3) & (prop.mean * dim < 1.15))

        def logq(t):
            Lg = np.array([np.log(prop.density(np.full(len(t), b), t)).sum(axis=1) for b in use]) - np.log(len(use))
            mx = Lg.max(axis=0)
            return mx + np.log(np.exp(Lg - mx).sum(axis=0))

        def draw(n_):
            bi = use[rng.integers(0, len(use), n_)]
            t = prop.sample(bi, dim, rng)
            M0 = rlib.largest(t, zeta, rng).max(axis=1)
            return t, M0, np.log(rlib.rho(t / zeta)).sum(axis=1) - logq(t)
        return draw

    draw_full, draw_ret = mixture(k), mixture(k - 1)
    acc = {key: [] for key in ('I', 'Ineg', 'Ipos', 'core', 'a', 'b', 'priced')}
    for _ in range(args.batches):
        n_ = 20000
        t, M0, lw = draw_full(n_)
        pa, pb = positions(rng, n_, k, 2)
        F = T.F(t, M0, pa, pb)
        acc['I'].append(np.exp(lw) * F * F)
        acc['Ineg'].append(np.exp(lw) * F * F * (F < 0))
        acc['Ipos'].append(np.exp(lw) * F * F * (F > 0))
        t, M0, lw = draw_ret(n_)
        j = T.cells(t)
        w = np.exp(lw)
        pa, pb = positions(rng, n_, k - 1, 2)
        Vc, ac = T.V('core', j, M0, pa, pb)
        Va, aa = T.V('a', j, M0, None, pb)
        Vb, ab = T.V('b', j, M0, pa, None)
        acc['core'].append(w * Vc * Vc)
        acc['a'].append(w * Va * Va)
        acc['b'].append(w * Vb * Vb)
        acc['priced'].append(w * ((k - 2) * ac * Vc * Vc + aa * Va * Va + ab * Vb * Vb))
    est = {key: (float(np.mean(np.concatenate(v))), float(np.std(np.concatenate(v)) / np.sqrt(sum(len(x) for x in v))))
           for key, v in acc.items()}
    I, dI = est['I']
    rho = T.rho
    faces = dict(core=rho * (k - 2) * est['core'][0] / I, a=rho * est['a'][0] / I, b=rho * est['b'][0] / I)
    rel = {key: float(np.hypot(dI / I, est[key][1] / est[key][0])) for key in ('core', 'a', 'b', 'priced')}
    out = dict(event='VALIDATE', samples=args.batches * 20000, I=I, I_relerr=dI / I,
               negative_mass_share=est['Ineg'][0] / I, negative_mass_share_se=est['Ineg'][1] / I,
               positive_mass_share=est['Ipos'][0] / I, positive_mass_share_se=est['Ipos'][1] / I,
               faces=faces, faces_relerr=rel,
               priced_one_prime=rho * est['priced'][0] / I, targets=T.m['targets'], seconds=round(time.time() - t0, 1))
    print(json.dumps(out), flush=True)


# ---------------------------------------------------------------- predicates (as outer_mc.py and inner_mc.py)
class Rows:
    def __init__(self, meta):
        rows = meta['rows']
        self.rows = rows
        self.a = np.array([r['a'] for r in rows]); self.A = np.array([r['A'] for r in rows])
        self.b = np.array([r['b'] for r in rows]); self.C = np.array([r['C'] for r in rows])
        self.xi = np.array([r['xi'] for r in rows]); self.order = np.array([r['order'] for r in rows])
        self.L = np.array([r['L'] for r in rows]); self.ladder = np.array([r['ladder'] for r in rows])
        self.c3 = min(r['a'] for r in rows if r['order'] == 3)
        self.Lmax = self.L[self.order == 3].max()

    def outer(self, f, P, s):
        phis = {}
        for cls in ('lin', 'old3', 'new3'):
            if cls == 'lin':
                ph = f
            else:
                Lc = self.L[(self.order == 3) & (self.ladder == cls[:3])][0]
                ph = np.minimum(1.5 * f, Lc)
            phis[cls] = np.maximum.accumulate(np.where(f > 0, P + ph, -np.inf), axis=1)
        fails = np.zeros((len(s), len(self.rows)), bool)
        for ri in range(len(self.rows)):
            cls = 'lin' if self.order[ri] < 3 else self.ladder[ri] + '3'
            J = (f > self.xi[ri]).sum(axis=1)
            Hv = np.where(J > 0, np.take_along_axis(phis[cls], np.maximum(J - 1, 0)[:, None], axis=1)[:, 0], -np.inf)
            fails[:, ri] = (s > self.a[ri]) & (Hv > self.A[ri])
        return fails.any(axis=1), fails

    @staticmethod
    def H(f, P, kind, L, xi):
        if kind == 'lin':
            ph = f
        elif kind == 'E':
            ph = np.maximum(1.5 * f, 3 * f - L)
        else:
            ph = np.minimum(1.5 * f, L)
        Hrun = np.maximum.accumulate(np.where(f > 0, P + ph, -np.inf), axis=1)
        J = (f > xi).sum(axis=1)
        return np.where(J > 0, np.take_along_axis(Hrun, np.maximum(J - 1, 0)[:, None], axis=1)[:, 0], -np.inf)

    def inner(self, f, P, s):
        out = np.zeros((len(s), len(self.rows)), bool)
        Mxi = f[:, 0]
        for ri in range(len(self.rows)):
            if self.order[ri] < 2:
                continue
            if self.order[ri] == 2:
                bad = self.H(f, P, 'lin', 0, self.xi[ri]) > self.C[ri]
            else:
                Hv = self.H(f, P, 'E', self.L[ri], self.xi[ri])
                bad = (Hv > self.C[ri]) | (np.minimum(1.5 * Mxi, self.L[ri]) > self.A[ri])
            out[:, ri] = (s > self.b[ri]) & bad
        return out


def shell_member(shells, end, M0, h):
    ok = np.zeros(np.shape(end), bool)
    for lo, hi, cap in shells:
        ok |= (end > lo) & (end <= hi) & (M0 <= cap * h)
    return ok


# ---------------------------------------------------------------- outer
def outer(args):
    T = Trial(args.trial)
    R = Rows(T.m)
    rng = np.random.default_rng(args.seed)
    k, S, zeta, h = T.k, T.S, T.zeta, T.h
    I = args.mass
    QMAX = T.caps.max() * h + 1e-9
    prop = rlib.Proposal(S, T.gfun, np.geomspace(1, 6000, 80), zeta)
    kmean = prop.mean * k
    in_rank2 = lambda q, w: q + w + np.minimum(1.5 * w, R.Lmax) > R.A.min() - 1e-12
    cache = {}

    def sample_qw(n_):
        if args.region == 'rank2':
            wl = (R.A.min() - QMAX) / 2.5
            out_q, out_w, need = [], [], n_
            while need > 0:
                q = rng.uniform(wl, QMAX, 4 * need); w = rng.uniform(wl, QMAX, 4 * need)
                ok = (w < q) & in_rank2(q, w)
                out_q.append(q[ok]); out_w.append(w[ok]); need -= ok.sum()
            q = np.concatenate(out_q)[:n_]; w = np.concatenate(out_w)[:n_]
            if 'area' not in cache:
                gq = np.linspace(wl, QMAX, 2001); gm = (gq[1:] + gq[:-1]) / 2
                Qg, Wg = np.meshgrid(gm, gm, indexing='ij')
                cache['area'] = ((Wg < Qg) & in_rank2(Qg, Wg)).sum() * (gq[1] - gq[0]) ** 2
            return q, w, np.full(n_, -np.log(cache['area']))
        QLO, WLO = 0.08, 0.04
        out_q, out_w, need = [], [], n_
        while need > 0:
            q = np.exp(rng.uniform(np.log(QLO), np.log(QMAX), 3 * need)); w = np.exp(rng.uniform(np.log(WLO), np.log(QMAX), 3 * need))
            ok = (w < q) & ~in_rank2(q, w)
            out_q.append(q[ok]); out_w.append(w[ok]); need -= ok.sum()
        q = np.concatenate(out_q)[:n_]; w = np.concatenate(out_w)[:n_]
        if 'frac' not in cache:
            gl = np.linspace(np.log(QLO), np.log(QMAX), 1501); gm = (gl[1:] + gl[:-1]) / 2
            gw = np.linspace(np.log(WLO), np.log(QMAX), 1501); gwm = (gw[1:] + gw[:-1]) / 2
            LQ, LW = np.meshgrid(gm, gwm, indexing='ij')
            cache['frac'] = ((np.exp(LW) < np.exp(LQ)) & ~in_rank2(np.exp(LQ), np.exp(LW))).sum() * (gl[1] - gl[0]) * (gw[1] - gw[0])
        return q, w, -np.log(q * w * cache['frac'])

    keys = ('A', 'M', 'MCS', 'X', 'Mp', 'MpCS', 'Xp', 'Xm', 'Aneg')
    comps = {}
    diag = dict(samples=0, failures=0)
    t0 = time.time()
    for it in range(args.batches):
        for same in (False, True):
            q, w, lpq = sample_qw(PER)
            n_ = len(q)
            target = np.maximum(S - q - w - 0.035, 0.002)
            bi = np.abs(kmean[None, :] - target[:, None]).argmin(axis=1)
            rest = prop.sample(bi, k, rng)
            lw = np.log(rlib.rho(rest / w[:, None])).sum(axis=1) - np.log(prop.density(bi, rest)).sum(axis=1)
            frag, dust = rlib.fragments(rest, np.broadcast_to(w[:, None], rest.shape), UMIN, rng)
            t = rest.copy()
            t[:, 0] += q
            if same:
                t[:, 0] += w
            else:
                t[:, 1] += w
            s = t.sum(axis=1)
            pa, pb = positions(rng, n_, k, 2)
            F = T.F(t, q, pa, pb)
            pooled = -np.sort(-np.concatenate([q[:, None], w[:, None], frag.reshape(n_, -1)], axis=1), axis=1)[:, :60]
            P = np.cumsum(pooled, axis=1)
            fail, fr = R.outer(pooled, P, s)
            mult = k if same else k * (k - 1)
            wt = mult * np.exp(lw - lpq - np.log(q * w)) / I
            diag['samples'] += n_
            f = fail & (F != 0)
            diag['failures'] += int(f.sum())
            if not f.any():
                continue
            idx = np.flatnonzero(f)
            CF, CS, CFp, CFm, CSp = cap_operator(T, t[idx], q[idx], w[idx], frag[idx], same, pa[idx], pb[idx])
            Ff, wf, sf, qf, wwf = F[idx], wt[idx], s[idx], q[idx], w[idx]
            grp = np.where(sf > R.c3, 'G2', 'G1')
            phw = np.where(R.order[None, :] < 3, wwf[:, None], np.minimum(1.5 * wwf[:, None], R.L[None, :]))
            r2 = ((qf + wwf)[:, None] + phw > R.A[None, :]) & (wwf[:, None] > R.xi[None, :]) & (sf[:, None] > R.a[None, :])
            third = pooled[idx, 2]
            split = np.where(grp == 'G2', T.m['groups'].get('G2', 0.0), T.m['groups'].get('G1', 0.0))
            kind = np.where(r2.any(axis=1), 'rank2', np.where(third > split, 'high', 'low'))
            for gname in ('G1', 'G2'):
                for kname in ('rank2', 'high', 'low'):
                    sel = (grp == gname) & (kind == kname)
                    if not sel.any():
                        continue
                    c = comps.setdefault('%s:%s' % (gname, kname), {x: np.zeros(args.batches) for x in keys})
                    c['A'][it] += np.sum(wf[sel] * Ff[sel] ** 2) / PER
                    c['M'][it] += np.sum(wf[sel] * CF[sel] ** 2) / PER
                    c['MCS'][it] += np.sum(wf[sel] * CS[sel]) / PER
                    c['X'][it] += np.sum(wf[sel] * Ff[sel] * CF[sel]) / PER
                    c['Mp'][it] += np.sum(wf[sel] * CFp[sel] ** 2) / PER
                    c['MpCS'][it] += np.sum(wf[sel] * CSp[sel]) / PER
                    c['Xp'][it] += np.sum(wf[sel] * Ff[sel] * CFp[sel]) / PER
                    c['Xm'][it] += np.sum(wf[sel] * Ff[sel] * CFm[sel]) / PER
                    neg = sel & (Ff < 0)
                    c['Aneg'][it] += np.sum(wf[neg] * Ff[neg] ** 2) / PER
        if (it + 1) % max(1, args.batches // 5) == 0:
            print(json.dumps(dict(event='PROGRESS', batch=it + 1, samples=diag['samples'], failures=diag['failures'],
                                  seconds=round(time.time() - t0))), flush=True)
    res = {}
    for key, c in comps.items():
        res[key] = {x: float(v.mean()) for x, v in c.items()}
        res[key].update({x + '_se': float(v.std(ddof=1) / np.sqrt(args.batches)) for x, v in c.items()} if args.batches > 1 else {})
    totals = {x: float(sum(c[x] for c in comps.values()).mean()) for x in keys} if comps else {}
    if comps and args.batches > 1:
        totals.update({x + '_se': float(sum(c[x] for c in comps.values()).std(ddof=1) / np.sqrt(args.batches)) for x in ('A', 'M', 'X', 'Xp')})
    print(json.dumps(dict(event='OUTER', region=args.region, seed=args.seed, batches=args.batches, mass=I, diag=diag,
                          totals=totals, components=res, seconds=round(time.time() - t0))), flush=True)


def largest_fragments(frag, q, w, same):
    lf = frag[:, :, 0].copy() if frag.shape[2] else np.zeros(frag.shape[:2])
    lf[:, 0] = q
    if not same:
        lf[:, 1] = np.maximum(lf[:, 1], w)
    return lf


def cap_operator(T, t, q, w, frag, same, pa, pb, lf=None, fail=None):
    """C'F = rho sum_i a(X^_i) V_i(X^_i) at failing full configurations, with Cauchy-Schwarz and sign parts.

    lf, if given, is the largest fragment of every coordinate; otherwise it is built from the marked pair.
    fail, if given (n, k) boolean, marks the erasures whose roots fail; the positive-price part of the
    sum over those erasures alone is then returned as a sixth value."""
    n_, k = t.shape
    rows = np.arange(n_)
    j = T.cells(t)
    if lf is None:
        lf = largest_fragments(frag, q, w, same)
    order = -np.sort(-lf, axis=1)
    top1, top2 = order[:, 0], order[:, 1]
    CF = np.zeros(n_); CS_a = np.zeros(n_); CS_v = np.zeros(n_)
    CFp = np.zeros(n_); CFm = np.zeros(n_); CSp_a = np.zeros(n_); CSp_v = np.zeros(n_)
    CFp_fail = np.zeros(n_)
    all_idx = np.arange(k)
    for e in range(k):
        keep = all_idx != e
        jY = j[:, keep]
        M0Y = np.where(lf[:, e] >= top1, top2, top1)
        # positions of the endpoints among the retained coordinates
        shift = lambda p: p - (p > e)
        is_a, is_b = pa == e, pb == e
        V = np.zeros(n_); a = np.zeros(n_)
        core_rows = ~(is_a | is_b)
        if core_rows.any():
            sel = np.flatnonzero(core_rows)
            v, pr = T.V('core', jY[sel], M0Y[sel], shift(pa[sel]), shift(pb[sel]))
            V[sel] = v; a[sel] = pr
        if is_a.any():
            sel = np.flatnonzero(is_a)
            v, pr = T.V('a', jY[sel], M0Y[sel], None, shift(pb[sel]))
            V[sel] = v; a[sel] = pr
        if is_b.any():
            sel = np.flatnonzero(is_b)
            v, pr = T.V('b', jY[sel], M0Y[sel], shift(pa[sel]), None)
            V[sel] = v; a[sel] = pr
        CF += a * V
        CS_a += np.abs(a); CS_v += np.abs(a) * V * V
        ap, am = np.maximum(a, 0), np.maximum(-a, 0)
        CFp += ap * V; CFm += am * V
        if fail is not None:
            CFp_fail += np.where(fail[:, e], ap * V, 0.0)
        CSp_a += ap; CSp_v += ap * V * V
    rho = T.rho
    if fail is not None:
        return rho * CF, rho ** 2 * CS_a * CS_v, rho * CFp, rho * CFm, rho ** 2 * CSp_a * CSp_v, rho * CFp_fail
    return rho * CF, rho ** 2 * CS_a * CS_v, rho * CFp, rho * CFm, rho ** 2 * CSp_a * CSp_v


# ---------------------------------------------------------------- inner
def inner(args):
    T = Trial(args.trial)
    R = Rows(T.m)
    rng = np.random.default_rng(args.seed)
    k, S, zeta, h = T.k, T.S, T.zeta, T.h
    d = k - 1
    I = args.mass
    sub = T.m['subtraction']
    from fractions import Fraction as Q
    SC = float(Q(sub['radius'])) if sub.get('radius') not in (None, 'None') else None
    coreC = float(Q(sub['core'])); xiC = float(Q(sub['xi'])); thrC = float(Q(sub['threshold']))
    prop = rlib.Proposal(S, T.gfun, np.geomspace(1, 6000, 80), zeta)
    kmean = prop.mean * d
    WLO, QHI = (0.17, 0.52) if args.region == 'rank2' else (0.04, 0.52)

    def sample_qw(n_):
        if args.region == 'rank2':
            q = rng.uniform(WLO, QHI, 3 * n_); w = rng.uniform(WLO, QHI, 3 * n_)
            ok = (w < q) & (q + 2.5 * w > 0.88)
            q, w = q[ok][:n_], w[ok][:n_]
            gq = np.linspace(WLO, QHI, 1501); gm = (gq[1:] + gq[:-1]) / 2
            Qg, Wg = np.meshgrid(gm, gm, indexing='ij')
            area = ((Wg < Qg) & (Qg + 2.5 * Wg > 0.88)).sum() * (gq[1] - gq[0]) ** 2
            return q, w, np.full(len(q), -np.log(area))
        lq = rng.uniform(np.log(0.08), np.log(QHI), 3 * n_); lw_ = rng.uniform(np.log(WLO), np.log(QHI), 3 * n_)
        q, w = np.exp(lq), np.exp(lw_)
        ok = (w < q) & ~(q + 2.5 * w > 0.88)
        q, w = q[ok][:n_], w[ok][:n_]
        gl = np.linspace(np.log(0.08), np.log(QHI), 1201); gm = (gl[1:] + gl[:-1]) / 2
        gw = np.linspace(np.log(WLO), np.log(QHI), 1201); gwm = (gw[1:] + gw[:-1]) / 2
        LQ, LW = np.meshgrid(gm, gwm, indexing='ij')
        frac = ((LW < LQ) & ~(np.exp(LQ) + 2.5 * np.exp(LW) > 0.88)).sum() * (gl[1] - gl[0]) * (gw[1] - gw[0])
        return q, w, -np.log(q * w * frac)

    keys = ('E_fail', 'E_fail_priced', 'E_fail_new', 'E_fail_new_priced', 'E_H1', 'E_H0')
    acc = {x: np.zeros(args.batches) for x in keys}
    nfail = 0
    t0 = time.time()
    for it in range(args.batches):
        for same in (False, True):
            q, w, lpq = sample_qw(PER)
            n_ = len(q)
            target = np.maximum(args.target - q - w, 0.002)
            bi = np.abs(kmean[None, :] - target[:, None]).argmin(axis=1)
            rest = prop.sample(bi, d, rng)
            lw = np.log(rlib.rho(rest / w[:, None])).sum(axis=1) - np.log(prop.density(bi, rest)).sum(axis=1)
            frag, dust = rlib.fragments(rest, np.broadcast_to(w[:, None], rest.shape), UMIN, rng)
            t = rest.copy(); t[:, 0] += q
            if same:
                t[:, 0] += w
            else:
                t[:, 1] += w
            s = t.sum(axis=1)
            j = T.cells(t)
            rY = j.sum(axis=1)
            pa, pb = positions(rng, n_, d, 2)
            Vc, ac = T.V('core', j, q, pa, pb)
            Va, aa = T.V('a', j, q, None, pb)
            Vb, ab = T.V('b', j, q, pa, None)
            energy = (k - 2) * Vc * Vc + Va * Va + Vb * Vb
            priced = (k - 2) * np.maximum(ac, 0) * Vc * Vc + np.maximum(aa, 0) * Va * Va + np.maximum(ab, 0) * Vb * Vb
            end = (rY + k - 1) * h
            H0 = shell_member(T.m['shells_base'], end, q, h)
            H1 = shell_member(T.m['shells_enlarged'], end, q, h)
            HC = shell_member(T.m['shells_sub'], end, q, h) | H1
            pooled = -np.sort(-np.concatenate([q[:, None], w[:, None], frag.reshape(n_, -1)], axis=1), axis=1)[:, :60]
            P = np.cumsum(pooled, axis=1)
            fr = R.inner(pooled, P, s)
            fail_old = fr[:, R.ladder == 'old'].any(axis=1); fail_new = fr[:, R.ladder == 'new'].any(axis=1)
            HsubC = R.H(pooled, P, 'lin', 0, xiC)
            failC = ((s > SC) if SC is not None else False) | ((s > coreC) & (HsubC > thrC))
            notL0 = H0 & (fail_old | fail_new)
            notL1 = H1 & fail_new
            notC = HC & failC
            failany = notL0 | notL1 | notC
            mult = d if same else d * (d - 1)
            wt = mult * np.exp(lw - lpq - np.log(q * w)) / I
            acc['E_fail'][it] += np.sum((wt * energy)[failany]) / PER
            acc['E_fail_priced'][it] += np.sum((wt * priced)[failany]) / PER
            acc['E_fail_new'][it] += np.sum((wt * energy)[notL1]) / PER
            acc['E_fail_new_priced'][it] += np.sum((wt * priced)[notL1]) / PER
            acc['E_H1'][it] += np.sum((wt * energy)[H1]) / PER
            acc['E_H0'][it] += np.sum((wt * energy)[H0]) / PER
            nfail += int(failany.sum())
        if (it + 1) % max(1, args.batches // 5) == 0:
            print(json.dumps(dict(event='PROGRESS', batch=it + 1, failures=nfail, seconds=round(time.time() - t0))), flush=True)
    rho = T.rho
    res = {x: dict(mean=float(rho * v.mean()), se=float(rho * v.std(ddof=1) / np.sqrt(args.batches)) if args.batches > 1 else None)
           for x, v in acc.items()}
    print(json.dumps(dict(event='INNER', region=args.region, seed=args.seed, batches=args.batches, mass=I, failures=nfail,
                          results=res, note='energies carry rho and the face multiplicities and are divided by I; '
                                            'E_H0, E_H1 are energies of the sampled box only',
                          seconds=round(time.time() - t0))), flush=True)


def project(args):
    """Deleted set of the projection onto configurations all of whose erasures pass their inner tests.

    Samples full configurations with the marked pair (q, w) in the box of inner(); for every coordinate
    e the retained root X^_e is tested with the inner predicates of the ladders and the subtraction
    source on its own pooled fragments, total and domain.  Reports the mass of the configurations with
    at least one failing erasure and <e, C F>, <e, C_+ F> over them, in units of the mass I."""
    from fractions import Fraction as Q
    T = Trial(args.trial)
    R = Rows(T.m)
    rng = np.random.default_rng(args.seed)
    k, S, zeta, h = T.k, T.S, T.zeta, T.h
    I = args.mass
    sub = T.m['subtraction']
    SC = float(Q(sub['radius'])) if sub.get('radius') not in (None, 'None') else None
    coreC = float(Q(sub['core'])); xiC = float(Q(sub['xi'])); thrC = float(Q(sub['threshold']))
    prop = rlib.Proposal(S, T.gfun, np.geomspace(1, 6000, 80), zeta)
    kmean = prop.mean * k
    WLO, QHI = 0.17, 0.52

    def sample_qw(n_):
        q = rng.uniform(WLO, QHI, 3 * n_); w = rng.uniform(WLO, QHI, 3 * n_)
        ok = (w < q) & (q + 2.5 * w > 0.88)
        q, w = q[ok][:n_], w[ok][:n_]
        gq = np.linspace(WLO, QHI, 1501); gm = (gq[1:] + gq[:-1]) / 2
        Qg, Wg = np.meshgrid(gm, gm, indexing='ij')
        area = ((Wg < Qg) & (Qg + 2.5 * Wg > 0.88)).sum() * (gq[1] - gq[0]) ** 2
        return q, w, np.full(len(q), -np.log(area))

    keys = ('A', 'X', 'Xp', 'Aneg', 'fail_erasures')
    acc = {x: np.zeros(args.batches) for x in keys}
    nfail = 0
    t0 = time.time()
    for it in range(args.batches):
        for same in (False, True):
            q, w, lpq = sample_qw(PER)
            n_ = len(q)
            target = np.maximum(S - q - w - 0.035, 0.002)
            bi = np.abs(kmean[None, :] - target[:, None]).argmin(axis=1)
            rest = prop.sample(bi, k, rng)
            lw = np.log(rlib.rho(rest / w[:, None])).sum(axis=1) - np.log(prop.density(bi, rest)).sum(axis=1)
            frag, dust = rlib.fragments(rest, np.broadcast_to(w[:, None], rest.shape), UMIN, rng)
            # fragments per coordinate, the marked ones included
            per = np.concatenate([np.zeros((n_, k, 2)), frag], axis=2)
            per[:, 0, 0] = q
            if same:
                per[:, 0, 1] = w
            else:
                per[:, 1, 1] = w
            t = rest.copy(); t[:, 0] += q
            if same:
                t[:, 0] += w
            else:
                t[:, 1] += w
            s = t.sum(axis=1)
            j = T.cells(t)
            r = j.sum(axis=1)
            pa, pb = positions(rng, n_, k, 2)
            F = T.F(t, q, pa, pb)
            live = np.flatnonzero(F != 0)
            if not len(live):
                continue
            failed = np.zeros(n_, bool)
            count = np.zeros(n_)
            # the 80 largest fragments of each configuration with their owners, sorted once
            flat = per[live].reshape(len(live), -1)
            owner = np.broadcast_to(np.repeat(np.arange(k), per.shape[2])[None, :], flat.shape)
            order = np.argsort(-flat, axis=1)[:, :80]
            top = np.take_along_axis(flat, order, axis=1)
            own = np.take_along_axis(owner, order, axis=1)
            for e in range(k):
                pooled = np.where(own == e, 0.0, top)
                pooled = -np.sort(-pooled, axis=1)[:, :60]
                P = np.cumsum(pooled, axis=1)
                sY = s[live] - t[live, e]
                M0 = pooled[:, 0]
                end = (r[live] - j[live, e] + k - 1) * h
                H0 = shell_member(T.m['shells_base'], end, M0, h)
                H1 = shell_member(T.m['shells_enlarged'], end, M0, h)
                HC = shell_member(T.m['shells_sub'], end, M0, h) | H1
                fr = R.inner(pooled, P, sY)
                fail_old = fr[:, R.ladder == 'old'].any(axis=1); fail_new = fr[:, R.ladder == 'new'].any(axis=1)
                HsubC = R.H(pooled, P, 'lin', 0, xiC)
                failC = ((sY > SC) if SC is not None else False) | ((sY > coreC) & (HsubC > thrC))
                bad = (H0 & (fail_old | fail_new)) | (H1 & fail_new) | (HC & failC)
                failed[live] |= bad
                count[live] += bad
            idx = np.flatnonzero(failed)
            mult = k if same else k * (k - 1)
            wt = mult * np.exp(lw - lpq - np.log(q * w)) / I
            nfail += len(idx)
            if not len(idx):
                continue
            CF, CS, CFp, CFm, CSp = cap_operator(T, t[idx], q[idx], w[idx], frag[idx], same, pa[idx], pb[idx])
            Ff, wf = F[idx], wt[idx]
            acc['A'][it] += np.sum(wf * Ff ** 2) / PER
            acc['X'][it] += np.sum(wf * Ff * CF) / PER
            acc['Xp'][it] += np.sum(wf * Ff * CFp) / PER
            acc['Aneg'][it] += np.sum((wf * Ff ** 2)[Ff < 0]) / PER
            acc['fail_erasures'][it] += np.sum(wf * Ff ** 2 * count[idx]) / PER
        if (it + 1) % max(1, args.batches // 5) == 0:
            print(json.dumps(dict(event='PROGRESS', batch=it + 1, failures=nfail, seconds=round(time.time() - t0))), flush=True)
    res = {x: dict(mean=float(v.mean()), se=float(v.std(ddof=1) / np.sqrt(args.batches)) if args.batches > 1 else None)
           for x, v in acc.items()}
    print(json.dumps(dict(event='PROJECT', seed=args.seed, batches=args.batches, mass=I, failures=nfail, results=res,
                          note='A: mass of configurations with a failing erasure; X, Xp: <e, C F>, <e, C_+ F> over them; '
                               'fail_erasures: F^2 times the number of failing erasures', seconds=round(time.time() - t0))),
          flush=True)


GATE_MINRAD = 2_000_000
GATE_UNIT = 10 ** 7
GATE_HALF = GATE_UNIT // 2


def gate_mark_edges(minimum, spacing):
    """As h1_multilevel_mark_orders.mark_edges."""
    return np.unique([minimum, *[x for x in (100, 300, 1000, 3000, 6000, 10000) if x > minimum],
                      *range(20000, 200001, 10000), *range(200000 + spacing, 1_800_000, spacing),
                      1_800_000]).astype(np.int64)


def gate_cap_types(norm, ends, gt, tick, trial, step, collar):
    """As h1_multilevel_partner_caps.cap_types (no extra caps)."""
    from fractions import Fraction as Q
    from math import ceil, floor
    fine = sorted(set(ends.tolist()) | set(trial['caps']))
    h = Q(norm['step']); n = norm['intervals'] - 38
    last = []
    for c in fine:
        v = min(n - 1, max((int(b // h) - 38 for _, b, cc in trial['shells'] if cc >= c), default=-1))
        for l, r, a, b in collar:
            if l < c <= r:
                assert v == b; v = a - 1
        last.append(v)
    G = 446; R = np.zeros((len(fine), G), np.int64)
    rs = np.zeros_like(R)
    tops = np.array([ceil(c * tick) for c in fine], np.int64)
    for k, c in enumerate(fine):
        ub = max([last[k]] + [last[j] - fine[j - 1] for j in range(k + 1, len(fine))])
        own = gt[np.searchsorted(ends, c), :ub + 1]; ix = np.arange(len(own))
        bot = np.full(G, n, int); top = np.full(G, -1, int)
        np.minimum.at(bot, own, ix); np.maximum.at(top, own, ix)
        for g in np.flatnonzero(top >= 0):
            R[k, g] = ceil((int(top[g]) + 37) * tick); rs[k, g] = floor(int(bot[g]) * tick)
    K = int(np.ceil(R.max() / step)) + 1 - GATE_MINRAD // step
    ls = np.full((len(fine), G, K), -1, int); own = []; radii = []; tag = []
    for k in range(len(fine)):
        for g in np.flatnonzero(R[k]):
            a = max(GATE_MINRAD // step, rs[k, g] // step); b = max(a, ceil(Q(int(R[k, g]), step)))
            for j in range(a, b + 1):
                ls[k, g, j - GATE_MINRAD // step] = len(own); own.append(int(g)); tag.append(k)
                radii.append(min(int(R[k, g]), j * step))
    return np.array(fine), R, rs, tops, ls, np.array(own), np.array(tag), np.array(radii)


def gate_budgets(R, tops, own, tags, radii, used, proofs, step):
    """As h1_multilevel_plateau_screen.budgets, with the 14 channels' nonzero patterns given directly."""
    R = R[:, :445]
    ceiling = max(c[-1] for p in proofs for c in p['corners'])
    by_cost = np.zeros((*R.shape, ceiling // step + 1), np.int32)
    for mat, p in zip(used, proofs):
        other = np.array([np.max(np.where(mat, r, 0), axis=1) for r in R])
        c = np.array(p['corners'], np.int64)
        allc = np.unique(np.vstack([c, c[:, [1, 0, 3, 2, 4]]]), axis=0)
        for i, (z, s_) in enumerate(zip(tops, R)):
            cand = allc[allc[:, 0] >= z]
            for w, t in zip(tops, other):
                idx = np.flatnonzero((s_ + t > GATE_HALF) & (s_ > 0) & (t > 0))
                if not len(idx):
                    continue
                pts = cand[cand[:, 1] >= w]
                cover = (pts[:, 2, None] >= s_[idx]) & (pts[:, 3, None] >= t[idx])
                assert cover.any(axis=0).all()
                best = np.where(cover, pts[:, 4, None], 0).max(axis=0)
                assert np.all(best % step == 0)
                a = best // step
                by_cost[i, idx, a] = np.maximum(by_cost[i, idx, a], t[idx])
    good = own < 445; lower = np.full(len(radii), 2 * GATE_UNIT, np.int64)
    hit = radii[good, None] + by_cost[tags[good], own[good]] > GATE_HALF
    lower[good] = np.where(hit.any(axis=1), hit.argmax(axis=1) * step, 2 * GATE_UNIT)
    return lower


def build_gates(args):
    """Tables for the tail gates, on the stored 38-coordinate frame of the twelve-level certificate."""
    import contextlib
    import io
    from fractions import Fraction as Q
    saved = list(sys.argv)
    sys.argv = sys.argv[:1]
    with contextlib.redirect_stdout(io.StringIO()):
        import h1_two_source_endpoints as TS
        from h1_geometry_scan import fit_geometry, geometry as geom
    sys.argv = saved
    t0 = time.time()
    frame = TS.stored_frame()
    norm = json.loads(Path(args.norm).read_text())
    fibres = json.loads(Path(args.fibres).read_text())
    collar = json.loads(Path(args.collar).read_text())['bands']
    proof_doc = json.loads(Path(args.plateaus).read_text())
    proofs = proof_doc['channels']
    if args.tilt:
        # the tilted-line certificate (h1_multilevel_tail_tilt.py): each corner ends with a common L
        # such that tails up to max(z, S - 2u, L - c u), c = tilt / 2, restore the channel
        assert proof_doc['rate_numerator'] == args.tilt and proof_doc['rate_denominator'] == 2
    with np.load(args.used, allow_pickle=False) as z:
        used = z['used']
    assert used.shape == (14, 445, 445) and len(proofs) == 14
    groups = json.loads(Path(args.groups).read_text())['groups']
    ends = frame['caps']
    n38 = norm['intervals'] - 38
    ix = np.arange(n38)
    sector_group = np.full(len(frame['energies']) + 1, len(groups), int)
    for i, g in enumerate(groups):
        sector_group[g] = i
    gt = np.asarray([sector_group[frame['layout'](c, ix)] for c in ends])
    tick = Q(norm['step']) * geom.RHO * GATE_UNIT
    g, _, _ = fit_geometry(dict(radius='.2798746934'), 38, 131072)
    hcell = g['parameters']['cell_step']
    assert hcell == Q(norm['step'])
    shells = [(sh['lower'], sh['upper'], min(78116, int(sh['cap'] // hcell))) for sh in g['continuous_cap_shells']['outer']]
    trial = dict(caps=list(fibres['caps']), shells=shells)
    fine, R, rs, tops, ls, own, tag, radii = gate_cap_types(norm, ends, gt, tick, trial, args.radial_step, collar)
    edges = gate_mark_edges(1, args.spacing)
    assert max(tops) < edges[-1]
    plateaus = gate_budgets(R, tops, own, tag, radii, used, proofs, 10000)
    Rr = R[tag, own]; z = tops[tag]; upper = edges[1:]
    if args.tilt:
        # as h1_multilevel_tilt_screen: max(z, L - c u, S - 2u) at the upper edge of each mark bin
        tilted = plateaus[:, None] - args.tilt * upper[None, :] // 2
        gates = np.maximum(np.maximum(z[:, None], tilted), Rr[:, None] - 2 * upper).astype(np.int64)
    else:
        gates = np.maximum(np.maximum(z, plateaus)[:, None], Rr[:, None] - 2 * upper).astype(np.int64)
    np.savez_compressed(args.out, fine=fine, ls=ls, gates=gates, edges=edges, R=R, tops=tops, own=own, tag=tag,
                        radii=radii, plateaus=plateaus, tick=float(tick), radial_step=args.radial_step)
    print(json.dumps(dict(event='GATES', tilt=args.tilt, classes=int(len(own)), fine_caps=int(len(fine)), edges=int(len(edges)),
                          plateau_ticks=dict(min=int(plateaus.min()), median=int(np.median(plateaus)), max=int(plateaus.max())),
                          seconds=round(time.time() - t0, 1))), flush=True)


def erased_parts(T, t_ret, M0Y, kind, pa, pb, nsamp, rng, prop1):
    """Inner Monte Carlo over the erased coordinate: (E F, E F_+) at retained roots.

    The erased coordinate is inserted last; for kind 'core' it is a core coordinate and the
    endpoints keep their retained positions pa, pb, for 'a' (or 'b') it is that endpoint.  Its total
    is drawn from prop1 and its largest fragment from the Dickman law, as in the full measure of
    validate(); the weight is rho(tau/zeta)/q(tau)."""
    n_, d = t_ret.shape
    tau = prop1.sample(np.zeros(n_, int), nsamp, rng)                       # (n, nsamp)
    u = rlib.largest(tau, T.zeta, rng)
    wt = rlib.rho(tau / T.zeta) / prop1.density(np.zeros(n_, int), tau)
    X = np.concatenate([np.repeat(t_ret[:, None, :], nsamp, axis=1), tau[:, :, None]], axis=2).reshape(-1, d + 1)
    M0 = np.maximum(np.repeat(M0Y, nsamp), u.ravel())
    if kind == 'core':
        A = np.repeat(pa, nsamp); Bp = np.repeat(pb, nsamp)
    elif kind == 'a':
        A = np.full(n_ * nsamp, d); Bp = np.repeat(pb, nsamp)
    else:
        A = np.repeat(pa, nsamp); Bp = np.full(n_ * nsamp, d)
    F = T.F(X, M0, A, Bp).reshape(n_, nsamp)
    return (wt * F).mean(axis=1), (wt * np.maximum(F, 0)).mean(axis=1), (wt * np.maximum(-F, 0)).mean(axis=1)


def minority_terms(T, t, lf, F, pa, pb, nsamp, rng, prop1, calibrate=False):
    """Per failing configuration X, the two minority-sign pairings of the projection loss:

      m1 = sum_i |p_-(X^_i)| |E_i F_minor(X^_i)| |F(X)| 1[F(X) majority]
      m2 = sum_i |p_-(X^_i)| |E_i F_major(X^_i)| |F(X)| 1[F(X) minority]

    with the majority sign taken to be negative (as for these trials).  Returns m1, m2 and, with
    calibrate, the ratios between the exact erased profile and the inner estimate of E_i F."""
    n_, k = t.shape
    rows = np.arange(n_)
    j = T.cells(t)
    order = -np.sort(-lf, axis=1); top1, top2 = order[:, 0], order[:, 1]
    m1 = np.zeros(n_); m2 = np.zeros(n_); ratios = []
    major = F < 0
    for e in range(k):
        keep = np.arange(k) != e
        tY = t[:, keep]; jY = j[:, keep]
        M0Y = np.where(lf[:, e] >= top1, top2, top1)
        shift = lambda q: q - (q > e)
        is_a, is_b = pa == e, pb == e
        for kind, sel in (('core', ~(is_a | is_b)), ('a', is_a), ('b', is_b)):
            ix = np.flatnonzero(sel)
            if not len(ix):
                continue
            ppa = shift(pa[ix]) if kind != 'a' else None
            ppb = shift(pb[ix]) if kind != 'b' else None
            V, price = T.V(kind, jY[ix], M0Y[ix], ppa, ppb)
            neg = price < 0
            if not neg.any() and not calibrate:
                continue
            use = ix if calibrate else ix[neg]
            sub = np.isin(ix, use)
            EF, EFp, EFm = erased_parts(T, tY[use], M0Y[use], kind,
                                        None if ppa is None else ppa[sub], None if ppb is None else ppb[sub], nsamp, rng, prop1)
            if calibrate:
                good = np.abs(V[sub]) > 0
                ratios.extend((V[sub][good] / np.where(EF[good] != 0, EF[good], np.nan)).tolist())
            pneg = np.maximum(-price[sub], 0)
            # majority negative: F_minor = F_+, F_major = F_- (as magnitudes)
            m1[use] += pneg * EFp * np.abs(F[use]) * major[use]
            m2[use] += pneg * EFm * np.abs(F[use]) * (~major[use])
    return m1, m2, ratios


def gate_projection(args):
    """Delete every sampled full configuration in which some erasure fails its class gate."""
    T = Trial(args.trial)
    if args.negate:
        T.negate()
    assert T.group_table is not None
    with np.load(args.gates, allow_pickle=False) as z:
        G = {key: z[key] for key in z.files}
    fine, ls, gates, edges, Rclass = G['fine'], G['ls'], G['gates'], G['edges'], G['R']
    tick, radial_step = float(G['tick']), int(G['radial_step'])
    mrad = GATE_MINRAD // radial_step
    ticks = T.m['rho_ticks'] * GATE_UNIT                         # ticks per unit of normalised total
    lower_edges = edges[:-1].astype(float)
    rng = np.random.default_rng(args.seed)
    k, S, zeta, h = T.k, T.S, T.zeta, T.h
    prop = rlib.Proposal(S, T.gfun, np.linspace(0, 120, 25), zeta)
    use = np.flatnonzero((prop.mean * k > args.low) & (prop.mean * k < args.high))

    def logq(t):
        Lg = np.array([np.log(prop.density(np.full(len(t), b), t)).sum(axis=1) for b in use]) - np.log(len(use))
        mx = Lg.max(axis=0)
        return mx + np.log(np.exp(Lg - mx).sum(axis=0))

    keys = ('I', 'A', 'A_unclassified', 'X', 'Xp', 'Aneg', 'failing_erasures', 'Ce', 'Ce_pos', 'Fpos_deleted', 'minor1', 'minor2',
            'Xp_failing_roots', 'Xp_passing_roots', 'Xp_w2lt10', 'Xp_w2lt10_w1_44_50', 'Xp_w2ge10')
    # Xp_w2lt10: the part of Xp from deleted configurations whose second largest fragment (over all
    # coordinates) is below 0.10, i.e. the rank-1 configurations; _w1_44_50 restricts their largest to [0.44, 0.50)
    # Xp_failing_roots: the part of <e, C_+ F> carried by erasures whose roots fail. Every insertion into a
    # failing root is deleted, so this part equals rho * sum over failing roots of p_+ V(root)^2, a
    # root-level integral; Xp_passing_roots is the rest
    # 'A_unclassified' counts configurations with an erasure outside every verified class or above
    # its class radius bound; they are deleted
    prop1 = rlib.Proposal(S, T.gfun, [0.0], zeta)
    calibration = []
    nb_all = len(edges) - 1
    upper_edges = edges[1:].astype(float)
    tops_ci = G['tops'].astype(float)
    Amin_ci = np.full(len(tops_ci), np.inf)
    np.minimum.at(Amin_ci, G['tag'], G['plateaus'].astype(float))
    def relaxed_threshold(cidx):
        # a root in cap index cidx fails the relaxed gate at bin b only if its tail exceeds
        # max(z, least plateau of the cap index, lower edge / 2); outside the tables: always
        inside_ = cidx < len(tops_ci)
        cc = np.minimum(cidx, len(tops_ci) - 1)
        thr = np.maximum(tops_ci[cc], Amin_ci[cc])
        return np.where(inside_, thr, -np.inf)
    # deleted mass by the first failing erasure's largest and smallest failing mark bin, the number of
    # root marks and of root coordinates at or above the largest failing mark, and the gap S - Y
    gap_bins = np.linspace(0, .3, 61)
    if args.window > 0:
        # per cap index and group: least class radius bound, least gate level over its radius bins
        nci, ngr = Rclass.shape
        Lmin_cg = np.full((nci, ngr), np.inf)
        valid = ls >= 0
        lvl = np.where(valid, G['plateaus'][np.maximum(ls, 0)], np.inf)
        Lmin_cg = lvl.min(axis=2)
        Lmin_cg = np.where(np.isinf(Lmin_cg), -np.inf, Lmin_cg)       # no class: always deleted
        Smin_cg = np.where(Rclass > 0, Rclass.astype(float), -np.inf)
        wcells = int(np.floor(args.window / h))
    prof = dict(bmax=np.zeros(nb_all), bmin=np.zeros(nb_all), rank=np.zeros(40), sites=np.zeros(40),
                gap=np.zeros(len(gap_bins)), noclass=0.0, relaxed_each=0.0, relaxed_free=0.0,
                deleted_not_each=0.0, deleted_not_free=0.0, Xp_relaxed_free=0.0, F_relaxed_free_pos=0.0,
                window=0.0, window_case0=0.0, window_big=0.0, window_big_sum=0.0, deleted_not_window=0.0, Xp_window=0.0,
                min_erasure_fails=0.0, min2_erasure_fails=0.0, deleted_count_hist=np.zeros(40))
    details = []
    acc = {x: np.zeros(args.batches) for x in keys}
    squares = np.zeros(args.batches)
    nfail = 0
    t0 = time.time()
    for it in range(args.batches):
        n_ = PER
        bi = use[rng.integers(0, len(use), n_)]
        t = prop.sample(bi, k, rng)
        lw = np.log(rlib.rho(t / zeta)).sum(axis=1) - logq(t)
        frag, dust = rlib.fragments(t, np.full(t.shape, zeta), UMIN, rng)
        lf = frag[:, :, 0]
        M0 = lf.max(axis=1)
        pa, pb = positions(rng, n_, k, 2)
        F = T.F(t, M0, pa, pb)
        w = np.exp(lw)
        acc['I'][it] = np.sum(w * F * F) / n_
        squares[it] = np.sum((w * F * F) ** 2)
        live = np.flatnonzero(F != 0)
        failed = np.zeros(n_, bool); unclassified = np.zeros(n_, bool); count = np.zeros(n_)
        failmat = np.zeros((n_, k), bool)
        if len(live):
            fl = frag[live] * ticks
            # mass of every coordinate's marks in each mark bin, and its unsampled dust
            nb = len(lower_edges)
            binix = np.clip(np.searchsorted(edges, fl, side='right') - 1, 0, nb - 1)
            hist = np.zeros((len(live), k, nb))
            np.add.at(hist, (np.arange(len(live))[:, None, None], np.arange(k)[None, :, None], binix), np.where(fl > 0, fl, 0.0))
            hcount = np.zeros((len(live), k, nb)) if args.profile else None
            if args.profile:
                np.add.at(hcount, (np.arange(len(live))[:, None, None], np.arange(k)[None, :, None], binix), (fl >= edges[0]) * 1.0)
            rec = np.full((len(live), 5), -1.0)
            relaxed_each = np.zeros(len(live), bool)
            big_union = np.zeros(len(live), bool); big_count = np.zeros(len(live))
            # the erasures of the coordinates with the smallest and second smallest totals
            ordt = np.argsort(t[live], axis=1)
            emin, emin2 = ordt[:, 0], ordt[:, 1]
            fail_min = np.zeros(len(live), bool); fail_min2 = np.zeros(len(live), bool)
            det = np.full((len(live), 9), np.nan)
            # marks below the sampling floor: break each coordinate's remaining mass by uniform
            # stick-breaking down to one tick, as the screen generates all of its marks
            rem = np.maximum(t[live] * ticks - fl.sum(axis=2), 0.0)
            ri_, ci_ = np.meshgrid(np.arange(len(live)), np.arange(k), indexing='ij')
            while (rem > edges[0]).any():
                v = rng.random(rem.shape) * rem
                rem -= v
                b = np.clip(np.searchsorted(edges, v, side='right') - 1, 0, nb - 1)
                np.add.at(hist, (ri_, ci_, b), np.where(v >= edges[0], v, 0.0))
                if args.profile:
                    np.add.at(hcount, (ri_, ci_, b), (v >= edges[0]) * 1.0)
            hist_all = hist.sum(axis=1)
            hcount_all = hcount.sum(axis=1) if args.profile else None
            j = T.cells(t[live]); r = j.sum(axis=1)
            lfl = lf[live]
            order = -np.sort(-lfl, axis=1); top1, top2 = order[:, 0], order[:, 1]
            s_ticks = t[live].sum(axis=1) * ticks
            for e in range(k):
                Y = s_ticks - t[live, e] * ticks
                M0Y = np.where(lfl[:, e] >= top1, top2, top1)
                lay, okl = T.layer(M0Y)
                rY = r - j[:, e]
                okr = (rY >= 0) & (rY < T.group_table.shape[1])
                grp = np.where(okl & okr, T.group_table[np.where(okl, lay, 0), np.clip(rY, 0, T.group_table.shape[1] - 1)], -1)
                tested = grp >= 0
                ci = np.searchsorted(fine, M0Y / h)
                rc = np.maximum(mrad, np.ceil(Y / radial_step).astype(int)) - mrad
                inside = tested & (ci < ls.shape[0]) & (rc < ls.shape[2])
                key = np.full(len(live), -1)
                sel = np.flatnonzero(inside)
                key[sel] = ls[ci[sel], grp[sel], rc[sel]]
                # a root above its class's verified radius bound has no verified gate: delete it
                over = np.zeros(len(live), bool)
                over[sel] = Y[sel] > Rclass[ci[sel], grp[sel]]
                noclass = tested & ((key < 0) | over)
                hits = hist_all - hist[:, e, :]
                tails = np.cumsum(hits[:, ::-1], axis=1)[:, ::-1]
                gk = gates[np.maximum(key, 0)]
                bad = (key >= 0) & np.any((tails > lower_edges * .5) & (tails > gk), axis=1)
                if args.profile:
                    # relaxed gate of this erasure: plateau -> least plateau of its cap index, S -> Y
                    thr = relaxed_threshold(ci)[:, None]
                    rel = np.any((tails > thr) & (tails > lower_edges * .5) & (Y[:, None] - tails < 2 * upper_edges), axis=1)
                    relaxed_each |= (tested & rel) | noclass
                    fail_min |= (bad | noclass) & (emin == e)
                    fail_min2 |= (bad | noclass) & ((emin == e) | (emin2 == e))
                    if args.window > 0:
                        isbig = t[live][:, e] > args.window
                        big_union |= (bad | noclass) & isbig
                        big_count += (bad | noclass) & isbig
                    fm = (key >= 0)[:, None] & (tails > lower_edges * .5) & (tails > gk)
                    new = np.flatnonzero(fm.any(axis=1) & (rec[:, 0] < 0) & ~noclass)
                    if len(new):
                        f_ = fm[new]
                        bmax = nb - 1 - np.argmax(f_[:, ::-1], axis=1)
                        bmin = np.argmax(f_, axis=1)
                        ch = hcount_all[new] - hcount[new, e, :]
                        nrank = np.cumsum(ch[:, ::-1], axis=1)[:, ::-1][np.arange(len(new)), bmax]
                        ct = np.cumsum(hist[new][:, :, ::-1], axis=2)[:, :, ::-1][np.arange(len(new)), :, bmax]
                        ct[:, e] = 0
                        gap = (Rclass[ci[new], grp[new]] - Y[new]) / ticks
                        rec[new] = np.c_[bmax, bmin, nrank, (ct > 0).sum(axis=1), gap]
                        kk = key[new]
                        Tu = tails[new, bmax]
                        det[new] = np.c_[lower_edges[bmax], Tu, gk[new, bmax], G['tops'][G['tag'][kk]],
                                         G['plateaus'][kk], G['R'][G['tag'][kk], G['own'][kk]], Y[new],
                                         s_ticks[new], t[live][new, e] * ticks] / ticks
                    nc = np.flatnonzero(noclass & (rec[:, 0] < 0))
                    rec[nc, 0] = -2
                bad |= noclass
                failed[live] |= bad
                failmat[live, e] = bad
                unclassified[live] |= noclass
                count[live] += bad
        relaxed_free_mask = np.zeros(n_, bool)
        window_mask = np.zeros(n_, bool)
        if args.profile and args.window > 0 and len(live):
            # case 0: the failing erasure has total <= window, so it carries no mark of a bin above the
            # window: its root has the configuration's tails, cap index and layer, its radial cell is r - off
            # and its total at most Y - off h, for some off in [0, wcells]; apply that root's exact gate
            rfull = r
            M0f = lfl.max(axis=1)
            cif = np.searchsorted(fine, M0f / h)
            layf, oklf = T.layer(M0f)
            ok_ci = cif < nci
            cic = np.minimum(cif, nci - 1); lyc = np.where(oklf, layf, 0)
            tails_full = np.cumsum(hist_all[:, ::-1], axis=1)[:, ::-1]
            case0 = np.zeros(len(live), bool)
            for off in range(wcells + 1):
                rY = rfull - off
                okr = (rY >= 0) & (rY < T.group_table.shape[1])
                g_ = np.where(okr & oklf, T.group_table[lyc, np.clip(rY, 0, T.group_table.shape[1] - 1)], -1)
                tst = (g_ >= 0) & ok_ci
                Ye = s_ticks - off * h * ticks
                rc_ = np.maximum(mrad, np.ceil(Ye / radial_step).astype(int)) - mrad
                ins = tst & (rc_ < ls.shape[2])
                key_ = np.full(len(live), -1)
                sl = np.flatnonzero(ins)
                key_[sl] = ls[cic[sl], g_[sl], rc_[sl]]
                over_ = np.zeros(len(live), bool)
                over_[sl] = Ye[sl] > Rclass[cic[sl], g_[sl]]
                gk_ = gates[np.maximum(key_, 0)]
                fo = (key_ >= 0) & np.any((tails_full > gk_) & (tails_full > lower_edges * .5), axis=1)
                case0 |= tst & (fo | (key_ < 0) | over_)
            case0 |= ~ok_ci & oklf
            wm = case0 | big_union
            window_mask[live] = wm
            mF = np.exp(lw) * F * F
            c0 = np.zeros(n_, bool); c0[live] = case0
            bu = np.zeros(n_, bool); bu[live] = big_union
            bc = np.zeros(n_); bc[live] = big_count
            prof['window'] += float(mF[window_mask].sum())
            prof['window_case0'] += float(mF[c0].sum())
            prof['window_big'] += float(mF[bu].sum())
            prof['window_big_sum'] += float((mF * bc).sum())
            prof['deleted_not_window'] += float(mF[failed & ~window_mask].sum())
            onlyw = np.flatnonzero(window_mask & ~failed)
            if len(onlyw):
                CFw = cap_operator(T, t[onlyw], None, None, None, None, pa[onlyw], pb[onlyw], lf=lf[onlyw])[2]
                prof['Xp_window'] += float((np.exp(lw[onlyw]) * F[onlyw] * CFw).sum())
        if args.profile and len(live):
            # erasure-free superset: case 0, the failing erasure carries no mark of the bin: the root's
            # marks at or above the bin are all of the configuration's, and its mass below the bin is
            # at least the configuration's minus the largest single coordinate's; case s, the erasure
            # is a coordinate s carrying such marks, taken exactly
            tails_full = np.cumsum(hist_all[:, ::-1], axis=1)[:, ::-1]
            coord_tail = np.cumsum(hist[:, :, ::-1], axis=2)[:, :, ::-1]
            rest = t[live][:, :, None] * ticks - coord_tail
            Rtot = rest.sum(axis=1)
            M0f = lfl.max(axis=1)
            thr0 = relaxed_threshold(np.searchsorted(fine, M0f / h))[:, None]
            free = np.any((tails_full > thr0) & (tails_full > lower_edges * .5)
                          & (Rtot - rest.max(axis=1) < 2 * upper_edges), axis=1)
            order_ = -np.sort(-lfl, axis=1)
            for s_ in range(k):
                carries = coord_tail[:, s_, :] > 0
                if not carries.any():
                    continue
                Ws = tails_full - coord_tail[:, s_, :]
                M0s = np.where(lfl[:, s_] >= order_[:, 0], order_[:, 1], order_[:, 0])
                thr_s = relaxed_threshold(np.searchsorted(fine, M0s / h))[:, None]
                free |= np.any(carries & (Ws > thr_s) & (Ws > lower_edges * .5)
                               & (Rtot - rest[:, s_, :] < 2 * upper_edges), axis=1)
            del coord_tail, rest
            rel_e = np.zeros(n_, bool); rel_e[live] = relaxed_each
            relaxed_free_mask[live] = free
            mF = np.exp(lw) * F * F
            prof['relaxed_each'] += float(mF[rel_e].sum())
            prof['relaxed_free'] += float(mF[relaxed_free_mask].sum())
            prof['deleted_not_each'] += float(mF[failed & ~rel_e].sum())
            prof['deleted_not_free'] += float(mF[failed & ~relaxed_free_mask].sum())
            prof['F_relaxed_free_pos'] += float(mF[relaxed_free_mask & (F > 0)].sum())
            onlyf = np.flatnonzero(relaxed_free_mask & ~failed)
            if len(onlyf):
                CFx = cap_operator(T, t[onlyf], None, None, None, None, pa[onlyf], pb[onlyf], lf=lf[onlyf])[2]
                prof['Xp_relaxed_free'] += float((np.exp(lw[onlyf]) * F[onlyf] * CFx).sum())
        idx = np.flatnonzero(failed)
        nfail += len(idx)
        if len(idx):
            CF, CS, CFp, CFm, CSp, CFpf = cap_operator(T, t[idx], None, None, None, None, pa[idx], pb[idx], lf=lf[idx],
                                                       fail=failmat[idx])
            Ff, wf = F[idx], w[idx]
            acc['Xp_failing_roots'][it] = np.sum(wf * Ff * CFpf) / n_
            acc['Xp_passing_roots'][it] = np.sum(wf * Ff * (CFp - CFpf)) / n_
            fr_ = frag[idx].reshape(len(idx), -1)
            top2 = -np.sort(-fr_, axis=1)[:, :2]
            r1_ = top2[:, 1] < 0.10
            acc['Xp_w2lt10'][it] = np.sum((wf * Ff * CFp)[r1_]) / n_
            acc['Xp_w2ge10'][it] = np.sum((wf * Ff * CFp)[~r1_]) / n_
            acc['Xp_w2lt10_w1_44_50'][it] = np.sum((wf * Ff * CFp)[r1_ & (top2[:, 0] >= 0.44) & (top2[:, 0] < 0.50)]) / n_
            acc['A'][it] = np.sum(wf * Ff ** 2) / n_
            acc['A_unclassified'][it] = np.sum((wf * Ff ** 2)[unclassified[idx]]) / n_
            acc['X'][it] = np.sum(wf * Ff * CF) / n_
            acc['Xp'][it] = np.sum(wf * Ff * CFp) / n_
            acc['Aneg'][it] = np.sum((wf * Ff ** 2)[Ff < 0]) / n_
            acc['Fpos_deleted'][it] = np.sum((wf * Ff ** 2)[Ff > 0]) / n_
            acc['failing_erasures'][it] = np.sum(wf * Ff ** 2 * count[idx]) / n_
            rows = np.arange(len(idx))
            core_total = t[idx].sum(axis=1) - t[idx][rows, pa[idx]] - t[idx][rows, pb[idx]]
            qc = T.rho * core_total
            phi = ((T.rho * T.S - qc) / (0.5 - qc - 1e-4)) ** 2
            acc['Ce'][it] = np.sum(wf * Ff ** 2 * phi) / n_
            acc['Ce_pos'][it] = np.sum((wf * Ff ** 2 * phi)[Ff > 0]) / n_
            if args.profile:
                fm_ = np.zeros(n_, bool); fm_[live] = fail_min
                fm2_ = np.zeros(n_, bool); fm2_[live] = fail_min2
                prof['min_erasure_fails'] += float(np.sum((wf * Ff ** 2)[fm_[idx]]))
                prof['min2_erasure_fails'] += float(np.sum((wf * Ff ** 2)[fm2_[idx]]))
                np.add.at(prof['deleted_count_hist'], np.clip(count[idx].astype(int), 0, 39), wf * Ff ** 2)
                prof['Xp_relaxed_free'] += float(np.sum((wf * Ff * CFp)[relaxed_free_mask[idx]]))
                prof['Xp_window'] += float(np.sum((wf * Ff * CFp)[window_mask[idx]]))
                pos = np.full(n_, -1); pos[live] = np.arange(len(live))
                R_ = rec[pos[idx]]; m_ = wf * Ff ** 2
                ok = R_[:, 0] >= 0
                prof['noclass'] += float(m_[R_[:, 0] == -2].sum())
                np.add.at(prof['bmax'], R_[ok, 0].astype(int), m_[ok])
                np.add.at(prof['bmin'], R_[ok, 1].astype(int), m_[ok])
                np.add.at(prof['rank'], np.clip(R_[ok, 2].astype(int), 0, 39), m_[ok])
                np.add.at(prof['sites'], np.clip(R_[ok, 3].astype(int), 0, 39), m_[ok])
                np.add.at(prof['gap'], np.clip(np.searchsorted(gap_bins, R_[ok, 4]), 0, len(gap_bins) - 1), m_[ok])
                D_ = det[pos[idx]]
                for q in np.flatnonzero(ok):
                    details.append([float(m_[q])] + [float(x) for x in D_[q]] + [float(R_[q, 2]), float(R_[q, 3])])
            if args.minority:
                m1, m2, ratios = minority_terms(T, t[idx], lf[idx], Ff, pa[idx], pb[idx], args.inner, rng, prop1,
                                                calibrate=(len(calibration) < 2000))
                calibration.extend(ratios)
                acc['minor1'][it] = np.sum(wf * m1) / n_
                acc['minor2'][it] = np.sum(wf * m2) / n_
        if (it + 1) % max(1, args.batches // 5) == 0:
            print(json.dumps(dict(event='PROGRESS', batch=it + 1, failures=nfail, seconds=round(time.time() - t0))), flush=True)
    I = acc['I'].mean()
    res = {x: dict(mean=float(acc[x].mean() / I), se=float(acc[x].std(ddof=1) / np.sqrt(args.batches) / I))
           for x in keys if x != 'I'}
    ess = float((acc['I'].sum() * PER) ** 2 / squares.sum())
    cal = np.array([c for c in calibration if np.isfinite(c)])
    calib = dict(count=int(len(cal)), median=float(np.median(cal)) if len(cal) else None,
                 quartiles=[float(np.percentile(cal, 25)), float(np.percentile(cal, 75))] if len(cal) else None)
    if args.minority and len(cal):
        # the inner estimates are in the measure rho(tau/zeta) d tau; scale them to the units of V,
        # and form the loss 2 rho (m1 + m2) of the projection's minority-sign pairings
        c = calib['median']
        res['minority_loss'] = dict(mean=float(2 * T.rho * c * (acc['minor1'].mean() + acc['minor2'].mean()) / I),
                                    se=float(2 * T.rho * c * (acc['minor1'] + acc['minor2']).std(ddof=1) / np.sqrt(args.batches) / I))
    if args.profile:
        norm_ = I * args.batches * PER
        res['profile'] = dict(mark_lower_edges=[float(x) for x in lower_edges / ticks], gap_bins=[float(x) for x in gap_bins],
                              **{x: (v / norm_).tolist() if isinstance(v, np.ndarray) else v / norm_ for x, v in prof.items()})
        # one row per deleted configuration: weight (units of I), then for its first failing erasure at the
        # largest failing mark edge: edge u, tail T(u), gate, cap top z, plateau A, class radius S, root total Y,
        # full total, erased total; then rank and sites (lengths in units of the normalised total)
        res['profile']['columns'] = ['weight', 'u', 'T', 'gate', 'z', 'A', 'S', 'Y', 'full', 'erased', 'rank', 'sites']
        res['profile']['failures'] = [[d[0] / norm_] + d[1:] for d in details]
    print(json.dumps(dict(event='GATE', seed=args.seed, batches=args.batches, samples=args.batches * PER, I=float(I),
                          minority=args.minority, inner_samples=args.inner, calibration_V_over_inner=calib,
                          I_relerr=float(acc['I'].std(ddof=1) / np.sqrt(args.batches) / I), effective_sample_size=ess,
                          failures=nfail, results=res, seconds=round(time.time() - t0))), flush=True)


def gate_failures(T, G, t, frag, rng, virtual=False):
    """Gate test of every erasure (as gate_projection): frag (n, k, L) are all sampled marks of each
    coordinate in descending order (zeros padded); marks below the sampling floor are stick-broken.
    With virtual=True it also returns the gate failure of the virtual root (the full configuration
    itself: its own radial cell, total, largest fragment and tails, no erasure; Phi_0 at all ranks,
    on the same stick-broken marks) and the number of failing erasures."""
    fine, ls, gates, edges, Rclass = G['fine'], G['ls'], G['gates'], G['edges'], G['R']
    radial_step = int(G['radial_step'])
    mrad = GATE_MINRAD // radial_step
    ticks = T.m['rho_ticks'] * GATE_UNIT
    lower_edges = edges[:-1].astype(float)
    n_, k = t.shape
    nb = len(lower_edges)
    fl = frag * ticks
    lf = frag[:, :, 0]
    binix = np.clip(np.searchsorted(edges, fl, side='right') - 1, 0, nb - 1)
    hist = np.zeros((n_, k, nb))
    np.add.at(hist, (np.arange(n_)[:, None, None], np.arange(k)[None, :, None], binix), np.where(fl > 0, fl, 0.0))
    rem = np.maximum(t * ticks - fl.sum(axis=2), 0.0)
    ri_, ci_ = np.meshgrid(np.arange(n_), np.arange(k), indexing='ij')
    while (rem > edges[0]).any():
        v = rng.random(rem.shape) * rem
        rem -= v
        b = np.clip(np.searchsorted(edges, v, side='right') - 1, 0, nb - 1)
        np.add.at(hist, (ri_, ci_, b), np.where(v >= edges[0], v, 0.0))
    hist_all = hist.sum(axis=1)
    j = T.cells(t); r = j.sum(axis=1)
    order = -np.sort(-lf, axis=1); top1, top2 = order[:, 0], order[:, 1]
    s_ticks = t.sum(axis=1) * ticks
    failed = np.zeros(n_, bool); unclassified = np.zeros(n_, bool); untested = np.zeros(n_, int)
    vfail = np.zeros(n_, bool); nfail = np.zeros(n_, int)
    hibin = np.full(n_, -1)                              # highest gate bin at which some erasure fails
    for e in (range(-1, k) if virtual else range(k)):
        if e < 0:                                         # the virtual root: no erasure
            Y = s_ticks.copy(); M0Y = top1; rY = r.copy()
        else:
            Y = s_ticks - t[:, e] * ticks
            M0Y = np.where(lf[:, e] >= top1, top2, top1)
            rY = r - j[:, e]
        lay, okl = T.layer(M0Y)
        okr = (rY >= 0) & (rY < T.group_table.shape[1])
        grp = np.where(okl & okr, T.group_table[np.where(okl, lay, 0), np.clip(rY, 0, T.group_table.shape[1] - 1)], -1)
        tested = grp >= 0
        if e >= 0:
            untested += ~tested
        ci = np.searchsorted(fine, M0Y / T.h)
        rc = np.maximum(mrad, np.ceil(Y / radial_step).astype(int)) - mrad
        inside = tested & (ci < ls.shape[0]) & (rc < ls.shape[2])
        key = np.full(n_, -1)
        sel = np.flatnonzero(inside)
        key[sel] = ls[ci[sel], grp[sel], rc[sel]]
        over = np.zeros(n_, bool)
        over[sel] = Y[sel] > Rclass[ci[sel], grp[sel]]
        noclass = tested & ((key < 0) | over)
        hits = hist_all - hist[:, e, :] if e >= 0 else hist_all
        tails = np.cumsum(hits[:, ::-1], axis=1)[:, ::-1]
        gk = gates[np.maximum(key, 0)]
        cond = (tails > lower_edges * .5) & (tails > gk)
        bad = (key >= 0) & np.any(cond, axis=1)
        if e < 0:
            vfail = bad | noclass
            continue
        failed |= bad | noclass
        nfail += bad | noclass
        top_b = np.where(cond.any(axis=1), nb - 1 - np.argmax(cond[:, ::-1], axis=1), -1)
        hibin = np.maximum(hibin, np.where(noclass, nb, np.where(bad, top_b, -1)))
        unclassified |= noclass
    if virtual:
        return failed, unclassified, untested, vfail, nfail, hibin
    return failed, unclassified, untested


def pair_marks(args):
    """Configurations with two marks at least a, by the second factorial moment (Mecke) formula.

    Each coordinate is an independent Poisson process with intensity du/u on (0, zeta]. The expected
    number of unordered pairs of marks >= a is, for any weight f of the configuration,
      E sum_{pairs} f = (1/2) sum_{i,j} int_a int_a E f(config + x at i + y at j) dx/x dy/y,
    with i = j allowed. If 3a exceeds the largest total in the support, no configuration has three
    such marks and the pair count is the indicator N_a of the set E_a. Estimates (floating, sampled):
    int F^2 N_a, <F N_a, C F> and its positive-price part, int F^2 N_a Phi, all in units of I, and the
    share of that mass whose configurations the tail gates delete."""
    T = Trial(args.trial)
    rng = np.random.default_rng(args.seed)
    k, S, zeta, h = T.k, T.S, T.zeta, T.h
    total_cap = T.n * h
    a = args.a
    top = min(zeta, total_cap)
    assert top > a
    Lw = np.log(top / a)
    G = None
    if args.gates:
        with np.load(args.gates, allow_pickle=False) as z:
            G = {key: z[key] for key in z.files}
    # normalisation: importance sampling of full configurations, as in gate
    prop = rlib.Proposal(S, T.gfun, np.linspace(0, 120, 25), zeta)
    use = np.flatnonzero((prop.mean * k > args.low) & (prop.mean * k < args.high))
    rprop = rlib.Proposal(S, T.gfun, np.geomspace(args.beta_low, args.beta_high, 32), zeta)

    def logq(P, idx, t):
        Lg = np.array([np.log(P.density(np.full(len(t), b), t)).sum(axis=1) for b in idx]) - np.log(len(idx))
        mx = Lg.max(axis=0)
        return mx + np.log(np.exp(Lg - mx).sum(axis=0))

    Is = []
    for it in range(args.norm_batches):
        bi = use[rng.integers(0, len(use), PER)]
        t = prop.sample(bi, k, rng)
        lw = np.log(rlib.rho(t / zeta)).sum(axis=1) - logq(prop, use, t)
        M0 = rlib.largest(t, zeta, rng).max(axis=1)
        pa, pb = positions(rng, PER, k, 2)
        F = T.F(t, M0, pa, pb)
        Is.append(np.sum(np.exp(lw) * F * F) / PER)
    I = float(np.mean(Is))
    keys = ('Q1', 'Q1_same_site', 'X', 'Xp', 'Ce', 'Q1_deleted', 'Q1_unclassified', 'Q1_untested', 'Q1_pos', 'Xp_deleted',
            'Xp_phi2', 'Q1_phi2', 'Xp_phi2_same_site', 'Xp_top2_row', 'Xp_phi2_row', 'Q1_top2_row',
            'Q1_top2_row_same', 'Q1_top2_row_corecore', 'Q1_top2_row_end',
            'Xp_phi2_carry0', 'Xp_phi2_carry1', 'Xp_phi2_carry2',
            'Xp_D_top2', 'Q1_D_top2', 'Xp_V_top2', 'Q1_V_top2', 'Xp_R_top2', 'Q1_R_top2', 'Xp_VnotD_top2',
            'Xp_phi2_notV_top2', 'Xp_R_top2_fail1', 'Xp_R_top2_fail2_4', 'Xp_R_top2_fail5up',
            'Xp_R_top2_lowbin', 'Xp_D_top2_lowbin')
    # *_lowbin: every failing erasure fails only at gate bins whose lower edge is below a
    # *_top2: the inserted pair is the configuration's top two marks, so each configuration with two
    # marks >= a is counted once. D: some erasure fails (the projection's deleted set); V: the virtual
    # root fails (Phi_0 at all ranks, same stick-broken marks); R = D minus V, split by its number of
    # failing erasures; VnotD should be empty; phi2_notV: the rank-2 formula outside V.
    counts = dict(D=0, V=0, R=0, VnotD=0, phi2_notV=0, R_lowbin=0)
    # Xp_phi2_carryN: the part of Xp_phi2 from C_+ erasures whose coordinate carries N of the two top marks
    # Xp_phi2: <F Phi2, C_+ F> with Phi2 the rank-2 failure of the virtual root (the configuration's own
    # radial cell and total, its two inserted marks as the top two, every other mark below the smaller),
    # the quantity of h1_root_face_moments.py rank2; needs --gates
    if G is not None:
        fineG, lsG, gatesG, edgesG, RclassG = G['fine'], G['ls'], G['gates'], G['edges'], G['R']
        rstepG = int(G['radial_step']); mradG = GATE_MINRAD // rstepG
        ticksG = T.m['rho_ticks'] * GATE_UNIT
    acc = {x: np.zeros(args.batches) for x in keys}
    ridx = np.arange(len(rprop.betas))
    t0 = time.time()
    for it in range(args.batches):
        n_ = PER
        bi = ridx[rng.integers(0, len(ridx), n_)]
        rest = rprop.sample(bi, k, rng)
        lw = np.log(rlib.rho(rest / zeta)).sum(axis=1) - logq(rprop, ridx, rest)
        i_ = rng.integers(0, k, n_); j_ = rng.integers(0, k, n_)
        x = a * np.exp(Lw * rng.random(n_)); y = a * np.exp(Lw * rng.random(n_))
        rows = np.arange(n_)
        t = rest.copy()
        t[rows, i_] += x
        t[rows, j_] += y
        w = np.exp(lw) * (k * k / 2.0) * Lw * Lw
        ok = t.sum(axis=1) <= total_cap
        live = np.flatnonzero(ok)
        if not len(live):
            continue
        frag_rest, dust = rlib.fragments(rest[live], np.full(rest[live].shape, zeta), UMIN, rng)
        lf_rest = frag_rest[:, :, 0]
        pa, pb = positions(rng, len(live), k, 2)
        il, jl, xl, yl = i_[live], j_[live], x[live], y[live]
        lr = np.arange(len(live))
        lf = lf_rest.copy()
        lf[lr, il] = np.maximum(lf[lr, il], xl)
        lf[lr, jl] = np.maximum(lf[lr, jl], yl)
        M0 = lf.max(axis=1)
        tl = t[live]
        F = T.F(tl, M0, pa, pb)
        wl = w[live]
        nz = np.flatnonzero(F != 0)
        if not len(nz):
            continue
        Fz, wz = F[nz], wl[nz]
        CF, CS, CFp, CFm, CSp = cap_operator(T, tl[nz], None, None, None, None, pa[nz], pb[nz], lf=lf[nz])
        acc['Q1'][it] = np.sum(wz * Fz ** 2) / n_
        acc['Q1_same_site'][it] = np.sum((wz * Fz ** 2)[il[nz] == jl[nz]]) / n_
        acc['Q1_pos'][it] = np.sum((wz * Fz ** 2)[Fz > 0]) / n_
        acc['X'][it] = np.sum(wz * Fz * CF) / n_
        acc['Xp'][it] = np.sum(wz * Fz * CFp) / n_
        core_total = tl[nz].sum(axis=1) - tl[nz][np.arange(len(nz)), pa[nz]] - tl[nz][np.arange(len(nz)), pb[nz]]
        qc = T.rho * core_total
        phi = ((T.rho * T.S - qc) / (0.5 - qc - 1e-4)) ** 2
        acc['Ce'][it] = np.sum(wz * Fz ** 2 * phi) / n_
        if G is not None:
            tz = tl[nz]
            wa_, wb_ = np.maximum(xl[nz], yl[nz]), np.minimum(xl[nz], yl[nz])
            restmax = frag_rest[nz][:, :, 0].max(axis=1)
            top2 = restmax < wb_
            rz = T.cells(tz).sum(axis=1)
            Yz = tz.sum(axis=1) * ticksG
            ci_ = np.searchsorted(fineG, wa_ / h)
            lay_, okl_ = T.layer(wa_)
            okc = okl_ & (ci_ < lsG.shape[0])
            grp_ = np.where(okc, T.group_table[np.where(okl_, lay_, 0), np.clip(rz, 0, T.group_table.shape[1] - 1)], -1)
            tested_ = grp_ >= 0
            rc_ = np.maximum(mradG, np.ceil(Yz / rstepG).astype(int)) - mradG
            ins_ = tested_ & (rc_ < lsG.shape[2])
            key_ = np.full(len(nz), -1)
            sl = np.flatnonzero(ins_)
            key_[sl] = lsG[np.minimum(ci_[sl], lsG.shape[0] - 1), grp_[sl], rc_[sl]]
            over_ = np.zeros(len(nz), bool)
            over_[sl] = Yz[sl] > RclassG[np.minimum(ci_[sl], lsG.shape[0] - 1), grp_[sl]]
            b2_ = np.clip(np.searchsorted(edgesG, wb_ * ticksG, side='right') - 1, 0, gatesG.shape[1] - 1)
            Wt = (wa_ + wb_) * ticksG
            fail_ = (key_ >= 0) & (Wt > gatesG[np.maximum(key_, 0), b2_])
            phi2 = top2 & ((tested_ & (fail_ | (key_ < 0) | over_)) | (okl_ & ~okc))
            acc['Xp_phi2'][it] = np.sum((wz * Fz * CFp)[phi2]) / n_
            acc['Q1_phi2'][it] = np.sum((wz * Fz ** 2)[phi2]) / n_
            acc['Xp_phi2_same_site'][it] = np.sum((wz * Fz * CFp)[phi2 & (il[nz] == jl[nz])]) / n_
            ph = np.flatnonzero(phi2)
            if len(ph):
                ee = np.arange(k)[None, :]
                ii, jj_ = il[nz][ph][:, None], jl[nz][ph][:, None]
                sel2 = (ee == ii) & (ee == jj_)
                sel1 = ((ee == ii) | (ee == jj_)) & ~sel2
                c2_ = cap_operator(T, tl[nz][ph], None, None, None, None, pa[nz][ph], pb[nz][ph], lf=lf[nz][ph], fail=sel2)[5]
                c1_ = cap_operator(T, tl[nz][ph], None, None, None, None, pa[nz][ph], pb[nz][ph], lf=lf[nz][ph], fail=sel1)[5]
                wp, Fp, Cp = wz[ph], Fz[ph], CFp[ph]
                acc['Xp_phi2_carry2'][it] = np.sum(wp * Fp * c2_) / n_
                acc['Xp_phi2_carry1'][it] = np.sum(wp * Fp * c1_) / n_
                acc['Xp_phi2_carry0'][it] = np.sum(wp * Fp * (Cp - c1_ - c2_)) / n_
            inrow = top2 & (wb_ >= args.row[0]) & (wb_ < args.row[1]) & (wa_ >= args.row[2]) & (wa_ < args.row[3])
            acc['Xp_top2_row'][it] = np.sum((wz * Fz * CFp)[inrow]) / n_
            acc['Q1_top2_row'][it] = np.sum((wz * Fz ** 2)[inrow]) / n_
            same_ = il[nz] == jl[nz]
            endsite = (il[nz] == pa[nz]) | (il[nz] == pb[nz]) | (jl[nz] == pa[nz]) | (jl[nz] == pb[nz])
            acc['Q1_top2_row_same'][it] = np.sum((wz * Fz ** 2)[inrow & same_]) / n_
            acc['Q1_top2_row_corecore'][it] = np.sum((wz * Fz ** 2)[inrow & ~same_ & ~endsite]) / n_
            acc['Q1_top2_row_end'][it] = np.sum((wz * Fz ** 2)[inrow & endsite]) / n_
            acc['Xp_phi2_row'][it] = np.sum((wz * Fz * CFp)[inrow & phi2]) / n_
            # all marks: the rest's sampled fragments plus the two inserted marks, in descending order
            fr = frag_rest[nz]
            extra = np.zeros((len(nz), k, 2))
            extra[np.arange(len(nz)), il[nz], 0] = xl[nz]
            same = il[nz] == jl[nz]
            extra[np.arange(len(nz)), jl[nz], np.where(same, 1, 0)] = np.where(same, yl[nz], yl[nz])
            allf = -np.sort(-np.concatenate([fr, extra], axis=2), axis=2)
            failed, uncl, untested, vfail, nfail, hibin = gate_failures(T, G, tl[nz], allf, rng, virtual=True)
            lowbin = (hibin >= 0) & (hibin < len(edgesG) - 1) & (edgesG[np.clip(hibin, 0, len(edgesG) - 1)] < a * ticksG)
            XF, QF = wz * Fz * CFp, wz * Fz ** 2
            Dt, Vt = failed & top2, vfail & top2
            Rt = Dt & ~vfail
            acc['Xp_D_top2'][it] = np.sum(XF[Dt]) / n_
            acc['Q1_D_top2'][it] = np.sum(QF[Dt]) / n_
            acc['Xp_V_top2'][it] = np.sum(XF[Vt]) / n_
            acc['Q1_V_top2'][it] = np.sum(QF[Vt]) / n_
            acc['Xp_R_top2'][it] = np.sum(XF[Rt]) / n_
            acc['Q1_R_top2'][it] = np.sum(QF[Rt]) / n_
            acc['Xp_VnotD_top2'][it] = np.sum(XF[Vt & ~failed]) / n_
            acc['Xp_phi2_notV_top2'][it] = np.sum(XF[phi2 & ~vfail]) / n_
            acc['Xp_R_top2_fail1'][it] = np.sum(XF[Rt & (nfail == 1)]) / n_
            acc['Xp_R_top2_fail2_4'][it] = np.sum(XF[Rt & (nfail >= 2) & (nfail <= 4)]) / n_
            acc['Xp_R_top2_fail5up'][it] = np.sum(XF[Rt & (nfail >= 5)]) / n_
            acc['Xp_R_top2_lowbin'][it] = np.sum(XF[Rt & lowbin]) / n_
            acc['Xp_D_top2_lowbin'][it] = np.sum(XF[Dt & lowbin]) / n_
            counts['D'] += int(Dt.sum()); counts['V'] += int(Vt.sum()); counts['R'] += int(Rt.sum())
            counts['VnotD'] += int((Vt & ~failed).sum()); counts['phi2_notV'] += int((phi2 & ~vfail).sum())
            counts['R_lowbin'] += int((Rt & lowbin).sum())
            acc['Q1_deleted'][it] = np.sum((wz * Fz ** 2)[failed]) / n_
            acc['Q1_unclassified'][it] = np.sum((wz * Fz ** 2)[uncl]) / n_
            acc['Q1_untested'][it] = np.sum((wz * Fz ** 2)[untested > 0]) / n_
            acc['Xp_deleted'][it] = np.sum((wz * Fz * CFp)[failed]) / n_
        if (it + 1) % max(1, args.batches // 5) == 0:
            print(json.dumps(dict(event='PROGRESS', batch=it + 1, seconds=round(time.time() - t0))), flush=True)
    res = {x: dict(mean=float(acc[x].mean() / I), se=float(acc[x].std(ddof=1) / np.sqrt(args.batches) / I)) for x in keys}
    print(json.dumps(dict(event='PAIRS', seed=args.seed, a=a, mark_top=top, total_cap=total_cap, exact_pair_count=bool(3 * a > total_cap),
                          batches=args.batches, samples=args.batches * PER, I=I,
                          I_relerr=float(np.std(Is, ddof=1) / np.sqrt(len(Is)) / I), beta_range=[args.beta_low, args.beta_high],
                          results=res, counts=counts, seconds=round(time.time() - t0))), flush=True)


FILTER_LEVELS = np.array([.001, .002, .004, .008, .012, .016, .020, .025, .032, .040, .050, .060, .075, .090, .11, .13, .15])
FILTER_STEP = 2000


def filter_restrictions(doc):
    """Per group: radius cap and tail bounds on a radius grid, as h1_multilevel_filter_screen.restrictions."""
    unit = doc['units']
    levels = FILTER_LEVELS * unit
    floor_radius = 2_000_000
    grid = np.arange(floor_radius, max(doc['group_radii']) + FILTER_STEP, FILTER_STEP, dtype=np.int64)
    G = len(doc['group_radii'])
    cap = np.full(G, unit, dtype=np.int64)
    bound = np.full((G + 1, len(grid), len(levels)), np.inf)
    for row in doc['channels']:
        srows = np.array(row['rows'], np.int64)
        g = np.asarray(row['gated_radius']); m = np.asarray(row['maximum_gated_partner'])
        cap = np.minimum(cap, np.where(m > 0, g, unit))
        for b, u in enumerate(levels):
            risk = np.where(srows[:, 3] < u, srows[:, 0] + srows[:, 3] - srows[:, 2] * u, np.inf)
            risk = np.r_[np.inf, np.minimum.accumulate(risk)]
            for i in np.flatnonzero(m):
                ix = np.searchsorted(srows[:, 0], grid + m[i], side='left')
                bound[i, :, b] = np.minimum(bound[i, :, b], risk[ix] * (g[i] / (g[i] + m[i])))
    assert floor_radius + max(doc['group_radii']) < unit // 2
    return floor_radius, np.r_[cap, unit], bound, levels


def filter_projection(args):
    T = Trial(args.trial)
    assert T.group_table is not None, 'export with a group table'
    doc = json.loads(Path(args.filter).read_text())
    assert len(doc['group_radii']) == T.m['ngroups']
    if args.strip_free:
        doc['channels'] = [row for row in doc['channels'] if row['channel'] not in ('C0', 'C1', 'C2')]
    floor_radius, gcap, bound, levels = filter_restrictions(doc)
    unit = doc['units']
    ticks = T.m['rho_ticks'] * unit                    # physical ticks per unit of normalised total
    rng = np.random.default_rng(args.seed)
    k, S, zeta, h = T.k, T.S, T.zeta, T.h
    prop = rlib.Proposal(S, T.gfun, np.linspace(0, 120, 25), zeta)
    use = np.flatnonzero((prop.mean * k > args.low) & (prop.mean * k < args.high))

    def logq(t):
        Lg = np.array([np.log(prop.density(np.full(len(t), b), t)).sum(axis=1) for b in use]) - np.log(len(use))
        mx = Lg.max(axis=0)
        return mx + np.log(np.exp(Lg - mx).sum(axis=0))

    keys = ('I', 'A', 'A_radius', 'X', 'Xp', 'Aneg', 'failing_erasures', 'Ce')
    acc = {x: np.zeros(args.batches) for x in keys}
    squares = np.zeros(args.batches)
    nfail = 0
    t0 = time.time()
    for it in range(args.batches):
        n_ = PER
        bi = use[rng.integers(0, len(use), n_)]
        t = prop.sample(bi, k, rng)
        lw = np.log(rlib.rho(t / zeta)).sum(axis=1) - logq(t)
        frag, dust = rlib.fragments(t, np.full(t.shape, zeta), UMIN, rng)          # (n, k, L)
        lf = frag[:, :, 0]
        M0 = lf.max(axis=1)
        pa, pb = positions(rng, n_, k, 2)
        F = T.F(t, M0, pa, pb)
        w = np.exp(lw)
        acc['I'][it] = np.sum(w * F * F) / n_
        squares[it] = np.sum((w * F * F) ** 2)
        live = np.flatnonzero(F != 0)
        failed = np.zeros(n_, bool); radius_failed = np.zeros(n_, bool); count = np.zeros(n_)
        if len(live):
            fl = frag[live] * ticks                                                   # physical marks
            tail_coord = np.stack([np.where(fl >= u, fl, 0.0).sum(axis=2) for u in levels], axis=2)   # (n, k, levels)
            tail_all = tail_coord.sum(axis=1)
            j = T.cells(t[live]); r = j.sum(axis=1)
            s_ticks = t[live].sum(axis=1) * ticks
            lfl = lf[live]
            order = -np.sort(-lfl, axis=1); top1, top2 = order[:, 0], order[:, 1]
            for e in range(k):
                Y = s_ticks - t[live, e] * ticks
                M0Y = np.where(lfl[:, e] >= top1, top2, top1)
                lay, okl = T.layer(M0Y)
                rY = r - j[:, e]
                okr = (rY >= 0) & (rY < T.group_table.shape[1])
                grp = np.where(okl & okr, T.group_table[np.where(okl, lay, 0), np.clip(rY, 0, T.group_table.shape[1] - 1)], -1)
                tested = grp >= 0
                gg = np.where(tested, grp, 0)
                gi = np.clip(np.floor((Y - floor_radius) / FILTER_STEP).astype(np.int64), 0, bound.shape[1] - 1)
                tails = tail_all - tail_coord[:, e, :]
                rfail = tested & (Y > gcap[gg])
                tfail = tested & np.any((tails > levels / 2) & (tails > bound[gg, gi, :]), axis=1)
                bad = rfail | tfail
                failed[live] |= bad
                radius_failed[live] |= rfail
                count[live] += bad
        idx = np.flatnonzero(failed)
        nfail += len(idx)
        if len(idx):
            CF, CS, CFp, CFm, CSp = cap_operator(T, t[idx], None, None, None, None, pa[idx], pb[idx], lf=lf[idx])
            Ff, wf = F[idx], w[idx]
            acc['A'][it] = np.sum(wf * Ff ** 2) / n_
            acc['A_radius'][it] = np.sum((wf * Ff ** 2)[radius_failed[idx]]) / n_
            acc['X'][it] = np.sum(wf * Ff * CF) / n_
            acc['Xp'][it] = np.sum(wf * Ff * CFp) / n_
            acc['Aneg'][it] = np.sum((wf * Ff ** 2)[Ff < 0]) / n_
            acc['failing_erasures'][it] = np.sum(wf * Ff ** 2 * count[idx]) / n_
            # pair-restoration fibre bound: C(e) <= int_D |F|^2 Phi, Phi at the core total
            rows = np.arange(len(idx))
            core_total = t[idx].sum(axis=1) - t[idx][rows, pa[idx]] - t[idx][rows, pb[idx]]
            qc = T.rho * core_total
            phi = ((T.rho * T.S - qc) / (0.5 - qc - 1e-4)) ** 2
            acc['Ce'][it] = np.sum(wf * Ff ** 2 * phi) / n_
        if (it + 1) % max(1, args.batches // 5) == 0:
            print(json.dumps(dict(event='PROGRESS', batch=it + 1, failures=nfail, seconds=round(time.time() - t0))), flush=True)
    I = acc['I'].mean()
    res = {x: dict(mean=float(acc[x].mean() / I), se=float(acc[x].std(ddof=1) / np.sqrt(args.batches) / I))
           for x in keys if x != 'I'}
    ess = float((acc['I'].sum() * PER) ** 2 / squares.sum())
    print(json.dumps(dict(event='FILTER', seed=args.seed, batches=args.batches, samples=args.batches * PER, strip_free=args.strip_free,
                          I=float(I), I_relerr=float(acc['I'].std(ddof=1) / np.sqrt(args.batches) / I), effective_sample_size=ess,
                          failures=nfail, results=res, seconds=round(time.time() - t0))), flush=True)


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='step', required=True)
    p = sub.add_parser('export')
    p.add_argument('--dimension', type=int, default=39)
    p.add_argument('--pair', action='store_true')
    p.add_argument('--angular', type=int, default=4)
    p.add_argument('--shapes', default='0,p2,300')
    p.add_argument('--intervals', type=int, default=32768)
    p.add_argument('--start', required=True)
    p.add_argument('--price-table', default=str(HERE.parents[1] / 'lean' / 'minorants' / 'data' / 'ml12_w25_prices.json'))
    p.add_argument('--groups', default=str(HERE / 'h1_decoupled_coarsened_1e14.json'),
                   help='certificate whose groups the root filter is compiled for')
    p.add_argument('--out', required=True)
    p = sub.add_parser('gates')
    p.add_argument('--norm', default=str(HERE / 'h1_combined_mass_native_interval.json'))
    p.add_argument('--fibres', default=str(HERE / 'h1_combined_fibres_native_interval.json'))
    p.add_argument('--collar', default=str(HERE / 'h1_multilevel_price_collar.json'))
    p.add_argument('--plateaus', default=str(HERE / 'h1_multilevel_tail_plateaus.json'),
                   help='plateau certificate, or with --tilt the tilted-line certificate h1_multilevel_tail_tilt<rate>.json')
    p.add_argument('--tilt', type=int, default=0, help='twice the slope c of the tilted line L - c u (0: plateau gate)')
    p.add_argument('--used', required=True, help='npz with the nonzero patterns of the 14 strip-free affine channels')
    p.add_argument('--groups', default=str(HERE / 'h1_decoupled_coarsened_1e14.json'))
    p.add_argument('--radial-step', type=int, default=2000)
    p.add_argument('--spacing', type=int, default=10000)
    p.add_argument('--out', required=True)
    p = sub.add_parser('pairs')
    p.add_argument('trial')
    p.add_argument('--seed', type=int, default=1)
    p.add_argument('--batches', type=int, default=20)
    p.add_argument('--norm-batches', type=int, default=20)
    p.add_argument('--a', type=float, default=0.131, help='mark threshold, in units of the normalised total')
    p.add_argument('--gates', help='also report the share deleted by these tail gates')
    p.add_argument('--beta-low', type=float, default=30.0)
    p.add_argument('--beta-high', type=float, default=30000.0)
    p.add_argument('--row', type=float, nargs=4, default=[0.25, 0.27, 0.39, 0.41],
                   help='bounds of the smaller and the larger mark for the row diagnostics')
    p.add_argument('--low', type=float, default=0.75)
    p.add_argument('--high', type=float, default=1.15)
    for name in ('validate', 'outer', 'inner', 'project', 'filter', 'gate'):
        p = sub.add_parser(name)
        p.add_argument('trial')
        p.add_argument('--seed', type=int, default=1)
        p.add_argument('--batches', type=int, default=20)
        if name == 'gate':
            p.add_argument('--gates', required=True)
            p.add_argument('--minority', action='store_true', help='also sample the two minority-sign pairings')
            p.add_argument('--profile', action='store_true',
                           help='record where the deleted mass lies: failing mark, rank, sites and radius gap')
            p.add_argument('--inner', type=int, default=400, help='inner samples per erased root')
            p.add_argument('--window', type=float, default=0.0,
                           help='with --profile: mass of the erasure-free window superset for erasures of total <= this')
            p.add_argument('--negate', action='store_true', help='replace F by -F (majority sign positive)')
            p.add_argument('--gate-tilt', type=int, default=0,
                           help='twice the slope of the tilted line the gate tables were built with (0: plateau)')
        if name == 'filter':
            p.add_argument('--filter', default=str(HERE / 'h1_multilevel_root_filter.json'))
            p.add_argument('--strip-free', action='store_true')
        if name in ('filter', 'gate'):
            p.add_argument('--low', type=float, default=0.75, help='range of k times the mean coordinate total of the tilts used')
            p.add_argument('--high', type=float, default=1.15)
        if name not in ('validate', 'filter', 'gate'):
            p.add_argument('--mass', type=float, required=True, help='the Monte Carlo mass I from validate')
            p.add_argument('--region', default='rank2', choices=['rank2', 'other'])
        if name == 'inner':
            p.add_argument('--target', type=float, default=0.92)
    args = parser.parse_args()
    {'export': export, 'validate': validate, 'outer': outer, 'inner': inner, 'project': project,
     'filter': filter_projection, 'gates': build_gates, 'gate': gate_projection, 'pairs': pair_marks}[args.step](args)


if __name__ == '__main__':
    main()
