"""Continue the combined finite dual and construct a feasible adverse assignment.

The upper witness applies to the 454-variable compressed problem, not to all
possible finer sector partitions or to the continuous prime-gap problem.
"""
import argparse
from fractions import Fraction as Q
from math import ceil, floor, isqrt, lcm
from pathlib import Path
import json

import numpy as np
from scipy.linalg import eigh

from h1_cover_family import rational
from h1_cover_pairings import model, tile_energies, TABLE, DUAL, MINORANTS
from h1_joint_semiprime_strips import add_strips
from h1_shared_rough_pricing import certify
from h1_split_shared_covers import solve
from h1_sunrise_boundary import read, digest
from verify_pairing_envelope import SCALE, quantize


def mixture_energies(forms, fit):
    desc, fitted = map(read, (forms, fit))
    archive = forms.with_suffix('.npz')
    assert fitted['inputs'][forms.name] == digest(forms)
    assert fitted['inputs'][archive.name] == digest(archive)
    assert desc['inputs'][TABLE.name] == digest(TABLE)
    assert desc.get('archive_sha256', desc.get('forms_sha256')) == digest(archive)
    v = np.asarray(desc['transform'], dtype=object) @ np.asarray(fitted['families']['mixed']['weights'], dtype=object)
    with np.load(archive, allow_pickle=False) as z:
        energy = (v @ rational(z['energies']) @ v) / (v @ rational(z['mass']) @ v)
    return energy


def load_problem(cover, seed, forms, fit, three_cutoff=None):
    cert=read(seed)
    archive=forms.with_suffix('.npz')
    energy=mixture_energies(forms,fit)
    data, _, inputs, _ = model(cover, energies=energy,three_cutoff=three_cutoff)
    assert all(cert['inputs'][k] == h for k, h in inputs.items())
    groups = read(DUAL)['groups']
    old = tile_energies()
    ratio = np.sqrt(np.array([sum(energy[g, 0])/sum(old[g, 0]) for g in groups], float))
    lin = [quantize(np.asarray(x, float)/SCALE*np.outer(ratio, ratio)) for x in cert['affine']]
    factors = [quantize(np.asarray(x, float)/SCALE*ratio[:, None]) for x in cert['factors']]
    cuts = list(map(Q, cert['cuts']))
    data, bands = add_strips(data, read(TABLE), cuts)
    for f in (cover, seed, forms, archive, fit):
        inputs[f.name] = digest(f)
    return data, bands, lin, factors, inputs, cuts


def densities(data, bands):
    row = next(s for s in read(MINORANTS)['rows'] if Q(s['theta']) == Q('.5291'))
    old = data[4]
    five = tuple(Q(row['five_mass'][key]) for key in ('lower', 'upper'))
    three = tuple(Q(row['three_mass'][key], 10**6) for key in ('lower_millionths', 'upper_millionths'))
    assert tuple(a+b for a,b in zip(three, five)) == data[5]
    return [(Q(1), Q(1)), old, three, (five[0]-old[1], five[1]-old[0]), *[b for _, b in bands]]


class Adversary:
    def __init__(self, data, bands):
        self.data, self.bands = data, bands
        self.intervals = densities(data, bands)
        self.means = np.array([float(sum(v)/2) for v in self.intervals])
        self.masks = [*data[1:4], *[m for m, _ in bands]]
        self.n = len(data[0])
        self.i, self.j = np.triu_indices(self.n)
        self.diag = self.i == self.j
        base = np.zeros((len(self.masks), len(self.means)))
        base[:3, :4] = [[1,0,0,0], [1,-1,0,0], [1,-1,-1,-1]]
        for t in range(len(bands)):
            base[3+t,4+t] = 1
        self.projections = []
        flags = np.column_stack([m[self.i,self.j] for m in self.masks])
        for code in range(1 << len(self.masks)):
            chosen = np.array([bool(code & (1 << t)) for t in range(len(self.masks))])
            ids = np.flatnonzero((flags == chosen).all(1))
            if len(ids) and chosen.any():
                B = base[chosen]*self.means
                self.projections.append((ids, B, np.linalg.pinv(B, rcond=1e-15)))
        self.best = float('inf')
        self.proposal = None
        self.blend = None
        self.history = []

    def __call__(self, matrices, tau, step, lower):
        y = np.array([x[self.i,self.j] for x in matrices])/self.means[:,None]
        for ids, B, inverse in self.projections:
            target = B.sum(1)[:,None]*self.diag[ids]
            y[:,ids] += inverse @ (target-B@y[:,ids])
        raw = []
        for a, mu in zip(y, self.means):
            x = np.empty((self.n,self.n))
            x[self.i,self.j] = x[self.j,self.i] = a*mu
            raw.append(x)
        baseline = [np.eye(self.n)*v for v in self.means]
        residuals = []
        for x, mu, bounds, cap in zip(raw, self.means, self.intervals, self.data[-2]):
            low, high = map(float,bounds)
            residuals.append((x+(low-mu)*np.eye(self.n), np.full(self.n, low)))
            residuals.append((np.diag(cap.astype(float))-x-(high-mu)*np.eye(self.n), cap.astype(float)-high))
        for alpha, cap in self.data[-1]:
            coeff = np.asarray(alpha,float)
            hi = sum(float(b[1])*a for a,b in zip(coeff,self.intervals))
            shifted = sum(a*(x+(float(b[1])-mu)*np.eye(self.n)) for a,x,b,mu in zip(coeff,raw,self.intervals,self.means))
            residuals.append((np.diag(cap.astype(float))-shifted, cap.astype(float)-hi))
        least = 0.
        for M, base in residuals:
            assert min(base) > 0
            val = eigh(M/np.sqrt(np.outer(base,base)), eigvals_only=True,
                       subset_by_index=[0,0], check_finite=False)[0]
            least = min(least, val)
        blend = min(1., -least/(1-least)+2e-7)
        w = np.sqrt(self.data[0][:,0].astype(float))
        value = float(self.data[6])+w@((1-blend)*raw[0]+blend*baseline[0])@w
        if value < self.best:
            self.best, self.proposal, self.blend = value, [quantize(x) for x in raw], Q(ceil(blend*10**9),10**9)
        item = dict(tau=tau, step=step, lower=float(lower), upper=float(value), blend=float(blend), best_upper=float(self.best))
        self.history.append(item)
        print('adversary', item, flush=True)


def integer_pd(M, denominator):
    a = np.asarray(M,float)/denominator
    smallest = eigh(a,eigvals_only=True,subset_by_index=[0,0],check_finite=False)[0]
    assert smallest > 0, smallest
    factor = quantize(np.linalg.cholesky(a-.4*smallest*np.eye(len(M))))
    R = SCALE**2*M-denominator*(factor@factor.T)
    assert np.all(2*R.diagonal() > np.abs(R).sum(1))


def check_upper(data, bands, proposal, blend):
    intervals = densities(data,bands)
    means = [sum(b)/2 for b in intervals]
    den = lcm(SCALE, *[x.denominator for b in intervals for x in b], *[x.denominator for x in means])
    n = len(data[0]); eye = np.eye(n,dtype=object)
    mats = [np.asarray(x,dtype=object)*(den//SCALE) for x in proposal]
    assert len(mats)==len(intervals) and all(np.array_equal(x,x.T) for x in mats)
    P,B,A,D = mats[:4]
    p,m,g = data[1:4]
    P[p] = (den*eye)[p]
    B[m] = (P-int(den*(1-means[1]))*eye)[m]
    A[g] = (P-B-D-int(den*(1-sum(means[1:4])))*eye)[g]
    for x,(mask,_),mu in zip(mats[4:],bands,means[4:]):
        x[mask] = (int(den*mu)*eye)[mask]
    numerator, unit = blend.numerator, blend.denominator
    assert 0 < blend < 1
    mats = [(unit-numerator)*x+numerator*int(den*mu)*eye for x,mu in zip(mats,means)]
    den *= unit
    P,B,A,D = mats[:4]
    assert np.array_equal(P[p],(den*eye)[p])
    assert np.array_equal((P-B)[m],(int(den*(1-means[1]))*eye)[m])
    assert np.array_equal((P-B-A-D)[g],(int(den*(1-sum(means[1:4])))*eye)[g])
    for x,(mask,_),mu in zip(mats[4:],bands,means[4:]):
        assert np.array_equal(x[mask],(int(den*mu)*eye)[mask])
    low = [x+int(den*(b[0]-mu))*eye for x,b,mu in zip(mats,intervals,means)]
    high = [x+int(den*(b[1]-mu))*eye for x,b,mu in zip(mats,intervals,means)]
    residuals = low+[np.diag([floor(u*den) for u in cap])-x for cap,x in zip(data[-2],high)]
    # Clear the rational 1/24 and 1/2 coefficients before checking each
    # coupled inequality. Diagonal budget rounding only tightens a cap.
    residuals += [24*np.diag([floor(u*den) for u in cap])-sum(int(24*a)*x for a,x in zip(alpha,high)) for alpha,cap in data[-1]]
    for index,M in enumerate(residuals):
        integer_pd(M,den*(24 if index >= 2*len(mats) else 1))
        print('positive constraint',index+1,'of',len(residuals),flush=True)
    w = np.array([isqrt(int(e*SCALE**2)) for e in data[0][:,0]],dtype=object)
    error = max(data[-2][0])*Q(2*sum(w)*n+n*n,SCALE**2)
    value = data[6]+Q(int(w@P@w),den*SCALE**2)+error
    return ceil(value*10**9)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for name in ('cover','seed','forms','fit'):
        ap.add_argument(name,type=Path)
    ap.add_argument('--warm',type=Path)
    ap.add_argument('--three-cutoff',type=Q)
    ap.add_argument('--lower-only',action='store_true')
    ap.add_argument('--balance-measures',type=float,default=0.,
                    help='Power of mean-to-median-cap ratio used for the spectral metric.')
    ap.add_argument('--steps',type=int,default=160)
    ap.add_argument('--stages',nargs='+',type=float,default=[8e-6,1.6e-6,3.2e-7])
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--check',action='store_true')
    a = ap.parse_args()
    data,bands,lin,factors,inputs,cuts = load_problem(a.cover,a.seed,a.forms,a.fit,a.three_cutoff)
    if a.warm:
        prev=read(a.warm)
        assert prev['inputs']==inputs
        lin=[np.array(x,dtype=object) for x in prev['affine']]
        factors=[np.array(x,dtype=object) for x in prev['factors']]
    if a.check:
        out=read(a.output)
        assert out['inputs']==inputs and out['cuts']==list(map(str,cuts))
        assert out.get('three_cutoff')==(str(a.three_cutoff) if a.three_cutoff is not None else None)
        assert out.get('lower_only',False)==a.lower_only
        lin=[np.array(x,dtype=object) for x in out['affine']]
        factors=[np.array(x,dtype=object) for x in out['factors']]
    else:
        adversary=None if a.lower_only else Adversary(data,bands)
        means=np.array([float(sum(v)/2) for v in densities(data,bands)])
        metric=(means/np.array([np.median(v.astype(float)) for v in data[-2]]))**a.balance_measures
        lin,factors,history=solve(data,lin,a.steps,strips=bands,initial_factors=factors,
                                  stages=a.stages,observer=adversary,measure_weights=metric)
        out=dict(scope='Bounds on the compressed 454-variable finite model for the combined mixture. No continuum or finer-partition upper claim.',
                 inputs=inputs,cuts=list(map(str,cuts)),history=history,
                 three_cutoff=str(a.three_cutoff) if a.three_cutoff is not None else None,
                 lower_only=a.lower_only,
                 metric=metric.tolist(),
                 affine=[x.tolist() for x in lin],factors=[x.tolist() for x in factors],
                 )
        if adversary is not None:
            out.update(adversary_history=adversary.history,
                       primal_proposal=[x.tolist() for x in adversary.proposal],blend=str(adversary.blend))
        # Save a restartable search record before the slower integer checks.
        a.output.write_text(json.dumps(out,separators=(',',':'))+'\n',newline='\n')
    lo=floor(certify(data,lin,factors,bands)*10**9)
    hi=None if a.lower_only else check_upper(data,bands,out['primal_proposal'],Q(out['blend']))
    assert hi is None or lo<=hi
    if a.check:
        assert out['interval_billionths']==[lo,hi]
    else:
        out.update(interval_billionths=[lo,hi],lower_billionths=lo)
        a.output.write_text(json.dumps(out,separators=(',',':'))+'\n',newline='\n')
    print('compressed finite interval',lo,hi,flush=True)


if __name__=='__main__':
    main()
