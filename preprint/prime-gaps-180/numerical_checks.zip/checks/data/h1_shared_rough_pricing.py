"""Price both minorants with disjoint-support bounds on the prime, three-prime and five-prime measures."""
import argparse
from decimal import Decimal
from fractions import Fraction as Q
from hashlib import sha256
import json
from math import ceil,floor,isqrt
from pathlib import Path
import numpy as np
from scipy import sparse
from scipy.linalg import eigh
from h1_bilinear_pricing import proof_data,kernel,five_upper
from h1_pairing_sdp import scs
from verify_pairing_envelope import lower_factor,quantize,SCALE


def budgets(args):
    (e,p,m,g,J,k,kt,fixed,omitted),groups,_,_=proof_data(args,with_layout=True)
    table=json.loads(args.control.read_text(),parse_float=Decimal)
    weights=np.array([Q(row[0]) for row in table['sector_energies']],dtype=object)
    q=[Q(ceil(Q(v)*10000)+1,10000) for v in table['physical_upper']]
    source=next(r for r in json.loads(args.minorants.read_text())['rows'] if Q(r['theta'])==Q(args.level))
    z,a,lam=map(Q,(source['zeta'],source['a'],source['rough']))
    a0=Q('.41361');retreat=Q('.0001')
    def calc(t):
        three=Q(kernel(z,a,t,bins=128)[1],10**12);five=five_upper(a,t)
        rough=lambda cut:1/(min(cut,Q(1,2)-t)-retreat)
        # Mark at least one new unordered pair of primes on every five-prime
        # exception absent from the old set. Bound its reciprocal measure.
        step=(a-a0)/128;thin=0
        for i in range(128):
            l=a0+i*step;r=l+step
            thin+=ceil(10**12*24*step*(r-2*lam)/(l*lam*(min(lam,(1-r)/2-t)-retreat)))
        return np.array([three,five,rough(Q('.17278')),rough(z),rough(lam),five,Q(thin,10**12)],dtype=object)
    cache={x:calc(x) for x in set(q)}
    vals=np.array([sum((weights[i]*cache[q[i]] for i in group),np.zeros(7,dtype=object))/sum(weights[group]) for group in groups])
    upper=[e[:,1]/e[:,0],e[:,2]/e[:,0],vals[:,0],vals[:,1]]
    coupled=[([1,Q(1,24),0,0],vals[:,2]),([1,0,Q(1,2),0],vals[:,3]),
             ([1,Q(1,24),Q(1,2),Q(1,24)],vals[:,4]),([0,1,0,1],vals[:,5]),([0,0,0,1],vals[:,6])]
    return e,p,m,g,k,kt,fixed,omitted,upper,coupled


def solve(data,seconds,fixed_five=None):
    e,p,m,g,k0,kt,fixed,omitted,upper,coupled=data
    k=float(sum(k0)/2);kt=float(sum(kt)/2);n=len(e);i,j=np.triu_indices(n);l=len(i);fac=np.where(i==j,1.,np.sqrt(2.))
    def unpack(y):
        M=np.zeros((n,n));M[i,j]=y/fac;M[j,i]=M[i,j];return M
    diag=(i==j).astype(float);eye=sparse.eye(l,format='csc');zero=sparse.csc_matrix((l,l))
    z=np.where(np.diag(p&m),np.sqrt(k),1.);zz=z[i]*z[j]
    variables=[sparse.hstack([eye if t==s else zero for s in range(4)],format='csr') for t in range(4)]
    P,Bn,A,D=variables;B=sparse.diags(zz)@Bn
    mask=p[i,j];old=m[i,j];new=g[i,j]
    use=[mask,mask&old,old&~mask,new&old,new&mask&~old,new&~mask&~old]
    forms=[P,Bn,P-B,A+D,B+A+D,P-B-A-D]
    val=[diag,k*diag/zz,(1-k)*diag,(kt-k)*diag,kt*diag,(1-kt)*diag]
    mats=[F[q] for F,q in zip(forms,use)];rhs=[v[q] for v,q in zip(val,use)]
    if fixed_five is not None:mats.append(D);rhs.append(float(fixed_five)*diag)
    nzero=sum(map(len,rhs))
    for neg,var,ub in zip(variables,[P,B,A,D],upper):
        mats.extend([-neg,var]);rhs.extend([np.zeros(l),ub.astype(float)[i]*diag])
    for coeff,ub in coupled:
        mats.append(sum(float(x)*v for x,v in zip(coeff,(P,B,A,D))))
        rhs.append(ub.astype(float)[i]*diag)
    w=np.sqrt(e[:,0].astype(float))
    spec=dict(A=sparse.vstack(mats,format='csc'),b=np.concatenate(rhs),c=np.r_[w[i]*w[j]*fac,np.zeros(3*l)])
    sol=scs.solve(spec,dict(z=nzero,s=[n]*(8+len(coupled))),eps_abs=3e-7,eps_rel=3e-7,max_iters=150000,time_limit_secs=seconds,verbose=False)
    if fixed_five is not None:
        v=sol['x'];return (unpack(v[:l]),unpack(v[l:2*l])*np.outer(z,z),unpack(v[2*l:3*l])),sol['info']['status']
    y=sol['y'];packed=[];start=0
    for q in use:
        v=np.zeros(l);size=int(q.sum());v[q]=-y[start:start+size];packed.append(v);start+=size
    a,b,c,h,f,s=packed
    lin=[quantize(unpack(v)) for v in (a+b/zz+f,c-b/zz+h,s-h-f)]
    pos=[]
    for j in range(len(coupled)):
        start=nzero+(8+j)*l
        val,vec=eigh(unpack(y[start:start+l]))
        pos.append(quantize(vec[:,val>0]*np.sqrt(val[val>0])))
    return lin,pos,sol['info']['status']


def certify(data,lin,pos,additional=()):
    e,p,m,g,k0,kt,fixed,omitted,upper,coupled=data;L,R,S=lin[:3];n=len(e)
    masks=(p,m,g,*(row[0] for row in additional))
    assert len(pos)==len(coupled) and len(masks)==len(lin) and len(upper)==4+len(additional)
    assert all(np.array_equal(x,x.T) and not x[~t].any() for x,t in zip(lin,masks))
    w=np.array([isqrt(int(x*SCALE**2)) for x in e[:,0]],dtype=object)
    err=max(upper[0])*(2*sum(w)*n+n*n)*Q(1,SCALE**2)
    # Retain a common integer denominator after including the 1/24 and
    # 1/2 coefficients from the joint rough-support constraints.
    mats=[np.outer(w,w)-SCALE*(L+R+S),SCALE*(R+S),SCALE*S,SCALE*S,*[-SCALE*v for v in lin[3:]]]
    mats=[24*A for A in mats];cost=Q(0)
    for F,(coeff,budget) in zip(pos,coupled):
        T=F@F.T;cost+=sum(T.diagonal()*budget)/SCALE**2
        for M,x in zip(mats,coeff):M+=int(24*x)*T
    for M,ub in zip(mats,upper):
        # lower_factor expects a denominator SCALE^2; apply to 24 times the
        # actual matrix and scale the resulting PSD correction back.
        diag,_=lower_factor(M,ub);cost+=sum(diag*ub)/24
    tr=lambda A:Q(int(A.trace()),SCALE)
    credit=sum(min(k*tr(v) for k in interval) for v,(_,interval) in zip(lin[3:],additional))
    return fixed+tr(L)+min((1-k)*tr(R) for k in k0)+min((1-k)*tr(S) for k in kt)+credit-cost-err


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('control',type=Path)
    p.add_argument('--permissions',type=Path,default=Path('h1_refit280_step2_permissions_131072.json'))
    p.add_argument('--minorants',type=Path,default=Path('../sensitivity/bilinear_minorant.json'))
    p.add_argument('--ladder-receipt',type=Path,default=Path('h1_bilinear_ladders_131072.json'))
    p.add_argument('--level',default='.5291');p.add_argument('--grant',choices=['ladder','ladder-outward','outer'],default='ladder')
    p.add_argument('--seconds',type=int,default=100);p.add_argument('--output',type=Path,required=True);p.add_argument('--check',action='store_true');a=p.parse_args()
    data=budgets(a);hashes={f.name:sha256(f.read_bytes()).hexdigest() for f in (a.control,a.permissions,a.minorants,a.ladder_receipt)}
    if a.check:
        out=json.loads(a.output.read_text());assert out['inputs']==hashes and out['level']==a.level and out['grant']==a.grant
        lin,pos=[[np.array(x,dtype=object) for x in out[key]] for key in ('affine','positive_factors')]
    else:lin,pos,status=solve(data,a.seconds)
    bound=floor(certify(data,lin,pos)*10**9)
    if a.check:assert bound==out['lower_billionths']
    else:
        out=dict(scope='Exact lower witness for the stated finite cap-sector model; floating erasure quadrature and restoration are separate.',
                 inputs=hashes,grant=a.grant,level=a.level,states=len(data[0]),scale=SCALE,solver_status=status,
                 affine=[x.tolist() for x in lin],positive_factors=[x.tolist() for x in pos],lower_billionths=bound)
        a.output.write_text(json.dumps(out,separators=(',',':'))+'\n')
    print(a.control.name,bound,flush=True)


if __name__=='__main__':main()
