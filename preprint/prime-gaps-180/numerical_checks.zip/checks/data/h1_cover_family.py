"""Re-evaluate trial spaces and independent scalar replays on the new fixed prices."""
import argparse
import json
from fractions import Fraction as Q
from math import floor
from pathlib import Path

import numpy as np
from scipy.linalg import eigh

from h1_cover_pairings import TABLE,TILES
from h1_sunrise_boundary import digest,geometry,read
from h1_sunrise_refined import FORMS,positive_definite
from verify_pairing_envelope import SCALE


def rational(array):
    return np.vectorize(lambda v: Q(float(v)),otypes=[object])(array)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('prices',type=Path);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--scalar',type=Path)
    p.add_argument('--mixed',type=Path)
    p.add_argument('--check',action='store_true')
    a=p.parse_args()
    desc=read(a.prices)
    assert desc['scale']==SCALE and desc['inputs'][TABLE.name]==digest(TABLE)
    prices=np.array(desc['sector_prices'],dtype=object)
    inputs={a.prices.name:digest(a.prices),TABLE.name:digest(TABLE)}
    old=read(a.output) if a.check else None
    if a.scalar:
        record=read(a.scalar)
        spline=a.scalar.with_name(record['trial_refit'])
        bins=a.scalar.with_name(record['cell_bins'])
        assert digest(bins)==record['cell_bins_sha256']
        _,source,layout=geometry(TABLE)
        assert all(record[k]==source[k] for k in ('intervals','sources','codes','fragment_cap','component_limits'))
        with np.load(bins,allow_pickle=False) as z,np.load(TABLE.with_name(source['cell_bins']),allow_pickle=False) as ref:
            cells=z['cells']
            np.testing.assert_array_equal(cells[:,:4],ref['cells'][:,:4])
        raw=np.zeros(prices.shape,dtype=object)
        for cap in np.unique(cells[:,1]):
            block=cells[cells[:,1]==cap]
            group=layout(cap,block[:,3].astype(int))
            np.add.at(raw,group,rational(block[:,4:7]))
        assert min(raw.ravel())>0
        score=floor(sum((raw*prices).ravel())*Q(10**9,SCALE))
        inputs.update({f.name:digest(f) for f in (a.scalar,spline,bins)})
        doc=dict(scope='Fixed-price lower witness on the stored normalized scalar cell energies.',
                 inputs=inputs,lower_billionths=score)
        print('scalar',spline.name,score,flush=True)
    else:
        result={}
        tables=[('mixed',a.mixed)] if a.mixed else [('tiles',TILES),('sunrise',FORMS)]
        for label,path in tables:
            fit=read(path);archive=path.with_suffix('.npz')
            assert digest(archive)==fit.get('archive_sha256',fit.get('forms_sha256'))
            inputs.update({f.name:digest(f) for f in (path,archive)})
            with np.load(archive,allow_pickle=False) as z:
                G=rational(z['mass'])
                E=rational(z['energies'])
            transform=np.array(fit['transform'],dtype=object) if 'transform' in fit else np.eye(len(G),dtype=int).astype(object)
            W=np.sum(E*prices[:,:,None,None],axis=(0,1))*Q(1,SCALE)
            gram,form=transform.T@G@transform,transform.T@W@transform
            if old:
                coeff=old['families'][label]['weights']
            else:
                g=gram.astype(float)
                d,V=eigh(g)
                assert d[0]>1e-14*d[-1]
                basis=V/np.sqrt(d)
                _,v=eigh(basis.T@form.astype(float)@basis)
                v=basis@v[:,-1]
                coeff=np.rint(10**12*v/max(abs(v))).astype(np.int64).tolist()
            v=transform@np.array(coeff,dtype=object)
            mass=v@G@v
            raw=v@E@v
            assert mass>0 and min(raw.ravel())>=0
            score=floor(Q(10**9,SCALE)*sum((raw*prices).ravel())/mass)
            assert positive_definite(gram) and positive_definite(Q(score+1,10**9)*gram-form)
            result[label]=dict(lower_billionths=score,fixed_price_upper_billionths=score+1,weights=coeff)
            print(label,score,flush=True)
        doc=dict(scope='Exact finite bounds for the fixed-price quotients on the specified trial spaces.',
                 inputs=inputs,families=result)
    if old:assert doc==old
    else:a.output.write_text(json.dumps(doc,indent=2)+'\n')


if __name__=='__main__':
    main()
