"""Exact arithmetic readback of a sector Gram envelope on the stored finite data."""
import argparse
from decimal import Decimal
from fractions import Fraction as F
import json
from math import ceil,floor
from pathlib import Path

import numpy as np
from scipy.linalg import eigh
from h1_pairing_sectors import HERE
from h1_cross_ladders import apply_permissions


SCALE=10**14


def quantize(a):
    v=np.rint(np.asarray(a,dtype=float)*SCALE)
    assert np.max(abs(v),initial=0)<2**62
    return v.astype(np.int64).astype(object)


def exact_data(fit,sample):
    ctrl=json.loads((HERE/str(sample['control'])).read_text(),parse_float=Decimal)
    v=[F(1),*map(lambda x:F(float(x)),fit['coefficients'])]
    def qform(x):
        return sum((v[i]*v[j]*F(float(x[i,j])) for i in range(len(v)) for j in range(len(v)) if x[i,j]),F(0))
    nr=len(sample['masses'])
    mass=sum(map(qform,sample['masses']))/nr
    e=[[F(x) for x in row] for row in ctrl['sector_energies']]
    for run in sample['deltas']:
        for i,rows in enumerate(run):
            for j,mat in enumerate(rows):e[i][j]+=qform(mat)/nr
    if fit['permissions']:apply_permissions(ctrl,HERE/fit['permissions'])
    return ctrl,mass,np.array(e,dtype=object)


def lower_factor(anum,budget):
    # Integer numerator of A has denominator SCALE². Write A+VV^t
    # as WW^t plus a small symmetric residual and cover it by its row sum.
    a=np.asarray(anum,dtype=float)/SCALE**2;s=np.sqrt(np.array(budget,dtype=float))
    ev,vec=eigh(a*np.outer(s,s))
    def factor(f):
        return quantize(vec[:,f]*np.sqrt(abs(ev[f]))/s[:,None])
    V=factor(ev<0);W=factor(ev>0)
    vv=V@V.T;err=anum+vv-W@W.T
    shift=max(np.abs(err).sum(axis=1))
    return np.array([F(int(vv[i,i]+shift),SCALE**2) for i in range(len(s))],dtype=object),F(int(shift),SCALE**2)


def strict_pd(mat):
    # A rounded Cholesky factor supplies an exact Gram matrix. Its
    # remainder is positive definite by strict diagonal dominance.
    a=np.asarray(mat,dtype=float)
    least=eigh(a,eigvals_only=True,subset_by_index=(0,0))[0]
    if least<=0:return False
    try: l=quantize(np.linalg.cholesky(a-np.eye(len(a))*(.4*least)))
    except np.linalg.LinAlgError:return False
    gram=l@l.T
    for i in range(len(a)):
        diag=mat[i,i]-F(int(gram[i,i]),SCALE**2)
        off=sum(abs(mat[i,j]-F(int(gram[i,j]),SCALE**2)) for j in range(len(a)) if i!=j)
        if diag<=off:return False
    return True


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('fit',type=Path)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--energies',type=Path,help='Reuse witnesses on another frozen profile with identical sector permissions.')
    a=p.parse_args()
    fit=json.loads(a.fit.read_text())
    from hashlib import sha256
    if 'best_sdp' in fit:
        sol=fit['best_sdp'];sample=np.load(HERE/fit['input'])
        assert sha256((HERE/fit['input']).read_bytes()).hexdigest()==fit['input_sha256']
        ctrl,mass,raw=exact_data(fit,sample)
    else:
        sol=fit;ctrl=json.loads((HERE/fit['source']).read_text(),parse_float=Decimal)
        if fit.get('permissions'):apply_permissions(ctrl,HERE/fit['permissions'])
        mass=F(1);raw=np.array([[F(x) for x in row] for row in ctrl['sector_energies']],dtype=object)
    groups=sol['groups'];resolved=sol['resolved'];n=len(groups)
    if a.energies:
        assert 'best_sdp' not in fit
        new=json.loads(a.energies.read_text(),parse_float=Decimal)
        assert new['base_control']==fit['source']
        assert new['base_control_sha256']==sha256((HERE/fit['source']).read_bytes()).hexdigest()
        if fit.get('permissions'):apply_permissions(new,HERE/fit['permissions'])
        assert all(new[key]==ctrl[key] for key in ('codes','sources','intervals','kappa_upper','prime_mask','minorant_mask'))
        updated=np.array([[F(x) for x in row] for row in new['sector_energies']],dtype=object)
        # The solver stores the dual in coordinates normalized by each
        # group's erasure norm. Transfer the same unnormalized dual.
        factor=np.sqrt([float(sum(updated[g,0])/sum(raw[g,0])) for g in groups])
        sol=dict(sol)
        for name in ('dual_prime','dual_exceptional','dual_minorant'):
            sol[name]=np.outer(factor,factor)*np.array(sol[name])
        ctrl,raw=new,updated
    ids=[*resolved,*[i for g in groups for i in g]]
    assert len(set(ids))==len(ids)
    omitted=sorted(set(range(len(raw)))-set(ids))
    error=sum(sum(abs(x) for x in raw[i]) for i in omitted)
    assert error<F(1,10**11)
    key=lambda name:np.array(ctrl[name],bool)
    p=key('prime_mask');m=key('minorant_mask')
    assert all(p[i,ids].all() for i in resolved)
    def groupmask(A):return np.array([[A[np.ix_(g,h)].all() for h in groups] for g in groups])
    p,m=groupmask(p),groupmask(m)
    e=np.array([raw[g].sum(axis=0) for g in groups],dtype=object)
    assert min(e.ravel())>0
    known=sum(raw[i,0] for i in resolved)
    d=np.array([F(float(x)) for x in np.sqrt(e[:,0].astype(float))],dtype=object)
    assert min(d)>0
    norm=1/(d*d)
    E,U,K=(e*norm[:,None]).T
    assert all(isinstance(v,F) for v in E) and isinstance(mass,F)
    L,M,R=(quantize(sol[t]) for t in ('dual_prime','dual_exceptional','dual_minorant'))
    for x,mask in [(L,p),(M,p&m),(R,m&~p)]:
        assert np.array_equal(x,x.T) and not np.any(x[~mask])
    dd=np.outer(d,d);dd_round=quantize(dd)
    assert max(np.abs(dd-dd_round*F(1,SCALE)).sum(axis=1))<=F(n,SCALE)
    # The integer diagonal retreat covers rounding the rank-one cost.
    retreat=np.diag(np.full(n,n,dtype=object))
    dp,sp=lower_factor(SCALE*(dd_round-retreat-L-R),U)
    db,sb=lower_factor(SCALE*(R-M),K)
    kl=F('.000093307088324061');ku=F('.000093307088324062')
    assert all(raw[i,1]>=raw[i,0] and raw[i,2]>=ku*raw[i,0] for i in resolved)
    drift=sum(E[i]*F(M[i,i]-R[i,i],SCALE) for i in range(n))
    lower=(known+min(kl*drift,ku*drift)+sum(E[i]*F(L[i,i]+R[i,i],SCALE)-U[i]*dp[i]-K[i]*db[i] for i in range(n)))/mass
    # An upper witness for the auxiliary minimization. Choose k strictly
    # within the published deficit interval and restore all linear identities.
    k=(kl+ku)/2
    def rational(x):return np.array([[F(int(v),SCALE) for v in row] for row in quantize(x)],dtype=object)
    P=rational(sol['primal_prime']);B=rational(sol['primal_exceptional'])
    I=np.diag(E);both=p&m;extra=m&~p
    P[p]=I[p];B[both]=k*I[both];B[extra]=(P-(1-k)*I)[extra]
    blend=F(1,10**6)
    while blend<=F(1,10):
        X=(1-blend)*P+blend*I;Y=(1-blend)*B+blend*k*I
        if all(strict_pd(x) for x in [X,np.diag(U)-X,Y,np.diag(K)-Y]):break
        blend*=4
    else:raise ArithmeticError('No strictly feasible upper witness found')
    assert np.all(X[p]==I[p]) and np.all((X-Y)[m]==(1-k)*I[m])
    upper=(known+sum((X*dd).ravel()))/mass
    assert lower<=upper
    out=dict(scope='Exact bounds for the specified finite compressed matrix problem on the stored cap energies. No enclosure of integrals or restoration.',
             fit=a.fit.name,fit_sha256=sha256(a.fit.read_bytes()).hexdigest(),
             n=n,lower_billionths=floor(lower*10**9),upper_billionths=ceil(upper*10**9),
             dual_integer_scale=SCALE,dual_diagonal_shifts=[str(sp),str(sb)],upper_blend=str(blend),
             omitted_sectors=omitted,total_absolute_omitted_table_entries=float(error),
             raw_mass=float(mass),used_deficit_interval=[str(kl),str(ku)])
    if a.energies:
        out.update(energy_table=a.energies.name,energy_sha256=sha256(a.energies.read_bytes()).hexdigest())
    a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))


if __name__=='__main__':
    main()
