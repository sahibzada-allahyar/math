"""Compare elliptic and elementary radial Fourier envelopes on the refitted H1 spline."""
import argparse
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path

import numpy as np
from scipy.linalg import eigh

from h1_boundary_pencil import evaluate
from h1_fit_pairing_sectors import uniform_weights
from h1_pairing_sectors import Sectors, trial_model
from h1_rectangle_cover import partition, sides, split_groups
from h1_sunrise import LIMIT, sunrise


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def envelopes(knots, degree):
    # B-spline control coefficients live at the Greville abscissae. A
    # multiplier below defines a new spline before a prime shift is erased.
    sites = np.array([np.mean(knots[i+1:i+degree+1]) for i in range(len(knots)-degree-1)])
    u = (sites-knots[0]) / (knots[-1]-knots[0])
    theta = 2*np.pi*u
    modes = np.array([np.ones_like(u), np.cos(theta), np.sin(theta)])
    response = sunrise(LIMIT*u)
    check = sunrise(LIMIT*u, order=64)
    assert np.max(abs(response-check)) < 1e-10
    fields = [np.ones_like(u), u, -np.log1p(-LIMIT*u/9), response/response[0]-1]
    return np.vstack([modes*field for field in fields])


def geometry(control_path):
    control = read(control_path)
    cells_path = control_path.with_name(control['cells'])
    piece_path = control_path.with_name(control['pieces'])
    assert digest(cells_path) == control['cells_sha256'] and digest(piece_path) == control['pieces_sha256']
    original = read(cells_path)
    bins = cells_path.with_name(original['cell_bins'])
    assert digest(bins) == original['cell_bins_sha256']
    with np.load(bins, allow_pickle=False) as archive:
        cells, step = archive['cells'], Fraction(str(archive['step']))
    inner,outer = sides(cells,read(piece_path)['pieces'],step,original['intervals'])
    parents,ids = partition(cells,inner,outer,control['coverage']['cuts'])
    parents,ids = split_groups(cells,parents,ids,control['targeted_splits'])
    np.testing.assert_array_equal(parents,control['parent_sectors'])
    caps = np.unique(cells[:,1])
    tables = [(cells[cells[:,1]==cap,3],ids[cells[:,1]==cap]) for cap in caps]

    def layout(cap, index):
        j = np.searchsorted(caps,cap)
        assert j < len(caps) and caps[j] == cap
        ends, groups = tables[j]
        assert ends[-1] >= index[-1]
        return groups[np.searchsorted(ends,index)]

    return control,original,layout


def best_direction(mass, form, keep, transform):
    if transform is None:
        space=np.eye(len(mass))[:,keep]
    else:
        # Represent the same subset of original envelopes in the integrated
        # orthogonal basis, including nonconsecutive subsets such as J alone.
        space,_=np.linalg.qr(transform[:,keep])
    gram = space.T@mass@space
    scale = np.sqrt(np.diag(gram))
    ev,v = eigh(gram/np.outer(scale,scale))
    selected = ev > 1e-11*ev[-1]
    basis = space@(v[:,selected]/(scale[:,None]*np.sqrt(ev[selected])))
    small = basis.T@form@basis
    _,v = eigh((small+small.T)/2)
    direction = basis@v[:,-1]
    direction *= np.sign(mass[0]@direction)
    return direction, int(sum(selected))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('control',type=Path)
    parser.add_argument('dual',type=Path)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--orthogonal',action='store_true',help='Separate nearly collinear envelopes before any integration.')
    parser.add_argument('--reuse',action='store_true',help='Re-evaluate the saved cross forms and verify their hashes.')
    parser.add_argument('--export',choices=['elementary','joint'])
    parser.add_argument('--table',type=Path,help='Normalized energies for the two-source finite verifier.')
    parser.add_argument('--spline',type=Path,help='Export the fitted spline for independent scalar integration.')
    args=parser.parse_args()
    if bool(args.export)!=bool(args.table or args.spline) or (args.export and not args.reuse):
        parser.error('Use --reuse --export ARM with --table or --spline.')
    control,original,layout = geometry(args.control)
    fit_path=args.control.with_name(original['trial_refit'])
    profile=read(fit_path)
    knots=np.array([float(Fraction(x)) for x in profile['shape_spec']['knots']])
    degree=profile['shape_spec']['degree']
    weights=envelopes(knots,degree)
    transform=None
    orthogonal=read(args.output).get('orthogonal_radial',False) if args.reuse else args.orthogonal
    if orthogonal:
        q,r=np.linalg.qr(weights.T)
        scale=np.sign(np.diag(r))*np.sqrt(len(weights[0]))
        assert np.min(abs(np.diag(r)))>1e-10
        transform=r/scale[:,None]
        stable=q.T*scale[:,None]
        np.testing.assert_allclose(transform.T@stable,weights,rtol=0,atol=2e-14)
        weights=stable
    original_coef=np.array(profile['coefficients']).reshape(3,-1,len(knots)-degree-1)
    profiles=[(original_coef*w).reshape(3,-1) for w in weights]
    inputs={f.name:digest(f) for f in (fit_path,args.control,args.dual)}
    archived=args.output.with_suffix('.npz')
    if args.reuse:
        previous=read(args.output)
        assert previous['inputs']==inputs and previous['forms_sha256']==digest(archived)
        with np.load(archived,allow_pickle=False) as z:
            mass,energies=z['mass'],z['energies']
    else:
        _,_,_,r,_,domains=trial_model(original['intervals'],fit_path.name)
        sec=Sectors(r,domains,[s['radius'] for s in original['sources']],original['max_radius'])
        limits=original['component_limits']
        data=[(i,Fraction(0),r.geometry['parameters']['S'],limits[-1]) for i in range(len(profiles))]
        mass,energies=evaluate(r,data,profiles,limits,sec,layout,len(control['codes']))
        np.savez_compressed(archived,mass=mass,energies=energies)
    baseline=np.array(control['sector_energies'])
    error=float(np.max(abs(energies[:,:,0,0]/mass[0,0]-baseline)))
    assert error<1e-10, error
    dual=read(args.dual)
    assert dual['source']==args.control.name
    prices=uniform_weights(baseline,dual,control['kappa_upper'])
    form=np.einsum('sk,skij->ij',prices,energies)
    arms={'frozen':[0],'fourier':[0,1,2],'linear_fourier':list(range(6)),
          'log_fourier':[0,1,2,6,7,8],'sunrise_fourier':[0,1,2,9,10,11],
          'elementary':list(range(9)),'joint':list(range(12))}
    records={}
    for name,keep in arms.items():
        v,rank=best_direction(mass,form,keep,transform)
        records[name]=dict(rank=rank,coefficients=v.tolist(),price_score=float((v@form@v)/(v@mass@v)))
    report=dict(scope='Fixed discovery prices on stored floating-point sector forms. No continuous error enclosure.',
                inputs=inputs,forms_sha256=digest(archived),baseline_max_discrepancy=error,arms=records)
    if orthogonal:
        report['orthogonal_radial']=True
    if args.reuse:
        assert error==previous['baseline_max_discrepancy']
        for name,row in records.items():
            assert abs(row['price_score']-previous['arms'][name]['price_score'])<1e-10
    else:
        args.output.write_text(json.dumps(report,indent=2)+'\n')
    if args.export:
        v=np.array(read(args.output)['arms'][args.export]['coefficients'])
        provenance=dict(fit_report=args.output.name,fit_report_sha256=digest(args.output),arm=args.export)
        if args.table:
            data={key:control[key] for key in ('codes','intervals','sources','kappa_upper','prime_mask','minorant_mask')}
            data.update(provenance,base_control=args.control.name,base_control_sha256=digest(args.control),
                        sector_energies=((v@energies@v)/(v@mass@v)).tolist())
            args.table.write_text(json.dumps(data,separators=(',',':'))+'\n')
        if args.spline:
            data={key:profile[key] for key in ('shape_spec','radius','intervals','fragment_cap','flat','extra_knots')}
            data.update(provenance,coefficients=(v@np.stack(profiles).reshape(len(v),-1)).tolist())
            args.spline.write_text(json.dumps(data,indent=1)+'\n')
    print({name:row['price_score'] for name,row in records.items()},flush=True)


if __name__=='__main__':
    main()
