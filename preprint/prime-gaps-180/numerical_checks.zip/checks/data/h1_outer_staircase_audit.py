"""Optimize every cross contraction on the remaining nested neighborhoods of the frozen trial."""
import argparse
from fractions import Fraction as Q
import json
from itertools import combinations_with_replacement, product
from math import isqrt, lcm
from pathlib import Path

import numpy as np

from h1_graded_coverage import provenance
from h1_graded_cross_block import native_layout
from h1_outer_matching import OBSTRUCTION,RES,maximize
from h1_raw_diagonal_bound import CERT,FIBRES,FIT,NORM,UNIT,ceil,digest,geom,mixture_energies,read,sci_upper
from h1_strip_free_prices import FORMS

BASE=Path('h1_graded_fine_coverage.json')
STAIRS=Path('h1_sparse_grade_paths.json')
BANDS=[Path('h1_outer_band_'+s+'.json') for s in
       ('251_263','251_2525_2625','2525_254_261','254_2555_260')]
PATCH=Path('h1_outer_matching_patch.json')
SECOND_PATCH=Path('h1_outer_matching_alternative.json')
OUTPUT=Path('h1_outer_staircase_audit.json')


def root_range(a,b,scale):
    t=4*a*b*RES**2
    v=isqrt(t)//scale
    return v,v+int((v*scale)**2<t)


def best_contraction(mask,a,b,scale,witness=False):
    # Neighborhoods are nested. Order rows from the fewest eligible columns
    # to the most. Columns in earlier neighborhoods can be used by later rows.
    ix=np.argsort(mask.sum(axis=1),kind='stable')
    cells=mask[ix]
    assert not np.any(cells[:-1] & ~cells[1:])
    pools=[]
    previous=0
    prefix=[]
    for i,row in zip(ix,cells):
        budget=sum(b[j] for j in np.flatnonzero(row))
        pools.append(([int(i)],a[i],budget-previous))
        previous=budget
        prefix.append(budget)
        while len(pools)>1:
            u,A,B=pools[-2]
            v,X,Y=pools[-1]
            if B*X<=Y*A:break
            pools[-2:]=[(u+v,A+X,B+Y)]
    roots=[root_range(A,B,scale) for _,A,B in pools]
    low,high=map(sum,zip(*roots))
    if not witness:return low,high,None
    target=[Q(0)]*len(a)
    for group,A,B in pools:
        for i in group:target[i]=Q(a[i]*B,A)
    running=Q(0)
    for i,budget in zip(ix,prefix):
        running+=target[i]
        assert running<=budget
    assert running==prefix[-1]
    # A transport realizes all the target squared row norms. Each positive
    # edge exhausts its row or column. Verify admissibility and exact marginals.
    cols=np.argsort(-mask.sum(axis=0),kind='stable')
    available=[Q(v) for v in b]
    cursor=0
    flows=[]
    for i in ix:
        remaining=target[i]
        while remaining:
            j=int(cols[cursor])
            assert mask[i,j] and available[j]>0
            used=min(remaining,available[j])
            flows.append((int(i),j,used))
            remaining-=used
            available[j]-=used
            if not available[j]:cursor+=1
    assert len(flows)<=len(a)+len(b)-1
    rows=[Q(0)]*len(a);columns=[Q(0)]*len(b)
    for i,j,v in flows:
        rows[i]+=v
        columns[j]+=v
    assert rows==target and all(v<=c for v,c in zip(columns,b))
    return low,high,dict(pools=[dict(rows=g,left=str(A),available=str(B)) for g,A,B in pools],
                         flows=[[i,j,str(v)] for i,j,v in flows])


def direct_checks():
    a,b=[2,3,1],[1,2,3]
    count=0
    # Enumerate squared output masses in a three-row example, independently
    # of the pooling and transport. Include empty and repeated neighborhoods.
    for widths in combinations_with_replacement(range(4),3):
        mask=np.array([[j<k for j in range(3)] for k in widths])
        bounds=[sum(b[:k]) for k in widths]
        _,upper,_=best_contraction(mask,a,b,1,True)
        for v in product(range(sum(b)+1),repeat=3):
            if any(sum(v[:i+1])>q for i,q in enumerate(bounds)):continue
            score=sum(root_range(h,m,1)[0] for h,m in zip(v,a))
            assert score<=upper
            count+=1
    return count


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    prior,cert,fibres,norm,base,stairs=map(read,(OBSTRUCTION,CERT,FIBRES,NORM,BASE,STAIRS))
    for f in (CERT,FIBRES,NORM,FIT,FORMS,FORMS.with_suffix('.npz')):
        assert prior['inputs'][f.name]==digest(f)
    provenance(base,Path.cwd());provenance(stairs,Path.cwd())
    x,y=[np.array(prior['frozen_full'][k],int) for k in ('left_groups','right_groups')]
    _,last,top,_=native_layout(fibres,cert)
    tick=Q(norm['step'])*geom.RHO*UNIT
    radius=np.array([int(ceil((int(v)+37)*tick)) for v in last])
    sums=radius[x,None]+radius[None,y]
    raw=mixture_energies(FORMS,FIT)
    ideal=sum(raw[:,0])
    e=[sum(raw[g,0]) for g in cert['groups']]
    scale=lcm(*(q.denominator for q in e))
    a,b=[[int(scale*e[i]) for i in group] for group in (x,y)]
    threshold=(ideal-1)*RES
    gain_bounds=[np.array([[root_range(v,w,scale)[j] for w in b] for v in a],np.int64) for j in (0,1)]
    paths=[Path(__file__),OBSTRUCTION,CERT,FIBRES,NORM,FIT,FORMS,FORMS.with_suffix('.npz'),
           BASE,STAIRS,*BANDS,PATCH,SECOND_PATCH,Path('h1_outer_matching.py'),Path('h1_graded_cross_block.py')]
    allowed=np.ones(sums.shape,bool)
    cost=Q(stairs['combined_upper_by_max_intervals_per_rectangle']['38'])
    identifiable=np.any(np.asarray(cert['affine'][:3],np.int64)[:,x[:,None],y]!=0,axis=0)
    audit=[]
    def append(name,allowance):
        lo,hi,w=best_contraction(allowed,a,b,scale,True)
        wu,pairs=maximize(np.where(allowed,gain_bounds[1],0),len(x))
        wl=sum(int(gain_bounds[0][i,j]) for i,j in pairs)
        audit.append(dict(after=name,covered_new_ordered_pairs=2*int((~allowed).sum()),
                          covered_new_active_ordered_pairs=2*int((~allowed&identifiable).sum()),
                          unresolved_active=base['unresolved_ordered_pairs']-2*int((~allowed&identifiable).sum()),
                          combined_error_upper=sci_upper(allowance),best_disjoint_gain_numerators=[wl,wu],
                          best_cross_gain_numerators=[lo,hi],
                          adverse_score_upper_trillionths=int(ceil((ideal-Q(lo,RES))*10**12)),
                          matched_score_lower_trillionths=int((ideal-Q(wu,RES))*10**12),
                          sparse_flow_edges=len(w['flows'])))
        return w
    append('original_square_and_two_crosses',cost)
    for i,path in enumerate([*BANDS,PATCH,SECOND_PATCH]):
        row=read(path);provenance(row,Path.cwd())
        assert row['inputs'][BASE.name]==digest(BASE)
        left,right=row['left_groups'],row['right_groups']
        mask=np.isin(x,left)[:,None]&np.isin(y,right)[None,:]
        assert set(left)<=set(x) and set(right)<=set(y)
        assert row['ordered_pairs']==2*int(mask.sum()) and not (mask&~allowed).any()
        cost+=Q(row['charge_upper'])
        allowed&=~mask
        if i>=len(BANDS)-1:
            witness=append(path.name,cost)
    assert audit[1]['best_disjoint_gain_numerators'][0]>threshold>audit[2]['best_disjoint_gain_numerators'][1]
    def threshold_for(subject):
        ticks=sorted(set(map(int,sums.flat)))
        def run(v):
            return best_contraction((sums>v)|~subject,a,b,scale)[:2]
        if run(ticks[-1])[0]>threshold:
            return dict(status='obstruction persists at all radius sums',gain_numerators=run(ticks[-1]))
        lo,hi=0,len(ticks)-1
        assert run(ticks[lo])[0]>threshold and run(ticks[hi])[1]<threshold
        while hi-lo>1:
            mid=(lo+hi)//2
            l,u=run(ticks[mid])
            if l>threshold:lo=mid
            else:
                assert u<threshold
                hi=mid
        return dict(first_nonobstructed_cutoff=ticks[hi],before=run(ticks[hi]-1),after=run(ticks[hi]))
    cutoffs={name:threshold_for(mask) for name,mask in (
        ('all_fragments',np.ones_like(allowed)),('right_native_cap_47317',np.broadcast_to(top[None,y]<=47317,allowed.shape)))}
    result=dict(scope='Continuous raw charges for the original trial on explicitly disjoint blocks. Separate sharp adverse scores only in the finite relaxation on the specified outer cross, granting every other entry exactly.',
                inputs={p.name:digest(p) for p in paths},gain_scale=RES,energy_denominator=str(scale),
                left_groups=x.tolist(),right_groups=y.tolist(),audit=audit,radius_cutoff_tests=cutoffs,
                final_contraction_witness=witness,enumerated_small_norm_assignments=direct_checks())
    result=json.loads(json.dumps(result))
    if args.check:assert result==read(OUTPUT)
    else:OUTPUT.write_text(json.dumps(result,indent=2)+'\n',newline='\n')
    for row in audit:
        print(row['after'],row['covered_new_ordered_pairs'],row['combined_error_upper'],
              row['matched_score_lower_trillionths'],row['adverse_score_upper_trillionths'],flush=True)
    print('cutoff tests',cutoffs,flush=True)


if __name__=='__main__':main()
