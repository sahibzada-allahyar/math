"""Verify additional prime and minorant rectangles independently of any self-source."""
import argparse
from fractions import Fraction as Q
from hashlib import sha256
from math import ceil
import json
from pathlib import Path
import numpy as np
from h1_geometry_scan import geometry as geom
from h1_pairing_sectors import HERE,Sectors,trial_model


def max_cells(sec):
    # Each entry is the last possible retained cell for a sector and a
    # largest-fragment class. Empty intersections have no containment cost.
    out=np.full((sec.n,len(sec.caps)),-1,np.int64)
    for j,row in enumerate(sec.index):
        np.maximum.at(out[:,j],row,np.arange(len(row)))
    return out


def address(rows,step,sec,last,d):
    # For an old cell vector the sum of new-grid indices is bounded
    # by its total of old upper ends divided by the new step. Work inward.
    limit=np.array([max([int(Q(t['index_last'])*step)-d for t in rows
                         if cap<=Q(t['cap_index'])*step]+[-1]) for cap in sec.caps])
    return np.all(last<=np.maximum(limit,-1),axis=1)


def rectangle(name,budget,physical,switch,plateau,sec,r,last,engine=geom,first=None,pieces=None):
    S=physical/engine.RS;T=budget/engine.RHO-S;h=S/r.N
    assert T>0 and (T<=S or abs(T-S)<Q(1,10**8))
    full=engine.make_ladder(name,S,T,h,r.k,r.N,switch,plateau)
    kept=[row for row in full if row['retained']]
    assert kept[0]['B']==Q(1,2)/engine.RHO and all(a['Bplus']==b['B'] for a,b in zip(kept,kept[1:]))
    blocks=[];overlap=[]
    for side,rad in [('outer',S),('inner',T)]:
        rows=engine.cell_masks(rad,kept,side,r.k-1,r.k,r.N,h)
        if pieces is not None:
            pieces[side]=[[int(Q(t['cap_index'])*h/r.exact_step),int(Q(t['index_last'])*h/r.exact_step)-(r.k-1)] for t in rows]
        assert rows[0]['index_first']==0 and all(a['index_last']+1==b['index_first'] and a['cap_index']>=b['cap_index'] for a,b in zip(rows,rows[1:]))
        blocks.append(address(rows,h/r.exact_step,sec,last,r.k-1))
        if first is not None:
            # If even the lower fragment endpoint or lower radial endpoint
            # is outside, no point in this cap-sector intersection qualifies.
            # Allow extra cells on both grids in the outward comparison.
            ratio=h/r.exact_step;bottom=np.r_[0,sec.caps[:-1]]
            upper=np.array([max([ceil((t['index_last']+2*r.k)*ratio)+2*r.k for t in rows
                                if b<=ceil((t['cap_index']+2)*ratio)+2]+[-1]) for b in bottom])
            overlap.append(np.any(first<=upper,axis=1))
    mask=blocks[0][:,None]&blocks[1]
    if first is not None:
        generous=overlap[0][:,None]&overlap[1];generous|=generous.T.copy()
        assert np.all(~(mask|mask.T)|generous)
        return mask|mask.T,len(kept),generous
    return mask|mask.T,len(kept)


def control_geometry(data):
    if 'edge_trial' in data:
        from h1_wide_pair_sectors import model
        path=HERE/data['edge_trial']
        assert sha256(path.read_bytes()).hexdigest()==data['edge_trial_sha256']
        _,_,r,_,dom=model(json.loads(path.read_text()),data['intervals'])
    else:
        _,_,_,r,_,dom=trial_model(data['intervals'],data.get('trial_refit'))
    return r,dom


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('control',type=Path)
    p.add_argument('--spacing',type=int,default=10,help='outer radius increment in units of 1e-4')
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--pieces',type=Path,help='Record the two inward side masks for every passing arithmetic source.')
    a=p.parse_args();data=json.loads(a.control.read_text());r,dom=control_geometry(data)
    sec=Sectors(r,dom,[d['radius'] for d in data['sources']],data['max_radius'])
    assert sec.codes==data['codes'];last=max_cells(sec)
    p0=np.array(data['prime_mask'],bool);b0=np.array(data['minorant_mask'],bool)
    receipts=[];tested=rejected=0;pieces=[]
    for name,budgets,mask in [('old',['.524997','.521','.516','.508'],p0),('new',['.528399','.525','.520','.512'],b0)]:
        for budget in map(Q,budgets):
            start=budget*geom.RS/(2*geom.RHO)
            radii={start}|{Q(i,10000) for i in range(2500,2910,a.spacing) if Q(i,10000)>start}
            for physical in sorted(radii):
                for switch,plateau in [((12,24),'capped_balance' if name=='old' else '23/40'),((0,0),'capped_balance')]:
                    tested+=1
                    try:
                        part={} if a.pieces else None
                        add,kept=rectangle(name,budget,physical,switch,plateau,sec,r,last,pieces=part)
                    except geom.GeometryError:
                        rejected+=1
                        continue
                    count=int(np.triu(add&~mask).sum())
                    if part is not None:pieces.append(dict(source=name,budget=str(budget),outer_radius=str(physical),
                                                           switch=switch,plateau=plateau,**part))
                    if count:
                        mask|=add
                        receipts.append(dict(source=name,budget=str(budget),physical_outer=str(physical),
                                             switch=switch,plateau=plateau,retained_rows=kept,new_pairs=count))
    # Store masks as row strings to keep the standalone permission file compact.
    out=dict(status='ARITHMETIC_LADDERS_CHECKED_CAP_SECTOR_PERMISSIONS_REQUIRE_RESTORATION',
             control=a.control.name,control_sha256=sha256(a.control.read_bytes()).hexdigest(),tested=tested,
             rejected=rejected,added_ladders=receipts,prime=[''.join(map(str,row.astype(int))) for row in p0],
             minorant=[''.join(map(str,row.astype(int))) for row in b0])
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    if a.pieces:
        a.pieces.write_text(json.dumps(dict(receipt=a.output.name,receipt_sha256=sha256(a.output.read_bytes()).hexdigest(),
                                            pieces=pieces),indent=1)+'\n')
    print(json.dumps(dict(tested=tested,rejected=rejected,useful=len(receipts),
                          prime_added=sum(x['new_pairs'] for x in receipts if x['source']=='old'),
                          minorant_added=sum(x['new_pairs'] for x in receipts if x['source']=='new'))))


def apply_permissions(control,path):
    data=json.loads(path.read_text())
    assert sha256((HERE/data['control']).read_bytes()).hexdigest()==data['control_sha256']
    original=json.loads((HERE/data['control']).read_text())
    assert original['codes']==control['codes'] and original['intervals']==control['intervals'] and original['sources']==control['sources']
    for target,key in [('prime_mask','prime'),('minorant_mask','minorant')]:
        mask=np.array([[x=='1' for x in row] for row in data[key]],bool)
        assert np.array_equal(mask,mask.T) and np.all(~np.array(control[target],bool)|mask)
        control[target]=mask.tolist()


def verify_receipt(path):
    receipt=json.loads(path.read_text());control=json.loads((HERE/receipt['control']).read_text())
    apply_permissions(dict(control),path)
    r,dom=control_geometry(control)
    sec=Sectors(r,dom,[s['radius'] for s in control['sources']],control['max_radius'])
    last=max_cells(sec);masks={name:np.array(control[key],bool) for name,key in
                               [('old','prime_mask'),('new','minorant_mask')]}
    for row in receipt['added_ladders']:
        mask=masks[row['source']]
        add,n=rectangle(row['source'],Q(row['budget']),Q(row['physical_outer']),
                        tuple(row['switch']),row['plateau'],sec,r,last)
        assert n==row['retained_rows'] and int(np.triu(add&~mask).sum())==row['new_pairs']
        mask|=add
    for tag,key in [('old','prime'),('new','minorant')]:
        assert [''.join(map(str,row.astype(int))) for row in masks[tag]]==receipt[key]
    return len(receipt['added_ladders'])


if __name__=='__main__':
    import sys
    if len(sys.argv)==3 and sys.argv[1]=='--verify':
        print(json.dumps(dict(verified_added_ladders=verify_receipt(Path(sys.argv[2])))))
    else:
        main()
