"""Construct mixed rectangles for the triple-and-five-prime minorant with the Type I/II row tests."""
import argparse
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
import json
from pathlib import Path
import numpy as np
from h1_cross_ladders import control_geometry,max_cells,rectangle
from h1_distribution_frontier import parametric
from h1_pairing_sectors import Sectors


def weak_engine(book,level,cap):
    rec=next(row for row in book['rows'] if Q(row['theta'])==level);a,I=map(Q,(rec['a'],rec['I']))
    assert cap<Q(rec['rough']) and Q(book['bilinear_handoff'])==Q('.46')
    # c is unused by all the retained arithmetic and geometric functions.
    engine=parametric._private_engine(a,I,Q('.4'),(level-Q(1,2))/2,cap)
    original=engine.fixed.new_input_slacks
    def weak_guards(order,w,delta):
        slack=original(order,w,delta)
        del slack['finite_III_main'],slack['finite_III_secondary']
        if order==3:
            step=Q('.46')-Q('.45')
            for k,slope in [('incidence_upper',-1),('incidence_Farey',-2),('handoff_Polymath',4),('witness_u_lower',-1)]:
                slack[k]+=slope*step
        slack.update(overlap1=1-64*w-16*delta,overlap2=2-112*w-41*delta)
        return slack
    engine.fixed.new_input_slacks=weak_guards
    return engine


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('control',type=Path);p.add_argument('minorants',type=Path)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--level',default='.5291')
    p.add_argument('--cap',default='.1668');p.add_argument('--spacing',type=int,default=10);p.add_argument('--pieces',type=Path);args=p.parse_args()
    level=Q(args.level);cap=Q(args.cap);book=json.loads(args.minorants.read_text())
    engine=weak_engine(book,level,cap)
    ctrl=json.loads(args.control.read_text());r,dom=control_geometry(ctrl)
    sec=Sectors(r,dom,[d['radius'] for d in ctrl['sources']],ctrl['max_radius'])
    assert sec.codes==ctrl['codes'];last=max_cells(sec);mask=np.zeros((sec.n,sec.n),bool);reject=Counter();receipts=[];passed=0
    first=np.full(last.shape,10**9,dtype=np.int64);outer=mask.copy();allpieces=[]
    for j,indices in enumerate(sec.index):np.minimum.at(first[:,j],indices,np.arange(len(indices)))
    for budget in (level-Q('.000001'),Q('.5283'),Q('.526'),Q('.523'),Q('.518'),Q('.51')):
        start=budget*engine.RS/(2*engine.RHO)
        for phys in sorted({start}|{Q(i,10000) for i in range(2520,2881,args.spacing) if Q(i,10000)>start}):
            for sw,plateau in [((12,24),'23/40'),((0,0),'capped_balance')]:
                pieces={} if args.pieces else None
                try:block,n,possible=rectangle('new',budget,phys,sw,plateau,sec,r,last,engine,first,pieces)
                except engine.GeometryError as exc:
                    reject[str(exc).split(': ')[-1]]+=1;continue
                passed+=1;added=int(np.triu(block&~mask).sum());outer|=possible
                if pieces is not None:allpieces.append(dict(budget=str(budget),outer_radius=str(phys),switch=sw,plateau=plateau,**pieces))
                if added:
                    mask|=block;receipts.append(dict(budget=str(budget),outer=str(phys),switch=sw,plateau=plateau,rows=n,added=added))
    digest=lambda f:sha256(f.read_bytes()).hexdigest()
    out=dict(scope='Checked mixed-row geometric and Type I/II scale permissions for cap proxies. Full divisor predicates and their restoration are still required.',
             control=args.control.name,control_sha256=digest(args.control),minorants_sha256=digest(args.minorants),
             level=args.level,cap=str(cap),spacing=args.spacing,passed=passed,rejections=dict(reject),receipts=receipts,
             mask=[''.join(map(str,row.astype(int))) for row in mask],pairs=int(np.triu(mask).sum()),
             outward_mask=[''.join(map(str,row.astype(int))) for row in outer],outward_pairs=int(np.triu(outer).sum()))
    args.output.write_text(json.dumps(out,indent=2)+'\n');print('accepted',passed,'rejected',sum(reject.values()),'pairs',out['pairs'])
    if args.pieces:args.pieces.write_text(json.dumps(dict(ladders=args.output.name,ladders_sha256=digest(args.output),pieces=allpieces),indent=1)+'\n')


if __name__=='__main__':main()
