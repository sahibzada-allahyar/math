"""Exact normalized charge for the first marked continuum gate of B=2."""
import argparse
from fractions import Fraction as Q
import json
from math import ceil,comb,factorial
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np

from h1_degree6_b2_gate_reachability import Gates
from h1_signed_gate_fibre import rebuild


def except_largest(n,x):
    """CDF for the sum of the smallest n-1 among n independent U[0,1]."""
    x=Q(x)
    if n<2:
        raise ValueError('At least two variables are required.')
    if x<=0:
        return Q(0)
    if x>=n-1:
        return Q(1)
    # Conditional on the maximum m, the other n−1 draws are uniform on
    # [0,m]. Integrate their Irwin–Hall CDF against n*m**(n−1) dm.
    total=n*x**(n-1)
    for k in range(1,n):
        total+=(-1)**k*comb(n-1,k)*(x**n-max(x-k,0)**n)/k
    return total/factorial(n-1)


def check(path):
    g=Gates(path)
    assert tuple(map(int,g.edges[:2]))==(1,100)
    # g.tile and g.verify check the sector, all possible rounded radial
    # lookups, and ceil((j+38)*tau) <= R[retained_class,sector] directly.
    stats=g.verify()
    count=0
    for i in range(len(g.fine)):
        j,keys,_=g.tile(i)
        radial=g.R[i,g.group[i][j]]
        for key in keys:
            assert np.all(g.gates[key,0]>=radial-200)
        count+=len(j)
    assert count==stats['reachable_retained_pairs']==3359637
    for x in (Q(1,4),Q(1,2),Q(3,4)):
        assert except_largest(2,x)==1-(1-x)**2
        assert except_largest(3,x)==3*x*x/2-3*x**3/4
    assert except_largest(38,0)==0 and except_largest(38,37)==1
    x=200/g.tick
    bound=except_largest(38,x)
    numerator_upper=ceil(10**15*bound)
    assert numerator_upper==197713714
    return dict(scope='Outward upper on first-edge deletion mass divided by full B=2 continuum profile mass.',
                covered_retained_pairs=count,edge_ticks=[1,100],native_width_ticks=str(g.tick),
                sum_deficit_in_cell_widths=str(x),nonowner_sites=38,
                exact_order_statistic_probability=str(bound),
                normalized_upper=str(Q(numerator_upper,10**15)))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--gates',type=Path)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    with TemporaryDirectory() as tmp:
        result=check(args.gates or rebuild(Path(tmp)))
    text=json.dumps(result,indent=2)+'\n'
    if args.output:
        args.output.write_text(text)
    print(text,end='')
