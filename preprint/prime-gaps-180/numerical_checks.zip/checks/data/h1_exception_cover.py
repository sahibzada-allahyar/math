"""Global fractional covers by marked primes or prime pairs on the exceptional products."""
import argparse
import json
from fractions import Fraction as Q
from itertools import combinations, combinations_with_replacement
from math import ceil, floor
from pathlib import Path

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix

OLD = Q('.41361')
PAD = Q('0.000001')
RETREAT = Q('.0001')
UNIT = 10**9


def region(kind, new, zeta, bins):
    three = kind == 'three'
    a = OLD if kind == 'old' else new
    lo = zeta if three else 1-2*a
    hi = a if three else (4*a-1)/3
    step = (hi-lo)/bins
    m = 3 if three else 5
    mins = ceil((1-m*lo)/step)-m
    maxs = floor((1+PAD-m*lo)/step)
    pair_max = floor((a-2*lo)/step)
    pair_min = ceil((OLD-2*lo)/step)-2
    configs = []
    for prefix in combinations_with_replacement(range(bins),m-1):
        bottom = max(prefix[-1],mins-sum(prefix))
        top = min(bins-1,maxs-sum(prefix))
        if not three:
            top = min(top,pair_max-prefix[-1])
        if kind=='increment':
            bottom = max(bottom,pair_min-prefix[-1])
        configs.extend((*prefix,j) for j in range(bottom,top+1))
    configs = np.asarray(configs,int)
    if three:
        labels = [(i,) for i in range(bins)]
        marks = configs
    else:
        labels = list(combinations_with_replacement(range(bins),2))
        ids = np.zeros((bins,bins),int)
        for i,(l,r) in enumerate(labels):
            ids[l,r] = i
        marks = np.stack([ids[configs[:,i],configs[:,j]] for i,j in combinations(range(m),2)],axis=1)
    return a,lo,step,labels,marks


def harmonic_rows(kind,new,zeta,bins):
    a,lo,step,labels,marks = region(kind,new,zeta,bins)
    # Exact positive upper masses on the prime-log exponent rectangles.
    positive = lambda v:max(Q(0),v)
    masses, ends = [], []
    for label in labels:
        l = lo+step*label[0]
        if len(label)==1:
            area = step/l
            end = l+step
        else:
            r = lo+step*label[1]
            x = a-l-r
            clipped = (positive(x)**2-2*positive(x-step)**2+positive(x-2*step)**2)/2
            area = clipped/(l*r*(1+(label[0]==label[1])))
            end = min(a,l+r+2*step)
        masses.append(area)
        ends.append(end)
    return lo,masses,ends,marks


def compact_weights(rows, weights):
    lo,masses,ends,_ = rows
    retained = {}
    for mass,end,w in zip(masses,ends,weights):
        if w and mass:
            retained[end] = retained.get(end,Q(0))+int(w)*mass/UNIT
    return lo,retained


def kernel_at(compact,q):
    lo,mass=compact
    total=Q(0)
    for end,term in mass.items():
        z=min(lo,(1-end)/2-q)-RETREAT
        assert z>0
        total+=ceil(10**12*term/z)
    return Q(total,10**12)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bins',type=int,default=32)
    p.add_argument('--q',type=Q,default=Q('.265'))
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--check',action='store_true')
    args=p.parse_args()
    src=Path('../sensitivity/bilinear_minorant.json')
    from h1_sunrise_boundary import digest
    row=next(r for r in json.loads(src.read_text())['rows'] if Q(r['theta'])==Q('.5291'))
    new,zeta=Q(row['a']),Q(row['zeta'])
    old=json.loads(args.output.read_text()) if args.check else None
    out=dict(source_sha256=digest(src),a=str(new),zeta=str(zeta),old=str(OLD),bins=args.bins,
             discovery_radius=str(args.q),logarithmic_padding=str(PAD),weight_scale=UNIT,covers={})
    for kind in ('old','three','new','increment'):
        rows=harmonic_rows(kind,new,zeta,args.bins)
        lo,masses,ends,marks=rows
        target=2 if kind=='three' else 24
        if old:
            w=np.array(old['covers'][kind]['weights'],np.int64)
        else:
            cost=np.array([float(m/(min(lo,(1-t)/2-args.q)-RETREAT)) if m else 0. for m,t in zip(masses,ends)])
            # Identical mark columns in a row include their multiplicity.
            n,width=marks.shape
            matrix=csr_matrix((np.ones(marks.size),marks.ravel(),np.arange(n+1)*width),shape=(n,len(cost)))
            fit=linprog(cost,A_ub=-matrix,b_ub=np.full(n,-target),bounds=(0,target),method='highs')
            assert fit.success, fit.message
            w=np.ceil(UNIT*np.maximum(0,fit.x)).astype(np.int64)
            deficit=target*UNIT-w[marks].sum(axis=1).min()
            if deficit>0:
                w+=ceil(int(deficit)/width)
        assert len(w)==len(masses) and 0<=w.min() and w.max()<=(target+1)*UNIT
        coverage=w[marks].sum(axis=1)
        assert coverage.min()>=target*UNIT
        compact=compact_weights(rows,w)
        vals={str(q):str(kernel_at(compact,q)) for q in map(Q,('.2','.24','.25','.26','.265','.27','.28'))}
        out['covers'][kind]=dict(configurations=len(marks),minimum_scaled_coverage=int(coverage.min()),
                                 positive_weights=int(np.count_nonzero(w)),weights=w.tolist(),upper_at=vals)
        print(kind,len(marks),np.count_nonzero(w),float(Q(vals[str(Q('.265'))])),flush=True)
    if old:
        assert old==out
    else:
        args.output.write_text(json.dumps(out,indent=1)+'\n')


if __name__=='__main__':
    main()
