"""Propose and verify independent retained-class intercepts and erased-share slopes."""

from fractions import Fraction as Q
from math import sqrt
from bare_index_singles import CAPS, ceilq

ROLES = ('core', 'a')
MULTIPLICITIES = (37, 2)
ALPHA = Q(1373, 2000)
B2_LIMITS = ((47096,130964),(60089,130825),(61104,129997),(63177,125536),
             (64599,124707),(65536,123370),(78116,117732))


def alternatives(row):
    return [row] if len(row) == 3 and isinstance(row[1], dict) else list(row)


def geometry_bounds(n):
    if n != len(CAPS):
        return [True]*n, {(f,c):(Q(0),Q(1)) for f in range(n) for c in range(f)}
    last = [next(j for cap,j in B2_LIMITS if cap >= end) for end in CAPS]
    low = [0, *CAPS[:-1]]
    equal = [2*lo <= hi for lo,hi in zip(low,last)]
    bounds = {(f,c):(Q(low[f],last[f]),1-Q(low[c],last[f]))
              for f in range(n) for c in range(f) if low[f]+low[c] <= last[f]}
    return equal,bounds


def full_coefficients(a, b):
    """At most one retained maximum group is strictly below the full one."""
    n = len(a[0])
    equal,bounds = geometry_bounds(n)
    result = []
    for f in range(n):
        usual = max(row[f] for row in b)
        options = [usual] if equal[f] else []
        for r in range(len(a)):
            for c in range(f):
                if (f,c) in bounds:
                    price = max((1-v)*usual+v*b[r][c] for v in bounds[f,c])
                    options.append(a[r][c] - a[r][f] + price)
        extra = max(options)
        result.append(sum(mult * row[f] for mult, row in zip(MULTIPLICITIES, a)) + extra)
    return result


def group_price(d, schur, z, mode):
    uniform = (2 - ALPHA + z) * d
    weighted = schur + max(0, z - ALPHA) * d
    if mode == 'cross':
        return z * d
    if mode == 'uniform':
        return uniform
    if mode == 'schur':
        return weighted
    if mode == 'mixed':
        return min(uniform, weighted)
    raise ValueError('Unknown charge mode')


def exact_charge(mass, schur, rows, a, b, mode='mixed'):
    """Raw upper on the twice cross and the specified ordinary/Schur terms."""
    assert len(mass) == len(schur) == len(CAPS) and set(rows) <= set(CAPS)
    assert all(len(role) == len(CAPS) for table in (a,b) for role in table)
    assert all(z >= 0 for seq in (mass, schur, *a, *b) for z in seq)
    total = Q(0)
    for c, cap in enumerate(CAPS):
        if cap not in rows:
            assert all(table[r][c] == 0 for table in (a,b) for r in range(2))
            continue
        for r, (role, mult) in enumerate(zip(ROLES, MULTIPLICITIES)):
            assert a[r][c] > 0
            costs = []
            for t, vals, _ in alternatives(rows[cap]):
                assert len(t) == len(vals[role]) and all(0 <= s <= 1 for s in t)
                costs.append(ceilq(sum(v / (a[r][c] + b[r][c] * (1-s))
                                       for s,v in zip(t, vals[role]))))
            total += mult * min(costs)
    return total + sum(group_price(d, n, z, mode) for d,n,z in zip(mass, schur, full_coefficients(a,b)))


def propose(mass, schur, rows, mode='mixed'):
    """Return two rational (core,endpoint) × ascending CAPS arrays, a and b.

    Input rows are the cap-indexed outputs of bare_index_singles.load for one
    edge. Alternative validated radial grids can be supplied under each cap.
    The optimizer is used only to propose, and exact_charge verifies the result.
    """
    import cvxpy as cp
    import numpy as np
    import warnings

    assert set(rows) <= set(CAPS) and mode in ('mixed', 'cross', 'uniform', 'schur')
    n = len(CAPS)
    active = [k for k,cap in enumerate(CAPS) if cap in rows]
    assert active and sum(mass) > 0
    d = np.array(list(map(float, mass)))
    ns = np.array(list(map(float, schur)))
    tagged, shares, costs = [], [], []
    for c in active:
        for r, (role, mult) in enumerate(zip(ROLES, MULTIPLICITIES)):
            t, v, _ = min(alternatives(rows[CAPS[c]]), key=lambda x: sum(x[1][role]))
            tagged.extend([r*n+c]*len(t))
            shares.extend(float(1-s) for s in t)
            costs.extend(mult*float(k) for k in v[role])
    ix, s, cost = np.array(tagged), np.array(shares), np.array(costs)
    # Unimportant rows may be omitted in the proposal only. Every signed
    # comparison and every final charge includes the full original quadrature.
    keep = cost > max(np.max(cost,initial=0)*1e-13, 1e-280)
    ix, s, cost = ix[keep], s[keep], cost[keep]
    dsum = np.sum(d)
    unit = max(1e-10, sqrt(np.sum(cost)/(39*dsum)))
    intercepts = tuple(tuple(Q(format(unit,'.11g')) if c in active else Q(0) for c in range(n)) for _ in ROLES)
    zero = tuple((Q(0),)*n for _ in ROLES)
    if not len(cost):
        return intercepts,zero
    alpha = float(ALPHA)/unit
    weights = cost/(dsum*unit**2)
    dnorm = d/dsum
    an, bn = cp.Variable(2*n), cp.Variable(2*n)
    z, rare, common = cp.Variable(n), cp.Variable(n), cp.Variable(n)
    constraints = [bn >= 0]
    inactive = [r*n+c for r in range(2) for c in range(n) if c not in active]
    if inactive:
        constraints.extend([an[inactive] == 0, bn[inactive] == 0])
    active_roles = [r*n+c for r in range(2) for c in active]
    equal,bounds = geometry_bounds(n)
    eq = np.flatnonzero(equal)
    constraints += [an[active_roles] >= 1e-7, common >= bn[:n], common >= bn[n:],
                    rare[eq] >= common[eq], z == 37*an[:n]+2*an[n:]+rare]
    f,c = np.array(list(bounds),dtype=int).T
    for r in range(2):
        delta = an[r*n+c]-an[r*n+f]
        for side in range(2):
            v = np.array([float(x[side]) for x in bounds.values()])
            constraints.append(rare[f] >= delta+cp.multiply(1-v,common[f])+cp.multiply(v,bn[r*n+c]))
    expr = cp.sum(cp.multiply(weights, cp.inv_pos(an[ix]+cp.multiply(s,bn[ix]))))
    # A fixed choice of the two valid Schur budgets is convex. For the
    # pointwise minimum take the cheaper branch at the current witness and
    # optimize that convex majorant, with the exact minimum replayed later.
    branches = np.full(n, mode == 'schur') if mode != 'mixed' else ns < 2*d
    best = exact_charge(mass,schur,rows,intercepts,zero,mode),intercepts,zero
    for _ in range(3):
        ss = np.flatnonzero(branches)
        uu = np.flatnonzero(~branches)
        objective = expr
        if len(uu):
            objective += dnorm[uu] @ z[uu]
        if len(ss):
            objective += dnorm[ss] @ cp.pos(z[ss]-alpha)
        problem = cp.Problem(cp.Minimize(objective), constraints)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', UserWarning)
            try:
                problem.solve(solver='CLARABEL', max_iter=150)
            except cp.SolverError:
                break
        if an.value is None or bn.value is None:
            break
        def rational(values, intercept):
            out = []
            for r in range(2):
                out.append(tuple(Q(format(max(1e-15 if intercept else 0, values[r*n+c]*unit), '.11g'))
                                 if c in active else Q(0) for c in range(n)))
            return tuple(out)
        a, b = rational(an.value, True), rational(bn.value, False)
        value = exact_charge(mass, schur, rows, a, b, mode)
        if value < best[0]:
            best = value,a,b
        if mode != 'mixed':
            break
        coeff = np.array(list(map(float,full_coefficients(a,b))))
        better = ns + np.maximum(0,coeff-float(ALPHA))*d < (2-float(ALPHA)+coeff)*d
        if np.array_equal(better,branches):
            break
        branches = better
    return best[1:]
