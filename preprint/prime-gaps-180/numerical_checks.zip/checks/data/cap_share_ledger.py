"""Combine verified full-class masses and retained-class image panels for each middle group."""
from fractions import Fraction as Q
from pathlib import Path
from hashlib import sha256
import json

from bare_index_singles import CAPS, EDGES, PRODUCTION_PIN, load
from cap_share_convex import propose, exact_charge
from middle_charge_aggregate import verify
from two_radius_cross import exact as radius_charge, improve

HERE = Path(__file__).resolve().parent


def joint_uppers(mass_paths, directories, uniform=False, *, witnesses=None, replay=None):
    """Raw twice-cross plus the negative Schur and deletion terms, excluding the pair."""
    dm = {}
    panels = {}
    for path in mass_paths:
        doc = json.loads(path.read_bytes())
        verify(doc)
        for row in doc['groups']:
            key = row['cap'], row['edge']
            panels.setdefault(key, []).extend(option['panels'] for option in row['inputs'])
            d = Q(row['scaled_deleted_upper'])
            b = Q(row['scaled_negative_upper'])
            previous = dm.get(key, (d,b))
            dm[key] = min(d,previous[0]), min(b,previous[1])
    fields = {}
    for path in directories:
        if not path.is_dir():
            continue
        manifest = json.loads((path/'manifest.json').read_bytes())
        if manifest['options']['owner_weight'] != 0:
            continue
        if manifest['calculation'] != PRODUCTION_PIN:
            continue
        values, _ = load(path)
        for key, row in values.items():
            fields.setdefault(key, []).append(row)

    # This full-radius, all-full-maxima reference is in this directory.
    # For this option only the integrated bounds are used, with no credit
    # from knowing where the radial panel lies (retained share at most one).
    reference_bytes = (HERE/'localized_singles_46567_330000_repriced.json').read_bytes()
    assert sha256(reference_bytes).hexdigest() == '8bbcf049c4a3772f23a29ad0890fae14069a8efe48a957d41e7b29559398e46a'
    reference = json.loads(reference_bytes)
    assert reference['cap'] == 46567 and reference['edge'] == 330000 and reference['owner_weight'] == 0
    costs = {role: Q(reference['charges'][role]['scaled_upper']) for role in ('core','a')}
    fields.setdefault((46567,330000), []).append(([Q(1)], {r:[v] for r,v in costs.items()}, costs))

    result = {}
    mode = 'uniform' if uniform else 'mixed'
    for edge in EDGES:
        keys = [(c,edge) for c in CAPS]
        if not all(k in fields and k in dm for k in keys):
            continue
        mass, schur = zip(*(dm[k] for k in keys))
        rows = {c:fields[c,edge] for c in CAPS}
        if not sum(mass):
            result[edge] = Q(0)
            continue
        options = {cap: panels[cap,edge] for cap in CAPS}
        if replay is None:
            a,b = propose(mass,schur,rows,mode)
            radial, radius = improve(edge,options,rows,a,b,mode)
        else:
            saved = replay[str(edge)]
            a,b = (tuple(tuple(map(Q,line)) for line in saved[key]) for key in ('intercepts','slopes'))
            r,u,v = saved['radius_and_scales']
            radius = int(r),Q(u),Q(v)
            radial = radius_charge(edge,options,rows,a,b,*radius,mode=mode)
        fixed = exact_charge(mass,schur,rows,a,b,mode)
        result[edge] = min(fixed,radial)
        if replay is not None:
            assert result[edge] == Q(saved['raw_upper'])
        if witnesses is not None:
            witnesses[str(edge)] = dict(intercepts=[list(map(str,line)) for line in a],
                                        slopes=[list(map(str,line)) for line in b],
                                        radius_and_scales=list(map(str,radius)),raw_upper=str(result[edge]))
    return result
