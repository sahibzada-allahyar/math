"""Rebuild the union of the 85 middle thresholds from signed pair-field certificates."""
import argparse
from fractions import Fraction as Q
from hashlib import sha256
import json
from math import ceil
from pathlib import Path

from archived_sources import recorded_digest
from grouped_restoration import CAPS, GEOMETRIES, MIDDLE, root
from quotient_inputs import STEP
from radial_rounding import captured
from h1_degree6_native_schur_support import replay_limits

HERE = Path(__file__).resolve().parent
PIN = '39326d4c210728dcedcd5441dbd73b7719dbf6823e5eb3a77e89d554051b9b72'


def load(path):
    return json.loads(path.read_bytes())


def summarize(manifest, cases):
    record = {k: v for k, v in manifest.items() if k != 'pin'}
    assert sha256(json.dumps(record, sort_keys=True).encode()).hexdigest() == manifest['pin'] == PIN
    for name, digest in record['code'].items():
        assert recorded_digest(name) == digest
    expected = {(c, e) for e in MIDDLE for c in CAPS}
    order = [tuple(v) for v in record['tasks']]
    assert len(order) == len(cases) == len(expected) and set(order) == expected
    limits = replay_limits(2)
    field_source = load(HERE / 'localized_middle_pair_39058_290000.json')['native_field_source']
    for name, digest in field_source.items():
        assert recorded_digest(name) == digest
    capture = Q(captured(256, 5)[0])
    totals = {edge: Q(0) for edge in MIDDLE}
    for (cap, edge), case in zip(order, cases, strict=True):
        assert case['pin'] == PIN
        r = case['result']
        previous = CAPS[CAPS.index(cap)-1] if cap != CAPS[0] else -1
        assert r['retained'] == [previous, cap]
        assert r['geometry'] == next(g for g in GEOMETRIES if g >= cap)
        assert r['edges'] == [edge, min(edge + 40000, 940000)]
        assert r['full_maxima'] == [cap] + [c for c in CAPS if c > cap and c*STEP*2624990 > edge]
        assert Q(r['capture']) == capture
        for k in ('radial', 'tail', 'micro', 'dust', 'count', 'radius', 'beta', 'eta'):
            assert r[k] == record['parameters'][k]
        panels = list(map(Q, r['panels']))
        assert r['native_field_source'] == field_source
        last = next(n for c, n in limits if c >= cap)
        first = max(0, ceil(Q(previous - 7*256, 256)))
        stop = (last + 5*256)//256 + 1
        assert len(panels) == len(range(first, stop, 8))
        raw = Q(r['raw_upper'])
        assert panels and min(panels) >= 0 and raw * capture >= sum(panels)
        totals[edge] += raw
    norm = Q(load(HERE / 'bottom_angular_norm.json')['continuum_scaled_lower'])
    transfer = load(HERE / 'localized_operator.json')
    h = Q(transfer['true_single_site_chi_upper'])
    delta = Q(transfer['pair_bare_norm_upper']) * (2*h + h*h)
    scaled = sum(totals.values())
    continuum = (root(scaled / norm) + delta)**2
    return dict(complete=len(order), expected=len(expected), raw_subtotal=str(scaled),
                continuum_squared_upper=str(Q(ceil(continuum*10**18), 10**18)),
                ordinary_floor=str(norm), pair_norm_transfer=str(delta),
                edges={str(e): dict(complete=True, cases=len(CAPS), raw_upper=str(v)) for e, v in totals.items()})


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--directory', type=Path)
    cli.add_argument('--receipt', type=Path, default=HERE / 'middle_pair_union.json')
    args = cli.parse_args()
    if args.directory:
        manifest = load(args.directory / 'pair-manifest.json')
        cases = [load(args.directory / f'{c}_{e}.json') for c, e in manifest['tasks']]
        doc = dict(manifest=manifest, receipts=cases, **summarize(manifest, cases))
        args.receipt.write_text(json.dumps(doc, separators=(',', ':'))+'\n')
    else:
        doc = load(args.receipt)
        assert all(doc[k] == v for k, v in summarize(doc['manifest'], doc['receipts']).items())
    print('Complete cases', doc['complete'], 'continuum pair squared upper', float(Q(doc['continuum_squared_upper'])))
