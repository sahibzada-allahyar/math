"""Couple retained-image radial panels to ordinary full-radius panels by a free reference index."""

from fractions import Fraction as Q
from functools import cache
import numpy as np

from bare_index_singles import CAPS, EDGE_FLOOR, ceilq
from cap_share_convex import ALPHA, ROLES, MULTIPLICITIES, alternatives, geometry_bounds


@cache
def schur_price(f,hi):
    from local_schur_charge import grouped
    return min(Q(2),grouped(CAPS[f-1] if f else 0,CAPS[f],hi))


def scenarios(a,b):
    """Intercept sum, slope sum, and share-weighted slope upper for each possible owner."""
    equal,bounds=geometry_bounds(len(CAPS))
    result=[]
    for f in range(len(CAPS)):
        A=sum(n*w[f] for n,w in zip(MULTIPLICITIES,a))
        B=sum(n*w[f] for n,w in zip(MULTIPLICITIES,b))
        top=max(w[f] for w in b)
        rows=[(A,B,top)] if equal[f] else []
        for r in range(2):
            for c in range(f):
                if (f,c) not in bounds:continue
                delta=b[r][c]-b[r][f]
                upper=max((1-s)*top+s*b[r][c] for s in bounds[f,c])
                rows.append((A+a[r][c]-a[r][f],B+delta,upper))
        result.append(rows)
    return result


def mass_panels(edge,options,mode):
    target=[]
    for f,cap in enumerate(CAPS):
        by_source=[]
        for panels in options[cap]:
            values=[]
            for lo,hi,val in panels:
                assert 102994<=lo<=hi<=131032 and Q(val)>=0
                if hi<EDGE_FLOOR[edge]:continue
                lo=max(lo,EDGE_FLOOR[edge])
                base=Q(0) if mode=='cross' else ((Q(2) if mode=='uniform' else schur_price(f,hi))-ALPHA)
                values.append((lo,base,Q(val)))
            by_source.append(values)
        assert by_source
        target.append(by_source)
    return target


def image_panels(rows):
    result=[]
    for f,cap in enumerate(CAPS):
        if cap not in rows:continue
        for r,(role,n) in enumerate(zip(ROLES,MULTIPLICITIES)):
            alts=[]
            for _,cost,meta in alternatives(rows[cap]):
                # A single integrated or older reference remains valid on the
                # whole physical support, with no virtual-radius discount.
                v=meta.get('native_panel_upper',(131032,)*len(cost[role]))
                assert len(v)==len(cost[role]) and all(h>=0 for h in v) and all(x>=0 for x in cost[role])
                alts.append((v,cost[role]))
            result.append((r,f,n,alts))
    return result


def exact(edge,options,rows,a,b,R,intercept_scale=Q(1),slope_scale=Q(1),mode='mixed'):
    assert R>0 and intercept_scale>0 and slope_scale>=0
    assert mode in ('uniform','schur','mixed','cross')
    assert set(options)==set(CAPS) and set(rows)<=set(CAPS)
    assert len(a)==len(b)==len(ROLES) and all(len(w)==len(CAPS) for w in (*a,*b))
    for i,cap in enumerate(CAPS):
        if cap in rows:
            assert all(v[i]>0 for v in a) and all(v[i]>=0 for v in b)
        else:
            assert all(v[i]==0 for v in (*a,*b))
    dsets=mass_panels(edge,options,mode)
    configs=scenarios(a,b)
    amount=Q(0)
    for f,sets in enumerate(dsets):
        def cost(panels):
            v=Q(0)
            for lo,base,m in panels:
                gamma=min(Q(1),Q(lo,R))
                z=max(intercept_scale*a0+slope_scale*((1-gamma)*b0+gamma*bt) for a0,b0,bt in configs[f])
                v+=max(Q(0),z+base)*m
            return v
        amount+=min(cost(z) for z in sets)
    for r,f,n,alts in image_panels(rows):
        aa=a[r][f]*intercept_scale
        bb=b[r][f]*slope_scale
        assert aa>0 and bb>=0
        amount+=n*min(ceilq(sum(x/(aa+bb*max(Q(0),1-Q(h,R))) for h,x in zip(v,c)))
                      for v,c in alts)
    return ceilq(amount)


def improve(edge,options,rows,a,b,mode='mixed'):
    """Return a rational upper and (reference, intercept multiplier, slope multiplier).

    Options maps every full maximum cap to a list of alternative full lists of
    [lo,hi,raw mass upper] panels. Rows has the same retained-cap interface as
    cap_share_convex. Every panel in the chosen result is repriced exactly.
    """
    mass=mass_panels(edge,options,mode)
    msets=[[np.array(q,dtype=float).reshape(-1,3).T for q in sets] for sets in mass]
    isets=[(r,f,n,[(np.array(v,float),np.array(c,float)) for v,c in alts])
           for r,f,n,alts in image_panels(rows)]
    configs=[np.array(s,float).T for s in scenarios(a,b)]
    aa,bb=np.array(a,float),np.array(b,float)
    best=None
    for R in sorted({EDGE_FLOOR[edge],112000,115000,118000,120000,122000,124000,126000,128000,130000}):
        # Only the ratio of the slope/intercept multipliers affects the full
        # upper before applying its final scalar; omit all-zero parameters.
        for ratio in (.50,.75,1.,1.33,2.):
            spans=[]
            for f,sets in enumerate(msets):
                A,B,T=configs[f]
                options_f=[]
                for lo,base,val in sets:
                    g=np.minimum(1,lo/R)
                    z=(A[:,None]+ratio*(B[:,None]*(1-g)+T[:,None]*g)).max(axis=0)
                    options_f.append((z,base,val))
                spans.append(options_f)
            im=sum(n*min(float(np.sum(c/(aa[r,f]+ratio*bb[r,f]*np.maximum(0,1-v/R)))) for v,c in alts)
                   for r,f,n,alts in isets)
            for scale in (.6,.8,1.,1.25,1.6):
                price=im/scale+sum(min(float(np.maximum(0,scale*z+base)@v) for z,base,v in opts)
                                   for opts in spans)
                item=price,(R,Q(str(scale)),Q(str(scale))*Q(str(ratio)))
                if best is None or item[0]<best[0]:best=item
    params=best[1]
    return exact(edge,options,rows,a,b,*params,mode=mode),params
