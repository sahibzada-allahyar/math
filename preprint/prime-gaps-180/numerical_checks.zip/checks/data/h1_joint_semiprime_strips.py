"""Optimize semiprime, three-prime, and five-prime constraints in one finite problem."""
import argparse
from fractions import Fraction as Q
from math import floor
from pathlib import Path
import json

import numpy as np
from scipy.linalg import eigh

from h1_cover_pairings import model,TABLE,DUAL
from h1_cover_semiprime_credit import prime_correction
from h1_semiprime_budget import density,strip_mask
from h1_shared_rough_pricing import certify
from h1_split_shared_covers import solve
from h1_sunrise_boundary import read,digest
from h1_third_measure import lower_radii
from verify_pairing_envelope import quantize,SCALE


def add_strips(data,table,cuts):
    groups=read(DUAL)['groups']
    ids=np.array(sum(groups,[]))
    owner=np.repeat(np.arange(len(groups)),[len(g) for g in groups])
    assert cuts[0]>=Q(1,2)-min(lower_radii(table)[ids]) and cuts[0]>Q('.2317327998')
    U=data[-2][0]
    bands=[]
    for b,u in zip(cuts,cuts[1:]):
        orig=strip_mask(table,TABLE,b)[np.ix_(ids,ids)]
        i,j=np.nonzero(~orig)
        mask=np.ones((len(groups),len(groups)),bool)
        mask[owner[i],owner[j]]=False
        bands.append((mask,density(b,u)))
    n=len(bands)
    coupled=[([*coeff,*[int(coeff[0])]*n],budget) for coeff,budget in data[-1]]
    coupled.append(([1,0,0,0,*([1]*n)],U))
    return (*data[:-2],[*data[-2],*([U]*n)],coupled),bands


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('cover',type=Path);p.add_argument('joint',type=Path)
    p.add_argument('--cuts',nargs='+',type=Q,default=list(map(Q,('.281','.36','.416407','.5'))))
    p.add_argument('--steps',type=int,default=70);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--check',action='store_true')
    a=p.parse_args()
    assert all(b<u for b,u in zip(a.cuts,a.cuts[1:])) and a.cuts[-1]<=Q('.5')
    data,_,hashes,_=model(a.cover)
    prior=read(a.joint)
    assert all(prior['inputs'][name]==h for name,h in hashes.items())
    hashes[a.joint.name]=digest(a.joint)
    combined,bands=add_strips(data,read(TABLE),a.cuts)
    if a.check:
        doc=read(a.output)
        assert doc['inputs']==hashes and doc['cuts']==list(map(str,a.cuts))
        lin=[np.asarray(m,dtype=object) for m in doc['affine']]
        factors=[np.asarray(m,dtype=object) for m in doc['factors']]
    else:
        lin=[np.asarray(m,dtype=object) for m in prior['affine']]
        factors=[np.asarray(m,dtype=object) for m in prior['factors']]
        assert floor(certify(data,lin,factors)*10**9)==prior['lower_billionths']
        _,prime=prime_correction(data,lin,factors)
        ev,V=eigh(np.asarray(prime,float)/(24*SCALE**2))
        good=ev>0
        factors.append(quantize(V[:,good]*np.sqrt(ev[good])))
        lin.extend(np.zeros_like(lin[0]) for _ in bands)
        lin,factors,log=solve(combined,lin,a.steps,strips=bands,initial_factors=factors)
    score=floor(certify(combined,lin,factors,bands)*10**9)
    if a.check:assert score==doc['lower_billionths']
    else:
        doc=dict(scope='Joint finite cap bound with disjoint semiprime strips in all applicable rough budgets.',
                 inputs=hashes,cuts=list(map(str,a.cuts)),history=log,lower_billionths=score,
                 pairs=[int(np.triu(m).sum()) for m,_ in bands],affine=[x.tolist() for x in lin],
                 factors=[x.tolist() for x in factors])
        a.output.write_text(json.dumps(doc,separators=(',',':'))+'\n')
    print('joint with semiprimes',score,flush=True)


if __name__=='__main__':
    main()
