"""Outward native radial and one-site fields for the finite B2 quotient."""
from fractions import Fraction as Q
from functools import cache
from hashlib import sha256
import json
from math import ceil
from pathlib import Path

import numpy as np

from h1_b2_global_amplitude import N,S,SIGS,controls,source


HERE=Path(__file__).resolve().parent
COUNT=N-39
STEP=S/N
PAIR_ORDER=((0,0),(0,1),(0,2),(1,1),(1,2),(2,2))
CDF_RECEIPT='ed9488dd445fac92da256d97f8c3f53684906823529875c033d6d6248072f7b3'
DICKMAN_RECEIPT='7c0671c33da312ef4b718f2aa3c6f403ea9f9986447b33e64fa1cf652145535d'


def exact_float_bounds(x):
    """Tight binary64 endpoints for an input rational."""
    x=Q(x)
    v=float(x)
    q=Q(v)
    return (np.nextafter(v,-np.inf) if q>x else v,
            np.nextafter(v,np.inf) if q<x else v)


def _positive_product(a,b):
    return (np.maximum(0.,np.nextafter(a[0]*b[0],-np.inf)),
            np.nextafter(a[1]*b[1],np.inf))


def _positive_sum(a,b):
    return (np.maximum(0.,np.nextafter(a[0]+b[0],-np.inf)),
            np.nextafter(a[1]+b[1],np.inf))


def _positive_quotient(a,b):
    return (np.maximum(0.,np.nextafter(a[0]/b[1],-np.inf)),
            np.nextafter(a[1]/b[0],np.inf))


def _range(start,stop):
    if not (0<=start<stop<=COUNT):
        raise ValueError(f'Native indices must obey 0 <= start < stop <= {COUNT}.')


def site_fields(start=0,stop=COUNT):
    """Return intervals for t, g, three endpoint shapes and six pair shapes."""
    _range(start,stop)
    j=np.arange(start,stop,dtype=np.float64)+.5
    t=_positive_product((j,j),exact_float_bounds(STEP))
    one=(np.ones(len(j)),np.ones(len(j)))
    def branch(weight,slope):
        den=_positive_sum(one,_positive_product(t,exact_float_bounds(slope)))
        return _positive_quotient(exact_float_bounds(weight),den)
    g=_positive_sum(branch(Q(21,200),Q(1,100)),branch(Q(179,200),Q(907,5)))
    # t/S=(j+1/2)/N is already exact in binary64; its squared numerator
    # fits in 53 bits on this grid, and both denominators are powers of two.
    normalized=j/N
    quadratic=normalized*normalized
    assert N==2**17 and (2*COUNT+1)**2<2**53
    shapes=(one,(quadratic,quadratic),branch(Q(1),Q(300)))
    pairs=[shapes[b] if a==0 else _positive_product(shapes[a],shapes[b]) for a,b in PAIR_ORDER]
    def pack(vals):
        return tuple(np.stack([v[a] for v in vals]) for a in range(2))
    return dict(t=t,g=g,shapes=pack(shapes),pair_shapes=pack(pairs))


@cache
def _radial_controls(span):
    knots,row=source()
    basis=controls(knots,span,knots[span],knots[span+1])
    low=np.empty((4,3,len(SIGS),9))
    high=np.empty_like(low)
    for pair in range(9):
        for sig,powers in enumerate(SIGS):
            scale=39**(sum(powers)-len(powers))
            for c in range(3):
                coef=row(c,pair,sig)[span-3:span+1]
                if c<2:
                    below=row(c+1,pair,sig)[span-3:span+1]
                    coef=[a-b for a,b in zip(coef,below,strict=True)]
                for k,weights in enumerate(zip(*basis)):
                    v=scale*sum(a*b for a,b in zip(coef,weights,strict=True))
                    low[k,c,sig,pair],high[k,c,sig,pair]=exact_float_bounds(v)
    return low,high


def _bernstein(knots,span,first,stop):
    """Enclose nonnegative cubic weights on [knot_span,knot_span+1)."""
    left,right=knots[span:span+2]
    step=STEP/(right-left)
    x0=((first+Q(39,2))*STEP-left)/(right-left)
    yend=(right-(stop-1+Q(39,2))*STEP)/(right-left)
    assert x0>=0 and yend>0
    k=np.arange(stop-first,dtype=float)
    def affine(offset,delta):
        return _positive_sum(exact_float_bounds(offset),
                             _positive_product((delta,delta),exact_float_bounds(step)))
    x=affine(x0,k)
    y=affine(yend,k[::-1])
    x2=_positive_product(x,x)
    y2=_positive_product(y,y)
    three=(3.,3.)
    return (_positive_product(y2,y),_positive_product(three,_positive_product(x,y2)),
            _positive_product(three,_positive_product(x2,y)),_positive_product(x2,x))


def radial_rows(component=None,start=0,stop=COUNT):
    """Certify individual radial rows in component,signature,ordered-endpoint,J order.

    Selecting one component removes the leading axis. Slices use native
    integer indices and are half open. Output includes the 39 angular scale.
    """
    _range(start,stop)
    if component is not None and component not in range(3):
        raise ValueError('Select component 0, 1 or 2, or all components.')
    knots,_=source()
    pick=slice(None) if component is None else component
    shape=((3,) if component is None else ())+(len(SIGS),9,stop-start)
    result=(np.zeros(shape),np.zeros(shape))
    # The archived spline has zero extension outside its knot interval.
    # Its first knot is positive, so there is a full zero prefix.
    covered=max(0,min(stop,ceil(knots[3]/STEP-Q(39,2)))-start)
    for span in range(3,len(knots)-4):
        a=max(start,ceil(knots[span]/STEP-Q(39,2)))
        b=min(stop,ceil(knots[span+1]/STEP-Q(39,2)))
        if a>=b:
            continue
        assert a==start+covered
        covered+=b-a
        low,high=_radial_controls(span)
        zero=np.all((low[:,pick]==0)&(high[:,pick]==0),axis=0)
        for first in range(a,b,1024):
            end=min(b,first+1024)
            out=tuple(v[...,first-start:end-start] for v in result)
            weights=_bernstein(knots,span,first,end)
            for k,(wl,wh) in enumerate(weights):
                l=low[k,pick,...,None]
                h=high[k,pick,...,None]
                bottom=np.nextafter(np.where(l<0,l*wh,l*wl),-np.inf)
                top=np.nextafter(np.where(h<0,h*wl,h*wh),np.inf)
                if k==0:
                    out[0][...]=bottom
                    out[1][...]=top
                else:
                    np.nextafter(out[0]+bottom,-np.inf,out=out[0])
                    np.nextafter(out[1]+top,np.inf,out=out[1])
            out[0][zero]=0.
            out[1][zero]=0.
    assert covered==stop-start
    return result


@cache
def _cdf_hashes():
    def receipt(name,digest):
        raw=(HERE/name).read_bytes()
        assert sha256(raw).hexdigest()==digest
        return json.loads(raw)
    grid=receipt('h1_dickman_native_bounds.json',DICKMAN_RECEIPT)
    transfer=receipt('h1_b2_cap_law_transfer.json',CDF_RECEIPT)
    assert transfer['dickman_receipt_sha256']==DICKMAN_RECEIPT
    rows={a['cap']:a['binary64_cdf_sha256'] for a in transfer['bins']}
    assert len(rows)==37 and grid['count']==COUNT+1
    return grid['count'],rows


@cache
def cap_cdf(cap):
    """Exact dyadic CDF used by the native quotient, with its archive hash."""
    cap=int(cap)
    count,hashes=_cdf_hashes()
    if cap not in hashes:
        raise ValueError('Cap is absent from the 37 authenticated native arrays.')
    values=np.ones(count+1)
    for j in range(cap,count):
        values[j+1]=values[j]-.5*(values[j-cap]/j+values[j+1-cap]/(j+1))
    cdf=np.maximum(0.,.5*(values[:-1]+values[1:]))
    assert sha256(cdf.astype('<f8').tobytes()).hexdigest()==hashes[cap]
    cdf=cdf[:COUNT]
    cdf.setflags(write=False)
    return cdf,cdf
