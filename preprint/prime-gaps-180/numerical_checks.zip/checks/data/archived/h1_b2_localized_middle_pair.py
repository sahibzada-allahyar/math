"""Directed 37-core, two-bare-site contraction of the frozen B2 pair image."""
import argparse
from fractions import Fraction as Q
import json
from math import ceil
from pathlib import Path
import resource
import sys
from time import monotonic

from flint import arb,arb_mat,ctx
import numpy as np

import h1_b2_localized_diagonal as D
from h1_b2_localized_pair_atoms import add_fold,library,square
from h1_b2_localized_spectral_tail import magnitude_upper,moments


F,P=D.F,D.P


def panel_bounds(center,radius,field,lo,hi):
    """An angular norm bound for every native pair coefficient row in a panel."""
    entries=[arb(float(m),float(r)) for m,r in zip(center,radius)]
    G=arb_mat([[entries[j] for j in ids] for ids in P.SIG_INDEX])
    m,r=field
    entire=np.nextafter(np.abs(m[:,lo:hi+1])+r[:,lo:hi+1],np.inf).max(axis=1)
    plus=arb_mat([list(map(F.ball,entire))])
    bounds=[(plus*G*plus.transpose())[0,0].upper()]
    for segments in (1,4,12):
        knots=np.unique(np.linspace(lo,hi,segments+1).round().astype(int))
        residual=np.zeros(len(P.SIGS))
        for left,right in zip(knots,knots[1:]):
            t=np.arange(right-left+1)/(right-left)
            a,b=m[:,left,None],m[:,right,None]
            approximation=a*(1-t)+b*t
            err=np.nextafter(abs(m[:,left:right+1]-approximation),np.inf)
            err=np.nextafter(err+r[:,left:right+1],np.inf)
            err=np.nextafter(err+12*F.U*(abs(a)+abs(b))+F.TINY,np.inf)
            residual=np.maximum(residual,err.max(axis=1))
        if len(knots)==1:residual=r[:,lo]
        box=arb_mat([list(map(F.ball,residual))])
        e=(box*G*box.transpose())[0,0].upper()
        rows=[[F.ball(v) for v in m[:,k]] for k in knots]
        def trace(values):
            h=arb_mat(values);H=h*G*h.transpose()
            return sum(H[i,i].upper() for i in range(len(values)))
        top=trace(rows).sqrt()
        for v in (rows[0],rows[-1],[sum(col)/len(col) for col in zip(*rows)]):
            top=min(top,(trace([v]).sqrt()+trace([[x-y for x,y in zip(row,v)] for row in rows]).sqrt()).upper())
        bounds.append(((top+e.sqrt())**2).upper())
    return F.upper_float(min(bounds))


def masked_pair(bank,layer,flags,same):
    atoms=bank['atoms']
    allowed=[b for b in range(4) if not ((b&1)&~flags)]
    all_sites=atoms[:layer+1,allowed].sum(axis=(0,1),dtype=np.uint64)
    small=(None if same else atoms[:layer+1,[b for b in allowed if not b&2]].sum(axis=(0,1),dtype=np.uint64))
    return square(all_sites,small)


def run(args,context=None):
    since=monotonic();ctx.prec=128
    F.supmag=magnitude_upper
    if args.dots:F.use_dots(args.dots)
    fold=library(args.fold)
    if context is None:
        g=P.Gates(args.gates)
        pr=P.Projection(g,args.radial,args.tail,[args.dust]*3,args.edge_group,True)
        model=D.Native()
    else:g,pr,model=context
    width,wt=args.radial,args.tail
    lower,upper,geometry,_=next(x for x in D.retained_groups(model,pr.cap_ends_projection) if x[1]==args.cap)
    with np.load(args.bank,allow_pickle=False) as archive:
        meta=json.loads(str(archive['meta']))
        assert meta['caps'][-1]['cap']==geometry
        m,r=model.pair
        price=np.nextafter(np.nextafter(np.abs(m)+r,np.inf)**2,np.inf)
        field=D.price_field((archive['pair0'],archive['pair1']),price)
    ix=np.flatnonzero(g.edges[pr.middle]==args.edge).item()
    a=int(g.edges[pr.middle[ix]]);b=int(g.edges[pr.ending[ix]+1])
    current=D.group_bank(g,pr,upper,a,b,args)
    n,keys,_,density,dust,group=current
    last=int(g.lasts[group[0]]);k,fields=F.site_fields(last,width,True)
    assert np.array_equal(k,keys)
    back=args.radius*width;retback=(args.radius+2)*width
    full_hi=(last+back)//width+1
    first=max(0,ceil(Q(lower-retback,width)))
    last_k=full_hi
    panels=[(j,min(last_k,j+args.count)) for j in range(first,last_k,args.count)]
    nt=ceil((last+39)*g.tick/wt)+39
    nk=max(F.pow2(max(n,full_hi)),2*F.pow2((model.n-1)//width))
    ny=F.pow2(2*nt+1)
    shape=nk,ny
    full=[D.bare_geometry(g,pr,upper,current,args,ix,nk)]
    for cap in pr.cap_ends_projection:
        if cap<=upper or cap*g.tick<=a:continue
        data=D.group_bank(g,pr,cap,a,b,args)
        full.append(D.bare_geometry(g,pr,cap,data,args,ix,nk))
    total=sum(sum(map(int,v['atoms'].flat))**2 for v in full)
    assert total<2**128
    sx=F.tilted_axis(float(np.exp(-args.beta*float(D.STEP)*width)),nk)
    sy=F.tilted_axis(float(np.exp(args.eta*wt/2624990)),ny)
    tilt=sx[:n,None]*sy[:density.shape[-1]];comp=1/(sx[:,None]*sy)
    result=np.zeros((len(panels),len(P.ANG)));error=np.zeros_like(result)
    mult=np.ones(ny//2+1)*2;mult[0]=mult[-1]=1
    require=3 if lower>=0 and group[0] else 1
    stages=0
    for layer in range(len(dust)):
        direction=-1 if layer+1<len(dust) else 1
        # Lower-crossing inclusion-exclusion for the retained sites is
        # independent of the two bare sites. Reuse its exact folded mask.
        masks={}
        for flags in range(4):
            if flags&~require:continue
            occupied=flags&1
            if occupied not in masks:
                mask=np.zeros((last_k,nt+1,2),dtype=np.uint64)
                for bank in full:
                    tops=bank['tops']
                    left,right=((tops[layer+1],tops[layer]) if direction<0
                                else (tops[layer],np.full(nk,bank['max_tail']+1,dtype=np.int32)))
                    if not np.any(left[bank['full_lo']:bank['full_hi']]<right[bank['full_lo']:bank['full_hi']]):continue
                    coef=masked_pair(bank,layer,occupied,bank['cap']==upper)
                    add_fold(fold,coef,left,right,bank['full_lo'],bank['full_hi'],mask)
                live=[i for i,(l,r) in enumerate(panels) if mask[l:r].any()]
                weights=[];we=[]
                for i in live:
                    l,r=panels[i];w=np.zeros(shape)
                    # Two independent dyadic bare laws each have scale 2^50.
                    bare=(mask[l:r,:,0].astype(float)*2.**-100+mask[l:r,:,1].astype(float)*2.**-36)
                    w[l:r,:nt+1]=bare*comp[l:r,:nt+1]
                    ft,re=F.transform(w,shape,30*F.U)
                    weights.append((ft.reshape(nk,-1).conj()*mult/(nk*ny)).ravel())
                    we.append(2*re/(nk*ny)+F.TINY)
                masks[occupied]=(live,np.asarray(weights),np.asarray(we))
            live,weights,we=masks[occupied]
            if not live:continue
            selected=[v for v in range(4) if not v&~flags]
            data=density[:layer+1,selected].sum(axis=(0,1))
            if not data.any():continue
            trans=[];rs=[]
            for row in fields[:13]:
                x=np.zeros((n,data.shape[-1]));np.add.at(x,keys,row[:,None]*data)
                ft,re=F.transform(x*tilt,shape,(width+4*len(dust)+180)*F.U)
                trans.append(ft);rs.append(re)
            cm,er=moments(np.asarray(trans),np.asarray(rs),weights,we,'pair',args.spectral_tail)
            cm=cm[:,:,0];er=er[:,:,0]
            sign=direction*(-1)**((flags^require).bit_count())
            error[live]+=er+4*F.U*(np.abs(result[live])+np.abs(cm))+F.TINY
            result[live]+=sign*cm
            stages+=1
    error=error*(1+2**-42)+F.TINY
    capture=D.captured(width,args.radius)[0]
    bounds=[]
    for i,(l,r) in enumerate(panels):
        if not result[i].any() and np.max(error[i])<=2*F.TINY:
            bounds.append(0.);continue
        low=max(0,lower,l*width-retback);high=min(last,(r-1)*width+retback)
        bounds.append(panel_bounds(result[i],error[i],field,low,high))
    raw=F.upper_float(sum(map(F.ball,bounds))/F.ball(capture))
    rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return dict(scope='Complete retained radii and all eligible full maxima for the squared tabulated pair image under the actual continuum site law.',
                retained=[lower,upper],edges=[a,b],full_maxima=[v['cap'] for v in full],geometry=geometry,
                native_field_source=meta['source'],raw_upper=raw,panels=bounds,
                capture=str(capture),stages=stages,radial=width,tail=wt,micro=args.micro,
                dust=args.dust,beta=args.beta,eta=args.eta,torus=list(shape),count=args.count,radius=args.radius,
                peak_mb=ceil(rss/(1024**2 if sys.platform=='darwin' else 1024)),
                seconds=round(monotonic()-since,3))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('gates','fold','dots','bank','output'):p.add_argument('--'+n,type=Path,required=True)
    for n,d in [('cap',39058),('edge',290000),('radial',256),('tail',30000),('micro',1000),
                ('dust',150000),('edge-group',4),('count',8),('radius',5)]:
        p.add_argument('--'+n,type=int,default=d)
    p.add_argument('--spectral-tail',type=float,default=.0625)
    p.add_argument('--beta',type=float,default=32.);p.add_argument('--eta',type=float,default=16.)
    args=p.parse_args();report=run(args)
    args.output.write_text(json.dumps(report,indent=2,default=int)+'\n')
    print(report['raw_upper'],report['seconds'],report['peak_mb'])
