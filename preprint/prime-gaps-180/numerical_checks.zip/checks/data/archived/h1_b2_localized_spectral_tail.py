"""Directed Fourier tail after the interchangeable core factors have been counted."""
from math import perm

import numpy as np

import h1_b2_projected_fourier as F
from h1_b2_localized_moments import role_moments


def magnitude_upper(z):
    """Complex absolute value with the square-underflow range treated explicitly."""
    re=np.abs(z.real);im=np.abs(z.imag)
    # If the larger input is >=2^-500, at least one square is normal.
    # Otherwise use the outward positive L1 triangle bound.
    measured=np.sqrt(re*re+im*im)*(1+4*F.U)
    return np.where(np.maximum(re,im)<2.**-500,np.nextafter(re+im,np.inf),measured)+F.TINY


def moments(trans,errors,weights,weight_errors,role,cutoff=.125):
    """Contract the active frequencies and enclose all omitted correlations."""
    assert 0<cutoff<=.25 and trans.shape[1]<=2**22
    h=F.supmag(trans)+np.asarray(errors)[:,None]
    h=np.nextafter(h,np.inf)
    assert np.max(h)<4 and np.max(F.supmag(weights))<2.**135
    peak=np.max(h[0])
    top=peak*cutoff
    active=h[0]>top
    if not np.any(active):
        raise ArithmeticError('The mass transform has no active frequencies.')
    center,radius=role_moments(np.ascontiguousarray(trans[:,active]),errors,
                               np.ascontiguousarray(weights[:,active]),weight_errors,role)
    cores=36 if role=='core' else 37
    extra=np.zeros_like(radius)
    working=h[0]<=top
    # Binning below the cutoff prevents one moderately large omitted
    # frequency from dominating a whole row of very small coefficients.
    for step in range(8):
        floor=top*.5
        chosen=working if step==7 else working&(h[0]>floor)
        if np.any(chosen):
            hi=h[:,chosen].max(axis=1)
            powers=[1.]
            for _ in range(cores):powers.append(powers[-1]*hi[0])
            angular=[]
            for sig in F.P.ANG:
                bound=0.
                for parts,mult in F.P._partitions(sig):
                    x=powers[cores-len(parts)]*(mult*perm(cores,len(parts)))
                    for degree in parts:x*=hi[degree]
                    bound+=x
                angular.append(bound)
            if role=='core':
                a,b=np.array(F.P.PAIR).T+13
                end=hi[a]*hi[b]
            elif role in ('a','b'):
                end=hi[13:19]
            else:end=np.ones(1)
            mag=F.supmag(weights[:,chosen])
            wsum=np.sum(mag+np.asarray(weight_errors)[:,None],axis=1)
            extra+=wsum[:,None,None]*np.asarray(angular)[None,:,None]*end[None,None,:]
        working&=h[0]<=floor
        top=floor
    # There are at most 2^22 summands in any nonnegative floating
    # reduction. The additional additive margin also covers any underflow
    # through the 37 products, 2^53 multiplicity, 2^135 weights and
    # fewer than 2^22 frequencies.
    err=(radius+extra*(1+2.**-26))*(1+2.**-46)+2.**-660
    assert np.isfinite(err).all()
    return center,err
