"""Screen a bivariate majorant for the 85 middle gates on the frozen B2 trial."""
import argparse
import json
from math import ceil, sqrt
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np

from h1_degree6_b2_gate_reachability import Gates, rebuild
from h1_degree6_b2_gate_screen import Profile, rlib


class Projection(Profile):
    def __init__(self, gate, radial, tail, dust, edge_group=1, group_caps=False):
        super().__init__(gate)
        self.radial = radial
        self.tail = tail
        self.dust = np.array(dust)
        if len(dust) != 3 or min(radial, tail, *dust) <= 0:
            raise ValueError('Expected positive mesh widths and three dust comparisons.')
        edges = np.flatnonzero((gate.edges[:-1] >= 90000) & (gate.edges[:-1] < 940000))
        assert edge_group >= 1 and np.all(np.diff(edges) == 1)
        self.middle = edges[::edge_group]
        self.ending = np.minimum(self.middle+edge_group-1, edges[-1])
        self.cap_groups = []
        cuts = {cap for cap,_ in gate.limits} | set(self.components) | set(gate.fine[:4])
        self.cap_ends_projection = sorted(cuts if group_caps else gate.fine)
        self.dust_limit = ceil(27971 * gate.tick)
        self.first = []
        self.second = []
        # For a full radial upper endpoint, store the two prefix minima up
        # to the END of its block, uniformly in every retained native index.
        self.lookup_width = 32
        for c in range(len(gate.fine)):
            j, keys, tops = gate.tile(c)
            ok = j >= 102994
            j = j[ok]
            blocks = j // self.lookup_width
            shape = (1 + gate.lasts[c] // self.lookup_width, len(self.middle))
            first = np.full(shape, 10**8, dtype=np.int32)
            second = first.copy()
            for key, top in zip(keys, tops):
                key, top = key[ok], top[ok]
                starts = np.r_[0, np.flatnonzero((np.diff(blocks) != 0) | (np.diff(key) != 0)) + 1]
                threshold = gate.gates[key[starts]][:, self.ending]
                live = threshold < np.maximum.reduceat(top, starts)[:, None]
                ends = np.r_[starts[1:] - 1, len(j) - 1]
                index_ticks = self.index_hi[j[ends]]
                np.minimum.at(first, blocks[starts], np.where(live, threshold, 10**8))
                np.minimum.at(second, blocks[starts], np.where(live, threshold-index_ticks[:, None], 10**8))
            self.first.append(np.minimum.accumulate(first, axis=0))
            self.second.append(np.minimum.accumulate(second, axis=0))
        for cap in self.cap_ends_projection:
            lower = self.cap_groups[-1][-1]+1 if self.cap_groups else 0
            last = np.flatnonzero(gate.fine == cap).item()
            group = list(range(lower, last+1))
            # Every grouped cap has the same hereditary radial ceiling and
            # the same active component suffix. Prefix minima use all rows.
            assert len(set(gate.lasts[c] for c in group)) == 1
            for bank in (self.first, self.second):
                shared = np.minimum.reduce([bank[c] for c in group])
                for c in group:
                    bank[c] = shared
            self.cap_groups.append(group)

    def compare(self, j, t, largest, marks):
        g = self.gate
        n = len(j)
        raw = marks * self.ticks
        pos = np.maximum(np.searchsorted(g.edges[:-1], raw, side='right') - 1, 0)
        hist = np.zeros((n, 39, len(g.edges)-1))
        np.add.at(hist, (np.arange(n)[:, None, None], np.arange(39)[None, :, None], pos),
                  np.where(raw >= g.edges[0], raw, 0.0))
        full_hist = hist.sum(axis=1)
        physical_tail = full_hist[:, ::-1].cumsum(axis=1)[:, ::-1]
        exact_fail = np.zeros_like(full_hist, dtype=bool)
        total = t.sum(axis=1)
        J = j.sum(axis=1)
        largest2 = np.partition(largest, -2, axis=1)[:, -2:]
        classes = np.searchsorted(g.fine, largest2[:, 1] / self.h)
        max_dust = np.zeros((n, len(self.middle)))
        tail_up = np.zeros_like(max_dust)
        for i in range(39):
            m = np.where(largest[:, i] >= largest2[:, 1], largest2[:, 0], largest2[:, 1])
            c = np.searchsorted(g.fine, m / self.h)
            rows = self.dense_group[c, J - j[:, i]]
            r = np.maximum(g.base, np.ceil((total-t[:, i])*self.ticks/g.step).astype(int)) - g.base
            key = g.ls[c, rows, r]
            assert np.all(rows >= 0) and np.all(key >= 0)
            own = hist[:, i, ::-1].cumsum(axis=1)[:, ::-1]
            exact_fail |= physical_tail - own > g.gates[key]
            part = own[:, self.middle]
            tail_up += np.ceil(part/self.tail)*self.tail
            eligible = j[:, i, None] <= 27970
            dust = np.where(eligible, t[:, i, None]*self.ticks - part, 0.)
            max_dust = np.maximum(max_dust, dust)

        Jlo = (j // self.radial).sum(axis=1)*self.radial
        Jhi = Jlo + 39*(self.radial-1)
        occupied = np.stack([full_hist[:, a:b+1].sum(axis=1) > 0
                             for a,b in zip(self.middle,self.ending)], axis=1)
        charges = [np.zeros(n, dtype=int) for width in self.dust]
        for c in np.unique(classes):
            use = np.flatnonzero(classes == c)
            hi = np.minimum(Jhi[use], g.lasts[c]) // self.lookup_width
            G = self.first[c][hi]
            offset = g.low[Jlo[use], None] + self.second[c][hi]
            above = occupied[use] & (tail_up[use] > G)
            for width, charge in zip(self.dust, charges):
                # Clipping is valid for every site eligible for a failing
                # erasure, including when every ineligible site has more dust.
                d = np.minimum(np.ceil(max_dust[use]/width)*width, self.dust_limit)
                charge[use] = (above & (tail_up[use]+d > offset)).sum(axis=1)
        last = np.where(exact_fail, g.edges[:-1], 0).max(axis=1)
        actual = (last >= 90000) & (last < 940000)
        assert all(np.all(actual <= charge) for charge in charges)
        return actual, *charges


def run(g, args):
    assert g.verify()['max_index_of_failing_erasure'] == 27970
    target = Projection(g, args.radial, args.tail, args.dust, args.edge_group, args.group_caps)
    proposal = rlib.Proposal(target.S, target.prefactor, np.geomspace(1., 6000., 80),
                             target.cap, ngrid=60000)
    rng = np.random.default_rng(args.seed)
    data = []
    for _ in range(args.batches):
        denominator = sum(target.one(args.size, rng, i, mass_only=True) for i in range(3))
        data.append([denominator, *target.palm(args.size, rng, proposal)])
    values = np.asarray(data)
    denominator = values[:, 0]
    def stats(values):
        ratio = values.sum()/denominator.sum()
        error = (values-ratio*denominator).std(ddof=1)/(sqrt(args.batches)*denominator.mean())
        return dict(fraction=float(ratio), batch_standard_error=float(error))
    return dict(scope='Paired floating importance sampling of bivariate middle-gate majorants.',
                seed=args.seed, batches=args.batches, size=args.size,
                site_radial_indices=args.radial, site_tail_ticks=args.tail,
                edge_group=args.edge_group, cap_groups=target.cap_ends_projection,
                dust_limit_ticks=target.dust_limit,
                actual_middle=stats(values[:, 1]),
                upper_by_dust_ticks={str(w): stats(values[:, i+2]) for i,w in enumerate(args.dust)},
                paired_excess={str(w): stats(values[:, i+2]-values[:, 1]) for i,w in enumerate(args.dust)},
                witnessed_counts=values[:, 5:].sum(axis=0).astype(int).tolist())


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--gates', type=Path)
    p.add_argument('--seed', type=int, default=41701)
    p.add_argument('--batches', type=int, default=160)
    p.add_argument('--size', type=int, default=384)
    p.add_argument('--radial', type=int, default=16)
    p.add_argument('--tail', type=int, default=2500)
    p.add_argument('--dust', type=int, nargs=3, default=[2500, 10000, 25000])
    p.add_argument('--edge-group', type=int, default=1)
    p.add_argument('--group-caps', action='store_true')
    p.add_argument('--output', type=Path)
    args = p.parse_args()
    with TemporaryDirectory() as tmp:
        result = run(Gates(args.gates or rebuild(Path(tmp))), args)
    encoded = json.dumps(result, indent=2, default=int)+'\n'
    if args.output:
        args.output.write_text(encoded)
    print(encoded, end='')
