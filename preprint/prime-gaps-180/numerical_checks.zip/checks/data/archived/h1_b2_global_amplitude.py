"""Uniform bound for the native B2 trial divided by its 39 root factors.

The native coordinate midpoints sum to (J+39/2)S/N. On each clipped
cubic knot span, positive Bernstein weights reduce the radial estimate
to its four controls. This includes both one-sided values at repeated
interior knots. The three increasing component caps and common outer
and B2 restrictions select either no coefficients or one of three suffixes.
"""
import argparse
import ast
from fractions import Fraction as Q
from functools import cache
from hashlib import sha256
import json
from math import ceil
from pathlib import Path
import struct
from zipfile import ZipFile


HERE = Path(__file__).resolve().parent
S = Q(1399373467, 1312494500)
N = 131072
NATIVE_TAIL_AMPLITUDE = 728975  # J >= 102994, all maximum-fragment classes
SIGS = ((), (2,), (3,), (4,), (2,2), (5,), (2,3), (6,), (2,4), (3,3), (2,2,2))
VECTOR_SHA = 'ae58b3d018eae9904fd2c6e869ba6f70cf77fcb982284a487ca9b6f446d2f624'
SHAPE_SHA = '528980a8ddbf32c61dd756cdeb365fe25a3805b06b97c8071539047638c3be41'


@cache
def source():
    archive = HERE / 'ts_s39a6.npz'
    shape = (HERE / 'h1_band_retrained.json').read_bytes()
    assert sha256(shape).hexdigest() == SHAPE_SHA and sha256(archive.read_bytes()).hexdigest() == VECTOR_SHA
    knots = tuple(map(Q, json.loads(shape)['shape_spec']['knots']))
    assert len(knots) == 34 and knots[-1] == S and tuple(sorted(knots)) == knots
    with ZipFile(archive) as z:
        data = z.read('vector.npy')
    assert data[:8] == b'\x93NUMPY\x01\x00'
    start = 10 + int.from_bytes(data[8:10], 'little')
    header = ast.literal_eval(data[10:start].decode('ascii'))
    assert header == {'descr': '<f8', 'fortran_order': False, 'shape': (8910,)}
    values = tuple(map(Q, struct.unpack('<8910d', data[start:])))
    # All three component caps share the outer schedule. Their active set,
    # including after the common B2 restriction, is a suffix or empty.
    @cache
    def row(suffix, pair, sig):
        return [sum(values[((pair*3+c)*11+sig)*30+d] for c in range(suffix,3))
                for d in range(30)]
    return knots, row


def controls(knots, span, left, right):
    """Cubic Bernstein coefficients of each active B-spline on [left,right]."""
    def basis(i, x):
        @cache
        def value(j, degree):
            if degree == 0:
                return Q(j == span)
            a = knots[j+degree]-knots[j]
            b = knots[j+degree+1]-knots[j+1]
            return ((x-knots[j])/a*value(j,degree-1) if a else 0) + (
                (knots[j+degree+1]-x)/b*value(j+1,degree-1) if b else 0)
        return value(i, 3)
    rows = []
    for i in range(span-3,span+1):
        a, b, c, d = (basis(i,left+(right-left)*j/3) for j in range(4))
        u, v = 27*b-8*a-d, 27*c-a-8*d
        rows.append((a,(2*u-v)/18,(2*v-u)/18,d))
    for column in zip(*rows):
        assert min(column) >= 0 and sum(column) == 1
    return rows


def radial_blocks(minimum_j, maximum_j, first_component, subdivisions=1):
    """Yield the four exact signed controls, including the angular 39 scale."""
    assert 0 <= minimum_j <= maximum_j <= N-40
    assert first_component is None or first_component in range(3)
    knots, row = source()
    minimum = (minimum_j+Q(39,2))*S/N
    maximum = (maximum_j+Q(39,2))*S/N
    panels = []
    for span in range(3,30):
        left, right = max(minimum,knots[span]), min(maximum,knots[span+1])
        # At a repeated internal knot use its right-hand span (as in BSpline).
        if left > right or knots[span] == knots[span+1] or left == knots[span+1]:
            continue
        points = [left+(right-left)*i/subdivisions for i in range(subdivisions+1)]
        panels.extend((span,a,b) for a,b in zip(points,points[1:]))
    for span,left,right in panels:
        control = controls(knots,span,left,right)
        for suffix in range(3) if first_component is None else (first_component,):
            block = {}
            for pair in range(9):
                for j,sig in enumerate(SIGS):
                    coeff = row(suffix,pair,j)[span-3:span+1]
                    scale = 39**(sum(sig)-len(sig))
                    block[pair,j] = tuple(scale*sum(c*v for c,v in zip(coeff,col))
                                          for col in zip(*control))
            yield right, block


@cache
def radial_upper(minimum_j=102994, maximum_j=N-40, first_component=None):
    """Integer M[a][b][j] for the absolute radial coefficient of SIGS[j].

    Includes 39**(sum(sig)-len(sig)); excludes both endpoint shapes, the
    core power-sum product and all 39 coordinate root factors. Endpoint
    indices 0,1,2 select 1,(t/S)^2,1/(1+300*t), respectively.
    """
    out = [[[0]*len(SIGS) for _ in range(3)] for _ in range(3)]
    for _, block in radial_blocks(minimum_j,maximum_j,first_component):
        for (pair,j), values in block.items():
            row = out[pair//3][pair%3]
            row[j] = max(row[j],ceil(max(map(abs,values))))
    return tuple(tuple(tuple(row) for row in a) for a in out)


def amplitude_upper(minimum_j=102994, maximum_j=N-40, first_component=None):
    """Integer upper bound simultaneously for every cap and J >= minimum_j."""
    maximum = Q(0)
    for right,block in radial_blocks(minimum_j,maximum_j,first_component,subdivisions=8):
        positive, negative = [Q(0)]*4, [Q(0)]*4
        for (pair,j),values in block.items():
            squares = (pair//3 == 1) + (pair%3 == 1)
            degree = sum(SIGS[j])
            total = degree+2*squares
            # If z is the core sum, prod_e sum_i t_i^e <= z^degree.
            # Maximize z^degree times the squared endpoint factors on
            # the simplex by weighted AM-GM. Other shapes are at most 1.
            angular = (right**total*degree**degree*4**squares
                       / (total**total*S**(2*squares)))
            for h,v in enumerate(values):
                if v > 0:
                    positive[h] += angular*v
                else:
                    negative[h] -= angular*v
        # Each endpoint/angular factor is nonnegative. The four signed
        # control values are combined with common convex Bernstein weights.
        maximum = max(maximum,*positive,*negative)
    return ceil(maximum)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--minimum-j', type=int, default=102994)
    parser.add_argument('--maximum-j', type=int, default=N-40)
    parser.add_argument('--first-component', type=int, choices=range(3),
                        help='Restrict to a known active suffix starting at this component.')
    parser.add_argument('--radial', action='store_true', help='Emit the individual coefficient ceilings as JSON.')
    args = parser.parse_args()
    bounds = (args.minimum_j,args.maximum_j,args.first_component)
    if args.radial:
        print(json.dumps(radial_upper(*bounds)))
    else:
        bound = amplitude_upper(*bounds)
        if bounds == (102994,N-40,None):
            assert bound == NATIVE_TAIL_AMPLITUDE
        print(bound)
