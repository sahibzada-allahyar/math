// One nonnegative native convolution. GMP multiplies packed integer digits
// exactly. The returned doubles round coefficients down; the Python wrapper
// propagates the two input quantizations and the final relative rounding.
#include <gmp.h>
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <limits>
#include <vector>

static_assert(sizeof(mp_limb_t) == sizeof(uint64_t) && GMP_NUMB_BITS == 64,
              "This fast path requires 64-bit GMP limbs without nails.");

static void pack(mpz_t value, const double *a, int n, int scale, size_t words) {
    mp_ptr data = mpz_limbs_write(value, n * words);
    std::fill(data, data + n * words, 0);
    for (int i = 0; i < n; ++i) {
        if (!a[i]) continue;
        int e;
        auto mantissa = static_cast<uint64_t>(std::ldexp(std::frexp(a[i], &e), 53));
        int shift = e + scale - 53;
        if (shift < 0) {
            data[i * words] = shift > -53 ? mantissa >> -shift : 0;
        } else {
            size_t slot = i * words + shift / 64;
            int bits = shift % 64;
            data[slot] = mantissa << bits;
            if (bits > 11) data[slot+1] = mantissa >> (64-bits);
        }
    }
    mpz_limbs_finish(value, n * words);
}

extern "C" void positive_convolution(const double *a, int na, const double *b,
               int nb, double *out, int n, int sa, int sb, int bits) {
    assert(n > 0 && na > 0 && nb > 0 && bits >= 96 && bits <= 512);
    // A digit is < 2^(2*bits)*min(na,nb), including every retained diagonal.
    int sz = std::min(na,nb);
    size_t words = (2*bits + 32-__builtin_clz(static_cast<unsigned>(sz)) + 63)/64;
    mpz_t x,y,prod;
    mpz_inits(x,y,prod,nullptr);
    pack(x,a,na,sa,words); pack(y,b,nb,sb,words);
    mpz_mul(prod,x,y);
    mp_srcptr data = mpz_limbs_read(prod);
    size_t len = mpz_size(prod);
    for (int j = 0; j<n; ++j) {
        size_t start = j * words, stop = std::min(len,start+words);
        while (stop>start && !data[stop-1]) --stop;
        if (stop<=start) {out[j]=0.;continue;}
        auto hi = data[stop-1];
        int lead = 64-__builtin_clzll(hi);
        int count = int((stop-start-1)*64)+lead;
        int shift = std::max(0,count-53);
        size_t slot = start + shift/64;
        int s = shift%64;
        uint64_t m = data[slot] >> s;
        if (s && slot+1<stop) m |= data[slot+1] << (64-s);
        assert(m < (UINT64_C(1)<<53));
        double v = std::ldexp(static_cast<double>(m),shift-sa-sb);
        assert(std::isfinite(v));
        out[j] = v>0 && v<=std::numeric_limits<double>::min() ? std::nextafter(v,0.) : v;
    }
    mpz_clears(x,y,prod,nullptr);
}

// Integrate a group of labelled bilinear terms against a positive moment row.
// centre/radius fields are stored contiguously as (channel,n). A balanced
// reduction over j has at most 18 additions on every path. See Python notes.
extern "C" void gram_scalar(int n, const double *a, const double *ra,
 const double *b, const double *rb, const int32_t *left, const int32_t *right,
 int m, const int32_t *indices, int count, const double *kernel,double rel,
 double abs_error,const double *weight,const double *wr,double *answer) {
    assert(n>0 && n<=(1<<18) && count>0 && count<=n && m>0 && m<=4096);
    std::vector<double> z(count), rad(count);
    double arithmetic=std::ldexp(double(m+64),-51);
    constexpr double bound=0x1p80;
    assert(rel>=0 && rel<bound && abs_error>=0 && abs_error<bound);
    for(int p=0;p<count;++p) {
        int j=indices[p];
        double mid=0.,err=0.,magnitude=0.;
        for(int t=0;t<m;++t) {
            size_t l=size_t(left[t])*n+j,r=size_t(right[t])*n+j;
            double x=a[l],y=b[r],v=x*y;
            assert(std::abs(x)<bound && std::abs(y)<bound && ra[l]>=0 && rb[r]>=0 && ra[l]<bound && rb[r]<bound);
            mid+=v; magnitude+=std::abs(v);
            err+=ra[l]*(std::abs(y)+rb[r])+std::abs(x)*rb[r];
        }
        double k=kernel[j], kr=k*rel+abs_error;
        double w=weight[j], werr=wr[j];
        assert(k>=0 && k<bound && std::abs(w)<bound && werr>=0 && werr<bound);
        double v=k*w,er=std::abs(w)*kr+werr*(k+kr);
        z[p]=mid*v;
        rad[p]=err*(std::abs(v)+er)+magnitude*er+
               arithmetic*((magnitude+err)*(std::abs(v)+er))+0x1p-480; // Covers subnormals under the explicit operand ceilings.
    }
    for(int stride=1;stride<count;stride*=2) {
        for(int p=0;p+stride<count;p+=2*stride) {
            z[p]+=z[p+stride];rad[p]+=rad[p+stride];
        }
    }
    answer[0]=z[0];answer[1]=std::nextafter(rad[0]*(1+std::ldexp(1.,-36)),INFINITY);
    assert(std::isfinite(answer[0]) && std::isfinite(answer[1]));
}
