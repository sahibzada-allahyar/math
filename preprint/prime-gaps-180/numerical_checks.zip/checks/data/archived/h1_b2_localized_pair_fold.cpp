#include <algorithm>
#include <cstdint>
#include <vector>

using wide=unsigned __int128;

// Each array entry is encoded by its low then high 64-bit limb. The caller
// checks an ordinary integer bound on the total, including all other full
// maximum classes, before accumulating into the shared output.
extern "C" void add_pair_fold(int n,int nt,int nr,int rt,int full_lo,int full_hi,
                             const uint64_t* coefficients,const int* left,const int* right,
                             uint64_t* sums) {
    std::vector<wide> prefix(static_cast<size_t>(n)*(nt+1));
    for (int b=0;b<n;++b) {
        auto* p=prefix.data()+static_cast<size_t>(b)*(nt+1);
        const auto* c=coefficients+static_cast<size_t>(b)*nt*2;
        for (int y=0;y<nt;++y)
            p[y+1]=p[y]+(static_cast<wide>(c[2*y+1])<<64)+c[2*y];
    }
    // Access the output by limbs to avoid an alignment or aliasing
    // assumption about the external NumPy array.
    for (int k=0;k<nr;++k) {
        std::vector<wide> row(rt);
        for (int b=std::max(0,full_lo-k);b<std::min(n,full_hi-k);++b) {
            const auto* p=prefix.data()+static_cast<size_t>(b)*(nt+1);
            const int l=left[k+b],r=right[k+b];
            if (l>=r) continue;
            for (int t=std::max(0,l-nt+1);t<std::min(rt,r);++t) {
                const int a=std::max(0,l-t),z=std::min(nt,r-t);
                if (a<z) row[t]+=p[z]-p[a];
            }
        }
        auto* out=sums+static_cast<size_t>(k)*rt*2;
        for (int t=0;t<rt;++t) {
            const wide val=row[t]+(static_cast<wide>(out[2*t+1])<<64)+out[2*t];
            out[2*t]=static_cast<uint64_t>(val);
            out[2*t+1]=static_cast<uint64_t>(val>>64);
        }
    }
}
