"""Parallel case inventory for localized B2 middle-gate pair images."""
import argparse
from fractions import Fraction as Q
from hashlib import sha256
import json
from pathlib import Path
from types import SimpleNamespace

from flint import ctx

import h1_b2_localized_middle_pair as P
from h1_b2_localized_middle_sweep import identity,write


HERE=Path(__file__).resolve().parent


def collect(out,manifest):
    totals={}
    complete=0
    for cap,edge in manifest['tasks']:
        v=totals.setdefault(edge,dict(count=0,raw=Q(0)))
        p=out/f'{cap}_{edge}.json'
        if p.exists():
            d=json.loads(p.read_text())
            assert d['pin']==manifest['pin']
            r=d['result']
            assert r['retained'][1]==cap and r['edges'][0]==edge
            v['count']+=1;v['raw']+=Q(r['raw_upper']);complete+=1
    return dict(complete=complete,expected=len(manifest['tasks']),
                raw_subtotal=str(sum(v['raw'] for v in totals.values())),
                edges={e:dict(complete=r['count']==13,cases=r['count'],raw_upper=str(r['raw']))
                       for e,r in totals.items()})


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--directory',type=Path,required=True)
    p.add_argument('--summary',action='store_true');p.add_argument('--output',type=Path)
    p.add_argument('--banks',type=Path,nargs='+')
    p.add_argument('--gates',type=Path);p.add_argument('--dots',type=Path);p.add_argument('--fold',type=Path)
    p.add_argument('--shard',default='0/1')
    for n,d in [('radial',256),('tail',30000),('micro',1000),('dust',150000),('edge-group',4),('count',8),('radius',5)]:
        p.add_argument('--'+n,type=int,default=d)
    p.add_argument('--spectral-tail',type=float,default=.0625)
    p.add_argument('--beta',type=float,default=32.);p.add_argument('--eta',type=float,default=16.)
    args=p.parse_args();ctx.prec=128;out=args.directory;out.mkdir(parents=True,exist_ok=True)
    manifest_path=out/'pair-manifest.json'
    if args.summary:
        d=collect(out,json.loads(manifest_path.read_text()))
        if args.output:write(args.output,d)
        print(json.dumps(d));return
    names=('radial','tail','micro','dust','edge_group','count','radius','spectral_tail','beta','eta')
    options={n:getattr(args,n) for n in names}
    g=P.P.Gates(args.gates);pr=P.P.Projection(g,args.radial,args.tail,[args.dust]*3,args.edge_group,True)
    m=P.D.Native()
    geoms={u:geom for _,u,geom,_ in P.D.retained_groups(m,pr.cap_ends_projection)}
    banks={v:next(p/f'cap-{v}.npz' for p in args.banks if (p/f'cap-{v}.npz').exists()) for v in set(geoms.values())}
    pairs=sorted(((int(c),int(e)) for c in geoms for e in g.edges[pr.middle]),
                 key=lambda v:(abs(v[1]-330000),abs(v[0]-39058),v))
    sources=['h1_b2_localized_middle_pair.py','h1_b2_localized_pair_atoms.py',
             'h1_b2_localized_pair_fold.cpp','h1_b2_localized_spectral_tail.py','h1_b2_localized_diagonal.py',
             'h1_b2_projected_fourier.py','h1_b2_projected_gram.py','h1_b2_projected_site_density.py',
             'h1_b2_middle_dust_projection.py','h1_b2_middle_site_law.py','h1_b2_projected_dots.c',
             'h1_b2_localized_moments.py','h1_b2_quotient_inputs.py','h1_b2_finite_quotient.py',Path(__file__).name]
    base=dict(parameters=options,code={n:identity(HERE/n) for n in sources},
              gates=identity(args.gates),tasks=pairs)
    pin=sha256(json.dumps(base,sort_keys=True).encode()).hexdigest()
    manifest=dict(pin=pin,**base)
    if manifest_path.exists():assert json.loads(manifest_path.read_text())['pin']==pin
    else:write(manifest_path,manifest)
    i,n=map(int,args.shard.split('/'));assert 0<=i<n
    for k,(cap,edge) in enumerate(pairs):
        if k%n!=i:continue
        path=out/f'{cap}_{edge}.json'
        if path.exists():
            assert json.loads(path.read_text())['pin']==pin
            continue
        cfg=SimpleNamespace(**options,cap=cap,edge=edge,gates=args.gates,fold=args.fold,dots=args.dots,bank=banks[geoms[cap]])
        r=P.run(cfg,(g,pr,m))
        write(path,dict(pin=pin,result=r))
        print(cap,edge,r['raw_upper'],r['seconds'],r['peak_mb'],flush=True)


if __name__=='__main__':main()
