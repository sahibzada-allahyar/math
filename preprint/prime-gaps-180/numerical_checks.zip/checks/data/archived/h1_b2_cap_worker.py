"""Independent signed cap increments for the original quotient and portable positive debit."""
import argparse
from fractions import Fraction as Q
from hashlib import sha256
import json
from pathlib import Path
import sys
import time

import numpy as np
import h1_b2_quotient_poly as P
from h1_b2_quotient_contract import Integral,Laws,configure,contract,empty
from h1_b2_quotient_inputs import COUNT,SIGS,STEP,cap_cdf,exact_float_bounds,radial_rows,site_fields


HERE=Path(__file__).resolve().parent
ROLES=('full','core','a','b','pair')
FORMS=ROLES+('debit_core','debit_a','debit_b')
GEOMETRY_KEYS=('core','a','b','pair')


def digest(path):
    h=sha256()
    with path.open('rb') as f:
        while chunk:=f.read(8*1024*1024):h.update(chunk)
    return h.hexdigest()


def write_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.tmp.json')
    tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)


def delta(new,old):return P.ball_add(new,(-old[0],old[1]))


def cap_forms(law,last,core,changed,first,weights,pair,full,bank):
    """A single telescoping increment; no other cap's numerical receipt is needed."""
    n=law.n;out={k:Integral() for k in FORMS}
    def add(term,acc,a,b,w):
        ix=np.flatnonzero((w[0][:last+1]!=0)|(w[1][:last+1]!=0))
        if len(ix):term.append((out[acc],a,b,w,ix))
    if changed:
        inc,old=full()
        both=inc if first else P.ball_add(inc,old,2)
        terms=[];add(terms,'full',inc,both,(np.ones(n),np.zeros(n)))
        contract(law,core,2,terms);del terms,inc,old,both
    def roleforms(role):
        terms=[];now,before=bank(role)
        if changed:
            inc=now if first else delta(now,before)
            both=now if first else P.ball_add(now,before)
            if role=='pair':add(terms,role,inc,both,pair)
            else:
                add(terms,role,inc,both,weights['price'])
                add(terms,'debit_'+role,inc,both,weights['debit'])
        if not first and role!='pair':
            add(terms,role,before,before,weights['jump']);add(terms,'debit_'+role,before,before,weights['debit_jump'])
        return terms
    if changed:contract(law,core,0,roleforms('pair'))
    contract(law,core-1,2,roleforms('core'))
    contract(law,core,1,roleforms('a')+roleforms('b'))
    return {k:[str(v.low),str(v.high)] for k,v in out.items()}


def full_increment(geometry,c):
    lo_old,hi_old=empty((99,COUNT));lo_inc,hi_inc=empty((99,COUNT))
    seen_old=np.zeros((3,COUNT),bool);seen_inc=np.zeros_like(seen_old)
    for g,rows in geometry.items():
        if g<c:continue
        seen=seen_inc if g==c else seen_old
        for comp,a,b in rows:
            assert not seen[comp,a:b].any();seen[comp,a:b]=True
    assert not (seen_inc&seen_old).any()
    for comp in range(3):
        used=seen_old[comp]|seen_inc[comp]
        if not used.any():continue
        ix=np.flatnonzero(used);first,last=int(ix[0]),int(ix[-1])+1
        lo,hi=(v.reshape(99,last-first) for v in radial_rows(comp,first,last))
        for mask,l,h in ((seen_old[comp],lo_old,hi_old),(seen_inc[comp],lo_inc,hi_inc)):
            # Contiguous runs avoid advanced-index copies over all 99 rows.
            e=np.flatnonzero(np.diff(np.r_[False,mask,False]))
            for a,b in zip(e[::2],e[1::2]):
                l[:,a:b]=P.down(l[:,a:b]+lo[:,a-first:b-first]);h[:,a:b]=P.up(h[:,a:b]+hi[:,a-first:b-first])
    return P.split_bounds((lo_inc,hi_inc)),P.split_bounds((lo_old,hi_old))


def manifest(root):
    raw=(root/'manifest.json').read_bytes();data=json.loads(raw);assert data['version']==1
    assert len(data['caps'])==len(set(data['caps']))==37 and data['caps']==sorted(data['caps'],reverse=True)
    assert len(data['geometry'])==len(data['banks'])==9
    return data,sha256(raw).hexdigest()


def validate(root,data,filenames):
    for name in filenames:
        p=root/name;assert p.is_file() and digest(p)==data['files'][name],f'SHA-256 mismatch: {name}'


def calculate(root,c,lib,output):
    since=time.monotonic();m,mh=manifest(root);row=m['rows'][str(c)];geo={int(k):v for k,v in m['geometry'].items()}
    banks=m['banks'];geoms={v for v in (row['bank'],row['prior_bank']) if v}
    needed=[m['banks'][str(v)] for v in geoms]+[row['price_file']]
    validate(root,m,[*m['common'],*needed]);configure(lib,256)
    positions=m['caps'];i=positions.index(c);first=i==0;changed=c in geo
    assert first==(row['prior_bank'] is None)
    assert row['bank']==min(k for k in geo if k>=c)
    assert first or row['prior_bank']==min(k for k in geo if k>=positions[i-1])
    assert changed==(row['bank']!=row['prior_bank'])
    law=Laws(site_fields(),cap_cdf(c),exact_float_bounds(100*STEP),37,SIGS)
    with np.load(root/row['price_file'],allow_pickle=False)as z:
        weights={k:(z[k+'0'],z[k+'1']) for k in ('price','jump','debit','debit_jump')}
    with np.load(root/'pair.npz',allow_pickle=False)as z:pair=z['v0'],z['v1']
    def get(g,role):
        with np.load(root/banks[str(g)],allow_pickle=False)as z:return z[role+'0'],z[role+'1']
    def fields(role):
        now=get(row['bank'],role);before=None if first else get(row['prior_bank'],role) if changed else now
        return now,before
    forms=cap_forms(law,row['last'],37,changed,first,weights,pair,lambda:full_increment(geo,c),fields)
    receipt=dict(version=1,manifest_sha256=mh,cap=c,prior_cap=None if first else positions[i-1],
          compiled_library_sha256=digest(lib),bits=P.BITS,forms=forms,elapsed_seconds=round(time.monotonic()-since,2))
    write_json(output,receipt)
    print(json.dumps(dict(cap=c,seconds=receipt['elapsed_seconds'],complete=True)),flush=True)


def combined(forms):
    v={k:[sum(Q(row[k][i]) for row in forms) for i in range(2)] for k in FORMS}
    mass=v['full'];assert 0<mass[0]<=mass[1]
    lower=37*v['core'][0]+v['a'][0]+v['b'][0]-v['pair'][1]
    upper=37*v['core'][1]+v['a'][1]+v['b'][1]-v['pair'][0]
    def ratio(l,h):
        choices=[x/y for x in (l,h) for y in mass];return [str(min(choices)),str(max(choices))]
    debit=[sum((37 if k=='debit_core' else 1)*v[k][i] for k in ('debit_core','debit_a','debit_b')) for i in range(2)]
    return dict(raw_forms={k:list(map(str,a)) for k,a in v.items()},quotient=ratio(lower,upper),positive_debit=ratio(*debit))


def reduce(root,receipts,output):
    m,mh=manifest(root);rows=[];lib=None
    for i,c in enumerate(m['caps']):
        row=json.loads((receipts/f'cap-{c}.json').read_text())
        assert row['version']==1 and row['manifest_sha256']==mh and row['cap']==c and row['bits']==256
        assert row['prior_cap']==(m['caps'][i-1] if i else None) and set(row['forms'])==set(FORMS)
        assert all(Q(l)<=Q(h) for l,h in row['forms'].values())
        lib=lib or row['compiled_library_sha256'];assert row['compiled_library_sha256']==lib
        rows.append(row)
    result=combined([v['forms'] for v in rows])
    result.update(version=1,scope='all 37 original native B2 caps, 100^39-scaled raw units, positive scalar cover debit',
                  manifest_sha256=mh,compiled_library_sha256=lib,caps=m['caps'],receipts=rows)
    write_json(output,result)
    print(json.dumps({k:list(map(float,map(Q,result[k]))) for k in ('quotient','positive_debit')}))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    ls=sub.add_parser('list')
    run=sub.add_parser('run');run.add_argument('--cap',type=int,required=True);run.add_argument('--library',type=Path,required=True)
    run.add_argument('--output',type=Path,required=True)
    red=sub.add_parser('reduce');red.add_argument('--receipts',type=Path,required=True);red.add_argument('--output',type=Path,required=True)
    for which in (ls,run,red):which.add_argument('--root',type=Path,default=HERE)
    a=p.parse_args()
    if a.command=='list':print('\n'.join(map(str,manifest(a.root)[0]['caps'])))
    elif a.command=='run':calculate(a.root,a.cap,a.library.resolve(),a.output)
    else:reduce(a.root,a.receipts,a.output)
