"""Directed endpoint diagonal on a full-radius, retained-maximum gate group."""
import argparse
import ctypes
from fractions import Fraction as Q
import json
from math import ceil
from pathlib import Path
from time import monotonic
from types import SimpleNamespace

from flint import arb,arb_mat,ctx
import numpy as np

import h1_b2_projected_fourier as F
from h1_b2_finite_quotient import Native
from h1_b2_localized_operator import retained_groups,native_price_square_upper
from h1_b2_localized_moments import role_moments
from h1_b2_quotient_inputs import STEP
from h1_b2_radial_rounding import captured


P=F.P
SCALE=1<<50


def bare_atoms(density,keys,last,width,owner_weight=0):
    starts=sorted(set(range(0,last+1,width))|({27971} if last>=27971 else set()))
    js=np.arange(last+1,dtype=np.int64)
    if owner_weight:
        assert 1<=owner_weight<=100000 and last<=130964
        # Insert the exact reciprocal weight 1/(1+owner_weight*j/L).
        # Denominators are exact integers; round the positive products
        # and block additions outward before packing the dyadic atoms.
        w=np.nextafter(130964./(130964+owner_weight*js),np.inf)
        rows=np.r_[np.add.reduceat((width-js%width)*w,starts),np.add.reduceat((js%width)*w,starts)]
        rows=np.where(rows==0,0.,np.nextafter(rows*(1+(width+12)*F.U),np.inf))
    else:
        rows=np.r_[np.add.reduceat(width-js%width,starts),np.add.reduceat(js%width,starts)]
    assert len(keys)==len(rows)
    # Positive dyadic integers dominate the exact bare model, independently
    # for each mark/dust atom before any inclusion-exclusion is applied.
    unit=F.upper_float(F.ball(100*STEP/width))
    top=np.nextafter(unit*rows,np.inf)
    top[rows==0]=0.
    val=np.nextafter(density*top[None,None,:,None],np.inf)
    val[(density==0)|(rows[None,None,:,None]==0)]=0.
    assert val.min()>=0 and val.max()<16
    units=np.ceil(val*SCALE).astype(np.uint64)
    nd,nf,_,nt=units.shape
    out=np.zeros((nd,nf,max(keys)+1,nt),dtype=np.uint64)
    # At most four positive contributions at one (k,l), none exceeding 2^54.
    assert np.bincount(keys).max()<=4
    for d in range(nd):
        for f in range(nf):
            np.add.at(out[d,f],keys,units[d,f])
    # Total, over independent atoms as exact Python integers, bounds every
    # subset sum and every output compensation prefix.
    assert sum(map(int,out.flat))<2**64
    return out


def fold(lib,bare,left,right,full_lo,full_hi,nr,rt):
    n,nt=bare.shape
    prefix=np.zeros((n,nt+1),dtype=np.uint64)
    np.cumsum(bare,axis=1,dtype=np.uint64,out=prefix[:,1:])
    assert sum(map(int,prefix[:,-1]))<2**64
    l=np.ascontiguousarray(left,dtype=np.int32);r=np.ascontiguousarray(right,dtype=np.int32)
    out=np.zeros((nr,rt),dtype=np.uint64)
    lib.fold_bare(n,nt,nr,rt,full_lo,full_hi,prefix.ctypes.data,l.ctypes.data,r.ctypes.data,out.ctypes.data)
    return out


def load_fold(path):
    lib=ctypes.CDLL(str(Path(path).resolve()))
    lib.fold_bare.argtypes=[ctypes.c_int]*6+[ctypes.c_void_p]*4
    lib.fold_bare.restype=None
    return lib


def bare_geometry(g,pr,cap,bank,args,ix,nk):
    _,keys,_,density,dust,group=bank
    last=int(g.lasts[group[0]])
    atoms=bare_atoms(density,keys,last,args.radial,getattr(args,'owner_weight',0))
    max_tail=ceil((last+39)*g.tick/args.tail)+39
    K=np.arange(nk);back=args.radius*args.radial
    low=np.maximum(0,K*args.radial-back)
    lookup=np.minimum(K*args.radial+back,last)//pr.lookup_width
    ga=pr.first[group[0]][lookup,ix]
    gb=g.low[np.minimum(low,last)]+pr.second[group[0]][lookup,ix]
    thresholds=[np.minimum(max_tail+1,np.maximum(0,np.maximum(ga//args.tail+1,(gb-d)//args.tail+1))) for d in dust]
    return dict(cap=cap,atoms=atoms,tops=thresholds,max_tail=max_tail,
                full_lo=max(0,ceil(Q(102994-back,args.radial))),full_hi=(last+back)//args.radial+1)


def group_bank(g,pr,cap,a,b,args):
    # When the retained maximum is below the witnessed edge, only the bare
    # site can witness it. Evaluating at edge=cap gives exactly the same
    # all-dust law and an empty positive-tail support.
    actual=min(a,cap*g.tick)
    data=P.bank(g,pr,cap,actual,b,args.radial,args.tail,args.micro,args.dust,balanced=True)
    if actual<a:
        density=data[3]
        assert not density[:,[1,3]].any() and not density[:,:,:,1:].any()
    return data


def projection_for_edge(g,args):
    if 90000<=args.edge<940000 and args.edge_end is None:
        return P.Projection(g,args.radial,args.tail,[args.dust]*3,args.edge_group,True)
    a=int(np.flatnonzero(g.edges[:-1]==args.edge).item())
    stop=(min(a+args.edge_group,int(np.flatnonzero(g.edges==1350000).item()))
          if args.edge_end is None else int(np.flatnonzero(g.edges==args.edge_end).item()))
    assert a<stop<=len(g.edges)-1
    from h1_two_source_endpoints import stored_frame
    components=stored_frame()['original']['component_limits']
    ends=sorted({int(c) for c,_ in g.limits}|set(components)|set(g.fine[:4]))
    first=[];second=[];groups=[];last=0
    u,v=g.tick.as_integer_ratio()
    for cap in ends:
        hi=int(np.flatnonzero(g.fine==cap).item())
        ids=list(range(last,hi+1));last=hi+1;groups.append(ids)
        assert len({g.lasts[x] for x in ids})==1
        n=g.lasts[hi]//32+1
        ca=np.full(n,10**8,dtype=np.int64);cb=ca.copy()
        for i in ids:
            j,keys,tops=g.tile(i)
            mask=j>=102994
            for key,top in zip(keys,tops):
                jj=j[mask]
                gate=g.gates[key[mask],stop-1]
                live=gate<top[mask]
                j2=jj[live];gg=gate[live];k=j2//32
                hi_tick=np.array([-(-int(x)*u//v) for x in j2],dtype=np.int64)
                np.minimum.at(ca,k,gg);np.minimum.at(cb,k,gg-hi_tick)
        ca=np.minimum.accumulate(ca)[:,None];cb=np.minimum.accumulate(cb)[:,None]
        first.extend([ca]*len(ids));second.extend([cb]*len(ids))
    return SimpleNamespace(middle=np.array([a]),ending=np.array([stop-1]),lookup_width=32,
                           cap_ends_projection=ends,cap_groups=groups,first=first,second=second)


def signed_field_gram(center,radius,field,price,lo,hi,role):
    if role=='core':
        shape=99
        index=(P.SIG_INDEX[:,None,:,None]*len(P.PAIR)+P.END_INDEX[None,:,None,:]).reshape(shape,shape)
    else:
        shape=33
        end=np.asarray([[P.END.index(tuple(sorted((a,b)))) for b in range(3)] for a in range(3)])
        index=(P.SIG_INDEX[:,None,:,None]*len(P.END)+end[None,:,None,:]).reshape(shape,shape)
    vals=[arb(float(x),float(y)) for x,y in zip(center.flat,radius.flat)]
    mat=arb_mat([[vals[j] for j in row] for row in index])
    m,e=field
    # Approximate the *curve* of native vectors by a piecewise linear
    # interpolation, and charge its rigorous coordinatewise remainder once.
    # Convex interpolation of integer-knot vectors leaves their Gram norms
    # subject to the same center-plus-sum-of-squares comparison as splines.
    scores=[]
    for num in (1,4,12):
        knots=np.unique(np.linspace(lo,hi,num+1).round().astype(int))
        controls=m[:,knots].T
        err=np.zeros(shape)
        for a,b in zip(knots,knots[1:]):
            t=np.arange(b-a+1,dtype=float)/(b-a)
            left=m[:,a,None];right=m[:,b,None]
            approx=left*(1-t)+right*t
            # Absolute rather than relative estimate permits cancellation.
            major=12*F.U*(np.abs(left)+np.abs(right))+F.TINY
            dev=np.nextafter(np.abs(m[:,a:b+1]-approx),np.inf)
            dev=np.nextafter(dev+e[:,a:b+1],np.inf)
            err=np.maximum(err,np.max(np.nextafter(dev+major,np.inf),axis=1))
        if len(knots)==1:err=e[:,lo].copy()
        rows=[list(map(F.ball,v)) for v in controls]
        delta=arb_mat([list(map(F.ball,err))])
        e2=(delta*mat*delta.transpose())[0,0].upper()
        assert e2>=0
        def norms(B):
            b=arb_mat(B);z=b*mat*b.transpose()
            ds=[z[j,j].upper() for j in range(len(B))]
            assert all(x>=0 for x in ds)
            return ds
        # The field lies in the convex hull of the knot vectors + a
        # coordinatewise positive error box. All physical angular entries
        # are nonnegative.
        sc=sum(norms(rows)).sqrt()
        for mid in (rows[0],rows[-1],[sum(c)/len(c) for c in zip(*rows)]):
            dif=[[a-b for a,b in zip(v,mid)] for v in rows]
            sc=min(sc,(norms([mid])[0].sqrt()+sum(norms(dif)).sqrt()).upper())
        scores.append(((sc+e2.sqrt())**2).upper())
    return F.upper_float(min(scores)*F.ball(float(price[lo:hi+1].max())))


def price_field(field,price):
    """Pointwise product with a dyadic upper on the absolute native price."""
    w=np.where(price==0,0.,np.nextafter(np.sqrt(price),np.inf))
    m,r=field
    v=m*w
    err=np.nextafter((r*w+2*F.U*np.abs(v))*(1+8*F.U)+F.TINY,np.inf)
    err[:,w==0]=0.
    return v,err


def split_price_upper(gram,error,field,price,lo,hi,role):
    """Charge at most eight dyadic price bands on their actual radial hulls."""
    p=price[lo:hi+1]
    high=float(p.max())
    # Consecutive powers of four in price squared mean factors of two in
    # the absolute price. A noncontiguous band's radial hull is harmless.
    result=[]
    for k in range(8):
        low=0. if k==7 else high*.25
        hits=np.flatnonzero((p>low)&(p<=high))
        if len(hits):
            first,last=lo+int(hits[0]),lo+int(hits[-1])
            weight=np.broadcast_to(p[hits].max(),price.shape)
            result.append(signed_field_gram(gram,error,field,weight,first,last,role))
        high=low
    return F.upper_float(sum(map(F.ball,result)))


def ring_charges(grams,errors,images,price,ranges,capture,price_coupled):
    norm_floor=Q('46.1984860121')
    charges={}
    for role in images:
        err=errors[role]*(1+2**-42)+F.TINY
        exact_price=price_field(images[role],price) if price_coupled else None
        unit=np.ones_like(price)
        raw=[]
        for c,e,(lo,hi) in zip(grams[role],err,ranges):
            if not np.any(c) and np.max(e)<=2*F.TINY:
                raw.append(0.)
                continue
            z=signed_field_gram(c,e,images[role],price,lo,hi,role)
            if exact_price is not None and price[lo:hi+1].min()!=price[lo:hi+1].max():
                z=min(z,signed_field_gram(c,e,exact_price,unit,lo,hi,role))
                if price[lo:hi+1].max()>16*price[lo:hi+1].min():
                    z=min(z,split_price_upper(c,e,images[role],price,lo,hi,role))
            raw.append(z)
        charge=F.upper_float(sum(F.ball(v) for v in raw)/F.ball(capture))
        charges[role]=dict(scaled_upper=charge,panel_bounds_before_capture=raw,
                           fraction_over_norm_floor=F.upper_float(F.ball(charge)/F.ball(norm_floor)))
    return charges


def run(args,context=None):
    since=monotonic();ctx.prec=128
    if args.dots:F.use_dots(args.dots)
    lib=load_fold(args.fold)
    width,wt=args.radial,args.tail
    assert width<=512 and args.radius>=1
    if context is None:
        g=P.Gates(args.gates)
        pr=projection_for_edge(g,args)
        model=Native()
    else:g,pr,model=context
    gr=next(row for row in retained_groups(model,pr.cap_ends_projection) if row[1]==args.cap)
    lower,upper,geometry,classes=gr
    price=native_price_square_upper(model,classes)
    roles=('core','a') if args.role=='singles' else (args.role,)
    with np.load(args.bank,allow_pickle=False) as f:
        meta=json.loads(str(f['meta']))
        # The bank key is a geometry cutoff from the descending native sweep.
        assert int(meta['caps'][-1]['cap'])==geometry
        images={r:(f[r+'0'],f[r+'1']) for r in roles}
    ix=np.flatnonzero(g.edges[pr.middle]==args.edge).item()
    a,b=int(g.edges[pr.middle[ix]]),int(g.edges[pr.ending[ix]+1])
    current=group_bank(g,pr,upper,a,b,args)
    n,keys,_,density,dust,group=current
    last=int(g.lasts[group[0]]); k,fields=F.site_fields(last,width,True)
    assert np.array_equal(k,keys)
    nt=ceil((last+39)*g.tick/wt)+39
    # Full radius is certified via all 39 artificial labels. Removing one
    # label increases the discrepancy for the retained sum by less than w.
    back=args.radius*width
    retback=(args.radius+1)*width
    full_hi=(last+back)//width+1
    ret_lo=max(0,ceil(Q(lower-retback,width)))
    ret_hi=min(full_hi,(last+retback)//width+1)
    panels=[]
    j=ret_lo
    while j<ret_hi:
        size=(min(args.count,getattr(args,'terminal_count',args.count))
              if width*j>=126000 else args.count)
        assert size>=1
        end=min(ret_hi,j+size)
        panels.append((j,end))
        j=end
    # Aliases add positive squared-field contributions after the flag
    # differences. It suffices to contain all single-site and output labels.
    # A blind 2x padding crosses 4096 at the largest native ceilings and
    # would put a needless part of the unweighted test below 2^-150.
    need=F.pow2(max(n,full_hi))
    nk=min(F.pow2(max(n,full_hi)*args.period),max(need,args.period*F.pow2((model.n-1)//width)))
    ny=F.pow2(nt*args.period+1)
    geometries=[bare_geometry(g,pr,upper,current,args,ix,nk)]
    if not args.same_full_only:
        for cap in pr.cap_ends_projection:
            if cap<=upper:continue
            if cap*g.tick<=a:continue
            bank=group_bank(g,pr,cap,a,b,args)
            geometries.append(bare_geometry(g,pr,cap,bank,args,ix,nk))
    assert sum(sum(map(int,h['atoms'].flat)) for h in geometries)<2**64
    sx=F.tilted_axis(float(np.exp(-args.beta*float(STEP)*width)),nk)
    sy=F.tilted_axis(float(np.exp(args.eta*wt/2624990)),ny)
    tilt=sx[:n,None]*sy[:density.shape[-1]];comp=1/(sx[:,None]*sy)
    grams={r:np.zeros((len(panels),len(P.ANG),len(P.PAIR) if r=='core' else len(P.END))) for r in roles}
    errors={r:np.zeros_like(x) for r,x in grams.items()}
    shape=nk,ny
    mult=np.ones(ny//2+1)*2;mult[0]=mult[-1]=1
    stages=0
    require=3 if lower>=0 and group[0] else 1
    for layer in range(len(dust)):
        sgn=-1 if layer+1<len(dust) else 1
        for flags in range(4):
            if flags&~require:continue
            rf=[v for v in range(4) if not v&~flags]
            signed=sgn*(-1)**((flags^require).bit_count())
            mask=np.zeros((ret_hi,nt+1),dtype=np.uint64)
            for bank in geometries:
                # At a strictly larger full maximum, only the bare site can
                # witness that class's lower crossing.
                bf=[v for v in range(4) if ((v&1)&~flags)==0 and (bank['cap']==upper or (v&2))]
                bare=bank['atoms'][:layer+1,bf].sum(axis=(0,1),dtype=np.uint64)
                tops=bank['tops']
                if sgn<0:left,right=tops[layer+1],tops[layer]
                else:left,right=tops[layer],np.full(nk,bank['max_tail']+1,dtype=np.int32)
                mask+=fold(lib,bare,left,right,bank['full_lo'],bank['full_hi'],ret_hi,nt+1)
            live=[i for i,(lo,hi) in enumerate(panels) if mask[lo:hi].any()]
            if not live:continue
            data=density[:layer+1,rf].sum(axis=(0,1))
            trans=[];radii=[]
            for row in fields:
                z=np.zeros((n,data.shape[-1]));np.add.at(z,keys,row[:,None]*data)
                ft,re=F.transform(z*tilt,shape,(width+4*len(dust)+180)*F.U)
                trans.append(ft);radii.append(re)
            weights=[];ew=[]
            for i in live:
                lo,hi=panels[i];w=np.zeros(shape)
                w[lo:hi,:nt+1]=mask[lo:hi].astype(float)/SCALE*comp[lo:hi,:nt+1]*signed
                ft,re=F.transform(w,shape,20*F.U)
                weights.append((ft.reshape(nk,-1).conj()*mult/(nk*ny)).ravel())
                ew.append(2*re/(nk*ny)+F.TINY)
            t,rs,ww,we=map(np.asarray,(trans,radii,weights,ew))
            for r in roles:
                if getattr(args,'spectral_tail',0):
                    from h1_b2_localized_spectral_tail import moments
                    cm,er=moments(t,rs,ww,we,r,args.spectral_tail)
                else:cm,er=role_moments(t,rs,ww,we,r)
                errors[r][live]+=er+4*F.U*(np.abs(grams[r][live])+np.abs(cm))+F.TINY
                grams[r][live]+=cm
            stages+=1
    ranges=[(max(lower,lo*width-retback,0),min(last,(hi-1)*width+retback)) for lo,hi in panels]
    capture=captured(width,args.radius)[0]
    if getattr(args,'moment_cache',None):
        import os
        path=Path(args.moment_cache);tmp=path.with_suffix(f'.{os.getpid()}.part')
        with tmp.open('wb') as out:
            np.savez(out,ranges=np.asarray(ranges),cap=args.cap,edge=args.edge,geometry=geometry,
                     capture=str(capture),owner_weight=getattr(args,'owner_weight',0),
                     spectral_tail=getattr(args,'spectral_tail',0),price=price,
                     **{k+s:v[k] for k in roles for s,v in (('0',grams),('1',errors))})
        tmp.replace(path)
    charges=ring_charges(grams,errors,images,price,ranges,capture,getattr(args,'price_coupled',False))
    return dict(scope='Directed localized single-erasure diagonal over every radial panel of the specified retained maximum and edge group, including every listed full maximum.',
                role=args.role,retained_cap=[lower,upper],covered_full_caps=[h['cap'] for h in geometries],field_geometry=geometry,
                native_field_bits=meta['bits'],native_field_source=meta['source'],edges=[a,b],full_J=[102994,last],
                retained_J=[ranges[0][0],ranges[-1][1]],panels=len(panels),stages=stages,
                torus=list(shape),radial=width,tail=wt,micro=args.micro,dust=args.dust,
                balanced_radius=args.radius,owner_weight=getattr(args,'owner_weight',0),
                price_coupled=getattr(args,'price_coupled',False),
                terminal_count=getattr(args,'terminal_count',args.count),
                spectral_tail_cutoff=getattr(args,'spectral_tail',0),
                charges=charges,seconds=round(monotonic()-since,3))


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--gates',type=Path,required=True);ap.add_argument('--bank',type=Path,required=True)
    ap.add_argument('--fold',type=Path,required=True);ap.add_argument('--dots',type=Path)
    ap.add_argument('--role',choices=('a','b','core','singles'),default='a')
    ap.add_argument('--same-full-only',action='store_true')
    ap.add_argument('--cap',type=int,default=78116);ap.add_argument('--edge',type=int,default=290000)
    ap.add_argument('--edge-end',type=int)
    for name,default in [('radial',128),('tail',15000),('micro',1000),('dust',150000),
                         ('edge-group',4),('radius',5),('period',2),('count',12)]:
        ap.add_argument('--'+name,type=int,default=default)
    ap.add_argument('--beta',type=float,default=38.);ap.add_argument('--eta',type=float,default=22.)
    ap.add_argument('--spectral-tail',type=float,default=0.)
    ap.add_argument('--owner-weight',type=int,default=0)
    ap.add_argument('--price-coupled',action='store_true')
    ap.add_argument('--moment-cache',type=Path)
    ap.add_argument('--terminal-count',type=int,default=12)
    ap.add_argument('--output',type=Path)
    args=ap.parse_args();report=json.dumps(run(args),indent=2,default=int)+'\n'
    if args.output:args.output.write_text(report)
    print(report,end='')
