/* Fixed-order binary64 dot products for the signed Fourier Gram and its radii.
   Build with strict floating-point semantics. The independent output columns
   can be vectorized without changing the summation order in k. */
#include <stddef.h>
#include <string.h>

void projected_dots(size_t rows, size_t count, size_t cols,
                    const double *restrict c, const double *restrict ca,
                    const double *restrict cr, const double *restrict z,
                    const double *restrict za, const double *restrict zr,
                    double *restrict out, double *restrict radius)
{
    memset(out, 0, rows * cols * sizeof(double));
    memset(radius, 0, rows * cols * sizeof(double));
    for (size_t i = 0; i < rows; ++i) {
        double *v = out + i * cols;
        double *r = radius + i * cols;
        for (size_t k = 0; k < count; ++k) {
            const size_t q = i * count + k;
            const double re = c[2*q], im = c[2*q+1];
            const double a = ca[q], e = cr[q];
            for (size_t j = 0; j < cols; ++j) {
                const size_t s = k * cols + j;
                v[j] += re * z[2*s] - im * z[2*s+1];
                r[j] += e * (za[s]+zr[s]) + a * zr[s] + (0x1p-39*a) * za[s];
            }
        }
    }
}
