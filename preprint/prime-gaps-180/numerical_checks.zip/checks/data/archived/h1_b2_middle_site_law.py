"""Directed one-site (total, tail, two mark flags) harmonic rectangle masses."""
from bisect import bisect_left, bisect_right
from fractions import Fraction as Q
from math import ceil, lcm


def ceildiv(a,b):
    return -((-a)//b)


class Step:
    """Constant integer density per unit grid cell and its two primitives."""
    def __init__(self):
        self.value=[]
        self.sum=[0]
        self.sum2=[0]   # Twice the integral of the first primitive.

    def add(self,v):
        self.sum2.append(self.sum2[-1]+2*self.sum[-1]+v)
        self.sum.append(self.sum[-1]+v)
        self.value.append(v)

    def at(self,x,D):
        """D times the first primitive at x/D."""
        if x<=0:
            return 0
        i,r=divmod(x,D)
        return D*self.sum[i]+(r*self.value[i] if r else 0)

    def twice(self,x):
        """Twice the second primitive, at a rational coordinate."""
        if x<=0:
            return Q()
        i=int(x)
        r=x-i
        return self.sum2[i]+2*r*self.sum[i]+(r*r*self.value[i] if r else 0)


class Dickman:
    def __init__(self,A,D,n,scale):
        # Grid-normalized dust cutoff e=A/D. Cell bounds follow from the
        # positive equation x*rho(x/e)=int_[x-e,x] rho(v/e) dv and monotonicity.
        if A<D:
            raise ValueError('Choose grid width at most the smallest dust cutoff.')
        self.low,self.high=Step(),Step()
        previous=scale
        for i in range(n):
            end=(i+1)*D
            if end<=A:
                low=up=scale
            else:
                past_low=D*self.low.sum[i]-self.low.at(end-A,D)
                past_up=D*self.high.sum[i]-self.high.at(end-A,D)
                low=past_low//(i*D)
                up=min(previous,ceildiv(past_up+D*previous,end))
            assert 0<=low<=up<=previous
            self.low.add(low)
            self.high.add(previous)
            previous=up


class TailStep:
    def __init__(self,knots):
        self.knots=knots
        self.value=[]
        self.sum=[0]

    def add(self,v):
        j=len(self.value)
        self.sum.append(self.sum[-1]+v*(self.knots[j+1]-self.knots[j]))
        self.value.append(v)

    def at(self,x):
        if x<=0:
            return 0
        i=bisect_right(self.knots,x)-1
        rem=x-self.knots[i]
        return self.sum[i]+(rem*self.value[i] if rem else 0)


class MiddleSiteLaw:
    """Coordinates supplied in physical gate ticks; returned masses in R units.

    Flag bit 1 records a mark in [edge,next_edge); bit 2 records a mark
    above the lower maximum-class boundary. If lower_cap=0, bit 2 is
    omitted and should be ignored in the final tuple. Endpoint ties have
    measure zero except the explicit zero-tail atom.
    """
    def __init__(self,edge,next_edge,lower_cap,cap,width,stop,bits=96):
        self.width=Q(width)
        e,E,L,c=(Q(x)/self.width for x in (edge,next_edge,lower_cap,cap))
        if not (1<=e<E and 0<=L<c and c>=e):
            raise ValueError('Expected a feasible cap, edge, and mesh.')
        self.scale=1<<bits
        self.n=ceil(Q(stop)/self.width)
        self.D=D=lcm(*(x.denominator for x in (e,E,L,c)))
        self.dust=Dickman(int(e*D),D,self.n,self.scale)
        self.small=Dickman(int(L*D),D,self.n,self.scale) if 0<L<e else None
        ends=sorted({e,c,min(E,c),max(e,L)})
        self.bands=[(int(x*D),int(y*D),(x<E)+2*(bool(L) and x>=L))
                    for x,y in zip(ends,ends[1:]) if x<y]
        self.knots=sorted(set(range(0,(self.n+1)*D,D))|
                          {int(x*D) for x in ends if x<=self.n})
        self.lo=[TailStep(self.knots) for _ in range(4)]
        self.hi=[TailStep(self.knots) for _ in range(4)]
        self._tail_density()

    def _tail_density(self):
        D=self.D
        # Split the grid at the exact mark endpoints. A thin class, even
        # one narrower than the mesh, keeps its true one-jump width.
        for left,right in zip(self.knots,self.knots[1:]):
            low,up=[0]*4,[0]*4
            for a,b,flag in self.bands:
                if right<=a:
                    continue
                if left>=a and right<=b:
                    low[flag]+=self.scale*D
                if left<b:
                    up[flag]+=self.scale*D
                # The integral is affine between translated density knots.
                vals={left,right}
                for shift in (a,b):
                    start=bisect_right(self.knots,left-shift)
                    stop=bisect_left(self.knots,right-shift)
                    vals.update(shift+z for z in self.knots[start:stop])
                for state in range(4):
                    lo,hi=self.lo[state],self.hi[state]
                    if not hi.sum[-1]:
                        continue
                    dest=state|flag
                    low[dest]+=min(lo.at(z-a)-lo.at(z-b) for z in vals)
                    up[dest]+=max(hi.at(z-a)-hi.at(z-b) for z in vals)
            for k in range(4):
                self.lo[k].add(low[k]//right)
                self.hi[k].add(ceildiv(up[k],left) if left else 0)

    @staticmethod
    def _strip(dust,a,b,y0,y1):
        # Exact double integral of the dust step on a<=y+d<=b,
        # y0<=y<=y1, times two. The four primitives must use the same
        # step function for the subtraction.
        F=dust.twice
        return F(b-y0)-F(b-y1)-F(a-y0)+F(a-y1)

    def rectangle(self,total_lo,total_hi,tail_lo,tail_hi):
        """Four pairs (lower,upper), in flag order 0,1,2,3."""
        a,b,l,r=(Q(x)/self.width for x in (total_lo,total_hi,tail_lo,tail_hi))
        if not (0<=a<b<=self.n and 0<=l<r):
            raise ValueError('Rectangle outside prepared total range.')
        r=min(r,b)
        out=[[Q(),Q()] for _ in range(4)]
        if not l:
            def atom(dust):
                def integral(k):
                    def F(x):
                        v=int(x)
                        return k.sum[v]+((x-v)*k.value[v] if x!=v else 0)
                    return Q(F(b)-F(a))/self.scale
                return integral(dust.low),integral(dust.high)
            m=atom(self.dust)
            if self.small:
                s=atom(self.small)
                out[0]=list(s)
                out[2]=[max(Q(),m[0]-s[1]),max(Q(),m[1]-s[0])]
            else:
                out[0]=list(m)
        if l<r:
            first=bisect_right(self.knots,l*self.D)-1
            last=bisect_left(self.knots,r*self.D)
            for j in range(first,last):
                if not any(k.value[j] for k in self.hi):
                    continue
                yl=max(l,Q(self.knots[j],self.D))
                yr=min(r,Q(self.knots[j+1],self.D))
                for side,(dust,tail) in enumerate(((self.dust.low,self.lo),(self.dust.high,self.hi))):
                    strip=self._strip(dust,a,b,yl,yr)/(2*self.scale**2)
                    assert strip>=0
                    for k in range(4):
                        out[k][side]+=strip*tail[k].value[j]
        # Small-dust Lebesgue measure supplies the one dimensional physical
        # unit; every logarithmic jump measure and the flags are dimensionless.
        return [(lo*self.width/2624990,hi*self.width/2624990) for lo,hi in out]


def check(mesh):
    from h1_b2_global_dust_transform import ball,ctx
    ctx.prec=160
    unit=2624990
    tau=Q(1399373467,172031279104000)*unit
    edge=300000
    cap=39058*tau
    law=MiddleSiteLaw(edge,310000,29293*tau,cap,mesh,1300000)
    results={}

    def contains(name,interval,value):
        lo,hi=interval
        assert isinstance(lo,Q) and isinstance(hi,Q) and lo<=hi
        assert ball(lo)<=value<=ball(hi)
        results[name]=dict(low=str(lo),high=str(hi))

    def mass2(a,b,c):
        # Exact integral of 1-log(t/c) on [a,b] contained in [c,2c].
        assert c<=a<b<=2*c
        primitive=lambda x:ball(x)*(2-ball(x/c).log())
        return (primitive(b)-primitive(a))/unit

    a=19912*tau
    w=law.rectangle(a,a+tau,300000,310000)
    assert all(x==(0,0) for j,x in enumerate(w) if j!=1)
    contains('tagged_one_jump',w[1],ball(tau/unit)*ball(Q(31,30)).log())
    for j in [19912,56200]:
        a,b=j*tau,(j+1)*tau
        out=law.rectangle(a,b,0,b)
        totals=tuple(sum(x[k] for x in out) for k in range(2))
        contains('complete_marginal_'+str(j),totals,
                 ball(tau/unit) if b<=cap else mass2(a,b,cap))

    # The untagged sum of the tail densities, before convolution with dust,
    # has an explicit count-one-plus-count-two expression for 2e<y<3e.
    y=Q(620125)
    i=bisect_right(law.knots,y/law.width*law.D)-1
    interval=[Q(sum(k.value[i] for k in tables),law.scale)/law.width
              for tables in (law.lo,law.hi)]
    contains('two_jump_density_per_tick',interval,
             (1+ball((y-edge)/edge).log())/ball(y))

    # A one-native-cell max band is narrower than the integration mesh.
    # If the tail lies in that band and has an owner above its lower cap,
    # that one mark already fills it. No second tail mark fits.
    l,c=46099*tau,46100*tau
    narrow=MiddleSiteLaw(edge,310000,l,c,mesh,1300000)
    a,b=48000*tau,48001*tau
    tagged=narrow.rectangle(a,b,l,c)
    contains('thin_max_class',tagged[2],ball(tau/unit)*ball(c/l).log())

    # Below the tail edge, a lower maximum-class crossing is carried
    # entirely by the small-dust law, even when the tail is the zero atom.
    l,c=29293*tau,49000*tau
    atom=MiddleSiteLaw(930000,940000,l,c,mesh,1300000)
    a,b=36000*tau,36001*tau
    tagged=atom.rectangle(a,b,0,2500)
    contains('small_dust_below_lower_cap',tagged[0],mass2(a,b,l))
    contains('small_dust_crosses_lower_cap',tagged[2],ball(tau/unit)-mass2(a,b,l))
    return results


def target_counts(g):
    """Count the outer target boxes before local-flag or mass pruning."""
    import numpy as np
    edges=np.flatnonzero((g.edges[:-1]>=90000)&(g.edges[:-1]<940000))
    count=dict(cap_edge=0,cap_edge_full_block=0,cap_edge_full_block_tail_bin=0)
    for i,c in enumerate(g.fine):
        active=edges[edges<=g.upper_edge(i)]
        L=g.lasts[i]
        if not len(active):
            continue
        j,keys,tops=g.tile(i)
        keep=j>=102994
        thresholds=np.full((L//128+1,len(active)),10**9,dtype=np.int64)
        for key,top in zip(keys,tops):
            block,idx,high=j[keep]//128,key[keep],top[keep]
            starts=np.r_[0,np.flatnonzero((np.diff(block)!=0)|(np.diff(idx)!=0))+1]
            gate=g.gates[idx[starts]][:,active]
            possible=gate<np.maximum.reduceat(high,starts)[:,None]
            np.minimum.at(thresholds,block[starts],np.where(possible,gate,10**9))
        floor=np.minimum.accumulate(thresholds,axis=0)
        last_bin=np.array([ceil((min(L,128*(k+1)-1)+39)*g.tick/2500)
                           for k in range(L//128+1)])
        visits=np.maximum(0,last_bin[:,None]-floor//2500)
        count['cap_edge']+=len(active)
        count['cap_edge_full_block']+=int(np.count_nonzero(visits))
        count['cap_edge_full_block_tail_bin']+=int(visits.sum())
        if int(c)==39058:
            h=np.flatnonzero(g.edges[active]==300000).item()
            count['edge300000_cap39058_targets']=int(visits[:,h].sum())
    return count


if __name__=='__main__':
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mesh',type=int,default=250)
    p.add_argument('--output',type=Path)
    p.add_argument('--check',type=Path)
    p.add_argument('--targets',action='store_true')
    p.add_argument('--gates',type=Path)
    args=p.parse_args()
    data=dict(mesh_ticks=args.mesh,checks=check(args.mesh))
    if args.targets:
        from h1_degree6_b2_gate_reachability import Gates,rebuild
        from tempfile import TemporaryDirectory
        with TemporaryDirectory() as directory:
            data['outer_targets']=target_counts(Gates(args.gates or rebuild(Path(directory))))
    if args.check:
        assert data==json.loads(args.check.read_text())
    if args.output:
        args.output.write_text(json.dumps(data,indent=2)+'\n')
    print(f'{len(data["checks"])} analytic checks passed at mesh {args.mesh} ticks.')
