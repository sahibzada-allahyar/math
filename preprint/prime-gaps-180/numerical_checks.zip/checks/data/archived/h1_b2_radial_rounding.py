"""Uniform mass captured by independently rounding the 39 native indices."""
from fractions import Fraction as Q
from functools import cache
from math import comb


@cache
def captured(width, radius, n=39):
    """Smallest binomial mass after fixing all possible native residue sums.

    Hoeffding's 1956 Theorem 5 minimizes a central integer interval
    containing the mean at equal success probabilities with the same sum.
    The artificial rounding is integrated out in the product law.
    """
    if not (width >= 1 and radius >= 1 and n >= 1):
        raise ValueError('Positive integral width, radius and count required.')
    den=n*width
    best=den**n
    at=0
    for total in range(n*(width-1)+1):
        lower=max(0,-(-(total-radius*width)//width))
        upper=min(n,(total+radius*width)//width)
        num=sum(comb(n,r)*total**r*(den-total)**(n-r) for r in range(lower,upper+1))
        if num<best:
            at=total
            best=num
    return Q(best,den**n),at


if __name__=='__main__':
    from itertools import product
    # Exhaust all tuples of small Bernoulli numerators without invoking
    # the comparison theorem in the separate check.
    seen=0
    for n in range(2,6):
        for w in range(2,5):
            lower,_=captured(w,1,n)
            for rates in product(range(w),repeat=n):
                row=[1]
                for r in rates:
                    row=[a*(w-r)+b*r for a,b in zip(row+[0],[0]+row)]
                num=sum(v for k,v in enumerate(row) if abs(k*w-sum(rates))<=w)
                assert Q(num,w**n)>=lower
                seen+=1
    print(seen,'discrete product laws checked')
    for a in (2,3,4,5,6,7,8):
        val,at=captured(128,a)
        print(a,float(val),at)
