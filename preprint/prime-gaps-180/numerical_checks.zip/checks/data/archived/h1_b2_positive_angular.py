"""Positive angular and endpoint contraction for the B2 full-dust bound.

Inputs are unnormalised one-site upper moments. They include the root shape
and the radial exponential tilt. The distinguished ordinary site omits only
the dust tilt. The three outputs distinguish the erased label, keeping its
coordinate in the full trial polynomial. No independence is asserted under
a maximum cut: this integrates a pointwise majorant over the product law.
"""
from collections import defaultdict
from decimal import Decimal, localcontext
from fractions import Fraction as Q
from functools import cache
from itertools import product
from math import isqrt, perm, prod

from h1_root_face_moments import block_partitions, fiber_splits


def upper_rational(x):
    """Endpoint of an Arb enclosure, or an already rational upper bound."""
    if hasattr(x, 'upper') and hasattr(x, 'man_exp'):
        mantissa, exponent = x.upper().man_exp()
        return int(mantissa) * Q(2)**int(exponent)
    if isinstance(x, float):
        raise TypeError('Use rational upper moments or Arb balls.')
    return Q(x)


def sqrt_upper(x, bits=100):
    """Round sqrt(x) upwards on a dyadic grid with relative precision."""
    if not x:
        return Q(0)
    log_approx = (x.numerator.bit_length()-x.denominator.bit_length())//2
    scale = 1 << max(0, bits-log_approx)
    z = x*scale**2
    floor = isqrt(z.numerator//z.denominator)
    return Q(floor + (floor**2 < z), scale)


_partitions = cache(block_partitions)
_splits = cache(fiber_splits)


def positive_angular_bounds(M, signatures, tilted, ordinary, S, *, cores=37):
    """Return exact rational upper bounds under 'direct' and 'minkowski'.

    For either method, 'core', 'endpoint_a' and 'endpoint_b' each refer to a
    single distinguished label. 'sum' includes the core multiplicity.
    M[a][b][s] includes every fixed radial/angular scaling, excluding the
    powers themselves. Endpoint shapes 0 and 2 are bounded by 1 and shape 1
    by (t+h/2)^2/S^2. A moment of order p integrates (t+h/2)^p.

    'direct' integrates all cross terms of the positive pointwise polynomial.
    'minkowski' applies the triangle inequality to its individual monomials.
    For oversized moment inputs that do not form a true moment sequence,
    each answer separately bounds the actual integral.
    """
    signatures = tuple(map(tuple,signatures))
    tilted = tuple(map(upper_rational,tilted))
    ordinary = tuple(map(upper_rational,ordinary))
    S = Q(S)
    power = max(4, 2*max(map(sum,signatures)))
    if (cores < 1 or S <= 0 or min(len(tilted),len(ordinary)) <= power
            or any(x < 0 for x in (*tilted,*ordinary))):
        raise ValueError('Invalid site count, scale, or moment upper bounds.')
    if (len(M) != 3 or any(len(row) != 3 for row in M)
            or any(len(v) != len(signatures) for row in M for v in row)):
        raise ValueError('Expect a 3 by 3 by number-of-signatures tensor.')
    coefficients = defaultdict(Q)
    for a,b in product(range(3),repeat=2):
        ea, eb = 2*(a==1), 2*(b==1)
        for s, value in zip(signatures,M[a][b]):
            value = upper_rational(value)
            if value < 0 or any(p < 1 for p in s):
                raise ValueError('Positive coefficients and powers required.')
            coefficients[ea,eb,s] += value/S**(ea+eb)
    terms = [(a,b,s,c) for (a,b,s),c in coefficients.items() if c]

    @cache
    def homogeneous(n, powers):
        # Each block picks a distinct site; unused sites still cost Z[0].
        return sum((mult*perm(n,len(blocks))*tilted[0]**(n-len(blocks))
                    *prod(tilted[e] for e in blocks)
                    for blocks,mult in _partitions(powers) if len(blocks)<=n),Q())

    @cache
    def core_mixed(powers):
        # Choose exactly the subset of factors evaluated at the ordinary
        # core site. The empty subset contributes its unnormalised Z0[0].
        return sum(mult*ordinary[e]*homogeneous(cores-1,rest)
                   for rest,e,mult in _splits(powers))

    @cache
    def integrated(a,b,powers):
        common = homogeneous(cores,powers)
        return (tilted[a]*tilted[b]*core_mixed(powers),
                ordinary[a]*tilted[b]*common,
                tilted[a]*ordinary[b]*common)

    direct, norms = [Q()]*3, [Q()]*3
    for i,(a,b,s,c) in enumerate(terms):
        for j in range(i+1):
            ax,bx,sx,cx = terms[j]
            gram = integrated(a+ax,b+bx,tuple(sorted(s+sx)))
            scale = c*cx*(1 if i==j else 2)
            for r,value in enumerate(gram):
                direct[r] += scale*value
                if i==j:
                    norms[r] += c*sqrt_upper(value)

    def roles(values):
        return dict(core=values[0],endpoint_a=values[1],endpoint_b=values[2],
                    sum=cores*values[0]+values[1]+values[2])
    return dict(direct=roles(direct),minkowski=roles([v**2 for v in norms]))


def self_check():
    """Compare all roles to explicit integration over a small discrete law."""
    signatures = ((),(2,),(2,2),(2,2,2),(2,3),(6,))
    M = [[[1+(a*3+b+1)*(j+2) for j in range(len(signatures))]
          for b in range(3)] for a in range(3)]
    S = Q(7,5)
    atom_l = ((Q(1,7),Q(2,9)),(Q(3,5),Q(1,8)))
    atom_0 = ((Q(1,11),Q(3,11)),(Q(3,4),Q(4,9)))

    def moments(law):
        return [sum(m*x**p for x,m in law) for p in range(13)]
    for n in (1,3):
        bounds = positive_angular_bounds(M, signatures, moments(atom_l),
                                         moments(atom_0), S, cores=n)
        for role, distinguished in [('core',2),('endpoint_a',0),('endpoint_b',1)]:
            laws = [atom_l]*(n+2)
            laws[distinguished] = atom_0
            exact = Q()
            for sample in product(*laws):
                x,mu = zip(*sample)
                powers = {p:sum(t**p for t in x[2:]) for p in (2,3,6)}
                angular = [prod(powers[p] for p in sig) for sig in signatures]
                f = sum(M[a][b][j]*(x[0]/S)**(2*(a==1))*(x[1]/S)**(2*(b==1))
                        *angular[j] for a,b in product(range(3),repeat=2)
                        for j in range(len(signatures)))
                exact += prod(mu)*f**2
            assert exact==bounds['direct'][role] <= bounds['minkowski'][role]
    tiny = Q(1,10**160)
    assert tiny <= sqrt_upper(tiny)**2 < tiny*(1+Q(1,2**96))


def global_edge_check(mesh):
    """Reapply the common Chernoff and midpoint factors for thirteen edges."""
    from h1_b2_global_amplitude import SIGS, S, radial_upper
    from h1_b2_global_dust_transform import (
        TILTS, abspow10_upper, ball, ctx, site_moments)

    ctx.prec = 160
    M, width = radial_upper(), S/131072
    edges = [100,300,1000,3000,6000,10000,*range(20000,90001,10000)]
    betas = [23,23,23,22,21,20,19,18,17,17,16,16,15]
    assert len(betas)==len(edges)-1
    rows = []
    total = Q()
    for edge, following, beta in zip(edges,edges[1:],betas):
        rate = TILTS[edge][1]
        def moments(r):
            return site_moments(beta,r,Q(edge,2624990),width,power=12,mesh=mesh)
        bounds = positive_angular_bounds(M,SIGS,moments(rate),moments(0),S)
        factor = ball(beta*S+Q(2*rate*following,2624990)).exp()
        factor *= ball(1+Q(907,5)*width/2)**78
        def charge(method):
            q = abspow10_upper(ball(bounds[method]['sum'])*factor)
            with localcontext() as ctx_decimal:
                ctx_decimal.prec = 15
                display = str(Decimal(q.numerator)/Decimal(q.denominator))
            assert Q(display)==q
            return display
        direct, minkowski = charge('direct'), charge('minkowski')
        total += Q(direct)
        rows.append(dict(edge=edge,next_edge=following,beta=beta,rate=rate,
                         direct_raw_upper=direct,minkowski_raw_upper=minkowski))
    floor = Q('4.46e-77')
    return dict(scope='Full native B2 support; 37 core and both endpoint erasures per edge.',
                gamma_mesh=mesh,gamma_stop=16,precision_bits=ctx.prec,
                ordinary_mass_floor='4.46e-77',whole_union_raw_upper=str(total),
                whole_union_relative_upper=str(total/floor),edges=rows)


if __name__=='__main__':
    import argparse
    import json
    from pathlib import Path
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--global-edges',action='store_true')
    p.add_argument('--mesh',type=int,default=100)
    p.add_argument('--output',type=Path)
    p.add_argument('--check',type=Path)
    args = p.parse_args()
    self_check()
    if args.global_edges or args.output or args.check:
        result = global_edge_check(args.mesh)
        if args.check:
            assert json.loads(args.check.read_text()) == result
            print('All whole-domain edge bounds reproduced.')
        if args.output:
            args.output.write_text(json.dumps(result,indent=2)+'\n')
        if not args.check and not args.output:
            print(json.dumps(result,indent=2))
    else:
        print('Exact enumeration agrees for all three erasure roles.')
