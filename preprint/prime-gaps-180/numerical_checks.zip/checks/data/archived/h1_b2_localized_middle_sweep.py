"""Worker and exact ledger for independent B2 middle single-root enclosures."""
import argparse
from fractions import Fraction as Q
import hashlib
import json
from math import ceil
import os
from pathlib import Path
import resource
import sys
from types import SimpleNamespace

import numpy as np
from flint import ctx

import h1_b2_localized_diagonal as D
from h1_b2_localized_operator import retained_groups
from h1_b2_localized_spectral_tail import magnitude_upper


HERE=Path(__file__).resolve().parent


def write(path,doc):
    partial=path.with_name(f'{path.name}.{os.getpid()}.part')
    def native_integer(value):
        if isinstance(value,np.integer):return int(value)
        raise TypeError(f'Unsupported receipt value {type(value).__name__}')
    partial.write_text(json.dumps(doc,separators=(',',':'),sort_keys=True,default=native_integer)+'\n')
    partial.replace(path)


def identity(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def ledger(directory,manifest,denominator):
    groups={}
    for cap,edge in manifest['tasks']:
        path=directory/f'{cap}_{edge}.json'
        bucket=groups.setdefault(edge,{'caps':[],'core':Q(0),'a':Q(0)})
        if not path.exists():continue
        d=json.loads(path.read_text());assert d['calculation']==manifest['calculation']
        v=d['value'];assert v['retained_cap'][1]==cap and v['edges'][0]==edge
        assert v['role']=='singles' and v['owner_weight']==manifest['options']['owner_weight']
        bucket['caps'].append(cap)
        for role in ('core','a'):
            bucket[role]+=Q(v['charges'][role]['scaled_upper'])
    full=sum(len(v['caps']) for v in groups.values())
    beta=manifest['options']['owner_weight']
    bounds={}
    for edge,row in groups.items():
        c,a=(D.F.ball(row[r]) for r in ('core','a'))
        cost=(39+beta)*(37*c+2*a)
        if beta==0:cost=min(cost,((37*c.sqrt()+2*a.sqrt())**2).upper())
        bounds[edge]=dict(complete=len(row['caps'])==13,caps=sorted(row['caps']),raw_core=str(row['core']),
                          raw_endpoint=str(row['a']),raw_singles_upper=D.F.upper_float(cost))
    total=sum((Q(v['raw_singles_upper']) for v in bounds.values()),Q(0))
    return dict(complete=full,expected=len(manifest['tasks']),all_covered=full==len(manifest['tasks']),
                raw_subtotal=str(total),ordinary_floor=str(denominator),
                fraction_subtotal=D.F.upper_float(D.F.ball(total/denominator)),by_edge=bounds)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--directory',type=Path,required=True)
    p.add_argument('--gates',type=Path)
    p.add_argument('--banks',type=Path,nargs='+')
    p.add_argument('--fold',type=Path)
    p.add_argument('--dots',type=Path)
    p.add_argument('--shard',default='0/1')
    p.add_argument('--owner-weight',type=int,default=0)
    p.add_argument('--spectral-tail',type=float,default=0.)
    p.add_argument('--moment-cache',type=Path)
    p.add_argument('--terminal-count',type=int,default=2)
    p.add_argument('--summary',action='store_true')
    p.add_argument('--floor',type=Q,default=Q('46.1984860121'))
    p.add_argument('--output',type=Path)
    p.add_argument('--max-cases',type=int)
    cli=p.parse_args();ctx.prec=128
    cli.directory.mkdir(parents=True,exist_ok=True)
    manifest_path=cli.directory/'manifest.json'
    if cli.summary:
        manifest=json.loads(manifest_path.read_text())
        report=ledger(cli.directory,manifest,cli.floor)
        if cli.output:write(cli.output,report)
        print(json.dumps({k:v for k,v in report.items() if k!='by_edge'}))
        return
    if not all((cli.gates,cli.banks,cli.fold,cli.dots)):p.error('Supply --gates, --banks, --fold and --dots for a worker.')
    D.F.supmag=magnitude_upper
    if cli.moment_cache:cli.moment_cache.mkdir(parents=True,exist_ok=True)
    options=dict(radial=128,tail=15000,micro=1000,dust=150000,edge_group=4,
                 radius=5,period=2,count=12,terminal_count=cli.terminal_count,beta=38.,eta=22.,
                 owner_weight=cli.owner_weight,spectral_tail=cli.spectral_tail,price_coupled=True,
                 role='singles',same_full_only=False,edge_end=None)
    g=D.P.Gates(cli.gates)
    pr=D.P.Projection(g,128,15000,[150000]*3,4,True)
    model=D.Native();context=g,pr,model
    geometry={upper:geom for _,upper,geom,_ in retained_groups(model,pr.cap_ends_projection)}
    banks={g:next(p/f'cap-{g}.npz' for p in cli.banks if (p/f'cap-{g}.npz').exists()) for g in set(geometry.values())}
    tasks=sorted(((int(cap),int(edge)) for cap in geometry for edge in g.edges[pr.middle]),
                 key=lambda t:(abs(t[1]-330000),abs(t[0]-39058),t))
    assert len(tasks)==286 and len(banks)==9
    # The producer metadata and the per-bank array digests in the portable
    # packet authenticate the heavyweight signed inputs. Program and gate
    # pins are portable across workers/platforms; compiled locations vary.
    deps=['h1_b2_localized_diagonal.py','h1_b2_localized_spectral_tail.py',
          'h1_b2_localized_moments.py','h1_b2_localized_operator.py','h1_b2_projected_fourier.py',
          'h1_b2_projected_gram.py','h1_b2_projected_site_density.py','h1_b2_middle_site_law.py',
          'h1_b2_middle_dust_projection.py','h1_b2_projected_dots.c','h1_b2_localized_fold.cpp',
          'h1_b2_quotient_inputs.py','h1_b2_finite_quotient.py','h1_b2_radial_rounding.py',Path(__file__).name]
    record={'options':options,'sources':{n:identity(HERE/n) for n in deps},
            'gates_sha256':identity(cli.gates),'tasks':tasks}
    pin=hashlib.sha256(json.dumps(record,sort_keys=True).encode()).hexdigest()
    manifest=dict(calculation=pin,**record)
    if manifest_path.exists():assert json.loads(manifest_path.read_text())['calculation']==pin
    else:write(manifest_path,manifest)
    i,n=map(int,cli.shard.split('/'));assert 0<=i<n
    done=0
    for k,(cap,edge) in enumerate(tasks):
        if k%n!=i:continue
        output=cli.directory/f'{cap}_{edge}.json'
        if output.exists():
            assert json.loads(output.read_text())['calculation']==pin
            continue
        cache=cli.moment_cache/f'{cap}_{edge}.npz' if cli.moment_cache else None
        a=SimpleNamespace(**options,gates=cli.gates,fold=cli.fold,dots=cli.dots,moment_cache=cache,
                          bank=banks[geometry[cap]],cap=cap,edge=edge)
        result=D.run(a,context)
        rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        mb=ceil(rss/(1024**2 if sys.platform=='darwin' else 1024))
        write(output,dict(calculation=pin,peak_mb=mb,value=result))
        print(cap,edge,result['charges']['core']['scaled_upper'],result['charges']['a']['scaled_upper'],
              result['seconds'],mb,flush=True)
        done+=1
        if done==cli.max_cases:break


if __name__=='__main__':main()
