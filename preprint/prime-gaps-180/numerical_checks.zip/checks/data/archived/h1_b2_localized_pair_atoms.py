"""Exact two-dimensional bare pair measures and finite radial/tail folds."""
import ctypes
from pathlib import Path

from gmpy2 import mpz
import numpy as np


def packed(a):
    n,nt=a.shape
    out=np.zeros((n,2*nt-1,2),dtype='<u8')
    out[:,:nt,0]=a
    return mpz.from_bytes(out.tobytes(),'little')


def square(a,small=None):
    """Return exact low/high limbs of A*A or A*A-small*small."""
    assert a.dtype==np.uint64
    n,nt=a.shape
    assert sum(map(int,a.sum(axis=1,dtype=np.uint64)))<2**64
    if small is not None:assert np.all(small<=a)
    x=packed(a)
    if small is None:z=x*x
    else:
        y=packed(small)
        # No borrow propagates between coefficients: a-small has
        # nonnegative coefficients, and the product is <= the full square.
        z=(x-y)*(x+y)
    size=(2*n-1)*(2*nt-1)
    assert z.bit_length()<=128*size
    data=z.to_bytes(16*size,'little')
    return np.frombuffer(data,'<u8').reshape(2*n-1,2*nt-1,2)


def library(path):
    f=ctypes.CDLL(str(Path(path).resolve())).add_pair_fold
    f.argtypes=[ctypes.c_int]*6+[ctypes.c_void_p]*4
    f.restype=None
    return f


def add_fold(fn,coef,left,right,low,high,out):
    n,nt,limbs=coef.shape
    nr,rt,other=out.shape
    assert limbs==other==2 and out.dtype==np.uint64 and out.flags.c_contiguous
    left=np.ascontiguousarray(left,dtype=np.int32)
    right=np.ascontiguousarray(right,dtype=np.int32)
    fn(n,nt,nr,rt,low,high,coef.ctypes.data,left.ctypes.data,right.ctypes.data,out.ctypes.data)
