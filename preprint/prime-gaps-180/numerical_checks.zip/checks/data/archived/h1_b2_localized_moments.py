"""Directed 36/37-core spectral moments for the localized erasure diagonals."""
from math import ceil,perm

import numpy as np

import h1_b2_projected_fourier as F


def role_moments(trans,errors,weights,weight_errors,role):
    cores=36 if role=='core' else 37
    ends=F.P.PAIR if role=='core' else tuple((i,) for i in range(6)) if role in ('a','b') else ((),)
    shape=(len(weights),len(F.P.ANG),len(ends))
    result=np.zeros(shape);err=np.zeros(shape)
    span=2048;length=trans.shape[1]
    assert ceil(length/span)<=4096
    assert np.max(F.supmag(trans)+errors[:,None])<4 and np.max(F.supmag(weights))<2**135
    for first in range(0,length,span):
        m=trans[:,first:first+span]
        high=F.supmag(m)+errors[:,None];relative=errors[:,None]/high
        p=[np.ones(m.shape[1],dtype=complex)]
        h=[np.ones(m.shape[1])]
        for _ in range(cores):
            p.append(p[-1]*m[0]);h.append(h[-1]*high[0])
        C=np.zeros((len(F.P.ANG),m.shape[1]),dtype=complex)
        rc=np.zeros(C.shape,dtype=float)
        for i,sig in enumerate(F.P.ANG):
            for parts,mult0 in F.P._partitions(sig):
                k=cores-len(parts);mult=mult0*perm(cores,len(parts))
                assert mult<2**53
                value,major,r=p[k]*mult,h[k]*mult,k*relative[0]
                for j in parts:
                    value=value*m[j];major=major*high[j];r=r+relative[j]
                C[i]+=value;rc[i]+=major*(r+2**-43)
        rc=rc*(1+2**-39)+F.TINY
        if role=='core':
            a,b=np.asarray(ends).T+13
            E=m[a]*m[b]
            re=high[a]*high[b]*(relative[a]+relative[b]+12*F.U)*(1+2**-45)+F.TINY
        elif role in ('a','b'):
            E=m[13:19]
            re=np.broadcast_to(errors[13:19,None],E.shape)
        else:
            E=np.ones((1,m.shape[1]),dtype=complex);re=np.zeros(E.shape)
        ac,ae=F.supmag(C),F.supmag(E)
        for j,(weights_j,ew) in enumerate(zip(weights[:,first:first+span],weight_errors)):
            mag=F.supmag(weights_j)
            z=E*weights_j
            rz=(re*(mag+ew)+ae*ew+12*F.U*(ae+re)*(mag+ew))*(1+2**-45)+F.TINY
            value,rad=F.dots(C,ac,rc,z,F.supmag(z),rz)
            err[j]+=rad*(1+2**-38)+2*F.U*(np.abs(result[j])+np.abs(value))+F.TINY
            result[j]+=value
    assert np.isfinite(result).all() and np.isfinite(err).all()
    return result,err*(1+2**-38)+F.TINY
