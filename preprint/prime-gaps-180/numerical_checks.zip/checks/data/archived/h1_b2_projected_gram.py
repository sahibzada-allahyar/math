"""Floating Fourier contraction of a whole 39-site signed gate panel.

The probability model uses a fixed positive upper density at each native
site cell. The Fourier and final signed Gram arithmetic here is exploratory.
"""
import argparse
from fractions import Fraction as Q
from itertools import combinations_with_replacement
import json
from math import ceil, perm
from pathlib import Path
from tempfile import TemporaryDirectory
from time import monotonic

import numpy as np
from scipy.fft import rfft2, next_fast_len

from h1_b2_global_amplitude import N, S, SIGS, radial_blocks
from h1_b2_middle_dust_projection import Gates, Projection, rebuild
from h1_b2_positive_angular import _partitions
from h1_b2_projected_site_density import site_density
from h1_b2_radial_rounding import captured
import h1_b2_full_index_kernel as jack


ANG = tuple(sorted({tuple(sorted(s+t)) for s in SIGS for t in SIGS}))
END = tuple(combinations_with_replacement(range(3),2))
PAIR = tuple(combinations_with_replacement(range(len(END)),2))
SIG_INDEX = np.array([[ANG.index(tuple(sorted(s+t))) for t in SIGS] for s in SIGS])
END_INDEX = np.array([[PAIR.index(tuple(sorted((END.index(tuple(sorted((a,c)))),
                                END.index(tuple(sorted((b,d)))))))) for c in range(3) for d in range(3)]
                                for a in range(3) for b in range(3)])


def gram_upper(moments, low, high, suffix):
    C = np.array([[float(block[i,s][a]) for i in range(9) for s in range(len(SIGS))]
                  for _,block in radial_blocks(low,high,suffix) for a in range(4)])
    G = moments[SIG_INDEX[None,:,None,:],END_INDEX[:,None,:,None]].reshape(99,99)
    def norms(B):
        value = np.einsum('ia,ab,ib->i',B,G,B,optimize=True)
        abs_sum = np.einsum('ia,ab,ib->i',abs(B),abs(G),abs(B),optimize=True)
        assert (value >= -1e-9*np.maximum(abs_sum,1e-150)).all()
        return np.sqrt(np.maximum(0.,value))
    out = np.linalg.norm(norms(C))
    for center in (C.mean(axis=0),C[0],C[-1]):
        out = min(out,norms(center[None])[0]+np.linalg.norm(norms(C-center)))
    return float(out**2)


def bank(g, projection, cap, a, b, width, tail, micro, cut, *, balanced=False):
    group = next(gr for gr in projection.cap_groups if g.fine[gr[-1]]==cap)
    prev = g.fine[group[0]-1] if group[0] else 0
    last = g.lasts[group[0]]
    blocks = [(x,min(last+1,x+width)) for x in range(0,last+1,width)]
    # Split the single bin containing the last possibly erased site.
    blocks = [(s,t) for x,y in blocks for s,t in ((x,min(y,27971)),(max(x,27971),y)) if s<t]
    n = (last//width)+1
    k = np.array([x//width for x,y in blocks])
    full = np.arange(last+1)
    t = (full+.5)*float(S/N)
    root = .105/(1+.01*t)+.895/(1+181.4*t)
    shape = [np.ones_like(t),(t/float(S))**2,1/(1+300*t)]
    fields = [t**p for p in range(13)] + [shape[i]*shape[j] for i,j in END]
    starts = np.array([x for x,y in blocks])
    def compress(multiplier):
        return np.stack([np.add.reduceat(100*float(S/N)*root**2*v*multiplier,starts) for v in fields])
    if balanced:
        # For the true native cell j, independently increment floor(j/B)
        # with probability (j mod B)/B. Roots and angular fields stay at j.
        up=(full % width)/width
        weighted=np.hstack([compress(1-up),compress(up)])
        k=np.r_[k,k+1]
        n+=1
    else:
        weighted=compress(1.)
    theta = g.tick
    opts=dict(edge=a,end=b,lower_cap=int(prev)*theta,cap=int(cap)*theta,
              tau=theta,tail_step=tail,mesh=micro)
    same = dict(blocks=blocks, **opts)
    # All dust band laws must stem from the same disjoint upper atoms.
    # Cumulative sums of these atoms are what the Fourier inclusion-exclusion uses.
    bounds=[0,*list(range(cut,ceil(27971*theta),cut)),None]
    density=[]
    eligible = np.array([x<=27970 for x,y in blocks])
    unrestricted = site_density(**same)
    for i,(l,r) in enumerate(zip(bounds,bounds[1:])):
        layer = site_density(**same,dust_lo=l,dust_hi=r)
        layer[:,~eligible,:] = unrestricted[:,~eligible,:] if i==0 else 0
        density.append(layer)
    # Maximum over eligible sites has a terminal cap even if a site's
    # coarsened density envelope has support beyond that value.
    upper=[*bounds[1:-1],ceil(27971*theta)]
    density=np.stack(density)
    if balanced:
        density=np.concatenate([density,density],axis=2)
    return n,k,weighted,density,upper,group


def panel_moments(trans, weights):
    """Batched Parseval sums, retaining all 53 × 21 moments per panel."""
    size = trans.shape[1]
    total = np.zeros((len(weights),len(ANG),len(PAIR)))
    magnitude = np.zeros_like(total)
    for i in range(0,size,4096):
        m=trans[:,i:i+4096]
        C=np.zeros((len(ANG),m.shape[1]),dtype=complex)
        p0 = [m[0]**j for j in range(31,38)]
        for s,sig in enumerate(ANG):
            for parts,count in _partitions(sig):
                u = p0[6-len(parts)]*(count*perm(37,len(parts)))
                for power in parts:
                    u = u*m[power]
                C[s]+=u
        E=np.stack([m[13+a]*m[13+b] for a,b in PAIR])
        absC=abs(C)
        for ix,w in enumerate(weights[:,i:i+C.shape[1]]):
            EW=E*w
            total[ix]+=(C@EW.T).real
            magnitude[ix]+=absC@abs(EW).T
    return total,magnitude


def jackson_input(last,width,beta,order):
    starts=sorted({*range(0,last+1,width),27971})
    j=np.arange(last+1)
    t=(j+.5)*float(S/N)
    root=.105/(1+.01*t)+.895/(1+181.4*t)
    sh=[np.ones_like(t),(t/float(S))**2,1/(1+300*t)]
    W=100*float(S/N)*root**2*np.exp(-beta*float(S/N)*j)
    rows=np.stack([W*t**p for p in range(13)]+[W*sh[a]*sh[b] for a,b in END])
    phase=(j%width-(width-1)/2)/width
    result=[]
    for _ in range(order+1):
        result.append(np.add.reduceat(rows,starts,axis=1))
        rows=rows*phase
    return np.stack(result)


def jackson_transform(data,j_coef,idx,n,nk,ny,tail_log,width,f):
    """Sub-bin Taylor formula for true native frequencies, diagnostic arithmetic."""
    fidx=f%nk
    phase=-2j*np.pi*f/nk
    z=np.exp(phase*((width-1)/(2*width)))
    data=data*np.exp(tail_log*np.arange(data.shape[1]))
    out=[]
    for channel in range(j_coef.shape[1]):
        summed=np.zeros((len(f),ny//2+1),dtype=complex)
        powers=np.ones(len(f),dtype=complex)
        for degree,co in enumerate(j_coef[:,channel]):
            d=np.zeros((n,data.shape[1]))
            np.add.at(d,idx,co[:,None]*data)
            spectrum=rfft2(d,s=(nk,ny))[fidx]
            summed+=powers[:,None]*spectrum
            powers=powers*phase/(degree+1)
        out.append((z[:,None]*summed).ravel())
    return np.asarray(out)


def run(g,args,pr=None):
    begin=monotonic()
    if pr is None:
        pr=Projection(g,args.radial,args.tail,[args.dust]*3,args.edge_group,True)
    group_idx=np.flatnonzero(g.edges[pr.middle]==args.edge).item()
    e0=int(g.edges[pr.middle[group_idx]])
    end=int(g.edges[pr.ending[group_idx]+1])
    width,step=args.radial,args.tail
    radius=getattr(args,'round_radius',0)
    jackson=getattr(args,'jackson_radius',0)
    assert not (radius and jackson)
    n,k,fields,density,dust_bounds,group=bank(g,pr,args.cap,e0,end,width,step,args.micro,args.dust,
                                              balanced=bool(radius))
    bank_time=monotonic()-begin
    last=g.lasts[group[0]]
    max_tail=ceil((last+39)*g.tick/step)+39
    extra=(radius+jackson)*width if radius or jackson else 39*(width-1)
    back=(radius+jackson)*width
    output_limit=(last+back)//width+1
    required=max(n,output_limit)*args.period
    nk=1<<(required-1).bit_length() if jackson else next_fast_len(required)
    ny=next_fast_len(max_tail*args.period+1,real=True)
    K,L=np.arange(nk),np.arange(ny)
    lower=np.maximum(0,K*width-back)
    if args.all_radial:
        kstart=max(0,ceil((102994-extra)/width))
        panels=[(x,min(output_limit,x+args.count)) for x in range(kstart,output_limit,args.count)]
    else:
        assert args.first+args.count<=n
        panels=[(args.first,args.first+args.count)]
    radial_ranges=[(max(102994,start*width-back),min(last,(stop-1)*width+extra))
                   for start,stop in panels]
    assert all(a<=b for a,b in radial_ranges)
    suffix=sum(v<args.cap for v in pr.components)
    price_rows=pr.first[group[0]]
    idx=np.minimum(K*width+extra,last)//pr.lookup_width
    A=price_rows[idx,group_idx]
    B=g.low[np.minimum(lower,last)]+pr.second[group[0]][idx,group_idx]
    in_panel=(K>=panels[0][0])&(K<panels[-1][1])
    gram=np.zeros((len(panels),len(ANG),len(PAIR)))
    scale_error=gram.copy()
    checks=[]
    freq_mult=np.full(ny//2+1,2.);freq_mult[0]=1.
    if ny%2==0:freq_mult[-1]=1.
    radial_log=args.beta*float(S/N)*width
    tail_log=args.eta*step/2624990.
    # Positive tilts undo exactly on true, unwrapped totals. Every extra
    # periodic tuple contributes the square of a real polynomial to each
    # final physical panel norm even if its native sum is out of support.
    tilt=np.exp(-radial_log*np.arange(n)[:,None]+tail_log*np.arange(density.shape[-1]))
    comp=np.exp(radial_log*K[:,None]-tail_log*L)
    if jackson:
        f,cf,normal=jack.multiplier(nk)
        f,cf=np.array(f),np.array(cf,dtype=float)/normal
        j_coef=jackson_input(last,width,args.beta,args.taylor_order)
    tables={}
    for level,D in enumerate(dust_bounds):
        accepted=in_panel[:,None] & (L*step>A[:,None]) & (L*step+D>B[:,None]) & (L<=max_tail)
        if not accepted.any():continue
        # The eligible maximum is in this one dust band. The exact atom D=0
        # belongs to the first. Lower cumulative passes are subtracted.
        coeffs = [(level,1)] if not level else [(level,1),(level-1,-1)]
        require=3 if group[0]>0 else 1
        for upto,sign in coeffs:
            for flags in range(4):
                if flags & ~require:continue
                sg=sign*(-1)**((require^flags).bit_count())
                key=(upto,flags)
                if key not in tables:tables[key]=np.zeros((nk,ny))
                tables[key]+=sg*(accepted*comp)
    for (level,flags),test in tables.items():
        if not test.any():continue
        use=[f for f in range(4) if not (f & ~flags)]
        data=density[:level+1,use].sum(axis=(0,1))
        # Distinct native cells in one radial bin share the Fourier label,
        # but retain all root, endpoint, and power-sum moments.
        if jackson:
            trans=jackson_transform(data,j_coef,k,n,nk,ny,tail_log,width,f)
        else:
            trans=[]
            for row in fields:
                d=np.zeros((n,data.shape[1]))
                np.add.at(d,k,row[:,None]*data)
                trans.append(rfft2(d*tilt,s=(nk,ny)).ravel())
        live=[];masks=[]
        for ip,(start,stop) in enumerate(panels):
            if test[start:stop].any():
                restriction=np.zeros_like(test)
                restriction[start:stop]=test[start:stop]
                mask=rfft2(restriction).conj()*freq_mult/(nk*ny)
                if jackson:mask=mask[f%nk]*cf[:,None]
                live.append(ip);masks.append(mask.ravel())
        if not live:continue
        packed,bound=panel_moments(np.asarray(trans),np.stack(masks))
        gram[live]+=packed;scale_error[live]+=bound
        checks.append(dict(layer=level,flags=flags,constant_moment=float(packed[:,0,0].sum())))
    raw=[gram_upper(mat,a,b,suffix) if mat.any() else 0.
         for mat,(a,b) in zip(gram,radial_ranges)]
    capture=captured(width,radius)[0] if radius else Q(1)
    if jackson:capture=Q(jack.captured(nk,width,jackson,args.beta))
    bound=sum(raw)/float(capture)
    return dict(scope='Floating contraction on an explicitly dominating periodic site law; signed arithmetic is not interval enclosed.',
                cap=args.cap,edge_group=[e0,end],site_radial_width=width,site_tail_ticks=step,
                site_dust_width=args.dust,dust_upper_ticks=dust_bounds,micro_ticks=args.micro,
                radial_output_bins=[panels[0][0],panels[-1][1]-1],possible_native_J=[radial_ranges[0][0],radial_ranges[-1][1]],
                fourier_grid=[nk,ny],beta=args.beta,eta=args.eta,
                independent_rounding_radius=radius,minimum_retained_probability=str(capture),
                full_index_kernel_radius=jackson,subcell_taylor_order=getattr(args,'taylor_order',None) if jackson else None,
                pdf_scaled_100_per_site=bound,fraction_at_previous_norm_floor=bound/46.1984860121,
                fraction_at_sampled_norm=bound/94.17,constant_gram=float(gram[:,0,0].sum()),
                constant_frequency_absolute_sum=float(scale_error[:,0,0].sum()),
                panel_scaled_forms=raw,
                site_seconds=round(bank_time,2),total_seconds=round(monotonic()-begin,2),subtotals=checks)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--gates',type=Path)
    p.add_argument('--cap',type=int,default=39058)
    p.add_argument('--edge',type=int,default=290000)
    p.add_argument('--edge-group',type=int,default=4)
    p.add_argument('--radial',type=int,default=128)
    p.add_argument('--first',type=int,default=912)
    p.add_argument('--count',type=int,default=8)
    p.add_argument('--all-radial',action='store_true')
    p.add_argument('--round-radius',type=int,default=0)
    p.add_argument('--jackson-radius',type=int,default=0)
    p.add_argument('--taylor-order',type=int,default=10)
    p.add_argument('--tail',type=int,default=15000)
    p.add_argument('--micro',type=int,default=1000)
    p.add_argument('--dust',type=int,default=150000)
    p.add_argument('--beta',type=float,default=24)
    p.add_argument('--eta',type=float,default=14)
    p.add_argument('--period',type=int,default=1)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    with TemporaryDirectory() as tmp:
        res=run(Gates(args.gates or rebuild(Path(tmp))),args)
    raw=json.dumps(res,indent=2,default=int)+'\n'
    if args.output:args.output.write_text(raw)
    print(raw,end='')
