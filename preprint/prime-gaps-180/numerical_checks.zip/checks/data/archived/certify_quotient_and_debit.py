"""Parallel outward-rounded enclosure of the native B=2 mass, Rayleigh quotient,
portable cover-debit u, and direct repriced-cover quotient on all 131,072 cells.

Reuses the exact polynomial-interval and bilinear-contraction primitives from
output/h1-h3-improvement/h1_b2_quotient_poly.py, h1_b2_quotient_contract.py,
and h1_b2_finite_quotient.py without modifying any file in output/h1-h3-improvement.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from fractions import Fraction as Q
from hashlib import sha256
import json
import os
from pathlib import Path
import sys
import time
from types import SimpleNamespace

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
H1_DIR = ROOT / "output" / "h1-h3-improvement"
if str(H1_DIR) not in sys.path:
    sys.path.insert(0, str(H1_DIR))

import h1_b2_quotient_poly as P
from h1_b2_quotient_contract import Integral, configure, contract, empty
from h1_b2_quotient_inputs import exact_float_bounds
from h1_b2_finite_quotient import Native, interval_multiply, via_interval
import h1_two_source_endpoints as TS


ROLES_ALL = (
    "full",
    "pair",
    "core",
    "a",
    "b",
    "debit_core",
    "debit_a",
    "debit_b",
    "repriced_core",
    "repriced_a",
    "repriced_b",
)

PINNED_FILES = (
    "h1_b2_quotient_inputs.py",
    "h1_b2_packed_poly.cpp",
    "h1_b2_quotient_poly.py",
    "h1_b2_quotient_contract.py",
    "h1_b2_finite_quotient.py",
    "h1_b2_global_amplitude.py",
    "h1_degree6_native_schur_support.py",
    "h1_degree6_stream.py",
    "h1_multilevel_strip_free.json",
    "h1_b2_repriced_covers.json",
    "ts_s39a6.npz",
)


def input_hashes() -> dict[str, str]:
    out = {name: sha256((H1_DIR / name).read_bytes()).hexdigest() for name in PINNED_FILES}
    out[Path(__file__).name] = sha256(Path(__file__).read_bytes()).hexdigest()
    return out


def build_extra_sector_tables(model: Native) -> tuple[dict[int, tuple], dict[int, tuple]]:
    """Build exact integer sector runs for (old - new)_+ debit and repriced new table."""
    old_doc = json.loads((H1_DIR / "h1_multilevel_strip_free.json").read_text())
    new_doc = json.loads((H1_DIR / "h1_b2_repriced_covers.json").read_text())
    assert old_doc["scale"] == new_doc["scale"] == model.scale
    old_arr = np.asarray(old_doc["sector_prices"], dtype=object)
    new_arr = np.asarray(new_doc["sector_prices"], dtype=object)
    assert not np.any(old_arr[:, 2]) and not np.any(new_arr[:, 2])
    diff_arr = old_arr - new_arr

    frame = TS.stored_frame()
    labels_fn = TS.labeller(SimpleNamespace(k=39, n=model.n), frame, 1)

    debit_runs: dict[int, tuple] = {}
    repriced_runs: dict[int, tuple] = {}

    for c in model.caps:
        full_last = model.classes[c].full_last
        ids = labels_fn(c)[: full_last + 1]
        ends = np.r_[0, np.flatnonzero(ids[1:] != ids[:-1]) + 1, full_last + 1]
        d_list = []
        r_list = []
        for i0, i1 in zip(ends[:-1], ends[1:]):
            s = int(ids[i0])
            a_start_i, stop_i = int(i0), int(i1) - 1
            if s < 0:
                d_list.append((a_start_i, stop_i, 0, 0))
                r_list.append((a_start_i, stop_i, 0, 0))
                continue
            na, nb = int(new_arr[s, 0]), int(new_arr[s, 1])
            if a_start_i <= model.active_last(c):
                check_stop = min(stop_i, model.active_last(c))
                v_lo = na + nb / (Q(4999, 10000) - model.rate * (a_start_i + 38))
                v_hi = na + nb / (Q(4999, 10000) - model.rate * (check_stop + 38))
                assert min(v_lo, v_hi) > -10000 * model.scale, f"Unexpected deep negative sector {s} at cap {c}"
            r_list.append((a_start_i, stop_i, na, nb))

            # Positive debit (old - new)_+ run in exact rational arithmetic:
            da, db = int(diff_arr[s, 0]), int(diff_arr[s, 1])
            if da == 0 and db == 0:
                d_list.append((a_start_i, stop_i, 0, 0))
                continue
            d0 = da + db / (Q(4999, 10000) - model.rate * (a_start_i + 38))
            d1 = da + db / (Q(4999, 10000) - model.rate * (stop_i + 38))
            if (d0 > 0) != (d1 > 0):
                for jj in range(a_start_i, stop_i + 1):
                    dj = da + db / (Q(4999, 10000) - model.rate * (jj + 38))
                    pair = (da, db) if dj > 0 else (0, 0)
                    if d_list and d_list[-1][1] == jj - 1 and d_list[-1][2:] == pair:
                        d_list[-1] = (d_list[-1][0], jj, *pair)
                    else:
                        d_list.append((jj, jj, *pair))
            elif d0 > 0 or d1 > 0:
                d_list.append((a_start_i, stop_i, da, db))
            else:
                d_list.append((a_start_i, stop_i, 0, 0))

        debit_runs[c] = tuple(d_list)
        repriced_runs[c] = tuple(r_list)
    return debit_runs, repriced_runs


def eval_runs_price(model: Native, runs_map: dict[int, tuple], c: int, previous: int | None = None):
    """Exact replica of Native.price(c, previous) for an arbitrary sector-run map."""
    n = model.n
    starts = {0, n}
    current = runs_map[c]
    prior = runs_map[previous] if previous is not None else ()
    for sectors in (current, prior):
        for a, b, _, _ in sectors:
            starts.update([a, b + 1])
    starts_sorted = sorted(starts)

    def coeff(sec):
        out = {a: (x, y) for a, b, x, y in sec}
        if sec:
            out[sec[-1][1] + 1] = (0, 0)
        return out

    cc, old = coeff(current), coeff(prior)
    left = right = (0, 0)
    w = np.zeros(n)
    e = np.zeros(n)
    last = model.active_last(c)
    for a, b in zip(starts_sorted, starts_sorted[1:]):
        left = cc.get(a, left)
        right = old.get(a, right)
        end = min(b, last + 1)
        if a >= end:
            continue
        aa, bb = (Q(l - r, model.scale) * model.rho / 100 for l, r in zip(left, right))
        if not (aa or bb):
            continue
        base = exact_float_bounds(aa)
        slope = exact_float_bounds(bb)
        inv = tuple(x[a:end] for x in model.price_kernel)
        lo, hi = interval_multiply(inv, slope)
        w[a:end], e[a:end] = via_interval((P.down(base[0] + lo), P.up(base[1] + hi)))
    return w, e


def _erase_worker(args):
    library, bits, cache_dir, c = args
    out_file = Path(cache_dir) / f"delta-{c}.npz"
    if out_file.exists():
        return c, 0.0, True
    t0 = time.monotonic()
    configure(library, bits)
    model = Native()
    model.prepare()
    full = model.increment(c)
    assert full is not None
    delta = model.laws(c).erase(full)
    tmp = out_file.with_name(f"delta-{c}.{os.getpid()}.tmp.npz")
    np.savez(tmp, **{f"{k}{j}": v for k, pair in delta.items() for j, v in enumerate(pair)})
    os.replace(tmp, out_file)
    return c, time.monotonic() - t0, False


def _load_ball_dict(npz_path: Path, keys=("full", "core", "a", "b", "pair")):
    with np.load(npz_path, allow_pickle=False) as z:
        return {k: (z[f"{k}0"], z[f"{k}1"]) for k in keys}


def _contract_worker(args):
    library, bits, cache_dir, idx, c, previous, old_geom_cap, has_delta = args
    cache_path = Path(cache_dir)
    done_file = cache_path / f"cap-result-{c}.json"
    if done_file.exists():
        return json.loads(done_file.read_text())

    t0 = time.monotonic()
    configure(library, bits)
    model = Native()
    debit_runs, repriced_runs = build_extra_sector_tables(model)

    old = _load_ball_dict(cache_path / f"old-before-{old_geom_cap}.npz") if old_geom_cap is not None else {}
    delta = _load_ball_dict(cache_path / f"delta-{c}.npz") if has_delta else None
    if not old and delta is not None:
        old = {k: empty(v[0].shape) for k, v in delta.items()}

    integrals = {k: Integral() for k in ROLES_ALL}
    law = model.laws(c)
    core = model.core
    last = model.active_last(c)

    def make_forms(acc_key: str, field_role: str, weight, change=None):
        acc = integrals[acc_key]
        terms = []

        def add(a, b, w):
            ix = np.flatnonzero((w[0][: last + 1] != 0) | (w[1][: last + 1] != 0))
            if len(ix):
                terms.append((acc, a, b, w, ix))

        if delta is not None:
            add(delta[field_role], P.ball_add(delta[field_role], old[field_role], 2), weight)
        if previous is not None and change is not None:
            add(old[field_role], old[field_role], change)
        return terms

    price = model.price(c)
    jump = model.price(c, previous)
    d_price = eval_runs_price(model, debit_runs, c)
    d_jump = eval_runs_price(model, debit_runs, c, previous)
    r_price = eval_runs_price(model, repriced_runs, c)
    r_jump = eval_runs_price(model, repriced_runs, c, previous)

    if delta is not None:
        contract(law, core, 2, make_forms("full", "full", model.mass))
        contract(law, core, 0, make_forms("pair", "pair", model.pair))

    core_forms = (
        make_forms("core", "core", price, jump)
        + make_forms("debit_core", "core", d_price, d_jump)
        + make_forms("repriced_core", "core", r_price, r_jump)
    )
    contract(law, core - 1, 2, core_forms)

    ep_forms = (
        make_forms("a", "a", price, jump)
        + make_forms("b", "b", price, jump)
        + make_forms("debit_a", "a", d_price, d_jump)
        + make_forms("debit_b", "b", d_price, d_jump)
        + make_forms("repriced_a", "a", r_price, r_jump)
        + make_forms("repriced_b", "b", r_price, r_jump)
    )
    contract(law, core, 1, ep_forms)

    payload = {
        "index": idx,
        "cap": c,
        "previous": previous,
        "seconds": round(time.monotonic() - t0, 2),
        "integrals": {k: [str(v.low), str(v.high)] for k, v in integrals.items()},
    }
    tmp = done_file.with_name(f"cap-result-{c}.{os.getpid()}.tmp.json")
    tmp.write_text(json.dumps(payload, indent=2) + "\n")
    os.replace(tmp, done_file)
    return payload


def self_check_price_builder():
    """Verify eval_runs_price reproduces Native.price on old sectors and builds extra tables."""
    model = Native()
    debit_runs, repriced_runs = build_extra_sector_tables(model)
    assert len(debit_runs) == len(repriced_runs) == len(model.caps)
    old_doc = json.loads((H1_DIR / "h1_multilevel_strip_free.json").read_text())
    old_arr = np.asarray(old_doc["sector_prices"], dtype=object)
    frame = TS.stored_frame()
    labels_fn = TS.labeller(SimpleNamespace(k=39, n=model.n), frame, 1)
    old_runs = {}
    for c in model.caps:
        full_last = model.classes[c].full_last
        ids = labels_fn(c)[: full_last + 1]
        ends = np.r_[0, np.flatnonzero(ids[1:] != ids[:-1]) + 1, full_last + 1]
        r_list = []
        for i0, i1 in zip(ends[:-1], ends[1:]):
            s = int(ids[i0])
            oa, ob = (int(old_arr[s, 0]), int(old_arr[s, 1])) if s >= 0 else (0, 0)
            r_list.append((int(i0), int(i1) - 1, oa, ob))
        old_runs[c] = tuple(r_list)
    for idx, c in enumerate(model.caps):
        prev = model.caps[idx - 1] if idx > 0 else None
        w1, e1 = model.price(c, prev)
        w2, e2 = eval_runs_price(model, old_runs, c, prev)
        assert np.array_equal(w1, w2) and np.array_equal(e1, e2), f"Mismatch at cap {c}"


def ratio_bounds(num_lo: Q, num_hi: Q, den_lo: Q, den_hi: Q) -> list[str]:
    assert den_lo > 0
    cands = [num_lo / den_lo, num_lo / den_hi, num_hi / den_lo, num_hi / den_hi]
    return [str(min(cands)), str(max(cands))]


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--library", required=True, type=Path)
    ap.add_argument("--bits", default=160, type=int)
    ap.add_argument("--workers", default=5, type=int)
    ap.add_argument("--cache", required=True, type=Path)
    ap.add_argument("--output", required=True, type=Path)
    ap.add_argument("--self-check-only", action="store_true")
    args = ap.parse_args()

    t_start = time.monotonic()
    self_check_price_builder()
    if args.self_check_only:
        print("Self-check passed: eval_runs_price matches Native.price bit-for-bit.")
        return

    args.cache.mkdir(parents=True, exist_ok=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    pinned = input_hashes()
    binary_sha = sha256(args.library.resolve().read_bytes()).hexdigest()

    model = Native()
    geom_caps = [c for c in model.caps if c in model.groups]
    assert len(geom_caps) == 9

    print(f"[Stage 1] Computing 9 geometry erasures on {args.workers} workers (bits={args.bits})...", flush=True)
    erase_tasks = [(str(args.library), args.bits, str(args.cache), c) for c in geom_caps]
    with ProcessPoolExecutor(max_workers=args.workers) as ex:
        futs = [ex.submit(_erase_worker, t) for t in erase_tasks]
        for fut in as_completed(futs):
            c, dt, cached = fut.result()
            print(f"  delta cap={c} done in {dt:.1f}s (cached={cached})", flush=True)

    print("[Stage 1.5] Building exact sequential cumulative field states...", flush=True)
    old_state = {}
    old_geom_for_cap: dict[int, int | None] = {}
    current_geom_tag: int | None = None
    for c in model.caps:
        old_geom_for_cap[c] = current_geom_tag
        if c in model.groups:
            delta_c = _load_ball_dict(args.cache / f"delta-{c}.npz")
            if not old_state:
                old_state = {k: empty(v[0].shape) for k, v in delta_c.items()}
            for k in old_state:
                old_state[k] = P.ball_add(old_state[k], delta_c[k])
            current_geom_tag = c
            out_old = args.cache / f"old-before-{c}.npz"
            if not out_old.exists():
                tmp = out_old.with_name(f"old-before-{c}.{os.getpid()}.tmp.npz")
                np.savez(tmp, **{f"{k}{j}": v for k, pair in old_state.items() for j, v in enumerate(pair)})
                os.replace(tmp, out_old)

    print(f"[Stage 2] Contracting all {len(model.caps)} caps on {args.workers} workers...", flush=True)
    contract_tasks = []
    for idx, c in enumerate(model.caps):
        prev = model.caps[idx - 1] if idx > 0 else None
        contract_tasks.append((
            str(args.library),
            args.bits,
            str(args.cache),
            idx,
            c,
            prev,
            old_geom_for_cap[c],
            c in model.groups,
        ))

    cap_results = []
    with ProcessPoolExecutor(max_workers=args.workers) as ex:
        futs = [ex.submit(_contract_worker, t) for t in contract_tasks]
        for fut in as_completed(futs):
            res = fut.result()
            cap_results.append(res)
            print(
                f"  [{len(cap_results):2d}/{len(model.caps)}] cap={res['cap']} finished in {res['seconds']}s "
                f"(elapsed {time.monotonic() - t_start:.1f}s)",
                flush=True,
            )

    cap_results.sort(key=lambda r: r["index"])
    totals = {k: Integral() for k in ROLES_ALL}
    for r in cap_results:
        for k in ROLES_ALL:
            lo_s, hi_s = r["integrals"][k]
            totals[k].low += Q(lo_s)
            totals[k].high += Q(hi_s)

    core_m = model.core
    m_int = totals["full"]
    p_int = totals["pair"]

    old_num_lo = core_m * totals["core"].low + totals["a"].low + totals["b"].low - p_int.high
    old_num_hi = core_m * totals["core"].high + totals["a"].high + totals["b"].high - p_int.low
    q_old_bounds = ratio_bounds(old_num_lo, old_num_hi, m_int.low, m_int.high)

    deb_num_lo = max(Q(0), core_m * totals["debit_core"].low + totals["debit_a"].low + totals["debit_b"].low)
    deb_num_hi = core_m * totals["debit_core"].high + totals["debit_a"].high + totals["debit_b"].high
    u_debit_bounds = ratio_bounds(deb_num_lo, deb_num_hi, m_int.low, m_int.high)

    rep_num_lo = core_m * totals["repriced_core"].low + totals["repriced_a"].low + totals["repriced_b"].low - p_int.high
    rep_num_hi = core_m * totals["repriced_core"].high + totals["repriced_a"].high + totals["repriced_b"].high - p_int.low
    q_rep_bounds = ratio_bounds(rep_num_lo, rep_num_hi, m_int.low, m_int.high)

    # Continuum ordinary mass lower bound via certified cellwise Dickman deficit < 3.266e-10 on <= 2 high sites:
    transfer_doc = json.loads((H1_DIR / "h1_b2_direct_cap_transfer.json").read_text())
    assert Q(str(transfer_doc["relative_deficit"])) < Q("0.0000000003266")
    dickman_factor = (1 - Q("0.0000000003266")) ** 2
    continuum_scaled_mass_lower = m_int.low * dickman_factor
    continuum_raw_mass_lower = continuum_scaled_mass_lower / (Q(100) ** 39)

    summary = {
        "source_hashes": pinned,
        "compiled_library_sha256": binary_sha,
        "bits": args.bits,
        "workers": args.workers,
        "elapsed_seconds": round(time.monotonic() - t_start, 2),
        "totals_100pow39": {k: [str(v.low), str(v.high)] for k, v in totals.items()},
        "native_mass_100pow39_float": [float(m_int.low), float(m_int.high)],
        "continuum_ordinary_mass_scaled_lower": str(continuum_scaled_mass_lower),
        "continuum_ordinary_mass_raw_lower": str(continuum_raw_mass_lower),
        "continuum_ordinary_mass_raw_lower_float": float(continuum_raw_mass_lower),
        "native_quotient_old_bounds": q_old_bounds,
        "native_quotient_old_float": [float(Q(x)) for x in q_old_bounds],
        "portable_cover_debit_u_bounds": u_debit_bounds,
        "portable_cover_debit_u_float": [float(Q(x)) for x in u_debit_bounds],
        "native_quotient_repriced_bounds": q_rep_bounds,
        "native_quotient_repriced_float": [float(Q(x)) for x in q_rep_bounds],
        "per_cap_results": cap_results,
    }
    args.output.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if k != "per_cap_results"}, indent=2), flush=True)


if __name__ == "__main__":
    main()
