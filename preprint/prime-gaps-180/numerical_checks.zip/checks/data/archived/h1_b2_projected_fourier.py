"""Directed arithmetic for the projected 39-site Gram, using a power-of-two Fourier torus."""
import argparse
import ctypes
from fractions import Fraction as Q
from functools import cache
from math import ceil, perm
from pathlib import Path
from tempfile import TemporaryDirectory
from time import monotonic
import json

from flint import arb, arb_mat, ctx, fmpq
import numpy as np

import h1_b2_projected_gram as P


U = 2.**-53
TINY = 2.**-700
HERE = Path(__file__).resolve().parent
_DOT = None


def use_dots(path):
    global _DOT
    lib = ctypes.CDLL(str(Path(path).resolve()))
    fun = lib.projected_dots
    fun.argtypes = [ctypes.c_size_t]*3+[ctypes.c_void_p]*8
    fun.restype = None
    _DOT = fun


def dots(C,abs_c,rc,zw,abs_zw,rzw):
    if _DOT is not None:
        values=np.empty((len(C),len(zw)))
        errors=np.empty_like(values)
        arrays = [np.ascontiguousarray(a) for a in (C,abs_c,rc,zw.T,abs_zw.T,rzw.T)]
        _DOT(len(C),C.shape[1],len(zw),*[a.ctypes.data for a in [*arrays,values,errors]])
        return values,errors
    # This path also uses explicit products and binary64 reductions, without BLAS.
    values=np.empty((len(C),len(zw)))
    errors=np.empty_like(values)
    for i in range(len(C)):
        values[i]=np.sum(C[i].real*zw.real-C[i].imag*zw.imag,axis=1)
        errors[i]=np.sum(rc[i]*(abs_zw+rzw)+abs_c[i]*rzw+(2.**-39*abs_c[i])*abs_zw,axis=1)
    return values,errors


def ball(x):
    if isinstance(x,Q): return arb(fmpq(x.numerator,x.denominator))
    return arb(float(x))


def upper_float(value):
    x = float(value.upper())
    out=float(np.nextafter(x,np.inf))
    assert ball(out)>=value
    return out


@cache
def twiddles(n):
    assert n>=2 and n&(n-1)==0
    values = []
    for j in range(n//2):
        sn,cs = (-2*arb.pi()*j/n).sin_cos()
        a,b = float(cs.mid()),float(sn.mid())
        assert abs(cs-ball(a)) < 2*U and abs(sn-ball(b)) < 2*U
        values.append(complex(a,b))
    return np.asarray(values)


@cache
def reversed_bits(n):
    order = np.arange(n,dtype=np.int64)
    out = np.zeros_like(order)
    for _ in range(n.bit_length()-1):
        out = 2*out+(order&1)
        order >>= 1
    return out


def fft_axis(x):
    n = x.shape[-1]
    y = np.ascontiguousarray(x[...,reversed_bits(n)],dtype=np.complex128)
    for j in range(1,n.bit_length()):
        length = 1<<j
        pairs = y.reshape(-1,length)
        first = pairs[:,:length//2].copy()
        rotated = pairs[:,length//2:]*twiddles(length)
        pairs[:,:length//2] = first+rotated
        pairs[:,length//2:] = first-rotated
    return y


def transform(array, shape, input_rel):
    """Return the half spectrum and an absolute complex error per Fourier node."""
    n,m = map(int,shape)
    assert n&(n-1)==m&(m-1)==0 and min(n,m)>1 and n*m<=2**24
    assert np.isfinite(array).all() and np.max(abs(array))<2.**160
    x = np.zeros(shape,dtype=float)
    x[:array.shape[0],:array.shape[1]] = array
    temp = fft_axis(x)[:,:m//2+1]
    result = fft_axis(temp.T).T.copy().reshape(-1)
    stages = n.bit_length()+m.bit_length()-2
    # Each radix-two path has one unit rotation and one addition per stage.
    # The L1 sum itself may use any parenthesization of at most 2^24 additions.
    norm = float(np.sum(abs(array)))*(1+2.**-28)
    err = (input_rel+18*stages*U+8*U)*norm+2.**-640
    return result,err


def supmag(z):
    # All magnitudes used below are bounded; the additive guard covers underflow.
    return np.sqrt(z.real*z.real+z.imag*z.imag)*(1+4*U)+TINY


def packed_moments(trans, errors, weight, weight_error):
    single = weight.ndim==1
    weight = np.atleast_2d(weight)
    weight_error = np.broadcast_to(weight_error,(len(weight),))
    shape = len(weight),len(P.ANG),len(P.PAIR)
    total,uncert = np.zeros(shape),np.zeros(shape)
    n = trans.shape[1]
    assert np.max(supmag(trans)+errors[:,None])<4 and np.max(supmag(weight))<2.**135
    span = 2048
    assert ceil(n/span)<=4096
    for start in range(0,n,span):
        m = trans[:,start:start+span]
        e = errors[:,None]
        hi = supmag(m)+e
        ratio = e/hi
        # Explicit integer powers avoid reliance on a platform complex power routine.
        powers = [np.ones(m.shape[1],dtype=complex)]
        high_powers = [np.ones(m.shape[1])]
        for _ in range(37):
            powers.append(powers[-1]*m[0])
            high_powers.append(high_powers[-1]*hi[0])
        C = np.zeros((len(P.ANG),m.shape[1]),dtype=complex)
        rc = np.zeros(C.shape,dtype=float)
        for i,sig in enumerate(P.ANG):
            for blocks,count in P._partitions(sig):
                k = 37-len(blocks)
                mult = count*perm(37,len(blocks))
                assert mult<2**53
                term = powers[k]*mult
                top = high_powers[k]*mult
                rel = k*ratio[0]
                for p in blocks:
                    term = term*m[p]
                    top = top*hi[p]
                    rel = rel+ratio[p]
                C[i] += term
                rc[i] += top*(rel+2.**-43)
        rc = rc*(1+2.**-39)+TINY
        ab,cd = np.asarray(P.PAIR).T+13
        z = m[ab]*m[cd]
        rz = (hi[ab]*hi[cd]*(ratio[ab]+ratio[cd]+12*U))*(1+2.**-45)+TINY
        abs_c,abs_z = supmag(C),supmag(z)
        for j,(w,ew) in enumerate(zip(weight[:,start:start+span],weight_error)):
            wmag = supmag(w)
            zw = z*w
            rzw = (rz*(wmag+ew)+abs_z*ew+12*U*(abs_z+rz)*(wmag+ew))*(1+2.**-45)+TINY
            abs_zw = supmag(zw)
            # Explicit signed and absolute reductions. Gamma_(4*span+4) is below 2^-39.
            value,radius=dots(C,abs_c,rc,zw,abs_zw,rzw)
            uncert[j] += radius*(1+2.**-38)+2*U*(abs(total[j])+abs(value))+TINY
            total[j] += value
    assert np.isfinite(total).all() and np.isfinite(uncert).all()
    radius=uncert*(1+2.**-38)+TINY
    return (total[0],radius[0]) if single else (total,radius)


def directed_gram(center,radius,lo,hi,suffix):
    """Evaluate the radial Bernstein and centering upper bounds in Arb."""
    entries = [arb(float(center[s,t]),float(radius[s,t])) for s in range(len(P.ANG)) for t in range(len(P.PAIR))]
    cols = len(P.SIGS)
    idx = (P.SIG_INDEX[None,:,None,:]*len(P.PAIR)+P.END_INDEX[:,None,:,None]).reshape(99,99)
    G = arb_mat([[entries[int(v)] for v in row] for row in idx])
    controls = [[block[i,s][a] for i in range(9) for s in range(cols)]
                for _,block in P.radial_blocks(lo,hi,suffix) for a in range(4)]
    def upper_norms(rows):
        bs = arb_mat([[ball(x) for x in row] for row in rows])
        m = bs*G*bs.transpose()
        tops = [m[i,i].upper() for i in range(len(rows))]
        assert all(t>=0 for t in tops)
        return tops
    scores = [sum(upper_norms(controls)).upper()]
    for c in (controls[0],controls[-1],[sum(col)/len(col) for col in zip(*controls)]):
        diffs = [[a-b for a,b in zip(row,c)] for row in controls]
        main, = upper_norms([c])
        scores.append(((main.sqrt()+sum(upper_norms(diffs)).sqrt())**2).upper())
    return min(map(upper_float,scores))


def site_fields(last,width,balanced):
    h = float(P.S/P.N)
    ids = np.arange(last+1)
    t = (ids+.5)*h
    g = .105/(1+.01*t)+.895/(1+181.4*t)
    endpoint = [np.ones_like(t),(t/float(P.S))*(t/float(P.S)),1/(1+300*t)]
    powers = [np.ones_like(t)]
    for _ in range(12): powers.append(powers[-1]*t)
    starts = sorted(set(range(0,last+1,width)) | ({27971} if last>=27971 else set()))
    raw=[100*h*g*g*v for v in [*powers,*[endpoint[i]*endpoint[j] for i,j in P.END]]]
    k=np.asarray(starts)//width
    def compress(weight):
        return np.stack([np.add.reduceat(v*weight,starts) for v in raw])
    if balanced:
        # Integer numerators keep the zero at the left edge exact.
        fields=np.hstack([compress((width-(ids%width))/width),compress((ids%width)/width)])
        k=np.r_[k,k+1]
    else: fields=compress(1.)
    # Every primitive field expression uses positive operations. At most width
    # additions then combine fields. This includes the errors in all decimal constants.
    return k,fields


def pow2(n): return 1<<(int(n)-1).bit_length()


def tilted_axis(base,n):
    # The base itself defines an exact positive dyadic tilt.
    assert .5 < base < 2
    values = []
    for i in range(n):
        x = ball(base)**i
        f = float(x.mid())
        assert 2.**-150<f<2.**150 and abs(x-ball(f))<2*U*x
        values.append(f)
    return np.asarray(values)


def panel(g,args,pr=None):
    started = monotonic()
    if pr is None: pr = P.Projection(g,args.radial,args.tail,[args.dust]*3,args.edge_group,True)
    ix = np.flatnonzero(g.edges[pr.middle]==args.edge).item()
    edge,end = int(g.edges[pr.middle[ix]]),int(g.edges[pr.ending[ix]+1])
    radius=args.round_radius
    n,k,_,density,dust,group = P.bank(g,pr,args.cap,edge,end,args.radial,args.tail,args.micro,args.dust,balanced=bool(radius))
    last = g.lasts[group[0]]
    keys,fields = site_fields(last,args.radial,bool(radius))
    assert np.array_equal(k,keys) and args.radial<=512 and density.shape[0]<=32
    max_tail = ceil((last+39)*g.tick/args.tail)+39
    extra=radius*args.radial if radius else 39*(args.radial-1)
    back=radius*args.radial
    output_limit=(last+back)//args.radial+1
    nk=args.grid_radial or pow2(max(n,output_limit)*args.period)
    ny=args.grid_tail or pow2(max_tail*args.period+1)
    assert nk>=max(n,output_limit) and ny>max_tail and ny>=density.shape[-1]
    K,L = np.arange(nk),np.arange(ny)
    low = np.maximum(0,K*args.radial-back)
    if args.all_radial:
        first=max(0,ceil(Q(102994-extra,args.radial)))
        panels=[(j,min(output_limit,j+args.count)) for j in range(first,output_limit,args.count)]
    else:
        panels=[(args.first,args.first+args.count)]
    assert 0<=panels[0][0]<panels[-1][1]<=output_limit
    lookup = np.minimum(K*args.radial+extra,last)//pr.lookup_width
    A = pr.first[group[0]][lookup,ix]
    B = g.low[np.minimum(low,last)]+pr.second[group[0]][lookup,ix]
    sx = tilted_axis(float(np.exp(-args.beta*float(P.S/P.N)*args.radial)),nk)
    sy = tilted_axis(float(np.exp(args.eta*args.tail/2624990)),ny)
    tilt = sx[:n,None]*sy[:density.shape[-1]]
    comp = 1/(sx[:,None]*sy)
    weights = {}
    for level,D in enumerate(dust):
        take = (K[:,None]>=panels[0][0])&(K[:,None]<panels[-1][1])&(L*args.tail>A[:,None])&(L*args.tail+D>B[:,None])&(L<=max_tail)
        if not take.any():continue
        require = 3 if group[0] else 1
        for d,ds in ([(level,1),(level-1,-1)] if level else [(level,1)]):
            for flags in range(4):
                if flags & ~require:continue
                key = (d,flags)
                if key not in weights:weights[key]=np.zeros((nk,ny),dtype=np.int16)
                weights[key]+=ds*(-1)**((require^flags).bit_count())*take
    gram = np.zeros((len(panels),len(P.ANG),len(P.PAIR)))
    radii = np.zeros_like(gram)
    shape=(nk,ny)
    site_time=monotonic()-started
    assert density.max()<4 and np.isfinite(density).all() and density.min()>=0
    assert np.min(density[density>0],initial=1.)>2.**-450 and np.min(fields[fields>0])>2.**-245
    subtotals=[]
    live_panels=set()
    for (layer,flags),test in weights.items():
        if not test.any():continue
        selected=[f for f in range(4) if not (f & ~flags)]
        data=density[:layer+1,selected].sum(axis=(0,1))
        trans,errors=[],[]
        for row in fields:
            d=np.zeros((n,data.shape[1]))
            np.add.at(d,k,row[:,None]*data)
            m,e=transform(d*tilt,shape,(args.radial+4*len(dust)+180)*U)
            trans.append(m)
            errors.append(e)
        mult=np.full(ny//2+1,2.);mult[0]=mult[-1]=1.
        live=[];ws=[];ew=[]
        for j,(a,b) in enumerate(panels):
            if not test[a:b].any():continue
            v=np.zeros(shape)
            v[a:b]=test[a:b]*comp[a:b]
            z,ez=transform(v,shape,16*U)
            ws.append((z.reshape(nk,-1).conj()*mult/(nk*ny)).ravel())
            ew.append(2*ez/(nk*ny)+TINY)
            live.append(j)
        live_panels.update(live)
        center,err=packed_moments(np.asarray(trans),np.asarray(errors),np.asarray(ws),np.asarray(ew))
        radii[live] += err+4*U*(abs(gram[live])+abs(center))+TINY
        gram[live] += center
        subtotals.append([layer,flags,float(center[:,0,0].sum()),float(err[:,0,0].sum())])
    radii = radii*(1+2.**-42)+TINY
    ranges=[(max(102994,a*args.radial-back),min(last,(b-1)*args.radial+extra)) for a,b in panels]
    suffix=sum(v<args.cap for v in pr.components)
    raw=[];diag=[]
    for j,(lo,hi) in enumerate(ranges):
        assert lo<=hi
        if j in live_panels:
            raw.append(directed_gram(gram[j],radii[j],lo,hi,suffix))
            try: diag.append(P.gram_upper(gram[j],lo,hi,suffix))
            except AssertionError: diag.append(None)
        else:
            # The signed acceptance mask was identically zero for every layer and flag.
            raw.append(0.);diag.append(0.)
    if radius:
        from h1_b2_radial_rounding import captured
        capture=captured(args.radial,radius)[0]
    else: capture=Q(1)
    upper=upper_float(sum(ball(z) for z in raw)/ball(capture))
    return dict(scope="Upper on one complete projected panel under its positive native-site density envelopes. The full middle range is separate.",
                cap=args.cap,edge_group=[edge,end],radial_output_bins=[panels[0][0],panels[-1][1]-1],possible_J=[ranges[0][0],ranges[-1][1]],grid=list(shape),
                site_radial=args.radial,site_tail=args.tail,site_dust=args.dust,micro=args.micro,
                dyadic_x=float(sx[1]).as_integer_ratio(),dyadic_y=float(sy[1]).as_integer_ratio(),
                independent_round_radius=radius,minimum_capture=str(capture),panel_bounds_before_capture=raw,
                constant_center=float(gram[:,0,0].sum()),constant_radius=float(radii[:,0,0].sum()),
                outward_scaled_upper=upper,fraction_at_previous_floor=upper_float(ball(upper)/ball(Q("46.1984860121"))),
                center_only_diagnostic=None if None in diag else sum(diag)/float(capture),subtotals=subtotals,
                site_seconds=round(site_time,3),total_seconds=round(monotonic()-started,3))


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    for name,default in (("cap",39058),("edge",290000),("edge-group",4),("radial",128),("first",912),
                         ("count",8),("tail",15000),("micro",1000),("dust",150000),("period",2),
                         ("round-radius",0),("grid-radial",0),("grid-tail",0)):
        p.add_argument("--"+name,type=int,default=default)
    p.add_argument("--beta",type=float,default=31.)
    p.add_argument("--eta",type=float,default=18.)
    p.add_argument("--gates",type=Path)
    p.add_argument("--output",type=Path)
    p.add_argument("--library",type=Path)
    p.add_argument("--all-radial",action="store_true")
    args=p.parse_args()
    ctx.prec=128
    if args.library:use_dots(args.library)
    with TemporaryDirectory() as tmp: result=panel(P.Gates(args.gates or P.rebuild(Path(tmp))),args)
    raw=json.dumps(result,indent=2)+"\n"
    if args.output:args.output.write_text(raw)
    print(raw,end="")
