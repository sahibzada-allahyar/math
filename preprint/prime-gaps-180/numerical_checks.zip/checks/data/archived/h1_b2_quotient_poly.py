"""Directed nonnegative products and signed erasures for the finite quotient.

Build h1_b2_packed_poly.cpp against GMP and supply its library path at startup.
All stored centers of positive polynomials are lower bounds, coefficientwise.
"""
import ctypes
from dataclasses import dataclass
from math import frexp,ldexp
from pathlib import Path

import numpy as np


TINY=2.**-1000
EPS=2.**-50
LIB=None
BITS=256
ARRAY=np.ctypeslib.ndpointer(dtype=np.float64,ndim=1,flags='C_CONTIGUOUS')


def configure(path,bits=256):
    global LIB,BITS
    assert 96<=bits<=512
    BITS=bits
    LIB=ctypes.CDLL(str(Path(path).resolve()))
    LIB.positive_convolution.argtypes=[ARRAY,ctypes.c_int,ARRAY,ctypes.c_int,ARRAY,
                                        ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int]
    LIB.positive_convolution.restype=None


def up(x):
    return np.nextafter(x,np.inf)


def down(x):
    return np.nextafter(x,-np.inf)


def safe(x):
    # At most 30 ordinary nonnegative operations in one scalar expression.
    return float(up((x+TINY)*(1+2.**-44)))


def upper_sum(x):
    # Even a serial binary64 sum of <=2^18 nonnegative numbers has
    # relative error under 2^-34. There is no cancellation here.
    assert len(x)<=2**18
    return safe(float(np.sum(x))*(1+2.**-33))


@dataclass
class Positive:
    low:np.ndarray
    relative:float=0.
    absolute:float=0.

    def __post_init__(self):
        self.low=np.ascontiguousarray(self.low,dtype=np.float64)
        assert np.all(np.isfinite(self.low)) and np.all(self.low>=0)
        assert self.relative>=0 and self.absolute>=0
        self.norm=upper_sum(self.low)
        self.exponent=frexp(float(np.max(self.low,initial=0)))[1]

    @classmethod
    def interval(cls,low,high):
        low=np.asarray(low);high=np.asarray(high)
        assert np.all((0<=low)&(low<=high))
        pos=low>0
        # Subtraction is outward-enclosed in case the endpoints have a
        # large dynamic range. Tiny zero-lower entries use an additive term.
        rel=float(np.max(up(up(high[pos]-low[pos])/low[pos]),initial=0.))
        add=float(np.max(high[~pos],initial=0.))
        return cls(low,rel,add)

    def bounds(self):
        high=up(up(self.low*up(1+self.relative))+self.absolute)
        return self.low,high

    def times_integer(self,m):
        assert 0<m<2**53
        if m==1:return self
        return Positive(np.maximum(0,down(self.low*m)),safe(self.relative+EPS*(1+self.relative)),safe(self.absolute*m))

    def plus(self,b):
        return Positive(np.maximum(0,down(self.low+b.low)),
                        safe(max(self.relative,b.relative)+EPS*(1+max(self.relative,b.relative))),
                        safe(self.absolute+b.absolute))

    def multiply(self,b,n):
        na=min(n,len(self.low));nb=min(n,len(b.low))
        out=np.empty(n)
        sa,sb=BITS-self.exponent,BITS-b.exponent
        LIB.positive_convolution(self.low,na,b.low,nb,out,n,sa,sb,BITS)
        # q_a=floor(a*2^sa)/2^sa and likewise for b; their l1 norms
        # are at most the recorded centre norms. GMP returns the product
        # rounded down by at most a relative 2^-51 plus 2^-1021.
        ra,rb=self.relative,b.relative
        ea=self.absolute+max(ldexp(1.,-sa),2.**-1020)*(1+ra)
        eb=b.absolute+max(ldexp(1.,-sb),2.**-1020)*(1+rb)
        absolute=safe(ea*(1+rb)*b.norm+eb*(1+ra)*self.norm+min(na,nb)*ea*eb+2.**-1020)
        relative=safe(ra+rb+ra*rb+EPS*(1+ra)*(1+rb))
        return Positive(out,relative,absolute)


def split_bounds(pair):
    """Nonnegative R with |v-mid|<=R for v in pair."""
    lo,hi=pair
    assert np.all(lo<=hi)
    mid=np.where(lo==hi,lo,lo*.5+hi*.5)
    radius=up(np.maximum(up(mid-lo),up(hi-mid)))
    radius=np.where(lo==hi,0.,radius)
    return mid,radius


def ball_add(a,b,m=1):
    x,r=a;y,s=b
    assert m in (1,2)
    z=x+m*y
    return z,up(up(r+m*s)+up(EPS*up(np.abs(z)+TINY)))


def ball_bounds(x,r):
    return down(x-r),up(x+r)


def positive_product(a,b):
    return np.maximum(0,down(a[0]*b[0])),up(a[1]*b[1])


def correlated(row,kernel):
    """Signed native correlation with nonnegative insertion kernel, one
    balanced row per retained J. The source row may have a long zero prefix
    or suffix; all such structural zeros remain exact in the full erasure.
    """
    mid,rad=row
    lo,hi=kernel
    n=len(mid)
    nz=np.flatnonzero((mid!=0)|(rad!=0))
    if not len(nz):return np.zeros(n),np.zeros(n)
    stop=nz[-1]+1
    km=Positive.interval(lo[:stop],hi[:stop]);row_rev=mid[:stop][::-1]
    p=Positive(np.maximum(row_rev,0)).multiply(km,stop)
    m=Positive(np.maximum(-row_rev,0)).multiply(km,stop)
    r=Positive(rad[:stop][::-1]).multiply(km,stop)
    pl,ph=p.bounds();ml,mh=m.bounds();_,rh=r.bounds()
    l=down(down(pl-mh)-rh);u=up(up(ph-ml)+rh)
    x,y=split_bounds((l[::-1],u[::-1]))
    return np.pad(x,(0,n-stop)),np.pad(y,(0,n-stop))
