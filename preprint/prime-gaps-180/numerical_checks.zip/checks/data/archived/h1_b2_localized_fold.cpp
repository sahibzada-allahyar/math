#include <algorithm>
#include <cstdint>

// For each retained (k,l), integrate the full threshold window against one
// independently marked bare site. Prefix entries are exact unsigned integers.
extern "C" void fold_bare(int n,int nt,int nr,int rt,int full_lo,int full_hi,
                           const uint64_t* prefix,const int* left,const int* right,
                           uint64_t* out) {
    for (int k=0;k<nr;k++) {
        auto* row=out+k*rt;
        for (int b=std::max(0,full_lo-k);b<std::min(n,full_hi-k);b++) {
            const auto* p=prefix+b*(nt+1);
            const int l=left[k+b], r=right[k+b];
            if (l>=r) continue;
            for (int t=std::max(0,l-nt+1);t<std::min(rt,r);t++) {
                const int a=std::max(0,l-t),z=std::min(nt,r-t);
                if (a<z) row[t]+=p[z]-p[a];
            }
        }
    }
}
