"""Track the H1 proof margin for a frozen trial and a compatible divisor ledger."""
import argparse
from fractions import Fraction
from hashlib import sha256
import json
from math import ceil, floor
from pathlib import Path
from time import sleep


HERE = Path(__file__).resolve().parent
UNIT = 10**12
DEFAULT_LEDGER = HERE/'h1_outer_laplace_refined_budget.json'
DEFAULT_FALLBACK = HERE/'h1_margin_fallback_65536.json'


def receipt(path, *, live=False):
    # The interval producer rewrites its checkpoint while it is running.
    for attempt in range(3):
        data = path.read_bytes()
        try:
            return json.loads(data), sha256(data).hexdigest()
        except json.JSONDecodeError:
            if not live or attempt == 2:
                raise
            sleep(0.1)


def require_input(document, path, digest):
    if document['inputs'].get(path.name) != digest:
        raise ValueError(f'Incompatible or stale input: {path.name}')


def prefix_hash(layers):
    entries = [[r['cap'], r['priced_contribution'], r['unweighted_contribution']] for r in layers]
    return sha256(json.dumps(entries, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def decimal(units):
    whole, part = divmod(abs(units), UNIT)
    digits = f'{whole}.{part:012d}'.rstrip('0').rstrip('.')
    return ('-' if units < 0 else '') + digits


def margin(finite, cap_lower, divisor_charge, unresolved, generic_charge=None):
    """Return exact decimal scores with bounds rounded outwards to 1e-12."""
    if divisor_charge < 0 or unresolved < 0 or (generic_charge is not None and generic_charge < 0):
        raise ValueError('Invalid divisor ledger')
    finite_units = floor(finite * UNIT)
    booked = ceil(divisor_charge * UNIT)
    integration = None
    headroom = finite_units - UNIT - booked
    if cap_lower is not None:
        integration = max(0, finite_units - floor(cap_lower * UNIT))
        headroom -= integration
    generic = None if generic_charge is None else ceil(generic_charge * UNIT)
    if unresolved == 0:
        generic = 0
    total = None if generic is None else booked + generic
    complete = integration is not None and total is not None
    return {
        'Q_finite_lower': decimal(finite_units),
        'E_integration': None if integration is None else decimal(integration),
        'E_divisors_booked': decimal(booked),
        'E_divisors_generic': None if generic is None else decimal(generic),
        'E_divisors': None if total is None else decimal(total),
        'finite_headroom_before_integration_and_generic_charge': decimal(finite_units - UNIT - booked),
        'headroom_after_booked_charges': decimal(headroom),
        'M': decimal(headroom - generic) if complete else None,
        'status': ('positive' if headroom > generic else 'nonpositive') if complete else 'incomplete',
    }


def benchmark(fit_path, prices_path, cap_path, ledger_path, fallback_path=None):
    fit, fit_hash = receipt(fit_path)
    _, prices_hash = receipt(prices_path)
    cap, cap_hash = receipt(cap_path, live=True)
    ledger, ledger_hash = receipt(ledger_path)
    audit_path = ledger_path.with_name('h1_outer_staircase_audit.json')
    audit, audit_hash = receipt(audit_path)
    require_input(ledger, audit_path, audit_hash)
    for doc in (fit, cap):
        require_input(doc, prices_path, prices_hash)
    for doc in (cap, audit):
        require_input(doc, fit_path, fit_hash)

    caps = cap['caps']
    layers = [r['cap'] for r in cap['layers']]
    if not caps or layers != caps[:len(layers)]:
        raise ValueError('Invalid integration checkpoint')
    cap_lower = None
    if cap['status'] == 'CONTINUOUS_CAP_SCORE_ENCLOSED':
        if layers != caps:
            raise ValueError('Incomplete cap integral labeled complete')
        interval = cap['cap_quotient']
        cap_lower = Fraction(interval['lower'])
        if cap_lower > Fraction(interval['upper']):
            raise ValueError('Reversed cap enclosure')
    elif cap['status'] != 'INCOMPLETE_CONTINUOUS_CAP_SCORE':
        raise ValueError('Unrecognized integration receipt')

    finite = Fraction(fit['families']['mixed']['lower_billionths'], 10**9)
    unresolved = ledger['unresolved_active_ordered_pairs']
    previous = audit['audit'][-1]
    remaining = previous['unresolved_active']
    charge = Fraction(previous['combined_error_upper'])
    for block in ledger['extra']:
        path = ledger_path.with_name(block['receipt'])
        source, digest = receipt(path)
        require_input(ledger, path, digest)
        if block['charge'] != source['upper'] or block['ordered_pairs'] <= 0:
            raise ValueError(f'Inconsistent divisor entry: {path.name}')
        remaining -= block['ordered_pairs']
        charge += Fraction(block['charge'])
    booked = Fraction(ledger['partial_upper'])
    if remaining != unresolved or booked < charge:
        raise ValueError('Divisor coverage or booked allowance disagrees with its inputs')
    generic = None
    fallback_info = {}
    prefix_info = {}
    if fallback_path is not None:
        fallback, fallback_digest = receipt(fallback_path)
        require_input(fallback, ledger_path, ledger_hash)
        require_input(fallback, fit_path, fit_hash)
        require_input(fallback, prices_path, prices_hash)
        count = fallback['layers_in_prefix']
        if (fallback['generic_ordered_pairs'] != unresolved or fallback['cap_schedule'] != caps
                or fallback['cap_inputs'] != cap['inputs'] or fallback['inventory_inputs'] != cap['inventory_inputs']
                or not 0 < count <= len(layers) or layers[count-1] != fallback['through']
                or prefix_hash(cap['layers'][:count]) != fallback['prefix_sha256']):
            raise ValueError('Fallback allowance belongs to a different trial or integration prefix')
        for name, expected in fallback['inputs'].items():
            path = fallback_path.with_name(name)
            if name == 'bilinear_minorant.json':
                path = path.parent.parent/'sensitivity'/name
            if sha256(path.read_bytes()).hexdigest() != expected:
                raise ValueError(f'Stale fallback input: {name}')
        generic = Fraction(fallback['generic_divisor_charge_upper'])
        if cap['status'] == 'CONTINUOUS_CAP_SCORE_ENCLOSED':
            energies = [Fraction(row[0]['upper']) for row in cap['normalized_sector_energies']]
            for scheme in fallback['sector_charge_uppers']:
                costs = list(map(Fraction, scheme))
                if not costs or len(costs) != len(energies) or min(costs) < 0 or min(energies) < 0:
                    raise ValueError('Invalid sector charges or completed continuous energies')
                generic = min(generic, sum(d*energy for d, energy in zip(costs, energies)))
        prefix_lower = Fraction(fallback['cap_lower'])
        if count < len(layers) and cap['status'] != 'CONTINUOUS_CAP_SCORE_ENCLOSED':
            norm_path = fallback_path.with_name('h1_combined_mass_native_interval.json')
            norm, norm_hash = receipt(norm_path)
            for doc in (fallback, cap):
                require_input(doc, norm_path, norm_hash)
            dlo, dhi = (Fraction(norm['normalized_norm'][k]) for k in ('lower', 'upper'))
            if not 0 < dlo <= dhi:
                raise ValueError('Invalid positive ordinary norm')
            numerator = sum(Fraction(r['priced_contribution']['lower']) for r in cap['layers'][:count])
            # The negative part of any later suffix is at most that of the entire frozen tail.
            negative_tail = Fraction(fallback['tail_negative_income_upper'])
            for index, layer in enumerate(cap['layers'][count:], count+1):
                numerator += Fraction(layer['priced_contribution']['lower'])
                bound = min(numerator/dlo, numerator/dhi) - negative_tail
                if bound > prefix_lower:
                    prefix_lower = bound
                    prefix_info = {'live_prefix_layers_used': index,
                                   'live_prefix_sha256': prefix_hash(cap['layers'][:index])}
        cap_lower = prefix_lower if cap_lower is None else max(cap_lower, prefix_lower)
        fallback_info = {fallback_path.name: fallback_digest}
    score = margin(finite, cap_lower, booked, unresolved, generic)
    report = {
        'criterion': 'H1, threshold 1, original coarsened prices; the divisor ledger includes the strip-price change once',
        'family': 'mixed',
        'receipts': {**{p.name: h for p, h in ((fit_path, fit_hash), (prices_path, prices_hash),
                                              (ledger_path, ledger_hash), (audit_path, audit_hash))}, **fallback_info},
        'cap_receipt': cap_path.name,
        'complete_cap_sha256': cap_hash if cap['status'] == 'CONTINUOUS_CAP_SCORE_ENCLOSED' else None,
        'covered_ordered_pairs': ledger['covered_ordered_pairs'],
        'ordered_pairs_without_local_bound': unresolved,
        'unresolved_active_ordered_pairs': unresolved if generic is None else 0,
        **prefix_info,
        **score,
    }
    return report, len(layers), len(caps)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fit', type=Path, default=HERE/'h1_decoupled_coarsened_1e14_fit.json')
    parser.add_argument('--prices', type=Path, default=HERE/'h1_decoupled_coarsened_1e14_prices.json')
    parser.add_argument('--cap', type=Path, default=HERE/'h1_combined_score_native_interval.json')
    parser.add_argument('--ledger', type=Path, default=DEFAULT_LEDGER)
    parser.add_argument('--fallback', type=Path, help='Full allowance for pairs outside this local ledger')
    parser.add_argument('--output', type=Path, help='Save the benchmark snapshot to this file')
    parser.add_argument('--check', action='store_true', help='Compare with --output without writing')
    args = parser.parse_args()
    fallback_path = args.fallback
    if fallback_path is None and args.ledger.resolve() == DEFAULT_LEDGER:
        fallback_path = DEFAULT_FALLBACK
    report, completed, total = benchmark(args.fit, args.prices, args.cap, args.ledger, fallback_path)
    if args.check:
        if not args.output:
            parser.error('--check requires --output')
        if receipt(args.output)[0] != report:
            raise SystemExit('Saved benchmark differs from the current receipts')
    elif args.output:
        args.output.write_text(json.dumps(report, indent=2)+'\n', newline='\n')
    print(f"M = {report['M'] if report['M'] is not None else 'pending'}; "
          f"integration layers {completed}/{total}; "
          f"pairings without a local bound {report['ordered_pairs_without_local_bound']}")


if __name__ == '__main__':
    main()
