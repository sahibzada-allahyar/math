"""Enclose a full-mask native insertion block of the asymmetric degree-six trial."""
import argparse
import contextlib
from fractions import Fraction as Q
import gzip
import io
import json
from math import ceil,prod
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace

from flint import arb,ctx,fmpq
import numpy as np

from h1_degree6_older_triangle import VECTOR
from h1_labelled_restoration_mc import build_gates,GATE_MINRAD,GATE_UNIT
from h1_mass_band_prices import digest,geom
from h1_multilevel_native_cap import CERT
from h1_two_source_endpoints import stored_frame,stored_model


GROUPS=Path(__file__).resolve().parents[2]/'lean'/'data'/'h1_decoupled_coarsened_1e14.json'
TILT=Path('h1_multilevel_tail_tilt2.json')
ROOT_SITES=[750103,580103]+[28003]*36
QUARTER=Q(1,4)
INSERT=(Q(50002),Q(50004))


def rebuild(directory):
    with gzip.open(CERT,'rt') as f:cert=json.load(f)
    used=directory/'used.npz';np.savez_compressed(used,used=np.array(cert['affine'][:14],dtype=np.int64)!=0)
    target=directory/'gates.npz'
    args=SimpleNamespace(norm='h1_combined_mass_native_interval.json',fibres='h1_combined_fibres_native_interval.json',
                         collar='h1_multilevel_price_collar.json',plateaus=TILT,tilt=2,used=used,
                         groups=GROUPS,radial_step=2000,spacing=10000,out=target)
    with contextlib.redirect_stdout(io.StringIO()):build_gates(args)
    return target


def fibre_intersection(frame,g):
    h=frame['step']; tick=h*geom.RHO*GATE_UNIT
    edges=list(map(int,g['edges'][:-1]));fine=g['fine'];radii=g['R'];ls=g['ls'];gates=g['gates'];step=int(g['radial_step'])
    assert gates.shape==(25600,185) and len(fine)==44 and np.array_equal(fine,np.sort(fine))
    groups=json.loads(GROUPS.read_text())['groups'];group=np.full(len(frame['energies']),len(groups),int)
    for i,individual in enumerate(groups):group[individual]=i
    # Integer ticks for mark locations, native bin indices for total coordinates.
    def between(a,b,fn):
        left,right=fn(a),fn(b);assert left==right,(a,b,left,right);return left
    def cell(x):return int(x//tick)
    def pos(s,x):return int(np.searchsorted(s,ceil(x/tick)))
    def checked_rule(sites,with_insert):
        big=max(sites); mark0,mark1=big-QUARTER,Q(big)
        if with_insert: assert mark0>INSERT[1]
        cid=between(mark0,mark1,lambda x:pos(fine,x))
        sid=between(mark0,mark1,lambda x:pos(frame['caps'],x))
        j=sum(between(v,v+QUARTER,cell) for v in sites)
        low=sum(sites,Q(0));upper=low+len(sites)*QUARTER
        if with_insert:
            j+=between(*INSERT,cell);low+=INSERT[0];upper+=INSERT[1]
        # Native 39-to-38 map from labeller at stride one.
        label=int(frame['layout'](frame['caps'][sid],np.array([j+1]))[0]);assert label>=0
        own=int(group[label]);assert upper<=int(radii[cid,own])
        radial=between(low,upper,lambda x:max(GATE_MINRAD//step,ceil(x/step))-GATE_MINRAD//step)
        key=int(ls[cid,own,radial]);assert key>=0
        # All residual fragments are below 1 tick. For the lowest bin also
        # cover code paths that add that negligible residual to the histogram.
        for v in sites:assert not any(v-QUARTER<e<=v for e in edges)
        min_tail=[sum((Q(v)-QUARTER for v in sites if v>=e),Q(0)) for e in edges]
        max_tail=[sum(v for v in sites if v>=e) for e in edges]
        max_tail[0]=upper-(INSERT[1] if with_insert else 0)
        # Positive tails at edge e contain a mark at least e, so the sampler's
        # additional half-edge test cannot make a positive tail pass a lower gate.
        assert np.all(gates[key]>=0)
        limits=[(Q(int(q))-hi,Q(int(q))-lo) for q,hi,lo in zip(gates[key],max_tail,min_tail,strict=True)]
        return key,limits
    own,base=checked_rule(ROOT_SITES,False);assert min(lo for lo,hi in base)>=0
    checks=[]
    for v in sorted(set(ROOT_SITES)):
        retained=ROOT_SITES.copy();retained.remove(v)
        key,limits=checked_rule(retained,True);checks.append((v,key,limits))
    low=[min(row[2][i][0] for row in checks) for i in range(len(edges))]
    high=[min(row[2][i][1] for row in checks) for i in range(len(edges))]
    active=[i for i,v in enumerate(low) if v<INSERT[1]]
    assert len(active)==1
    i=active[0]; e=edges[i]; C0,C1=low[i],high[i]
    assert INSERT[1]<3*e and INSERT[1]/2<C0<=C1<2*e<INSERT[0]
    return dict(own_key=own,other_keys=[(v,key) for v,key,limits in checks],edge=e,ceilings=(C0,C1))


def bspline(x,knots):
    b=[Q(int(a<=x<c)) for a,c in zip(knots,knots[1:])]
    for deg in range(1,4):
        out=[]
        for i in range(len(b)-1):
            l=knots[i+deg]-knots[i];r=knots[i+deg+1]-knots[i+1]
            out.append(((x-knots[i])*b[i]/l if l else 0)+((knots[i+deg+1]-x)*b[i+1]/r if r else 0))
        b=out
    assert sum(b)==1 and min(b)>=0
    return b


def profiles(frame,totals_in_ticks=None):
    h=frame['step'];S=h*131072; tick=h*geom.RHO*GATE_UNIT
    # Knot vectors and angular descriptors are invariant under the cell-count
    # argument. Radial basis values below are evaluated at the native midpoint.
    with contextlib.redirect_stdout(io.StringIO()):
        r,_,_,_,fit,_=stored_model(39,1024,6,frame)
    knots=tuple(map(Q,fit['shape_spec']['knots']));assert knots==tuple(r.knots)
    sigs=r.signatures
    totals=ROOT_SITES+[INSERT[0]] if totals_in_ticks is None else totals_in_ticks
    assert len(totals)==39
    mid=[(int(Q(v)//tick)+Q(1,2))*h for v in totals]
    J=sum(int(v/h) for v in mid); assert J+39<131072
    assert (J+39)*h<Q(r.shells['outer'][0][1]) and max(totals)/tick<min(frame['original']['component_limits'])
    spline=bspline(sum(mid),knots)
    assert digest(VECTOR)=='ae58b3d018eae9904fd2c6e869ba6f70cf77fcb982284a487ca9b6f446d2f624'
    with np.load(VECTOR,allow_pickle=False) as target:
        v=target['vector'].reshape(3,3,3,len(sigs),len(spline))
    # For this max all three native components are present in the first shell.
    cols=np.zeros((3,3,len(sigs)),object)
    for a,b,n in np.ndindex(cols.shape):
        cols[a,b,n]=sum((Q(float(v[a,b,c,n,j]))*z for c in range(3) for j,z in enumerate(spline) if z),Q(0))
    g=prod(Q(21,200)/(1+x/100)+Q(179,200)/(1+Q(907,5)*x) for x in mid)
    def site(x):return (Q(1),(x/S)**2,1/(1+300*x))
    def F(i,j):
        core=[x for l,x in enumerate(mid) if l not in (i,j)]
        p={e:sum(x**e for x in core) for e in range(2,7)}
        angular=[39**(sum(s)-len(s))*prod(p[e] for e in s) for s in sigs]
        return g*sum(a*b*sum(v*w for v,w in zip(cols[m,n],angular,strict=True))
                     for m,a in enumerate(site(mid[i])) for n,b in enumerate(site(mid[j])))
    return {f'{i},{j}':F(i,j) for i,j in ((0,1),(0,2),(1,2),(2,3),(0,38),(2,38))}


def ball(x):
    x=Q(x);return arb(fmpq(x.numerator,x.denominator))


def pass_mass(t,C,e):
    t,C,e=map(ball,(t,C,e));x=e/t
    two=((t/e).log()*((t-e)/e).log()-(1-x).polylog(2)+x.polylog(2))/2
    return 1-(t/C).log()-two


def endpoints(x,y,places):
    scale=10**places
    # Rounding in the safe direction; floor and ceil of ball endpoints.
    return [str(Q(int((x*scale).lower().floor().unique_fmpz()),scale)),str(Q(int((y*scale).upper().ceil().unique_fmpz()),scale))]


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--gates',type=Path);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();frame=stored_frame();ctx.prec=192
    with TemporaryDirectory() as directory:
        path=args.gates or rebuild(Path(directory))
        with np.load(path,allow_pickle=False) as gate:
            data=fibre_intersection(frame,gate)
            import hashlib
            gate_hash=hashlib.sha256(np.ascontiguousarray(gate['gates'].astype('<i8')).tobytes()).hexdigest()
    C0,C1=data['ceilings'];e=data['edge'];lo=pass_mass(INSERT[1],C0,e);hi=pass_mass(INSERT[0],C1,e)
    assert lo>0 and hi<1 and hi>lo
    output={};width=ball((INSERT[1]-INSERT[0])/(geom.RHO*GATE_UNIT))
    for tag,v in profiles(frame).items():
        a,b=lo,hi
        if v<0:a,b=b,a
        output[tag]=dict(sign=(v>0)-(v<0),profile=endpoints(ball(v),ball(v),25),
                         signed_erased_panel=endpoints(ball(v)*a*width,ball(v)*b*width,33))
    inputs=[Path(__file__),VECTOR,GROUPS,CERT,TILT,Path('h1_labelled_restoration_mc.py'),Path('h1_two_source_endpoints.py')]
    doc=dict(scope='Conditional continuum insertion mass in one positive-width retained-root neighborhood and one native-cell subinterval. Exact rational source conventions; gate lookup integers and 192-bit Arb bounds. This is not the complete restored erasure or its squared norm.',
             inputs={p.name:digest(p) for p in inputs},gate_table_sha256=gate_hash,
             retained_nominal_ticks=ROOT_SITES,retained_total_range_above_nominal='[0,1/4]',dominant_mark_range_below_nominal='[0,1/4]',
             inserted_total_ticks=list(map(str,INSERT)),retained_key=data['own_key'],other_keys=data['other_keys'],
             active_edge=e,ceiling_range_ticks=[str(C0),str(C1)],pass_fraction=endpoints(lo,hi,12),signed_profiles=output)
    args.output.write_text(json.dumps(doc,indent=2)+'\n');print(doc['pass_fraction'],doc['ceiling_range_ticks'],{k:v['sign'] for k,v in output.items()})


if __name__=='__main__':main()
