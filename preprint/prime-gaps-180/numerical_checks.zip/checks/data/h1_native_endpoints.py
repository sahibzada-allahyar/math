"""Native evaluator for a trial with two labelled endpoint coordinates (floating point, uncertified).

Trial class on the pinned backend geometry, k coordinates = (k-2) core + endpoints a, b:

  F = 1_outer * prod_core g(t_i) * sum coef[m,m',c,sigma,d]
        * u_m(t_a) u_m'(t_b) * 1[M0 <= limit_c] * B_d(total) * P^core_sigma * scale,

with u_m = g(t)/(1+alpha_m t) and power sums over the core coordinates only.
Mass, the k-2 core faces, the two endpoint faces and the double erasure at (a,b)
use the backend's cell weights, Dickman survival, moment banks, cap layers,
radial splines and erasure correlations.  Face forms are returned per role for
an arbitrary per-layer multiplier, so any multiplier form can be assembled.

Not a certificate: no enclosure, no ladder check beyond the supplied domains,
no restoration.  The pair kernel 'min' (pointwise minimum of the lift kernel and
a level-1/2 kernel) is kept for comparison only; it is NOT a valid bound, since
cross terms between low and high retained roots are covered by neither argument.
Use 'lift'.
"""
import json
import sys
import time
from fractions import Fraction as Q

import numpy as np
from scipy.fft import rfft, irfft
from scipy.linalg import eigh

from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
_saved = list(sys.argv)
sys.argv = sys.argv[:1]
import h1_knn_harmonic as D
from incidence_multicap_spline_ritz import basis_components, limited_shells, multicap_forms
from incidence_subtraction_tail_scan import cap_shells
sys.argv = _saved

EPS0 = 1e-4


def inside(r, shells, cap):
    mask = np.zeros(r.n, dtype=bool)
    for shell in shells:
        if cap <= shell[2]:
            mask |= r.mask(shell, r.k - 1)
    return mask


class Labelled:
    def __init__(self, k, intervals, angular, alphas, source='incidence_multicap_spline_a6_n32768.json', quiet=True,
                 spec_overrides=None, subtraction='source', model=None):
        """model, if given, is (backend model, component limits, subtraction shells) built elsewhere,
        for example on a refitted geometry with a fragment cap; it replaces the default construction."""
        prior = json.loads((D.BACKEND / 'results' / source).read_text())
        spec = {**prior['specification'], 'angular': angular, **(spec_overrides or {})}
        self.prior = prior
        self.kappa = prior['kappa']
        r = model[0] if model is not None else D.make_model(k, intervals, spec)
        assert r.k == k and r.N == intervals
        self.r, self.k, self.n = r, k, r.n
        self.core = k - 2
        p = r.geometry['parameters']
        self.rho_star = float(Q(p['rho_star']))
        step = r.exact_step
        maximum = max(sh[2] for sh in r.shells['outer'])
        self.limits = sorted({int(Q('.3788') // step), int(Q('.4745') // step), maximum})
        if model is not None:
            self.limits = sorted(int(x) for x in model[1])
        self.gram_native, self.components, self.axes = basis_components(r, self.limits)
        self.ncomp = len(self.limits)
        self.nbase = r.nb
        self.nr = r.nr
        self.sigs = list(r.signatures)
        self.sig_index = {s: i for i, s in enumerate(self.sigs)}
        self.sig_scale = np.array([float(k) ** (sum(s) - len(s)) for s in self.sigs])
        assert np.allclose(r.scale.reshape(len(self.sigs), self.nr)[:, 0], self.sig_scale)
        self.alphas = list(alphas)
        self.B = len(alphas)
        self.psi = []
        for a in alphas:
            cut = None
            if isinstance(a, str) and a.startswith('c'):       # c<tau>:<shape>: the shape times 1[t <= tau]
                head, a = a[1:].split(':', 1)
                cut = float(head)
                a = a if a[0] in 'pq' else float(a)
            if isinstance(a, str) and a.startswith('p'):       # power multiplier (t/S)^e
                psi = (r.t / r.S) ** int(a[1:])
            elif isinstance(a, str) and a.startswith('q'):     # (t/S)^2 / (1 + a t)
                psi = (r.t / r.S) ** 2 / (1.0 + float(a[1:]) * r.t)
            else:
                psi = 1.0 / (1.0 + float(a) * r.t)
            if cut is not None:
                psi = psi * (r.t <= cut)
            self.psi.append(psi)
        self.pairs = [(m, mp) for m in range(self.B) for mp in range(self.B)]
        self.N = len(self.pairs) * self.ncomp * self.nbase
        self.unit = r.norm / r.k            # h/Z
        self.sub = None
        if model is not None:
            self.sub = list(model[2])
        elif subtraction == 'source':
            for row in prior['supplied_domains']['domains']:
                self.sub = cap_shells(r, row['physical_radius'], row['delta'])
        else:
            self.sub = list(r.shells['enlarged'])     # the source's subtraction domain exists only at its own radius
        self._endpoint_correlations()

    # ---- indexing -------------------------------------------------------
    def offset(self, pair_index, comp):
        return (pair_index * self.ncomp + comp) * self.nbase

    def sig_block(self, pair_index, comp, sig):
        start = self.offset(pair_index, comp) + self.sig_index[sig] * self.nr
        return slice(start, start + self.nr)

    # ---- cell arrays ----------------------------------------------------
    def ue(self, cap, m, p):
        r = self.r
        return r.w * self.psi[m] * self.psi[p] * r.survival(cap)

    def conv(self, a, b):
        r = self.r
        return np.maximum(0., irfft(rfft(a, r.L) * rfft(b, r.L), r.L)[:r.n])

    def _endpoint_correlations(self):
        """Single and double erasure correlations of each radial basis function
        against the endpoint kernels, per component and outer shell."""
        r = self.r
        alpha = r.fiber_tilt
        forward = np.exp(alpha * (r.sf - r.center))
        back1 = np.exp(-alpha * (r.sy - r.center))
        s2 = (np.arange(r.n) + (r.k - 2) / 2) * r.h
        back2 = np.exp(-alpha * (s2 - r.center))
        source = np.exp(-alpha * r.t)
        original = list(r.shells['outer'])
        self.comp_shells, self.corr1, self.corr2 = [], [], []
        for limit in self.limits:
            shells = limited_shells(original, limit)
            self.comp_shells.append(shells)
            c1_shells, c2_shells = [], []
            for shell in shells:
                mask, cap = r.mask(shell, r.k), shell[2]
                kern = [r.g * self.psi[m] * r.survival(cap) * source for m in range(self.B)]
                f1 = [rfft(kv[::-1], r.L) for kv in kern]
                k2 = {}
                for m in range(self.B):
                    for mp in range(m, self.B):
                        k2[m, mp] = irfft(rfft(kern[m], r.L) * rfft(kern[mp], r.L), r.L)[:r.n]
                f2 = {key: rfft(val[::-1], r.L) for key, val in k2.items()}
                c1 = np.zeros((self.B, self.nr, r.n))
                c2 = np.zeros((self.B, self.B, self.nr, r.n))
                for d in range(self.nr):
                    radial = rfft(r.radial_values[d] * mask * forward, r.L)
                    for m in range(self.B):
                        c1[m, d] = irfft(radial * f1[m], r.L)[r.n - 1:2 * r.n - 1] * back1
                        for mp in range(m, self.B):
                            val = irfft(radial * f2[m, mp], r.L)[r.n - 1:2 * r.n - 1] * back2
                            c2[m, mp, d] = val
                            c2[mp, m, d] = val
                c1_shells.append(c1)
                c2_shells.append(c2)
            self.corr1.append(c1_shells)
            self.corr2.append(c2_shells)

    # ---- mass -----------------------------------------------------------
    def mass(self):
        r = self.r
        G = np.zeros((self.N, self.N))
        sums = sorted({tuple(sorted(a + b)) for a in self.sigs for b in self.sigs})
        upairs = [(m, p) for m in range(self.B) for p in range(m, self.B)]
        for cmin in range(self.ncomp):
            for shell in self.comp_shells[cmin]:
                mask, cap = r.mask(shell, r.k), shell[2]
                ue = {mp: self.ue(cap, *mp) for mp in upairs}
                blocks = {}
                for sig in sums:
                    core = r.moment(cap, self.core, sig)
                    first = {mp: self.conv(core, ue[mp]) for mp in upairs}
                    for x, mp in enumerate(upairs):
                        for mq in upairs[x:]:
                            wt = r.outer_exp * mask * self.conv(first[mp], ue[mq])
                            cells = r.radial_products @ wt
                            block = np.zeros((self.nr, self.nr))
                            for value, (d, e) in zip(cells, r.radial_pairs):
                                block[d, e] = block[e, d] = value
                            blocks[sig, mp, mq] = block
                            blocks[sig, mq, mp] = block
                r.clear_cache()
                for i, (m, mprime) in enumerate(self.pairs):
                    for j, (p, pprime) in enumerate(self.pairs):
                        ka = (min(m, p), max(m, p))
                        kb = (min(mprime, pprime), max(mprime, pprime))
                        for c1 in range(self.ncomp):
                            for c2 in range(self.ncomp):
                                if min(c1, c2) != cmin:
                                    continue
                                for sa in self.sigs:
                                    for sb in self.sigs:
                                        sig = tuple(sorted(sa + sb))
                                        scale = self.sig_scale[self.sig_index[sa]] * self.sig_scale[self.sig_index[sb]]
                                        G[self.sig_block(i, c1, sa), self.sig_block(j, c2, sb)] += scale * blocks[sig, ka, kb]
        return (G + G.T) / 2

    # ---- layered forms --------------------------------------------------
    def layer_caps(self, extra_caps=()):
        """Cap layers used by forms() and densities(), in increasing order."""
        r = self.r
        caps = sorted(set(r.caps) | {sh[2] for shells in self.comp_shells for sh in shells}
                      | {sh[2] for sh in self.sub} | set(extra_caps))
        top = max(sh[2] for sh in r.shells['outer'])
        return [cap for cap in caps if cap <= top]

    def forms(self, role_weights, extra_caps=(), pair_kernels=('lift',), theta_option=0.5, role_faces=None):
        """Return (face matrices per role, pair matrices per kernel).

        role_faces, if given, names for each role the faces it applies to: 'all' (default),
        'core' (the k-2 core faces), 'a' or 'b' (one endpoint face) or 'ends' (both).
        """
        r = self.r
        B, ncomp, nr, nbase, n = self.B, self.ncomp, self.nr, self.nbase, r.n
        caps = sorted(set(r.caps) | {sh[2] for shells in self.comp_shells for sh in shells}
                      | {sh[2] for sh in self.sub} | set(extra_caps))
        top = max(sh[2] for sh in r.shells['outer'])
        upairs = [(m, p) for m in range(B) for p in range(m, B)]
        uindex = {mp: x for x, mp in enumerate(upairs)}
        key2 = lambda a, b: (min(a, b), max(a, b))
        rests = sorted(self.axes, key=lambda s: (sum(s), s))
        sums_core = sorted({tuple(sorted(a + b)) for a in rests for b in rests})
        sums_full = sorted({tuple(sorted(a + b)) for a in self.sigs for b in self.sigs})
        s2 = (np.arange(n) + (r.k - 2) / 2) * r.h
        exp2 = np.exp(r.tilt * (s2 - r.center))
        q_pair = self.rho_star * (np.arange(n) + (r.k - 2)) * r.h
        assert 0.5 - q_pair.max() - EPS0 > 0          # the lift needs every retained total below 1/2 - eps0
        lift = 2 * self.rho_star ** 2 / (0.5 - q_pair - EPS0) ** 2
        z_opt = theta_option / 2 - q_pair - EPS0
        option = np.where(z_opt > 1e-9, self.rho_star ** 2 / np.maximum(z_opt, 1e-9), np.inf)
        kern = {'lift': lift, 'min': np.minimum(lift, option)}
        face = None
        pair = [np.zeros((self.N, self.N)) for _ in pair_kernels]
        prev3, prev2, prev1 = {}, {}, {}
        # global row positions for the core-face rows of each rest signature
        axis_core = {rest: np.concatenate([self.axes[rest] + c * nbase for c in range(ncomp)]) for rest in rests}
        comp_rows = {(pair_index, sig): np.concatenate(
            [np.arange(nr) + self.offset(pair_index, c) + self.sig_index[sig] * nr for c in range(ncomp)])
            for pair_index in range(len(self.pairs)) for sig in self.sigs}
        for cap in caps:
            if cap > top:
                continue
            weights = role_weights(cap)
            if face is None:
                face = [np.zeros((self.N, self.N)) for _ in weights]
                faces_of = list(role_faces) if role_faces is not None else ['all'] * len(weights)
                assert len(faces_of) == len(weights) and set(faces_of) <= {'all', 'core', 'a', 'b', 'ends'}
            positions = [np.flatnonzero(w) for w in weights]
            # rows for this layer
            rows_core = {rest: np.zeros((len(axis_core[rest]), n)) for rest in rests}
            cu = np.zeros((B, ncomp * nr, n))
            c2 = np.zeros((B, B, ncomp * nr, n)) if pair_kernels else None
            for comp, (shells, parts) in enumerate(self.components):
                for sidx, (shell, part) in enumerate(zip(shells, parts)):
                    if cap <= shell[2]:
                        for rest, value in part.items():
                            width = len(self.axes[rest])
                            rows_core[rest][comp * width:(comp + 1) * width] += value
                        cu[:, comp * nr:(comp + 1) * nr] += self.corr1[comp][sidx]
                        if pair_kernels:
                            c2[:, :, comp * nr:(comp + 1) * nr] += self.corr2[comp][sidx]
            ue = {mp: self.ue(cap, *mp) for mp in upairs}
            # weights: core faces (k-3 core + two endpoints), endpoint faces (k-2 core + one), pair (k-2 core)
            cur3, cur2, cur1 = {}, {}, {}
            for sig in sums_core:
                core = r.moment(cap, self.core - 1, sig)
                first = [self.conv(core, ue[mp]) for mp in upairs]
                for x, mp in enumerate(upairs):
                    for y in range(x, len(upairs)):
                        cur3[sig, x, y] = self.conv(first[x], ue[upairs[y]])
            for sig in sums_full:
                core = r.moment(cap, self.core, sig)
                cur1[sig] = core.copy()
                for x, mp in enumerate(upairs):
                    cur2[sig, x] = self.conv(core, ue[mp])
            r.clear_cache()
            d3 = {key: val - prev3.get(key, 0.) for key, val in cur3.items()}
            d2 = {key: val - prev2.get(key, 0.) for key, val in cur2.items()}
            d1 = {key: val - prev1.get(key, 0.) for key, val in cur1.items()}
            prev3, prev2, prev1 = cur3, cur2, cur1
            norm_core = self.core * self.unit
            whole = [len(idx) == n for idx in positions]

            def take(array, role):
                return array if whole[role] else array[..., positions[role]]

            # ---- core faces
            core_roles = [role for role, idx in enumerate(positions) if len(idx) and faces_of[role] in ('all', 'core')]
            sliced = {role: {rest: take(rows_core[rest], role) for rest in rests} for role in core_roles}
            for a_i, ri in enumerate(rests):
                for rj in rests[a_i:]:
                    sig = tuple(sorted(ri + rj))
                    for role in core_roles:
                        base_w = norm_core * take(r.inner_exp, role) * take(weights[role], role)
                        Ai, Bi = sliced[role][ri], sliced[role][rj]
                        vals = {}
                        for x in range(len(upairs)):
                            for y in range(x, len(upairs)):
                                vals[x, y] = (Ai * (base_w * take(d3[sig, x, y], role))) @ Bi.T
                        for i, (m, mprime) in enumerate(self.pairs):
                            for j, (p, pprime) in enumerate(self.pairs):
                                x, y = uindex[key2(m, p)], uindex[key2(mprime, pprime)]
                                val = vals[min(x, y), max(x, y)]
                                rows_i = axis_core[ri] + i * ncomp * nbase
                                cols_j = axis_core[rj] + j * ncomp * nbase
                                face[role][np.ix_(rows_i, cols_j)] += val
                                if ri != rj:
                                    rows_j = axis_core[rj] + i * ncomp * nbase
                                    cols_i = axis_core[ri] + j * ncomp * nbase
                                    face[role][np.ix_(rows_j, cols_i)] += val.T
            # ---- endpoint faces and pair: one product per weight on the stacked erased rows
            width = ncomp * nr
            end_roles = [role for role, idx in enumerate(positions) if len(idx) and faces_of[role] != 'core']
            stacked = {role: np.ascontiguousarray(take(cu, role)).reshape(B * width, -1) for role in end_roles}
            double = c2.reshape(B * B * width, n) if pair_kernels else None      # block i = m*B + m', as self.pairs
            for sig in sums_full:
                members = [(sa, sb) for sa in self.sigs for sb in self.sigs if tuple(sorted(sa + sb)) == sig]
                for role in end_roles:
                    use_a = faces_of[role] in ('all', 'a', 'ends')
                    use_b = faces_of[role] in ('all', 'b', 'ends')
                    base_w = self.unit * take(r.inner_exp, role) * take(weights[role], role)
                    rows = stacked[role]
                    gram = [(rows * (base_w * take(d2[sig, x], role))) @ rows.T for x in range(len(upairs))]
                    for i, (m, mprime) in enumerate(self.pairs):
                        for j, (p, pprime) in enumerate(self.pairs):
                            total = 0.
                            if use_a:      # erase a (shapes m, p); retained b carries (m', p')
                                total = total + gram[uindex[key2(mprime, pprime)]][m * width:(m + 1) * width, p * width:(p + 1) * width]
                            if use_b:      # erase b (shapes m', p'); retained a carries (m, p)
                                total = total + gram[uindex[key2(m, p)]][mprime * width:(mprime + 1) * width,
                                                                          pprime * width:(pprime + 1) * width]
                            for sa, sb in members:
                                scale = self.sig_scale[self.sig_index[sa]] * self.sig_scale[self.sig_index[sb]]
                                face[role][np.ix_(comp_rows[i, sa], comp_rows[j, sb])] += scale * total
                for kidx, name in enumerate(pair_kernels):
                    wt = self.unit ** 2 * exp2 * kern[name] * d1[sig]
                    finite = np.isfinite(wt)
                    wt = np.where(finite, wt, 0.)
                    big = (double * wt) @ double.T
                    for i in range(len(self.pairs)):
                        for j in range(len(self.pairs)):
                            val = big[i * width:(i + 1) * width, j * width:(j + 1) * width]
                            for sa, sb in members:
                                scale = self.sig_scale[self.sig_index[sa]] * self.sig_scale[self.sig_index[sb]]
                                pair[kidx][np.ix_(comp_rows[i, sa], comp_rows[j, sb])] += scale * val
        return [(M + M.T) / 2 for M in face], [(M + M.T) / 2 for M in pair]

    # ---- face energy densities of one coefficient vector ----------------
    def densities(self, vec, extra_caps=()):
        return self._densities(vec, extra_caps, False)[0]

    def fibre_tables(self, vec, extra_caps=()):
        """Per cap layer, the erased rows of vec, for evaluating the erased profiles at points.

        Returns (rests, {cap: (core, a, b)}) with core[rest_index, m, m', y], a[sig_index, m', y]
        and b[sig_index, m, y] (float64).  With h the cell width, the profile with a core
        coordinate erased at a retained configuration Y in the layer ending at cap is
            h * prod_Y g * sum_{rest, m, m'} core[rest, m, m', rY] psi_m(t_a) psi_m'(t_b) P_rest(core of Y),
        with endpoint a erased it is
            h * prod_Y g * sum_{sig, m'} a[sig, m', rY] psi_m'(t_b) P_sig(core of Y),
        and likewise for b; rY is the sum of the cell indices of Y and P runs over core coordinates.
        """
        collect = {}
        self._densities(vec, extra_caps, False, collect)
        rests = sorted(self.axes, key=lambda s: (sum(s), s))
        out = {}
        for cap, (amp, sum_a, sum_b) in collect.items():
            out[cap] = (np.stack([amp[rest] for rest in rests]), np.stack([sum_a[sig] for sig in self.sigs]),
                        np.stack([sum_b[sig] for sig in self.sigs]))
        return rests, out

    def densities_and_pair(self, vec, extra_caps=()):
        """The layer densities of densities() and the lift cost vec^T pair vec of the pair (a, b)."""
        return self._densities(vec, extra_caps, True)

    def _densities(self, vec, extra_caps, with_pair, collect=None):
        """Per cap layer, the face energy of vec carried by each cell, by face type.

        Returns {cap: (core, a, b)} with arrays of length n such that for any role weight
        w(cap)[cell] the quadratic forms of forms() satisfy

            vec^T face[role restricted to 'core'] vec = sum_cap sum_cell w(cap)[cell] * core[cap][cell],

        and likewise for the two endpoint faces.  The 'core' density already carries the
        multiplicity k-2 of the core faces, as the matrices do.
        """
        r = self.r
        B, ncomp, nr, nbase, n = self.B, self.ncomp, self.nr, self.nbase, r.n
        vec = np.asarray(vec, float)
        assert vec.shape == (self.N,)
        upairs = [(m, p) for m in range(B) for p in range(m, B)]
        uindex = {mp: x for x, mp in enumerate(upairs)}
        nu = len(upairs)
        ux = np.array([[uindex[(min(m, p), max(m, p))] for p in range(B)] for m in range(B)])
        rests = sorted(self.axes, key=lambda s: (sum(s), s))
        sums_core = sorted({tuple(sorted(a + b)) for a in rests for b in rests})
        sums_full = sorted({tuple(sorted(a + b)) for a in self.sigs for b in self.sigs})
        axis_core = {rest: np.concatenate([self.axes[rest] + c * nbase for c in range(ncomp)]) for rest in rests}
        npairs = len(self.pairs)
        comp_rows = lambda pair_index, sig: np.concatenate(
            [np.arange(nr) + self.offset(pair_index, c) + self.sig_index[sig] * nr for c in range(ncomp)])
        out = {}
        prev3, prev2, prev1 = {}, {}, {}
        norm_core = self.core * self.unit
        pair_value = 0.0
        if with_pair:
            s2 = (np.arange(n) + (r.k - 2) / 2) * r.h
            exp2 = np.exp(r.tilt * (s2 - r.center))
            q_pair = self.rho_star * (np.arange(n) + (r.k - 2)) * r.h
            assert 0.5 - q_pair.max() - EPS0 > 0
            lift = 2 * self.rho_star ** 2 / (0.5 - q_pair - EPS0) ** 2
        for cap in self.layer_caps(extra_caps):
            rows_core = {rest: np.zeros((len(axis_core[rest]), n)) for rest in rests}
            cu = np.zeros((B, ncomp * nr, n))
            double = {sig: np.zeros(n) for sig in self.sigs} if with_pair else None
            for comp, (shells, parts) in enumerate(self.components):
                for sidx, (shell, part) in enumerate(zip(shells, parts)):
                    if cap <= shell[2]:
                        for rest, value in part.items():
                            width = len(self.axes[rest])
                            rows_core[rest][comp * width:(comp + 1) * width] += value
                        cu[:, comp * nr:(comp + 1) * nr] += self.corr1[comp][sidx]
                        if with_pair:
                            # double-erased amplitude of vec for each signature, without storing the c2 rows
                            block = self.corr2[comp][sidx]
                            for sig in self.sigs:
                                scale = self.sig_scale[self.sig_index[sig]]
                                for i, (m, mprime) in enumerate(self.pairs):
                                    start = self.offset(i, comp) + self.sig_index[sig] * nr
                                    double[sig] += scale * (vec[start:start + nr] @ block[m, mprime])
            ue = {mp: self.ue(cap, *mp) for mp in upairs}
            cur3, cur2 = {}, {}
            for sig in sums_core:
                core = r.moment(cap, self.core - 1, sig)
                first = [self.conv(core, ue[mp]) for mp in upairs]
                arr = np.zeros((nu, nu, n))
                for x in range(nu):
                    for y in range(x, nu):
                        arr[x, y] = arr[y, x] = self.conv(first[x], ue[upairs[y]])
                cur3[sig] = arr
            cur1 = {}
            for sig in sums_full:
                core = r.moment(cap, self.core, sig)
                cur2[sig] = np.stack([self.conv(core, ue[mp]) for mp in upairs])
                if with_pair:
                    cur1[sig] = core.copy()
            r.clear_cache()
            d3 = {key: val - prev3.get(key, 0.) for key, val in cur3.items()}
            d2 = {key: val - prev2.get(key, 0.) for key, val in cur2.items()}
            if with_pair:
                for sa in self.sigs:
                    for sb in self.sigs:
                        sig = tuple(sorted(sa + sb))
                        weight = self.unit ** 2 * exp2 * lift * (cur1[sig] - prev1.get(sig, 0.))
                        pair_value += float(np.sum(weight * double[sa] * double[sb]))
                prev1 = cur1
            prev3, prev2 = cur3, cur2
            # core faces: amplitude of each endpoint-shape pair against the core rows of each rest signature
            amp = {rest: np.stack([vec[axis_core[rest] + i * ncomp * nbase] @ rows_core[rest]
                                   for i in range(npairs)]).reshape(B, B, n) for rest in rests}
            core_density = np.zeros(n)
            for ri in rests:
                for rj in rests:
                    kernel = d3[tuple(sorted(ri + rj))][ux[:, :, None, None], ux[None, None, :, :]]   # [m, p, m', p', cell]
                    core_density += np.einsum('acn,bdn,abcdn->n', amp[ri], amp[rj], kernel, optimize=True)
            core_density *= norm_core * r.inner_exp
            # endpoint faces: erase a uses the correlation with shape m, erase b with shape m'
            sum_a = {}
            sum_b = {}
            for sig in self.sigs:
                scale = self.sig_scale[self.sig_index[sig]]
                ea = np.zeros((B, n))        # indexed by the retained shape m' of b
                eb = np.zeros((B, n))        # indexed by the retained shape m of a
                for i, (m, mprime) in enumerate(self.pairs):
                    coefficients = vec[comp_rows(i, sig)]
                    ea[mprime] += scale * (coefficients @ cu[m])
                    eb[m] += scale * (coefficients @ cu[mprime])
                sum_a[sig], sum_b[sig] = ea, eb
            a_density = np.zeros(n)
            b_density = np.zeros(n)
            for sa in self.sigs:
                for sb in self.sigs:
                    kernel = d2[tuple(sorted(sa + sb))][ux]          # [x, y, cell] for retained shapes x, y
                    a_density += np.einsum('xn,yn,xyn->n', sum_a[sa], sum_a[sb], kernel, optimize=True)
                    b_density += np.einsum('xn,yn,xyn->n', sum_b[sa], sum_b[sb], kernel, optimize=True)
            a_density *= self.unit * r.inner_exp
            b_density *= self.unit * r.inner_exp
            out[cap] = (core_density, a_density, b_density)
            if collect is not None:
                collect[cap] = (amp, sum_a, sum_b)
        return out, pair_value

    # ---- standard plain-hybrid roles -----------------------------------
    def plain_roles(self):
        r = self.r
        base, enlarged, full = r.shells['base'], r.shells['enlarged'], r.shells['full']
        kernel = r.radial_weight()

        def role_weights(cap):
            in_base, in_enl, in_full = inside(r, base, cap), inside(r, enlarged, cap), inside(r, full, cap)
            in_sub = inside(r, self.sub, cap) | in_enl
            return [in_base * 1.0, (in_enl & ~in_base) * 1.0, (in_full & ~in_sub) * kernel]
        return role_weights


class Reducer:
    def __init__(self, gram, cutoff=1e-8):
        diagonal = np.sqrt(np.diag(gram))
        normalized = gram / diagonal[:, None] / diagonal[None, :]
        ev, vec = eigh((normalized + normalized.T) / 2)
        self.min_ev = float(ev[0] / ev[-1])
        keep = ev > cutoff * ev[-1]
        self.W = vec[:, keep] / np.sqrt(ev[keep]) / diagonal[:, None]
        self.rank = int(keep.sum())

    def small(self, matrix):
        m = self.W.T @ matrix @ self.W
        return (m + m.T) / 2


def top(operator):
    size = len(operator)
    value, vector = eigh(operator, subset_by_index=[size - 1, size - 1])
    return float(value[0]), vector[:, 0]


def plain_hybrid(rho, kappa, small_face, small_pair=None, pair_mult=1.0):
    """Optimise ell for rho*(F0+(1-ell)F1+(1-1/ell)kappa F2) - pair."""
    best = (-np.inf, None, None)
    for ell in np.geomspace(1e-4, 0.3, 40):
        op = rho * (small_face[0] + (1 - ell) * small_face[1] + (1 - 1 / ell) * kappa * small_face[2])
        if small_pair is not None:
            op = op - pair_mult * small_pair
        value, vec = top(op)
        if value > best[0]:
            best = (value, ell, vec)
    return best
