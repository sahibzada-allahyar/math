"""Bracket the exact radial Gram minimum using nested input budgets and their dual prices."""
import argparse
from fractions import Fraction as Q
from hashlib import sha256
from math import ceil,isqrt
from pathlib import Path
import json
import numpy as np


TICKS=10**8
UNIT=10**18


def histogram(path):
    j=json.loads(path.read_text());file=path.with_name(j['radial_energy'])
    assert sha256(file.read_bytes()).hexdigest()==j['radial_sha256']
    with np.load(file,allow_pickle=False) as z:
        energy=z['energy'];step=Q(str(z['step']))
    # The binning uses radial indices only. Keep the exact sum of the
    # binary64 energy entries; store the extremes of each pooled interval.
    groups=[];total=Q(0);begin=0
    for i,x in enumerate(energy):
        total+=Q(float(x))
        if (i+1)%4 or ((i+1)*step*Q('.262499')<Q('.21') and i+1<len(energy)):
            continue
        if total>0:
            groups.append([begin,i,total]);begin=i+1;total=Q(0)
    if begin<len(energy):
        groups[-1][1]=len(energy)-1;groups[-1][2]+=total
    assert all(g[2]>0 for g in groups)
    assert abs(float(sum(g[2] for g in groups))-sum(v[0] for v in j['sector_energies']))<1e-11
    lo=np.array([int(i*step*Q('.2624989')*TICKS) for i,_,_ in groups])
    hi=np.array([ceil((i+38)*step*Q('.262499')*TICKS) for _,i,_ in groups])
    return lo,hi,[g[2] for g in groups]


def rates(e,d,b):
    # On a block the multiplier solves sum(e*d/(1+lambda*d)^2) = budget.
    # Pool blocks until their multipliers are nonincreasing. Only the final
    # rational inequalities, not convergence of this floating fit, are used.
    if not len(e):return np.array([])
    blocks=[];a=e*d
    def root(l,r,budget):
        if budget<=0:return 1e18
        x,y=a[l:r],d[l:r];total=x.sum()
        if total<=budget:return 0.
        m=(np.sqrt(total/budget)-1)/np.mean(y)
        for _ in range(5):
            z=1+m*y;f=np.sum(x/z**2)-budget
            m=max(0.,m+f/(2*np.sum(x*y/z**3)))
        return m
    for i,budget in enumerate(b):
        l=i;r=i+1
        rate=root(l,r,budget)
        while blocks and blocks[-1][3]<rate:
            l,_,v,_=blocks.pop();budget+=v;rate=root(l,r,budget)
        blocks.append((l,r,budget,rate))
    result=np.empty(len(e))
    for l,r,_,v in blocks:result[l:r]=v
    return result


def enclose(edges,energy,level,retreat):
    low=np.flatnonzero(2*edges<=level);high=np.flatnonzero(2*edges>level)
    assert len(low) and len(high)
    U=[1/(Q(1,2)-Q(int(c),TICKS)-retreat) for c in edges]
    D=[U[i]/(U[i]-1) for i in low]
    attach=np.searchsorted(edges[low],level-edges[high],side='right')
    ef=np.array([float(energy[i]) for i in low]);df=np.array(list(map(float,D)))
    amounts=[energy[i]*U[i] for i in high]
    bf=np.bincount(attach,weights=list(map(float,amounts)),minlength=len(low)+1)[:len(low)]
    lam=rates(ef,df,bf)
    z=np.sqrt(ef*df)/(1+lam*df)
    # Integer prefix budgets are rounded down, making the construction of
    # an adverse matrix conservative, also when the floating solve is close.
    budget=[0]*(len(low)+1)
    for j,v in zip(attach,amounts):budget[j]+=int(v*UNIT**2)
    used=0;upper=0;lower=0;prices=[Q(max(0,round(v*10**12)),10**12) for v in lam]
    assert all(x>=y for x,y in zip(prices,prices[1:]))
    for i,(index,d,m) in enumerate(zip(low,D,prices)):
        used+=budget[i]
        y=min(int(z[i]*UNIT),isqrt(used));used-=y*y
        x=energy[index]
        cross=isqrt(int((x/d)*UNIT**2))
        upper+=ceil(UNIT*(x+Q(y*y,UNIT**2)/d-Q(2*y*cross,UNIT**2)))
        lower+=int(UNIT*x*d*m/(1+d*m))
    for j,v in zip(attach,amounts):
        if j<len(low):lower-=ceil(UNIT*prices[j]*v)
    assert lower<=upper
    return dict(lower_billionths=lower*10**9//UNIT,upper_billionths=ceil(Q(upper*10**9,UNIT)),
                low_bins=len(low),high_bins=len(high)),(low,high,attach,prices,D,U)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('table',type=Path)
    p.add_argument('--levels',type=Q,nargs='+',default=list(map(Q,['.524998','.528399','.529099'])))
    p.add_argument('--output',required=True,type=Path);p.add_argument('--threshold',action='store_true')
    a=p.parse_args();lo,hi,e=histogram(a.table)
    out=dict(scope='Finite radial model with ideal prime identities on an entire total-size triangle.',
             table=a.table.name,table_sha256=sha256(a.table.read_bytes()).hexdigest(),bins=len(e),rows=[])
    for edges,retreat,name in [(lo,Q(0),'outward'),(hi,Q('.0001'),'inward')]:
        def test(t):
            res,_=enclose(edges,e,t,retreat)
            row=dict(grid=name,theta=str(Q(t,TICKS)),**res)
            out['rows'].append(row);print(row,flush=True)
            return res
        for x in a.levels:
            assert (x*TICKS).denominator==1;test(int(x*TICKS))
        if a.threshold:
            l,h=52499800,52909900
            assert test(l)['upper_billionths']<10**9<test(h)['lower_billionths']
            while h-l>100:
                mid=(l+h)//2;r=test(mid)
                if r['lower_billionths']>10**9:h=mid
                elif r['upper_billionths']<10**9:l=mid
                else:break
            out[name+'_critical_bracket']=list(map(str,(Q(l,TICKS),Q(h,TICKS))))
    a.output.write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
