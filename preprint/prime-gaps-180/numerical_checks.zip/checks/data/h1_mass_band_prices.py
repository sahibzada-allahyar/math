"""Compile the unpaid H1 entries in radius bands and their common small-mass tests."""
import argparse
import json
from fractions import Fraction as Q
from pathlib import Path

import numpy as np

from h1_exception_cover import compact_weights, harmonic_rows, kernel_at, UNIT as COVER_UNIT
from h1_margin_fallback import (CERT,FIBRES,FIT,FORMS,FROZEN,MINORANTS,NORM,PRICES,TABLE,UNIT,
                                ceil,digest,geom,mixture_energies,native_layout,provenance,read,
                                remaining_entries,upper)
from h1_graded_outer_cross import operator_caps
from h1_raw_rectangle_cover import schedules

LEDGER=Path('h1_outer_laplace_refined_budget.json')
OUTPUT=Path('h1_mass_band_prices.json')
COVER=Path('h1_exception_cover_72.json')


def mask_for(affine, radii, caps, total, maximum):
    return ((radii[:,None]+radii<=total) & (np.maximum(caps[:,None],caps)<=maximum)
            & np.any(affine!=0,axis=0))


def model():
    cert,fi,n,ledger,prices=map(read,(CERT,FIBRES,NORM,LEDGER,PRICES))
    provenance(ledger,Path.cwd())
    for p in (FORMS,FORMS.with_suffix('.npz'),FROZEN,CERT,COVER):
        assert prices['inputs'][p.name]==digest(p)
    ix,last,top,by=native_layout(fi,cert)
    step=Q(n['step'])*geom.RHO*UNIT
    radii=np.array([int(ceil((int(v)+37)*step)) for v in last])
    affine,blocks=remaining_entries(cert,radii,ledger)
    return cert,fi,n,prices,ix,by,step,radii,np.asarray(top,int),affine,blocks


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--sums',nargs='+',type=int,default=[5010000,5050000,5100000])
    ap.add_argument('--caps',nargs='+',type=int,default=[58332,78116])
    ap.add_argument('--output',type=Path,default=OUTPUT)
    ap.add_argument('--check',action='store_true')
    args=ap.parse_args()
    cert,_,_,prices,_,_,step,radii,top,affine,blocks=model()
    rows=schedules(read(TABLE),cert)[:3]
    frozen=mixture_energies(FORMS,FROZEN)
    refs=[sum(frozen[g,0]) for g in cert['groups']]
    assert min(refs)>0
    data=next(r for r in read(MINORANTS)['rows'] if Q(r['theta'])==Q('.5291'))
    cover=read(COVER)
    assert cover['source_sha256']==digest(MINORANTS)
    means=[Q(1),Q(str(read(TABLE)['kappa_upper'])),Q(data['five_mass']['upper'])+Q(cert['arithmetic']['three_error_mass'][1])]
    # The same operator upper holds for all group combinations on this support.
    radius=int(max(radii))
    op=operator_caps(radius,data,cover)
    extra=Q(0)
    for kind,need in (('three',2),('increment',24)):
        h=harmonic_rows(kind,Q(data['a']),Q(data['zeta']),cover['bins'])
        w=np.array(cover['covers'][kind]['weights'],np.int64)
        assert min(w)>=0 and max(w)<=(need+1)*COVER_UNIT and min(w[h[-1]].sum(axis=1))>=need*COVER_UNIT
        extra+=kernel_at(compact_weights(h,w),Q(radius,UNIT))
    op[2]=min(op[2],extra)
    constants=[max(c,mu) for c,mu in zip(op,means)]
    scopes=[]
    for total in args.sums:
        assert all(r[-1,1]>=total for r in rows)
        bands=[r[r[:,0]<total] for r in rows]
        delta=min(int(min(r[:,2])) for r in bands)
        budget=min(int(min(r[:,0]+r[:,2])) for r in bands)
        assert delta>0
        for maximum in args.caps:
            mask=mask_for(affine,radii,top,total,maximum)
            if not mask.any():continue
            L,R,S=affine*mask
            sums=[np.abs(a).sum(axis=1) for a in (L+R+S,-R-S,-S)]
            costs=[upper(sum(Q(int(v[i]),prices['scale'])*c for v,c in zip(sums,constants))/ref)
                   for i,ref in enumerate(refs)]
            partner=np.where(mask,radii[None,:],0).max(axis=1)
            scopes.append(dict(radius_sum=total,cap=maximum,fragment_upper=int(ceil(maximum*step)),
                               ordered=int(mask.sum()),diagonal=int(np.trace(mask)),channels=[int(np.count_nonzero(a)) for a in (L,R,S)],
                               delta=delta,budget=budget,partner=partner.tolist(),costs=list(map(str,costs))))
    paths=[Path(__file__),LEDGER,CERT,FIT,FIBRES,NORM,PRICES,TABLE,COVER,MINORANTS,FORMS,FORMS.with_suffix('.npz'),FROZEN,
           Path('h1_raw_rectangle_cover.py'),Path('h1_margin_fallback.py'),Path('h1_graded_cross_block.py'),*blocks]
    out=dict(scope='Alternative nested subsets of the remaining nonzero entries, counted in both orientations. Costs bound the Schur-weighted signed discrepancy on these subsets only.',
             inputs={p.name:digest(p) for p in paths},operator_constants=list(map(str,constants)),scopes=scopes)
    if args.check:assert out==read(args.output)
    else:args.output.write_text(json.dumps(out,indent=2)+'\n',newline='\n')
    print([(v['radius_sum'],v['cap'],v['ordered']) for v in scopes],flush=True)


if __name__=='__main__':main()
