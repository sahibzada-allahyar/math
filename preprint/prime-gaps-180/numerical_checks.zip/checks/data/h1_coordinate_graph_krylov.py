"""Uncertified floating-point coordinate-neighbour Hamiltonians and a Krylov residual.

The discrete cap operator includes the hybrid minorant correction. All forms
below are sampled, not enclosed. No prime-gap bound follows from this script.
"""
from pathlib import Path
from fractions import Fraction as Q
import argparse,hashlib,json,time
import numpy as np
from scipy.linalg import eigh
from scipy.stats import qmc
from h1_full_operator_probe import MultiCapOperator,BACKEND,make_model,cap_shells

LABELS=['F','(rho A-q)F','F expm1(-64 E1)','F expm1(-64 E2)',
        'F expm1(-64 E6)','F expm1(-8 Eglobal)']


def energies(t,neighbours=(1,2,6)):
    """E_q=(1/q) sum_i sum_{j in N_q(i)}(t_i-t_j)^2.

    Neighbours are chosen by coordinate distance, so E_q is permutation
    invariant. At most q sorted positions on either side need be inspected.
    Ties have the same squared distance and do not affect the energy.
    """
    t=np.sort(t,axis=1);m=t.shape[1];width=max(neighbours)
    distances=[]
    for shift in range(1,width+1):
        d=(t[:,shift:]-t[:,:-shift])**2
        left=np.full_like(t,np.inf);right=np.full_like(t,np.inf)
        left[:,shift:]=d;right[:,:-shift]=d
        distances.extend([left,right])
    d=np.sort(np.stack(distances,axis=-1),axis=-1)
    local=[d[:,:,:q].sum(axis=(1,2))/q for q in neighbours]
    global_energy=((t-t.mean(axis=1)[:,None])**2).sum(axis=1)
    return np.stack(local+[global_energy],axis=1)


def features(operator,idx,cat,qref):
    F,A,keep=operator.evaluate(idx,cat)
    E=energies(operator.r.t[idx])
    factors=np.expm1(-E*np.array([64.,64.,64.,8.]))
    if len(LABELS)>6:
        factors=np.column_stack([factors,np.expm1(-64*E[:,:3]-8*E[:,3,None])])
    return np.column_stack([F,operator.r.rho*A-qref*F,F[:,None]*factors]),operator.r.rho*A


def normal(operator,reference,power,seed,beta,batch_power=11):
    r=operator.r;raw=r.g*r.g*np.exp(-beta*r.t)*operator.survival[-1]
    Z=raw.sum();cdf=np.cumsum(raw)/Z;cdf[-1]=1
    normalizer=np.exp(r.k*np.log(Z/r.Z)+(beta-r.tilt)*r.center)
    gen=qmc.Sobol(2*r.k,scramble=True,seed=seed)
    batch=2**min(power,batch_power);blocks=[]
    for j in range(2**power//batch):
        u=gen.random(batch);idx=np.searchsorted(cdf,u[:,:r.k])
        cat=operator.categories(idx,u[:,r.k:])
        V,CF=features(operator,idx,cat,reference['quotient'])
        W=normalizer*np.exp(beta*(r.t[idx].sum(axis=1)-r.center))/reference['I']
        gram=V.T@(W[:,None]*V)/batch
        cross=(V*(W*CF)[:,None]).mean(axis=0)
        blocks.append(np.r_[gram.ravel(),cross])
        if (j+1)%max(1,(2**power//batch)//4)==0:
            print(json.dumps({'event':'NORMAL','seed':seed,'samples':(j+1)*batch}),flush=True)
    return np.array(blocks)


def pairs(operator,reference,power,seed,beta,batch_power=11):
    r=operator.r;survival=operator.survival[-1]
    raw=r.g*r.g*np.exp(-beta*r.t)*survival
    Z=raw.sum();cdf=np.cumsum(raw)/Z;cdf[-1]=1
    linear=r.g*np.exp(-beta*r.t/2)*survival
    L=linear.sum();lcdf=np.cumsum(linear)/L;lcdf[-1]=1
    normalizer=np.exp(r.k*np.log(Z/r.Z)+(beta-r.tilt)*r.center)
    factor=normalizer*r.rho*r.h*r.k*L*L/Z/reference['I']
    gen=qmc.Sobol(2*r.k+2,scramble=True,seed=seed)
    batch=2**min(power,batch_power);blocks=[]
    for j in range(2**power//batch):
        u=gen.random(batch);iy=np.searchsorted(cdf,u[:,:r.k-1])
        cy=operator.categories(iy,u[:,r.k-1:2*r.k-2]);total=iy.sum(axis=1)
        keep=total<r.n;B=np.zeros((len(LABELS),len(LABELS)))
        if np.any(keep):
            iy,cy,total=iy[keep],cy[keep],total[keep]
            uu=u[keep,2*r.k-2:]
            mass=lcdf[r.n-total-1]
            iu=np.searchsorted(lcdf,uu[:,:2]*mass[:,None])
            cu=operator.categories(iu,uu[:,2:])
            values=[]
            for side in range(2):
                idx=np.column_stack([iy,iu[:,side]])
                cat=np.column_stack([cy,cu[:,side]])
                values.append(features(operator,idx,cat,reference['quotient'])[0])
            multiplier=operator.multipliers(total,cy.max(axis=1))
            W=factor*mass*mass*multiplier*np.exp(beta*(
                r.t[iy].sum(axis=1)+.5*r.t[iu].sum(axis=1)-r.center))
            B=values[0].T@(W[:,None]*values[1])/batch
            B=(B+B.T)/2
        blocks.append(B.ravel())
        if (j+1)%max(1,(2**power//batch)//4)==0:
            print(json.dumps({'event':'PAIRS','seed':seed,'samples':(j+1)*batch}),flush=True)
    return np.array(blocks)


def ritz(I,B):
    diag=np.sqrt(np.diag(I));G=I/diag[:,None]/diag[None,:]
    e,v=eigh((G+G.T)/2);keep=e>1e-7*e[-1]
    assert e[0]>-1e-10*e[-1]
    W=v[:,keep]/np.sqrt(e[keep])/diag[:,None]
    ev,vec=eigh(W.T@B@W)
    return {'quotient':float(ev[-1]),'vector':(W@vec[:,-1]).tolist(),
            'rank':int(keep.sum()),'normalized_mass_eigenvalues':e.tolist()}


def analyze(nb,pb,qref):
    n=len(LABELS);nm=nb.mean(axis=0);pm=pb.mean(axis=0)
    I=nm[:n*n].reshape(n,n);B=pm.reshape(n,n);cross=nm[n*n:]
    # The first row can be estimated with one configuration instead of pairs,
    # using <F,C U>=<C F,U>. The constant entry is also known deterministically.
    controlled=B.copy();controlled[0,:]=cross;controlled[:,0]=cross
    controlled[0,0]=qref
    mass=I.copy();mass[0,0]=1
    views={}
    for name,ids in {'krylov':[0,1],'coordinate_hamiltonians':[0]+list(range(2,n)),
                     'combined':list(range(n))}.items():
        ix=np.ix_(ids,ids)
        fit=ritz(mass[ix],controlled[ix]);fit['indices']=ids
        full=np.zeros(n);full[ids]=fit['vector'];fit['full_vector']=full.tolist()
        views[name]=fit
    residual_square=I[1,1];residual_curvature=B[1,1]/residual_square
    identity=np.array([[qref,np.sqrt(residual_square)],
                       [np.sqrt(residual_square),residual_curvature]])
    return {'sampled_mass':I.tolist(),'sampled_form':B.tolist(),
            'controlled_mass':mass.tolist(),'controlled_form':controlled.tolist(),
            'views':views,'krylov_identity_quotient':float(eigh(identity,eigvals_only=True)[-1]),
            'residual_curvature':float(residual_curvature),
            'curvature_needed_to_reach_one':float(1-residual_square/(1-qref)),
            'calibration':{'mass_error':float(I[0,0]-1),'pair_quotient_error':float(B[0,0]/I[0,0]-qref),
               'normal_quotient_error':float(cross[0]/I[0,0]-qref),
               'residual_inner_product':float(I[0,1]),
               'pair_cross_minus_normal_cross':(B[0]-cross).tolist()},
            'descriptive_normal_block_se':(nb.std(axis=0,ddof=1)/np.sqrt(len(nb))).tolist(),
            'descriptive_pair_block_se':(pb.std(axis=0,ddof=1)/np.sqrt(len(pb))).tolist()}


def energy_check():
    rng=np.random.default_rng(1923);t=rng.random((32,38))
    got=energies(t);d=(t[:,:,None]-t[:,None,:])**2
    d[:,np.arange(38),np.arange(38)]=np.inf
    exact=np.column_stack([np.sort(d,axis=-1)[:,:,:q].sum(axis=(1,2))/q for q in (1,2,6)])
    error=float(np.max(abs(got[:,:3]-exact)))
    global_direct=.5*((t[:,:,None]-t[:,None,:])**2).sum(axis=(1,2))/38
    ge=float(np.max(abs(got[:,3]-global_direct)))
    assert error<1e-12 and ge<1e-12
    return {'local_max_absolute_error':error,'global_max_absolute_error':ge,'configurations':32}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('candidate',type=Path)
    p.add_argument('--joint',action='store_true',help='Include exponentials containing both local and global energies')
    p.add_argument('--replay',type=Path,help='Previously checked finer-grid scalar replay of this fixed candidate')
    p.add_argument('--power',type=int,default=18);p.add_argument('--beta',type=float,default=15.)
    p.add_argument('--seeds',nargs='+',type=int,default=[19001,19002]);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();start=time.monotonic();candidate=json.loads(a.candidate.read_text())
    if a.joint:
        LABELS.extend([f'F expm1(-64 E{q}-8 Eglobal)' for q in (1,2,6)])
    assert not candidate.get('harmonic_beta',0)
    replay=json.loads(a.replay.read_text()) if a.replay else None
    if replay:
        assert replay['candidate_sha256']==hashlib.sha256(a.candidate.read_bytes()).hexdigest()
        assert replay['dimension']==candidate['dimension']
    intervals=replay['intervals'] if replay else candidate['intervals']
    r=make_model(candidate['dimension'],intervals,candidate['specification'])
    maximum=max(sh[2] for sh in r.shells['outer'])
    limits=sorted({min(maximum,int(Q(c)//r.exact_step)) for c in
                   candidate.get('cap_thresholds',['.3788','.4745'])}|{maximum})
    vectors=np.array(candidate['best_coefficients']).reshape(len(limits),r.nb)
    prior=json.loads((BACKEND/'results/incidence_multicap_spline_a6_n32768.json').read_text())
    domains={'L1':r.shells['enlarged']}
    for row in prior['supplied_domains']['domains']:
        domains[row['name']]=cap_shells(r,row['physical_radius'],row['delta'])
    row=candidate['rows'][candidate['best_index']]
    if replay:
        assert replay['hybrid_lambda']==row['hybrid_lambda']
        row=replay
    op=MultiCapOperator(r,vectors,limits,domains,prior['kappa'],row['hybrid_lambda'])
    reference={'I':row['mass'],'quotient':row['cap_quotient_without_penalty']}
    out={'status':'UNCERTIFIED_SAMPLED_COORDINATE_GRAPH_KRYLOV_NOT_A_BOUND',
         'candidate':a.candidate.name,'replay':a.replay.name if a.replay else None,
         'intervals':r.N,'reference':reference,'features':LABELS,'energy_checks':energy_check(),
         'power':a.power,'beta':a.beta,'runs':[],
         'limitations':['No rigorous quadrature or sampling enclosure.','Support-restoration loss is omitted.',
          'Ritz optimization on sampled forms can overfit; independent-seed replay is reported.',
          'Block standard errors are descriptive, not confidence bounds.']}
    arrays={}
    for seed in a.seeds:
        nb=normal(op,reference,a.power,seed+100000,a.beta)
        pb=pairs(op,reference,a.power,seed,a.beta)
        result=analyze(nb,pb,reference['quotient']);result['seed']=seed
        out['runs'].append(result);arrays[f'normal_{seed}']=nb;arrays[f'pairs_{seed}']=pb
        print(json.dumps({'event':'RESULT','seed':seed,'quotients':{k:v['quotient'] for k,v in result['views'].items()},
                          'residual_curvature':result['residual_curvature']}),flush=True)
        a.output.write_text(json.dumps(out,indent=2)+'\n')
    out['cross_seed_replays']=[]
    for train in out['runs']:
        for test in out['runs']:
            if train['seed']==test['seed']:continue
            for name,fit in train['views'].items():
                v=np.array(fit['full_vector']);I=np.array(test['controlled_mass']);B=np.array(test['controlled_form'])
                out['cross_seed_replays'].append({'training_seed':train['seed'],'test_seed':test['seed'],
                      'family':name,'quotient':float(v@B@v/(v@I@v))})
    out['seconds']=time.monotonic()-start
    a.output.write_text(json.dumps(out,indent=2)+'\n');np.savez_compressed(a.output.with_suffix('.npz'),**arrays)
    print(json.dumps({'event':'COMPLETE','seconds':out['seconds'],'replays':out['cross_seed_replays']}),flush=True)


if __name__=='__main__':main()
