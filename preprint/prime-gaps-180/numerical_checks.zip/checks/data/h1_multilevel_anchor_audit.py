"""Audit the two largest factors against each reached distribution band, including lower-order transfers."""
import argparse
import gzip
import json
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path
import numpy as np

from h1_combined_mass_interval import load_trial
from h1_bilinear_ladders import weak_engine
from h1_direct_bands import HALF,UNIT,source_rows
from h1_mass_band_prices import FIT,TABLE,digest,geom,read
from h1_multilevel_mark_orders import OUT as ORDERS
from h1_multilevel_native_cap import CERT
from h1_multilevel_partner_caps import prepare_geometry
from h1_multilevel_root_filter import BOOK

OUT=Path('h1_multilevel_anchor_audit.json')


def refinement(guards):
    @lru_cache(None)
    def mesh(hi):
        # Only the right endpoint enters the strict source guard calculation.
        return source_rows(guards,hi,hi-HALF)[0][2]

    def allowance(lo,hi,S,T,z,w):
        hi=min(hi,S+T)
        if hi<=lo:return UNIT
        best=0
        for order,delta in enumerate(mesh(hi),1):
            if delta<=0:continue
            limit=lo+delta
            single=max((order+1)*a if a>delta else 0 for a in (z,w))
            pair=z+w+order*min(z,w) if min(z,w)>delta else 0
            left=z<=delta or 2*z+T<=limit
            right=w<=delta or 2*w+S<=limit
            one=order==1 and ((left and 2*T<=limit) or (right and 2*S<=limit))
            two=order==2 and left and right and max(2*S-T,2*T-S)<=limit
            if max(single,pair)<=limit or one or two:best=max(best,delta)
        if best or hi-lo==1:return best
        mid=(lo+hi)//2
        return min(allowance(lo,mid,S,T,z,w),allowance(mid,hi,S,T,z,w))
    return mesh,allowance


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--check',action='store_true')
    args=ap.parse_args()
    m=prepare_geometry(load_trial(FIT),10000,2000)
    R=m['R'][:,:445];Z=m['tops']
    with gzip.open(CERT,'rt') as f: proof=json.load(f)
    matrices=proof['affine'][:14]
    cap=Q(read(TABLE)['fragment_cap']);book=read(BOOK)
    guards=[geom.fixed.old_input_slacks,geom.fixed.new_input_slacks]
    guards.extend(weak_engine(book,Q(level),cap).fixed.new_input_slacks for level in proof['levels'])
    assert len(matrices)==len(guards)==len(m['doc']['channels'])==14
    results=[]
    for matrix,ch,guard in zip(matrices,m['doc']['channels'],guards):
        endpoint_mesh,allowance=refinement(guard)
        rows=np.asarray(ch['rows'],np.int64);b=rows[:,0];D=rows[:,2:]
        used=np.asarray(matrix,np.int64)!=0
        partner=np.array([np.max(np.where(used,r,0),axis=1) for r in R])
        failed=rescued=refined=domains=0;examples=[];rad=0;dust=UNIT
        pair_room=transfer_room=HALF
        for i,(s,z) in enumerate(zip(R,Z)):
            for j in range(i+1):
                t=partner[j];w=Z[j]
                take=(s+t>5_000_000)&(s>0)&(t>0)
                if not take.any():continue
                S=s[take];T=t[take]
                pair_room=min(pair_room,HALF-int(z+w))
                transfer_room=min(transfer_room,HALF-int(max((T+z).max(),(S+w).max())))
                top=max(S+T)
                nd=np.searchsorted(b,top,side='left')
                assert top<=rows[-1,1]
                B=b[:nd,None];ds=D[:nd]
                orders=np.arange(1,4)
                single=np.maximum(np.where(z>ds,(orders+1)*z,0),np.where(w>ds,(orders+1)*w,0))
                pair=np.where((z>ds)&(w>ds),z+w+orders*min(z,w),0)
                selected=np.max(np.where(np.maximum(single,pair)<=B+ds,ds,0),axis=1)
                ok=selected>0
                if ok.any():dust=min(dust,int(selected[ok].min()))
                domains+=nd;rad+=int(take.sum())
                if np.all(ok):continue
                ix=np.flatnonzero(~ok)
                low=b[ix,None];mesh=D[ix]
                live=S+T>low
                recovered=np.zeros(live.shape,np.int64)
                # On a reached row S,T are below .29, and above .21, so
                # b+delta >= max(2S-T,2T-S) for the order-two transfer.
                assert max(max(S),max(T))<2_900_000
                for order in (1,2):
                    delta=mesh[:,order-1,None];limit=low+delta
                    left=(z<=delta)|(2*z+T<=limit)
                    right=(w<=delta)|(2*w+S<=limit)
                    if order==1:
                        transfer=(left&(2*T<=limit))|(right&(2*S<=limit))
                    else:transfer=left&right
                    recovered=np.maximum(recovered,np.where(live&transfer,delta,0))
                if recovered.any():dust=min(dust,int(recovered[recovered>0].min()))
                live &= recovered==0
                rem=live.any(axis=1)
                rescued+=int(np.sum(~rem))
                for q in np.flatnonzero(rem):
                    row=rows[ix[q]]
                    lo,hi=map(int,row[:2])
                    assert endpoint_mesh(hi)==row[2:].tolist()
                    for p in np.flatnonzero(live[q]):
                        allowed=allowance(lo,hi,int(S[p]),int(T[p]),int(z),int(w))
                        dust=min(dust,allowed)
                        if not allowed:
                            failed+=1
                            if len(examples)<12:
                                examples.append([int(m['fine'][i]),int(m['fine'][j]),lo,int(S[p]),int(T[p])])
                            break
                    else:refined+=1
        results.append(dict(channel=ch['channel'],reached_cap_band_combinations=int(domains),
                            transfer_beyond_sorted=rescued,adaptive_subdivision=refined,unresolved=failed,examples=examples,
                            active_cap_group_frontiers=rad,uniform_dust_ticks=dust,
                            pair_room_ticks=pair_room,transfer_room_ticks=transfer_room))
        print(ch['channel'],domains,'transfers',rescued,'subdivision',refined,'unresolved',failed,'dust',dust,flush=True)
    paths=[Path(__file__),ORDERS,CERT,FIT,TABLE,BOOK,Path('h1_multilevel_partner_caps.py'),
           Path('h1_bilinear_ladders.py'),Path('h1_direct_bands.py')]
    # At a mark above the largest residual factor the anchor proof still applies.
    # Below it, bound each residual tail by its entire mass.
    pair_room=min(row['pair_room_ticks'] for row in results)
    transfer_room=min(row['transfer_room_ticks'] for row in results)
    dust=min(row['uniform_dust_ticks'] for row in results)
    residual=min(pair_room//5,transfer_room//2)
    assert dust>0 and residual>dust and not any(row['unresolved'] for row in results)
    report=dict(scope='Sufficient arithmetic support on the strip-free truncated trial. In each root discard its largest mark and all dust up to the uniform dust cutoff. The other marks may have total a and maximum b when 2a+3b and a+b satisfy the two stated upper bounds. The cost of this restriction is open.',
                inputs={p.name:digest(p) for p in paths},results=results,units=UNIT,
                dust_ticks=dust,two_mass_plus_three_max_upper_ticks=pair_room,
                mass_plus_max_upper_ticks=transfer_room,residual_mass_alone_ticks=residual)
    if args.check:assert read(OUT)==report
    else:OUT.write_text(json.dumps(report,indent=2)+'\n',newline='\n')


if __name__=='__main__':
    main()
