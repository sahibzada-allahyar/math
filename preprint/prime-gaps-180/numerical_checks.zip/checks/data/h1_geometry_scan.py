"""Scan exact source-admitted cap geometries for the 38-shift single-prime test."""
import argparse
from fractions import Fraction as Q
import json
from pathlib import Path
import numpy as np
from h1_knn_harmonic import BACKEND, make_model, cap_shells, scalar_replay
import flexible_fragment_geometry as geometry
import incidence_spline_ritz as spline
from subtraction_from_geometry import build_subtractions


HERE=Path(__file__).resolve().parent
BASE_S=geometry.S_DEFAULT+Q('.006')
BASE_T1=geometry.T1_DEFAULT-Q('.006')
BASE_RADIUS=geometry.RS*BASE_S
SELF_SOURCES=[(Q('.0042'),Q('.02279')),(Q('.00666'),Q('.01332'))]


def fit_geometry(config,k,N):
    S=Q(config['radius'])/geometry.RS
    shift=S-BASE_S
    T0=Q(config.get('old_total','1.999999'))-S
    T1=BASE_T1-shift+Q(config.get('new_total_change','0'))
    errors=[]
    for omega,delta in SELF_SOURCES:
        try:
            g=geometry.build_geometry(S=S,T0=T0,T1=T1,k=k,N=N,
                old_switch=tuple(config.get('old_switch',[12,24])),
                new_switch=tuple(config.get('new_switch',[12,24])),
                old_plateau=config.get('old_plateau','capped_balance'),
                new_plateau=config.get('new_plateau','23/40'),
                self_omega=omega,self_delta=delta)
            return g,build_subtractions(g),[str(omega),str(delta)]
        except (ValueError,AssertionError) as exc:
            errors.append(str(exc))
    raise ValueError(' / '.join(errors))


def model_on_geometry(source,g,extra_knots=()):
    # With both mixed total budgets fixed, all active outer radial cores
    # B-T move by the same amount as S. Carry the two repeated interior
    # knots to those cores and keep the map continuous and increasing.
    p=g['parameters']
    spec=dict(source['specification'])
    knots=list(map(Q,spec['knots']))
    anchor=min(x for x in knots if knots.count(x)>1 and knots[0]<x<knots[-1])
    shift=p['S']-BASE_S
    spec['knots']=[str(t+shift*min(t/anchor,1)) for t in knots]
    if extra_knots:
        places=[Q(x)/p['rho_star'] for x in extra_knots]
        ordered=list(map(Q,spec['knots']))
        assert all(ordered[0]<x<ordered[-1] for x in places)
        spec['knots']=list(map(str,sorted(ordered+places)))
    spec['radius_shift']=str(p['S']-geometry.S_DEFAULT)
    spec['old_total']=str(p['old_total'])
    original=spline.build_geometry
    def selected(**arguments):
        assert arguments['k']==g['k'] and arguments['N']==g['intervals'] and arguments['S']==p['S']
        return g
    spline.build_geometry=selected
    try:
        r=make_model(g['k'],g['intervals'],spec)
    finally:
        spline.build_geometry=original
    return r,spec


def instantiate(source,config,k,N):
    g,sub,self_source=fit_geometry(config,k,N)
    r,spec=model_on_geometry(source,g,config.get('extra_knots',()))
    maximum=max(shell[2] for shell in r.shells['outer'])
    limits=sorted({min(maximum,int(Q(c)//r.exact_step)) for c in ['.3788','.4745']}|{maximum})
    assert len(limits)==3
    chosen=next((d for d in sub['domains'] if d['id']==sub['recommended_id']),None)
    if chosen is None:
        raise ValueError('No checked subtraction source')
    domains={'L1':r.shells['enlarged'],chosen['id']:cap_shells(r,chosen['physical_radius'],chosen['delta'])}
    record=dict(self_source=self_source,subtraction_source=chosen['id'],subtraction_radius=str(chosen['physical_radius']),
                exact_geometry_sha256=sub['geometry_sha256'],geometry_replayed=sub['geometry_replayed'],
                physical_outer=str(g['parameters']['physical_outer']),
                physical_base=str(g['parameters']['physical_base']),physical_enlarged=str(g['parameters']['physical_enlarged']))
    return r,limits,domains,spec,record


def evaluate(source,config,k,N,kappa):
    try:
        r,limits,domains,spec,record=instantiate(source,config,k,N)
    except (ValueError,AssertionError) as exc:
        return dict(config=config,status='rejected by geometry or source checks',reason=str(exc))
    v=np.array(source['best_coefficients'])
    mass,forms=scalar_replay(r,v,limits,domains)
    assert mass>0 and min(forms)>0
    ell=float(np.sqrt(kappa*forms[2]/forms[1]))
    assert 0<ell<1
    q=r.rho*(forms[0]+(1-ell)*forms[1]+(1-1/ell)*kappa*forms[2])/mass
    return dict(config=config,status='checked geometry; floating cap evaluation',**record,mass=mass,
                single_prime_cap_score=float(q),hybrid_lambda=ell,forms=list(map(float,forms)))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--intervals',type=int,default=8192)
    parser.add_argument('--dimension',type=int,default=38)
    parser.add_argument('--profile',type=Path,default=HERE/'h1_k38_knn6_n32768.json')
    parser.add_argument('--configs',type=Path)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    source=json.loads(args.profile.read_text())
    prior=json.loads((BACKEND/'results/incidence_multicap_spline_a6_n32768.json').read_text())
    configs=json.loads(args.configs.read_text()) if args.configs else [dict(radius=str(x)) for x in
        [BASE_RADIUS,'.267','.269','.271','.272','.273','.274','.275','.277','.278','.280','.282','.284','.287','.290']]
    report=dict(status='UNCERTIFIED_SOURCE_GEOMETRIES_NOT_A_PRIME_GAP_BOUND',dimension=args.dimension,
                intervals=args.intervals,profile=args.profile.name,rows=[],
                scope='Single-prime hybrid criterion. No arithmetic support restoration or integral enclosures.')
    for config in configs:
        row=evaluate(source,config,args.dimension,args.intervals,prior['kappa'])
        report['rows'].append(row)
        args.output.write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps({'event':'GEOMETRY_SCAN',**config,'score':row.get('single_prime_cap_score'),
                          'rejection':row.get('reason')}),flush=True)


if __name__=='__main__':
    main()
