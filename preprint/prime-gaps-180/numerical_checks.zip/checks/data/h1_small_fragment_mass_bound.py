"""Upper-bound a family of raw-support exceptions throughout the combined H1 trial."""
import argparse
from fractions import Fraction as Q
from math import comb, factorial, isqrt
from itertools import combinations, product
from pathlib import Path
import json

import numpy as np

from h1_direct_bands import digest, geom, read
from h1_cover_convergence import mixture_energies


def ceiling_sqrt(value):
    # Relative outward accuracy is better than 1e-12, also for tiny bounds.
    shift = max(0,(value.denominator.bit_length()-value.numerator.bit_length())//2+48)
    scaled = value*(1 << (2*shift))
    root = isqrt(int(scaled))
    return Q(root if root*root == scaled else root+1, 1<<shift)


def sci_upper(value):
    exponent = int((value.numerator.bit_length()-value.denominator.bit_length())*.30103)
    while Q(10)**exponent > value:
        exponent -= 1
    while Q(10)**(exponent+1) <= value:
        exponent += 1
    unit = Q(10)**(exponent-5)
    return str(int(-((-value)//unit)))+'e'+str(exponent-5)


def multiplier_norm(affine, reciprocal, scale):
    """Weighted row inequalities for a symmetric nonnegative majorant."""
    B = abs(np.asarray(affine,dtype=object))*np.outer(reciprocal,reciprocal)
    v = np.ones(len(B),dtype=object)
    best = None
    for _ in range(12):
        product = B@v
        ceiling = max(-((-n)//(scale*d)) for n,d in zip(product,v))
        assert np.all(product <= ceiling*scale*v)
        best = ceiling if best is None else min(best,ceiling)
        # Any positive comparison vector is valid. The shift damps oscillation.
        next_v = product + max(1,best*scale//3)*v
        v = np.maximum(1,(10**12*next_v)//max(next_v))
    return int(best),Q(max(B.diagonal()),scale)


def coordinate_factor(t):
    return Q(21,200)/(1+t/100) + Q(179,200)/(1+Q(907,5)*t)


def mark_volume(m, count, threshold, rho, step):
    # Distribute labelled Poisson marks among distinct coordinates and
    # cancel the total factorial. A coordinate with j marks has midpoint
    # at least j*tau/rho-h/2 because its continuous total includes them all.
    bound = Q(1)
    for n in range(1,count+1):
        for occupied in range(1,n+1):
            for cuts in combinations(range(1,n),occupied-1):
                weight = Q(comb(m,occupied))*Q(3,2)**n
                for a,b in zip((0,*cuts),(*cuts,n)):
                    j = b-a
                    weight *= coordinate_factor(max(0,j*threshold/rho-step/2))**2/factorial(j)
                bound += weight
    return bound


def body_envelope(fibres,n,step,m):
    # On each radial block sum outward bounds on the signed cap increments.
    # Use the radial sum of the frozen midpoints to bound each power sum.
    starts = np.arange(0,n,128)
    ends = np.minimum(starts+127,n-1)
    degrees = [sum(sig) for sig in fibres['signatures']]
    power = np.array([[(int(r)*step+m*step/2)**deg for r in ends] for deg in degrees],dtype=object)
    lo = np.zeros(power.shape,dtype=object)
    hi = np.zeros(power.shape,dtype=object)
    exact = np.vectorize(lambda x: Q(float(x)),otypes=[object])
    supremum = Q(0)
    for layer in reversed(fibres['layers']):
        path = Path(fibres['cache_directory'])/layer['file']
        assert digest(path)==layer['sha256']
        with np.load(path,allow_pickle=False) as archive:
            rows = archive['bounds']
        assert rows.shape==(len(degrees),2,n) and np.isfinite(rows).all()
        lo += exact(np.minimum.reduceat(rows[:,0],starts,axis=1))
        hi += exact(np.maximum.reduceat(rows[:,1],starts,axis=1))
        assert np.all(lo<=hi)
        supremum = max(supremum,max((np.maximum(abs(lo),abs(hi))*power).sum(axis=0)))
    return supremum


def check_assignments(step,threshold,rho):
    # Compare the occupancy formula with every ordered assignment of up to
    # five marks to three labelled coordinates, starting from the Poisson sum.
    direct = Q(1)
    for n in range(1,6):
        for labels in product(range(3),repeat=n):
            term = Q(3,2)**n/factorial(n)
            for i in set(labels):
                term *= coordinate_factor(max(0,labels.count(i)*threshold/rho-step/2))**2
            direct += term
        assert direct == mark_volume(3,n,threshold,rho,step)
    return sum(3**n for n in range(6))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--check',action='store_true')
    args = parser.parse_args()
    norm_path = Path('h1_combined_mass_native_interval.json')
    fibres_path = Path('h1_combined_fibres_native_interval.json')
    cert_path = Path('h1_decoupled_coarsened_1e14.json')
    price_path = Path('h1_decoupled_coarsened_1e14_prices.json')
    fit_path = Path('h1_decoupled_coarsened_1e14_fit.json')
    reference_fit = Path('h1_cover_72_semiprime_mixed_fit.json')
    forms = Path('h1_cover_native_mixed.json')
    example_path = Path('h1_raw_obstruction.json')
    norm,fibres,cert,prices,fit,example = map(read,(norm_path,fibres_path,cert_path,price_path,fit_path,example_path))
    for p in (norm_path,fibres_path,cert_path,price_path,fit_path):
        assert example['inputs'][p.name] == digest(p)
    assert prices['inputs'][cert_path.name] == digest(cert_path)
    assert fit['inputs'][price_path.name] == digest(price_path)
    assert norm['status']=='ORDINARY_NORM_ENCLOSED' and fibres['status']=='ERASED_AMPLITUDES_ENCLOSED'
    assert [v['cap'] for v in fibres['layers']] == fibres['caps'] == norm['caps']
    assert norm['step'] == fibres['step'] and norm['dimension'] == fibres['dimension'] == 38
    m, k = 37,38
    S,h = Q(norm['S']),Q(norm['step'])
    rho = geom.RS
    z,D = Q(norm['coordinate_Z']['lower']),Q(norm['normalized_norm']['lower'])
    threshold = Q('.05')
    assignments = check_assignments(h,threshold,rho)
    max_marks = int(rho*S/threshold)
    assert max_marks==5 and rho*k*S < 11
    cap = max(fibres['caps'])*h*rho
    # exp(3/2) exceeds its cubic Taylor sum, which already exceeds cap/tau.
    assert sum(Q(3,2)**j/factorial(j) for j in range(4)) > cap/threshold
    multiplicities = mark_volume(m,max_marks,threshold,rho,h)
    assert multiplicities <= sum((Q(3*m,2)**j/factorial(j) for j in range(max_marks+1)), Q(0))
    body = body_envelope(fibres,norm['intervals']-k,h,m)
    assert h*norm['intervals']==S
    ref_floor = Q(cert['minimum_group_energy'])
    assert ref_floor>=Q('1e-14')
    for p in (reference_fit,forms,forms.with_suffix('.npz')):
        assert cert['inputs'][p.name]==digest(p)
    frozen = mixture_energies(forms,reference_fit)
    reference = [sum(frozen[g,0]) for g in cert['groups']]
    assert min(reference)==ref_floor
    reciprocal = np.asarray([isqrt(int(1/e))+1 for e in reference],dtype=object)
    assert all(e*r*r >= 1 for e,r in zip(reference,reciprocal))
    # P and P+sum_j C_j have bound U; P+B/24+A/2+D'/24 has the
    # joint rough bound. Thus -168 I <= P-B-A-D' <= 5 I, and the
    # operator norms of all six signed/evaluated channels are <=168.
    q = rho*S
    assert 1/(Q(1,2)-q-Q('.0001'))<5
    rough = 1-2*Q(cert['arithmetic']['a'])
    assert 1/(min(rough,Q(1,2)-q)-Q('.0001')) < 7
    norms = [5,168,168,5,5,5]
    multiplier_bounds,diags = [],[]
    for A in cert['affine']:
        assert all(A[i][j]==A[j][i] for i in range(len(A)) for j in range(i))
        op,diagonal = multiplier_norm(A,reciprocal,prices['scale'])
        multiplier_bounds.append(op)
        diags.append(diagonal)
    assert len(multiplier_bounds)==len(norms)
    scale = rho*k*h/(z*D)*body**2*multiplicities/factorial(m)
    result = []
    delta = max(Q(row['maximum_delta']) for row in example['source'].values())
    half_missing_window = (threshold-delta)/2
    cutoffs = set(map(Q,('.0005','.001','.0015','.002','.0025','.003','.0035','.004','.0046','.005')))
    for cutoff in sorted(cutoffs|{half_missing_window}):
        energy = scale*(cutoff/(rho*h*z))**m
        root = ceiling_sqrt(11*energy)
        assert root**2>=11*energy
        loss = sum(C*(2*r*root + v*energy) for C,r,v in zip(norms,multiplier_bounds,diags))
        result.append(dict(physical_small_mass_ceiling=str(cutoff),
                           total_normalized_erasure_energy_upper=sci_upper(energy),
                           six_channel_trace_allowance_upper=sci_upper(loss)))
    assert Q(example['all_small_exponents_sum_upper'])/2 < Q(result[0]['physical_small_mass_ceiling'])
    assert Q(example['large_mark_exponent_lower'])>threshold
    gap_row, = [row for row in result if Q(row['physical_small_mass_ceiling'])==half_missing_window]
    assert Q(gap_row['six_channel_trace_allowance_upper']) < Q('0.000001')
    doc = dict(scope='Upper bounds for removing the specified small-fragment-total event from the six active affine pairing identities, under the existing upper-form hypotheses. All other raw failures remain to be covered.',
               inputs={p.name:digest(p) for p in (Path(__file__),norm_path,fibres_path,cert_path,price_path,fit_path,
                       example_path,reference_fit,forms,forms.with_suffix('.npz'),Path('h1_cover_convergence.py'))},
               small_fragment_exponent_cutoff=str(threshold),maximum_large_marks=max_marks,
               small_ordered_assignment_checks=assignments,half_missing_window=str(half_missing_window),
               log_ratio_upper='3/2',body_supremum_upper=sci_upper(body),
               mark_assignment_volume_with_coordinate_weights_upper=sci_upper(multiplicities),
               reference_group_mass_lower=str(ref_floor),unrestricted_erasure_energy_upper='11',
               rescaled_absolute_multiplier_norm_upper=multiplier_bounds,
               rescaled_absolute_diagonal_bounds=list(map(str,diags)),
               operator_bounds=norms,cutoffs=result)
    if args.check:
        assert doc == read(args.output)
    else:
        args.output.write_text(json.dumps(doc,indent=2)+'\n',newline='\n')
    print(json.dumps(result),flush=True)


if __name__=='__main__':
    main()
