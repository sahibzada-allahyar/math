"""Restore the three surviving H1 affine forms by grading both roots' tail excess."""
import argparse
from fractions import Fraction as Q
from functools import lru_cache
from itertools import accumulate, combinations_with_replacement, product
from math import comb, factorial
from pathlib import Path
import json

import gmpy2
import numpy as np

from h1_raw_diagonal_bound import (CERT,FIBRES,FIT,MINORANTS,NORM,ONE,PRICES,TABLE,UNIT,
    ceil,ceiling_sqrt,coordinate_factor,digest,fixed,geom,multiply,one_cut,partitions,read,residual_cdfs,
    schedules,sci_upper,trial_box)
from h1_cover_convergence import mixture_energies
from h1_exception_cover import UNIT as COVER_UNIT, compact_weights, harmonic_rows, kernel_at
from h1_strip_free_integral_budget import REDUCED

F=gmpy2.mpq


def exact(x):
    if isinstance(x,Q): return F(x.numerator,x.denominator)
    return F(int(x))


def rational(x):
    return Q(int(x.numerator),int(x.denominator))


def residual_tables(m,nmax,size,step,scale,h,Z):
    tables=residual_cdfs(m,min(nmax,m-1),size,step,scale,h,Z)
    if nmax>=m:
        # When every coordinate is occupied, start with the full padded
        # identity before the m flat-residual convolutions.
        poly=[gmpy2.mpz(ONE)]+[gmpy2.mpz(0)]*(size-1)
        unit=fixed(step/(scale*h*Z))
        for _ in range(m):
            poly=[(unit*x+ONE-1)//ONE for x in accumulate(poly)]
        tables[m]=[gmpy2.mpz(0),*accumulate(poly)]
    return tables


def square_bound(coeff,sigs,pattern,v,z,need,R,scale,h,m,common):
    """Upper bound for the actual square; a common pattern majorizes all occupations of n marks on s sites."""
    n,s=sum(pattern),len(pattern)
    needed=max(need,n*v)
    # Sorted prefix totals are bounded using the maximum number of marks on
    # any k sites and the mandatory marks on the remaining sites.
    counts=list(reversed(pattern))+[0]*(m-s)
    prefix=[F(0)]
    for k,q in enumerate(accumulate(counts),1):
        prefix.append(min(R-needed+q*z,R-(n-q)*v)/scale+k*h/2)
    major=[b-a for a,b in zip(prefix,prefix[1:])]
    assert min(major)>=0 and all(a>=b for a,b in zip(major,major[1:]))
    mean=max(F(0),needed/(s*scale)-h/2)
    lower=[] if common else [max(F(0),max(j*v,needed-(n-j)*z)/scale-h/2) for j in pattern]
    mom={}
    for p in (2,3,4,5,6):
        mom[p]=(max(s*mean**p,sum(t**p for t in lower)),sum(t**p for t in major))
    lo,hi=F(0),F(0)
    for (a,b),sig in zip(coeff,sigs):
        x,y=F(1),F(1)
        for p in sig:
            x*=mom[p][0]
            y*=mom[p][1]
        lo+=a*(y if a<0 else x)
        hi+=b*(x if b<0 else y)
    return max(lo*lo,hi*hi)


def cut_energies(v,w,needs,R,radial_lo,z,eta,h,scale,coeff,sigs,cdf,m,split):
    nmax=R//v
    nbin=R//eta+1
    marks=[gmpy2.mpz(0)]*(z//eta+1)
    tagged=marks.copy()
    for i in range(v//eta,len(marks)):
        left=max(v,i*eta)
        right=min(z,(i+1)*eta)
        if right>left:
            marks[i]=fixed(Q(right-left,left))
            if w>left:tagged[i]=fixed(Q(min(w,right)-left,left))
    weights=[F(0)]+[exact(coordinate_factor(max(Q(0),j*v/scale-h/2))**2)/factorial(j) for j in range(1,nmax+1)]
    # A separate upward scale bounds the ordered occupancy sums without
    # introducing large products of unrelated rational denominators.
    enc=1<<384
    iw=[gmpy2.mpz(-((-x.numerator*enc)//x.denominator)) for x in weights]
    @lru_cache(None)
    def ordered(n,s):
        if s==0:return gmpy2.mpz(enc if n==0 else 0)
        return (sum(iw[k]*ordered(n-k,s-1) for k in range(1,n-s+2))+enc-1)//enc
    result=[F(0) for _ in needs]
    poly=[gmpy2.mpz(ONE)]
    sh,sc=exact(h),exact(scale)
    for n in range(1,nmax+1):
        prev=poly
        poly=multiply(prev,marks,nbin)
        if min(needs)>=n*z:continue
        tag=multiply(prev,tagged,nbin)
        admitted=[min(a,n*b) for a,b in zip(poly,tag)]
        # Every symmetric-profile witness is a true root mark in (v,w].
        # Group all marked sums in a tail by the sum of their floored bins.
        for s in range(1,min(n,m)+1):
            c=cdf[s]
            start=max(n*(v//eta),int(min(needs)//eta)-n+1,0)
            stop=len(admitted)
            if stop<=start:continue
            integral=[gmpy2.mpz(0)]*(stop-start+1)
            for i in range(stop-1,start-1,-1):
                first=max(0,radial_lo//eta-i-n-m)
                last=min(nbin-1,R//eta-i)
                term=admitted[i]*(c[last+1]-c[first]) if last>=first else 0
                integral[i-start]=integral[i-start+1]+term
            if not integral[0]:continue
            terms=[]
            if n<=split:
                for pat in partitions(n,s):
                    ways=comb(m,s)*factorial(s)
                    for j in set(pat):ways//=factorial(pat.count(j))
                    weight=F(ways)
                    for j in pat:weight*=weights[j]
                    terms.append((pat,weight,False))
            else:
                # This pattern bounds every sorted occupancy prefix. For the
                # lower moments only Jensen's bound common to all patterns is used.
                pat=(1,)*(s-1)+(n-s+1,)
                terms=[(pat,F(comb(m,s)*ordered(n,s),enc),True)]
            for j,L in enumerate(needs):
                i=max(start,int(L//eta)-n+1)
                if n*z<=L or i>=stop or not integral[i-start]:continue
                assignment=sum(a*square_bound(coeff,sigs,pat,v,z,exact(L),R,sc,sh,m,common)
                               for pat,a,common in terms)
                result[j]+=F(integral[i-start],ONE**2)*assignment
    ordered.cache_clear()
    return list(map(rational,result))


def self_check():
    # Independent direct tail comparisons, including the endpoints between grades.
    marks=[x for n in range(4) for x in combinations_with_replacement((1,3,5,7),n) if sum(x)<=15]
    W,delta,offsets=26,2,[0,2,4,8,16]
    def grade(x):
        return max([7]+[2*sum(v for v in x if v>=u)+u for u in x if u>delta])
    safe=0
    for a,b in product(marks,repeat=2):
        x,y=sorted([grade(a),grade(b)])
        if y<=W:
            paid=False
        elif x>W:
            paid=True
        else:
            upper=next((d for d in offsets[1:] if y<=W+d),None)
            paid=upper is None or x>W-upper
        if not paid:
            assert all(sum(t for t in a+b if t>=u)+u<=W for u in a+b if u>delta)
            safe+=1
    # At full pattern resolution the batched marked-volume integral
    # agrees with the separate exact convolution in three dimensions.
    h,sc,Z=Q(1,32),Q(19),Q(9)
    cdfs=residual_tables(3,2,12,1,sc,h,Z)
    needs=[Q(5),Q(13,2)]
    expected=[one_cut(4,6,x,11,6,8,1,h,sc,Z,[(Q(1),Q(1))],[()],cdfs,3,True) for x in needs]
    for split in (1,3):
        new=cut_energies(4,6,needs,11,6,8,1,h,sc,[(F(1),F(1))],[()],cdfs,3,split)
        assert all(a<=b<=a+Q(1,10**38) for a,b in zip(expected,new))
    # Test the common angular bound on distinct actual occupations; they
    # need not equal the maximally concentrated pattern in the bound.
    checked=0
    from collections import Counter
    sigs=[(),(3,),(2,2)]
    coeff=[(F(-1),F(2)),(F(1),F(4)),(F(-3),F(-1))]
    for labels in combinations_with_replacement(range(4),6):
        s=len(set(labels));pat=(1,)*(s-1)+(7-s,)
        bound=square_bound(coeff,sigs,pat,2,4,F(15),28,F(5),F(1,4),4,True)
        for i in range(4):
            counts=Counter(labels)
            totals=[3*counts[j]+(2 if j==i else 0) for j in range(4)]
            x=[(int(F(t*4,5))+F(1,2))/4 for t in totals]
            basis=[1,sum(t**3 for t in x),sum(t*t for t in x)**2]
            assert all(sum(c[k]*v for c,v in zip(coeff,basis))**2<=bound for k in (0,1))
            checked+=1
    return dict(legal_pair_rectangles=safe,batched_volume_comparisons=4,common_angular_checks=checked)


def spectral_bounds(cert,prices,ids,radii):
    forms=Path('h1_cover_native_mixed.json')
    frozen=Path('h1_cover_72_semiprime_mixed_fit.json')
    for p in (forms,forms.with_suffix('.npz'),frozen):assert prices['inputs'][p.name]==digest(p)
    base=mixture_energies(forms,frozen)
    e=[sum(base[g,0]) for g in (cert['groups'][i] for i in ids)]
    r=np.asarray(radii)
    risk=r[:,None]+r[None,:]>UNIT//2
    L,B,H=[np.array(a,dtype=object)[np.ix_(ids,ids)]*risk for a in cert['affine'][:3]]
    nonzero=[np.count_nonzero(a) for a in (L,B,H)]
    # Clear the few common denominators once, then check both signs with
    # fraction-free symmetric elimination and exact GMP division.
    gram_scale=int(np.lcm.reduce(np.array([q.denominator for q in e],dtype=object)))
    E=[q.numerator*(gram_scale//q.denominator) for q in e]
    unit=10**8
    sc=prices['scale']
    def pd(a):
        prev=gmpy2.mpz(1)
        for _ in range(len(a)):
            pivot=a[0,0]
            if pivot<=0:return False
            tail=pivot*a[1:,1:]-np.outer(a[1:,0],a[0,1:])
            if prev!=1:
                assert np.all(tail%prev==0)
                tail//=prev
            a,prev=tail,pivot
        return True
    def op(A):
        relevant=np.flatnonzero(A.any(axis=0))
        if not len(relevant):return Q(0)
        M=A[np.ix_(relevant,relevant)]
        roots=np.sqrt(np.array([float(e[i]) for i in relevant]))
        estimate=np.linalg.norm(M.astype(float)/sc/np.outer(roots,roots),2)
        upper=int(np.ceil(estimate*unit))+1
        scaled=np.vectorize(gmpy2.mpz,otypes=[object])(M*gram_scale*unit)
        diagonal=np.diag([gmpy2.mpz(upper*E[i]*sc) for i in relevant])
        assert pd(diagonal+scaled) and pd(diagonal-scaled)
        return Q(upper,unit)
    return [op(a) for a in (L+B+H,-B-H,-H)],list(map(int,nonzero)),risk


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--radial-index',type=int,required=True)
    parser.add_argument('--fragment-index',type=int,required=True)
    parser.add_argument('--integral-step',type=int,default=500)
    parser.add_argument('--witness-step',type=int,default=10000)
    parser.add_argument('--offsets',nargs='+',type=int,default=[0,50000,100000,170000,250000,350000,500000])
    parser.add_argument('--split-occupancies-through',type=int,default=5)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    offsets=args.offsets
    assert offsets==sorted(set(offsets)) and offsets[0]==0 and len(offsets)>1
    assert min(args.integral_step,args.witness_step)>0
    cert,prices,norm,fibres,table,reduced=map(read,(CERT,PRICES,NORM,FIBRES,TABLE,REDUCED))
    for p in (CERT,PRICES,TABLE,FIT):assert reduced['inputs'][p.name]==digest(p)
    assert reduced['retained_affine_channels']==[0,1,2]
    assert norm['status']=='ORDINARY_NORM_ENCLOSED' and fibres['status']=='ERASED_AMPLITUDES_ENCLOSED'
    for p in (TABLE,FIT):assert norm['inputs'][p.name]==fibres['inputs'][p.name]==digest(p)
    h=Q(norm['step']);scale=geom.RHO*UNIT;m=37
    lo,hi,cap,coeff,ids,radii=trial_box(fibres,cert,True,args.radial_index,args.fragment_index)
    R=int(ceil((hi+m)*scale*h));radial_lo=int(lo*h*scale);z=int(ceil(cap*h*scale))
    spec=[]
    for rows in schedules(table,cert)[:3]:
        used=rows[rows[:,0]<2*R]
        assert used[-1,1]>=2*R and min(used[:,2])>0
        spec.append((int(used[:,2].min()),int((used[:,0]+used[:,2]).min())))
    delta=min(v for v,W in spec);W=min(W for v,W in spec)
    assert delta>0 and 2*R>UNIT//2
    eta=args.integral_step
    Z=Q(norm['coordinate_Z']['lower']);D=Q(norm['normalized_norm']['lower'])
    cdf=residual_tables(m,R//delta,R//eta+1,eta,scale,h,Z)
    thresholds=sorted(set([W+d for d in offsets]+[W-d for d in offsets]))
    assert thresholds[0]>z
    totals={t:Q(0) for t in thresholds}
    rank=R//z;split=int(ceil(Q(R,rank+1)))
    coeff=[tuple(map(exact,pair)) for pair in coeff]
    pref=geom.RS*38*h/(Z*D)
    steps=0
    for lower,stop,tail in ((delta,split,R),(max(delta,split),z,rank*z)):
        for v in range(lower,stop,args.witness_step):
            w=min(stop,v+args.witness_step)
            active=[t for t in thresholds if 2*tail+w>t]
            if not active:continue
            needs=[Q(t-w,2) for t in active]
            values=cut_energies(v,w,needs,R,radial_lo,z,eta,h,scale,coeff,fibres['signatures'],cdf,m,
                                args.split_occupancies_through)
            for t,val in zip(active,values):totals[t]+=pref*val
            steps+=1
            if steps%16==0:print('graded witness intervals',steps,'through',w,flush=True)
    const=geom.RS*Q(norm['S'])*38*Q('3.638')/37
    assert sum(Q('3.638')**i/factorial(i) for i in range(20))>38
    # Higher thresholds give nested failure events. Preserve every valid
    # bound even if numerical overcounting is larger on a smaller event.
    running=const
    for t in thresholds:
        running=min(running,totals[t]);totals[t]=running
    mixed=sum(ceiling_sqrt(totals[W+u]*totals[W-v]) for u,v in zip(offsets,offsets[1:]))
    mixed+=ceiling_sqrt(totals[W+offsets[-1]]*const)
    op,nz,risk=spectral_bounds(cert,prices,ids,radii)
    book=read(MINORANTS);cover_path=Path('h1_exception_cover_72.json');cover=read(cover_path)
    assert prices['inputs'][cover_path.name]==digest(cover_path)
    assert cover['source_sha256']==digest(MINORANTS) and cover['weight_scale']==COVER_UNIT
    source=next(row for row in book['rows'] if Q(row['theta'])==Q('.5291'))
    cover_rows=harmonic_rows('old',Q(source['a']),Q(source['zeta']),cover['bins'])
    cw=np.array(cover['covers']['old']['weights'],np.int64)
    assert min(cw)>=0 and min(cw[cover_rows[-1]].sum(axis=1))>=24*COVER_UNIT
    q=Q(R,UNIT);rough=1-2*Q(source['a'])
    caps=[1/(Q(1,2)-q-Q('.0001')),kernel_at(compact_weights(cover_rows,cw),q),24/(min(rough,Q(1,2)-q)-Q('.0001'))]
    means=[Q(1),Q('.000093307088324062'),Q(source['five_mass']['upper'])+Q(cert['arithmetic']['three_error_mass'][1])]
    assert Q(str(table['kappa_upper']))==means[1]
    charges=[k*(2*ceiling_sqrt(mu*C)*mixed+(mu+C)*totals[W]) for k,mu,C in zip(op,means,caps)]
    paths=[Path(__file__),REDUCED,CERT,PRICES,NORM,FIBRES,FIT,TABLE,MINORANTS,cover_path,Path('h1_raw_diagonal_bound.py'),
           Path('h1_exact_convolution.py'),Path('h1_raw_rectangle_cover.py')]
    result=dict(scope='Full three-channel restoration on the specified block after removing the semiprime affine identities. The global price change is separate.',
                inputs={p.name:digest(p) for p in paths},selected_groups=ids.tolist(),radial_index_limit=args.radial_index,
                fragment_index_limit=args.fragment_index,nominal_radius=R,nominal_fragment=z,common_budget=W,
                common_activation=delta,intervals=steps,integral_step=eta,witness_step=args.witness_step,
                offsets=offsets,split_occupancies_through=args.split_occupancies_through,checks=self_check(),
                ordered_pairs_above_half=int(risk.sum()),active_entries=nz,
                threshold_energy_uppers={str(t):sci_upper(v) if v else '0' for t,v in totals.items()},
                mixed_norm_upper=sci_upper(mixed),signed_multiplier_bounds=list(map(str,op)),
                operator_bounds=list(map(str,caps)),mean_bounds=list(map(str,means)),
                component_loss_uppers=[sci_upper(v) for v in charges],three_channel_loss_upper=sci_upper(sum(charges)))
    if args.check:assert result==read(args.output)
    else:args.output.write_text(json.dumps(result,indent=2)+'\n',newline='\n')
    print(len(ids),'groups',int(risk.sum()),'risky ordered pairs, upper',result['three_channel_loss_upper'],flush=True)


if __name__=='__main__':
    main()
