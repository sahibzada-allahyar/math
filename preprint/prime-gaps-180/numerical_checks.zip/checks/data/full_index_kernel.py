"""A positive finite-Fourier label for the whole native radial sum."""
from fractions import Fraction as Q
from functools import cache
from math import ceil, floor

from flint import arb,ctx,fmpq
import numpy as np

from global_amplitude import S,N


def ball(x):
    q=Q(x)
    return arb(fmpq(q.numerator,q.denominator))


@cache
def multiplier(grid):
    # A triangular frequency window is |D_m|^2. Squaring the latter on
    # physical space convolves its triangular frequency coefficients.
    assert grid>=8 and grid%4==0
    m=grid//4
    triangular=[m-abs(i) for i in range(1-m,m)]
    coeff=np.convolve(np.array(triangular,dtype=object),triangular)
    offset=2*(m-1)
    normal=m*(2*m*m+1)//3
    assert coeff[offset]==normal and len(coeff)<grid
    return tuple(range(-offset,offset+1)),tuple(map(int,coeff)),normal


def captured(grid,width,radius,beta):
    """Outward lower on E[true tilt/output tilt; label within radius]."""
    ctx.prec=128
    frequencies,coeff,normal=multiplier(grid)
    m=grid//4
    result=arb(2)
    for r in range(width):
        x=Q(r,width)
        subtotal=arb(0)
        for k in range(ceil(x-radius),floor(x+radius)+1):
            t=(k-x)/grid
            D=arb(m) if not t else (ball(m*t).sin_pi()/ball(t).sin_pi())
            compensation=(ball(beta)*ball(S/N)*(k*width-r)).exp()
            subtotal+=D**4*compensation/(grid*normal)
        result=result.min(subtotal)
    return float(np.nextafter(float(result.lower()),-np.inf))


def check():
    ctx.prec=128
    from flint import acb
    checked=0
    for grid,width in [(8,3),(12,5),(32,8)]:
        f,co,z=multiplier(grid)
        for j in range(grid*width):
            vals=[]
            for k in range(grid):
                t=Q(k,grid)-Q(j,grid*width)
                value=sum(a*acb(ball(2*n*t)).exp_pi_i() for n,a in zip(f,co))/(grid*z)
                m=grid//4
                direct=arb(m) if t.denominator==1 else ball(m*t).sin_pi()/ball(t).sin_pi()
                mass=direct**4/(grid*z)
                assert value.real.overlaps(mass) and 0 in value.imag
                vals.append(mass)
                checked+=1
            assert 1 in sum(vals)
    return checked


if __name__=='__main__':
    print(check(),'kernel coefficients checked')
    for radius in (1,2,3,4):
        print(radius,captured(2048,128,radius,31))
