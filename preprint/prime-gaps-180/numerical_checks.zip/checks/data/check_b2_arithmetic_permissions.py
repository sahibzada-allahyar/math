"""Read the frozen 14-channel schedules and check their non-Type-III source inequalities."""
from collections import Counter
from fractions import Fraction as Q
from gzip import open as gzopen
from itertools import combinations, combinations_with_replacement
from math import ceil, floor
from pathlib import Path
import json


HERE = Path(__file__).resolve().parent
DATA = HERE.parents[1] / "lean" / "minorants" / "data"
UNIT = 10**7
TAU = Q(1, 10**10)
H = (0, 6, 14, 20, 24, 26, 30, 36, 42, 44, 50, 54, 62, 66, 72, 80, 84, 86, 92,
     96, 104, 110, 114, 120, 126, 132, 134, 140, 146, 150, 152, 156, 162, 164, 170,
     174, 176, 180, 182)


def source_tests(order, omega, delta, a, smooth, handoff):
    if a is None:
        c1, c2, bound = ((108, 30, 1), (280, 80, 3), (240, 80, 3))[order - 1]
        return {"186 prime Corollary 2.19": bound - c1 * omega - c2 * delta}
    low = a - TAU
    tests = {
        "long smooth": smooth - TAU - Q(1, 4) - 7 * omega - 2 * delta,
        "elementary long variable": 1 - a - Q(1, 2) - 2 * omega,
        "near diagonal": 1 - 68 * omega - 14 * delta,
    }
    if order < 3:
        c1, c2, c3 = ((54, 15, 5), (56, 16, 4))[order - 1]
        tests["lower bilinear"] = 1 - c1 * omega - c2 * delta - c3 * (Q(1, 2) - low)
    else:
        tests.update({
            "2.3 lower": low - 12 * omega - 6 * delta,
            "2.3 upper": Q(1, 2) - 2 * omega - handoff,
            "2.3 volume": 1 - 2 * handoff - 4 * omega - 2 * delta,
            "2.3 first lower error": low - 16 * omega - 7 * delta,
            "2.3 second lower error": 5 * low - Q(3, 2) - 40 * omega - 16 * delta,
            "10.3 upper handoff": handoff - Q(1, 4) - 14 * omega - 4 * delta,
            "10.4 first overlap": 1 - 64 * omega - 16 * delta,
            "10.4 second overlap": 2 - 112 * omega - 41 * delta,
            "9.3 second target": low - 8 * omega - 2 * delta,
            "handoff above start": handoff - low,
        })
    return tests


def universal_five_cover(a_values):
    """Independently enumerate normalized integer bins and test the archived full weights."""
    recorded = json.loads((HERE / "h1_exception_cover_72.json").read_text())
    full = recorded["covers"]["new"]["weights"]
    base = recorded["covers"]["old"]["weights"]
    subset = recorded["covers"]["increment"]["weights"]
    unit = recorded["weight_scale"]
    pair_index = {p: i for i, p in enumerate(combinations_with_replacement(range(72), 2))}
    assert unit == 10**9
    for weights in (base, full, subset):
        assert len(weights) == len(pair_index)
        assert all(type(weight) is int and weight >= 0 for weight in weights)
    total = narrow = 0
    for a in (Q(".41361"), *a_values):
        lo = 1 - 2 * a
        width = ((4*a-1)/3-lo)/72
        assert (1-5*lo)/width == 216 and (a-2*lo)/width == 108
        assert floor((1+Q(1,10**6)-5*lo)/width) == 216
        assert ceil((Q(".41361")-2*lo)/width)-2 >= 103
    for prefix in combinations_with_replacement(range(72), 4):
        four = sum(prefix)
        for last in range(max(prefix[-1], 211-four), min(71, 216-four, 108-prefix[-1])+1):
            inds = [pair_index[x] for x in combinations((*prefix, last), 2)]
            assert sum(full[i] for i in inds) >= 24 * unit
            assert sum(base[i] for i in inds) >= 24 * unit
            total += 1
            if last + prefix[-1] >= 103:
                assert sum(subset[i] for i in inds) >= 24 * unit
                narrow += 1
    assert [total, narrow] == [recorded["covers"][name]["configurations"] for name in ("new", "increment")]
    return total, narrow


def coherent_assignments():
    """Count compatible left/right placements and their CRT residues on the actual tuple."""
    p, q = 191, 193
    choices = (None, *H)
    # A prime can occur in one tuple or in both. The local congruences
    # must agree, and the detected coordinate cannot occur in either.
    checked = 0
    for shift in H:
        def multiplicities(prime):
            counts = Counter()
            for left in choices:
                for right in choices:
                    sites = {j for j in (left, right) if j is not None}
                    if len(sites) != 1 or shift in sites:
                        continue
                    residue = (shift - next(iter(sites))) % prime
                    counts[residue] += 1
            assert len(counts) == 38 and 0 not in counts and set(counts.values()) == {3}
            return counts

        left, right = multiplicities(p), multiplicities(q)
        inverse = pow(p, -1, q)
        residues = {u + p * ((v - u) * inverse % q): left[u] * right[v]
                    for u in left for v in right}
        assert len(residues) == 38**2 and set(residues.values()) == {9}
        assert sum(residues.values()) == 114**2
        checked += len(residues)
    return checked


def main():
    with gzopen(DATA / "ml12_w25.json.gz", "rt") as handle:
        cert = json.load(handle)
    book = {Q(v["theta"]): v for v in json.loads((DATA / "book_port.json").read_text())["rows"]}
    schedules = json.loads((HERE.parents[1] / "lean" / "data" / "h1_multilevel_order_schedules.json").read_text())["channels"]
    free = json.loads((HERE / "h1_multilevel_strip_free.json").read_text())
    assert free["removed_channels"] == cert["identities"][-3:] == ["C0", "C1", "C2"]
    assert [c["channel"] for c in schedules] == cert["identities"][:-3]
    prime_cap = Q(417, 2500)
    a_values = [Q(book[Q(v)]["a"]) for v in cert["levels"]]
    cuts = list(map(Q, cert["cuts"]))
    assert all(x < y for x, y in zip([Q(".41361"), *a_values], a_values))
    assert all(x > y for x, y in zip(cuts, cuts[1:]))
    for level, a, cut in zip(cert["levels"], a_values, cuts):
        I = Q(book[Q(level)]["I"])
        rough, zeta = 1 - 2*a, 1 - I - a
        assert Q(2,5) < a < Q(5,12) and prime_cap < rough < zeta < I < a
        assert 2*I+3*a < 2 and 3*I+7*a < 4 and 2*I+a > 1 and Q(level)+a < 1
        assert zeta < cut < (1-a)/2 and 3*rough > a and cut > prime_cap
        assert Q(1,2)-(1-3*rough) >= Q(3043997, 5000000000)
        assert min(a, 8*a-3, zeta)-(4*a-1)/3 >= Q(28037599, 3000000000)
    active_count = sum(sum(bool(x) for row in matrix for x in row) for matrix in cert["affine"][:14])
    assert active_count == 1634243
    minima = {}
    counts = Counter()
    for k, channel in enumerate(schedules):
        a, smooth, handoff = None, None, None
        if k == 1:
            a, smooth, handoff = Q(".41361"), Q(".34941"), Q(".45")
        if k >= 2:
            a, smooth, handoff = a_values[k-2], Q(book[Q(cert["levels"][k-2])]["I"]), Q(".46")
        last = UNIT//2
        for lo, hi, *widths in channel["rows"]:
            assert lo == last < hi and len(widths) == 3
            last = hi
            for order, width in enumerate(widths, 1):
                if not width:
                    continue
                assert hi <= 5_291_390  # The full modulus stays below x^0.54 after presieving.
                omega, delta = Q(hi - UNIT//2, 2*UNIT), Q(width, UNIT)
                assert omega > 0 and 0 < delta < Q(1,4)+omega and omega < Q(1,12)
                for label, slack in source_tests(order, omega, delta, a, smooth, handoff).items():
                    assert slack > 0, (channel["channel"], lo, hi, order, label, slack)
                    entry = (slack, channel["channel"], hi, order)
                    if label not in minima or entry < minima[label]:
                        minima[label] = entry
                counts[order] += 1
    table = json.loads((HERE / "h1_priced_168_table.json").read_text(), parse_float=Q)
    qmax = (max(ceil(Q(q)*10_000) for q in table["physical_upper"])+1)/Q(10_000)
    zmin = (1-max(a_values))/2-qmax-Q(".0001")
    assert zmin > 0 and qmax < Q(".29")
    # All priced radial cells use r <= qmax, mark exponent s <= a and
    # roughness at least the physical minimum below. Check the adverse corners.
    retreat = Q(1, 10_000)
    for a, c, b in zip(a_values, cuts, map(Q, cert["b"]), strict=True):
        assert 3*b > 1 + Q(1, 10**6)
        for rough in (1-2*a, c):
            radius = min(rough, (1-a)/2-qmax) - retreat
            carrier = max(prime_cap, rough-retreat)
            assert 0 < radius <= carrier < rough
            assert a+retreat+2*(qmax+radius) <= 1-retreat
    for previous, a in zip(a_values[:-1], a_values[1:], strict=True):
        assert 0 < 2*(1-2*a) <= previous < a
    assert len(H) == 39 and list((x,y) for x,y in combinations(H,2) if y-x>180) == [(0,182)]
    assert all(len({h%p for h in H}) < p for p in (2,3,5,7,11,13,17,19,23,29,31,37))
    print("two-prime CRT residue counts checked", coherent_assignments())
    print("bands", sum(len(x["rows"]) for x in schedules), "positive orders", dict(counts))
    print("nonzero affine entries", active_count, "maximum charged radius", qmax,
          "smallest roughness reserve", 1-2*max(a_values)-prime_cap, "marked radius reserve", zmin)
    for label, data in sorted(minima.items()):
        print(label, *data)
    print("universal full and incremental five-prime cover configuration counts", *universal_five_cover(a_values))


if __name__ == "__main__":
    main()
