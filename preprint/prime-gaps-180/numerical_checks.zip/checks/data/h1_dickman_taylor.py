"""Directed cell integrals of Dickman's density by a polynomial delay method.

On [a,a+h], let p(z) approximate rho(a-1+z), with error <= E.
Set q_0=-p_0/a and q_j=-(p_j+q_(j-1))/a for 1<=j<d.
Then (a+z)q(z)+p(z)=(p_d+q_(d-1))z^d. Integrating the
differential equation rho'(u)=-rho(u-1)/u bounds the density
remainder by E*z/a + |p_d+q_(d-1)|*z^(d+1)/(a*(d+1)).
Integrating again bounds the primitive remainder. All coefficient
and endpoint operations below use Arb intervals.
"""
from dataclasses import dataclass
from fractions import Fraction as Q
from math import ceil
import argparse
import hashlib
import json
from pathlib import Path
import time

from flint import arb,ctx
import flint
import numpy as np


def rat(value):
    value=Q(value)
    return arb(value.numerator)/value.denominator


def endpoint(value):
    assert value.is_finite() and value.is_exact()
    m,e=map(int,value.man_exp())
    return Q(m*2**e) if e>=0 else Q(m,2**(-e))


def record(value):
    return dict(lower=str(endpoint(value.lower())),upper=str(endpoint(value.upper())))


def positive_unit(value):
    lo=max(arb(0),value.lower());hi=min(arb(1),value.upper())
    assert lo<=hi
    return lo.union(hi)


@dataclass
class Segment:
    start: Q
    density: tuple
    primitive: tuple
    delay_error: arb
    residual: arb
    density_error: arb
    primitive_error: arb


def horner(coefficients, x):
    """Scalar interval arithmetic; deliberately no polynomial convolution."""
    value=arb(0)
    for coefficient in reversed(coefficients):
        value=value*x+coefficient
    return value


class DickmanTaylor:
    def __init__(self,maximum,mesh=16,degree=24,precision=192):
        assert maximum>=1 and mesh>=2 and degree>=2 and precision>=80
        assert ctx.prec==precision
        self.maximum=Q(maximum);self.mesh=int(mesh);self.degree=int(degree)
        self.precision=precision;self.rows=[]
        self.h=Q(1,self.mesh);h=rat(self.h)
        density_end=arb(1);primitive_end=arb(1)
        for j in range(ceil(self.maximum*self.mesh)):
            a=Q(j,self.mesh)
            if j<self.mesh:
                row=Segment(a,(arb(1),),(rat(a),arb(1)),arb(0),arb(0),arb(0),arb(0))
            else:
                old=self.rows[j-self.mesh]
                p=[old.density[k] if k<len(old.density) else arb(0) for k in range(self.degree+1)]
                q=[];aa=rat(a)
                for k in range(self.degree):
                    q.append(-(p[k]+(q[-1] if q else 0))/aa)
                remainder=(abs(p[-1]+q[-1])/aa).upper()
                delay=old.density_error
                density=(density_end,*[v/(k+1) for k,v in enumerate(q)])
                primitive=(primitive_end,*[v/(k+1) for k,v in enumerate(density)])
                de=(delay*h/aa+remainder*h**(self.degree+1)/(self.degree+1)).upper()
                pe=(delay*h*h/(2*aa)+remainder*h**(self.degree+2)/((self.degree+1)*(self.degree+2))).upper()
                row=Segment(a,density,primitive,delay,remainder,de,pe)
                density_end=positive_unit(horner(density,h)+arb(0,de))
                primitive_end=horner(primitive,h)+arb(0,pe)
            self.rows.append(row)

    def _settings(self):
        assert ctx.prec==self.precision

    def value(self,u,primitive=False):
        self._settings();u=Q(u)
        assert 0<=u<=self.maximum
        if u<=1:return rat(u) if primitive else arb(1)
        j=min(int(u*self.mesh),len(self.rows)-1)
        row=self.rows[j];z=rat(u-row.start);a=rat(row.start)
        if primitive:
            error=row.delay_error*z*z/(2*a)+row.residual*z**(self.degree+2)/((self.degree+1)*(self.degree+2))
            return horner(row.primitive,z)+arb(0,error.upper())
        error=row.delay_error*z/a+row.residual*z**(self.degree+1)/(self.degree+1)
        return positive_unit(horner(row.density,z)+arb(0,error.upper()))

    def cells(self,cap,count):
        """Return cap*[H((j+1)/cap)-H(j/cap)], including all count cells."""
        self._settings();cap,count=int(cap),int(count)
        assert cap>0 and count>0 and Q(count,cap)<=self.maximum
        if count<=cap:return [arb(1)]*count
        values=[None]*(count-cap+1)
        for k in range(self.mesh,min(len(self.rows),count*self.mesh//cap+1)):
            lo=max(cap,-((-k*cap)//self.mesh))
            hi=min(count+1,-((-(k+1)*cap)//self.mesh))
            if hi<=lo:continue
            row=self.rows[k]
            z=[arb(j*self.mesh-k*cap)/(cap*self.mesh) for j in range(lo,hi)]
            computed=[horner(row.primitive,x) for x in z]
            error=arb(0,row.primitive_error)
            for j,v in zip(range(lo,hi),computed):values[j-cap]=v+error
        # At the final mesh endpoint the right-hand segment may not exist.
        if values[-1] is None:values[-1]=self.value(Q(count,cap),primitive=True)
        assert all(v is not None for v in values)
        return [arb(1)]*cap+[positive_unit(cap*(b-a)) for a,b in zip(values,values[1:])]


def exact_three(u,primitive=False):
    """Independent log/dilog formula on the first three delay intervals."""
    u=Q(u);assert 0<=u<=3
    x=rat(u)
    if u<=1:return x if primitive else arb(1)
    density=1-x.log()
    if u>2:density+=(x-1).log()*x.log()+(1-x).polylog(2)+arb.pi()**2/12
    if not primitive:return density
    if u<=2:return 2*x-x*x.log()-1
    return x*density+2*(x-1)-(x-1)*(x-1).log()-1


def native_inventory():
    from h1_cover_pairings import TABLE,TILES
    from h1_sunrise_boundary import read,digest
    table=read(TABLE);cells=TABLE.with_name(table['cells']);base=read(cells)
    bins=TABLE.with_name(base['cell_bins'])
    assert digest(cells)==table['cells_sha256'] and digest(bins)==base['cell_bins_sha256']
    tile=read(TILES)
    assert tile['inputs'][TABLE.name]==digest(TABLE)
    with np.load(bins,allow_pickle=False) as z:
        caps={int(c) for c in np.unique(z['cells'][:,1])}
    caps|=set(map(int,tile['cap_edges']))|set(map(int,base['component_limits']))
    caps.discard(0)
    return sorted(caps),tile['intervals']-38,{p.name:digest(p) for p in (TABLE,TILES,cells,bins)}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mesh',type=int,default=16)
    parser.add_argument('--degree',type=int,default=24)
    parser.add_argument('--precision',type=int,default=192)
    parser.add_argument('--caps',type=int,nargs='+')
    parser.add_argument('--count',type=int,default=131034)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();ctx.prec=args.precision
    caps,count,inputs=native_inventory() if args.caps is None else (args.caps,args.count,{})
    maximum=max(3,ceil(Q(count,min(caps))))
    model=DickmanTaylor(maximum,args.mesh,args.degree,args.precision)
    # Non-mesh points, mesh boundaries, and both derivative-change points.
    tests=sorted({Q(i,101) for i in range(304)}|{Q(i,args.mesh) for i in range(3*args.mesh+1)})
    widths=[]
    for u in tests:
        for primitive in (False,True):
            v=model.value(u,primitive);reference=exact_three(u,primitive)
            assert v.overlaps(reference),(u,primitive,v,reference)
            widths.append((v.upper()-v.lower()).upper())
    assert max(float(w) for w in widths)<1e-24
    output=dict(scope='Directed continuous Dickman cell masses only; no many-coordinate trial integral or prime-gap bound.',
                inputs=inputs,implementation_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                mesh=args.mesh,degree=args.degree,precision=args.precision,maximum=str(maximum),count=count,
                independent_log_dilog_checks=2*len(tests),maximum_check_width=record(max(widths)),
                runtime=dict(python_flint=flint.__version__,flint=flint.__FLINT_VERSION__),caps=[])
    for cap in caps:
        start=time.monotonic();balls=model.cells(cap,count)
        lo=np.nextafter(np.array([float(v.lower()) for v in balls]),-np.inf)
        hi=np.nextafter(np.array([float(v.upper()) for v in balls]),np.inf)
        lo=np.maximum(lo,0);hi=np.minimum(hi,1)
        assert np.all(lo<=hi) and min(lo)>=0 and max(hi)<=1
        # Reproduce the discovery engine's trapezoid inputs for comparison.
        old=np.ones(count+1)
        for j in range(cap,count):old[j+1]=old[j]-(old[j-cap]/j+old[j+1-cap]/(j+1))/2
        old=np.maximum(0,(old[:-1]+old[1:])/2)
        difference=np.nextafter(np.maximum(abs(old-lo),abs(old-hi)),np.inf)
        width=max((v.upper()-v.lower()).upper() for v in balls)
        entry=dict(cap=cap,maximum_argument=str(Q(count,cap)),cell_count=len(balls),
                   maximum_arb_cell_width=record(width),maximum_binary64_cell_width=float(max(hi-lo)),
                   trapezoid_maximum_absolute_error_upper=str(Q(float(max(difference)))),
                   lower_sha256=hashlib.sha256(lo.astype('<f8').tobytes()).hexdigest(),
                   upper_sha256=hashlib.sha256(hi.astype('<f8').tobytes()).hexdigest(),
                   final_cell=record(balls[-1]))
        output['caps'].append(entry)
        print('cap',cap,'seconds',round(time.monotonic()-start,2),'Arb width',float(width),
              'trapezoid error upper',float(max(difference)),flush=True)
        args.output.write_text(json.dumps(output,indent=2)+'\n',newline='\n')
    assert len(output['caps'])==len(caps)
    print('Dickman cell inventory complete:',len(caps),'caps; independent checks',2*len(tests),flush=True)


if __name__=='__main__':main()
