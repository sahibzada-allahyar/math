"""Directed quotient of the authenticated 39-site B=2 vector on its native grid.

All product measures are scaled by 100 per coordinate. Consequently each
one-coordinate squared erasure has the factor rho/100 and the endpoint
pair costs 2*(rho/100)^2/(.4999-rho*h*(J+37))^2. The common 100^39
cancels in the quotient. No site distribution assumption is evaluated here.
"""
import argparse
from collections import defaultdict
from fractions import Fraction as Q
from hashlib import sha256
import json
import os
from pathlib import Path
import resource
import time
from types import SimpleNamespace

import numpy as np

import quotient_poly as P
from quotient_contract import Integral,Laws,configure,contract,empty
from quotient_inputs import COUNT,N,STEP,SIGS,cap_cdf,exact_float_bounds,radial_rows,site_fields
from h1_degree6_native_schur_support import inputs,replay_limits
from h1_degree6_stream import trim_native_shell
from h1_geometry_scan import fit_geometry
from h1_two_source_endpoints import stored_frame


HERE=Path(__file__).resolve().parent
ROLES=('full','core','a','b','pair')


def via_interval(pair):return P.split_bounds(pair)


def weight_ball(bounds,n):
    return via_interval(tuple(np.broadcast_to(x,(n,)).copy() for x in bounds))


def interval_multiply(a,b):
    prods=[x*y for x in a for y in b]
    return P.down(np.minimum.reduce(prods)),P.up(np.maximum.reduce(prods))


def geometry():
    f=stored_frame();fit=json.loads((HERE/f['original']['trial_refit']).read_text())
    g,_,_=fit_geometry({'radius':fit['radius']},39,N)
    r=SimpleNamespace(k=39,N=N,exact_step=STEP)
    groups=defaultdict(list)
    for c,limit in enumerate(f['original']['component_limits']):
        for s in g['continuous_cap_shells']['outer']:
            shell=(s['lower'],s['upper'],min(s['cap']//STEP,limit))
            for lo,hi,cap in trim_native_shell(r,shell,'2'):
                a=max(0,int(lo//STEP)-38);b=min(COUNT,int(hi//STEP)-38)
                if a<b:groups[cap].append((c,a,b))
    assert len(groups)==9
    return groups


def reciprocal_kernel(rate,offset,n):
    j=np.arange(n,dtype=float)+offset
    r=exact_float_bounds(rate);c=exact_float_bounds(Q(4999,10000))
    lo=P.down(c[0]-P.up(j*r[1]));hi=P.up(c[1]-P.down(j*r[0]))
    assert np.all(lo>0)
    return P.down(1/hi),P.up(1/lo)


class Native:
    def __init__(self):
        self.n=COUNT;self.sigs=SIGS;self.core=37
        self.width=exact_float_bounds(100*STEP)
        rate,scale,classes=inputs();self.rate=rate;self.scale=scale
        self.rho=rate/STEP;self.site=site_fields()
        self.groups=geometry();self.caps=tuple(c.upper for c in reversed(classes));self.classes={c.upper:c for c in classes}
        assert all(c in self.caps for c in self.groups)
        # Any positive cap defect occurs at a site index >=45067. Thus all
        # higher-than-quadratic cap-defect products are absent on this grid.
        self.first=min(self.caps);assert 3*self.first>self.n
        self.limits=replay_limits(2)
        self.price_kernel=reciprocal_kernel(rate,38,self.n)
        inv=reciprocal_kernel(rate,37,self.n)
        self.pair=via_interval(P.positive_product(P.positive_product(inv,inv),exact_float_bounds(2*(self.rho/100)**2)))
        self.mass=(np.ones(self.n),np.zeros(self.n));self.radial=None

    def prepare(self):self.radial=radial_rows()

    def laws(self,c):return Laws(self.site,cap_cdf(c),self.width,self.core,self.sigs)

    def increment(self,c):
        if c not in self.groups:return None
        lo,hi=empty((len(self.sigs)*9,self.n));used=np.zeros(self.n,bool)
        for comp,a,b in self.groups[c]:
            x=self.radial[0][comp,:,:,a:b].reshape(-1,b-a)
            y=self.radial[1][comp,:,:,a:b].reshape(-1,b-a)
            l=lo[:,a:b];h=hi[:,a:b]
            if used[a:b].any():
                l[:]=P.down(l+x);h[:]=P.up(h+y)
            else:l[:]=x;h[:]=y
            used[a:b]=True
        return via_interval((lo,hi))

    def active_last(self,c):return next(j for cap,j in self.limits if c<=cap)

    def price(self,c,previous=None):
        # Subtract exact source intercepts/slopes first. Identical prices
        # give zero weight and zero radius, including at strip boundaries.
        n=self.n;starts={0,n};current=self.classes[c].sectors;prior=self.classes[previous].sectors if previous else ()
        for sectors in (current,prior):
            for a,b,x,y in sectors:starts.update([a,b+1])
        starts=sorted(starts)
        def coeff(sec):
            out={a:(x,y) for a,b,x,y in sec}
            if sec:out[sec[-1][1]+1]=(0,0)
            return out
        cc,old=coeff(current),coeff(prior);left=right=(0,0)
        w=np.zeros(n);e=np.zeros(n);last=self.active_last(c)
        for a,b in zip(starts,starts[1:]):
            left=cc.get(a,left);right=old.get(a,right)
            end=min(b,last+1)
            if a>=end:continue
            aa,bb=(Q(l-r,self.scale)*self.rho/100 for l,r in zip(left,right))
            if not (aa or bb):continue
            base=exact_float_bounds(aa);slope=exact_float_bounds(bb)
            inv=tuple(x[a:end] for x in self.price_kernel)
            l,h=interval_multiply(inv,slope)
            w[a:end],e[a:end]=via_interval((P.down(base[0]+l),P.up(base[1]+h)))
        return w,e


def cap_step(model,c,previous,old,integrals):
    law=model.laws(c);n=law.n;core=model.core
    def trace(stage):
        if os.environ.get('H1_B2_NATIVE_PROGRESS'):
            print(json.dumps(dict(cap=c,stage=stage,unix_time=round(time.time()))),flush=True)
    trace('erasure')
    full=model.increment(c);delta=None if full is None else law.erase(full)
    if not old and delta is not None:old.update({k:empty(v[0].shape) for k,v in delta.items()})
    if not old:return
    price=model.price(c);jump=model.price(c,previous)
    def forms(role,weight,change=None):
        acc=integrals[role];terms=[];last=model.active_last(c)
        def add(a,b,w):
            ix=np.flatnonzero((w[0][:last+1]!=0)|(w[1][:last+1]!=0))
            if len(ix):terms.append((acc,a,b,w,ix))
        if delta is not None:
            # G_new^2-G_old^2 = D(2G_old+D).
            add(delta[role],P.ball_add(delta[role],old[role],2),weight)
        if previous is not None and change is not None:add(old[role],old[role],change)
        return terms
    if delta is not None:
        trace('ordinary and pair')
        contract(law,core,2,forms('full',model.mass))
        contract(law,core,0,forms('pair',model.pair))
    trace('core prime')
    contract(law,core-1,2,forms('core',price,jump))
    trace('endpoint primes')
    contract(law,core,1,forms('a',price,jump)+forms('b',price,jump))
    if delta is not None:
        for role in old:old[role]=P.ball_add(old[role],delta[role])


def report(out,core):
    vals={k:[str(v.low),str(v.high)] for k,v in out.items()}
    m,coreface,a,b,p=(out[k] for k in ROLES)
    lower=core*coreface.low+a.low+b.low-p.high;upper=core*coreface.high+a.high+b.high-p.low
    if m.low>0:
        quot=[lower/m.low,lower/m.high,upper/m.low,upper/m.high]
        vals['quotient']=[str(min(quot)),str(max(quot))]
    return vals


def source_hash():
    names=['quotient_inputs.py','packed_poly.cpp','quotient_poly.py','quotient_contract.py',Path(__file__).name,
           'global_amplitude.py','h1_degree6_native_schur_support.py','h1_degree6_stream.py','h1_multilevel_strip_free.json','ts_s39a6.npz']
    return {name:sha256((HERE/name).read_bytes()).hexdigest() for name in names}


def run(model,outpath,cache,bits):
    t=time.monotonic();out={k:Integral() for k in ROLES};old={};steps=[];previous=None
    pinned=source_hash();binary=sha256(Path(P.LIB._name).read_bytes()).hexdigest()
    cp=cache/'state.npz' if cache else None
    if cp and cp.exists():
        with np.load(cp,allow_pickle=False) as f:
            state=json.loads(str(f['meta']))
            assert (state['source'],state['bits'],state['binary'])==(pinned,bits,binary)
            steps=state['caps'];previous=steps[-1]['cap']
            for k in ROLES:
                old[k]=(f[k+'0'],f[k+'1']);out[k].low,out[k].high=map(Q,steps[-1]['totals'][k])
    model.prepare()
    for c in model.caps[len(steps):]:
        tic=time.monotonic();cap_step(model,c,previous,old,out);previous=c
        totals=report(out,model.core);steps.append(dict(cap=c,totals=totals))
        q=totals.get('quotient');print(json.dumps(dict(cap=c,completed=len(steps),total=len(model.caps),
            seconds=round(time.monotonic()-tic,1),elapsed=round(time.monotonic()-t,1),
            partial_mass=[float(Q(v)) for v in totals['full']],partial_q=[float(Q(v)) for v in q] if q else None,
            peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)),flush=True)
        if cp and (c in model.groups or len(steps)==len(model.caps)):
            meta=json.dumps(dict(source=pinned,bits=bits,binary=binary,caps=steps));tmp=cp.with_suffix('.tmp.npz')
            np.savez(tmp,meta=meta,**{k+str(j):v for k,a in old.items() for j,v in enumerate(a)})
            os.replace(tmp,cp)
    totals=report(out,model.core)
    result=dict(source=pinned,compiled_library_sha256=binary,native_bins=model.n,dimension=model.core+2,bits=bits,model='native B2 with exact binary64 trapezoid marks',
                totals=totals,caps=steps)
    if outpath:outpath.write_text(json.dumps(result,indent=2)+'\n')
    return result


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--library',required=True,type=Path);ap.add_argument('--bits',default=256,type=int)
    ap.add_argument('--cache',type=Path);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    configure(args.library,args.bits)
    if args.cache:args.cache.mkdir(exist_ok=True,parents=True)
    run(Native(),args.output,args.cache,args.bits)
