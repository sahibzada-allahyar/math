"""Fit rotating Fourier sums and their interactions with the existing combined H1 weight."""
import argparse
import json
from pathlib import Path
import numpy as np
from h1_coordinate_shape import configured
from h1_harmonic_sector_probe import forms,sample
from h1_joint_weight import DIGEST,HERE,JointWeight,basis,frozen_fits,train


FAMILIES=('radial','rank_flat','shift_flat','rank_spiral','rank_reverse','shift_spiral')
MODES=(1,2,3)
MIX=(('rank_spiral',1,'re','walk'),('rank_spiral',1,'im','tensor'),
     ('rank_spiral',2,'power','spring'),('rank_reverse',2,'im','fermi'),
     ('shift_spiral',1,'power','sign'),('shift_spiral',2,'re','tensor'),
     ('rank_spiral',3,'im','sign'),('rank_reverse',1,'power','five_way'))


def radial_coordinate(q):
    return np.log1p(q/.01)/np.log1p(.28/.01)


class Spiral:
    def __init__(self,r,core,prior):
        self.core=core
        self.v=frozen_fits(prior,core,['main_effects','joint'])
        self.prior_ids=basis(core,'main_effects')
        self.labels=['original','frozen_main',*[core.labels[i] for i in self.prior_ids],'frozen_joint','mean_radius']
        self.u=radial_coordinate(r.rho*r.t)
        self.weighted=np.stack([self.u*np.exp(2j*np.pi*m*self.u) for m in MODES])
        shifts=np.array(json.loads((HERE/'window_180_exact_check.json').read_text())['witness_for_38'])
        assert len(shifts)==38 and np.all(np.diff(shifts)>0)
        self.rank=np.exp(2j*np.pi*np.outer(MODES,np.arange(38)/38))
        self.shifts=np.exp(2j*np.pi*np.outer(MODES,(shifts-shifts[0])/(np.ptp(shifts)+2)))
        self.family_ids={}
        for name in FAMILIES:
            start=len(self.labels)
            self.labels.extend(f'{name}_{m}_{part}' for m in MODES for part in ('re','im','power'))
            self.family_ids[name]=list(range(start,len(self.labels)))
        self.mix_start=len(self.labels)
        self.labels.extend(f'{name}_{m}_{part}*{term}' for name,m,part,term in MIX)

    def __call__(self,idx,cat,F=None,action=None,core_values=None):
        core=self.core(idx,cat) if core_values is None else core_values
        previous=core@self.v
        h=previous[:,0]
        ordered=np.sort(idx,axis=1)
        u=self.u[idx];sorted_u=self.u[ordered];norm=u.sum(axis=1)
        cols=[np.ones(len(h)),h,core[:,self.prior_ids],previous[:,1],h*norm/38]
        modes={}
        for j,m in enumerate(MODES):
            z=self.weighted[j,idx];sorted_z=self.weighted[j,ordered]
            modes.update({('radial',m):z.sum(axis=1)/norm,
                          ('rank_flat',m):sorted_u@self.rank[j]/norm,
                          ('shift_flat',m):u@self.shifts[j]/norm,
                          ('rank_spiral',m):sorted_z@self.rank[j]/norm,
                          ('rank_reverse',m):sorted_z.conj()@self.rank[j]/norm,
                          ('shift_spiral',m):z@self.shifts[j]/norm})
        for name in FAMILIES:
            for m in MODES:
                z=modes[name,m]
                cols.extend([h*z.real,h*z.imag,h*abs(z)**2])
        for name,m,part,term in MIX:
            z=modes[name,m];v={'re':z.real,'im':z.imag,'power':abs(z)**2}[part]
            key='fermi*spring*walk*sign*tensor' if term=='five_way' else term
            cols.append(v*core[:,self.core.labels.index(key)])
        return np.column_stack(cols)

    def groups(self):
        old=list(range(1,self.labels.index('mean_radius')))
        first=[*old,self.labels.index('mean_radius')]
        def extra(names):
            return [i for name in names for i in self.family_ids[name]]
        controls=first+extra(('radial','rank_flat','shift_flat'))
        modes=first+extra(FAMILIES)
        return dict(previous=[1],combined=old,ordinary_fourier=controls,
                    rank_spiral=controls+extra(('rank_spiral','rank_reverse')),
                    shift_spiral=controls+extra(('shift_spiral',)),
                    all_modes=modes,joint=modes+list(range(self.mix_start,len(self.labels))))


class FaceSpiral:
    """Use the radial position and measured permission coverage after each possible erasure."""
    def __init__(self,op,core,prior,control,dual):
        from h1_cross_ladders import apply_permissions
        self.core=core;self.sec=op.sectors;self.r=op.r
        self.v=frozen_fits(prior,core,['main_effects','joint'])
        self.prior_ids=basis(core,'main_effects')
        ctrl=dict(control);sol=json.loads(dual.read_text())
        apply_permissions(ctrl,HERE/sol['permissions'])
        energy=np.maximum(0.,np.array(ctrl['sector_energies'])[:,0])
        def missing(key):
            return (~np.array(ctrl[key],bool))@energy/energy.sum()
        self.missing=(np.sqrt(missing('prime_mask'))+np.sqrt(missing('minorant_mask')))/2
        self.u=radial_coordinate(op.r.rho*op.r.t)
        self.eta=np.clip(((np.arange(self.sec.count)+18.5)*op.r.h*op.r.rho-.225)/.055,0.,1.)
        self.spin=[np.exp(2j*np.pi*z) for z in (self.u,self.eta,self.missing)]
        self.labels=['original','frozen_main',*[core.labels[i] for i in self.prior_ids],'frozen_joint']
        start=len(self.labels)
        self.labels+=['mean_radius','mean_erased_position','mean_missing_coverage']
        self.base_ids=list(range(1,start));self.controls=list(range(1,len(self.labels)))
        self.families=('coordinate','erased_position','coverage','radial_spiral','permission_spiral')
        self.ids={}
        for fam in self.families:
            start=len(self.labels)
            self.labels.extend(f'{fam}_{m}_{p}' for m in MODES for p in ('re','im','power'))
            self.ids[fam]=list(range(start,len(self.labels)))
        self.mix_start=len(self.labels)
        self.labels+=['permission_re*walk','permission_im*tensor','permission_power*sign']

    def __call__(self,idx,cat,F=None,action=None,core_values=None):
        X=self.core(idx,cat) if core_values is None else core_values
        prior=X@self.v;h=prior[:,0]
        other=idx.sum(axis=1)[:,None]-idx
        top=np.partition(cat,-2,axis=1)[:,-2:]
        cap=np.where(cat==top[:,1,None],top[:,0,None],top[:,1,None])
        assert other.max(initial=0)<self.sec.count
        cells=self.sec.index[np.searchsorted(self.sec.caps,cap),other]
        u=self.u[idx];den=u.sum(axis=1);amp=u/den[:,None]
        a,b,c=self.spin[0][idx],self.spin[1][other],self.spin[2][cells]
        cols=[np.ones(len(idx)),h,X[:,self.prior_ids],prior[:,1],h*den/38,
              h*(amp*self.eta[other]).sum(axis=1),h*(amp*self.missing[cells]).sum(axis=1)]
        tw=b*a;mix=None
        for z in (a,b,c,tw,tw*c):
            z_m=z;terms=[]
            for _ in MODES:
                S=(amp*z_m).sum(axis=1)
                terms.extend([S.real,S.imag,abs(S)**2]);z_m=z_m*z
            cols.append(h[:,None]*np.column_stack(terms));mix=terms
        for val,key in zip((mix[0],mix[4],mix[8]),('walk','tensor','sign')):
            cols.append(val*X[:,self.core.labels.index(key)])
        return np.column_stack(cols)

    def groups(self):
        ordinary=self.controls+self.ids['coordinate']+self.ids['erased_position']+self.ids['coverage']
        unpriced=ordinary+self.ids['radial_spiral'];priced=unpriced+self.ids['permission_spiral']
        return dict(previous=[1],combined=self.base_ids,nonoscillating=self.controls,ordinary_fourier=ordinary,
                    radial_spiral=unpriced,permission_spiral=priced,joint=priced+list(range(self.mix_start,len(self.labels))))


def compare(traw,test,groups,base):
    G,A=forms(traw.mean(0),base);g,b=forms(test.mean(0),base)
    tests=[forms(row,base) for row in test];out={}
    for name,ids in groups.items():
        v,rank=train(G,A,ids)
        ss=[float(v@a@v/(v@h@v)) for h,a in tests]
        out[name]=dict(rank=rank,ids=ids,score=float(v@b@v/(v@g@v)),seed_scores=ss,coefficients=v.tolist())
    for row in out.values():
        row['comparisons']={}
        for name in ('combined','ordinary_fourier'):
            diff=np.subtract(row['seed_scores'],out[name]['seed_scores'])
            row['comparisons'][name]=dict(gain=row['score']-out[name]['score'],
                                          paired_se=float(diff.std(ddof=1)/np.sqrt(len(diff))))
    return out


def run():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('prior',type=Path)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--seed',type=int,required=True)
    p.add_argument('--training',type=Path);p.add_argument('--runs',type=int,default=6)
    p.add_argument('--boundary',action='store_true',help='Wind at the native erased arithmetic sectors.')
    p.add_argument('--power',type=int,default=16);p.add_argument('--tilt',type=float,default=15.)
    a=p.parse_args();prior=json.loads(a.prior.read_text());dual=HERE/prior['dual'];coord=HERE/prior['coordinate']
    assert DIGEST(dual)==prior['dual_sha256'] and DIGEST(coord)==prior['coordinate_sha256']
    op,feature,ctrl=configured(dual);core=JointWeight(op.r,json.loads(coord.read_text()))
    spiral=FaceSpiral(op,core,a.prior,ctrl,dual) if a.boundary else Spiral(op.r,core,a.prior)
    seeds=list(range(a.seed,a.seed+a.runs))
    old=None;used=set(prior['seeds']);assert a.runs>=4 and a.power>=9
    if a.training:
        old=json.loads(a.training.read_text());assert old['prior_sha256']==DIGEST(a.prior) and old['labels']==spiral.labels
        used.update(old['seeds'])
    assert {s+j for s in seeds for j in (0,100000)}.isdisjoint(s+j for s in used for j in (0,100000))
    blocks=[]
    for s in seeds:
        blocks.append(sample(op,s,a.power,a.tilt,feature.base,False,spiral,random_marked_label=True))
        print(json.dumps(dict(seed=s,mass=blocks[-1][0,0,0])),flush=True)
    raw=np.stack(blocks)
    if old:
        path=a.training.with_name(old['sample']);assert DIGEST(path)==old['sample_sha256']
        with np.load(path,allow_pickle=False) as z:fit=z['raw']
        test=raw
    else:fit,test=raw[:len(raw)//2],raw[len(raw)//2:]
    rows=compare(fit,test,spiral.groups(),feature.base)
    f=a.output.with_suffix('.npz');np.savez_compressed(f,raw=raw)
    out=dict(scope='Held-out fixed-dual 38-shift Fourier and winding-mode comparisons on the combined sieve weight.',
             prior=a.prior.name,prior_sha256=DIGEST(a.prior),labels=spiral.labels,rows=rows,seeds=seeds,
             power=a.power,tilt=a.tilt,base=feature.base,sample=f.name,sample_sha256=DIGEST(f),boundary=a.boundary)
    if old:out.update(training=a.training.name,training_sha256=DIGEST(a.training))
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v['score'] for k,v in rows.items()}),flush=True)


if __name__=='__main__':run()
