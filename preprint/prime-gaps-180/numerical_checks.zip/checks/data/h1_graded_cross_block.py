"""Restore a rectangle crossing the boundary of a previously certified H1 square."""
import argparse
from fractions import Fraction as Q
from pathlib import Path
import json

import gmpy2
import numpy as np

from h1_graded_raw_block import (CERT,FIT,FIBRES,MINORANTS,NORM,PRICES,REDUCED,TABLE,UNIT,
    ceil,ceiling_sqrt,cut_energies,digest,exact,geom,read,residual_tables,schedules,sci_upper)
from h1_raw_diagonal_bound import geometry,mixture_energies,compact_weights,harmonic_rows,kernel_at
from h1_sunrise_refined import positive_definite


def native_layout(fibres,cert):
    table,original,layout=geometry(TABLE)
    with np.load(original['cell_bins'],allow_pickle=False) as arch:
        strata=np.unique(arch['cells'][:,1]).astype(int)
    indices=np.arange(fibres['intervals']-38)
    groups=np.full(len(table['codes']),-1,int)
    for i,g in enumerate(cert['groups']):groups[g]=i
    last=np.full(len(cert['groups'])+1,-1,int)
    top=last.copy()
    by_cap={}
    for c in sorted(set(strata.tolist())|set(fibres['caps'])):
        owner=groups[layout(strata[np.searchsorted(strata,c)],indices)]
        np.maximum.at(last,owner,indices);np.maximum.at(top,np.unique(owner),c)
        by_cap[c]=owner
    return indices,last[:-1],top[:-1],by_cap


def coefficients(fibres,by_cap,indices,selected,partner,step):
    """Bound the signed coefficients on native indices where this side could need a source."""
    by_inc={}
    used_caps=[]
    first=int((UNIT//2-partner)//step)-37+1
    for c,owner in by_cap.items():
        rr=indices[(indices>=first)&np.isin(owner,selected)]
        if len(rr):
            inc=next(t for t in fibres['caps'] if t>=c)
            by_inc.setdefault(inc,[]).append(rr)
            used_caps.append(c)
    lo=min(int(r[0]) for ranges in by_inc.values() for r in ranges)
    hi=max(int(r[-1]) for ranges in by_inc.values() for r in ranges)
    # Group at most 16 adjacent radial cells. Extrema are taken before
    # summing increments, so every possible active coefficient is enclosed.
    width=16
    starts=np.arange(0,hi-lo+1,width)
    shape=(len(fibres['signatures']),len(starts))
    lows=np.zeros(shape,dtype=object);highs=lows.copy()
    windows=[]
    lift=np.vectorize(lambda x:Q(float(x)),otypes=[object])
    for layer in reversed(fibres['layers']):
        f=Path(fibres['cache_directory'])/layer['file']
        assert digest(f)==layer['sha256']
        with np.load(f,allow_pickle=False) as archive:
            bounds=archive['bounds'][:,:,lo:hi+1]
        lows+=lift(np.minimum.reduceat(bounds[:,0],starts,axis=1))
        highs+=lift(np.maximum.reduceat(bounds[:,1],starts,axis=1))
        if layer['cap'] in by_inc:
            bins=np.unique((np.concatenate(by_inc[layer['cap']])-lo)//width)
            windows.append(list(zip(lows[:,bins].min(axis=1),highs[:,bins].max(axis=1))))
    coeff=[(exact(min(w[i][0] for w in windows)),exact(max(w[i][1] for w in windows))) for i in range(shape[0])]
    return coeff,int(lo*step),int(ceil(max(used_caps)*step))


def max_grade(R,z):
    n=R//z
    return max(z,2*R+int(ceil(Q(R,n+1))),2*n*z+z)


def tails(cuts,delta,R,low,z,coeff,h,scale,Z,D,eta,step,sigs,erasure_limit):
    m=37
    upper=max_grade(R,z)
    wanted=sorted({t for t in cuts if t<upper})
    assert min(cuts)>z
    total={t:Q(0) for t in cuts}
    cdfs=residual_tables(m,R//delta,R//eta+1,eta,scale,h,Z)
    rank=R//z
    split=int(ceil(Q(R,rank+1)))
    count=0
    for lower,stop,envelope in ((delta,split,R),(max(delta,split),z,rank*z)):
        for v in range(lower,stop,step):
            w=min(stop,v+step)
            levels=[t for t in wanted if 2*envelope+w>t]
            if not levels:continue
            parts=cut_energies(v,w,[Q(t-w,2) for t in levels],R,low,z,eta,h,scale,coeff,sigs,cdfs,m,5)
            for t,value in zip(levels,parts):total[t]+=value
            count+=1
    pref=geom.RS*38*h/(Z*D)
    cap=erasure_limit
    for t in sorted(total):
        cap=min(cap,pref*total[t])
        total[t]=cap
    return total,count


def signed_norms(cert,prices,left,right,risk):
    forms=Path('h1_cover_native_mixed.json');frozen=Path('h1_cover_72_semiprime_mixed_fit.json')
    for p in (forms,forms.with_suffix('.npz'),frozen):
        assert prices['inputs'][p.name]==digest(p)
    base=mixture_energies(forms,frozen)
    masses=[sum(base[g,0]) for g in cert['groups']]
    a=np.array([exact(masses[i]) for i in left],dtype=object)
    b=np.array([exact(masses[i]) for i in right],dtype=object)
    L,R,S=[np.asarray(M,dtype=object)[np.ix_(left,right)]*risk for M in cert['affine'][:3]]
    def verify(M):
        if not np.any(M):return Q(0)
        A=M*gmpy2.mpq(1,prices['scale'])
        norm=np.linalg.norm(A.astype(float)/np.sqrt(np.outer(a,b).astype(float)),2)
        k=Q(int(np.ceil(norm*10**8))+1,10**8)
        # Schur complement of the opposite diagonal, on the smaller side.
        gram=(A/b[None,:])@A.T
        assert positive_definite(np.diag(a*exact(k)**2)-gram)
        return k
    return [verify(M) for M in (L+R+S,-R-S,-S)],[int(np.count_nonzero(M))*2 for M in (L,R,S)]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--left-radius-ticks',type=int,default=2500000)
    parser.add_argument('--right-radius-ticks',type=int,default=2625000)
    parser.add_argument('--fragment-index',type=int,default=47317)
    parser.add_argument('--square',type=Path,default=Path('h1_graded_r120712.json'))
    parser.add_argument('--grade-step',type=int,default=40000)
    parser.add_argument('--integral-step',type=int,default=500)
    parser.add_argument('--witness-step',type=int,default=10000)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    cert,fibres,norm,prices,table,cut,square=map(read,(CERT,FIBRES,NORM,PRICES,TABLE,REDUCED,args.square))
    assert all(square['inputs'][p.name]==digest(p) for p in (CERT,FIBRES,NORM,PRICES,TABLE,REDUCED))
    assert cut['retained_affine_channels']==[0,1,2]
    assert norm['status']=='ORDINARY_NORM_ENCLOSED' and fibres['status']=='ERASED_AMPLITUDES_ENCLOSED'
    ix,last,z,bycap=native_layout(fibres,cert)
    h=Q(norm['step']);scale=geom.RHO*UNIT;unit=h*scale
    rs=np.array([int(ceil((int(j)+37)*unit)) for j in last])
    prior=np.isin(np.arange(len(rs)),square['selected_groups'])
    left=np.flatnonzero(prior&(rs<=args.left_radius_ticks)&(z<=args.fragment_index))
    right=np.flatnonzero(~prior&(rs<=args.right_radius_ticks)&(z<=args.fragment_index))
    assert len(left) and len(right) and np.all(rs[left]*2<=UNIT//2)
    risk=rs[left,None]+rs[None,right]>UNIT//2
    left=left[risk.any(axis=1)];right=right[risk.any(axis=0)]
    risk=rs[left,None]+rs[None,right]>UNIT//2
    A,B=int(max(rs[left])),int(max(rs[right]))
    one=[]
    for rows in schedules(table,cert)[:3]:
        used=rows[rows[:,0]<A+B]
        assert len(used) and used[-1,1]>=A+B and min(used[:,2])>0
        one.append((int(used[:,2].min()),int((used[:,0]+used[:,2]).min())))
    delta=min(v for v,w in one);W=min(w for v,w in one)
    ca,la,za=coefficients(fibres,bycap,ix,left,B,unit)
    cb,lb,zb=coefficients(fibres,bycap,ix,right,A,unit)
    va,vb=max_grade(A,za),max_grade(B,zb)
    start=2*W-vb
    assert za<start<va and 2*W-va>zb
    breaks=[*range(start,va,args.grade_step),va]
    Z=Q(norm['coordinate_Z']['lower']);D=Q(norm['normalized_norm']['lower'])
    common=(h,scale,Z,D,args.integral_step,args.witness_step,fibres['signatures'],geom.RS*Q(norm['S'])*38*Q('3.638')/37)
    left_tail,na=tails(breaks[:-1],delta,A,la,za,ca,*common)
    print('enclosed left thresholds',len(left_tail),'witness intervals',na,flush=True)
    right_tail,nb=tails([2*W-t for t in breaks[1:]],delta,B,lb,zb,cb,*common)
    products=[ceiling_sqrt(left_tail[x]*right_tail[2*W-y]) for x,y in zip(breaks,breaks[1:])]
    mixed=sum(products,Q(0))
    ops,nz=signed_norms(cert,prices,left,right,risk)
    cover_path=Path('h1_exception_cover_72.json');cover=read(cover_path);book=read(MINORANTS)
    assert cover['source_sha256']==digest(MINORANTS) and prices['inputs'][cover_path.name]==digest(cover_path)
    data=next(r for r in book['rows'] if Q(r['theta'])==Q('.5291'))
    old=harmonic_rows('old',Q(data['a']),Q(data['zeta']),cover['bins'])
    w=np.array(cover['covers']['old']['weights'],np.int64)
    assert cover['weight_scale']==10**9 and min(w)>=0 and min(w[old[-1]].sum(axis=1))>=24*10**9
    q=Q(B,UNIT)
    budgets=[1/(Q(1,2)-q-Q('.0001')),kernel_at(compact_weights(old,w),q),
             24/(min(1-2*Q(data['a']),Q(1,2)-q)-Q('.0001'))]
    means=[Q(1),Q('.000093307088324062'),Q(data['five_mass']['upper'])+Q(cert['arithmetic']['three_error_mass'][1])]
    assert means[1]==Q(str(table['kappa_upper']))
    charges=[2*k*ceiling_sqrt(u*m)*mixed for k,u,m in zip(ops,budgets,means)]
    def show(v):return sci_upper(v) if v else '0'
    paths=[Path(__file__),args.square,CERT,FIT,FIBRES,MINORANTS,NORM,PRICES,REDUCED,TABLE,cover_path,
           Path('h1_graded_raw_block.py'),Path('h1_raw_diagonal_bound.py'),Path('h1_sunrise_refined.py')]
    out=dict(scope='Three affine raw-error allowance on both orientations of a rectangle outside the previous square. Left self-pairings are in the ordinary range.',
             inputs={p.name:digest(p) for p in paths},left_groups=left.tolist(),right_groups=right.tolist(),
             radius_cutoffs_ticks=[args.left_radius_ticks,args.right_radius_ticks],native_fragment_limit=args.fragment_index,
             actual_radius_ticks=[A,B],actual_fragment_ticks=[za,zb],common_activation=delta,common_budget=W,
             integral_step=args.integral_step,witness_step=args.witness_step,grade_step=args.grade_step,grade_breaks=breaks,
             ordered_above_half=int(2*risk.sum()),active_entries=nz,
             left_tail={str(k):show(v) for k,v in left_tail.items()},right_tail={str(k):show(v) for k,v in right_tail.items()},
             mixed_energy_upper=show(mixed),signed_multiplier_norms=list(map(str,ops)),
             component_charge_upper=list(map(show,charges)),three_channel_loss_upper=show(sum(charges)))
    if args.check:assert out==read(args.output)
    else:args.output.write_text(json.dumps(out,indent=2)+'\n',newline='\n')
    print('additional ordered pairs',out['ordered_above_half'],'cost',out['three_channel_loss_upper'],flush=True)


if __name__=='__main__':
    main()
