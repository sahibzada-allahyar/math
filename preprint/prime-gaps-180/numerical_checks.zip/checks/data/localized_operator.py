"""Continuum error and uniform gate charges for the true B2 operator image."""
from fractions import Fraction as Q
from hashlib import sha256
import json
from math import ceil, factorial
from pathlib import Path

import numpy as np

from first_edge_mass import except_largest
from quotient_inputs import STEP
from h1_degree6_native_schur_support import inputs,replay_limits
from h1_exact_convolution import convolution


HERE=Path(__file__).resolve().parent
FIRST=45067


def retained_groups(model,group_ends):
    """All possible exact native price classes and common geometry per retained group."""
    caps=sorted(model.caps)
    geoms=sorted(model.groups)
    result=[]
    lower=-1
    for upper in group_ends:
        last=next(c for c in caps if c>=upper)
        rows=[c for c in caps if lower<c<=last]
        geometry={next(g for g in geoms if g>=c) for c in rows}
        assert len(geometry)==1
        result.append((lower,upper,geometry.pop(),tuple(rows)))
        lower=upper
    assert upper==caps[-1]
    return result


def native_price_square_upper(model,rows):
    """Upper on the square of (rho/100)*price throughout one retained class group."""
    out=np.zeros(model.n)
    for c in rows:
        m,r=model.price(c)
        abs_high=np.nextafter(np.abs(m)+r,np.inf)
        high=np.nextafter(abs_high**2,np.inf)
        high[(m==0)&(r==0)]=0.
        np.maximum(out,high,out=out)
    return out


def first_edge(regular,tau,subticks):
    """Independent clipped discrete deficits with one tick of sub-threshold dust."""
    ne=subticks
    nx=int(tau*subticks)
    pmf=[0]*(nx+1)
    for j in range(nx):
        for u in range(ne):
            pmf[min(nx,j+u)]+=1
    den=nx*ne
    assert sum(pmf)==den
    n=regular-1
    maxsum=200*subticks
    # Split by the maximum of the coupled regular draws. This avoids the
    # union factor regular when the same configuration has several witnesses.
    # Use bins to keep the exact integer convolutions economical.
    def power(p,degree,limit):
        if degree==0:return [1]
        h=power(p,degree//2,limit)
        y=convolution(h,h,limit+1)
        return convolution(y,p,limit+1) if degree%2 else y
    previous=[0]
    total=0
    for lo in range(0,nx+1,16*subticks//8):
        hi=min(nx,lo+16*subticks//8-1)
        # If the maximum lies in [lo,hi], a retained-deficit sum <=200
        # requires the total of all 37 to be <=200+hi.
        limit=maxsum+hi
        upper=power(pmf[:hi+1],regular,limit)
        if lo:
            previous=power(pmf[:lo],regular,limit)
        total+=int(sum(upper)-sum(previous))
    grouped=Q(total,den**regular)
    simple=Q(regular*int(sum(power(pmf,n,maxsum))),den**n)
    exact_plain=except_largest(regular,Q(200)/tau)
    return min(grouped,simple,exact_plain),grouped,simple,exact_plain


def constants():
    rate,scale,classes=inputs()
    last=max(j for _,j in replay_limits(2))
    assert last==130964 and classes[0].upper==FIRST and 3*FIRST>last
    retained_max=last-FIRST
    for c in classes:
        rows=[(l,u,a,b) for l,u,a,b in c.sectors if l<=retained_max]
        assert rows[0][0]==0 and rows[-1][1]>=retained_max
        assert all(a==scale and b==0 for _,_,a,b in rows)
    receipt=HERE/'cap_law_transfer.json'
    report=json.loads(receipt.read_text())
    native_r=Q(report['relative_bin_bound'])
    chi_native_sq=Q(report['squared_hellinger_bound'])
    chi=Q('0.000000110001')
    assert chi**2*(1-native_r)>chi_native_sq
    ray=rate*(last-FIRST+1)
    single=Q('1.619885')
    assert single**2>=78*ray**2
    pair=Q('.314')
    # At common retained index s the bare pair volume is at most the triangle
    # with sides (last-s+1),(last-s+2); denominator uses the upper 37-cell.
    # (last-s+2)/(0.4999/rate-37-s) decreases throughout its support.
    assert Q(4999,10000)>rate*(last+39)
    assert (rate*(last+2)/(Q(4999,10000)-37*rate))**2 < pair
    err=(single+pair*(2+chi))*chi
    assert err<Q('0.000000248')
    tau=STEP*Q(2624990) # gate ticks differ from the prime-price clock
    regular=39-2
    first,grouped,simple,plain=first_edge(regular,tau,32)
    lam=Q(43,200)
    cell_exp=1/sum((lam*tau)**k/factorial(k) for k in range(15))
    site=max(cell_exp,1/(lam*tau*lam*100))
    assert cell_exp<1/(lam*100) and tau<100
    exp_upper=Q(68,25)
    assert sum(Q(1,factorial(k)) for k in range(7))+Q(8,7*factorial(7)) < exp_upper
    # For each of the 37 regular sites that could be erased, retain the
    # other 36. If it is an exceptional site, a regular deletion suffices.
    second=regular*exp_upper**129*site**(regular-1)
    opnorm=Q('11.314')
    low_charge=(first+second)*opnorm**2
    ceil_at=lambda q,p: str(Q(ceil(q*10**p),10**p))
    return dict(scope='True continuum B2 operator. Native erasure fields approximate its image on the true product law, uniformly over subsequent event projections.',
                cap_law_receipt_sha256=sha256(receipt.read_bytes()).hexdigest(),
                last_full_index=last,first_changed_site_index=FIRST,
                changed_site_retained_index_ceiling=retained_max,price_class_count=len(classes),
                changed_insertion_price='1',true_single_site_chi_upper=str(chi),
                single_error_over_chi_upper=str(single),pair_bare_norm_upper=str(pair),
                relative_image_norm_error_upper=ceil_at(err,14),
                conditional_regular_sites=regular,first_probability_upper=ceil_at(first,16),
                first_grouped_max_upper=ceil_at(grouped,16),first_simple_union_upper=ceil_at(simple,16),
                first_uniform_deficit_only_upper=ceil_at(plain,16),
                second_probability_upper=ceil_at(second,18),
                actual_operator_norm_upper=str(opnorm),two_edge_operator_charge_over_F_norm_sq=ceil_at(low_charge,13))


if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',type=Path)
    args=ap.parse_args()
    encoded=json.dumps(constants(),indent=2)+'\n'
    print(encoded,end='')
    if args.output:args.output.write_text(encoded)
