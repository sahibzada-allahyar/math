"""Checkpoint native sector antiderivatives separately, then recover all disjoint layer energies."""
import argparse
from fractions import Fraction as Q
from math import ceil
from pathlib import Path
import json
import time

import numpy as np
from flint import arb,ctx

from h1_combined_mass_interval import CellMoments,P,square_rows
from h1_dickman_taylor import DickmanTaylor,rat,record
from h1_margin_fallback import FIBRES,FIT,NORM,PRICES,SCORE,TABLE,geom,read,digest
from h1_native_cap_total import OUTPUT as TOTAL,enclosure,interval
from h1_sunrise_boundary import geometry
from h1_tilted_transform import TiltedMoments,powers_of_two,self_check

DIRECTORY=Path('h1_native_sector_layers')
OUTPUT=Path('h1_native_sector_replay.json')


def save(path,out):
    tmp=path.with_suffix('.pending')
    tmp.write_text(json.dumps(out,separators=(',',':'))+'\n',newline='\n')
    tmp.replace(path)


def sector_sum(density,ids,kernel,pref):
    assert np.all(density[1]>=0)
    density=(np.maximum(0,density[0]),density[1])
    weighted=P.interval_multiply(density,kernel)
    return {str(i):[record(pref*P.nonnegative(P.outward_sum(row,ids==i))) for row in (density,weighted)]
            for i in np.unique(ids)}


def coefficients(fibres,e,cap):
    sigs=tuple(map(tuple,fibres['signatures']))
    rows=[(np.zeros(e.n),np.zeros(e.n)) for _ in sigs]
    for r in fibres['layers']:
        if r['cap']<cap:continue
        path=Path(fibres['cache_directory'])/r['file']
        assert digest(path)==r['sha256']
        with np.load(path,allow_pickle=False) as arc:
            raw=arc['bounds']
        rows=[P._interval_add(row,tuple(v)) for row,v in zip(rows,raw,strict=True)]
    return square_rows(rows,sigs)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--caps',nargs='+',type=int,help='Compute only these boundaries')
    parser.add_argument('--check',action='store_true',help='Verify saved boundaries and assemble the full enclosure')
    args=parser.parse_args()
    moment_checks=self_check()
    total,src,fi,norm,price=map(read,(TOTAL,SCORE,FIBRES,NORM,PRICES))
    for p in (SCORE,FIT,FIBRES,NORM,PRICES,TABLE):assert total['inputs'][p.name]==digest(p)
    caps=src['caps'];assert [r['cap'] for r in src['layers']]==caps
    paths=[Path(__file__),Path('h1_tilted_transform.py'),TOTAL,SCORE,FIBRES,FIT,NORM,PRICES,TABLE,
           Path('h1_combined_mass_interval.py'),Path('h1_dickman_taylor.py'),Path('h1_sunrise_boundary.py')]
    hashes={p.name:digest(p) for p in paths}
    def pathname(cap):return DIRECTORY/f'cap_{cap}.json'
    selected=set(args.caps or caps)
    assert selected<=set(caps)
    DIRECTORY.mkdir(exist_ok=True)
    engine=None;layout=None
    for k,cap in enumerate(caps):
        if cap not in selected:continue
        path=pathname(cap)
        nxt=caps[k+1] if k+1<len(caps) else None
        if path.exists():
            saved=read(path)
            assert saved['inputs']==hashes and saved['cap']==cap and saved['next_cap']==nxt
            continue
        assert not args.check
        if engine is None:
            e=CellMoments(38,norm['intervals'],Q(norm['S']),precision=576,minimum_cap=min(caps))
            e.dickman=DickmanTaylor(max(3,ceil(Q(e.n,min(caps)))),degree=56,precision=e.precision)
            engine=e
            assert fi['step']==norm['step']==str(e.hq)
            table,original,layout=geometry(TABLE)
            with np.load(original['cell_bins'],allow_pickle=False) as z:strata=np.unique(z['cells'][:,1])
            indices=np.arange(e.n)
            length=1<<(e.n-1).bit_length();bits=256
            damping=powers_of_two(length,bits)
            kernel=P.float_interval([1/rat(Q(1,2)-geom.RS*(int(j)+37)*e.hq-Q('.0001')) for j in indices])
            dlo,dhi=enclosure(norm['normalized_norm'])
            pref=rat(geom.RS)*e.k*e.h/e.Z/(rat(dlo).union(rat(dhi)))
        start=time.monotonic()
        at=coefficients(fi,e,cap)
        changed=nxt is not None and cap in fi['caps']
        after=coefficients(fi,e,nxt) if changed else at
        polys=[at,after] if changed else [at]
        weights=[w*d for w,d in zip(e.coordinate_weights,e.survival(cap*e.hq))]
        tm=TiltedMoments(weights,e.midpoints,list(at),37,e.S,damping,bits)
        densities=[(np.zeros(e.n),np.zeros(e.n)) for _ in polys]
        for sig in at:
            moment=tm.moment(sig)
            for i,poly in enumerate(polys):
                densities[i]=P._interval_add(densities[i],P.interval_multiply(poly[sig],moment))
        tm.clear();del tm,weights
        e._survival.clear()
        def sums(values,c):
            ids=layout(strata[np.searchsorted(strata,c)],indices)
            return sector_sum(values,ids,kernel,pref)
        ending=sums(densities[0],cap)
        following=sums(densities[-1],nxt) if nxt is not None else {}
        save(path,dict(inputs=hashes,cap=cap,next_cap=nxt,ending=ending,following=following,
                       precision=e.precision,damping_bits=bits,relative_input_bits=80,toy_checks=moment_checks))
        print('native sector boundary',cap,'seconds',round(time.monotonic()-start,1),flush=True)
    if not all(pathname(c).exists() for c in caps):return
    energies=[[[Q(0),Q(0)],[Q(0),Q(0)]] for _ in price['sector_prices']]
    previous={};zero=[interval(Q(0),Q(0))]*2
    dlo,dhi=enclosure(norm['normalized_norm'])
    for k,cap in enumerate(caps):
        path=pathname(cap);r=read(path)
        assert r['inputs']==hashes and r['cap']==cap and r['next_cap']==(caps[k+1] if k+1<len(caps) else None)
        hashes_layer={i:r['ending'].get(i,zero) for i in set(previous)|set(r['ending'])}
        income=[Q(0),Q(0)];ordinary=[Q(0),Q(0)]
        for key,end in hashes_layer.items():
            beg=previous.get(key,zero)
            for j in range(2):
                a,b=enclosure(end[j]);l,h=enclosure(beg[j])
                lo,hi=max(0,a-h),b-l
                assert hi>=lo
                energies[int(key)][j][0]+=lo;energies[int(key)][j][1]+=hi
                coefficient=Q(price['sector_prices'][int(key)][j],price['scale'])
                income[0]+=min(coefficient*lo,coefficient*hi);income[1]+=max(coefficient*lo,coefficient*hi)
                if j==0:ordinary[0]+=lo;ordinary[1]+=hi
        for pair,field in ((income,'priced_contribution'),(ordinary,'unweighted_contribution')):
            a,b=enclosure(src['layers'][k][field])
            assert max(pair[0],min(a/dlo,a/dhi))<=min(pair[1],max(b/dlo,b/dhi)),(cap,field)
        previous=r['following']
    out=dict(scope='Normalized native ordinary and prime-kernel sector enclosures from independent ball-arithmetic transforms. All layer incomes were cross-checked against the archived native integrals.',
             inputs=hashes,boundaries={pathname(c).name:digest(pathname(c)) for c in caps},
             cap_quotient=total['cap_quotient'],normalized_sector_energies=[[interval(*v) for v in row] for row in energies])
    if args.check:assert read(OUTPUT)==out
    else:save(OUTPUT,out)
    print('recovered',len(energies),'native sectors and cross-checked',len(caps),'layers',flush=True)


if __name__=='__main__':main()
