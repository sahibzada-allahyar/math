"""Select a source order at each band and compile a sufficient all-mark filter for fourteen channels."""
import argparse
import gzip
import json
from fractions import Fraction as Q
from math import ceil,floor
from pathlib import Path
import numpy as np

from h1_mass_band_prices import CERT,FIT,NORM,TABLE,UNIT,digest,geom,read
from h1_multilevel_native_cap import CERT as ML_CERT
from h1_multilevel_root_filter import OUT as PARENT,rows_for
from h1_multilevel_strip_free import OUT as STRIP_FREE
from h1_sunrise_boundary import geometry

OUT=Path('h1_multilevel_order_schedules.json')
MINRAD=2_000_000


def schedule(name,rows):
    if name=='largest':
        order=rows[:,2:].argmax(axis=1)
    else:
        minimum=int(name)
        enough=rows[:,2:]>=minimum
        order=np.where(enough.any(axis=1),enough.argmax(axis=1),rows[:,2:].argmax(axis=1))
    return rows[:,0],order+1,rows[np.arange(len(rows)),order+2]


def mark_edges(minimum,spacing,split=()):
    # Finer near zero. No source needs to test a mark below the first edge.
    return np.unique([minimum,*[x for x in (100,300,1000,3000,6000,10000) if x>minimum],
                      *range(20000,200001,10000),*range(200000+spacing,1_800_000,spacing),
                      *split,1_800_000]).astype(np.int64)


def model():
    parent,free,norm=map(read,(PARENT,STRIP_FREE,NORM))
    doc=read(OUT)
    assert doc['inputs'][PARENT.name]==digest(PARENT) and free['removed_channels']==['C0','C1','C2']
    shape,orig,layout=geometry(TABLE)
    with np.load(orig['cell_bins']) as z:ends=np.unique(z['cells'][:,1])
    ix=np.arange(norm['intervals']-38)
    groups=read(CERT)['groups']
    group=np.full(len(shape['codes'])+1,len(groups),int)
    for i,g in enumerate(groups):group[g]=i
    native=np.asarray([layout(c,ix) for c in ends])
    gt=group[native]
    lo=np.full(len(groups)+1,len(ix),int);hi=np.full(len(groups)+1,-1,int)
    for v in gt:
        np.minimum.at(lo,v,ix);np.maximum.at(hi,v,ix)
    tick=Q(norm['step'])*geom.RHO*UNIT
    return parent,doc,norm,ends,native,gt,lo,hi,tick


def radius_ids(lo,hi,tick,step):
    first=np.array([max(MINRAD//step,floor(int(x)*tick/step)) for x in lo])
    last=np.array([max(MINRAD//step,ceil((int(x)+37)*tick/step)) for x in hi])
    lookup=np.full((len(lo),int(last.max()+1-MINRAD//step)),-1,int)
    labels=[];radii=[]
    for i,(a,b) in enumerate(zip(first,last)):
        if i==len(lo)-1:a=MINRAD//step
        for j in range(a,b+1):
            lookup[i,j-MINRAD//step]=len(labels)
            labels.append(i);radii.append(j*step)
    return lookup,np.array(labels),np.array(radii)


def budget(parent,doc,labels,radii,u,name):
    # Upper radial and mark endpoints give the more stringent threshold
    # for the entire bin. Round the allowed tail DOWN to integer ticks.
    G=len(parent['group_radii']);limit=np.full((len(labels),len(u)),2*UNIT,dtype=np.int32)
    for base,q in zip(parent['channels'][:14],doc['channels']):
        assert base['channel']==q['channel'] and base['reduced_radius_groups']==0
        R=np.r_[base['gated_radius'],0];M=np.r_[base['maximum_gated_partner'],0]
        radius=np.minimum(radii,R[labels])
        active=(M[labels]>0)&(radius+M[labels]>5_000_000)
        a=np.flatnonzero(active)
        if not len(a):continue
        groups=labels[a]
        lo,order,delta=schedule(name,np.array(q['rows'],np.int64))
        assert min(delta)>0
        j=np.searchsorted(lo,radius[a]+M[groups],side='left')
        for n,v in enumerate(u):
            p=np.where(delta<v,lo+delta-order*v,4*UNIT)
            mins=np.r_[4*UNIT,np.minimum.accumulate(p)][j]
            cap=mins*R[groups]//(R[groups]+M[groups])
            cap=np.where(mins==4*UNIT,2*UNIT,cap)
            limit[a,n]=np.minimum(limit[a,n],cap)
    return limit


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--check',action='store_true')
    args=ap.parse_args()
    parent=read(PARENT);free=read(STRIP_FREE)
    with gzip.open(ML_CERT,'rt') as f:proof=json.load(f)
    assert free['inputs'][ML_CERT.name]==digest(ML_CERT)
    records=[]
    for original,raw in zip(parent['channels'][:14],rows_for(read(TABLE),proof,read(CERT))):
        rows=raw[:len(original['rows'])]
        lo,d,delta=schedule('largest',rows)
        assert list(map(list,zip(lo.tolist(),rows[:,1].tolist(),d.tolist(),delta.tolist())))==original['rows']
        assert np.all(rows[:,2:]>=0) and rows[-1,1]==original['level_limit']
        records.append(dict(channel=original['channel'],rows=rows.tolist()))
    assert len(records)==14
    paths=[Path(__file__),PARENT,STRIP_FREE,ML_CERT,TABLE,NORM,FIT]
    out=dict(scope='Permitted single orders and their strictly positive meshes for each source band. Zero means the order is unavailable. A chosen order is used on every mark of a modulus in its band.',
             inputs={p.name:digest(p) for p in paths},channels=records)
    if args.check:assert read(OUT)==out
    else:OUT.write_text(json.dumps(out,separators=(',',':'))+'\n',newline='\n')
    print('verified alternatives on',sum(len(x['rows']) for x in records),'source bands',flush=True)


if __name__=='__main__':
    main()
