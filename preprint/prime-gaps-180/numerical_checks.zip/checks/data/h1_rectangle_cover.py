"""Price the union of all mixed rectangles before rounding it to a finite sector partition."""
import argparse
from fractions import Fraction as Q
from hashlib import sha256
import json
from math import ceil
from pathlib import Path
import numpy as np
from h1_cross_ladders import apply_permissions


def sides(cells,pieces,step,N):
    cap=cells[:,1].astype(int);first=cells[:,2].astype(int);last=cells[:,3].astype(int)
    caps,inv=np.unique(cap,return_inverse=True);bottom=np.r_[0,caps[:-1]]
    inner=np.zeros((len(cells),2*len(pieces)),bool);outer=inner.copy()
    for j,r in enumerate(pieces):
        ratio=Q(r['outer_radius'])/(Q('.2624989')*N*step)
        # Stored side masks round down the converted cap and radial end;
        # the radial end also subtracts k-1. Restore the outward allowances
        # used by h1_cross_ladders.rectangle, rounding separately upwards.
        pad_c=ceil(2*ratio)+3;pad_r=37+ceil(76*ratio)+77
        for b,name in enumerate(('outer','inner')):
            rows=r[name]
            hi=np.array([max([h for c,h in rows if x<=c],default=-1) for x in caps])
            lo=np.array([max([h+pad_r for c,h in rows if x<=c+pad_c],default=-1) for x in bottom])
            inner[:,2*j+b]=last<=hi[inv];outer[:,2*j+b]=first<=lo[inv]
    assert np.all(~inner|outer)
    return inner,outer


def signatures(bits):
    packed=np.packbits(bits,axis=1,bitorder='little')
    uniq,ids=np.unique(packed,axis=0,return_inverse=True)
    v=np.unpackbits(uniq,axis=1,bitorder='little')[:,:bits.shape[1]].astype(np.float32)
    count=v[:,::2]@v[:,1::2].T
    covered=(count>0)|(count.T>0)
    return ids,covered


def group_mask(ids,signature,covered,whole):
    n=ids.max()+1
    # Incidence of each group on the finite set of distinct signatures.
    # Count failures for a universal check, successes for an existential one.
    H=np.zeros((n,len(covered)),np.float32);H[ids,signature]=1
    has=((H@(1-covered if whole else covered).astype(np.float32))>0).astype(np.float32)
    found=has@H.T>0
    return ~found if whole else found


def partition(cells,inner,outer,cuts):
    controls=[cells[:,0].astype(int)]
    for cut in cuts:
        bits=inner if cut>=0 else outer;c=cut if cut>=0 else -cut-1
        controls.extend([bits[:,2*c],bits[:,2*c+1]])
    labels,ids=np.unique(np.column_stack(controls[::-1]),axis=0,return_inverse=True)
    return labels[:,-1],ids


def archive_signatures(cells,step,ctrl,hist,permissions):
    assert hist['receipt_sha256']==sha256(permissions.read_bytes()).hexdigest()
    sources={}
    for name in ('old','new'):
        pieces=[r for r in hist['pieces'] if r['source']==name]
        inn,out=sides(cells,pieces,step,ctrl['intervals'])
        sources[name]=(signatures(inn),signatures(out))
    return sources


def historical_masks(sources,ids,pr,ctrl,outer):
    out={}
    for name,key in [('old','prime_mask'),('new','minorant_mask')]:
        signature,cover=sources[name][int(outer)]
        mask=group_mask(ids,signature,cover,not outer)
        out[key]=mask|np.array(ctrl[key],bool)[np.ix_(pr,pr)]
    return out


def split_groups(cells,pr,ids,splits):
    ids=ids.copy();parents=list(pr)
    for row in splits:
        i=row['group'];col={'fragment':1,'radius':3}[row['axis']]
        block=ids==i;move=block&(cells[:,col]>row['threshold'])
        assert move.any() and (block&~move).any()
        ids[move]=len(parents);parents.append(parents[i])
    return np.array(parents),ids


def adaptive_splits(cells,pr,ids,sources,original,number):
    # A threshold wins when it excludes partially covered energy from an
    # outward pair, or proves coverage of a positive part of an inward pair.
    # This score selects geometry only. All permissions are rebuilt afterwards.
    wt=np.maximum(cells[:,4],0.);splits=[]
    while len(splits)<number:
        n=len(pr);energy=np.bincount(ids,weights=wt,minlength=n);channels=[]
        for key,(left,right) in sources.items():
            prior=np.array(original['prime_mask' if key=='old' else 'minorant_mask'],bool)[np.ix_(pr,pr)]
            for whole,(sig,cover) in [(True,left),(False,right)]:
                hit=~cover if whole else cover
                incidence=np.zeros((n,len(hit)),np.float32);incidence[ids,sig]=1
                toward=hit.astype(np.float32)@incidence.T>0
                any_hit=(incidence@toward.astype(np.float32))>0
                channels.append((sig,toward,any_hit&~prior,(.35 if key=='higher' else 1.)))
        winners=[]
        for i in range(n):
            ix=np.flatnonzero(ids==i)
            if energy[i]<1e-13 or len(ix)<2:continue
            best=(0.,'',0)
            for col,name in [(1,'fragment'),(3,'radius')]:
                order=ix[np.argsort(cells[ix,col],kind='stable')];v=cells[order,col]
                ends=np.flatnonzero(v[:-1]<v[1:])
                if not len(ends):continue
                left=np.cumsum(wt[order])[ends];right=energy[i]-left
                scores=np.zeros(len(ends))
                for sig,hit,active,importance in channels:
                    use=np.flatnonzero(active[i]&(energy>1e-15)&(np.arange(n)!=i))
                    if not len(use):continue
                    flags=hit[np.ix_(sig[order],use)]
                    first=flags.argmax(axis=0);last=len(order)-1-flags[::-1].argmax(axis=0)
                    assert np.all(flags[first,np.arange(len(use))])
                    ec=importance*energy[use]
                    scores+=left*((ends[:,None]<first)@ec)+right*((ends[:,None]>=last)@ec)
                j=int(scores.argmax())
                best=max(best,(scores[j],name,int(v[ends[j]])))
            if best[0]>1e-18:winners.append((best,i))
        if not winners:break
        take=min(number-len(splits),12)
        batch=[dict(group=i,axis=axis,threshold=t,selection_score=float(score))
               for (score,axis,t),i in sorted(winners,reverse=True)[:take]]
        pr,ids=split_groups(cells,pr,ids,batch);splits+=batch
    return pr,ids,splits


def verify_historical(data,original,path):
    # Rebuild every extra old-source permission using the authenticated
    # rectangle masks and the actual subcells used to construct this table.
    base=path.parent
    f=base/data['historical'];c=base/original['cell_bins'];p=base/data['pieces']
    for file,key in [(f,data['historical_sha256']),(c,original['cell_bins_sha256']),(p,data['pieces_sha256'])]:
        assert sha256(file.read_bytes()).hexdigest()==key
    with np.load(c,allow_pickle=False) as z:v=z['cells'];step=Q(str(z['step']))
    a,b=sides(v,json.loads(p.read_text())['pieces'],step,original['intervals'])
    pr,ids=partition(v,a,b,data['coverage']['cuts'])
    pr,ids=split_groups(v,pr,ids,data.get('targeted_splits',[]))
    assert np.array_equal(pr,data['parent_sectors'])
    sources=archive_signatures(v,step,original,json.loads(f.read_text()),path)
    for name,mask in historical_masks(sources,ids,pr,original,data['historical_outward']).items():
        assert np.array_equal(data[name],mask)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('cells',type=Path)
    p.add_argument('permissions',type=Path);p.add_argument('pieces',type=Path)
    p.add_argument('--cuts',nargs='*',type=int,default=[])
    p.add_argument('--historical',type=Path);p.add_argument('--historical-outward',action='store_true')
    select=p.add_mutually_exclusive_group()
    select.add_argument('--adaptive',type=int,default=0);select.add_argument('--split-plan',type=Path)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    digest=lambda f:sha256(f.read_bytes()).hexdigest()
    ctrl=json.loads(a.cells.read_text());apply_permissions(ctrl,a.permissions)
    geom=json.loads(a.pieces.read_text());rec=a.pieces.with_name(geom['ladders'])
    assert digest(rec)==geom['ladders_sha256'];ref=json.loads(rec.read_text())
    origin=a.pieces.with_name(ref['control']);assert digest(origin)==ref['control_sha256']
    assert json.loads(origin.read_text())['codes']==ctrl['codes'] and Q(ctrl['fragment_cap'])<=Q(ref['cap'])
    cache=a.cells.with_name(ctrl['cell_bins']);assert digest(cache)==ctrl['cell_bins_sha256']
    with np.load(cache,allow_pickle=False) as z:cells=z['cells'];step=Q(str(z['step']))
    inner,outer=sides(cells,geom['pieces'],step,ctrl['intervals'])
    si,ci=signatures(inner);so,co=signatures(outer)
    print('inward/outward signatures',len(ci),len(co),flush=True)
    pr,ids=partition(cells,inner,outer,a.cuts)
    sources=archive_signatures(cells,step,ctrl,json.loads(a.historical.read_text()),a.permissions) if a.historical else {}
    if a.split_plan:
        plan=json.loads(a.split_plan.read_text());assert plan['coverage']['cuts']==a.cuts and plan['pieces_sha256']==digest(a.pieces)
        splits=plan['targeted_splits'];pr,ids=split_groups(cells,pr,ids,splits)
    else:
        pr,ids,splits=adaptive_splits(cells,pr,ids,dict(sources,higher=((si,ci),(so,co))),ctrl,a.adaptive)
    n=len(pr);E=np.column_stack([np.bincount(ids,weights=cells[:,j],minlength=n) for j in (4,5,6)])
    G=group_mask(ids,si,ci,True);U=group_mask(ids,so,co,False)
    dec=lambda lines:np.array([[q=='1' for q in row] for row in lines],bool)
    old_in=dec(ref['mask'])[np.ix_(pr,pr)];old_out=dec(ref['outward_mask'])[np.ix_(pr,pr)]
    # A subcell has both a parent and its own tests. Retain every sound
    # inward grant and intersect the two independent outward bounds.
    G|=old_in;U&=old_out
    assert np.all(~G|U),np.argwhere(G&~U)[:8]
    old=np.array(ctrl['minorant_mask'],bool)[np.ix_(pr,pr)]
    target=E[:,0].clip(min=0)
    rows=lambda mask:[''.join(map(str,row.astype(int))) for row in mask]
    out=dict(ctrl)
    for key in ('prime_mask','minorant_mask'):
        out[key]=np.array(ctrl[key],bool)[np.ix_(pr,pr)].astype(int).tolist()
    if a.historical:
        for key,mask in historical_masks(sources,ids,pr,ctrl,a.historical_outward).items():
            out[key]=mask.astype(int).tolist()
        out.update(historical=a.historical.name,historical_sha256=digest(a.historical),
                   historical_outward=a.historical_outward)
    out.update(status='DETERMINISTIC_CAP_SUBCELLS_WITH_FULL_RECTANGLE_UNION',cells=a.cells.name,cells_sha256=digest(a.cells),
               old_permissions_sha256=digest(a.permissions),pieces=a.pieces.name,pieces_sha256=digest(a.pieces),
               ladder_sha256=digest(rec),subdivision=[dict(kind='rectangle-side',cut=c) for c in a.cuts],
               parent_sectors=pr.tolist(),codes=[ctrl['codes'][i] for i in pr],physical_upper=[ctrl['physical_upper'][i] for i in pr],
               sector_energies=E.tolist(),refined_grant=rows(G),refined_outward_grant=rows(U),
               targeted_splits=splits,
               coverage=dict(cuts=a.cuts,groups=n,signatures=[len(ci),len(co)],whole_pairs=int(np.triu(G).sum()),
                             possible_pairs=int(np.triu(U).sum()),new_whole=int(np.triu(G&~old).sum()),
                             new_possible=int(np.triu(U&~old).sum()),inward_weight=float(target@(G&~old)@target),
                             outward_weight=float(target@(U&~old)@target)))
    rebuilt=np.zeros_like(ctrl['sector_energies'],dtype=float);np.add.at(rebuilt,pr,E)
    assert np.max(abs(rebuilt-np.array(ctrl['sector_energies'])))<1e-11
    a.output.write_text(json.dumps(out,indent=1)+'\n');print(json.dumps(out['coverage']))


if __name__=='__main__':main()
