"""Use disjoint semiprime strips to improve a four-measure rough-support certificate."""
import argparse
from fractions import Fraction as Q
from math import floor,isqrt
from pathlib import Path
import json

import numpy as np
from scipy.linalg import eigh

from h1_cover_pairings import model,TABLE,DUAL
from h1_semiprime_budget import density,strip_mask
from h1_shared_rough_pricing import certify
from h1_sunrise_boundary import read,digest
from h1_third_measure import lower_radii
from verify_pairing_envelope import SCALE,quantize,lower_factor


def prime_correction(data,lin,factors):
    e,_,_,_,_,_,_,_,upper,coupled=data
    roots=np.array([isqrt(int(x*SCALE**2)) for x in e[:,0]],dtype=object)
    M=24*(np.outer(roots,roots)-SCALE*sum(lin))
    joint=np.zeros_like(M)
    for F,(coeff,_) in zip(factors,coupled):
        if coeff[0]:
            assert coeff[0]==1
            joint+=24*(F@F.T)
    M+=joint
    s=np.sqrt(upper[0].astype(float))
    ev,V=eigh((M.astype(float)/SCALE**2)*np.outer(s,s))
    def gram(keep):
        G=quantize(V[:,keep]*np.sqrt(np.abs(ev[keep]))/s[:,None])
        return G@G.T
    negative,positive=gram(ev<0),gram(ev>0)
    shift=max(np.abs(M+negative-positive).sum(axis=1))
    negative[np.diag_indices_from(negative)]+=shift
    paid,_=lower_factor(M,upper[0])
    assert all(Q(int(v),SCALE**2)==x for v,x in zip(negative.diagonal(),paid))
    # M+negative is PSD and the old bound paid its diagonal times U/24.
    # All rough multipliers involving P also include every tested strip.
    return joint,negative


def bonus_exact(Z,T,mask,cap,mu):
    assert np.array_equal(T,T.T) and not T[~mask].any()
    M=Z-24*SCALE*T
    penalty,_=lower_factor(M,cap)
    trace=Q(int(T.trace()),SCALE)
    return min(v*trace for v in mu)-sum(penalty*cap)/24


def solve_bonus(Z,mask,cap,mu,steps):
    # Maximise mu*tr(T) minus the cost of negative eigenvalues of Z-T.
    scale=np.sqrt(np.outer(cap.astype(float),cap.astype(float)))
    ref=Z.astype(float)*scale/(24*SCALE**2)
    b=float(sum(mu)/2)
    drift=b*np.diag(1/cap.astype(float))
    best=0.;saved=np.zeros_like(ref);prices=None
    for tau in (3e-5,3e-6,3e-7):
        z=ref-saved*scale
        if prices is not None:
            z+=tau*prices
        for i in range(steps):
            # Variable x is the residual. Its constrained entries are
            # fixed off-mask, free on-mask, with linear cost +mu*x_ii/cap_i.
            x=np.where(mask,z-tau*drift,ref)
            if i%30==0 or i+1==steps:
                T=(ref-x)/scale
                value=b*np.trace(T)+np.minimum(eigh(x,eigvals_only=True,check_finite=False),0).sum()
                if value>best:
                    best,saved,prices=value,T,(z-x)/tau
            h=2*x-z
            ev,V=eigh(h,check_finite=False)
            idx=ev<0
            prox=h+(V[:,idx]*np.minimum(-ev[idx],tau))@V[:,idx].T
            z+=1.65*(prox-x)
    return quantize(saved)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('cover',type=Path);ap.add_argument('joint',type=Path)
    ap.add_argument('--steps',type=int,default=55)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--check',action='store_true')
    a=ap.parse_args()
    data,_,inputs,_=model(a.cover)
    joint=read(a.joint);assert all(joint['inputs'][k]==v for k,v in inputs.items())
    inputs[a.joint.name]=digest(a.joint)
    table=read(TABLE)
    lin=[np.array(t,dtype=object) for t in joint['affine']]
    factors=[np.array(t,dtype=object) for t in joint['factors']]
    base=certify(data,lin,factors)
    assert floor(base*10**9)==joint['lower_billionths']
    rough,Qp=prime_correction(data,lin,factors)
    groups=read(DUAL)['groups']
    ids=np.array(sum(groups,[]))
    owner=np.repeat(np.arange(len(groups)),[len(g) for g in groups])
    low=min(lower_radii(table)[ids])
    # Every tested strip is rougher than zeta. In the first strip we
    # use the existing rough bound on C alone; elsewhere C<=U.
    cuts=list(map(Q,('.23174','.281','.32','.36','.39','.416407','.5')))
    old=read(a.output) if a.check else None
    if old:
        assert old['inputs']==inputs
    rows=[]
    total=base
    for i,(b,u) in enumerate(zip(cuts,cuts[1:])):
        local=strip_mask(table,TABLE,b)[np.ix_(ids,ids)]
        ii,jj=np.nonzero(~local)
        mask=np.ones((len(groups),len(groups)),bool)
        mask[owner[ii],owner[jj]]=False
        free=b>=Q(1,2)-low
        assert b>Q('.2317327998')
        Z=rough+Qp if free else rough
        H=data[-2][0] if free else data[-1][1][1]
        mu=density(b,u)
        if old:
            T=np.array(old['rows'][i]['multiplier'],dtype=object)
        else:
            T=solve_bonus(Z,mask,H,mu,a.steps)
        gain=bonus_exact(Z,T,mask,H,mu)
        if not old and gain<=0:
            T=np.zeros_like(T)
            # Z is an explicitly positive Gram plus a diagonal retreat,
            # so T=0 costs exactly nothing.
            gain=Q(0)
        if not T.any():
            gain=Q(0)
        total+=gain
        row=dict(lower=str(b),upper=str(u),prime_budget=bool(free),pairs=int(np.triu(mask).sum()),
                 gain_trillionths=floor(gain*10**12),multiplier=T.tolist())
        if old:
            assert row==old['rows'][i]
        rows.append(row)
        print(b,u,row['gain_trillionths'],'total',floor(total*10**9),flush=True)
    doc=dict(scope='Finite lower certificate with disjoint semiprimes in the prime and rough-support budgets.',
             inputs=inputs,rows=rows,lower_billionths=floor(total*10**9))
    if old:assert doc==old
    else:a.output.write_text(json.dumps(doc,separators=(',',':'))+'\n')


if __name__=='__main__':
    main()
