"""Bound the remaining raw pairing on a specified active diagonal of the H1 trial."""
import argparse
from fractions import Fraction as Q
from itertools import accumulate, product
from math import comb, factorial
from pathlib import Path
import json

import gmpy2
import numpy as np

from h1_exact_convolution import convolution
from h1_cover_convergence import mixture_energies
from h1_exception_cover import UNIT as COVER_UNIT, compact_weights, harmonic_rows, kernel_at
from h1_raw_rectangle_cover import CERT, FIT, FIBRES, MINORANTS, NAMES, NORM, PRICES, TABLE, UNIT, digest, geom, read, schedules
from h1_semiprime_budget import density
from h1_small_fragment_mass_bound import ceiling_sqrt, coordinate_factor, sci_upper
from h1_sunrise_boundary import geometry

BITS = 192
ONE = 1 << BITS
GROUP = 363


def ceil(x):
    return -((-x)//1)


def fixed(x):
    assert isinstance(x,(int,Q))
    return gmpy2.mpz(int(ceil(x*ONE)))


def multiply(a,b,size):
    return [(v+ONE-1)>>BITS for v in convolution(a,b,size)]


def partitions(n,s,minimum=1):
    if s==1:
        if n>=minimum:
            yield (n,)
        return
    for first in range(minimum,n//s+1):
        for rest in partitions(n-first,s-1,first):
            yield first,*rest


def basis_bound(coeffs, signatures, pattern, v, z, dust, radius, harmonic_scale, h,m):
    """Bound angular factors with the known number of marks at each occupied coordinate."""
    n,s=sum(pattern),len(pattern)
    needed=radius-dust
    lower=[max(Q(0),max(j*v,needed-(n-j)*z)/harmonic_scale-h/2) for j in pattern]
    # Upper bounds for every sorted prefix. Their consecutive differences
    # form a decreasing vector that weakly majorizes the frozen coordinates.
    counts=(*reversed(pattern),*([0]*(m-s)))
    prefix=[Q(0)]
    for k,q in enumerate(accumulate(counts),1):
        prefix.append(min(dust+q*z,radius-(n-q)*v)/harmonic_scale+k*h/2)
    major=[b-a for a,b in zip(prefix,prefix[1:])]
    assert all(x>=y>=0 for x,y in zip(major,major[1:]))
    mean=max(Q(0),needed/(s*harmonic_scale)-h/2)
    moments={p:(max(sum(x**p for x in lower),s*mean**p),sum(x**p for x in major))
             for p in {t for sig in signatures for t in sig}}
    low,high=Q(0),Q(0)
    for (a,b),sig in zip(coeffs,signatures):
        x,y=Q(1),Q(1)
        for p in sig:
            x*=moments[p][0]
            y*=moments[p][1]
        corners=(a*x,b*x,a*y,b*y)
        low+=min(corners)
        high+=max(corners)
    return max(abs(low),abs(high))


def trial_box(fibres,cert,block,radial_limit,fragment_limit):
    _,original,layout=geometry(TABLE)
    with np.load(original['cell_bins'],allow_pickle=False) as z:
        strata=np.unique(z['cells'][:,1]).astype(int)
    n=fibres['intervals']-fibres['dimension']
    ids=np.arange(n)
    assert cert['groups'][GROUP]==[198,403]
    group_owner=np.full(len(read(TABLE)['codes']),-1,int)
    for g,sector_ids in enumerate(cert['groups']):
        group_owner[sector_ids]=g
    by_cap={}
    last=np.full(len(cert['groups'])+1,-1,int)
    top=last.copy()
    for cap in sorted(set(strata)|set(fibres['caps'])):
        owner=group_owner[layout(strata[np.searchsorted(strata,cap)],ids)]
        np.maximum.at(last,owner,ids)
        np.maximum.at(top,np.unique(owner),cap)
        by_cap[cap]=owner
    last,top=last[:-1],top[:-1]
    assert np.all(last>=0)
    if block:
        selected=np.flatnonzero((last<=(radial_limit or last[GROUP]))&(top<=(fragment_limit or top[GROUP])))
        assert len(selected)>1
    else:
        assert radial_limit is None and fragment_limit is None
        selected=np.array([GROUP])
    nominal_step=Q(fibres['step'])*geom.RHO*UNIT
    radii=[int(ceil((int(last[g])+37)*nominal_step)) for g in selected]
    minimum_index=int((UNIT//2-max(radii))//nominal_step)-37+1
    pieces=[]
    for cap,owner in by_cap.items():
        r=ids[np.isin(owner,selected)&(ids>=minimum_index)]
        if len(r):
            pieces.append((cap,r))
    lo=min(int(r[0]) for cap,r in pieces)
    hi=max(int(r[-1]) for cap,r in pieces)
    # Cumulative amplitudes on exactly the radial indices and cap strata
    # represented by this group. Bound on the intervals before each cut.
    sigs=fibres['signatures']
    exact=np.vectorize(lambda x:Q(float(x)),otypes=[object])
    low=np.zeros((len(sigs),hi-lo+1),dtype=object)
    high=low.copy()
    inventory={}
    for row in reversed(fibres['layers']):
        path=Path(fibres['cache_directory'])/row['file']
        assert digest(path)==row['sha256']
        with np.load(path,allow_pickle=False) as archive:
            bounds=archive['bounds'][:,:,lo:hi+1]
        low+=exact(bounds[:,0]); high+=exact(bounds[:,1])
        inventory[row['cap']]=low.copy(),high.copy()
    coeffs=[]
    for cap,r in pieces:
        inc=next(c for c in fibres['caps'] if c>=cap)
        l,u=inventory[inc]
        coeffs.append(list(zip(l[:,r-lo].min(axis=1),u[:,r-lo].max(axis=1))))
    aggregate=[(min(row[j][0] for row in coeffs),max(row[j][1] for row in coeffs)) for j in range(len(sigs))]
    return lo,hi,max(c for c,r in pieces),aggregate,selected,radii


def residual_cdfs(m,nmax,size,eta,scale,h,Z):
    # Floor each residual into a positive coarse cell. Use its full width
    # and g at its smallest possible native midpoint. Drop its Dickman cap.
    base=eta/(scale*h*Z)
    smooth=[fixed(base*coordinate_factor(max(Q(0),i*eta/scale-h/2))**2) for i in range(size)]
    inv=fixed(base)
    memo={0:[gmpy2.mpz(ONE)],1:smooth}
    def power(n):
        if n not in memo:
            memo[n]=multiply(power(n//2),power(n-n//2),size)
        return memo[n]
    result={}
    for s in range(1,nmax+1):
        poly=power(m-s)
        for _ in range(s):
            # Every occupied coordinate contributes unweighted residual dt.
            poly=[(inv*v+ONE-1)>>BITS for v in accumulate(poly)]
        result[s]=[gmpy2.mpz(0),*accumulate(poly)]
    return result


def one_cut(v,w,need,R,radial_lo,cap,eta,h,scale,Z,coeffs,sigs,cdfs,m,requires_mark):
    """Mass upper bound at one possible witness interval (v,w], in ticks."""
    nmax=int(R//v)
    z=cap
    size=R//eta+1
    marks=[gmpy2.mpz(0)]*(z//eta+1)
    witness=[gmpy2.mpz(0)]*len(marks)
    for i in range(v//eta,z//eta+1):
        a=max(v,i*eta)
        b=min(z,(i+1)*eta)
        if b>a:
            marks[i]=fixed(Q(b-a,a))
            if w>a: witness[i]=fixed(Q(min(w,b)-a,a))
    if not any(marks): return Q(0)
    # n-fold marks are labelled here. The assignment factors below include
    # their Poisson factorial. Upper array indices are sums of rounded-down bins.
    poly=[gmpy2.mpz(ONE)]
    total=Q(0)
    min_marks=max(1,int(need//z)+1)
    for n in range(1,nmax+1):
        prev=poly
        poly=multiply(prev,marks,size)
        if n<min_marks: continue
        admitted=poly
        if requires_mark:
            tagged=multiply(prev,witness,size)
            admitted=[min(a,n*b) for a,b in zip(poly,tagged)]
        # Largest possible true sum for mark bin i is (i+n)*eta.
        start=max(n*(v//eta),int(need//eta)-n+1,0)
        for s in range(1,n+1):
            cdf=cdfs[s]
            integral=0
            for i in range(start,len(admitted)):
                if admitted[i]:
                    first=max(0,radial_lo//eta-i-n-m)
                    last=min(size-1,R//eta-i)
                    if first<=last:
                        integral+=admitted[i]*(cdf[last+1]-cdf[first])
            if not integral:continue
            assignment=Q(0)
            for pat in partitions(n,s):
                ways=comb(m,s)*factorial(s)
                for j in set(pat):
                    ways//=factorial(pat.count(j))
                factor=Q(ways)
                for j in pat:
                    factor*=coordinate_factor(max(Q(0),j*v/scale-h/2))**2/factorial(j)
                body=basis_bound(coeffs,sigs,pat,v,z,R-need,R,scale,h,m)
                assignment+=factor*body**2
            total+=Q(int(integral),ONE**2)*assignment
    return total


def bin_checks():
    # Enumerate labelled marks and individual residual bins, with no grouped
    # assignments or polynomial products. Compare the same relaxed upper
    # bin sum against the exact-convolution majorant in three coordinates.
    m,eta,v,w,z,R,radial_lo=3,1,4,6,8,11,6
    h,scale,Z=Q(1,32),Q(19),Q(9)
    size=R//eta+1
    cdfs=residual_cdfs(m,R//v,size,eta,scale,h,Z)
    checks=0
    for need in (Q(5),Q(13,2)):
        for tag in (False,True):
            upper=one_cut(v,w,need,R,radial_lo,z,eta,h,scale,Z,[(Q(1),Q(1))],[()],cdfs,m,tag)
            direct=Q(0)
            for n in range(1,R//v+1):
                if n*z<=need:continue
                for marks in product(range(v,z),repeat=n):
                    i=sum(marks)
                    if i+n<=need or (tag and all(j>=w for j in marks)):continue
                    for labels in product(range(m),repeat=n):
                        weight=Q(1,factorial(n))
                        for j in marks: weight/=j
                        for coord in set(labels):
                            weight*=coordinate_factor(max(Q(0),labels.count(coord)*v/scale-h/2))**2
                        for residual in product(range(R-i+1),repeat=m):
                            if not radial_lo-i-n-m<=sum(residual)<=R-i:continue
                            term=weight*(1/(scale*h*Z))**m
                            for coord,j in enumerate(residual):
                                if coord not in labels:term*=coordinate_factor(max(Q(0),j/scale-h/2))**2
                            direct+=term
            assert 0<direct<=upper
            if not tag:
                assert upper-direct < Q(1,10**38)
            checks+=1
    return checks


def angular_checks():
    sigs=((),(2,),(3,),(2,2))
    coeffs=[(Q(-1),Q(2)),(Q(1),Q(3)),(Q(-4),Q(-2)),(Q(-2),Q(1))]
    bounds={}
    count=0
    m,scale,h=3,Q(7,2),Q(1,4)
    for n in (2,3):
        for labels in product(range(m),repeat=n):
            pat=tuple(sorted(labels.count(i) for i in set(labels)))
            if pat not in bounds:
                bounds[pat]=basis_bound(coeffs,sigs,pat,2,4,Q(13,2),12,scale,h,m)
            for marks in product((Q(5,2),Q(7,2)),repeat=n):
                if sum(marks)<=Q(11,2): continue
                for dust in ((0,0,Q(1,2)),(Q(3,2),Q(1,2),0),(0,Q(1,2),Q(3,2))):
                    totals=[dust[i]+sum(v for v,j in zip(marks,labels) if j==i) for i in range(m)]
                    if sum(totals)>12:continue
                    points=[(int(v//(scale*h))+Q(1,2))*h for v in totals]
                    p2,p3=[sum(x**p for x in points) for p in (2,3)]
                    basis=(1,p2,p3,p2*p2)
                    for side in (0,1):
                        assert abs(sum(c[side]*b for c,b in zip(coeffs,basis)))<=bounds[pat]
                    count+=1
    return count


def charge(cert,table,prices,norm,R,tail,heavy,selected,radii):
    forms=Path('h1_cover_native_mixed.json')
    frozen=Path('h1_cover_72_semiprime_mixed_fit.json')
    old_cover=Path('h1_exception_cover_72.json')
    for p in (forms,forms.with_suffix('.npz'),frozen,old_cover,MINORANTS):
        assert prices['inputs'][p.name]==digest(p)
    frozen_masses=mixture_energies(forms,frozen)
    reference=np.array([sum(frozen_masses[cert['groups'][g],0]) for g in selected],dtype=object)
    assert min(reference)>0
    q=Q(R,UNIT)
    U=1/(Q(1,2)-q-Q('.0001'))
    book=read(MINORANTS)
    source=next(row for row in book['rows'] if Q(row['theta'])==Q('.5291'))
    cover=read(old_cover)
    assert cover['source_sha256']==digest(MINORANTS) and cover['weight_scale']==COVER_UNIT
    rows=harmonic_rows('old',Q(source['a']),Q(source['zeta']),cover['bins'])
    w=np.asarray(cover['covers']['old']['weights'],np.int64)
    assert min(w)>=0 and min(w[rows[-1]].sum(axis=1))>=24*COVER_UNIT
    K=kernel_at(compact_weights(rows,w),q)
    kappa=Q('.000093307088324062')
    assert Q(str(table['kappa_upper']))==kappa
    exceptional_mean=Q(source['five_mass']['upper'])+Q(cert['arithmetic']['three_error_mass'][1])
    rough=1-2*Q(source['a'])
    other=24/(min(rough,Q(1,2)-q)-Q('.0001'))
    cuts=list(map(Q,cert['cuts']))
    top_mean=density(cuts[-2],cuts[-1])[1]
    # On M x M the individual positive forms P,B,A+D,C_top are evaluated.
    # Thus the cross terms use their own means on M and upper budgets on H.
    # The tiny negative middle-strip multiplier can use its unconditional
    # positive upper form on the entire group. Its true mean is nonnegative.
    # Lemma 2.1 gives total energy <= rho*S*k*log(k)/(k-1), with log(38)<4.
    assert sum(Q(4)**j/factorial(j) for j in range(7))>38
    erasure=geom.RS*Q(norm['S'])*38*4/37
    if len(selected)>1:
        return block_charge(cert,prices,selected,radii,reference,U,K,other,kappa,
                            exceptional_mean,top_mean,erasure,tail,heavy)
    e0=reference[0]
    L,sharp,higher,low,middle,top=[Q(a[GROUP][GROUP],prices['scale']) for a in cert['affine']]
    prime=L+sharp+higher
    exception=sharp+higher
    assert prime>0 and exception>0 and higher>0 and top>0 and middle<0 and low==0
    cross=2*ceiling_sqrt(tail*heavy)*(prime*ceiling_sqrt(U)+exception*ceiling_sqrt(kappa*K)
          +higher*ceiling_sqrt(exceptional_mean*other)+top*ceiling_sqrt(top_mean*U))
    diagonal=heavy*(prime+top*top_mean+exception*K+higher*other)
    middle_loss=abs(middle)*U*erasure
    bound=(cross+diagonal+middle_loss)/e0
    return dict(reference_energy=str(e0),prime_upper=str(U),old_exception_upper=str(K),
                other_exception_upper=str(other),combined_prime_multiplier=str(prime),
                mixed_charge_upper=sci_upper(cross/e0),heavy_diagonal_charge_upper=sci_upper(diagonal/e0),
                middle_strip_charge_upper=sci_upper(middle_loss/e0),six_channel_charge_upper=sci_upper(bound))


def block_charge(cert,prices,selected,radii,reference,U,K,other,kappa,ex_mean,top_mean,erasure,tail,heavy):
    from h1_sunrise_refined import positive_definite
    radii=np.asarray(radii)
    risk=(radii[:,None]+radii[None,:]>UNIT//2)
    L,R,S,X,Y,V=[np.asarray(A,dtype=object)[np.ix_(selected,selected)]*risk*Q(1,prices['scale'])
                 for A in cert['affine']]
    # If E is the diagonal matrix of frozen masses, -kE < A < kE proves
    # the signed spectral bound after congruence by E^(-1/2).
    def op(A):
        scale=np.sqrt(reference.astype(float))
        estimate=np.max(abs(np.linalg.eigvalsh(A.astype(float)/np.outer(scale,scale))))
        if not np.any(A):return Q(0)
        k=Q(int(np.ceil(estimate*10**12))+1,10**12)
        diagonal=np.diag(reference*k)
        assert positive_definite(diagonal+A) and positive_definite(diagonal-A)
        return k
    terms=(('prime',L+R+S,U,Q(1)),('old_exception',-R-S,K,kappa),
           ('other_exceptions',-S,other,ex_mean),('top_semiprime',V,U,top_mean))
    evaluated=Q(0)
    details=[]
    for name,A,cap,mean in terms:
        k=op(A)
        row=k*(2*ceiling_sqrt(tail*heavy*cap*mean)+(cap+mean)*heavy)
        evaluated+=row
        details.append(dict(component=name,signed_multiplier_norm_upper=str(k),charge_upper=sci_upper(row)))
    # The two small strip terms use P+C1+C2+C3 <= U I, and each of
    # their means lies between zero and one on the specified interval.
    cuts=list(map(Q,cert['cuts']))
    means=[density(a,b)[1] for a,b in zip(cuts,cuts[1:])]
    assert max(means)<1
    # Keep the three charges on the true positive forms separate from
    # their known harmonic diagonals. A common U controls C1+C2.
    # Taking the maximum spectral norm suffices for the two trace terms
    # since their positive traces sum to at most U times the root energy.
    kx,ky=op(X),op(Y)
    diagcap=max(abs(np.diag(X))*means[0]/reference+abs(np.diag(Y))*means[1]/reference)
    coefficient=max(kx,ky)*U+diagcap
    small=coefficient*erasure
    return dict(selected_groups=[int(x) for x in selected],above_half_ordered_pairs=int(risk.sum()),
                above_half_active_by_channel=[int(np.count_nonzero(A)) for A in (L,R,S,X,Y,V)],
                components=details,small_strip_norms=list(map(str,(kx,ky))),
                small_strip_charge_per_unit_risky_group_energy=str(coefficient),
                risky_groups=[int(i) for i in selected[risk.any(axis=1)]],total_erasure_upper=str(erasure),
                evaluated_channels_charge_upper=sci_upper(evaluated),small_strips_charge_upper=sci_upper(small),
                six_channel_charge_upper=sci_upper(evaluated+small))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--bin-ticks',type=int,default=1000)
    parser.add_argument('--witness-ticks',type=int,default=20000)
    parser.add_argument('--block',action='store_true')
    parser.add_argument('--radial-index-limit',type=int)
    parser.add_argument('--fragment-index-limit',type=int)
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    eta=args.bin_ticks
    assert eta>0 and args.witness_ticks>0
    norm,fibres,cert,table,prices,fit=map(read,(NORM,FIBRES,CERT,TABLE,PRICES,FIT))
    cover_path=Path('h1_raw_rectangle_cover.json')
    cover=read(cover_path)
    for path in (NORM,FIBRES,CERT,TABLE,PRICES,FIT):
        assert cover['inputs'][path.name]==digest(path)
    assert norm['status']=='ORDINARY_NORM_ENCLOSED' and fibres['status']=='ERASED_AMPLITUDES_ENCLOSED'
    h=Q(norm['step'])
    scale=geom.RHO*UNIT
    Z=Q(norm['coordinate_Z']['lower'])
    D=Q(norm['normalized_norm']['lower'])
    pref=geom.RS*38*h/(Z*D)
    m=37
    lo,hi,cap,coeffs,selected,radii=trial_box(fibres,cert,args.block,args.radial_index_limit,args.fragment_index_limit)
    R=int(ceil((hi+m)*h*scale))
    radial_lo=int(lo*h*scale)
    cap=int(ceil(cap*h*scale))
    specs=[]
    all_rows=schedules(table,cert)
    for channel in (0,1,2,5):
        rows=[(int(B),int(top),int(d)) for B,top,d,_,_ in all_rows[channel] if B<2*R]
        assert rows[-1][1]>=2*R and min(row[2] for row in rows)>0
        specs.append((min(d for B,top,d in rows),min(B+d for B,top,d in rows)))
    delta=min(a for a,b in specs)
    budget=min(b for a,b in specs)
    rank=R//cap
    breakpoint=int(ceil(Q(R,rank+1)))
    # The opposite root is represented by its two-atom tail envelope.
    # Split at that discontinuity and at the top of the current root cap.
    targets=[]
    for start,stop,opposite in ((delta,breakpoint,R),(max(delta,breakpoint),cap,rank*cap)):
        if start>=stop:continue
        for v in range(start,stop,args.witness_ticks):
            w=min(stop,v+args.witness_ticks)
            need=budget-opposite-w
            if need>=R or (v>=breakpoint and need>=rank*cap):continue
            assert 0<need<R
            targets.append((v,w,need,w not in (breakpoint,cap)))
    size=R//eta+1
    cdfs=residual_cdfs(m,R//delta,size,eta,scale,h,Z)
    tail=Q(0)
    records=[]
    heavy=Q(0)
    for v,w,need,marked in targets:
        arguments=(R,radial_lo,cap,eta,h,scale,Z,coeffs,fibres['signatures'],cdfs,m)
        value=pref*one_cut(v,w,need,*arguments,marked)
        # The symmetric half-budget only needs checking at true root marks.
        half_need=Q(budget-w,2)
        half_value=pref*one_cut(v,w,half_need,*arguments,True)
        tail+=value
        heavy+=half_value
        records.append(dict(from_ticks=v,to_ticks=w,required_large_total_over=need,
                            energy_upper=sci_upper(value) if value else '0',
                            half_budget_energy_upper=sci_upper(half_value) if half_value else '0'))
    heavy=min(tail,heavy)
    cost=charge(cert,table,prices,norm,R,tail,heavy,selected,radii)
    out=dict(scope='Complete six-channel upper allowance on the specified group block under the stated arithmetic inputs.',
             inputs={p.name:digest(p) for p in (Path(__file__),cover_path,NORM,FIBRES,CERT,TABLE,PRICES,FIT,
                                          MINORANTS,Path('h1_cover_native_mixed.json'),Path('h1_cover_native_mixed.npz'),
                                          Path('h1_cover_72_semiprime_mixed_fit.json'),Path('h1_exception_cover_72.json'),
                                          Path('h1_small_fragment_mass_bound.py'),Path('h1_exact_convolution.py'),
                                          Path('h1_exception_cover.py'),Path('h1_semiprime_budget.py'),
                                          Path('h1_bilinear_pricing.py'),Path('prime_gaps_182_full.txt'))},
             anchor_group=GROUP,block=args.block,radial_index_limits=[lo,hi],nominal_root_ticks=[radial_lo,R],
             nominal_fragment_ceiling=cap,partner_rank_break=breakpoint,
             order=1,common_activation_ticks=delta,common_budget_ticks=budget,
             integral_bin_ticks=eta,witness_bin_ticks=args.witness_ticks,
             fixed_bits=BITS,rectangles=records,failure_energy_upper=sci_upper(tail),
             half_budget_failure_energy_upper=sci_upper(heavy),charge=cost,
             requested_index_limits=[args.radial_index_limit,args.fragment_index_limit],
             order_one_channels=[NAMES[j] for j in (0,1,2,5)],small_direct_bin_checks=bin_checks(),
             exact_angular_checks=angular_checks())
    if args.check: assert out==read(args.output)
    else: args.output.write_text(json.dumps(out,indent=2)+'\n',newline='\n')
    print('bad-root upper',float(tail),'heavy upper',float(heavy),'six-channel charge',cost['six_channel_charge_upper'],flush=True)


if __name__=='__main__':
    main()
