"""Restore a rectangle with both sides beyond the ordinary self-pairing radius."""
import argparse
from fractions import Fraction as Q
import json
from pathlib import Path

import numpy as np

from h1_graded_coverage import monotone_trace, provenance
from h1_graded_cross_block import coefficients, max_grade, native_layout, signed_norms, tails
from h1_raw_diagonal_bound import (CERT, FIBRES, FIT, MINORANTS, NORM, PRICES, TABLE, UNIT,
    ceil, ceiling_sqrt, compact_weights, digest, geom, harmonic_rows, kernel_at, read, schedules, sci_upper)

BASE = Path('h1_graded_fine_coverage.json')
REDUCED = Path('h1_strip_free_prices.json')


def source_threshold(rows, radius_sum):
    used = rows[rows[:, 0] < radius_sum]
    assert len(used) and used[-1, 1] >= radius_sum and min(used[:, 2]) > 0
    return int(min(used[:, 2])), int(min(used[:, 0] + used[:, 2]))


def operator_caps(radius, data, cover):
    old = harmonic_rows('old', Q(data['a']), Q(data['zeta']), cover['bins'])
    weights = np.asarray(cover['covers']['old']['weights'], np.int64)
    assert cover['weight_scale']==10**9 and min(weights)>=0 and min(weights[old[-1]].sum(axis=1))>=24*10**9
    q = Q(radius, UNIT)
    return [1/(Q(1,2)-q-Q('.0001')), kernel_at(compact_weights(old, weights), q),
            24/(min(1-2*Q(data['a']),Q(1,2)-q)-Q('.0001'))]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--left-radius', type=int, required=True)
    parser.add_argument('--right-radius', type=int, required=True)
    parser.add_argument('--left-above', type=int, default=UNIT//4)
    parser.add_argument('--right-above', type=int, default=UNIT//4)
    parser.add_argument('--fragment', type=int, default=47317)
    parser.add_argument('--integral-step', type=int, default=500)
    parser.add_argument('--witness-step', type=int, default=10000)
    parser.add_argument('--grade-step', type=int, default=40000)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    base, cert, fibres, norm, prices = map(read, (BASE, CERT, FIBRES, NORM, PRICES))
    provenance(base, Path.cwd())
    assert read(REDUCED)['retained_affine_channels'] == [0,1,2]
    assert prices['inputs'][CERT.name] == digest(CERT)
    assert norm['status']=='ORDINARY_NORM_ENCLOSED' and fibres['status']=='ERASED_AMPLITUDES_ENCLOSED'
    for doc in (fibres, norm):
        for source in (FIT, TABLE):
            assert doc['inputs'][source.name] == digest(source)
    ix, last, z, bycap = native_layout(fibres, cert)
    h = Q(norm['step'])
    scale = geom.RHO*UNIT
    tick = h*scale
    rs = np.array([int(ceil((int(j)+37)*tick)) for j in last])
    prior = read(Path(base['blocks'][0]['receipt']))['selected_groups']
    inside = np.isin(np.arange(len(rs)), prior)
    outer = (2*rs > UNIT//2) & (z <= args.fragment)
    left = np.flatnonzero(outer & inside & (args.left_above < rs) & (rs <= args.left_radius))
    right = np.flatnonzero(outer & ~inside & (args.right_above < rs) & (rs <= args.right_radius))
    risk = rs[left, None] + rs[None, right] > UNIT//2
    assert len(left) and len(right) and risk.all()
    for rec in base['blocks'][1:]:
        old = read(Path(rec['receipt']))
        assert all(2*rs[i] <= UNIT//2 for i in old['left_groups'])
    A, B = int(max(rs[left])), int(max(rs[right]))
    assert A <= B
    rows = schedules(read(TABLE), cert)[:3]
    common = [source_threshold(row,A+B) for row in rows]
    self_left = [source_threshold(row,2*A) for row in rows]
    delta, W = map(min, zip(*common))
    assert all(d>=delta for d,_ in self_left)
    Wleft = min(w for _,w in self_left)
    ca, la, za = coefficients(fibres,bycap,ix,left,B,tick)
    cb, lb, zb = coefficients(fibres,bycap,ix,right,A,tick)
    va, vb = max_grade(A,za), max_grade(B,zb)
    start = 2*W-vb
    assert max(za,zb) < min(start, 2*W-va) and start < Wleft < va
    breaks = sorted({*range(start,va,args.grade_step), Wleft, va})
    Z, D = Q(norm['coordinate_Z']['lower']), Q(norm['normalized_norm']['lower'])
    shared = (h,scale,Z,D,args.integral_step,args.witness_step,fibres['signatures'],
              geom.RS*Q(norm['S'])*38*Q('3.638')/37)
    left_tail, nleft = tails(breaks[:-1],delta,A,la,za,ca,*shared)
    right_tail, nright = tails([2*W-t for t in breaks[1:]],delta,B,lb,zb,cb,*shared)
    ops, active = signed_norms(cert,prices,left,right,risk)
    cover_path = Path('h1_exception_cover_72.json')
    cover = read(cover_path)
    assert prices['inputs'][cover_path.name]==digest(cover_path) and cover['source_sha256']==digest(MINORANTS)
    data = next(r for r in read(MINORANTS)['rows'] if Q(r['theta'])==Q('.5291'))
    caps_a, caps_b = [operator_caps(r,data,cover) for r in (A,B)]
    means = [Q(1),Q(str(read(TABLE)['kappa_upper'])),
             Q(data['five_mass']['upper'])+Q(cert['arithmetic']['three_error_mass'][1])]
    charges = []
    cut = breaks.index(Wleft)
    first = [left_tail[t] for t in breaks[:-1]]
    second = [right_tail[2*W-t] for t in breaks[1:]]
    for k, mu, ca, cb in zip(ops,means,caps_a,caps_b):
        # The complementary right tail has operator bound cb on every bin.
        # On the left a bin ending at or below Wleft has its exact self trace.
        weighted = [cb*(mu if j<cut else ca)*v for j,v in enumerate(second)]
        charges.append(2*k*monotone_trace(first,weighted))
    paths = [Path(__file__),BASE,REDUCED,CERT,FIBRES,FIT,NORM,PRICES,TABLE,MINORANTS,cover_path,
             Path('h1_graded_cross_block.py'),Path('h1_graded_coverage.py'),Path('h1_graded_raw_block.py')]
    show = lambda v: sci_upper(v) if v else '0'
    result = dict(scope='Three retained source identities on both orientations of the specified disjoint outer rectangle for the original 21-coefficient trial. Includes every raw divisor.',
                  inputs={p.name:digest(p) for p in paths}, left_groups=left.tolist(),right_groups=right.tolist(),
                  radius_limits=[args.left_radius,args.right_radius],strict_radius_floors=[args.left_above,args.right_above],
                  fragment_limit=args.fragment,
                  actual_radius_ticks=[A,B],actual_fragment_ticks=[za,zb],active_entries=active,
                  ordered_pairs=2*int(risk.sum()),common_activation=delta,cross_budget=W,left_self_budget=Wleft,
                  integral_step=args.integral_step,witness_step=args.witness_step,grade_step=args.grade_step,
                  grade_breaks=breaks,witness_intervals=[nleft,nright],left_tails={k:show(v) for k,v in left_tail.items()},
                  right_tails={k:show(v) for k,v in right_tail.items()}, operator_norms=list(map(str,ops)),
                  left_caps=list(map(str,caps_a)),right_caps=list(map(str,caps_b)),means=list(map(str,means)),
                  component_charge_uppers=list(map(show,charges)),charge_upper=show(sum(charges)))
    result = json.loads(json.dumps(result))
    if args.check:
        assert result == read(args.output)
    else:
        args.output.write_text(json.dumps(result,indent=2)+'\n',newline='\n')
    print('outer cross',len(left),len(right),'ordered',result['ordered_pairs'],
          'three-term upper',result['charge_upper'],flush=True)


if __name__=='__main__':
    main()
