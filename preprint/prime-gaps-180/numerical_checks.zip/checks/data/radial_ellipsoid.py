"""An interval upper for the maximum square of radial Bernstein controls."""
from argparse import ArgumentParser
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
from time import sleep

from flint import arb, arb_mat, ctx
import numpy as np

import projected_fourier as F
from legacy_gram import EXTRA, corrected_baseline, enlarged


def input_matrix(a):
    return arb_mat([[F.ball(v) for v in row] for row in a])


def sym_root(a):
    values,vectors=np.linalg.eigh((a+a.T)/2)
    return (vectors*np.sqrt(np.maximum(0,values)))@vectors.T


def propose(h):
    """Fit a correlation matrix; its provenance plays no role in the certificate."""
    scale=np.max(np.abs(h))
    n=len(h)
    if not scale>0:return np.eye(n)
    v,w=np.linalg.eigh((h+h.T)/(2*scale))
    psd=(w*np.maximum(1e-13,v))@w.T
    lam=np.maximum(np.diag(psd),1e-6)
    for _ in range(80):
        d=np.sqrt(lam)
        r=sym_root(d[:,None]*psd*d)
        updated=np.maximum(np.diag(r),1e-13)
        if np.max(abs(updated-lam))<1e-11*(1+np.max(lam)):break
        lam=updated
    inv=1/np.sqrt(np.maximum(np.diag(r),1e-16))
    return r*inv[:,None]*inv


def certified_inverse(proposal,mix):
    """Dyadic unit diagonal, with positive definiteness checked by congruence."""
    n=len(proposal)
    k=(1-mix)*proposal+mix*np.eye(n)
    k=np.rint((k+k.T)*2**30)*2**-31
    np.fill_diagonal(k,1.)
    assert np.array_equal(k,k.T)
    candidate=input_matrix(k)
    pre=input_matrix(np.linalg.inv(np.linalg.cholesky(k)))
    congruence=pre*candidate*pre.transpose()
    for i in range(n):
        assert congruence[i,i]>sum((abs(congruence[i,j]) for j in range(n) if j!=i),arb(0))
    return candidate.inv()


def certificate(center,radius,lo,hi,suffix):
    """Enclose tr(K^{-1} C G Cᵀ), combining all identical angular moments first."""
    P=F.P
    cols=len(P.SIGS)
    rows=list(dict.fromkeys(tuple(block[i,s][a] for i in range(9) for s in range(cols))
                            for _,block in P.radial_blocks(lo,hi,suffix) for a in range(4)))
    b=input_matrix(rows)
    ids=(P.SIG_INDEX[None,:,None,:]*len(P.PAIR)+P.END_INDEX[:,None,:,None]).reshape(99,99)
    assert np.array_equal(ids,ids.T)
    cb=np.asarray(rows,dtype=float)
    fitted=propose(cb@center.ravel()[ids]@cb.T)
    moments=[arb(float(x),float(e)) for x,e in zip(center.ravel(),radius.ravel())]
    out=[]
    for mix in (2.**-7,2.**-17,2.**-24):
        inverse=certified_inverse(fitted,mix)
        q=b.transpose()*inverse*b
        weights=[arb(0) for _ in moments]
        for i in range(99):
            weights[ids[i,i]]+=q[i,i]
            for j in range(i):weights[ids[i,j]]+=2*q[i,j]
        envelope=sum((x*w for x,w in zip(moments,weights)),arb(0)).upper()
        assert envelope>=0
        out.append(F.upper_float(envelope))
    return min(out)


def replay(path,receipt):
    doc=json.loads(receipt.read_text())
    result=doc['result']
    assert doc['status']=='enclosed'
    with np.load(path) as cache:
        assert str(cache['pin'])==doc['pin'] and float(cache['baseline'])==result['outward_scaled_upper']
        rows=[]
        originals=[]
        for name in cache.files:
            if name in ('pin','baseline'):continue
            lo,hi,suffix=map(int,name.split('_'))
            center,radius=cache[name]
            originals.append(F.directed_gram(center,radius,lo,hi,suffix))
            radius=enlarged(radius)
            old=F.directed_gram(center,radius,lo,hi,suffix)
            new=certificate(center,radius,lo,hi,suffix)
            rows.append(dict(lo=lo,hi=hi,suffix=suffix,center_bound=old,ellipsoid_bound=new))
    capture=F.ball(Fraction(result['minimum_capture']))
    total=F.upper_float(sum((F.ball(min(r['center_bound'],r['ellipsoid_bound'])) for r in rows),arb(0))/capture)
    old=F.upper_float(sum((F.ball(r['center_bound']) for r in rows),arb(0))/capture)
    original=F.upper_float(sum((F.ball(v) for v in originals),arb(0))/capture)
    assert abs(original-result['outward_scaled_upper'])<=abs(original)*1e-13
    ref=dict(pin=doc['pin'],cap=doc['cap'],edge=doc['edge'],baseline=old,ellipsoid_upper=total,rows=rows,
             extra_gram_radius=EXTRA,old_upper_before_magnitude_correction=original)
    return add_panel_charges(ref,result)


def add_panel_charges(ref,result):
    ref['minimum_capture']=result['minimum_capture']
    capture=F.ball(Fraction(ref['minimum_capture']))
    for row in ref['rows']:
        best=min(row['center_bound'],row['ellipsoid_bound'])
        row['scaled_upper_after_capture']=F.upper_float(F.ball(best)/capture)
    return ref


def replay_directory(caches,receipts,out,follow):
    from projected_fourier_sweep import save
    manifest=json.loads((receipts/'manifest.json').read_text())
    out.mkdir(parents=True,exist_ok=True)
    while True:
        pending=0
        for cap,edge in manifest['pairs']:
            label=f'{cap}_{edge}'
            receipt=receipts/(label+'.json')
            cache=caches/(label+'.npz')
            target=out/(label+'.json')
            if not receipt.exists():pending+=1;continue
            if not cache.exists():continue
            if target.exists():
                ref=json.loads(target.read_text())
                assert ref['pin']==manifest['pin']
                if ref.get('extra_gram_radius')==EXTRA:continue
            refined=replay(cache,receipt)
            assert refined['pin']==manifest['pin']
            save(target,refined)
            print('bounded',cap,edge,refined['baseline'],refined['ellipsoid_upper'],flush=True)
        if not follow or not pending:return
        sleep(15)


def aggregate(receipts,refinements,complete=True,ordinary_floor='46.1984860121'):
    """Collect disjoint maximum classes and union bounds over successive gate groups."""
    manifest=json.loads((receipts/'manifest.json').read_text())
    groups=[]
    missing=[]
    for cap,edge in manifest['pairs']:
        name=f'{cap}_{edge}.json'
        if not (receipts/name).exists():missing.append([cap,edge]);continue
        doc=json.loads((receipts/name).read_text())
        assert (doc['pin'],doc['cap'],doc['edge'])==(manifest['pin'],cap,edge)
        r=corrected_baseline(doc['result'])
        bound=r['outward_scaled_upper']
        rows=[]
        mode=doc['status']
        ref=json.loads((refinements/name).read_text()) if (refinements/name).exists() else {}
        if ref.get('extra_gram_radius')==EXTRA:
            assert ref['pin']==doc['pin'] and mode=='enclosed' and ref['minimum_capture']==r['minimum_capture']
            bound=min(bound,ref['ellipsoid_upper'])
            mode='ellipsoid and baseline'
            rows=[[x['lo'],x['hi'],x['scaled_upper_after_capture']] for x in ref['rows']]
        elif mode=='enclosed':
            width=r['site_radial']; back=width*r['independent_round_radius']; count=manifest['record']['parameters']['count']
            extra=back if back else 39*(width-1)
            first,last=r['radial_output_bins']; capture=F.ball(Fraction(r['minimum_capture']))
            panel_start=range(first,last+1,count)
            assert len(panel_start)==len(r['panel_bounds_before_capture'])
            for j,value in zip(panel_start,r['panel_bounds_before_capture']):
                if value==0:continue
                lo=max(r['possible_J'][0],j*width-back)
                hi=min(r['possible_J'][1],min(last,j+count-1)*width+extra)
                rows.append([lo,hi,F.upper_float(F.ball(value)/capture)])
        else:assert mode=='impossible' and bound==0
        groups.append(dict(cap=cap,edge=edge,mode=mode,upper=bound,baseline=r['outward_scaled_upper'],panels=rows))
    if complete and missing:raise ValueError(f'{len(missing)} gate classes are still pending.')
    raw=sum((Fraction(float(x['upper'])) for x in groups),Fraction(0))
    den=Fraction(ordinary_floor)
    assert den>0
    proof=Path(__file__).with_name('legacy_gram.py')
    return dict(source_pin=manifest['pin'],extra_gram_radius=EXTRA,legacy_correction_code_sha256=sha256(proof.read_bytes()).hexdigest(),
                ellipsoid_code_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
                units='Native site masses scaled by 100^39. Panels are [lowest possible native J, highest possible native J, outward scaled upper after rounding capture].',
                cases=len(groups),missing=missing,ordinary_mass_floor=str(den),scaled_upper=F.upper_float(F.ball(raw)),
                fraction_upper=F.upper_float(F.ball(raw/den)),groups=groups)


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('cache',type=Path)
    p.add_argument('receipt',type=Path)
    p.add_argument('--output',type=Path)
    p.add_argument('--follow',action='store_true')
    p.add_argument('--aggregate',action='store_true',help='Use receipt and refinement directories as positional inputs.')
    p.add_argument('--partial',action='store_true',help='Allow partial status when aggregating.')
    p.add_argument('--ordinary-floor',default='46.1984860121',help='Separately proved scaled ordinary mass lower bound.')
    args=p.parse_args();ctx.prec=160
    if args.aggregate:
        result=aggregate(args.cache,args.receipt,not args.partial,args.ordinary_floor)
        if args.output:args.output.write_text(json.dumps(result,separators=(',',':'))+'\n')
        print(json.dumps({k:v for k,v in result.items() if k not in ('groups','missing')}))
    elif args.cache.is_dir():
        assert args.receipt.is_dir() and args.output
        replay_directory(args.cache,args.receipt,args.output,args.follow)
    else:
        result=replay(args.cache,args.receipt)
        data=json.dumps(result,indent=2)+'\n'
        if args.output:args.output.write_text(data)
        print(data,end='')
