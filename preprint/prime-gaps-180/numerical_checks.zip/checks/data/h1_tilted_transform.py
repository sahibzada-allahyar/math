"""Certified positive angular moments by a damped ball-arithmetic DFT on the native radial grid."""
from fractions import Fraction as Q
from functools import lru_cache
from itertools import product

import numpy as np
from flint import acb,arb,ctx

from h1_combined_mass_interval import P
from h1_dickman_taylor import rat


def powers_of_two(n,bits):
    # The radial tilt has exact N-th power 2^-bits.
    damping=(-arb(bits)*arb(2).log()/n).exp()
    values=[arb(1)]
    for _ in range(1,n):values.append(values[-1]*damping)
    return values


class TiltedMoments:
    def __init__(self,weights,midpoints,signatures,count,S,damping,bits):
        self.length=len(weights);self.n=len(damping);self.count=count;self.S=Q(S);self.bits=bits
        assert self.n>=self.length and self.n&(self.n-1)==0 and self.length==len(midpoints)
        assert min(x.lower() for x in weights)>0
        assert all(t.lower()>=0 and t.upper()<=rat(self.S) for t in midpoints)
        self.mass_factor=(sum((w.upper() for w in weights),arb(0))**count).upper()
        half=self.n//2+1
        self.inverse=[1/x for x in damping[:self.length]]
        self.terms={sig:P.moment_terms(count,sig) for sig in signatures}
        exponents={0,*[x for terms in self.terms.values() for p,m in terms for x in p]}
        delta=arb(2)**-80
        self.inflation=np.nextafter(float(((1+delta)**count).upper()),np.inf)
        self.transforms={}
        for k in sorted(exponents):
            full=[w*t**k if k else w for w,t in zip(weights,midpoints)]
            low=[x.lower() for x in full]
            assert all(x.upper()<=(1+delta)*a for x,a in zip(full,low))
            transform=acb.dft([a*b for a,b in zip(low,damping)]+[arb(0)]*(self.n-self.length))
            self.transforms[k]=np.asarray(transform[:half],dtype=object)
        depth=max(len(p) for terms in self.terms.values() for p,m in terms)
        self.zeros={count-depth:self.transforms[0]**(count-depth)}
        for k in range(count-depth+1,count+1):
            self.zeros[k]=self.zeros[k-1]*self.transforms[0]

    @lru_cache(maxsize=10)
    def angular(self,p):
        if len(p)==1:return self.transforms[p[0]]
        return self.angular(p[:-1])*self.transforms[p[-1]]

    @lru_cache(maxsize=8)
    def product(self,p):
        base=self.zeros[self.count-len(p)]
        return base*self.angular(p) if p else base

    def moment(self,sig):
        f=None
        for pattern,multiplicity in self.terms[sig]:
            a=self.product(tuple(pattern))
            term=a if multiplicity==1 else a*int(multiplicity)
            f=term if f is None else f+term
        values=f.tolist()
        spectrum=values+[v.conjugate() for v in reversed(values[1:-1])] if self.n>1 else values
        r=acb.dft(spectrum,inverse=True)
        assert all(x.imag.contains(0) for x in r[:self.length])
        low,high=P.float_interval([v.real*t for v,t in zip(r,self.inverse)])
        # Every wrap is nonnegative. The sum of the unweighted coefficients
        # is bounded by count^len(sig) S^sum(sig) when the coordinate mass <=1.
        alias=self.mass_factor*rat(Q(self.count**len(sig))*self.S**sum(sig)/2**self.bits)
        error=np.nextafter(float(alias.upper()),np.inf)
        lower=np.maximum(0,np.nextafter(low-error,-np.inf))
        upper=np.maximum(0,np.nextafter(high*self.inflation,np.inf))
        assert np.isfinite(upper).all() and np.all(lower<=upper)
        return lower,upper

    def clear(self):
        self.angular.cache_clear();self.product.cache_clear()


def self_check():
    ctx.prec=384
    q=[Q(2,10),Q(3,10),Q(1,10),Q(4,10)]
    t=[Q(i+1,5) for i in range(4)]
    sigs=[(),(2,),(2,2),(2,3),(2,2,2)]
    n=4;count=4
    checks=0
    for bits in (6,64):
        z=TiltedMoments(list(map(rat,q)),list(map(rat,t)),sigs,count,1,powers_of_two(n,bits),bits)
        for sig in sigs:
            low,high=z.moment(sig)
            exact=[Q(0)]*n
            for ids in product(range(n),repeat=count):
                if sum(ids)>=n:continue
                w=Q(1)
                for j in ids:w*=q[j]
                for p in sig:w*=sum(t[j]**p for j in ids)
                exact[sum(ids)]+=w
            assert all(Q(float(a))<=v<=Q(float(b)) for a,v,b in zip(low,exact,high))
            checks+=n
        z.clear()
    return checks
