"""Replay the fixed labelled degree-six trial with scalar signed erasures."""
import argparse
import contextlib
from collections import defaultdict
from fractions import Fraction as Q
from functools import lru_cache
from hashlib import sha256
import io
import json
from pathlib import Path
import resource
import time

import numpy as np
from scipy.fft import rfft, irfft

import h1_two_source_endpoints as TS
from fast_fragment_ritz import fiber_splits
from h1_182_source_pair_cost import bound_moment_storage
from h1_degree6_older_triangle import VECTOR, model, scalar_mass
from incidence_multicap_spline_ritz import limited_shells


def erase(r, shapes, cap, full):
    sigs = list(r.signatures)
    source = r.g*r.survival(cap)*np.exp(-r.fiber_tilt*r.t)
    one = [source*psi for psi in shapes]
    single = [rfft(k[::-1],r.L) for k in one]
    double = {}
    for a in range(3):
        for b in range(a+1):
            convolution = irfft(rfft(one[a],r.L)*rfft(one[b],r.L),r.L)[:r.n]
            double[a,b] = double[b,a] = rfft(convolution[::-1],r.L)
    split = [fiber_splits(sig) for sig in sigs]
    moments = {e:rfft((source*r.t**e)[::-1],r.L) for row in split for _,e,_ in row}
    forward = np.exp(r.fiber_tilt*(r.sf-r.center))
    back1 = np.exp(-r.fiber_tilt*(r.sy-r.center))
    s2 = (np.arange(r.n)+(r.k-2)/2)*r.h
    back2 = np.exp(-r.fiber_tilt*(s2-r.center))
    core = np.zeros_like(full)
    fa = np.zeros((len(sigs),3,r.n))
    fb = np.zeros_like(fa)
    pair = np.zeros((len(sigs),1,r.n))
    for s in range(len(sigs)):
        for a in range(3):
            for b in range(3):
                z = rfft(full[s,3*a+b]*forward,r.L)
                def corr(kernel):
                    return irfft(z*kernel,r.L)[r.n-1:2*r.n-1]
                for rest,e,multiplicity in split[s]:
                    core[sigs.index(rest),3*a+b] += multiplicity*corr(moments[e])*back1
                fa[s,b] += corr(single[a])*back1
                fb[s,a] += corr(single[b])*back1
                pair[s,0] += corr(double[a,b])*back2
    return dict(full=full,core=core,a=fa,b=fb,pair=pair)


def contract(r, cap, shapes, count, fields, where=None):
    """Contract several labelled bilinear densities, one core moment at a time."""
    p = fields[0][0].shape[1]
    pairs = [(m,k) for m in range(3) for k in range(m,3)]
    if p == 9:
        pair_index = [(a,b) for a in range(3) for b in range(3)]
        endpoints = [[tuple(sorted((pairs.index(tuple(sorted((a,c)))),
                                    pairs.index(tuple(sorted((b,d)))))))
                      for c,d in pair_index] for a,b in pair_index]
    elif p == 3:
        endpoints = [[(pairs.index(tuple(sorted((a,b)))),) for b in range(3)] for a in range(3)]
    else:
        assert p == 1
        endpoints = [[()]]
    keys = sorted({key for row in endpoints for key in row})
    group = {key:[] for key in keys}
    for i in range(p):
        for j in range(p):
            group[endpoints[i][j]].append((i,j))
    angular = defaultdict(list)
    for i,s in enumerate(r.signatures):
        for j,t in enumerate(r.signatures):
            angular[tuple(sorted(s+t))].append((i,j))
    law = [r.w*r.survival(cap)*shapes[m]*shapes[k] for m,k in pairs]
    # Use a single positive convolution of the core moment with the
    # pre-combined endpoint kernel. On nonnegative indices truncating
    # after either convolution gives the same exact first n entries.
    spectra = {}
    for key in keys:
        if len(key)==2:
            spectra[key] = rfft(r.conv(law[key[0]],law[key[1]]),r.L)
        elif len(key)==1:
            spectra[key] = rfft(law[key[0]],r.L)
    if where is not None:
        fields = [(a[:,:,where],b[:,:,where]) for a,b in fields]
    size = r.n if where is None else len(where)
    out = [np.zeros(size) for _ in fields]
    for sig, positions in angular.items():
        core = r.moment(cap,count,sig)
        transform = rfft(core,r.L) if p>1 else None
        for key in keys:
            kernel = np.maximum(0.,irfft(transform*spectra[key],r.L)[:r.n]) if key else core
            if where is not None:
                kernel = kernel[where]
            for n,(delta,twice) in enumerate(fields):
                block = np.zeros(size)
                for i,j in positions:
                    for a,b in group[key]:
                        block += delta[i,a]*twice[j,b]
                out[n] += block*kernel
    return out


NATIVE_STARTS = {
    'trim': ((125500,63177),(130996,60089)),
    'b8': ((117733,65536),(124337,64599),(125500,63177),(125537,61104),(130668,60089)),
    'b6': ((117733,65536),(124270,64599),(125500,63177),(125537,61104),(130593,60089),(130976,47096)),
}


@lru_cache
def native_starts(profile):
    if profile in NATIVE_STARTS:
        return NATIVE_STARTS[profile]
    from h1_degree6_native_schur_support import replay_limits
    limits = replay_limits(Q(profile))
    # Above a maximum J drop to the preceding fragment cap. Above the
    # largest surviving J there are no tuples, including unmarked tuples.
    return tuple(sorted((last+1,limits[i-1][0] if i else -1)
                        for i,(_,last) in enumerate(limits)))


def trim_native_shell(r,shell,profile='trim'):
    """Intersect one outer shell with the native above-cap exclusions."""
    if r.k != 39 or r.N != 131072:
        raise ValueError("The trim boundaries are defined on the native 39-site grid.")
    lo,hi,cap = shell
    pieces = []
    # mask() assigns the lower-side cell J=floor(lo/h)-k+1 to this shell.
    for j,limit in native_starts(profile):
        boundary = (j+r.k-1)*r.exact_step
        end = min(hi,boundary)
        if lo < end and cap>=0:
            pieces.append((lo,end,cap))
        lo = max(lo,boundary)
        cap = min(cap,limit)
    if lo < hi and cap>=0:
        pieces.append((lo,hi,cap))
    return pieces


def inputs(frame,cells,v,radial_multiplier=None,shell_transform=None):
    with contextlib.redirect_stdout(io.StringIO()):
        r,limits,_,_,_,m = TS.stored_model(39,cells,6,frame)
    del r.radial_products
    bound_moment_storage(r)
    shapes = [np.ones(r.n), (r.t/r.S)**2, 1/(1+300*r.t)]
    sigs = list(r.signatures)
    coefficients = v.reshape(9,3,len(sigs),r.nr)
    scales = r.scale.reshape(len(sigs),r.nr)
    geometry = defaultdict(list)
    for c,limit in enumerate(limits):
        for shell in limited_shells(r.shells['outer'],limit):
            pieces = [shell] if shell_transform is None else shell_transform(r,shell)
            for piece in pieces:
                geometry[piece[2]].append((c,piece))
    radial = None if radial_multiplier is None else radial_multiplier(r)
    def increment(cap, *, raw=False):
        full = np.zeros((len(sigs),9,r.n))
        for c,shell in geometry[cap]:
            mask = r.mask(shell,r.k)
            for k in range(9):
                full[:,k] += ((coefficients[k,c]*scales) @ r.radial_values)*mask
        if radial is not None:
            full *= radial
        return full if raw else erase(r,shapes,cap,full)
    return r,m,shapes,geometry,increment


def replay(frame,cells,v,radial_multiplier=None,shell_transform=None):
    r,m,shapes,geometry,increment = inputs(frame,cells,v,radial_multiplier,shell_transform)
    core = r.k-2
    unit = r.norm/r.k
    qpair = r.rho*(np.arange(r.n)+core)*r.h
    lift = 2*r.rho**2/(.4999-qpair)**2
    pair_w = unit**2*np.exp(r.tilt*((np.arange(r.n)+core/2)*r.h-r.center))*lift
    old = {}
    mass = pair = 0.
    faces = np.zeros((3,r.n))
    for cap in sorted(geometry,reverse=True):
        start = time.monotonic()
        delta = increment(cap)
        if not old:
            old = {key:np.zeros_like(d) for key,d in delta.items()}
        def fields(keys,count):
            inputs = [(delta[k],2*old[k]+delta[k]) for k in keys]
            return contract(r,cap,shapes,count,inputs)
        mass += r.outer_exp @ fields(['full'],core)[0]
        faces[0] += (r.rho*core*unit)*r.inner_exp*fields(['core'],core-1)[0]
        ea,eb = fields(['a','b'],core)
        faces[1] += (r.rho*unit)*r.inner_exp*ea
        faces[2] += (r.rho*unit)*r.inner_exp*eb
        pair += pair_w @ fields(['pair'],core)[0]
        for key in old:
            old[key] += delta[key]
        del delta
        r.clear_cache()
        print(json.dumps(dict(cap=cap,seconds=round(time.monotonic()-start,2),
                              peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)),flush=True)
    return r,sorted(geometry),mass,faces/mass,pair/mass


def ordinary_mass(frame,cells,v,shell_transform=None):
    """Contract only the changed full cells, with no erased profiles."""
    r,_,shapes,geometry,increment=inputs(frame,cells,v,shell_transform=shell_transform)
    old=None
    mass=0.
    for cap in sorted(geometry,reverse=True):
        delta=increment(cap,raw=True)
        if old is None:
            old=np.zeros_like(delta)
        ix=np.flatnonzero(np.any(delta!=0.,axis=(0,1)))
        if len(ix):
            density,=contract(r,cap,shapes,r.k-2,[(delta,2*old+delta)],ix)
            mass+=r.outer_exp[ix]@density
        old+=delta
        r.clear_cache()
    return mass


def fixed_price(frame,cells,v,faces,mass,shell_transform=None):
    """Telescoping fixed-price multiplier, restricted to its changing cells."""
    r,m,shapes,geometry,increment = inputs(frame,cells,v,shell_transform=shell_transform)
    labels = TS.labeller(r,frame,m)
    pu,ker = TS.aux(r,frame['original']['max_radius'])
    prices = TS.load_price_table(TS.HERE/'h1_multilevel_strip_free.json',len(frame['energies']))
    caps = sorted(set(TS.layer_caps(frame,m)) | set(geometry),reverse=True)
    caps = [c for c in caps if c<=max(geometry)]
    def weight(cap):
        ids = labels(cap)
        w = np.zeros(r.n)
        ok = ids>=0
        w[ok] = prices[ids[ok],0]+pu[ok]*prices[ids[ok],1]+ker[ok]*prices[ids[ok],2]
        return w
    ref = weight(caps[-1])
    value = np.sum(faces@ref)
    prev = ref
    old = {}
    core = r.k-2
    for index,cap in enumerate(caps):
        w = weight(cap)
        delta = increment(cap) if cap in geometry else None
        if delta is not None:
            delta = {k:delta[k] for k in ('core','a','b')}
            if not old:
                old = {k:np.zeros_like(d) for k,d in delta.items()}
        # The unconditional histograms already carry the common price ref.
        # At this cap telescope Hnew^2(w-ref)-Hold^2(wprev-ref).
        for wm,changed in [(w-ref,True),(w-prev,False)]:
            ix = np.flatnonzero(wm)
            if not len(ix) or (changed and delta is None):
                continue
            def pair(k):
                return (delta[k],2*old[k]+delta[k]) if changed else (old[k],old[k])
            dcore, = contract(r,cap,shapes,core-1,[pair('core')],ix)
            da,db = contract(r,cap,shapes,core,[pair('a'),pair('b')],ix)
            mult = r.rho*(r.norm/r.k)*r.inner_exp[ix]*wm[ix]/mass
            value += mult@(core*dcore+da+db)
        if delta is not None:
            for k in old:
                old[k] += delta[k]
        prev = w
        r.clear_cache()
        if (index+1)%5==0:
            print(json.dumps(dict(price_caps=index+1,total=len(caps),
                                  peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)),flush=True)
    return value


def native_receipt():
    path = TS.HERE/'h1_two_source_endpoints_runs.jsonl'
    rows = (json.loads(line) for line in path.read_text().splitlines() if line.strip())
    values = [row for row in rows if row.get('run')=='ts_s39a6' and row.get('event')=='VALUE']
    assert len(values)==1
    return values[0]


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cells',type=int,required=True)
    parser.add_argument('--check',action='store_true')
    parser.add_argument('--save',type=Path)
    parser.add_argument('--price-hist',type=Path,help='Replay archived cap-specific prices with these native radial energies.')
    parser.add_argument('--trim-native',action='store_true',help='Apply the two native, full-tuple radial and fragment exclusions.')
    parser.add_argument('--support-profile',choices=NATIVE_STARTS,help='Apply a native cap and total schedule before erasure.')
    parser.add_argument('--schur-budget',help='Use the exact hereditary native support for this nonnegative Schur budget.')
    parser.add_argument('--mass-only',action='store_true',help='Only compute the ordinary squared norm.')
    parser.add_argument('--price',action='store_true',help='Compute the cap-specific fixed-price quotient after the mass and pair replay.')
    args=parser.parse_args()
    assert sha256(VECTOR.read_bytes()).hexdigest() == 'ae58b3d018eae9904fd2c6e869ba6f70cf77fcb982284a487ca9b6f446d2f624'
    with np.load(VECTOR) as f:
        vector=f['vector']
    frame=TS.stored_frame()
    if sum(map(bool,(args.trim_native,args.support_profile,args.schur_budget)))>1:
        parser.error('Choose one native support profile.')
    profile='trim' if args.trim_native else args.support_profile or args.schur_budget
    transform=(lambda r,s:trim_native_shell(r,s,profile)) if profile else None
    if args.mass_only:
        print(json.dumps(dict(support_profile=profile,cells=args.cells,
                              mass=ordinary_mass(frame,args.cells,vector,transform))),flush=True)
        raise SystemExit(0)
    if args.price_hist:
        with np.load(args.price_hist,allow_pickle=False) as h:
            assert int(h['cells']) == args.cells
            assert str(h['support_profile'] if 'support_profile' in h else '')==(profile or '')
            val = fixed_price(frame,args.cells,vector,h['faces'],float(h['mass']),transform)
            if args.cells==131072 and not profile:
                assert abs(val-native_receipt()['fixed_price_one_prime'])<1e-8
            print(json.dumps(dict(fixed_price_one_prime=val,fixed_price_net=val-float(h['pair']))),flush=True)
        raise SystemExit(0)
    r,caps,mass,faces,pair=replay(frame,args.cells,vector,shell_transform=transform)
    if args.cells == 131072 and not profile:
        prior = native_receipt()
        archived = [prior['faces'][role]['total_energy'] for role in ['core','a','b']]
        assert np.allclose(faces.sum(axis=1),archived,rtol=0,atol=1e-8)
        assert abs(mass-1)<1e-8 and abs(pair-prior['pair_cost'])<1e-8
    if args.check:
        assert args.cells<=4096
        L=model(frame,args.cells,6,[0.,'p2',300.])
        refmass=scalar_mass(L,vector)
        L.layer_caps=lambda extra:caps
        layers,p=L.densities_and_pair(vector)
        ref=np.sum(list(layers.values()),axis=0)*r.rho/refmass
        assert abs(refmass/mass-1)<1e-8
        assert abs(p/refmass/pair-1)<1e-8
        print('Absolute histogram L1 differences', np.sum(abs(ref-faces),axis=1))
        assert np.all(np.sum(abs(ref-faces),axis=1)<1e-8)
    print(json.dumps(dict(cells=args.cells,mass=mass,face_sums=faces.sum(axis=1).tolist(),pair=pair,
                          negative=-np.minimum(0.,faces).sum())),flush=True)
    if args.save:
        np.savez_compressed(args.save,cells=args.cells,mass=mass,faces=faces,pair=pair,caps=caps,support_profile=profile or '',
                            step=str(r.exact_step),rho=str(Q(r.geometry['parameters']['rho_star'])),
                            physical_outer=str(Q(r.geometry['parameters']['physical_outer'])))
    if args.price:
        del r
        val=fixed_price(frame,args.cells,vector,faces,mass,transform)
        print(json.dumps(dict(fixed_price_one_prime=val,fixed_price_net=val-pair)),flush=True)
