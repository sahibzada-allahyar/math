"""Apply global exceptional-product covers to the nineteen-tile trial on 521 sectors."""
import argparse
import json
from fractions import Fraction as Q
from math import ceil, floor
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from h1_bilinear_pricing import lower, proof_data
from h1_exception_cover import UNIT, compact_weights, harmonic_rows, kernel_at
from h1_split_minorant_prices import solve
from h1_sunrise_boundary import digest, read
from h1_sunrise_refined import TABLE, DUAL
from verify_pairing_envelope import SCALE, quantize


TILES = Path('h1_nested_tiles_131072.json')
FIT = Path('h1_nested_tiles_131072_fit.json')
PERMISSIONS = Path('h1_refit280_step2_permissions_131072.json')
LADDER = Path('h1_bilinear_ladders_131072.json')
MINORANTS = Path('../sensitivity/bilinear_minorant.json')


def tile_energies():
    desc, fit = map(read,(TILES,FIT))
    archive = TILES.with_suffix('.npz')
    assert digest(archive)==desc['archive_sha256'] and digest(TILES)==fit['inputs'][TILES.name]
    assert desc['inputs'][TABLE.name]==digest(TABLE)
    # Treat the binary64 pencils as exact finite inputs. The independent
    # scalar replay and the continuous approximation have separate status.
    v = np.asarray(desc['transform'],dtype=object)@np.asarray(fit['arms']['free_nineteen']['leaf'],dtype=object)
    rational = np.vectorize(lambda x: Q(float(x)),otypes=[object])
    with np.load(archive,allow_pickle=False) as z:
        e = (v@rational(z['energies'])@v)/(v@rational(z['mass'])@v)
    assert min(e.ravel())>0
    return e


def model(cover,with_layout=False,energies=None,three_cutoff=None):
    base,dual=map(read,(TABLE,DUAL))
    assert dual['inputs'][TABLE.name]==digest(TABLE)
    archive=TILES.with_suffix('.npz')
    e=tile_energies() if energies is None else energies
    assert e.shape==(len(base['codes']),3) and min(e.ravel())>0
    args=SimpleNamespace(control=TABLE,permissions=PERMISSIONS,ladder_receipt=LADDER,
                         minorants=MINORANTS,grant='ladder',level='.5291')
    full,parts,fixed,extra=proof_data(args,with_layout=True)
    _,prime,sharp,high,_,k0,kt,_,omitted=full
    assert not omitted
    groups=[np.asarray(group) for group in dual['groups']]
    owner=np.full(len(e),-1,int)
    for i,part in enumerate(parts):
        owner[part]=i
    parent=[owner[g[0]] for g in groups]
    assert all(i>=0 and (owner[g]==i).all() for g,i in zip(groups,parent))
    assert sorted(fixed.tolist()+sum(dual['groups'],[]))==list(range(len(e)))
    masks=[mask[np.ix_(parent,parent)] for mask in (prime,sharp,high)]
    q=[Q(ceil(Q(str(t))*10000)+1,10000) for t in base['physical_upper']]
    record=read(cover)
    assert record['source_sha256']==digest(MINORANTS) and record['weight_scale']==UNIT
    source=next(s for s in read(MINORANTS)['rows'] if Q(s['theta'])==Q('.5291'))
    new,zeta=Q(source['a']),Q(source['zeta'])
    caps={}
    for kind,row in record['covers'].items():
        rows=harmonic_rows(kind,new,zeta,record['bins'])
        w=np.array(row['weights'],np.int64)
        assert 0<=min(w) and max(w)<=25*UNIT and len(w)==len(rows[1])
        assert min(w[rows[-1]].sum(1))>=(2 if kind=='three' else 24)*UNIT
        compact=compact_weights(rows,w)
        tab={x:kernel_at(compact,x) for x in set(q)}
        caps[kind]=np.array([tab[x] for x in q],dtype=object)
    if three_cutoff is not None:
        from h1_three_affine_cover import kernel
        # One common marked-prime weight for the entire signed square.
        tab={x:kernel(zeta,new,Q(three_cutoff),x)[1] for x in set(q)}
        caps['three']=np.array([tab[x] for x in q],dtype=object)
    group_mass=np.array([e[g].sum(0) for g in groups])
    mass = group_mass[:,0]
    def average(values):
        return np.array([sum(e[g,0]*values[g])/v for g,v in zip(groups,mass)],dtype=object)
    old=np.array(base['sector_energies'])
    scales=np.sqrt(mass.astype(float)/np.array([old[g,0].sum() for g in groups]))
    lin=[quantize(np.asarray(v,float)/SCALE*np.outer(scales,scales)) for v in dual['affine']]
    upper=[group_mass[:,1]/mass,*[average(caps[k]) for k in ('old','three','increment')]]
    rough=lambda t:np.array([1/(min(t,Q(1,2)-x)-Q('.0001')) for x in q],dtype=object)
    local=[rough(Q('.17278')),rough(zeta),rough(1-2*new),caps['new']]
    coeffs=[[1,Q(1,24),0,0],[1,0,Q(1,2),0],[1,Q(1,24),Q(1,2),Q(1,24)],[0,1,0,1]]
    coupled=[(coeff,average(v)) for coeff,v in zip(coeffs,local)]
    fixed_cost=sum(e[fixed,0])
    data=(group_mass,*masks,k0,kt,fixed_cost,omitted,upper,coupled)
    keys=(TILES,FIT,archive,TABLE,DUAL,cover,MINORANTS,PERMISSIONS,LADDER)
    result=(data,lin,{path.name:digest(path) for path in keys},average(extra))
    if with_layout:
        return (*result,(e,groups,fixed,caps,local))
    return result


def reduced(data):
    e,p,m,g,k,kt,fixed,_,u,_=data
    en=e.copy()
    en[:,2]=e[:,0]*u[1]
    return en,p,m,g,u[2]+u[3],k,kt,fixed


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('cover',type=Path)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--steps',type=int,default=90)
    ap.add_argument('--warm',type=Path)
    ap.add_argument('--check',action='store_true')
    a=ap.parse_args()
    data,lin,hashes,legacy_extra=model(a.cover)
    red=reduced(data)
    base_args=(data[0],*data[1:4],legacy_extra,*data[4:7])
    if a.check:
        doc=read(a.output)
        assert doc['inputs']==hashes
        chosen=[np.array(x,dtype=object) for x in doc['affine']]
        assert floor(lower(*red,chosen)*10**9)==doc['lower_billionths']
    else:
        before=floor(lower(*base_args,lin)*10**9)
        after=floor(lower(*red,lin)*10**9)
        if a.warm:
            prev=read(a.warm)
            assert all(prev['inputs'][f.name]==hashes[f.name] for f in (TILES,FIT,TABLE,DUAL))
            lin=[np.array(x,dtype=object) for x in prev['affine']]
        L,R,S=[np.asarray(x,float)/SCALE for x in lin]
        candidate,history=solve(red,(L+R+S,R+S,S),a.steps)
        choices=[lin,candidate]
        bounds=[floor(lower(*red,w)*10**9) for w in choices]
        i=int(np.argmax(bounds))
        doc=dict(scope='Lower certificate on the fixed native cap forms with new global marking weights.',
                 inputs=hashes,legacy_replay=before,original_prices_with_new_covers=after,
                 lower_billionths=bounds[i],history=history,affine=[v.tolist() for v in choices[i]])
        if a.warm:doc['warm_sha256']=digest(a.warm)
        a.output.write_text(json.dumps(doc,separators=(',',':'))+'\n')
    print('legacy',doc['legacy_replay'],'new marking',doc['original_prices_with_new_covers'],
          'refitted',doc['lower_billionths'],flush=True)


if __name__=='__main__':
    main()
