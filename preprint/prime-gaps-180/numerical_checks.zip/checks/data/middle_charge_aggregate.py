"""Collect raw deleted mass and the local negative-form charge, with provenance by gate group."""
from argparse import ArgumentParser
from fractions import Fraction as Q
from hashlib import sha256
import json
from math import ceil
from pathlib import Path

from flint import ctx

from local_schur_charge import PIN,grouped
from radial_ellipsoid import aggregate


def priced(panels,lower,cap):
    return sum((Q(value)*grouped(lower,cap,int(hi)) for _lo,hi,value in panels),Q(0))


def check_radial_coverage(r,limits):
    width=r['radial_width']
    back=width*r['kernel_radius']
    last=next(n for c,n in limits if c>=r['cap'])
    first=max(0,ceil(Q(102994-back,width)))
    stop=(last+back)//width+1
    if r.get('label_interval')!=[first,stop] or r.get('last_native_index')!=last:
        raise ValueError('Receipt does not document every required radial label.')
    block=r['panel_width'];assert block>0
    assert r['ranges']==[[max(102994,k*width-back),min(last,(min(stop,k+block)-1)*width+back)]
                         for k in range(first,stop,block)]


def load_jackson(paths):
    files=[f for p in paths for f in (sorted(p.glob('*.json')) if p.is_dir() else [p])]
    from h1_degree6_native_schur_support import replay_limits
    limits=replay_limits(2) if files else ()
    pieces={}
    for f in files:
        raw=f.read_bytes();r=json.loads(raw);cap=r['cap'];edge,end=r['edge_group']
        if r.get('square_underflow_safe') is not True:
            raise ValueError(f'{f} has no verified safe-magnitude marker.')
        check_radial_coverage(r,limits)
        capture=Q(r['minimum_capture'])
        assert 0<capture<=1 and all(x>=0 for x in r['panel_bounds_before_capture'])
        panels=[[lo,hi,Q(x)/capture] for (lo,hi),x in zip(r['ranges'],r['panel_bounds_before_capture'],strict=True)]
        group=90000+40000*((edge-90000)//40000)
        assert 90000<=group<940000 and group<=edge<end<=min(group+40000,940000)
        assert (edge-90000)%10000==0 and (end-90000)%10000==0
        pieces.setdefault((cap,group),{}).setdefault(edge,[]).append((end,sha256(raw).hexdigest(),panels))
    out={}
    for key,by_start in pieces.items():
        start=key[1];end=min(start+40000,940000)
        def covers(pos,sources,panels):
            if pos==end:
                out.setdefault(key,[]).append((sources,panels))
            else:
                for to,digest,rows in by_start.get(pos,[]):
                    covers(to,{**sources,f'{pos}-{to}':digest},panels+rows)
        covers(start,{},[])
    return out


def upper_decimal(x,places=18):
    scale=10**places
    n=-(-x.numerator*scale//x.denominator)
    return f'{n//scale}.{n%scale:0{places}d}'


def amount(panels,lower,cap):
    return sum((Q(value) for _,_,value in panels),Q(0)),priced(panels,lower,cap)


def measured_option(label,panels,lower,cap,origins):
    d,b=amount(panels,lower,cap)
    return dict(scheme=label,source_receipts=origins,scaled_deleted_upper=upper_decimal(d),
                scaled_negative_upper=upper_decimal(b),panels=[[a,z,str(Q(x))] for a,z,x in panels if x])


def source_inventory(paths):
    sources={}
    for path in paths:
        for f in sorted(path.glob('*.json') if path.is_dir() else [path]):
            raw=f.read_bytes();r=json.loads(raw);fingerprint=sha256(raw).hexdigest()
            sources[fingerprint]=dict(file=f.name,cap=r['cap'],edges=r['edge_group'],labels=r['label_interval'],
                                      panel_width=r['panel_width'],native_last=r['last_native_index'])
    return sources


def subtotals(rows,lower):
    edges={}
    for row in rows:
        cap=row['cap'];edge=row['edge'];opts=row['inputs']
        values=[amount(x['panels'],lower[cap],cap) for x in opts]
        for opt,(d,b) in zip(opts,values):
            assert (opt['scaled_deleted_upper'],opt['scaled_negative_upper'])==(upper_decimal(d),upper_decimal(b))
        d,b=min(x[0] for x in values),min(x[1] for x in values)
        assert (row['scaled_deleted_upper'],row['scaled_negative_upper'])==(upper_decimal(d),upper_decimal(b))
        a,z=edges.get(edge,(Q(0),Q(0)));edges[edge]=a+d,z+b
    return edges


def combined(root,ellipsoid,jackson,denominator,partial,window=None):
    base=aggregate(root,ellipsoid,not (partial or window),denominator)
    assert base['source_pin']==PIN and base['extra_gram_radius']=='2^-146'
    manifest=json.loads((root/'manifest.json').read_text());caps=sorted({a for a,_ in manifest['pairs']})
    lower=dict(zip(caps,[0]+caps[:-1]));alternates=load_jackson(jackson)
    groups=[]
    for row in base['groups']:
        cap=row['cap'];edge=row['edge']
        if window and not window[0]<=edge<=window[1]:continue
        name=f'{cap}_{edge}.json';sources={'raw':sha256((root/name).read_bytes()).hexdigest()}
        if row['mode']=='ellipsoid and baseline':sources['corrected_ellipsoid']=sha256((ellipsoid/name).read_bytes()).hexdigest()
        options=[measured_option(row['mode'],row['panels'],lower[cap],cap,sources)]
        for fingerprints,panels in alternates.get((cap,edge),[]):
            options.append(measured_option('safe full-index kernel',panels,lower[cap],cap,fingerprints))
        values=[amount(x['panels'],lower[cap],cap) for x in options]
        d,b=min(v[0] for v in values),min(v[1] for v in values)
        groups.append(dict(cap=cap,edge=edge,scaled_deleted_upper=upper_decimal(d),scaled_negative_upper=upper_decimal(b),
                           inputs=options))
    edges=subtotals(groups,lower);dust=sum(x for x,y in edges.values());negative=sum(y for x,y in edges.values())
    pairs=[(a,b) for a,b in manifest['pairs'] if not window or window[0]<=b<=window[1]]
    if not partial:assert {(r['cap'],r['edge']) for r in groups}==set(pairs)
    den=Q(denominator)
    norm=Path(__file__).with_name('bottom_angular_norm.json')
    norm_bound=json.loads(norm.read_text())['continuum_scaled_lower']
    assert 0<den<=Q(norm_bound)
    return dict(scope='Sum over covered middle gate groups. Deleted mass and negative Schur form are separate uppers.',
                baseline_pin=PIN,legacy_extra_gram_radius=base['extra_gram_radius'],cases=len(groups),required=len(manifest['pairs']),
                window=window,expected_in_window=len(pairs),source_manifest=manifest,jackson_sources=source_inventory(jackson),
                legacy_correction_code_sha256=base['legacy_correction_code_sha256'],ellipsoid_code_sha256=base['ellipsoid_code_sha256'],
                panels_format=['inclusive possible native J lower','inclusive possible native J upper','post-capture raw upper as exact rational'],
                ordinary_receipt=[norm.name,sha256(norm.read_bytes()).hexdigest(),'continuum_scaled_lower',norm_bound],
                scaled_ordinary_floor=str(denominator),scaled_deleted_upper=upper_decimal(dust),scaled_negative_upper=upper_decimal(negative),
                fraction_deleted_upper=upper_decimal(dust/den),fraction_negative_upper=upper_decimal(negative/den),
                edge_totals=[[e,min(e+40000,940000),upper_decimal(a),upper_decimal(b)] for e,(a,b) in sorted(edges.items())],groups=groups)


def verify(ledger,supplement=None):
    manifest=ledger['source_manifest']; record=manifest['record']
    assert sha256(json.dumps(record,sort_keys=True).encode()).hexdigest()==manifest['pin']==ledger['baseline_pin']==PIN
    assert ledger['legacy_extra_gram_radius']=='2^-146'
    directory=Path(__file__).resolve().parent
    from archived_sources import recorded_digest,working_name
    for name,digest in record['inputs'].items():assert recorded_digest(name)==digest
    from projected_fourier import P
    from inspect import getsource
    assert sha256(getsource(P.bank).encode()).hexdigest()==record['bank_code_hash']
    caps=sorted({a for a,_ in manifest['pairs']});lower=dict(zip(caps,[0]+caps[:-1]))
    window=ledger['window'];pairs={(a,b) for a,b in manifest['pairs'] if not window or window[0]<=b<=window[1]}
    rows=ledger['groups'];covered={(r['cap'],r['edge']) for r in rows}
    assert covered==pairs and len(rows)==ledger['cases']==ledger['expected_in_window']==len(pairs)
    sources=ledger.get('jackson_sources',{})
    known={}
    if supplement:
        files=[supplement/meta['file'] for meta in sources.values()]
        assert source_inventory(files)==sources
        known=load_jackson(files)
    for r in rows:
        for opt in r['inputs']:
            assert all(102994<=lo<=hi<=131032 and Q(x)>0 for lo,hi,x in opt['panels'])
            if opt['scheme']=='impossible':assert not opt['panels'] and r['cap']*(P.S/P.N)*2624990<=r['edge']
            if opt['scheme']=='safe full-index kernel':
                start=r['edge']
                for label,h in sorted(opt['source_receipts'].items(),key=lambda z:int(z[0].split('-')[0])):
                    a,b=map(int,label.split('-'));assert a==start and b>a
                    assert sources[h]['cap']==r['cap'] and sources[h]['edges']==[a,b]
                    start=b
                assert start==min(940000,r['edge']+40000)
                if supplement:
                    original=next(panels for digests,panels in known[r['cap'],r['edge']] if digests==opt['source_receipts'])
                    assert opt['panels']==[[lo,hi,str(Q(v))] for lo,hi,v in original if v]
    edges=subtotals(rows,lower)
    assert ledger['edge_totals']==[[e,min(e+40000,940000),upper_decimal(a),upper_decimal(b)] for e,(a,b) in sorted(edges.items())]
    d=sum(x for x,y in edges.values());b=sum(y for x,y in edges.values());den=Q(ledger['scaled_ordinary_floor'])
    name,fingerprint,key,value=ledger['ordinary_receipt'];norm=directory/working_name(name)
    assert sha256(norm.read_bytes()).hexdigest()==fingerprint and json.loads(norm.read_text())[key]==value and 0<den<=Q(value)
    assert [ledger[k] for k in ('scaled_deleted_upper','scaled_negative_upper','fraction_deleted_upper','fraction_negative_upper')]==[upper_decimal(x) for x in (d,b,d/den,b/den)]
    return len(rows),sum(len(opt['panels']) for r in rows for opt in r['inputs'])


if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('receipts',type=Path,nargs='?');p.add_argument('ellipsoid',type=Path,nargs='?')
    p.add_argument('--jackson',nargs='*',type=Path,default=[])
    p.add_argument('--ordinary-floor',default='90.563143145')
    p.add_argument('--partial',action='store_true');p.add_argument('--output',type=Path)
    p.add_argument('--edge-window',type=int,nargs=2);p.add_argument('--verify',type=Path)
    p.add_argument('--check-supplement-inputs',type=Path)
    a=p.parse_args();ctx.prec=160
    if a.verify:print('verified cases and signed radial witnesses',verify(json.loads(a.verify.read_text()),a.check_supplement_inputs))
    else:
        d=combined(a.receipts,a.ellipsoid,a.jackson,a.ordinary_floor,a.partial,a.edge_window)
        if a.output:a.output.write_text(json.dumps(d,separators=(',',':'))+'\n')
        print(json.dumps({k:v for k,v in d.items() if k not in ('groups','source_manifest','edge_totals','jackson_sources')}))
