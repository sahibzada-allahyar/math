"""Enclose the ordinary norm of the frozen combined 38-coordinate cell trial.

The trial freezes coordinate and radial values at rational cell midpoints;
its largest-fragment indicators retain their continuous Dickman measures.
This does not integrate an unfrozen smooth spline or certify a prime gap.
Moment combinatorics and directed binary64 operations use the pinned public
engine. Positive convolutions use independent GMP integer packing because
the installed FLINT runtime fails the public signed-FFT regression.
"""
import argparse
from collections import defaultdict
import ctypes
from fractions import Fraction as Q
import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path
import sys
import time

import numpy as np
from flint import arb, ctx

from h1_dickman_taylor import DickmanTaylor, native_inventory, rat, record, horner
from h1_exact_convolution import PositivePolynomial, check_convolution
from h1_knn_harmonic import BACKEND


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


SPLINE_PATH = BACKEND/'experiments/analytic_support/certify_incidence_spline.py'
SPLINE_SHA = 'caebe8861621633bb2c2b22be7dfb210c11a826cc1e7d40bc5f67434d0f49fad'
assert digest(SPLINE_PATH) == SPLINE_SHA
spec = importlib.util.spec_from_file_location('_combined_mass_spline', SPLINE_PATH)
SPLINE = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = SPLINE
spec.loader.exec_module(SPLINE)
P = SPLINE.P


def check_environment():
    """Public-engine checks, using the Windows C runtime on Windows."""
    info = sys.float_info
    assert __debug__
    assert (info.radix, info.mant_dig, info.max_exp, info.min_exp, info.rounds) == (2, 53, 1024, -1021, 1)
    runtime = ctypes.CDLL('ucrtbase' if sys.platform == 'win32' else None)
    runtime.fegetround.restype = ctypes.c_int
    assert runtime.fegetround() == 0
    smallest = np.nextafter(np.float64(0), np.float64(1))
    product = np.float64(math.ldexp(1., -1022))*np.float64(math.ldexp(1., -52))
    assert 0 < smallest == math.ldexp(1., -1074) == product == smallest*np.float64(1)


class CellMoments(P.CapEngine):
    def __init__(self, k, intervals, S, precision=192, fixed_bits=192, minimum_cap=1):
        check_environment()
        assert k >= 2 and intervals > k and precision >= 80 and fixed_bits >= 32
        ctx.prec, ctx.threads = precision, 1
        self.precision, self.arb_threads, self.fixed_bits = precision, 1, fixed_bits
        self.k, self.intervals, self.n = k, intervals, intervals-k
        self.S = Q(S)
        self.hq = self.S/intervals
        self.h = rat(self.hq)
        self.midpoints = tuple(rat((Q(j)+Q(1, 2))*self.hq) for j in range(self.n))
        self.root_values = tuple(rat(Q(21, 200))/(1+t/100) +
                                 rat(Q(179, 200))/(1+rat(Q(907, 5))*t) for t in self.midpoints)
        self.Z = sum((g*g for g in self.root_values), arb(0))
        assert self.Z.lower() > 0
        self.coordinate_weights = tuple(g*g/self.Z for g in self.root_values)
        self.physical_scale = (self.h*self.Z)**k
        self.directed_reduction_slack = P._verify_directed_reduction_range(self.n)
        self._survival, self._midpoint_powers = {}, {}
        self._weighted, self._powers, self._blocks, self._distinct = {}, {}, {}, {}
        self._moments, self._interval_moments = {}, {}
        self.dickman = DickmanTaylor(max(3, math.ceil(Q(self.n, minimum_cap))), precision=precision)
        inherited = ('moment_interval', 'release_moment_caches', 'midpoint_power', 'aligned_cap')
        assert all(getattr(type(self), name) is getattr(P.CapEngine, name) for name in inherited)

    def survival(self, cap):
        self._assert_precision()
        cap = self.aligned_cap(cap)
        if cap not in self._survival:
            self._survival[cap] = tuple([arb(1)]*self.n if cap is None else
                                        self.dickman.cells(int(cap/self.hq), self.n))
        return self._survival[cap]

    def weighted(self, cap, exponent):
        self._assert_precision()
        cap = self.aligned_cap(cap)
        key = cap, int(exponent)
        if key not in self._weighted:
            self._weighted[key] = PositivePolynomial.from_arb(
                (w*d*p for w, d, p in zip(self.coordinate_weights, self.survival(cap),
                                          self.midpoint_power(exponent))), self.fixed_bits, self.n)
        return self._weighted[key]

    def probability_power(self, cap, count):
        assert count >= 0 and int(count) == count
        key = self.aligned_cap(cap), count
        if key not in self._powers:
            if count == 0:
                value = PositivePolynomial.one(self.fixed_bits, self.n)
            elif count == 1:
                value = self.weighted(cap, 0)
            else:
                half = self.probability_power(cap, count//2)
                value = half.multiply(half)
                if count % 2:
                    value = value.multiply(self.weighted(cap, 0))
            self._powers[key] = value
        return self._powers[key]

    def block_product(self, cap, blocks):
        blocks = tuple(blocks)
        key = self.aligned_cap(cap), blocks
        if key not in self._blocks:
            self._blocks[key] = (PositivePolynomial.one(self.fixed_bits, self.n) if not blocks else
                                self.weighted(cap, blocks[0]) if len(blocks) == 1 else
                                self.block_product(cap, blocks[:-1]).multiply(self.weighted(cap, blocks[-1])))
        return self._blocks[key]

    def moment(self, cap, count, signature):
        self._assert_precision()
        cap, signature = self.aligned_cap(cap), tuple(sorted(signature))
        assert count >= 0 and min(signature, default=0) >= 0
        key = cap, count, signature
        if key not in self._moments:
            answer = PositivePolynomial.zero(self.fixed_bits, self.n)
            for blocks, coefficient in P.moment_terms(count, signature):
                distinct = cap, count, blocks
                if distinct not in self._distinct:
                    self._distinct[distinct] = self.probability_power(cap, count-len(blocks)).multiply(self.block_product(cap, blocks))
                answer = answer.add(self._distinct[distinct].scale_integer(coefficient))
            self._moments[key] = answer
        return self._moments[key]


def self_check():
    """Compare convolutions with explicit enumeration, including a cap difference."""
    e = CellMoments(2, 10, Q(1), minimum_cap=2)
    signatures = ((), (2,), (3,), (2, 2), (2, 3), (2, 2, 2), (6, 6))
    previous = {}
    checks = 0
    for c in (2, 4, 8):
        cap = c*e.hq
        D = e.survival(cap)
        for sig in signatures:
            exact = [arb(0) for _ in range(e.n)]
            for i, j in itertools.product(range(e.n), repeat=2):
                if i+j >= e.n:
                    continue
                value = e.coordinate_weights[i]*e.coordinate_weights[j]*D[i]*D[j]
                for power in sig:
                    value *= e.midpoints[i]**power+e.midpoints[j]**power
                exact[i+j] += value
            interval = e.moment_interval(cap, 2, sig)
            for j, value in enumerate(exact):
                assert arb(float(interval[0][j])).union(arb(float(interval[1][j]))).contains(value)
                checks += 1
            if sig in previous:
                diff = P._cap_positive_difference(interval, previous[sig][0])
                for j, value in enumerate(exact):
                    target = value-previous[sig][1][j]
                    assert arb(float(diff[0][j])).union(arb(float(diff[1][j]))).overlaps(target)
                    checks += 1
            previous[sig] = interval, exact
        e.release_moment_caches()
    return dict(explicit_enumeration_checks=checks, exact_convolution=check_convolution(),
                binary64_environment_check='passed', flint_polynomial_convolution='not used')


def load_trial(fit_path):
    from h1_cover_pairings import TABLE, TILES
    from h1_geometry_scan import fit_geometry
    from h1_nested_tiles import TRIAL
    forms_path = Path('h1_cover_native_mixed.json')
    forms, tiles, fit = map(read, (forms_path, TILES, fit_path))
    paths = [forms_path, forms_path.with_suffix('.npz'), TILES, TABLE, fit_path,
             TRIAL, *map(Path, forms['fits'])]
    assert forms['archive_sha256'] == digest(paths[1])
    for path in (forms_path, paths[1], TABLE):
        assert fit['inputs'][path.name] == digest(path)
    for path in (TILES, TABLE, TRIAL, *map(Path, forms['fits'])):
        assert forms['inputs'][path.name] == digest(path)
    transform = np.array(forms['transform'], dtype=int)
    expected = np.zeros((22, 21), dtype=int)
    expected[:20, :19] = tiles['transform']
    expected[20:, 19:] = np.eye(2, dtype=int)
    assert np.array_equal(transform, expected)
    assert forms['intervals'] == tiles['intervals'] == 131072
    weights = list(map(lambda v: Q(v, 10**12), fit['families']['mixed']['weights']))
    assert len(weights) == 21 and len(tiles['tiles']) == 19
    profiles = [read(path) for path in (TRIAL, *map(Path, forms['fits']))]
    assert all(p['shape_spec'] == profiles[0]['shape_spec'] for p in profiles)
    assert all(not p.get('flat', False) and Q(p['radius']) == Q('.2798746934') for p in profiles)
    geometry, _, _ = fit_geometry(dict(radius=profiles[0]['radius']), 38, 131072)
    pars = geometry['parameters']
    S, h = pars['S'], pars['cell_step']
    assert S == Q(1399373467, 1312494500) and h == S/131072
    table = read(TABLE)
    cells = TABLE.with_name(table['cells'])
    paths.append(cells)
    assert table['cells_sha256'] == digest(cells)
    limits = read(cells)['component_limits']
    assert limits == [46567, 58332, 78116]
    shells = [(s['lower'], s['upper'], min(limits[-1], int(s['cap']//h)))
              for s in geometry['continuous_cap_shells']['outer']]
    basis = SPLINE.RationalBSplineBasis(profiles[0]['shape_spec']['knots'])
    signatures = ((), (2,), (3,), (4,), (2, 2), (5,), (2, 3), (6,), (2, 4), (3, 3), (2, 2, 2))
    assert basis.size == 30 and all(len(p['coefficients']) == 990 for p in profiles)
    coefficient_arrays = [np.array([Q(float(v)) for v in p['coefficients']], dtype=object).reshape(3, 11, 30)
                          for p in profiles]
    # Build each mixed angular profile exactly on the common rational knot spans.
    combined = {}
    for leaf in range(19):
        for first in range(3):
            arrays = [a[first:].sum(axis=0) for a in coefficient_arrays]
            coeff = weights[leaf]*arrays[0]+weights[19]*arrays[1]+weights[20]*arrays[2]
            combined[leaf, first] = [basis.combine(coeff[j]*38**(sum(sig)-len(sig)))
                                     for j, sig in enumerate(signatures)]
    # The sector price table changes at additional native cap boundaries.
    # Retaining those otherwise-zero field increments is essential: it makes
    # the ordinary norm, erased fields, and signed score live on precisely
    # the same maximum-stratum partition.
    native_caps, native_count, inventory_inputs = native_inventory()
    assert native_count == 131072-38
    trial_caps = {c for c in tiles['cap_edges'] if c > 0} | set(limits) | {s[2] for s in shells}
    assert trial_caps <= set(native_caps)
    caps = list(native_caps)
    return dict(paths=paths, S=S, h=h, k=38, intervals=131072, shells=shells, limits=limits,
                tiles=tiles, weights=weights, transform=transform, signatures=signatures,
                combined=combined, caps=caps, inventory_inputs=inventory_inputs,
                rho_star=pars['rho_star'])


def radial_rows(trial, cap, engine):
    """Exact midpoint values, outward converted after exact spline assembly."""
    n, k, h = engine.n, engine.k, engine.hq
    rows = [(np.zeros(n), np.zeros(n)) for _ in trial['signatures']]
    allowed = np.zeros(n, dtype=bool)
    for lo, hi, ceiling in trial['shells']:
        if cap <= ceiling:
            allowed |= engine.shell_mask(P.Shell(lo, hi, ceiling*h), k)
    first = next(j for j, limit in enumerate(trial['limits']) if cap <= limit)
    edges = list(map(Q, trial['tiles']['radius_edges']))
    cap_edges = trial['tiles']['cap_edges']
    owners = np.zeros(n, dtype=int)
    for leaf, (x, y, c, d) in enumerate(trial['tiles']['tiles']):
        if not cap_edges[c] < cap <= cap_edges[d]:
            continue
        mask = allowed & engine.shell_mask(P.Shell(edges[x], edges[y], cap*h), k)
        owners += mask
        for sig_index, profile in enumerate(trial['combined'][leaf, first]):
            for span, (left, right) in enumerate(zip(profile.breaks, profile.breaks[1:])):
                start = max(0, math.ceil(left/h-Q(k, 2)))
                stop = min(n, math.ceil(right/h-Q(k, 2)))
                ids = np.flatnonzero(mask[start:stop])+start
                if not len(ids):
                    continue
                # Final endpoint belongs to the last span; the cell masks here
                # keep every midpoint strictly below S, so it cannot occur.
                points = [rat(((Q(int(j))+Q(k, 2))*h-left)/(right-left)) for j in ids]
                polynomial = tuple(map(rat, profile.coefficients[span]))
                values = P.float_interval([horner(polynomial, x) for x in points])
                rows[sig_index][0][ids] = values[0]
                rows[sig_index][1][ids] = values[1]
    assert np.all(owners[allowed] == 1) and not owners[~allowed].any()
    return rows


def square_rows(rows, signatures):
    out = {}
    for i, si in enumerate(signatures):
        for j in range(i, len(signatures)):
            signature = tuple(sorted(si+signatures[j]))
            value = P._interval_scale_nonnegative(P.interval_multiply(rows[i], rows[j]), 1 if i == j else 2)
            out[signature] = value if signature not in out else P._interval_add(out[signature], value)
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fit', type=Path, default=Path('h1_decoupled_coarsened_1e14_fit.json'))
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--check-only', action='store_true')
    parser.add_argument('--precision', type=int, default=192)
    parser.add_argument('--fixed-bits', type=int, default=192)
    args = parser.parse_args()
    checks = self_check()
    print('engine checks', checks, flush=True)
    if args.check_only:
        args.output.write_text(json.dumps(checks, indent=2)+'\n', newline='\n')
        return
    trial = load_trial(args.fit)
    e = CellMoments(trial['k'], trial['intervals'], trial['S'], args.precision,
                    args.fixed_bits, min(trial['caps']))
    local_paths = trial['paths']+[Path(__file__), Path('h1_dickman_taylor.py'),
                                Path('h1_geometry_scan.py'), Path('h1_nested_tiles.py'),
                                Path('h1_exact_convolution.py')]
    output = dict(status='INCOMPLETE_ORDINARY_NORM',
                  scope='Continuous Dickman integral of the frozen combined cell trial; no erased forms or raw-support restoration.',
                  inputs={p.name: digest(p) for p in local_paths},
                  external_inputs={str(p.relative_to(BACKEND)): digest(p) for p in
                                   (SPLINE_PATH, SPLINE.GENERAL_PATH, SPLINE.G.SOURCE)},
                  checks=checks, dimension=e.k, intervals=e.intervals, precision=args.precision,
                  fixed_bits=args.fixed_bits, S=str(e.S), step=str(e.hq),
                  coefficient_convention='Exact binary64 spline coefficients, integer angular scales, fit weights divided by 10^12.',
                  normalization='I(F)/(h*sum_j g(midpoint_j)^2)^38',
                  inventory_inputs=trial['inventory_inputs'], caps=trial['caps'], layers=[])
    def save():
        args.output.write_text(json.dumps(output, indent=2)+'\n', newline='\n')
    save()
    total, previous = arb(0), {}
    for cap in trial['caps']:
        started = time.monotonic()
        polynomial = square_rows(radial_rows(trial, cap, e), trial['signatures'])
        now, contribution = {}, arb(0)
        for index, (signature, coefficient) in enumerate(polynomial.items()):
            moment = e.moment_interval(cap*e.hq, e.k, signature)
            now[signature] = moment
            delta = moment if signature not in previous else P._cap_positive_difference(moment, previous[signature])
            contribution += P.outward_sum(P.interval_multiply(coefficient, delta))
            if (index+1) % 10 == 0:
                print('cap', cap, 'moments', index+1, '/', len(polynomial), flush=True)
        contribution = P.nonnegative(contribution)
        total += contribution
        output['layers'].append(dict(cap=cap, contribution=record(contribution),
                                     seconds=time.monotonic()-started))
        output['partial_norm'] = record(total)
        save()
        previous = now
        e.release_moment_caches()
        e._survival.clear()
        print('cap', cap, 'contribution', contribution, 'total', total, flush=True)
    assert total.lower() > 0
    output.update(status='ORDINARY_NORM_ENCLOSED', normalized_norm=record(total),
                  physical_norm=record(total*e.physical_scale),
                  relative_width=record((total.upper()-total.lower())/total),
                  coordinate_Z=record(e.Z), physical_scale=record(e.physical_scale))
    save()
    print('ordinary norm', total, 'relative width', (total.upper()-total.lower())/total, flush=True)


if __name__ == '__main__':
    main()
