"""Compile sufficient single-root tail tests for every affine grant in the twelve-level witness."""
import argparse
import gzip
import json
from fractions import Fraction as Q
from math import ceil
from pathlib import Path

import numpy as np

from h1_bilinear_ladders import weak_engine
from h1_direct_bands import HALF,UNIT,source_rows
from h1_mass_band_prices import CERT,FIBRES,FIT,NORM,TABLE,digest,geom,read
from h1_multilevel_native_cap import CERT as ML_CERT,DATA,OUT as CAP
from h1_raw_rectangle_cover import schedules
from h1_sunrise_boundary import geometry

BOOK=DATA/'book_port.json'
OUT=Path('h1_multilevel_root_filter.json')


def rows_for(src,proof,grouped):
    earlier=schedules(src,grouped)
    yield earlier[0]
    yield earlier[1]
    book=read(BOOK)
    for s in proof['levels']:
        level=Q(s)
        engine=weak_engine(book,level,Q(src['fragment_cap']))
        limit=(level-Q('0.000001'))*UNIT
        assert limit.denominator==1
        values=source_rows(engine.fixed.new_input_slacks,int(limit),500)
        yield np.array([[lo,hi,*d] for lo,hi,d in values],dtype=np.int64)
    yield from earlier[3:]


def radii(source,norm):
    shape,orig,layout=geometry(TABLE)
    with np.load(orig['cell_bins']) as z:
        caps=np.unique(z['cells'][:,1])
    idx=np.arange(norm['intervals']-38)
    last=np.full(len(shape['codes'])+1,-1,int)
    for c in caps:
        owner=layout(c,idx)
        np.maximum.at(last,owner,idx)
    assert min(last[:-1])>=0
    tick=Q(norm['step'])*geom.RHO*UNIT
    upper=np.asarray([ceil((int(v)+37)*tick) for v in last[:-1]],dtype=np.int64)
    fixed=sorted(set(range(len(upper)))-{i for g in source['groups'] for i in g})
    assert fixed==[170,171,172,173] and max(upper[fixed])+max(upper)<HALF
    return np.array([max(upper[g]) for g in source['groups']],dtype=np.int64)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--check',action='store_true')
    args=ap.parse_args()
    table,groups,norm=map(read,(TABLE,CERT,NORM))
    with gzip.open(ML_CERT,'rt') as f:
        proof=json.load(f)
    cap=read(CAP)
    assert cap['inputs'][ML_CERT.name]==digest(ML_CERT) and proof['fit']==FIT.name
    expected=['P','P-B',*[f'S{i}' for i in range(12)],'C0','C1','C2']
    assert proof['identities']==expected and proof['groups']==len(groups['groups'])==445
    R=radii(groups,norm)
    records=[]
    for name,A,scan in zip(expected,proof['affine'],rows_for(table,proof,groups)):
        used=np.asarray(A,dtype=np.int64)!=0
        assert np.array_equal(used,used.T)
        assert scan[0,0]==HALF and np.array_equal(scan[:-1,1],scan[1:,0])
        schedule=[]
        for a,b,*d in scan.tolist():
            best=max(d)
            if not best:
                break
            schedule.append([a,b,d.index(best)+1,best])
        assert schedule
        limit=schedule[-1][1]
        partner=np.max(np.where(used,R[None,:],0),axis=1)
        den=np.maximum(1,R+partner)
        g=np.minimum(R,R*limit//den)
        opposite=np.max(np.where(used,g[None,:],0),axis=1)
        i,j=np.nonzero(used)
        assert np.all(g[i]+g[j]<=limit)
        # g_i/(g_i+M_i) + g_j/(g_j+M_j) <= 1 on every active pair.
        assert np.all(g[i]*g[j]<=opposite[i]*opposite[j]) and np.all(g[i]>0)
        beyond=int(np.sum(R[i]+R[j]>HALF))
        # Store the full source schedule even if this particular multiplier
        # has no entries beyond the ordinary range.
        records.append(dict(channel=name,ordered=int(len(i)),outside_ordinary=beyond,
                            level_limit=limit,rows=schedule,gated_radius=g.tolist(),
                            maximum_gated_partner=opposite.tolist(),
                            reduced_radius_groups=int(np.sum(g<R))))
        print(name,'ordered',len(i),'above ordinary',beyond,'rows',len(schedule),flush=True)
    assert len(records)==17
    paths=[Path(__file__),ML_CERT,BOOK,CAP,CERT,FIT,FIBRES,NORM,TABLE,Path('h1_raw_rectangle_cover.py'),
           Path('h1_bilinear_ladders.py'),Path('h1_direct_bands.py')]
    out=dict(scope='Sufficient full-root projection for all nonzero affine entries, conditional on the listed distribution theorems, not a measure or a bound on the cost of projecting.',
             inputs={p.name:digest(p) for p in paths},units=UNIT,ordinary=HALF,
             fixed_sectors=[170,171,172,173],group_radii=R.tolist(),channels=records)
    if args.check:
        assert read(OUT)==out
    else:
        OUT.write_text(json.dumps(out,separators=(',',':'))+'\n',newline='\n')
    print('all active pairs audited',sum(v['ordered'] for v in records),flush=True)


if __name__=='__main__':
    main()
