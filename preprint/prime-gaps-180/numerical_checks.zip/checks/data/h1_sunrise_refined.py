"""Fit and check elliptic and elementary Fourier weights on the same refined sieve."""
import argparse
import json
from fractions import Fraction as Q
from math import floor, isqrt
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from h1_bilinear_pricing import proof_data
from h1_sunrise_boundary import best_direction, digest, envelopes, geometry, read
from verify_pairing_envelope import SCALE, lower_factor


TABLE = Path('h1_priced_168_table.json')
DUAL = Path('h1_priced_nested_three.json')
FORMS = Path('h1_sunrise_521_forms.json')
ARMS = {
    'frozen': [0],
    'linear_fourier': list(range(6)),
    'log_control': list(range(9)),
    'sunrise': list(range(6)) + [9, 10, 11],
    'joint': list(range(12)),
}


def uniform_lower_prices():
    """Componentwise rational prices valid after every positive energy rescaling."""
    args = SimpleNamespace(control=TABLE, permissions=Path('h1_refit280_step2_permissions_131072.json'),
                           ladder_receipt=Path('h1_bilinear_ladders_131072.json'), grant='ladder',
                           minorants=Path('../sensitivity/bilinear_minorant.json'), level='.5291')
    full, parts, fixed, extra = proof_data(args, with_layout=True)
    _, prime, old, higher, _, k0, kt, _, omitted = full
    assert not omitted
    table = json.loads(TABLE.read_text(), parse_float=Q)
    raw = np.array(table['sector_energies'], dtype=object)
    witness = read(DUAL)
    for path in (TABLE, args.permissions, args.ladder_receipt, args.minorants):
        assert witness['inputs'][path.name] == digest(path)
    groups = [np.array(g) for g in witness['groups']]
    assert sorted([*fixed, *(i for g in groups for i in g)]) == list(range(len(raw)))
    owner = np.full(len(raw), -1, int)
    for j, part in enumerate(parts):
        owner[part] = j
    parent = [owner[g[0]] for g in groups]
    assert all(h >= 0 and (owner[g] == h).all() for g, h in zip(groups, parent))
    L, R, S = [np.array(v, dtype=object) for v in witness['affine']]
    for dual, mask in zip((L, R, S), (prime, old, higher)):
        assert np.array_equal(dual, dual.T) and not dual[~mask[np.ix_(parent, parent)]].any()
    e = np.array([raw[g].sum(axis=0) for g in groups])
    mass = e[:, 0]
    roots = np.array([isqrt(int(q * SCALE**2)) for q in mass], dtype=object)
    budgets = (e[:, 1] / mass, e[:, 2] / mass,
               [sum(raw[g, 0] * extra[g]) / v for g, v in zip(groups, mass)])
    residuals = (np.outer(roots, roots) - SCALE * (L+R+S), SCALE * (R+S), SCALE * S)
    p, b, h = [lower_factor(mat, cap)[0] for mat, cap in zip(residuals, budgets)]
    # Diagonal dominance bounds the error of replacing sqrt(e_i)*sqrt(e_j)
    # by the corresponding product of roots rounded down to 1/SCALE.
    n = len(groups)
    p += [Q(int(n*r + sum(roots) + n), SCALE**2) for r in roots]
    prices = np.zeros((len(raw), 3), dtype=object)
    prices[fixed, 0] = SCALE
    for i, g in enumerate(groups):
        trace = (L[i, i] + min((1-k)*R[i, i] for k in k0) + min((1-k)*S[i, i] for k in kt)) / Q(SCALE)
        for s in g:
            slopes = (trace - h[i]*extra[s], -p[i], -b[i])
            prices[s] = [floor(v*SCALE/mass[i]) for v in slopes]
    return prices


def positive_definite(matrix):
    """Exact symmetric elimination, with a positive pivot at every step."""
    m = matrix
    while len(m):
        pivot = m[0, 0]
        if pivot <= 0:
            return False
        m = m[1:, 1:] - np.outer(m[1:, 0], m[0, 1:])/pivot
    return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--scalar', type=Path, help='Native cell report from reintegrating the exported joint spline.')
    parser.add_argument('--receipt', type=Path, help='Record the independent scalar readback.')
    parser.add_argument('--spline', type=Path, help='Export the fixed joint vector as a single spline.')
    args = parser.parse_args()
    prices = uniform_lower_prices()
    forms = read(FORMS)
    base = read(TABLE)
    fit = Path(base['trial_refit'])
    profile = read(fit)
    archive = FORMS.with_suffix('.npz')
    assert forms['orthogonal_radial'] and forms['inputs'][TABLE.name] == digest(TABLE)
    assert forms['inputs'][fit.name] == digest(fit) and forms['forms_sha256'] == digest(archive)
    with np.load(archive, allow_pickle=False) as data:
        gram, energies = data['mass'], data['energies']
    np.testing.assert_allclose(energies[:, :, 0, 0]/gram[0, 0], base['sector_energies'], atol=1e-10, rtol=0)
    price_scale = Q(1, SCALE)
    form = np.einsum('sk,skij->ij', prices.astype(float)/SCALE, energies)
    spec = profile['shape_spec']
    knots = list(map(float, map(Q, spec['knots'])))
    fields = envelopes(np.array(knots), spec['degree'])
    q, r = np.linalg.qr(fields.T)
    scale = np.sign(np.diag(r))*np.sqrt(len(knots) - spec['degree'] - 1)
    transform, stable = r/scale[:, None], q.T*scale[:, None]
    np.testing.assert_allclose(transform.T@stable, fields, atol=2e-14, rtol=0)
    # Evaluate the chosen rational vectors exactly on the binary64 forms.
    rational = np.vectorize(lambda x: Q(float(x)), otypes=[object])
    G, E = rational(gram), rational(energies)
    fixed_form = np.sum(E * prices[:, :, None, None], axis=(0, 1))*price_scale
    inputs = {path.name: digest(path) for path in (TABLE, DUAL, FORMS, archive, fit)}
    result = dict(scope='Lower certificates on stored binary64 forms before continuum and raw-support errors.',
                  inputs=inputs, arms={})
    previous = read(args.output) if args.check or args.scalar else None
    if previous is not None:
        assert previous['inputs'] == inputs
    for name, subset in ARMS.items():
        space = transform[:, subset]
        v, rank = best_direction(gram, form, subset, transform)
        if previous is None:
            coeff, _, _, _ = np.linalg.lstsq(space, v, rcond=None)
            np.testing.assert_allclose(space @ coeff, v, rtol=2e-7, atol=2e-8)
            coeff /= max(abs(coeff))
        else:
            coeff = [float.fromhex(x) for x in previous['arms'][name]['coefficients_hex']]
        # Form the archived linear combination inside the declared column span.
        exact_space = rational(space)
        vec = exact_space @ rational(coeff)
        norm, weights = vec @ G @ vec, vec @ E @ vec
        assert norm > 0 and min(weights.ravel()) >= 0
        score = sum((weights*prices).ravel())*price_scale/norm
        row = dict(rank=int(rank), coefficients_hex=[float(x).hex() for x in coeff],
                   lower_billionths=floor(10**9*score))
        small_mass = exact_space.T @ G @ exact_space
        small_form = exact_space.T @ fixed_form @ exact_space
        assert positive_definite(small_mass)
        # Enclose the optimized fixed-price quotient for the entire declared span.
        # This upper endpoint does not apply to other admissible sieve prices.
        upper = row['lower_billionths'] + 1
        assert positive_definite(Q(upper, 10**9)*small_mass - small_form)
        row['fixed_price_upper_billionths'] = upper
        if previous is not None:
            assert row == previous['arms'][name]
        result['arms'][name] = row
        print(name, row['rank'], row['lower_billionths'], flush=True)
        if name == 'joint':
            joint = vec
            joint_energies = weights/norm
    if previous is None:
        args.output.write_text(json.dumps(result, indent=2)+'\n')
    if args.spline or args.scalar:
        v = np.asarray(joint, float)
        v /= np.sqrt(v@gram@v)
        coefs = np.array(profile['coefficients']).reshape(3, -1, len(fields[0]))
        new = {key: profile[key] for key in ('shape_spec','radius','intervals','fragment_cap','flat','extra_knots')}
        new.update(fit_report=args.output.name, fit_report_sha256=digest(args.output), arm='joint',
                   coefficients=(coefs*(v@stable)).ravel().tolist())
        if args.spline:
            args.spline.write_text(json.dumps(new, indent=1)+'\n')
    if args.scalar:
        record = read(args.scalar)
        spline = args.scalar.with_name(record['trial_refit'])
        loaded = read(spline)
        assert {k:v for k,v in new.items() if k!='coefficients'} == {k:v for k,v in loaded.items() if k!='coefficients'}
        np.testing.assert_allclose(loaded['coefficients'], new['coefficients'], rtol=1e-12, atol=1e-13)
        _, original, layout = geometry(TABLE)
        assert all(original[key] == record[key] for key in ('intervals','component_limits','sources','fragment_cap','codes'))
        bins = args.scalar.with_name(record['cell_bins'])
        assert record['cell_bins_sha256'] == digest(bins)
        with np.load(bins, allow_pickle=False) as z, np.load(TABLE.with_name(original['cell_bins']), allow_pickle=False) as old:
            cells = z['cells']
            np.testing.assert_array_equal(cells[:, :4], old['cells'][:, :4])
        raw = np.zeros(prices.shape, dtype=object)
        for cap in np.unique(cells[:, 1]):
            block = cells[cells[:, 1] == cap]
            groups = layout(cap, block[:, 3].astype(int))
            np.add.at(raw, groups, rational(block[:, 4:7]))
        assert min(raw.ravel()) >= 0
        discrepancy = float(np.max(np.abs(raw-joint_energies)))
        assert discrepancy < 1e-9
        exact = floor(10**9*sum((raw*prices).ravel())*price_scale)
        receipt = dict(inputs={path.name:digest(path) for path in (args.output, args.scalar, bins, spline)},
                       cells=len(cells), sector_entries=int(raw.size), max_absolute_energy_difference=discrepancy,
                       joint_lower_billionths=exact)
        if args.receipt and args.check:
            assert read(args.receipt) == receipt
        elif args.receipt:
            args.receipt.write_text(json.dumps(receipt, indent=2)+'\n')
        print('joint scalar readback', exact, 'max energy discrepancy', discrepancy, flush=True)


if __name__ == '__main__':
    main()
