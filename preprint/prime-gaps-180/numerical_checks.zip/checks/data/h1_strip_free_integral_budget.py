"""Certify the global continuous cost of deleting the semiprime affine identities."""
import argparse
from fractions import Fraction as Q
from math import factorial
from pathlib import Path
import json

import numpy as np

from h1_raw_rectangle_cover import FIBRES, FIT, NORM, PRICES, TABLE, digest, geom, read
from h1_small_fragment_mass_bound import sci_upper
from h1_sunrise_boundary import geometry

REDUCED=Path('h1_strip_free_prices.json')
PRODUCER=Path('h1_combined_score_interval.py')


def affine_majorant(loss, price, energy, numerator):
    """Minimize a+b*(1-average price) with a,b nonnegative by intersecting lines."""
    # The lines are a >= loss_i+b*(maximum_price_i-1), including a>=0.
    # Equal slopes only need the highest intercept.
    lines={Q(0):Q(0)}
    for c,p in zip(loss,price):
        lines[p-1]=max(lines.get(p-1,Q(0)),c)
    hull=[]
    for slope,intercept in sorted(lines.items()):
        while hull:
            prior,old,start=hull[-1]
            crossing=(old-intercept)/(slope-prior)
            if start is None or crossing>start:
                break
            hull.pop()
        hull.append((slope,intercept,crossing if hull else None))
    b=Q(0)
    for j,(slope,intercept,start) in enumerate(hull):
        if j+1<len(hull) and hull[j+1][2]<=0:
            continue
        if (1+slope)*energy>=numerator:
            b=max(Q(0),start or Q(0))
            break
    # A short reproducible witness; its validity is checked at every extremum.
    b=Q(round(b*10**16),10**16)
    a=max([Q(0),*(c+b*(p-1) for c,p in zip(loss,price))])
    assert all(c<=a+b*(1-p) for c,p in zip(loss,price))
    return a,b


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--score',type=Path,default=Path('h1_combined_score_native_interval.json'))
    parser.add_argument('--through-cap',type=int,required=True)
    parser.add_argument('--prefix',type=Path,help='Direct cumulative loss bound to use on the early retained layers.')
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    old,cut,norm,fibres,score=map(read,(PRICES,REDUCED,NORM,FIBRES,args.score))
    for p in (PRICES,FIT,TABLE):assert cut['inputs'][p.name]==digest(p)
    for p in (NORM,FIBRES,FIT,PRICES,TABLE,PRODUCER):assert score['inputs'][p.name]==digest(p)
    assert cut['zero_affine_channels']==[3,4,5]
    assert norm['status']=='ORDINARY_NORM_ENCLOSED' and fibres['status']=='ERASED_AMPLITUDES_ENCLOSED'
    assert [r['cap'] for r in norm['layers']]==norm['caps']==fibres['caps']
    assert score['status'] in ('INCOMPLETE_CONTINUOUS_CAP_SCORE','CONTINUOUS_CAP_SCORE_ENCLOSED')
    assert [r['cap'] for r in score['layers']]==score['caps'][:len(score['layers'])]
    assert args.through_cap in [r['cap'] for r in score['layers']]
    scale=old['scale']
    assert scale==cut['scale']
    prices=np.asarray(old['sector_prices'],dtype=object)
    reduced=np.asarray(cut['sector_prices'],dtype=object)
    assert np.array_equal(prices[:,1:],reduced[:,1:]) and max(prices[:,1])<=0 and not prices[:,2].any()
    loss=(prices[:,0]-reduced[:,0])*Q(1,scale)
    assert min(loss)>=0
    h=Q(norm['step'])
    k=norm['dimension']
    indices=np.arange(norm['intervals']-k)
    _,original,layout=geometry(TABLE)
    with np.load(original['cell_bins'],allow_pickle=False) as arc:
        strata=np.unique(arc['cells'][:,1]).astype(int)
    caps=sorted(set(strata.tolist())|set(fibres['caps']))
    assert caps==score['caps']
    Dlo,Dhi=[Q(norm['normalized_norm'][s]) for s in ('lower','upper')]
    rho=geom.RS
    # exp(3.638)>38 by a positive finite Taylor sum.
    log_upper=Q('3.638')
    assert sum(log_upper**i/factorial(i) for i in range(20))>k
    erasure_factor=rho*Q(norm['S'])*k*log_upper/(k-1)
    done=Q(0)
    early=Q(0)
    prefix=read(args.prefix) if args.prefix else None
    if prefix is not None:
        for p in (REDUCED,PRICES,NORM,FIBRES,FIT,TABLE,Path('h1_strip_free_prefix.py')):
            assert prefix['inputs'][p.name]==digest(p)
        assert prefix['cap'] in caps and prefix['cap']<=args.through_cap
    done_energy_lower=Q(0)
    tail_loss=Q(0)
    high_water=Q(0)
    records=[]
    tail_records=[]
    for j,cap in enumerate(caps):
        ids=layout(strata[np.searchsorted(strata,cap)],indices)
        active=np.unique(ids)
        if cap>args.through_cap:
            # If the remaining sector-price ceiling increases, charge its
            # increment to ALL subsequent erasure energy. On that event
            # the full trial necessarily also has a mark above the old cap.
            ceiling=max(loss[active])
            if ceiling>high_water:
                previous=caps[j-1] if j else 0
                mass=sum(Q(r['contribution']['upper']) for r in norm['layers'] if r['cap']>previous)
                tail_energy=min(erasure_factor*mass/Dlo,erasure_factor-done_energy_lower)
                assert tail_energy>=0
                tail_loss+=(ceiling-high_water)*tail_energy
                tail_records.append(dict(after_cap=previous,price_ceiling=str(ceiling),
                                         tail_full_norm_upper=str(mass),erasure_upper=str(tail_energy)))
                high_water=ceiling
            continue
        first=np.full(len(prices),len(indices),np.int64)
        np.minimum.at(first,ids,indices)
        price=[]
        for i in active:
            U=1/(Q(1,2)-rho*h*(int(first[i])+k-1)-Q(1,10000))
            price.append(Q(prices[i,0],scale)+Q(prices[i,1],scale)*U)
        row=score['layers'][j]
        E=Q(row['unweighted_contribution']['upper'])
        P=Q(row['priced_contribution']['lower'])
        a,b=affine_majorant(loss[active],price,E,P)
        expense=(a+b)*E-b*P
        assert expense>=0
        done+=expense/Dlo
        if prefix is not None and cap<=prefix['cap']:early+=expense/Dlo
        done_energy_lower+=Q(row['unweighted_contribution']['lower'])/Dhi
        records.append(dict(cap=cap,slope=str(b),intercept=str(a),normalized_loss_upper=sci_upper(expense/Dlo) if expense else '0',
                            unweighted=row['unweighted_contribution'],priced=row['priced_contribution']))
    effective=done
    if prefix is not None:
        effective=done-early+min(early,Q(prefix['prefix_loss_upper']))
    total=effective+tail_loss
    document=dict(scope='Continuous upper bound for the price loss on all 521 sectors; independent of every raw semiprime pairing identity. The cap quotient and the three other affine channels remain separate.',
              inputs={p.name:digest(p) for p in (Path(__file__),REDUCED,PRICES,NORM,FIBRES,FIT,TABLE,PRODUCER)},
              through_cap=args.through_cap,erasure_constant_upper=str(erasure_factor),layers=records,tail_layers=tail_records,
              completed_layers_loss_upper=sci_upper(effective),
              remaining_layers_loss_upper=sci_upper(tail_loss) if tail_loss else '0',
              all_layers_loss_upper=sci_upper(total))
    if prefix is not None:
        document['inputs'][args.prefix.name]=digest(args.prefix)
        document.update(direct_prefix_cap=prefix['cap'],direct_prefix_loss_upper=prefix['prefix_loss_upper'],
                        affine_envelope_prefix_loss_upper=sci_upper(early))
    if args.through_cap==caps[-1]:
        assert score['status']=='CONTINUOUS_CAP_SCORE_ENCLOSED'
        energies=score['normalized_sector_energies']
        direct=sum(c*Q(row[0]['upper']) for c,row in zip(loss,energies))
        lower=Q(score['cap_quotient']['lower'])-min(total,direct)
        document.update(direct_sector_loss_upper=sci_upper(direct),reduced_cap_lower_billionths=int((lower*10**9)//1))
    if args.check:assert document==read(args.output)
    else:args.output.write_text(json.dumps(document,indent=2)+'\n',newline='\n')
    print('all-sector continuous cost',float(total),'completed layers',float(effective),'remaining',float(tail_loss),flush=True)


if __name__=='__main__':
    main()
