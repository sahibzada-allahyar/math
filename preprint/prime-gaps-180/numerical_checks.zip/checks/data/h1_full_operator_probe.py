"""Explore the full cap-operator residual outside the finite trial basis.

Uses scrambled Sobol sampling and direct fiber checks. No rigorous bound
or support-restoration estimate is supplied by this experiment.
"""
from pathlib import Path
from fractions import Fraction as Q
from collections import defaultdict
import argparse,json,sys,time
import numpy as np
from h1_knn_harmonic import BACKEND,make_model,cap_shells
from incidence_multicap_spline_ritz import limited_shells
sys.path.insert(0,str(BACKEND/'experiments/variational_routes'))
from spline_cap_operator_residual import DiscreteCapOperator,run_probe,compensated_add


class MultiCapOperator(DiscreteCapOperator):
    def __init__(self,r,vectors,limits,domains,kappa,ell):
        original=list(r.shells['outer'])
        super().__init__(r,vectors[-1],domains,kappa,ell)
        self.limits=np.array(limits)
        self.radials=[(v*r.scale).reshape(len(r.signatures),r.nr)@r.radial_values for v in vectors]
        self.caps=np.array(sorted(set(map(int,self.caps))|set(limits)))
        self.survival=np.array([r.survival(int(c)) for c in self.caps])
        increments=np.diff(self.survival,axis=0)
        assert np.min(increments)>=0,'Nonmonotone category survival probabilities'
        self.category_cdf=self.survival/self.survival[-1]
        self.component_shells=[]
        by_cap=defaultdict(lambda:defaultdict(lambda:np.zeros(r.n)))
        try:
            for vector,limit in zip(vectors,limits):
                shells=limited_shells(original,limit)
                self.component_shells.append(shells)
                r.shells['outer']=shells
                for shell,part in zip(shells,r.scalar_affine(vector)):
                    for sig,value in part.items():by_cap[shell[2]][sig]+=value
        finally:r.shells['outer']=original
        self.outer_shell_caps=np.array(sorted(by_cap,reverse=True))
        self.signatures=sorted({s for part in by_cap.values() for s in part},key=lambda s:(sum(s),s))
        self.table=np.zeros((len(by_cap)+1,len(self.signatures),r.n))
        for j,cap in enumerate(self.outer_shell_caps):
            self.table[j+1]=self.table[j]
            for i,sig in enumerate(self.signatures):
                if sig in by_cap[cap]:self.table[j+1,i]+=by_cap[cap][sig]
        self.validation.update(caps=self.caps.tolist(),minimum_CDF_increment=float(increments.min()),
                               components=len(limits),combined_fiber_caps=self.outer_shell_caps.tolist())

    def component_polynomial(self,component,total,powers):
        value=np.zeros_like(total,dtype=float);correction=np.zeros_like(value)
        for row,sig in zip(self.radials[component],self.r.signatures):
            term=row[total].copy()
            for exponent in sig:term*=powers[exponent]
            value,correction=compensated_add(value,correction,term)
        return value

    def evaluate(self,indices,categories):
        r=self.r
        total=indices.sum(axis=1)
        keep=total<r.n
        keep&=categories.max(axis=1)<=self.outer_cap[np.minimum(total,r.n-1)]
        F=np.zeros(len(indices));A=np.zeros(len(indices))
        if not np.any(keep):return F,A,keep
        idx,cat,tot=indices[keep],categories[keep],total[keep]
        t,g=r.t[idx],r.g[idx]
        coordinate={e:t**e for e in self.exponents}
        powers={e:v.sum(axis=1) for e,v in coordinate.items()}
        maximum=cat.max(axis=1)
        for j,limit in enumerate(self.limits):
            F[keep]+=self.component_polynomial(j,tot,powers)*(maximum<=limit)
        ordered=np.partition(cat,-2,axis=1)[:,-2:]
        other_max=np.where(cat==ordered[:,1,None],ordered[:,0,None],ordered[:,1,None])
        other_index=tot[:,None]-idx
        remaining={e:powers[e][:,None]-coordinate[e] for e in self.exponents}
        fiber=self.fibers(other_index,other_max,remaining)
        A[keep]=r.h*np.sum(self.multipliers(other_index,other_max)*fiber/g,axis=1)
        return F,A,keep

    def direct_fiber_checks(self,count=12,seed=17087):
        r=self.r;rng=np.random.default_rng(seed);cases=[]
        proposal=r.g*r.g*np.exp(-15*r.t)*self.survival[-1]
        proposal/=proposal.sum()
        while len(cases)<count:
            idx=rng.choice(r.n,size=r.k-1,p=proposal);total=int(idx.sum())
            if total>=r.n:continue
            maximum=int(self.categories(idx,rng.random(r.k-1)).max())
            powers={e:float(np.sum(r.t[idx]**e)) for e in self.exponents}
            got=float(self.fibers(np.array([total]),np.array([maximum]),
                    {e:np.array([v]) for e,v in powers.items()})[0])
            jj=np.arange(r.n-total);tot=jj+total
            full={e:v+r.t[jj]**e for e,v in powers.items()}
            direct=absolute=0.
            for component,shells in enumerate(self.component_shells):
                poly=self.component_polynomial(component,tot,full)
                for shell in shells:
                    if maximum>shell[2]:continue
                    weight=r.g[jj]*r.survival(shell[2])[jj]*r.mask(shell,r.k)[tot]
                    direct+=float(weight@poly)
                    absolute+=float(weight@np.abs(poly))
            error=abs(got-direct)/max(abs(direct),absolute*1e-9,1e-250)
            assert error<5e-7,(got,direct,error)
            cases.append({'total_index':total,'maximum_category':maximum,'FFT':got,
                          'direct':direct,'relative_error':error})
        return {'count':count,'cases':cases,'max_relative_error':max(x['relative_error'] for x in cases)}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('candidate',type=Path)
    p.add_argument('--power',type=int,default=17)
    p.add_argument('--beta',type=float,default=15.)
    p.add_argument('--seeds',type=int,nargs='+',default=[17087,17088])
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();start=time.monotonic()
    a=json.loads(args.candidate.read_text())
    assert not a.get('harmonic_beta',0),'This probe currently covers the original coordinate profile.'
    r=make_model(a['dimension'],a['intervals'],a['specification'])
    limits=a['limits'];vectors=np.array(a['best_coefficients']).reshape(len(limits),r.nb)
    prior=json.loads((BACKEND/'results/incidence_multicap_spline_a6_n32768.json').read_text())
    domains={'L1':r.shells['enlarged']}
    for row in prior['supplied_domains']['domains']:
        domains[row['name']]=cap_shells(r,row['physical_radius'],row['delta'])
    row=a['rows'][a['best_index']];ell=row['hybrid_lambda']
    operator=MultiCapOperator(r,vectors,limits,domains,prior['kappa'],ell)
    fiber_check=operator.direct_fiber_checks()
    reference={'I':row['mass'],'quotient':row['cap_quotient_without_penalty'],
               'F_rhoA':row['mass']*row['cap_quotient_without_penalty']}
    results=[]
    for seed in args.seeds:
        result,blocks=run_probe(operator,reference,args.power,seed,args.beta,11)
        results.append(result)
    out={'status':'UNCERTIFIED_FULL_CAP_OPERATOR_PROBE_NOT_A_BOUND',
         'candidate':args.candidate.name,'dimension':r.k,'intervals':r.N,
         'reference':reference,'validation':operator.validation,'direct_fiber_check':fiber_check,
         'results':results,'seconds':time.monotonic()-start,
         'limitations':['Scrambled Sobol estimates, not rigorous bounds.',
                        'No support-restoration loss estimate.',
                        'A nonzero residual alone does not prove an improvement.']}
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'event':'COMPLETE','seconds':out['seconds'],
        'residual_norms':[x['qshift_residual_norm'] for x in results],
        'quotients':[x['quotient'] for x in results]}),flush=True)


if __name__=='__main__':main()
