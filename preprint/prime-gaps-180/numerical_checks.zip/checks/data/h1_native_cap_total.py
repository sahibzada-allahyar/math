"""Recover the full H1 quotient from a complete sequence of signed native layer integrals."""
import argparse
from fractions import Fraction as Q
from math import ceil,floor
from pathlib import Path
import json

from h1_combined_margin import prefix_hash, margin
from h1_margin_fallback import SCORE, FIT, PRICES, TABLE, FIBRES, NORM, digest, read
from h1_dickman_taylor import native_inventory

OUTPUT=Path('h1_native_cap_total.json')
FALLBACK=Path('h1_margin_fallback_65536.json')
LEDGER=Path('h1_outer_laplace_refined_budget.json')


def enclosure(row):
    a,b=(Q(row[k]) for k in ('lower','upper'))
    assert a<=b
    return a,b


def interval(a,b):
    return dict(lower=str(a),upper=str(b))


def recover():
    src,norm=read(SCORE),read(NORM)
    caps,n,inventory=native_inventory()
    assert src['status'] in ('INCOMPLETE_CONTINUOUS_CAP_SCORE','CONTINUOUS_CAP_SCORE_ENCLOSED')
    assert [r['cap'] for r in src['layers']]==src['caps']==caps and src['inventory_inputs']==inventory
    assert n==src['intervals']-src['dimension'] and src['checks']['direct_signed_square_and_price_checks']==27
    for name,h in src['inputs'].items():assert digest(Path(name))==h
    assert norm['status']=='ORDINARY_NORM_ENCLOSED' and norm['inputs'][FIT.name]==digest(FIT)
    dlo,dhi=enclosure(norm['normalized_norm'])
    assert dlo>0
    def total(field):
        rows=[enclosure(r[field]) for r in src['layers']]
        return sum(a for a,b in rows),sum(b for a,b in rows)
    a,b=total('priced_contribution')
    c,d=enclosure(src['partial_priced_numerator'])
    a,b=max(a,c),min(b,d)
    assert 0<a<=b
    u,v=total('unweighted_contribution')
    assert 0<u<=v
    return interval(a/dhi,b/dlo),interval(u/dhi,v/dlo),src


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',type=Path,default=OUTPUT)
    ap.add_argument('--check',action='store_true')
    args=ap.parse_args()
    cap,ordinary,src=recover()
    fallback,ledger=read(FALLBACK),read(LEDGER)
    assert fallback['inputs'][LEDGER.name]==digest(LEDGER)
    assert fallback['cap_inputs']==src['inputs'] and fallback['inventory_inputs']==src['inventory_inputs']
    prefix=src['layers'][:fallback['layers_in_prefix']]
    assert fallback['cap_schedule']==src['caps'] and prefix_hash(prefix)==fallback['prefix_sha256']
    finite=Q(read(FIT)['families']['mixed']['lower_billionths'],10**9)
    report=margin(finite,Q(cap['lower']),Q(ledger['partial_upper']),ledger['unresolved_active_ordered_pairs'],
                  Q(fallback['generic_divisor_charge_upper']))
    paths=[Path(__file__),SCORE,FIT,PRICES,TABLE,FIBRES,NORM,FALLBACK,LEDGER]
    out=dict(scope='Full continuous original-price quotient, reconstructed from every signed native layer. This receipt does not require sector-energy estimates.',
             inputs={p.name:digest(p) for p in paths},layers=len(src['layers']),cap_quotient=cap,
             ordinary_erased_quotient=ordinary,cap_lower_trillionths=floor(Q(cap['lower'])*10**12),
             cap_upper_trillionths=ceil(Q(cap['upper'])*10**12),benchmark=report)
    if args.check:assert out==read(args.output)
    else:args.output.write_text(json.dumps(out,indent=2)+'\n',newline='\n')
    print(out['cap_lower_trillionths'],out['cap_upper_trillionths'],'margin before repricing',report['M'],flush=True)


if __name__=='__main__':main()
