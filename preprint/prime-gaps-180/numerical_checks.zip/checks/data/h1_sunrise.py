"""Test the equal-mass sunrise graph and the Frobenius traces of its cubic on the frozen H1 spiral."""
import argparse
import json
from pathlib import Path
import numpy as np
from numpy.polynomial.legendre import leggauss
from h1_coordinate_shape import configured
from h1_harmonic_sector_probe import forms,sample
from h1_joint_weight import DIGEST,HERE,JointWeight,train
from h1_spiral_modes import FaceSpiral,radial_coordinate


PRIMES=(17,31)
LIMIT=8.8


def sunrise(t,order=32):
    """Dimensionless two-loop amplitude, evaluated on six equal ordered sectors."""
    nodes,weight=leggauss(order)
    nodes=(1+nodes)/2
    w,v=np.meshgrid(nodes,nodes,indexing='ij')
    numerator=1.5*np.outer(weight,weight)
    denominator=(1+w*(1+v))*(1+v+w*v)
    return np.array([(numerator/(denominator-z*w*v)).sum() for z in np.atleast_1d(t)])


def traces(p):
    # Three points at infinity. For x=-1 each smooth fibre has one affine root.
    x=np.arange(p-1)
    chi=np.full(p,-1);chi[(np.arange(1,p)**2)%p]=1;chi[0]=0
    params=np.array([t for t in range(p) if t not in (0,1,9)])
    b=(x+1)**2+(1-params[:,None])*x
    disc=(b*b-4*x*(x+1)**2)%p
    counts=3+1+(1+chi[disc]).sum(axis=1)
    return params,p+1-counts


class Kernels:
    def __init__(self):
        self.grid=np.linspace(0,1,4097)
        j=sunrise(LIMIT*self.grid)
        self.real=j/j[0]-1
        self.finite={};self.shuffle={}
        for p in PRIMES:
            _,a=traces(p)
            self.finite[p]=a/(2*np.sqrt(p))
            self.shuffle[p]=np.random.default_rng(628367+p).permutation(self.finite[p])

    def fields(self,z):
        # Label the good residues in increasing order before evaluating the exact trace.
        z=np.clip(z,0.,1.)
        real=[np.interp(x,self.grid,self.real) for x in (z,1-z)]
        smooth=[-np.log1p(-(LIMIT/9)*x) for x in (z,1-z)]
        actual=[];shuffled=[]
        for p in PRIMES:
            bins=np.minimum((len(self.finite[p])*z).astype(int),len(self.finite[p])-1)
            actual.append(self.finite[p][bins]);shuffled.append(self.shuffle[p][bins])
        return smooth,real,actual,shuffled


class SieveSunrise:
    def __init__(self,spiral,ref):
        self.spiral=spiral
        assert ref['labels']==spiral.labels
        self.vector=np.array(ref['rows']['radial_spiral']['coefficients'])
        self.kernels=Kernels()
        self.set_labels('frozen_radial_spiral',('mean','cos','sin'))

    def set_labels(self,reference,parts):
        self.labels=['original',reference]
        self.ids={}
        for name in ('polynomial','logarithm','real','trace','permuted','coupled','placebo_coupled'):
            start=len(self.labels)
            self.labels.extend(f'{name}_{j}_{part}' for j in (0,1) for part in parts)
            self.ids[name]=list(range(start,len(self.labels)))

    def blocks(self,z):
        z=np.clip(z,0.,1.)
        smooth,real,actual,shuffled=self.kernels.fields(z)
        return ([z,z*z],smooth,real,actual,shuffled,
                [a*b for a,b in zip(real,actual)],[a*b for a,b in zip(real,shuffled)])

    def __call__(self,idx,cat,F=None,action=None):
        h=self.spiral(idx,cat)@self.vector
        rest=idx.sum(axis=1)[:,None]-idx
        u=self.spiral.u[idx];eta=self.spiral.eta[rest]
        z=(u+eta)/2
        phase=self.spiral.spin[0][idx]*self.spiral.spin[1][rest]
        amp=u/u.sum(axis=1)[:,None]
        out=[np.ones(len(h)),h]
        for fields in self.blocks(z):
            for f in fields:
                w=amp*f;s=(w*phase).sum(axis=1)
                out.extend([h*w.sum(axis=1),h*s.real,h*s.imag])
        return np.column_stack(out)

    def groups(self):
        def ids(*keys):
            return [1]+[i for k in keys for i in self.ids[k]]
        smooth=('polynomial','logarithm')
        return dict(spiral=[1],polynomial=ids('polynomial'),smooth=ids(*smooth),
                    real=ids(*smooth,'real'),trace=ids(*smooth,'trace'),placebo_trace=ids(*smooth,'permuted'),
                    additive=ids(*smooth,'real','trace'),joint=ids(*smooth,'real','trace','coupled'),
                    placebo_joint=ids(*smooth,'real','permuted','placebo_coupled'))


class EndpointSunrise(SieveSunrise):
    def __init__(self,bank,record):
        self.bank=bank;self.kernels=Kernels()
        self.vector=np.array(record['coefficients']['joint_unpenalized'])
        self.q=bank.r.rho*bank.r.t
        self.u=radial_coordinate(self.q)
        self.set_labels('frozen_odd_fourier',('mean','signed_difference','product'))

    def __call__(self,idx,cat,F=None,action=None):
        h=self.bank(idx,cat)@self.vector
        ends=idx[:,-2:];q=self.q[ends]
        # The same bulk sum is used on both sides of the endpoint exchange.
        eta=np.clip((self.q[idx[:,:-2]].sum(axis=1)[:,None]+q[:,::-1]-.225)/.055,0.,1.)
        sign=np.sign(ends[:,0]-ends[:,1])
        out=[np.ones(len(h)),h]
        for fields in self.blocks((self.u[ends]+eta)/2):
            for f in fields:
                a,b=f.T
                out.extend([h*(a+b)/2,h*sign*(a-b),h*a*b])
        return np.column_stack(out)


def spiral_setup():
    refpath=HERE/'h1_boundary_spiral_validation.json';ref=json.loads(refpath.read_text())
    prior=HERE/ref['prior'];assert DIGEST(prior)==ref['prior_sha256'];old=json.loads(prior.read_text())
    coord=HERE/old['coordinate'];dual=HERE/old['dual']
    assert DIGEST(coord)==old['coordinate_sha256'] and DIGEST(dual)==old['dual_sha256']
    op,feature,ctrl=configured(dual)
    core=JointWeight(op.r,json.loads(coord.read_text()));shape=SieveSunrise(FaceSpiral(op,core,prior,ctrl,dual),ref)
    return op,shape,feature.base,refpath,ref['seeds']+old['seeds']


def endpoint_setup():
    from h1_spiral_exchange import FourierBank,setup_exchange
    src=HERE/'h1_spiral_bank_frozen.json';frozen=json.loads(src.read_text())
    srcbank=HERE/frozen['source'];m=json.loads(srcbank.read_text());assert DIGEST(srcbank)==frozen['source_sha256']
    prior=HERE/m['prior'];assert DIGEST(prior)==m['prior_sha256']
    op,core,old,base,inputs=setup_exchange(prior,sector_dual=True)
    bank=FourierBank(op.r,old,core)
    assert m['labels']==bank.labels and inputs==m['sector_inputs'] and base==m['base']
    return op,EndpointSunrise(bank,frozen),base,src,m['seeds']+old['seeds']


def collect(args):
    op,shape,base,refpath,used=endpoint_setup() if args.endpoints else spiral_setup()
    if args.loops:
        from h1_sunrise_loops import OrbitSunrise
        shape=OrbitSunrise(shape)
    seeds=list(range(args.seed,args.seed+args.runs))
    assert not set(seeds)&set(used)
    raw=[]
    for s in seeds:
        raw.append(sample(op,s,args.power,args.tilt,base,False,shape,random_marked_label=True))
        print(s,flush=True)
    path=args.output.with_suffix('.npz');np.savez_compressed(path,raw=np.array(raw))
    return dict(scope=f'Sampled {op.r.k}-shift sector-dual forms; label 0 provides the constant calibration.',
                seeds=seeds,power=args.power,tilt=args.tilt,base=base,labels=shape.labels,groups=shape.groups(),
                sample=path.name,sample_sha256=DIGEST(path),spiral=refpath.name,spiral_sha256=DIGEST(refpath),
                primes=PRIMES,limit=LIMIT,quadrature_order=32,table_intervals=4096)


def fit(data):
    m,raw=data;g,b=forms(raw.mean(0),m['base'])
    rows={}
    for k,ids in m['groups'].items():
        v,rank=train(g,b,ids)
        rows[k]=dict(coefficients=v.tolist(),rank=rank)
    return rows


def read(path):
    m=json.loads(path.read_text());other=path.with_name(m['sample'])
    assert DIGEST(other)==m['sample_sha256']
    with np.load(other,allow_pickle=False) as z:return m,z['raw']


def report(args):
    training=read(args.training);meta=training[0];vectors=fit(training);tests={};used=set(meta['seeds'])
    for path in args.test:
        m,raw=read(path)
        assert not used.intersection(m['seeds']);used.update(m['seeds'])
        assert all(m[k]==meta[k] for k in ('base','labels','groups','spiral_sha256','primes','limit'))
        g,b=forms(raw.mean(0),m['base']);parts=[forms(x,m['base']) for x in raw]
        rows={}
        for name,trial in vectors.items():
            v=np.array(trial['coefficients'])
            ss=[float((v@B@v)/(v@G@v)) for G,B in parts]
            rows[name]=dict(score=float((v@b@v)/(v@g@v)),scrambles=ss)
        for row in rows.values():
            row['comparisons']={}
            for name,ctrl in rows.items():
                diff=np.subtract(row['scrambles'],ctrl['scrambles'])
                row['comparisons'][name]=dict(gain=row['score']-ctrl['score'],paired_se=float(diff.std(ddof=1)/np.sqrt(len(diff))))
        tests[path.name]=dict(sha256=DIGEST(path),rows=rows)
    return dict(scope='Frozen trial scores on disjoint scrambles, with paired descriptive errors.',
                training=args.training.name,training_sha256=DIGEST(args.training),fits=vectors,tests=tests)


def check():
    for p in PRIMES:
        params,a=traces(p);x,y=np.indices((p,p))
        counts=[3+int(np.sum(((x+y+1)*(x*y+x+y)-t*x*y)%p==0)) for t in params]
        np.testing.assert_array_equal(a,p+1-np.array(counts))
        assert np.all(a*a<=4*p)
    # The exact value at t=1 follows from the factorization into three linear terms.
    np.testing.assert_allclose(sunrise([1.]),np.pi**2/4,rtol=1e-13)
    t=np.linspace(0,LIMIT,129)
    np.testing.assert_allclose(sunrise(t),sunrise(t,64),rtol=2e-12)
    k=Kernels();u=(np.arange(4096)+.5)/4096
    err=np.max(np.abs(np.interp(u,k.grid,k.real)-(sunrise(u*LIMIT,40)/sunrise([0],40)[0]-1)))
    assert err<5e-5
    print('Direct point counts, Hasse inequalities, known integral at t=1, quadrature refinement and interpolation passed. Maximum midpoint interpolation discrepancy:',err)


def check_endpoints():
    op,shape,_,_,_=endpoint_setup()
    rng=np.random.default_rng(19731)
    idx=rng.integers(0,op.r.n//50,(80,39));cats=op.categories(idx,rng.random(idx.shape))
    idx[0,-2:]=11
    v=shape(idx,cats)[:,1:];order=[*range(37),38,37]
    np.testing.assert_allclose(v,-shape(idx[:,order],cats[:,order])[:,1:],rtol=1e-12,atol=1e-12)
    np.testing.assert_array_equal(v[0],0.)
    print('All 43 fitted endpoint directions reverse under exchange and vanish at tied endpoints.')


def main():
    parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('sample');p.add_argument('--seed',type=int,required=True);p.add_argument('--runs',type=int,default=8)
    mode=p.add_mutually_exclusive_group()
    mode.add_argument('--endpoints',action='store_true');mode.add_argument('--loops',action='store_true')
    p.add_argument('--power',type=int,required=True);p.add_argument('--tilt',type=float,required=True)
    p.add_argument('--output',type=Path,required=True)
    p=sub.add_parser('report');p.add_argument('training',type=Path);p.add_argument('test',type=Path,nargs='+')
    p.add_argument('--output',type=Path,required=True);sub.add_parser('check');sub.add_parser('check-endpoints');a=parser.parse_args()
    if a.command=='check':check();return
    if a.command=='check-endpoints':check_endpoints();return
    out=collect(a) if a.command=='sample' else report(a)
    a.output.write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
