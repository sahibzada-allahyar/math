"""Certified full-cap and full-radius weights for the deleted negative prime form."""
import argparse
from fractions import Fraction as Q
from functools import cache
from math import ceil
from pathlib import Path
import json

import numpy as np

from h1_degree6_native_schur_support import Cap, feasible, inputs, replay_limits
from legacy_gram import EXTRA,corrected_baseline

UNIT = 10**7
PIN = 'c9d947bdea94e048f532d88f88bdb6030b964ba92e6ace3a2b225594b3406229'


@cache
def native():
    rate,scale,caps = inputs()
    limits = replay_limits(2)
    rows=[]
    for c in caps:
        last = next(x for b,x in limits if c.upper<=b)
        j=np.arange(last+1)
        p=np.zeros(last+1)
        for a,b,u,v in c.sectors:
            p[a:b+1]=(float(u)+float(v)/(.4999-float(rate)*(j[a:b+1]+38)))/scale
        upper=np.maximum.accumulate(39*float(rate)*(last+1-j)*np.maximum(0,-p))
        rows.append((c,last,upper))
    return rows


@cache
def factor(index,j):
    cap,last,proposals=native()[index]
    j=min(j,last)
    if j<0:return Q(0)
    # Clip occupied price rows while leaving the true insertion length L-r+1 intact.
    sectors=tuple((a,min(b,j),x,y) for a,b,x,y in cap.sectors if a<=j)
    truncated=Cap(cap.upper,last,sectors)
    rate,scale,_=inputs()
    value=min(Q(2),Q(ceil(float(proposals[j])*UNIT),UNIT))
    while not feasible(truncated,last,value,rate,scale):
        value+=Q(1,UNIT)
    assert value<=2
    return value


@cache
def grouped(lower,upper,full_hi):
    same=Q(0)
    exceptional=Q(0)
    previous=0
    for i,(cap,_,_) in enumerate(native()):
        if previous>=upper:break
        if cap.upper>lower:
            same=max(same,factor(i,full_hi))
        # A single erased site may carry the unique full maximum.
        exceptional=max(exceptional,factor(i,full_hi-lower))
        previous=cap.upper
    return (38*same+max(same,exceptional))/39


def check():
    examples=[(0,9764,112000),(19529,29293,124000),(29293,39058,128000),
              (39058,46567,130964),(63177,64599,124000),(65536,78116,117732)]
    return [(a,b,j,str(grouped(a,b,j))) for a,b,j in examples]


def collect(root,ellipsoid):
    manifest=json.loads((root/'manifest.json').read_text())
    assert manifest['pin']==PIN
    caps=sorted({a for a,_ in manifest['pairs']})
    lower=dict(zip(caps,[0]+caps[:-1]))
    dust=Q(0);negative=Q(0);count=0
    for cap,edge in manifest['pairs']:
        receipt=root/f'{cap}_{edge}.json'
        if not receipt.exists(): continue
        item=json.loads(receipt.read_text())
        assert item['pin']==PIN and (item['cap'],item['edge'])==(cap,edge)
        count+=1
        obj=corrected_baseline(item['result'])
        if item['status']=='impossible':
            assert obj['outward_scaled_upper']==0
            continue
        assert item['status']=='enclosed'
        start,stop=obj['radial_output_bins']
        lo,hi=obj['possible_J']
        width=obj['site_radial']
        radius=obj['independent_round_radius']*width
        stride=manifest['record']['parameters']['count']
        full=[(max(lo,k*width-radius),min(hi,(min(stop+1,k+stride)-1)*width+radius),Q(b))
              for k,b in zip(range(start,stop+1,stride),obj['panel_bounds_before_capture'],strict=True)]
        improved={}
        if ellipsoid and (ellipsoid/receipt.name).exists():
            extra=json.loads((ellipsoid/receipt.name).read_text())
            assert extra['pin']==PIN and (extra['cap'],extra['edge'])==(cap,edge)
            if extra.get('extra_gram_radius')==EXTRA:
                for row in extra['rows']:
                    improved[row['lo'],row['hi']]=min(Q(row['ellipsoid_bound']),Q(row['center_bound']))
        capture=Q(obj['minimum_capture'])
        for j,k,b in full:
            bound=min(b,improved.get((j,k),b))/capture
            assert bound>=0
            dust+=bound
            negative+=bound*grouped(lower[cap],cap,k)
    def rounded_upper(x):
        scale=10**15
        return str(Q(ceil(x*scale),scale))
    return dict(panels_available=count,panels_required=len(manifest['pairs']),extra_gram_radius=EXTRA,
                scaled_deleted_mass_partial_upper=rounded_upper(dust),
                scaled_negative_schur_partial_upper=rounded_upper(negative),
                ratio_of_the_two_upper_sums=float(negative/dust) if dust else None)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--receipts',type=Path)
    p.add_argument('--ellipsoid',type=Path)
    args=p.parse_args()
    print(json.dumps(collect(args.receipts,args.ellipsoid) if args.receipts else check(),indent=2))
