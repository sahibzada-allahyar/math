"""Explore a pair-subtraction criterion for prime gaps at most 180.

The double-fibre statistic is a profile diagnostic. A bound on the weighted
simultaneous primality of two shifts for this hybrid sieve is still required.
"""
import argparse
from collections import defaultdict
from fractions import Fraction
from itertools import combinations
import json
from pathlib import Path

import numpy as np
from scipy.fft import rfft, irfft
from h1_knn_harmonic import BACKEND, make_model, cap_shells, scalar_replay
from fast_fragment_ritz import fiber_splits
from incidence_multicap_spline_ritz import limited_shells


HERE = Path(__file__).resolve().parent


def geometry(shifts):
    k = len(shifts)
    assert len(set(shifts)) == k and shifts == sorted(shifts)
    missing = {}
    for p in range(2, k + 1):
        if any(p % d == 0 for d in range(2, int(p**.5) + 1)):
            continue
        residues = {v % p for v in shifts}
        missing[p] = next(v for v in range(p) if v not in residues)
    bad = [list(pair) for pair in combinations(shifts, 2) if pair[1] - pair[0] > 180]
    window = max(sum(start <= v <= start + 180 for v in shifts) for start in shifts)
    return dict(diameter=shifts[-1]-shifts[0], bad_pairs=bad,
                max_points_in_180_window=window, missing_residues=missing)


def first_fibres(r, vector, limits, marked_power=0):
    """Integrate F times the specified power of the erased coordinate."""
    original = r.shells['outer']
    coordinate_weight = r.g
    first = defaultdict(lambda: defaultdict(lambda: np.zeros(r.n)))
    try:
        r.g = coordinate_weight * r.t**marked_power
        for part, limit in zip(vector.reshape(-1, r.nb), limits):
            r.shells['outer'] = limited_shells(original, limit)
            for shell, rows in zip(r.shells['outer'], r.scalar_affine(part)):
                for signature, values in rows.items():
                    first[shell[2]][signature] += values
    finally:
        r.shells['outer'] = original
        r.g = coordinate_weight
    return first


def double_fibres(r, vector, limits, marked_power=0, first=None):
    """Integrate two marked coordinates with their fragment-cap survival."""
    if first is None:
        first = first_fibres(r, vector, limits)
    return erase_next(r,first,1,marked_power)


def erase_next(r,first,previous_order,marked_power=0):
    """Integrate one further marked coordinate in an already erased table."""
    previous_total=(np.arange(r.n)+(r.k-previous_order)/2)*r.h
    other_total = (np.arange(r.n) + (r.k-previous_order-1)/2) * r.h
    forward = np.exp(r.fiber_tilt * (previous_total-r.center))
    backward = np.exp(-r.fiber_tilt * (other_total-r.center))
    second = {}
    for cap, part in first.items():
        marked = r.g * r.t**marked_power * r.survival(cap) * np.exp(-r.fiber_tilt*r.t)
        kernels = {}
        rows = defaultdict(lambda: np.zeros(r.n))
        for signature, values in part.items():
            transformed = rfft(values*forward, r.L)
            for remaining, power, multiplicity in fiber_splits(signature):
                if power not in kernels:
                    kernels[power] = rfft((marked*r.t**power)[::-1], r.L)
                corr = irfft(transformed*kernels[power], r.L)[r.n-1:2*r.n-1]
                rows[remaining] += multiplicity * corr * backward
        second[cap] = dict(rows)
    return second, other_total


def double_fibre_form(r, rows, total):
    # Above a fixed lower cut the summed fibres have one common polynomial.
    # Moment differences integrate that square over disjoint maximum layers.
    caps = sorted(rows, reverse=True)
    cumulative = defaultdict(lambda: np.zeros(r.n))
    form = 0.
    for index, cap in enumerate(caps):
        for sig, values in rows[cap].items():
            cumulative[sig] += values
        lower = caps[index+1] if index+1 < len(caps) else None
        terms = list(cumulative.items())
        density = np.zeros(r.n)
        for j, (sig, values) in enumerate(terms):
            for i in range(j+1):
                other, coeff = terms[i]
                signature = tuple(sorted(sig+other))
                moment = r.moment(cap, r.k-2, signature)
                if lower is not None:
                    moment = moment - r.moment(lower, r.k-2, signature)
                density += (1 if j == i else 2) * values * coeff * moment
        form += density @ np.exp(r.tilt*(total-r.center))
        r.clear_cache()
    return float((r.h/r.Z)**2 * form)


def direct_fibre_check(r, vector, limits, rows):
    # Independently sum over all two marked grid positions at small N.
    # Check several fixed common-coordinate configurations and cap categories.
    rng = np.random.default_rng(183)
    fixed_cases = []
    shells = [limited_shells(r.shells['outer'], limit) for limit in limits]
    radial = [(v*r.scale).reshape(-1, r.nr) @ r.radial_values
              for v in vector.reshape(-1, r.nb)]
    for _ in range(8):
        fixed = rng.integers(0, 6, size=r.k-2)
        total = int(fixed.sum())
        category = int(rng.choice(list(rows)))
        powers = {e: sum(r.t[fixed]**e) for sig in r.signatures for e in sig}
        table_value = 0.
        for cap, part in rows.items():
            if cap < category:
                continue
            for sig, values in part.items():
                table_value += values[total] * np.prod([powers[e] for e in sig])
        sum_index,u = np.tril_indices(r.n-total)
        v = sum_index-u
        full = total+u+v
        direct = 0.
        for shell_list, coeffs in zip(shells, radial):
            poly = np.zeros(len(full))
            for sig, coeff in zip(r.signatures, coeffs):
                term = coeff[full].copy()
                for e in sig:
                    term *= powers[e]+r.t[u]**e+r.t[v]**e
                poly += term
            for shell in shell_list:
                if shell[2] < category:
                    continue
                survival = r.survival(shell[2])
                direct += sum(poly*r.mask(shell,r.k)[full]*r.g[u]*r.g[v]*survival[u]*survival[v])
        error = float(abs(direct-table_value)/max(abs(direct),1.e-8))
        assert error < 1.e-6, (direct,table_value,error)
        fixed_cases.append(dict(total_index=total, cap_category=category, relative_error=error))
    return fixed_cases


def setup(k, N, source, prior):
    r = make_model(k, N, source['specification'])
    maximum = max(row[2] for row in r.shells['outer'])
    limits = sorted({min(maximum, int(Fraction(c)//r.exact_step)) for c in ['.3788','.4745']} | {maximum})
    domains = {'L1':r.shells['enlarged']}
    for row in prior['supplied_domains']['domains']:
        domains[row['name']] = cap_shells(r, row['physical_radius'], row['delta'])
    return r, limits, domains


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--intervals', type=int, default=16384)
    parser.add_argument('--dimensions', type=int, nargs='+', default=[39,40,41,42,43])
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    source = json.loads((HERE/'h1_k39_control_n32768.json').read_text())
    prior = json.loads((BACKEND/'results/incidence_multicap_spline_a6_n32768.json').read_text())
    tuples = json.loads((HERE/'endpoint_tuple_inputs.json').read_text())
    vector = np.asarray(source['best_coefficients'])
    ell = source['rows'][source['best_index']]['hybrid_lambda']
    test, limits, _ = setup(39,256,source,prior)
    fibres, _ = double_fibres(test,vector,limits)
    check = direct_fibre_check(test,vector,limits,fibres)
    report = dict(status='UNCERTIFIED_PAIR_BUDGET_NO_ARITHMETIC_PAIR_BOUND',
                  intervals=args.intervals, vector_source='h1_k39_control_n32768.json',
                  direct_small_grid_checks=check, rows=[],
                  limitations=['K-dependent cap model and restoration need verification.',
                  'The ratio for two marked coordinates is a profile statistic, not a bound on prime pairs.',
                  'No prime-pair multiplier is assumed or inherited from another sieve.'])
    for k in args.dimensions:
        row = geometry(tuples[str(k)]['shifts'])
        r,limits,domains = setup(k,args.intervals,source,prior)
        mass,forms = scalar_replay(r,vector,limits,domains)
        quotient = r.rho*(forms[0]+(1-ell)*forms[1]+(1-1/ell)*prior['kappa']*forms[2])/mass
        fibres,total = double_fibres(r,vector,limits)
        ratio = r.rho**2 * double_fibre_form(r,fibres,total)/mass
        assert ratio > 0 and mass > 0
        count = len(row['bad_pairs'])
        row.update(k=k, cap_quotient=float(quotient), mass=float(mass), ell=ell,
                   double_fibre_physical_ratio=float(ratio),
                   normalized_pair_budget_before_restoration=float((quotient-1)/count),
                   break_even_multiplier_before_restoration=float((quotient-1)/(count*ratio)))
        report['rows'].append(row)
        args.output.write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps({'event':'PAIR_BUDGET','k':k,'wide_pairs':count,'cap':quotient,
                          'double_ratio':ratio,'critical':row['break_even_multiplier_before_restoration']}),flush=True)


if __name__ == '__main__':
    main()
