"""Replay the saved labelled degree-six vector on ideal prime triangles."""
import argparse
import contextlib
from fractions import Fraction as Q
from hashlib import sha256
import io
import json
from math import ceil, factorial, floor
from pathlib import Path

import numpy as np

import h1_two_source_endpoints as TS
from h1_radial_threshold import enclose, TICKS


VECTOR = TS.HERE / 'ts_s39a6.npz'
LEVELS = [Q('.525303'), Q(143,272), Q(10,19), Q('.5284'), Q('.5291')]
# Li, arXiv:2602.20917v3, Tables 6.1 and 6.2, printed lower masses
# at levels .5264,.5265,...,.5284. Every lower level is overgranted
# unit prime identities to 10/19 in the combined diagnostic.
LI = dict(zip([Q(i,10000) for i in range(5264,5285)], map(Q,
    ('.7407 .7259 .7141 .6947 .6807 .6662 .6509 .6312 .6107 .5903 '
     '.5654 .5374 .5135 .4760 .4291 .3856 .3354 .2833 .2189 .1489 .0648').split())))


def scalar_mass(L, vector):
    """Integrate each incremental cap component against the full signed sum."""
    r = L.r
    parts = vector.reshape(L.B, L.B, L.ncomp, len(L.sigs), L.nr)
    parts = (parts * L.sig_scale[None,None,None,:,None]) @ r.radial_values
    prefix = np.zeros_like(parts[:,:,0])
    endpoints = [(m,p) for m in range(L.B) for p in range(m, L.B)]
    lookup = np.array([[endpoints.index(tuple(sorted((m,p)))) for p in range(L.B)]
                       for m in range(L.B)])
    moment_terms = {}
    for i, s in enumerate(L.sigs):
        for j, t in enumerate(L.sigs[:i+1]):
            moment_terms.setdefault(tuple(sorted(s+t)), []).append((i,j))
    mass = 0.
    for c in reversed(range(L.ncomp)):
        after = prefix + parts[:,:,c]
        for shell in L.comp_shells[c]:
            cap = shell[2]
            law = [L.ue(cap,*p) for p in endpoints]
            weight = r.outer_exp*r.mask(shell, r.k)
            for signature, terms in moment_terms.items():
                core = r.moment(cap, L.core, signature)
                first = [L.conv(core, u) for u in law]
                kernel = np.empty((len(law), len(law), r.n))
                for i in range(len(law)):
                    for j in range(i+1):
                        kernel[i,j] = kernel[j,i] = L.conv(first[i], law[j])*weight
                labelled = kernel[lookup[:,:,None,None], lookup[None,None,:,:]]
                for i,j in terms:
                    def term(amps):
                        return np.einsum('acn,bdn,abcdn->', amps[:,:,i], amps[:,:,j],
                                         labelled, optimize=False)
                    mass += (1 if i == j else 2) * (term(after)-term(prefix))
            r.clear_cache()
        prefix = after
    return float(mass)


def model(frame, cells, angular, shapes):
    with contextlib.redirect_stdout(io.StringIO()):
        r, limits, sub, *_ = TS.stored_model(39, cells, angular, frame)
        return TS.E.Labelled(39, cells, angular, shapes, model=(r, limits, sub))


def check_scalar(frame):
    L = model(frame, 512, 2, [0.,300.])
    v = np.random.default_rng(182).normal(size=L.N)
    dense = v @ L.mass() @ v
    scalar = scalar_mass(L,v)
    assert np.isclose(dense, scalar, rtol=1e-9, atol=0), (dense,scalar)


def split_uniform_offsets(face, count):
    """Convolve binary64 input masses exactly with floor(sum of count uniforms)."""
    a = [1]
    for n in range(2, count+1):
        a = [(j+1)*(a[j] if j < n-1 else 0) + (n-j)*(a[j-1] if j else 0)
             for j in range(n)]
    assert sum(a) == factorial(count)
    masses = list(map(Q, map(float, face)))
    scale = max(x.denominator for x in masses)
    ints = [x.numerator*(scale//x.denominator) for x in masses]
    split = np.convolve(np.array(ints,dtype=object), np.array(a,dtype=object))
    return [Q(x,scale*factorial(count)) for x in split]


def screen(frame, cells, vector, detailed, localize):
    L = model(frame, cells, 6, [0.,'p2',300.])
    mass = scalar_mass(L, vector)
    # Full-face densities change only where the amplitudes change.
    caps = sorted({shell[2] for comp in L.comp_shells for shell in comp})
    L.layer_caps = lambda extra: caps
    layers, pair = L.densities_and_pair(vector)
    r = L.r
    energies = np.sum(list(layers.values()),axis=0)*r.rho/mass
    step = r.exact_step*Q(r.geometry['parameters']['rho_star'])
    return compare(cells,mass,energies,pair/mass,caps,step,Q(r.geometry['parameters']['physical_outer']),
                   detailed,localize)


def compare(cells,mass,energies,pair,caps,radial_step,radius,detailed,localize,merge=1):
    negative = -np.minimum(0., energies).sum()
    assert negative < 1e-10
    energies = np.maximum(0., energies)
    if localize:
        retained = 38
        automatic = retained - (energies.shape[1]-1)//int(min(caps))
        assert automatic == 36
        spectra = [split_uniform_offsets(face, automatic) for face in energies]
        width = retained-automatic+1
    else:
        spectra = [list(map(Q,map(float,face))) for face in energies]
        width = 38
    rows = []
    thresholds, mixtures = {}, {}
    for mode, offset, retreat in [('outward',0,Q(0)),('inward',width,Q('.0001'))]:
        fn = floor if mode == 'outward' else ceil
        ticks = np.array([fn((i+offset)*radial_step*TICKS) for i in range(len(spectra[0]))])
        tables = []
        for spectrum in spectra:
            if merge>1:
                # Across each merged radial interval grant its lowest edge
                # in the adverse comparison and use its highest inward.
                values = [sum(spectrum[j:j+merge]) for j in range(0,len(spectrum),merge)]
                end = 0 if mode == 'outward' else merge-1
                indices = np.minimum(np.arange(0,len(spectrum),merge)+end,len(ticks)-1)
                e = ticks[indices]
            else:
                values, e = spectrum, ticks
            positive = np.array([x>0 for x in values])
            edges, values = e[positive], [x for x in values if x>0]
            # Every identity on these rows is prescribed at EVERY level
            # tested. Pooling them leaves the radial Gram objective unchanged.
            k = np.searchsorted(edges, int(Q('.525')*TICKS)-edges[-1], side='right')
            tables.append((np.r_[edges[0],edges[k:]], [sum(values[:k])]+values[k:]))
        pair_charge = Q(float(pair))
        if localize and mode == 'outward':
            # Cost with the true pair kernel is no smaller than this
            # multiple of the upper-cell cost used in the trial replay.
            gap = Q('.4999') - radius
            pair_charge *= (gap/(gap+37*radial_step))**2
        def evaluate(level):
            pieces = []
            for edges, values in tables:
                result, _ = enclose(edges, values, (ceil if mode == 'outward' else floor)(level*TICKS), retreat)
                pieces.append(result)
            return dict(mode=mode,theta=str(level),
                        lower=floor(sum(p['lower_billionths'] for p in pieces)-10**9*pair_charge)/10**9,
                        upper=ceil(sum(p['upper_billionths'] for p in pieces)-10**9*pair_charge)/10**9)
        outcomes = {level:evaluate(level) for level in LEVELS}
        rows.extend(outcomes.values())
        if detailed:
            left, right = 52500000, 53000000
            assert evaluate(Q(left,TICKS))['upper']<1<evaluate(Q(right,TICKS))['lower']
            while right-left > 500:
                mid = (left+right)//2
                candidate = evaluate(Q(mid,TICKS))
                if candidate['upper']<1:
                    left = mid
                elif candidate['lower']>1:
                    right = mid
                else:
                    break
            thresholds[mode] = [left/TICKS,right/TICKS]
            if mode == 'outward':
                for level in LI:
                    if level not in outcomes:
                        outcomes[level] = evaluate(level)
                previous = 1
                def upper(level):
                    return Q(str(outcomes[level]['upper']))
                base = upper(Q(10,19))
                mixture = Q(0)
                for level, share in LI.items():
                    mixture += (previous-share)*base
                    base, previous = upper(level), share
                mixture += previous*base
                mixtures['full_printed_stack'] = ceil(10**9*mixture)/10**9
                for level in [Q('.527'),Q('.528'),Q('.5284')]:
                    share = LI[level]
                    value = (1-share)*upper(Q(10,19))+share*upper(level)
                    mixtures['10/19_plus_'+str(level)] = ceil(10**9*value)/10**9
    return dict(cells=cells, raw_mass=mass, negative_mass=float(negative),
                face_sums=energies.sum(axis=1).tolist(), pair=pair, rows=rows,
                inward_offset=width, radial_merge=merge, threshold_intervals=thresholds, adverse_mixtures=mixtures)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cells', type=int, nargs='+', default=[2048,4096])
    parser.add_argument('--detailed', action='store_true')
    parser.add_argument('--localize', action='store_true')
    parser.add_argument('--histogram',type=Path,help='Use fixed-vector histograms from h1_degree6_stream.py.')
    parser.add_argument('--merge',type=int,default=1,help='Outward/inward radial pooling stride for archived histograms.')
    args = parser.parse_args()
    with np.load(VECTOR, allow_pickle=False) as data:
        assert json.loads(str(data['meta'])) == dict(dimension=39,cells=131072,angular=6,
                    shapes=['0.0','p2','300.0'],pair=True,round=0)
        vector = data['vector']
    assert vector.shape == (8910,)
    assert sha256(VECTOR.read_bytes()).hexdigest() == 'ae58b3d018eae9904fd2c6e869ba6f70cf77fcb982284a487ca9b6f446d2f624'
    assert split_uniform_offsets([1.,0.], 3) == [Q(1,6),Q(2,3),Q(1,6),Q(0)]
    if args.histogram:
        assert args.merge>=1
        with np.load(args.histogram,allow_pickle=False) as h:
            result=compare(int(h['cells']),float(h['mass']),h['faces'],float(h['pair']),h['caps'],
                           Q(str(h['step']))*Q(str(h['rho'])),Q(str(h['physical_outer'])),
                           args.detailed,args.localize,args.merge)
        print(json.dumps(result),flush=True)
        raise SystemExit(0)
    frame = TS.stored_frame()
    check_scalar(frame)
    for n in args.cells:
        print(json.dumps(screen(frame,n,vector,args.detailed,args.localize)),flush=True)
