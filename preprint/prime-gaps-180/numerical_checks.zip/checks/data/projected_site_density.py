"""Positive native site-density envelopes for a bivariate gate contraction."""
from fractions import Fraction as Q
from math import ceil, floor

import numpy as np

from middle_site_law import MiddleSiteLaw


def upper(v):
    return np.nextafter(v, np.inf)


def up_ratio(values, scale):
    # scale is a power of two. One upward ulp covers integer conversion.
    y = np.asarray(values, dtype=float)/scale
    return np.where(y == 0, 0., upper(y))


def site_density(edge, end, lower_cap, cap, tau, blocks, tail_step, mesh,
                 dust_lo=0, dust_hi=None, *, zero_is_eligible=True):
    """Return [flag, radial block, ceil(tail/tail_step)] upper densities.

    Blocks contain (inclusive native-site first index, exclusive stop index).
    Every native site in a block receives the same upper *density*, to be
    multiplied by its own native cell width and its own profile factors.
    Dust thresholds are ticks and affect only this one-site call. An atom at
    zero tail is assigned to output index zero. Lower/upper dust endpoints
    may both be closed, since the physical site total has continuous density.
    """
    tau = Q(tau)
    if not (tail_step % mesh == 0 and 0 <= dust_lo and (dust_hi is None or dust_lo < dust_hi)):
        raise ValueError('Expected aligned tail mesh and ordered dust cuts.')
    if not all(0 <= a < b for a,b in blocks):
        raise ValueError('Empty native site interval.')
    lo = np.array([floor(a*tau) for a,_ in blocks], dtype=np.int64)
    hi = np.array([ceil(b*tau) for _,b in blocks], dtype=np.int64)
    stop = int(hi.max()) + mesh
    law = MiddleSiteLaw(edge, end, lower_cap, cap, mesh, stop)
    scale = law.scale
    limit = stop if dust_hi is None else dust_hi
    rho = up_ratio(law.dust.high.value, scale)
    assert np.all(np.diff(rho) <= 0)
    tail_cells = 1+ceil(int(hi.max())/tail_step)
    result = np.zeros((4,len(lo),tail_cells))
    a0 = np.maximum(lo, dust_lo)
    b0 = np.minimum(hi, limit)
    possible = a0 < b0
    idx = np.minimum(a0//mesh, len(rho)-1)
    overall = np.where(possible, rho[idx], 0.)
    if law.small:
        small_up = up_ratio(law.small.high.value, scale)
        small_down = np.maximum(0., np.nextafter(np.array(law.small.low.value,dtype=float)/scale,-np.inf))
        result[0,:,0] = np.where(possible,small_up[idx],0.)
        sub = small_down[np.minimum(np.maximum(b0,0)//mesh,len(small_down)-1)]
        result[2,:,0] = np.where(possible,np.maximum(0.,upper(overall-sub)),0.)
    else:
        result[0,:,0] = overall
    if not zero_is_eligible:
        result[:,:,0] = 0.

    # Clip each true tail microcell to the output bin before rounding its
    # integration endpoints outward in ticks. Even the narrow native caps
    # consequently stay in their correct output bin.
    starts = []
    ends = []
    cells = []
    rows = []
    for i,(a,b) in enumerate(zip(law.knots,law.knots[1:])):
        if not any(step.value[i] for step in law.hi):
            continue
        left,right = Q(a*mesh,law.D),Q(b*mesh,law.D)
        for k in range(floor(left/tail_step)+1, min(tail_cells-1,ceil(right/tail_step))+1):
            y0,y1 = max(left,(k-1)*tail_step),min(right,k*tail_step)
            if y1<=y0:
                continue
            starts.append(floor(y0)); ends.append(ceil(y1)); cells.append(k)
            rows.append([step.value[i] for step in law.hi])
    if not cells:
        return result
    y0 = np.asarray(starts)
    y1 = np.asarray(ends)
    cells = np.asarray(cells)
    density = up_ratio(rows,scale)
    boundaries = np.r_[0,np.flatnonzero(np.diff(cells))+1]
    assert np.all(np.diff(cells)>=0) and len(cells)<2**20
    for row,(a,b) in enumerate(zip(lo,hi)):
        low_y = np.maximum(y0,a-limit)
        high_y = np.minimum(y1,b-dust_lo)
        lengths = np.maximum(0,high_y-low_y)
        least_dust = np.maximum(dust_lo,a-high_y)
        upper_rho = rho[np.minimum(least_dust//mesh,len(rho)-1)]
        terms = (upper_rho*(lengths/mesh))[:,None]*density
        # At most 2^20 nonnegative summands, each involving three roundings.
        # Binary64 serial summation has relative error <2^-32 here.
        sums = np.add.reduceat(terms,boundaries,axis=0)
        result[:,row,cells[boundaries]] = np.where(sums.T>0,
                upper((sums.T + 2.**-995)*(1+2.**-31)),0.)
    return result


def check():
    tau = Q(1399373467,172031279104000)*2624990
    blocks = [(19912,19913),(28800,28832),(48000,48001)]
    kwargs = dict(edge=300000,end=330000,lower_cap=29293*tau,cap=39058*tau,
                  tau=tau,blocks=blocks,tail_step=10000,mesh=500)
    table = site_density(**kwargs)
    exact = MiddleSiteLaw(kwargs['edge'],kwargs['end'],kwargs['lower_cap'],kwargs['cap'],
                          kwargs['mesh'],ceil(max(b for _,b in blocks)*tau)+1000)
    comparisons = 0
    for r,(a,b) in enumerate(blocks):
        for j in {a,(a+b-1)//2,b-1}:
            for k in [0,31,33,34,62,64,70,80]:
                yl,yr = (0,1) if k==0 else ((k-1)*10000,k*10000)
                intervals = exact.rectangle(j*tau,(j+1)*tau,yl,yr)
                for f,(low,hi) in enumerate(intervals):
                    assert Q(float(table[f,r,k])) * tau/2624990 >= hi
                    comparisons += 1
    # A site contributing one mark in [300000,310000] with remaining dust
    # inside [120000,130000] has an explicit logarithmic density. The two
    # disjoint dust ranges below cover every site, including the atom.
    cut = 125000
    below = site_density(**kwargs,dust_hi=cut)
    above = site_density(**kwargs,dust_lo=cut)
    for r,(a,b) in enumerate(blocks):
        j=a
        for k in [0,31,33,64]:
            yl,yr = (0,1) if k==0 else ((k-1)*10000,k*10000)
            for f,(_,h) in enumerate(exact.rectangle(j*tau,(j+1)*tau,yl,yr)):
                assert (Q(float(below[f,r,k]))+Q(float(above[f,r,k])))*tau/2624990 >= h
                comparisons += 1
    return comparisons


if __name__=='__main__':
    print(f'{check()} exact one-site comparisons passed')
