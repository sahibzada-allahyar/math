"""Certify tail allocations using the actual largest-fragment and radius classes of each partner."""
import argparse
import gzip
import json
from fractions import Fraction as Q
from math import ceil,floor
from pathlib import Path
import numpy as np

from h1_mass_band_prices import CERT,FIT,NORM,TABLE,UNIT,digest,geom,read
from h1_multilevel_mark_orders import MINRAD,OUT as ORDERS,mark_edges,model,schedule
from h1_multilevel_native_cap import CERT as ML_CERT
from h1_multilevel_price_collar import OUT as COLLAR
from h1_multilevel_strip_free import OUT as FREE

OUT=Path('h1_multilevel_partner_caps.json')


def cap_types(norm,ends,gt,tick,trial,step,collar,extra=()):
    fine=sorted(set(ends.tolist())|set(trial['caps'])|set(extra))
    h=Q(norm['step']);n=norm['intervals']-38
    last=[]
    for c in fine:
        v=min(n-1,max((int(b//h)-38 for _,b,cc in trial['shells'] if cc>=c),default=-1))
        for l,r,a,b in collar:
            if l<c<=r:
                assert v==b;v=a-1
        last.append(v)
    G=446;R=np.zeros((len(fine),G),np.int64)
    rs=np.zeros_like(R)
    tops=np.array([ceil(c*tick) for c in fine],np.int64)
    # A full-root maximum above the retained maximum must be carried
    # by the inserted coordinate, which then consumes at least its lower cap.
    for k,c in enumerate(fine):
        ub=max([last[k]]+[last[j]-fine[j-1] for j in range(k+1,len(fine))])
        own=gt[np.searchsorted(ends,c),:ub+1];ix=np.arange(len(own))
        bot=np.full(G,n,int);top=np.full(G,-1,int)
        np.minimum.at(bot,own,ix);np.maximum.at(top,own,ix)
        for g in np.flatnonzero(top>=0):
            R[k,g]=ceil((int(top[g])+37)*tick);rs[k,g]=floor(int(bot[g])*tick)
    K=int(np.ceil(R.max()/step))+1-MINRAD//step
    ls=np.full((len(fine),G,K),-1,int);own=[];radii=[];tag=[]
    for k in range(len(fine)):
        for g in np.flatnonzero(R[k]):
            a=max(MINRAD//step,rs[k,g]//step);b=max(a,ceil(Q(int(R[k,g]),step)))
            for j in range(a,b+1):
                ls[k,g,j-MINRAD//step]=len(own);own.append(int(g));tag.append(k)
                radii.append(min(int(R[k,g]),j*step))
    return np.array(fine),R,rs,tops,ls,np.array(own),np.array(tag),np.array(radii)


def compile_limits(m,name):
    doc,parent=m['doc'],m['parent']
    u=m['edges'][1:];l=m['edges'][:-1];G=445
    R,tops,own,tag,radii=(m[k] for k in ('R','tops','own','tag','radii'))
    limits=np.full((len(own),len(u)),2*UNIT,dtype=np.int32)
    # A single fixed-sector class at the end has no arithmetic predicates.
    active=own<G
    with gzip.open(ML_CERT,'rt') as f:
        coeff=json.load(f)['affine'][:14]
    for matrix,raw,old in zip(coeff,doc['channels'],parent['channels'][:14]):
        used=np.asarray(matrix,dtype=np.int64)!=0
        assert raw['channel']==old['channel'] and not old['reduced_radius_groups']
        any_part=np.max(np.where(used,R[:,:G].max(axis=0)[None,:],0),axis=1)
        assert np.all(any_part<=old['maximum_gated_partner'])
        m0=np.r_[any_part,0][own]
        ix=np.flatnonzero(active&(radii+m0>5_000_000))
        if not len(ix):continue
        i=own[ix];rg=R[tag[ix],i]
        lo,d,delta=schedule(name,np.array(raw['rows'],np.int64))
        end=np.searchsorted(lo,radii[ix]+m0[ix],side='left')
        for b,(lower,upper) in enumerate(zip(l,u)):
            eligible=tops>lower
            if not eligible.any():continue
            # For an actual threshold in (lower,upper], at most floor(R/lower)
            # marks can exceed lower. Each such mark is bounded by its class cap.
            sub=R[eligible,:G];z=tops[eligible,None]
            opp_radius=sub.max(axis=0)
            opp_tail=np.minimum(sub,sub//max(1,lower)*z).max(axis=0)
            partner=np.max(np.where(used,opp_radius[None,:],0),axis=1)[i]
            tail=np.max(np.where(used,opp_tail[None,:],0),axis=1)[i]
            both=np.where(delta<upper,lo+delta-d*upper,4*UNIT)
            prefix=np.r_[4*UNIT,np.minimum.accumulate(both)]
            single=prefix[end]
            reached=np.searchsorted(lo,radii[ix]+partner,side='left')
            common=prefix[reached]
            shared=common*rg//(rg+partner)
            quota=np.maximum(shared,common-tail)
            quota=np.where((partner==0)|(common==4*UNIT),2*UNIT,quota)
            cell=np.minimum(single,quota)
            limits[ix,b]=np.minimum(limits[ix,b],cell)
    return limits


def prepare_geometry(trial,spacing,step,extra=()):
    parent,doc,norm,ends,_,gt,_,_,tick=model()
    extra=[floor(Q(v)/tick) for v in extra if floor(Q(v)/tick)<max(trial['caps'])]
    fine,R,rs,tops,ls,own,tag,radii=cap_types(norm,ends,gt,tick,trial,step,read(COLLAR)['bands'],extra)
    e=mark_edges(1,spacing)
    # A tail above the highest represented edge cannot occur on this support.
    assert max(tops)<e[-1]
    return dict(doc=doc,parent=parent,fine=fine,R=R,rs=rs,tops=tops,ls=ls,own=own,tag=tag,radii=radii,edges=e)


def main():
    from h1_combined_mass_interval import load_trial
    from hashlib import sha256
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--check',action='store_true')
    ap.add_argument('--policies',nargs='+',default=['largest','30000'])
    ap.add_argument('--spacing',type=int,default=10000)
    ap.add_argument('--step',type=int,default=2000)
    args=ap.parse_args();assert MINRAD%args.step==0 and args.spacing>0
    m=prepare_geometry(load_trial(FIT),args.spacing,args.step)
    checks=[]
    for name in args.policies:
        arr=compile_limits(m,name)
        checks.append(dict(policy=name,table_sha256=sha256(arr.astype('<i4').tobytes()).hexdigest(),
                           entries=int(arr.size),nontrivial=int(np.sum(arr<UNIT))))
    paths=[Path(__file__),ORDERS,ML_CERT,CERT,NORM,TABLE,COLLAR,FIT,FREE,Path('h1_multilevel_mark_orders.py')]
    out=dict(scope='Reproducible integer sufficient tail tests on the truncated support of the strip-free weight. The certificate concerns source sufficiency only.',
             inputs={p.name:digest(p) for p in paths},radial_step=args.step,edges=m['edges'].tolist(),
             root_classes=len(m['own']),checks=checks)
    if args.check:assert read(OUT)==out
    else:OUT.write_text(json.dumps(out,separators=(',',':'))+'\n',newline='\n')
    print('partner-aware classes',len(m['own']),checks,flush=True)


if __name__=='__main__':
    main()
