"""Partition an H1 erased profile by all available source pairings."""
import argparse
from fractions import Fraction as Q
import json
from pathlib import Path

import numpy as np
from endpoint_pair_scan import HERE,BACKEND,setup,first_fibres
from h1_geometry_scan import BASE_RADIUS,fit_geometry
from h1_window_spectators import radial,coefficients
from spline_cap_operator_residual import cap_array


class Sectors:
    def __init__(self,r,dom,radii,max_radius):
        self.sources=[]
        step=r.exact_step;n=r.k-1
        for radius in radii:
            g,sub,_=fit_geometry(dict(radius=str(radius)),r.k,r.N)
            if Q(radius)==BASE_RADIUS and Q(str(r.geometry['parameters']['physical_outer']))==BASE_RADIUS:
                def caps(domains):
                    rows=cap_array(r,domains,n)
                    return [(int(c),int(np.flatnonzero(rows>=c)[-1])) for c in np.unique(rows) if c>=0]
                masks=[caps(r.shells[s]) for s in ('outer','base','enlarged')]
                masks.append(sum((caps(s) for s in dom.values()),[]))
            else:
                ratio=g['parameters']['cell_step']/step
                add=next(x for x in sub['domains'] if x['id']==sub['recommended_id'])
                raw=[g['cell_masks'][s] for s in ('outer','base','enlarged')]+[add['cell_masks']]
                masks=[[(int(Q(v['cap_index'])*ratio),int(Q(v['index_last'])*ratio)-n) for v in rows]
                       for rows in raw]
                # Both the common self square and the separate subtraction rectangle are supplied.
                masks[3]=masks[3]+masks[2]
            self.sources.append(dict(radius=str(radius),sha256=sub['geometry_sha256'],masks=masks))
        self.caps=np.array(sorted(c for c in set(r.caps)|{sh[2] for s in dom.values() for sh in s}|
                            {c for src in self.sources for rows in src['masks'] for c,i in rows}
                            if 0<c<=max(r.caps)))
        self.count=int(Q(str(max_radius))/(Q(str(r.rho))*step))+1
        self.q=(np.arange(self.count)+n)*r.h*r.rho
        valid=self.q<=float(max_radius)+1.e-12
        self.prime_upper=1/(.5-self.q-.0001)
        # Round q upwards to a short table of root radii and use log(1+v)<=v.
        qbin=np.ceil(self.q*10000).astype(int)
        qtab=np.arange(max(qbin)+1)/10000
        rough=1-2*.41361;ds=(.41361-2*rough)/1024;weight=np.zeros(len(qtab))
        for j in range(1,1025):
            x=2*rough+j*ds
            bottom=np.minimum(rough-.0001,(1-x)/2-qtab-.0001)
            assert min(bottom)>0
            weight+=ds*(12/5)*max(0.,x-.38)/(.4-.38)*(x-2*rough)/(x*rough*bottom)
        self.kernel=weight[qbin]
        keys=np.zeros((len(self.caps),self.count),dtype=np.int64)
        offsets=np.arange(self.count)
        for s,src in enumerate(self.sources):
            for m,rows in enumerate(src['masks']):
                last=np.array([max([i for c,i in rows if t<=c]+[-1]) for t in self.caps])
                keys|=(offsets<=last[:,None]).astype(np.int64)<<(4*s+m)
        bits=4*len(radii)
        assert bits<53
        edges=np.r_[.20,np.arange(2100,2951,50)/10000]
        rb=np.searchsorted(edges,self.q)
        keys|=rb.astype(np.int64)<<bits
        keys[:,~valid]=-1
        codes,inv=np.unique(keys,return_inverse=True)
        self.index=inv.reshape(keys.shape)
        self.codes=list(map(int,codes));self.n=len(codes)
        self.qmax=np.zeros(self.n)
        for a in self.index:
            np.maximum.at(self.qmax,a,self.q)
        self.prime_mask,self.minor_mask=self.permissions(codes,bits)

    def permissions(self,codes,bits):
        prime=self.qmax[:,None]+self.qmax<.5-.0001
        minor=prime.copy()
        for s in range(bits//4):
            o,l,m,c=[((codes>>(4*s+i))&1).astype(bool) for i in range(4)]
            both=c[:,None]&m
            p=o[:,None]&l;v=o[:,None]&m
            prime|=p|p.T|both|both.T
            minor|=v|v.T|both|both.T
        return prime,minor

    def report(self):
        return dict(sources=[{k:v for k,v in s.items() if k!='masks'} for s in self.sources],
                    codes=self.codes,physical_upper=self.qmax.tolist(),
                    prime_mask=self.prime_mask.astype(int).tolist(),minorant_mask=self.minor_mask.astype(int).tolist())


def model(N):
    P=json.loads((HERE/'h1_k38_knn6_n32768.json').read_text())
    prior=json.loads((BACKEND/'results/incidence_multicap_spline_a6_n32768.json').read_text())
    base=P['rows'][P['best_index']] if N==32768 else json.loads((HERE/'h1_k38_replay_n131072.json').read_text())
    r,lim,dom=setup(38,N,P,prior)
    return P,prior,base,r,lim,dom


def trial_model(N,filename=None):
    if not filename:return model(N)
    from h1_geometry_scan import instantiate
    P,prior,_,_,_,_=model(N)
    fit=json.loads((HERE/filename).read_text())
    if 'shape_spec' in fit:
        P=dict(P,specification=dict(P['specification'],angular=fit['shape_spec']['angular']))
    r,lim,dom,spec,rec=instantiate(P,dict(radius=fit['radius'],extra_knots=fit.get('extra_knots',())),38,N)
    assert spec==fit['shape_spec']
    if fit['flat']:r.shells['outer']=[(Q(0),r.geometry['parameters']['S'],max(lim))]
    P=dict(P,best_coefficients=fit['coefficients'])
    return P,prior,None,r,lim,dom


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--intervals',type=int,choices=(32768,131072),required=True)
    p.add_argument('--radii',nargs='+',default=['.2718','.273',str(BASE_RADIUS),'.2798746934','.284'])
    p.add_argument('--max-radius',default='.284')
    p.add_argument('--refit',type=Path)
    p.add_argument('--fragment-cap',type=Q,help='Clamp every spline component to this physical prime-factor exponent.')
    p.add_argument('--cell-bins',type=Path,help='Save radial subcells of each sector/fragment layer for mixed-rectangle refinement.')
    p.add_argument('--radial-energy',type=Path,help='Save the normalized erasure energy at each native radial index.')
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();name=a.refit.name if a.refit else None
    P,prior,base,r,lim,dom=trial_model(a.intervals,name)
    if a.fragment_cap:
        rho=max(Q(str(r.geometry['parameters'][s])) for s in ('rho','rho_star'))
        cutoff=int(a.fragment_cap//(r.exact_step*rho))
        assert cutoff>0
        lim=[min(limit,cutoff) for limit in lim]
    if name or a.fragment_cap:
        from h1_knn_harmonic import scalar_replay
        mass,forms=scalar_replay(r,np.array(P['best_coefficients']),lim,dom)
        ell=P['rows'][P['best_index']]['hybrid_lambda']
        diagnostic=r.rho*(forms[0]+(1-ell)*forms[1]+(1-1/ell)*prior['kappa']*forms[2])/mass
        base=dict(mass=mass,forms=forms,cap_quotient_without_penalty=diagnostic)
    sec=Sectors(r,dom,a.radii,a.max_radius)
    fibres=first_fibres(r,np.array(P['best_coefficients']),lim)
    original0=cap_array(r,r.shells['base'],r.k-1)
    original1=cap_array(r,r.shells['enlarged'],r.k-1)
    originalC=np.maximum.reduce([cap_array(r,s,r.k-1) for s in dom.values()])
    cuts=sorted(set(map(int,sec.caps))|set(fibres))
    previous={};values=np.zeros((sec.n,3));check=np.zeros(3);oldK=r.radial_weight();bins=[]
    radial_sum=np.zeros(r.n) if a.radial_energy else None
    pref=r.rho*r.norm*r.inner_exp/base['mass']
    for cap in cuts:
        if cap>max(fibres):continue
        rows=radial(fibres,cap,r.n);poly=coefficients(rows,rows)
        dens=np.zeros(r.n);current={}
        for sig,v in poly.items():
            current[sig]=r.moment(cap,r.k-1,sig).copy()
            dens+=v*(current[sig]-previous.get(sig,0.))
        dens*=pref
        if radial_sum is not None:
            radial_sum+=dens
        ids=sec.index[np.searchsorted(sec.caps,cap),:r.n]
        for j,mult in enumerate([1,sec.prime_upper[:r.n],sec.kernel[:r.n]]):
            values[:,j]+=np.bincount(ids,weights=dens*mult,minlength=sec.n)
        if a.cell_bins:
            index=np.arange(r.n);starts=np.r_[0,np.flatnonzero((ids[:-1]!=ids[1:])|(index[1:]%64==0))+1]
            sums=[np.add.reduceat(x,starts) for x in (dens,dens*sec.prime_upper[:r.n],dens*sec.kernel[:r.n])]
            bins.append(np.column_stack([ids[starts],np.full(len(starts),cap),starts,np.r_[starts[1:]-1,r.n-1],*sums]))
        check+=[dens[cap<=original0].sum(),dens[(cap>original0)&(cap<=original1)].sum(),
                (dens*oldK)[cap>originalC].sum()]
        previous=current;r.clear_cache()
    ref=np.array(base['forms'])*r.rho/base['mass']
    assert max(abs(check-ref))<1.e-8 and min(values.ravel())>-1.e-12
    out=dict(status='DETERMINISTIC_FLOATING_SECTOR_INTEGRALS_BEFORE_RESTORATION',trial_refit=name,
             intervals=a.intervals,kappa_upper=prior['kappa'],max_radius=a.max_radius,
             baseline=base['cap_quotient_without_penalty'],sector_energies=values.tolist(),
             baseline_form_error=max(abs(check-ref)),**sec.report())
    if a.fragment_cap:out.update(fragment_cap=str(a.fragment_cap),cutoff=cutoff,component_limits=lim)
    if a.radial_energy:
        from hashlib import sha256
        assert abs(radial_sum.sum()-values[:,0].sum())<1e-11
        np.savez_compressed(a.radial_energy,energy=radial_sum,step=str(r.exact_step))
        out.update(radial_energy=a.radial_energy.name,radial_sha256=sha256(a.radial_energy.read_bytes()).hexdigest())
    if a.cell_bins:
        from hashlib import sha256
        v=np.concatenate(bins)
        replay=np.column_stack([np.bincount(v[:,0].astype(int),weights=v[:,j],minlength=sec.n) for j in (4,5,6)])
        assert np.abs(replay-values).max()<1e-11
        np.savez_compressed(a.cell_bins,cells=v,ordinary_mass=base['mass'],step=str(r.exact_step))
        out.update(cell_bins=a.cell_bins.name,cell_bins_sha256=sha256(a.cell_bins.read_bytes()).hexdigest())
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(sectors=sec.n,total=values.sum(axis=0).tolist(),error=out['baseline_form_error'])))


if __name__=='__main__':
    main()
