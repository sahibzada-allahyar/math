"""Lower envelopes of the prime and exceptional Gram matrices on disjoint sectors."""
import argparse
import json
from pathlib import Path
import sys

import numpy as np
from scipy import sparse
from scipy.linalg import eigh

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'deps/h1-conic'))
import scs


def compress(energy,prime,minor,limit):
    keep=np.flatnonzero(energy[:,0]>0)
    if np.min(energy)<-1.e-10:
        raise ValueError('Negative sector integral; increase numerical resolution')
    p=prime[np.ix_(keep,keep)];m=minor[np.ix_(keep,keep)]
    exact=p.all(axis=1)
    resolved=keep[exact];keep=keep[~exact]
    p=prime[np.ix_(keep,keep)];m=minor[np.ix_(keep,keep)]
    _,classes=np.unique(np.hstack([p,m]),axis=0,return_inverse=True)
    groups=[keep[classes==i].tolist() for i in range(max(classes)+1)]
    def matrices(groups):
        def gather(A):
            return np.array([[A[np.ix_(a,b)].all() for b in groups] for a in groups])
        return gather(prime),gather(minor)
    p,m=matrices(groups);w=np.array([energy[g,0].sum() for g in groups])
    while len(groups)>limit:
        a=np.argmin(w)
        # Preserve self permissions when merging a small group. Charge any
        # permissions lost by the larger group in proportion to its energy.
        dist=((p[a]!=p)*np.sqrt(w)).sum(1)+((m[a]!=m)*np.sqrt(w)).sum(1)
        loss=(~p[a]&p.diagonal() | ~m[a]&m.diagonal()).astype(float)
        lost=((~p[a]&p)*np.sqrt(w)).sum(1)+((~m[a]&m)*np.sqrt(w)).sum(1)
        scores=np.sqrt(w[a])*dist+np.sqrt(w)*(lost+loss)
        scores[a]=np.inf;b=np.argmin(scores)
        groups[b]+=groups[a];groups.pop(a)
        w[b]+=w[a];w=np.delete(w,a)
        for mask in (p,m):
            row=mask[a]&mask[b]
            row[b]=row[b] and row[a]
            mask[b,:]=row;mask[:,b]=row
        p=np.delete(np.delete(p,a,0),a,1);m=np.delete(np.delete(m,a,0),a,1)
    pp,mm=matrices(groups)
    assert np.array_equal(p,pp) and np.array_equal(m,mm)
    return resolved.tolist(),groups,p,m


def problem(energy,p,m,kappa,tight=False):
    # Normalize sector profiles to mass one. Rescale exceptional entries
    # with evaluated self pairings to avoid a nearly singular PSD block.
    w=np.sqrt(energy[:,0]);n=len(w);i,j=np.triu_indices(n);d=len(i)
    pack=lambda a:a[i,j]*np.where(i==j,1.,2**.5)
    def unpack(x):
        v=np.zeros((n,n));v[i,j]=v[j,i]=x/np.where(i==j,1.,2**.5)
        return v
    mask=p[i,j];both=mask&m[i,j];rest=m[i,j]&~mask
    a=np.flatnonzero(mask);ab=np.flatnonzero(both);b=np.flatnonzero(rest)
    E=sparse.eye(d,format='csc');I=pack(np.eye(n))
    z=np.where((p&m).diagonal(),np.sqrt(kappa),1.)
    zz=z[i]*z[j]
    S=sparse.diags(zz,format='csc')
    za=lambda a,b:sparse.csc_matrix((a,b))
    col=lambda x:sparse.csc_matrix(np.asarray(x).reshape(-1,1))
    # For a known prime/exceptional off-diagonal B'=0 even if only
    # one endpoint has an evaluated self form.
    pp=sparse.hstack([E[a],za(len(a),d+1)])
    bb=sparse.hstack([za(len(ab),d),E[ab],col(-kappa*I[ab]/zz[ab])])
    rr=sparse.hstack([E[b],-S[b],col(kappa*I[b])])
    low=sparse.hstack([za(2,2*d),col([-1.,1.])])
    xp=sparse.hstack([E,za(d,d+1)])
    xb=sparse.hstack([za(d,d),E,za(d,1)])
    xbs=sparse.hstack([za(d,d),S,za(d,1)])
    U=energy[:,1]/energy[:,0];K=energy[:,2]/energy[:,0]
    level=low[1:] if tight else low
    A=sparse.vstack([pp,bb,rr,level,-xp,xp,-xb,xbs],format='csc')
    rhs=np.r_[I[a],np.zeros(len(ab)),I[b],([1.] if tight else [0.,1.]),np.zeros(d),pack(np.diag(U)),
              np.zeros(d),pack(np.diag(K))]
    obj=np.r_[pack(np.outer(w,w)),np.zeros(d+1)]
    def multipliers(y):
        L=np.zeros(d);M=np.zeros(d);R=np.zeros(d);t=len(a);u=t+len(ab)
        L[a]=-y[:t];M[ab]=-y[t:u]/zz[ab];R[b]=-y[u:u+len(b)]
        return unpack(L),unpack(M),unpack(R)
    def primal(x):
        return unpack(x[:d]),unpack(x[d:2*d])*np.outer(z,z),x[-1]*kappa
    return dict(A=A,b=rhs,c=obj),dict(z=len(a)+len(ab)+len(b)+int(tight),l=0 if tight else 2,s=[n]*4),multipliers,primal


def spectral_lower(energy,L,M,R,kappa,tight=False):
    w=np.sqrt(energy[:,0])
    U=np.sqrt(energy[:,1]/energy[:,0]);K=np.sqrt(energy[:,2]/energy[:,0])
    def negative_trace(A):
        return np.minimum(eigh((A+A.T)/2,eigvals_only=True),0.).sum()
    drift=np.trace(M-R)
    constant=np.trace(L+R)+min((.000093307088324061 if tight else 0.)*drift,kappa*drift)
    return float(constant+negative_trace(np.outer(U,U)*(np.outer(w,w)-L-R))
                 +negative_trace(np.outer(K,K)*(R-M)))


def solve(data,limit,seconds,tol,tight=False):
    energy=np.array(data['sector_energies']);p=np.array(data['prime_mask'],bool);m=np.array(data['minorant_mask'],bool)
    resolved,groups,p,m=compress(energy,p,m,limit)
    known=energy[resolved,0].sum() if resolved else 0.
    e=np.array([energy[g].sum(0) for g in groups]);kappa=data['kappa_upper']
    assert min(e[:,1]-e[:,0])>=0 and min(e[:,2]-kappa*e[:,0])>=0
    spec,cones,extract,primal=problem(e,p,m,kappa,tight)
    sol=scs.solve(spec,cones,verbose=False,max_iters=200000,eps_abs=tol,eps_rel=tol,
                  time_limit_secs=seconds,acceleration_lookback=10)
    L,M,R=extract(sol['y']);P,B,k=primal(sol['x'])
    lower=spectral_lower(e,L,M,R,kappa,tight)+known
    # Exact affine constraints, then a common blend with a strictly
    # feasible diagonal point repairs the floating primal witness.
    k=float(np.clip(k,kappa*1.e-5,kappa))
    I=np.eye(len(e));P[p]=I[p];B[p&m]=k*I[p&m]
    Rmask=m&~p;B[Rmask]=(P-(1-k)*I)[Rmask]
    diag=np.diag
    def blend(t):
        x=(1-t)*P+t*I;y=(1-t)*B+t*k*I
        vs=[x,diag(e[:,1]/e[:,0])-x,y,diag(e[:,2]/e[:,0])-y]
        return min(eigh(v,eigvals_only=True)[0] for v in vs)
    lo=0.;hi=1.
    for _ in range(40):
        mid=(lo+hi)/2
        if blend(mid)>1e-10:hi=mid
        else:lo=mid
    primal_upper=known+np.sqrt(e[:,0])@((1-hi)*P+hi*I)@np.sqrt(e[:,0])
    out=dict(n=len(e),fixed_contribution=known,groups=groups,resolved=resolved,lower=lower,
             primal_upper=float(primal_upper),primal_blend=hi,primal_kappa=k,
             primal_prime=P.tolist(),primal_exceptional=B.tolist(),
             dual_prime=L.tolist(),dual_exceptional=M.tolist(),dual_minorant=R.tolist(),
             solver_status=sol['info']['status'],iterations=sol['info']['iter'],
             prime_pairs=int(np.triu(p).sum()),minorant_pairs=int(np.triu(m).sum()))
    assert lower<=primal_upper+1.e-8
    return out


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('input',type=Path)
    p.add_argument('--classes',type=int,default=28);p.add_argument('--seconds',type=float,default=100.)
    p.add_argument('--tol',type=float,default=1e-6);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--permissions',type=Path);p.add_argument('--tight-deficit',action='store_true')
    a=p.parse_args();data=json.loads(a.input.read_text())
    if a.permissions:
        from h1_cross_ladders import apply_permissions
        apply_permissions(data,a.permissions)
    out=solve(data,a.classes,a.seconds,a.tol,a.tight_deficit)
    out.update(source=a.input.name,permissions=a.permissions.name if a.permissions else None,
               scs_version=scs.__version__,scope='Finite cap matrices, floating solver and spectral readback.')
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:out[k] for k in ('n','fixed_contribution','lower','primal_upper','primal_blend','iterations','solver_status')}))


if __name__=='__main__':
    main()
