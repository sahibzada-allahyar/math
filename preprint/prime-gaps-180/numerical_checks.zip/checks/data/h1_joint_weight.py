"""Joint Ritz fit of Fermi, neighbour, walk, intersection and two-half sieve amplitudes."""
import argparse
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import numpy as np
from scipy.linalg import eigh
from scipy.special import expit
from h1_coordinate_shape import configured
from h1_harmonic_sector_probe import forms,sample
from h1_intersection_blocks import BANDS,M
from h1_markov_resolvent import Cells
from h1_schmidt_table import EDGES,LARGE


HERE=Path(__file__).resolve().parent
MODULES=('fermi','spring','walk','sign','tensor')
FROZEN=(('h1_markov_validation.json','residual_laplace_0.75'),
        ('h1_intersection_test.json','signed_promise_4_0.15'),('h1_schmidt_trial.json','joint'))
EXTRA=(('fermi','soft_tail'),('spring','global'),('sign','singleton_overlap'),('sign','parity'),
       ('tensor','CZ'),('tensor','half_imbalance'))
SPECIAL=(('sign','tensor'),('spring','sign','tensor'),('walk','sign','tensor'),MODULES)
DIGEST=lambda p:sha256(p.read_bytes()).hexdigest()


class JointWeight:
    def __init__(self,r,coordinate):
        self.r=r;self.cells=Cells(r,coordinate)
        self.tables=[];self.hashes={}
        for name,key in FROZEN:
            path=HERE/name;data=json.loads(path.read_text())
            assert data['coordinate_sha256']==DIGEST(HERE/'h1_shape_training_131072.json')
            self.tables.append(np.array(data['rows'][key]['multiplier']));self.hashes[name]=DIGEST(path)
        self.subsets=[s for length in range(1,6) for s in combinations(MODULES,length)]
        self.labels=['original','coordinate']+['*'.join(s) for s in self.subsets]+[s for _,s in EXTRA]+[
            'promise:'+'*'.join(s) for s in SPECIAL]
        self.members=[(),()]+self.subsets+[(s,) for s,_ in EXTRA]+list(SPECIAL)
        self.pop=np.array([i.bit_count() for i in range(M)])

    def __call__(self,idx,cat,F=None,action=None):
        assert idx.shape[1]==38
        h,region=self.cells.values(idx,cat)
        t=self.r.t[idx];q=self.r.rho*t
        hq=q.reshape(len(idx),2,19)
        total=q.sum(axis=1)
        masks=np.zeros((len(idx),2),dtype=int)
        for bit,(lo,hi) in enumerate(BANDS):
            masks|=np.any((hq>=lo)&(hq<hi),axis=2).astype(int)<<bit
        intersection=self.pop[masks[:,0]&masks[:,1]]
        promise=np.where(intersection==0,1.,np.where(intersection==1,-1.,0.))
        mask=(masks[:,0]|masks[:,1])+M*(total>.25)
        halft=hq.sum(axis=2)
        u=2*np.searchsorted(EDGES,halft)+(hq.max(axis=2)>=LARGE)
        high=u.max(axis=1);low=u.min(axis=1)
        types=high*(high+1)//2+low
        gaps=np.diff(np.sort(t,axis=1),axis=1)**2
        local=gaps[:,0]+gaps[:,-1]+np.minimum(gaps[:,:-1],gaps[:,1:]).sum(axis=1)
        glob=((t-t.mean(axis=1)[:,None])**2).sum(axis=1)
        walk,signed,coupling=self.tables
        val=dict(fermi=(expit((q-.012)/.003).mean(axis=1)-.20)/.15,
                 spring=(np.exp(-64*local-8*glob)-.45)/.35,walk=(walk[region]-1)/.01,
                 sign=(signed[mask]-1)/.01,tensor=(coupling[types]-1)/.008)
        prods={():np.ones(len(idx))}
        for subset in self.subsets:prods[subset]=prods[subset[:-1]]*val[subset[-1]]
        matched_ones=((hq[:,0]>=.015)&(hq[:,1]>=.015)).sum(axis=1)
        CZ=1-2*(matched_ones%2)
        features=[prods[s] for s in self.subsets]
        features.extend([expit((q-.03)/.006).mean(axis=1),np.exp(-8*glob),promise,
                         1-2*(intersection%2),CZ,(halft[:,0]-halft[:,1])**2])
        for subset in SPECIAL:
            other=tuple(s for s in subset if s!='sign')
            features.append(promise*prods[other])
        return np.column_stack([np.ones(len(h)),h,h[:,None]*np.column_stack(features)])


def basis(features,name):
    which=[]
    for i,s in enumerate(features.members):
        if i<2:continue
        if name in MODULES:keep=set(s)=={name}
        elif name=='main_effects':keep=len(s)==1
        elif name=='pair_effects':keep=len(s)<=2
        elif name=='joint':keep=True
        elif name.startswith('drop_'):keep=name[5:] not in s
        elif name=='coord':keep=False
        else:raise ValueError(name)
        if keep:which.append(i)
    return [1,*which]


def train(G,A,ids,penalty=.10,trust_radius=.04):
    # Center extra directions against the coordinate reference. Regularize
    # only the correction, retaining the unpenalized coordinate trial.
    n=len(G);one=np.eye(n)[:,1];g0=G[1,1]
    if len(ids)==1:return one,1
    ix=ids[1:]
    T=np.eye(n)[:,ix]-np.outer(one,G[1,ix]/g0)
    gram=T.T@G@T;sc=np.sqrt(np.maximum(0.,np.diag(gram)))
    useful=sc>1e-11
    T=T[:,useful]/sc[useful]
    gram=T.T@G@T;e,V=eigh((gram+gram.T)/2)
    ok=e>1e-6*e[-1]
    W=np.column_stack([one/np.sqrt(g0),T@(V[:,ok]/np.sqrt(e[ok]))])
    form=W.T@A@W
    form[1:,1:]-=penalty*np.eye(len(form)-1)
    _,v=eigh((form+form.T)/2);a=v[:,-1]
    norm=np.linalg.norm(a[1:])
    if norm<1e-13:return one,len(a)
    tangent=(W[:,1:]@a[1:])*np.sqrt(g0)/norm
    # Evaluate the unpenalized line optimum inside the chosen RMS trust region.
    U=np.column_stack([one,tangent]);small=U.T@A@U;sm=U.T@G@U
    _,v=eigh((small+small.T)/2,(sm+sm.T)/2)
    steps=[0.,-trust_radius,trust_radius]
    if abs(v[0,-1])>1e-14:steps.append(np.clip(v[1,-1]/v[0,-1],-trust_radius,trust_radius))
    def score(s):
        h=one+s*tangent;return h@A@h/(h@G@h)
    return one+max(steps,key=score)*tangent,len(a)


def frozen_fits(path,weight,choices):
    rec=json.loads(path.read_text());source=path.with_name(rec['sample'])
    assert rec['labels']==weight.labels and rec['frozen']==weight.hashes and DIGEST(source)==rec['sample_sha256']
    with np.load(source,allow_pickle=False) as data:G,A=forms(data['raw'].mean(0),rec['base'])
    vectors=np.stack([train(G,A,basis(weight,name))[0] for name in choices],axis=1)
    means=G[0]@vectors/G[0,0]
    assert np.all(abs(means)>.1)
    return vectors/means


def run():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('dual',type=Path);p.add_argument('coordinate',type=Path)
    p.add_argument('--seed',type=int,required=True);p.add_argument('--power',type=int,default=16)
    p.add_argument('--runs',type=int,default=6);p.add_argument('--tilt',type=float,default=15.)
    p.add_argument('--training',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    coordinate=json.loads(a.coordinate.read_text());assert DIGEST(a.dual)==coordinate['dual_sha256']
    assert DIGEST(a.coordinate)==DIGEST(HERE/'h1_shape_training_131072.json') and a.runs>=4 and a.power>=9
    op,prior,_=configured(a.dual);weight=JointWeight(op.r,coordinate)
    old=None;seeds=list(range(a.seed,a.seed+a.runs));used=set(coordinate['seeds'])
    for file,_ in FROZEN:
        rec=json.loads((HERE/file).read_text());used.update(rec['seeds'])
        if rec.get('training'):used.update(json.loads((HERE/rec['training']).read_text())['seeds'])
    if a.training:
        old=json.loads(a.training.read_text());used.update(old['seeds'])
        assert old['labels']==weight.labels and old['frozen']==weight.hashes and old['dual_sha256']==DIGEST(a.dual)
    assert not {s+j for s in seeds for j in (0,100000)}&{s+j for s in used for j in (0,100000)}
    raw=[]
    for seed in seeds:
        raw.append(sample(op,seed,a.power,a.tilt,prior.base,False,weight))
        print(json.dumps(dict(seed=seed,original_mass=raw[-1][0,0,0])),flush=True)
    raw=np.asarray(raw)
    if old:
        src=a.training.with_name(old['sample']);assert DIGEST(src)==old['sample_sha256']
        with np.load(src,allow_pickle=False) as z:training=z['raw']
        test=raw
    else:training,test=raw[:len(seeds)//2],raw[len(seeds)//2:]
    G,A=forms(training.mean(0),prior.base);g,b=forms(test.mean(0),prior.base)
    separate=[forms(row,prior.base) for row in test];rows={}
    names=['coord',*MODULES,'main_effects','pair_effects','joint',*['drop_'+s for s in MODULES]]
    for name in names:
        ids=basis(weight,name);h,rank=train(G,A,ids)
        vals=[float(h@bb@h/(h@gg@h)) for gg,bb in separate]
        rows[name]=dict(score=float(h@b@h/(h@g@h)),training_score=float(h@A@h/(h@G@h)),rank=rank,
                        seed_scores=vals,coefficients=h.tolist(),ids=ids)
    single=max(MODULES,key=lambda s:rows[s]['training_score'])
    for row in rows.values():
        delta=np.subtract(row['seed_scores'],rows['main_effects']['seed_scores'])
        row['gain_over_main_effects']=row['score']-rows['main_effects']['score']
        row['paired_se_vs_main_effects']=float(delta.std(ddof=1)/np.sqrt(len(delta)))
    src=a.output.with_suffix('.npz');np.savez_compressed(src,raw=raw)
    report=dict(scope='Joint held-out frozen-dual sieve fits on 38 shifts. Five-way interactions and drop-one fits use common samples.',
                dual=a.dual.name,dual_sha256=DIGEST(a.dual),coordinate=a.coordinate.name,coordinate_sha256=DIGEST(a.coordinate),
                frozen=weight.hashes,sample=src.name,sample_sha256=DIGEST(src),seeds=seeds,power=a.power,tilt=a.tilt,
                base=prior.base,labels=weight.labels,members=weight.members,rows=rows,best_training_single=single)
    if old:report.update(training=a.training.name,training_sha256=DIGEST(a.training))
    a.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({s:rows[s]['score'] for s in ['coord',single,'main_effects','joint']}),flush=True)


if __name__=='__main__':run()
