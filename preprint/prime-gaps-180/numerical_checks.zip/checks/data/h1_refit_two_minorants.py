"""Refit the clamped H1 spline using the three-measure dual and the refined erasure sectors."""
import argparse
from fractions import Fraction as Q
from hashlib import sha256
import json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from scipy.linalg import eigh
from h1_bilinear_pricing import proof_data
from h1_full_sector_refit import weighted_forms,scalar
from h1_geometry_scan import instantiate
from h1_pairing_sectors import trial_model,Sectors
from verify_pairing_envelope import SCALE


HERE=Path(__file__).resolve().parent
digest=lambda p:sha256(p.read_bytes()).hexdigest()


def field_from_dual(dual,with_sectors=False,refined_table=None):
    sol=json.loads(dual.read_text())
    if refined_table is not None or ('dual_prime' in sol and 'source' in sol):
        from h1_fit_pairing_sectors import uniform_weights,affine_weights
        from h1_sunrise_boundary import geometry
        path=refined_table if refined_table is not None else dual.with_name(sol['source'])
        control,record,layout=geometry(path)
        assert control.get('band_rule')=='transfer' and not control['historical_outward']
        e=np.array(control['sector_energies'])
        if refined_table is None:
            weights=uniform_weights(e,sol,control['kappa_upper'])
            score=sol['lower']
        elif 'sector_prices' in sol:
            assert sol['inputs'][path.name]==digest(path) and sol['scale']==SCALE
            weights=np.asarray(sol['sector_prices'],float)/SCALE
            assert weights.shape==e.shape
            score=float(np.sum(e*weights))
        else:
            assert sol['inputs'][path.name]==digest(path)
            A,H=[np.asarray(v,float)/SCALE for v in sol['affine']]
            resolved=np.flatnonzero(np.asarray(control['prime_mask'],bool).all(1))
            assert sorted(resolved.tolist()+sum(sol['groups'],[]))==list(range(len(e)))
            weights=affine_weights(e,sol['groups'],resolved,A,H,control['kappa_upper'])
            score=sol['lower_billionths']/1e9
        target=float(np.sum(e*weights))
        assert abs(target-score)<1e-7
        _,_,_,old,_,dom=trial_model(record['intervals'],record['trial_refit'])
        sec=Sectors(old,dom,[s['radius'] for s in record['sources']],record['max_radius'])
        with np.load(HERE/record['cell_bins'],allow_pickle=False) as z:
            caps=np.unique(z['cells'][:,1]).astype(int)
        def groups_at(cap,index):
            c=caps[min(np.searchsorted(caps,cap),len(caps)-1)]
            return layout(c,np.minimum(index,old.n-1))
        def lookup(cap,index):
            w=weights[groups_at(cap,index)]
            return w[:,0]+w[:,1]*sec.prime_upper[index]+w[:,2]*sec.kernel[index]
        result=(old,sec,lookup,target,record)
        return (*result,groups_at,weights) if with_sectors else result
    files={k.split('/')[-1]:next(x for x in [HERE/k,HERE.parent/'sensitivity'/k] if x.is_file()) for k in sol['inputs']}
    assert all(digest(files[k])==h for k,h in sol['inputs'].items())
    ref=next(p for p in files.values() if 'parent_sectors' in json.loads(p.read_text()))
    base=json.loads(ref.read_text());assert sol['grant']=='ladder'
    args=SimpleNamespace(control=ref,permissions=next(p for p in files.values() if 'permissions_' in p.name),
                         minorants=files['bilinear_minorant.json'],ladder_receipt=files['h1_bilinear_ladders_131072.json'],
                         level=sol['level'],grant=sol['grant'])
    (e,p,m,g,J,k,kt,fixed,_),groups,resolved,extra=proof_data(args,with_layout=True)
    e=e.astype(float);J=J.astype(float);w=np.sqrt(e[:,0]);U=e[:,1]/e[:,0];K=e[:,2]/e[:,0]
    L,R,S=(np.array(v,dtype=float)/SCALE for v in sol['multipliers'])
    def penalty(mat,budget):
        ev,vec=eigh(mat*np.sqrt(np.outer(budget,budget)))
        return (vec**2)@np.maximum(-ev,0)/budget
    diag=np.diag(L)+np.minimum.reduce([(1-float(i))*np.diag(R) for i in k])+np.minimum.reduce([(1-float(i))*np.diag(S) for i in kt])
    P=penalty(np.outer(w,w)-L-R-S,U);B=penalty(R+S,K);H=penalty(S,J)
    weights=np.zeros((len(base['codes']),3));weights[resolved,0]=1.
    for i,ids in enumerate(groups):
        weights[ids,0]=(diag[i]-H[i]*extra[ids].astype(float))/e[i,0]
        weights[ids,1:]=[-P[i]/e[i,0],-B[i]/e[i,0]]
    target=float((weights*np.array(base['sector_energies'])).sum())
    assert abs(target-sol['lower_billionths']/1e9)<2e-6,(target,sol['lower_billionths'])
    source=HERE/base['cells'];assert digest(source)==base['cells_sha256']
    record=json.loads(source.read_text());bfile=HERE/record['cell_bins'];assert digest(bfile)==record['cell_bins_sha256']
    z=np.load(bfile,allow_pickle=False);v=z['cells'];cap=v[:,1].astype(int);right=v[:,3].astype(int)
    parent=v[:,0].astype(int);code=parent.copy();n0=len(record['codes']);caps,inv=np.unique(cap,return_inverse=True)
    piecefile=HERE/base['pieces'];assert digest(piecefile)==base['pieces_sha256']
    rect=json.loads(piecefile.read_text())['pieces']
    for j,cut in enumerate(base['subdivision']):
        q=rect[cut['candidate']]
        for l,key in enumerate(('outer','inner')):
            ends=np.array([max([h for c,h in q[key] if t<=c],default=-1) for t in caps])
            code+=n0*(2**(2*j+l))*(right<=ends[inv])
    label,ids=np.unique(code,return_inverse=True)
    assert np.array_equal(label%n0,base['parent_sectors'])
    np.testing.assert_allclose(weights[ids].ravel()@v[:,4:7].ravel(),target,atol=2e-8,rtol=0)
    _,_,_,old,_,dom=trial_model(record['intervals'],record['trial_refit'])
    sec=Sectors(old,dom,[s['radius'] for s in record['sources']],record['max_radius'])
    tables=[(right[cap==c],ids[cap==c]) for c in caps]
    def groups_at(cref,index):
        j=np.searchsorted(caps,cref);assert j<len(caps),(cref,caps[-1])
        ends,ident=tables[j];index=np.minimum(index,ends[-1])
        return ident[np.searchsorted(ends,index)]
    def lookup(cref,index):
        group=groups_at(cref,index)
        return weights[group,0]+weights[group,1]*sec.prime_upper[index]+weights[group,2]*sec.kernel[index]
    result=(old,sec,lookup,target,record)
    return (*result,groups_at,weights) if with_sectors else result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('dual',type=Path);p.add_argument('--radius',default='.2798746934')
    p.add_argument('--intervals',type=int,default=8192);p.add_argument('--knots',nargs='*',default=[])
    p.add_argument('--angular',type=int);p.add_argument('--refined-table',type=Path)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    old,sec,field,target,record=field_from_dual(a.dual,refined_table=a.refined_table)
    src=json.loads((HERE/'h1_k38_knn6_n32768.json').read_text())
    if a.angular is not None:
        src['specification']['angular']=a.angular
    r,lim,dom,spec,geo=instantiate(src,dict(radius=a.radius,extra_knots=a.knots),38,a.intervals)
    rho=max(Q(str(r.geometry['parameters'][s])) for s in ('rho','rho_star'))
    cut=int(Q(record['fragment_cap'])//(r.exact_step*rho))
    lim=[min(cut,n) for n in lim]
    G,A,fields=weighted_forms(r,lim,old,sec,None,np.inf,field_at=field)
    diag=np.diag(G);active=diag>diag.max()*1e-18;scale=np.sqrt(diag[active])
    gm=G[np.ix_(active,active)]/np.outer(scale,scale)
    ev,V=eigh((gm+gm.T)/2);assert ev[0]>-1e-8*ev[-1]
    keep=ev>1e-8*ev[-1];W=V[:,keep]/np.sqrt(ev[keep])/scale[:,None]
    B=W.T@A[np.ix_(active,active)]@W;val,V=eigh((B+B.T)/2)
    out=np.zeros(len(diag));out[active]=W@V[:,-1]
    mass=float(out@G@out);direct=scalar(r,lim,out,fields)/mass
    assert abs(direct-val[-1])<1e-6
    ctrl=dict(status='Spline refit on transferred two-minorant prices; requires independent native-grid replay.',
              guide=a.dual.name,guide_sha256=digest(a.dual),radius=a.radius,flat=False,intervals=a.intervals,clip=None,
              extra_knots=a.knots,fragment_cap=record['fragment_cap'],component_limits=lim,shape_spec=spec,geometry=geo,
              rank=int(keep.sum()),mass=mass,reference_score=target,weighted_score=float(val[-1]),
              scalar_replay=direct,coefficients=out.tolist())
    if a.refined_table is not None:ctrl.update(price_table=a.refined_table.name,price_table_sha256=digest(a.refined_table))
    a.output.write_text(json.dumps(ctrl,indent=2)+'\n');print(a.radius,len(out),ctrl['rank'],direct,flush=True)


if __name__=='__main__':main()
