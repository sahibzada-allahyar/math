"""Test moving nearest-neighbour springs against the frozen full-spline sector dual."""
import argparse
from hashlib import sha256
import json
from pathlib import Path

import numpy as np
from scipy.linalg import eigh
from scipy.stats import qmc

from h1_coordinate_graph_krylov import energies
from h1_fit_pairing_sectors import uniform_weights
from h1_full_operator_probe import MultiCapOperator
from h1_pairing_sectors import HERE, Sectors, trial_model


LABELS = ['base', 'global', 'local1', 'local2', 'local6', 'joint1', 'joint2', 'joint6',
          'weak_joint1', 'outer_joint1', 'outer_joint6']
EXTRA = ['outer', 'outer_global', 'outer_local1', 'outer_local2', 'outer_local6']


def modifiers(t, rho, radial_controls):
    e = energies(t)
    local, glob = 64*e[:, :3], 8*e[:, 3]
    joint = np.expm1(-local-glob[:, None])
    outer = np.clip((rho*t.sum(axis=1)-.245)/.03, 0., 1.)
    features = [np.ones(len(t)), np.expm1(-glob), np.expm1(-local), joint,
                np.expm1(-(local[:, 0]+glob)/8), outer*joint[:, 0], outer*joint[:, 2]]
    if radial_controls:
        features.extend([outer, outer*np.expm1(-glob), outer[:,None]*np.expm1(-local)])
    return np.column_stack(features)


class SectorOperator(MultiCapOperator):
    def configure(self, sec, weights):
        self.sectors, self.weights = sec, weights
        self.caps = np.union1d(self.caps, sec.caps)
        assert self.caps[-1] == self.global_cap
        self.survival = np.array([self.r.survival(int(c)) for c in self.caps])
        assert np.min(np.diff(self.survival, axis=0)) >= 0
        self.category_cdf = self.survival/self.survival[-1]

    def multipliers(self, index, cap):
        s = self.sectors
        ids = s.index[np.searchsorted(s.caps, cap), index]
        return self.weights[ids, 0]+self.weights[ids, 1]*s.prime_upper[index]+self.weights[ids, 2]*s.kernel[index]

    def amplitude(self, idx, cat):
        total, cap = idx.sum(axis=1), cat.max(axis=1)
        keep = (total < self.r.n) & (cap <= self.outer_cap[np.minimum(total, self.r.n-1)])
        out = np.zeros(len(idx))
        t = self.r.t[idx[keep]]
        powers = {e: (t**e).sum(axis=1) for e in self.exponents}
        for i, limit in enumerate(self.limits):
            out[keep] += self.component_polynomial(i, total[keep], powers)*(cap[keep] <= limit)
        return out


def place_marked_coordinate(values,labels):
    rows=np.arange(len(labels))
    values[rows,labels],values[:,-1]=values[:,-1].copy(),values[rows,labels].copy()


def sample(op, seed, power, tilt, reference, radial_controls, features=None, random_marked_label=False):
    r = op.r
    density = r.g*r.g*np.exp(-tilt*r.t)*op.survival[-1]
    linear = r.g*np.exp(-tilt*r.t/2)*op.survival[-1]
    z, a = density.sum(), linear.sum()
    cdf, insert = np.cumsum(density)/z, np.cumsum(linear)/a
    cdf[-1] = insert[-1] = 1.
    norm = np.exp(r.k*np.log(z/r.Z)+(tilt-r.tilt)*r.center)
    factor = norm*r.rho*r.h*r.k*a*a/z
    full = qmc.Sobol(2*r.k, scramble=True, seed=seed)
    marked = qmc.Sobol(2*r.k+2+int(random_marked_label), scramble=True, seed=seed+100000)
    n = len(features.labels) if features is not None else len(LABELS)+(len(EXTRA) if radial_controls else 0)
    mass, residual, differences = np.zeros((3,n,n))
    batch = 512
    for j in range(2**power//batch):
        u = full.random(batch)
        idx = np.searchsorted(cdf, u[:, :r.k])
        cat = op.categories(idx, u[:, r.k:])
        F, CF, keep = op.evaluate(idx, cat)
        if j == 0:
            np.testing.assert_allclose(op.amplitude(idx, cat), F, rtol=1e-12, atol=1e-13)
        t = r.t[idx[keep]]
        h = (features(idx[keep],cat[keep],F[keep],CF[keep]) if features is not None
             else modifiers(t, r.rho, radial_controls))
        w = norm*np.exp(tilt*(t.sum(axis=1)-r.center))
        F = F[keep]
        mass += h.T@((w*F**2)[:,None]*h)
        residual += h.T@((w*F*(r.rho*CF[keep]-reference*F))[:,None]*h)
        u = marked.random(batch)
        m = r.k-1
        y = np.searchsorted(cdf, u[:, :m])
        total = y.sum(axis=1)
        keep = total < r.n
        if not np.any(keep):
            continue
        y, total, u = y[keep], total[keep], u[keep]
        yc = op.categories(y, u[:, m:2*m])
        area = insert[r.n-1-total]
        ix = np.searchsorted(insert, u[:, 2*m:2*m+2]*area[:, None])
        cx = op.categories(ix, u[:, 2*m+2:2*m+4])
        vals = []
        for b in range(2):
            idx = np.column_stack([y, ix[:, b]])
            cat = np.column_stack([yc, cx[:, b]])
            vals.append(op.amplitude(idx, cat))
        ok = vals[0]*vals[1] != 0
        if np.any(ok):
            if features is None:
                delta = (modifiers(r.t[np.column_stack([y[ok], ix[ok, 0]])], r.rho, radial_controls)-
                         modifiers(r.t[np.column_stack([y[ok], ix[ok, 1]])], r.rho, radial_controls))
            else:
                def side(j):
                    idx=np.column_stack([y[ok],ix[ok,j]])
                    cat=np.column_stack([yc[ok],cx[ok,j]])
                    if random_marked_label:
                        label=(r.k*u[ok,-1]).astype(int)
                        place_marked_coordinate(idx,label)
                        place_marked_coordinate(cat,label)
                    return features(idx,cat,vals[j][ok])
                delta=side(0)-side(1)
            w = (.5*factor*area[ok]**2*op.multipliers(total[ok], yc[ok].max(axis=1))*
                 np.exp(tilt*(r.t[y[ok]].sum(axis=1)+r.t[ix[ok]].sum(axis=1)/2-r.center))*
                 vals[0][ok]*vals[1][ok])
            differences += delta.T@(w[:, None]*delta)
    return np.array([mass, residual, differences])/2**power


def forms(raw, base):
    G, R, D = raw
    # The exact baseline residual integral is zero. Remove the observed
    # common drift before fitting; independent scrambles check the result.
    B = (base-R[0,0]/G[0,0])*G+R-D
    return G/G[0,0], B/G[0,0]


def fit(G, B, ids):
    ix = np.ix_(ids, ids)
    scale = np.sqrt(np.diag(G)[ids])
    S = G[ix]/np.outer(scale, scale)
    e, U = eigh((S+S.T)/2)
    keep = e > 1e-7*e[-1]
    assert e[0] >= -1e-9*e[-1]
    W = U[:,keep]/np.sqrt(e[keep])/scale[:, None]
    small = W.T@B[ix]@W
    _, V = eigh((small+small.T)/2)
    v = np.zeros(len(G))
    v[ids] = W@V[:, -1]
    return v/v[0]


def compare(train, test, base):
    G, B = forms(train.mean(0), base)
    g, b = forms(test.mean(0), base)
    labels = LABELS if len(G) == len(LABELS) else LABELS+EXTRA
    families = {name: [0,i] for i,name in enumerate(labels) if i}
    if len(G) > len(LABELS):
        families['radial_global'] = [labels.index(s) for s in ('base','outer','global','outer_global')]
        families['radial_local'] = [labels.index(s) for s in
            ('base','outer','local1','local2','local6','outer_local1','outer_local2','outer_local6')]
    families['local_and_global'] = list(range(8))
    families['all'] = list(range(len(G)))
    vs = {name: fit(G, B, ids) for name,ids in families.items()}
    for i in (1,2,5,6,7,8):
        v = np.zeros(len(G)); v[[0,i]] = 1.
        vs['direct_'+LABELS[i]] = v
    results = {}
    for name,v in vs.items():
        values = []
        for row in test:
            gr, br = forms(row, base)
            values.append(float(v@br@v/(v@gr@v)))
        value = float(v@b@v/(v@g@v))
        results[name] = dict(coefficients=v.tolist(), held_out_score=value, held_out_scores=values,
                             gain=value-base, descriptive_se=float(np.std(values, ddof=1)/np.sqrt(len(values))))
    return results


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('dual', type=Path)
    p.add_argument('--power', type=int, default=17)
    p.add_argument('--seeds', nargs='+', type=int, default=list(range(21801,21809)))
    p.add_argument('--tilt', type=float, default=15.)
    p.add_argument('--radial-controls', action='store_true')
    p.add_argument('--training', type=Path, help='Freeze fits from a separate run and score all new scrambles.')
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    assert a.power >= 9 and len(a.seeds) >= 4 and len(set(a.seeds)) == len(a.seeds)
    sol = json.loads(a.dual.read_text())
    control = HERE/sol['source']
    c = json.loads(control.read_text())
    P, prior, _, r, limits, dom = trial_model(c['intervals'], c['trial_refit'])
    sec = Sectors(r, dom, [v['radius'] for v in c['sources']], c['max_radius'])
    assert sec.codes == c['codes']
    e = np.array(c['sector_energies'])
    weights = uniform_weights(e, sol, c['kappa_upper'])
    base = float(np.sum(e*weights))
    assert abs(base-sol['lower']) < 1e-7
    vector = np.array(P['best_coefficients']).reshape(len(limits), r.nb)
    op = SectorOperator(r, vector, limits, dom, prior['kappa'], P['rows'][P['best_index']]['hybrid_lambda'])
    op.configure(sec, weights)
    r.clear_cache()
    raw = []
    for seed in a.seeds:
        raw.append(sample(op, seed, a.power, a.tilt, base, a.radial_controls))
        print(json.dumps(dict(seed=seed, mass=raw[-1][0,0,0], residual=raw[-1][1,0,0])), flush=True)
    raw = np.array(raw)
    mid = len(raw)//2
    report = dict(scope='Sampled fixed-dual cap quotients before support restoration or integration enclosures.',
                  trial=c['trial_refit'], dual=a.dual.name, dual_sha256=sha256(a.dual.read_bytes()).hexdigest(),
                  control=control.name, control_sha256=sha256(control.read_bytes()).hexdigest(),
                  base=base, labels=LABELS+EXTRA if a.radial_controls else LABELS,
                  intervals=r.N, tilt=a.tilt, power=a.power, seeds=a.seeds,
                  raw_order=['mass', 'full_residual', 'marked_difference'], raw=raw.tolist(),
                  first_to_second=compare(raw[:mid], raw[mid:], base), second_to_first=compare(raw[mid:], raw[:mid], base))
    if a.training:
        old = json.loads(a.training.read_text())
        assert old['dual_sha256'] == report['dual_sha256'] and old['labels'] == report['labels']
        old_seeds = {s+offset for s in old['seeds'] for offset in (0,100000)}
        assert old_seeds.isdisjoint(s+offset for s in a.seeds for offset in (0,100000))
        report['training'] = a.training.name
        report['training_sha256'] = sha256(a.training.read_bytes()).hexdigest()
        report['frozen_to_new'] = compare(np.array(old['raw']), raw, base)
    a.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({s:{k:report[s][k]['held_out_score'] for k in ('direct_joint1','joint1','all')}
                      for s in ('first_to_second','second_to_first')}))


if __name__ == '__main__':
    main()
