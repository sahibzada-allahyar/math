"""Source files whose SHA-256 values are recorded in the certificates.

Several certificates record the SHA-256 of the programs that computed them. They record
those programs, and some data files, under names that begin with `h1_b2_`, and the
programs refer to one another by those names. The directory `archived` holds the recorded
programs byte for byte under the recorded names. The working file in this directory has
the same name without the prefix, and it must equal the archived file with every
occurrence of the prefix removed. A recorded file that is not in `archived` is the
working file itself.
"""
from hashlib import sha256
from pathlib import Path

PREFIX = 'h1_b2_'
HERE = Path(__file__).resolve().parent
ARCHIVED = HERE / 'archived'
# Recorded programs that are kept for their hash only and have no working file.
ARCHIVED_ONLY = ('certify_quotient_and_debit.py', PREFIX + 'cap_worker.py')


def working_name(recorded):
    """The name in this directory of the file that a certificate records as `recorded`."""
    return recorded.removeprefix(PREFIX)


def recorded_bytes(recorded):
    """The bytes of the file that a certificate records under the name `recorded`.

    For an archived program this also requires that the working file equals the archived
    file with the prefix removed.
    """
    archived = ARCHIVED / recorded
    working = HERE / working_name(recorded)
    if not archived.exists():
        return working.read_bytes()
    data = archived.read_bytes()
    if recorded not in ARCHIVED_ONLY and working.read_bytes() != data.replace(PREFIX.encode(), b''):
        raise ValueError(f'{working.name} differs from the archived {recorded}')
    return data


def recorded_digest(recorded):
    """SHA-256 of the file that a certificate records under the name `recorded`."""
    return sha256(recorded_bytes(recorded)).hexdigest()
