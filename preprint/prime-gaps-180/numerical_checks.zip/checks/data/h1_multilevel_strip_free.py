"""Retain all twelve minorants while eliminating the three evaluated semiprime strips."""
import argparse
from fractions import Fraction as Q
import gzip
import json
from math import ceil,floor
from pathlib import Path
import numpy as np

from h1_combined_margin import margin
from h1_mass_band_prices import CERT as GROUPS,FIT,FORMS,TABLE,digest,mixture_energies,read
from h1_multilevel_native_cap import NEW,CERT,OUT as CAP,DATA
from h1_native_cap_total import enclosure,interval
from h1_native_sector_replay import OUTPUT as SECTORS
from h1_semiprime_budget import density

OUT=Path('h1_multilevel_strip_free.json')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--check',action='store_true');args=ap.parse_args()
    cp,price,grouped,sector=map(read,(CAP,NEW,GROUPS,SECTORS))
    assert cp['inputs'][NEW.name]==digest(NEW) and cp['inputs'][CERT.name]==digest(CERT)
    with gzip.open(CERT) as f:
        proof=json.load(f)
    K=len(proof['levels']);cuts=list(map(Q,proof['strip_cuts']))
    assert K==12 and len(cuts)==4 and proof['fit']==FIT.name and proof['all_rough']=='top'
    removed=[f'C{t}' for t in range(3)]
    assert proof['identities']==['P','P-B',*[f'S{k}' for k in range(K)],*removed]
    assert proof['measures'][-3:]==removed and proof['groups']==445
    coefficients={'old_rough':[1,1,1]}
    for k,cut in enumerate(map(Q,proof['cuts'])):
        coefficients[f'PA_rough_{k}']=[int(l>=cut) for l in cuts[:-1]]
        if k==K-1:coefficients[f'all_rough_{k}']=[1,1,1]
        coefficients[f'BD_new_{k}']=[0]*3
        if k:
            coefficients[f'Asum_{k}']=[0]*3;coefficients[f'Dsum_{k}']=[0]*3
    coefficients['strip_U']=[1,1,1]
    assert list(coefficients)==proof['coupled'] and len(proof['factors'])==len(coefficients)
    assert all(len(F)==445 for F in proof['factors'])
    lower=mixture_energies(FORMS,FIT)
    groups=grouped['groups'];means=[density(l,r) for l,r in zip(cuts,cuts[1:])]
    scale=price['scale'];old=np.asarray(price['sector_prices'],dtype=object);new=old.copy()
    change=[Q(0),Q(0)]
    for i,g in enumerate(groups):
        mass=sum(lower[g,0])
        assert mass>0
        earned=sum(min(v*X[i][i] for v in iv) for iv,X in zip(means,proof['affine'][-3:]))
        charge=max(0,ceil(earned/mass))
        new[g,0]-=charge
        for j in g:
            a,b=enclosure(sector['normalized_sector_energies'][j][0])
            change[0]+=a*charge/scale;change[1]+=b*charge/scale
    assert np.all(new<=old) and np.array_equal(old[:,1:],new[:,1:])
    finite=floor(sum((new*lower).ravel())/scale*10**9)
    lo,hi=enclosure(cp['cap_quotient'])
    lo-=change[1];hi-=change[0]
    assert 1<lo<=hi
    scripts=DATA.parent/'scripts'
    paths=[Path(__file__),CAP,CERT,NEW,FIT,GROUPS,FORMS,FORMS.with_suffix('.npz'),SECTORS,TABLE,
           scripts/'mlmodel.py',scripts/'post.py',Path('h1_semiprime_budget.py')]
    out=dict(scope='Continuous cap quotient on the same trial using all twelve higher minorants and no evaluated semiprime strip identities. Positive upper-form constraints are retained. The fourteen remaining affine channels require restoration.',
             inputs={p.name:digest(p) for p in paths},removed_channels=removed,coupled_strip_coefficients=coefficients,
             scale=scale,sector_prices=new.tolist(),finite_lower_billionths=finite,
             exact_cap_cost=interval(*change),cap_quotient=interval(lo,hi),
             lower_trillionths=floor(lo*10**12),upper_trillionths=ceil(hi*10**12),
             benchmark=margin(Q(finite,10**9),lo,Q(0),1))
    if args.check:
        assert read(OUT)==out
    else:
        OUT.write_text(json.dumps(out,separators=(',',':'))+'\n',newline='\n')
    print('strip-free finite',finite,'continuous trillionths',out['lower_trillionths'],out['upper_trillionths'],
          'cost',float(change[1]),flush=True)


if __name__=='__main__':
    main()
