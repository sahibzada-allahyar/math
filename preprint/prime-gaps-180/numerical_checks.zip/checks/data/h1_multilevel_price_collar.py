"""Remove the full-root preimages of the extreme twelve-level prices on the native grid."""
import argparse
from bisect import bisect_right
from collections import defaultdict
from fractions import Fraction as Q
from functools import lru_cache
import json
from math import ceil, floor
from pathlib import Path

import numpy as np
from flint import arb

from h1_combined_fibres_interval import atoms,profile_at
from h1_combined_mass_interval import CellMoments,load_trial
from h1_dickman_taylor import DickmanTaylor,rat,record
from h1_mass_band_prices import FIT,NORM,TABLE,digest,geom,read
from h1_multilevel_native_cap import NEW,OUT as CAP
from h1_native_cap_total import enclosure,interval
from h1_native_sector_replay import OUTPUT as SECTORS
from h1_sunrise_boundary import geometry
from h1_tilted_transform import TiltedMoments,powers_of_two

OUT=Path('h1_multilevel_price_collar.json')
LIMIT=1000


def mask(trial,sector,norm,price):
    _,original,layout=geometry(TABLE)
    with np.load(original['cell_bins'],allow_pickle=False) as arc:
        strata=np.unique(arc['cells'][:,1])
    caps=sorted(int(f[4:-5]) for f in sector['boundaries'])
    n=norm['intervals']-38;h=Q(norm['step']);idx=np.arange(n)
    scaled=price['scale'];rows=price['sector_prices']
    @lru_cache(None)
    def K(j):
        return 1/(Q(1,2)-geom.RS*(j+37)*h-Q('.0001'))
    def bad(s,j):
        a,b,d=rows[s]
        assert b<=0 and d==0
        return a+b*K(j)<-LIMIT*scaled
    prior=0;past=n;out=[];active=set()
    for c in caps:
        own=layout(strata[np.searchsorted(strata,c)],idx)
        starts=np.r_[0,np.flatnonzero(np.diff(own))+1]
        stops=np.r_[starts[1:]-1,n-1]
        first=n
        end=min(n-1,max(int(hi//h)-38 for lo,hi,ceiling in trial['shells'] if ceiling>=c))
        for s,l,r in zip(own[starts],starts,stops):
            if s<0 or not bad(s,int(r)):
                continue
            a,b=int(l),int(r)
            while a<b:
                m=(a+b)//2
                if bad(s,m):
                    b=m
                else:
                    a=m+1
            assert bad(s,a) and (a==l or not bad(s,a-1))
            first=min(first,a)
            if a<=end:
                active.add(int(s))
        start=min(first,prior+past)
        if start<=end:
            if out and out[-1][1]==prior and out[-1][2:]==[start,end] and prior not in trial['caps']:
                out[-1][1]=c
            else:
                out.append([prior,c,start,end])
        past=min(first,past);prior=c
    return out,sorted(active)


def endpoint_name(c):
    return Path(f'h1_multilevel_collar_cap_{c}.json')


def endpoint(c,band,trial,norm,inputs):
    lo,hi,start,end=band
    assert c in (lo,hi) and not any(lo<x<hi for x in trial['caps'])
    e=CellMoments(38,norm['intervals'],Q(norm['S']),precision=512,minimum_cap=lo)
    e.dickman=DickmanTaylor(max(3,ceil(Q(e.n,lo))),degree=56,precision=e.precision)
    _,edges,br=atoms(trial,e)
    grid=list(range(start,end+1))
    sig=list(trial['signatures'])
    coefficients=defaultdict(lambda:[Q(0)]*len(grid))
    for pos,r in enumerate(grid):
        value=(r+Q(38,2))*e.hq
        span=bisect_right(br,value)-1
        assert 0<=span and span+1<len(br)
        rows=profile_at(trial,e,r,hi,span,edges)
        if rows is None:
            continue
        point=(value-br[span])/(br[span+1]-br[span])
        v=[sum(a*point**j for j,a in enumerate(pol)) for pol in rows]
        for ix,x in enumerate(v):
            for iy in range(ix+1):
                key=tuple(sorted(sig[ix]+sig[iy]))
                coefficients[key][pos]+=x*v[iy]*(1 if ix==iy else 2)
    weights=[a*b for a,b in zip(e.coordinate_weights,e.survival(c*e.hq))]
    damping=powers_of_two(1<<(e.n-1).bit_length(),256)
    engine=TiltedMoments(weights,e.midpoints,list(coefficients),38,e.S,damping,256)
    vals=[arb(0) for _ in grid]
    print('native full-root mass',c,'signatures',len(coefficients),'indices',start,end,flush=True)
    for s,v in coefficients.items():
        a,b=engine.moment(s)
        for pos,r in enumerate(grid):
            vals[pos]+=rat(v[pos])*arb(a[r]).union(arb(b[r]))
    engine.clear()
    return dict(scope='Cumulative maximum-cap integral of the fixed polynomial at the upper cap of this band, on the specified full native radial indices.',
                inputs=inputs,cap=c,band=band,mass=record(sum(vals,arb(0))))


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--boundary',nargs='+',type=int)
    ap.add_argument('--check',action='store_true')
    args=ap.parse_args()
    data,norm,price,cap=map(read,(SECTORS,NORM,NEW,CAP))
    for p in (SECTORS,FIT,NORM,NEW,TABLE):
        assert cap['inputs'][p.name]==digest(p)
    trial=load_trial(FIT)
    boxes,active=mask(trial,data,norm,price)
    assert boxes==[[60089,61104,130997,131033],[63177,65536,125501,125537]] and active==[52,72]
    print('extreme-price root boxes',boxes,flush=True)
    paths=[Path(__file__),CAP,FIT,NORM,NEW,SECTORS,TABLE,Path('h1_combined_fibres_interval.py'),
           Path('h1_tilted_transform.py'),*trial['paths']]
    inputs={p.name:digest(p) for p in paths}
    if args.boundary:
        for c in args.boundary:
            band=next(b for b in boxes if c in b[:2])
            p=endpoint_name(c)
            if p.exists() and not args.check:
                saved=read(p)
                assert saved['inputs']==inputs and saved['band']==band and saved['cap']==c
                continue
            row=endpoint(c,band,trial,norm,inputs)
            if args.check:
                assert read(p)==row
            else:
                tmp=p.with_suffix('.pending')
                tmp.write_text(json.dumps(row,indent=2)+'\n',newline='\n');tmp.replace(p)
        return
    den=enclosure(norm['normalized_norm'])
    losses=[];endpoints={}
    for band in boxes:
        l,r=band[:2];current=[]
        for c in (l,r):
            p=endpoint_name(c);row=read(p)
            assert row['inputs']==inputs and row['cap']==c and row['band']==band
            current.append(enclosure(row['mass']));endpoints[p.name]=digest(p)
        (a,b),(u,v)=current
        assert 0<=max(0,u-b)<=v-a
        losses.append((max(0,u-b)/den[1],(v-a)/den[0]))
    lower=sum(v[0] for v in losses);upper=sum(v[1] for v in losses)
    out=dict(scope='Mass removed by a sufficient full-root mask for every reachable native effective price below -1000. The raw source grants still need separate restoration.',
             inputs=inputs,endpoints=endpoints,bands=boxes,reachable_extreme_sectors=active,
             band_norm_ratios=[interval(*v) for v in losses],removed_norm_ratio=interval(lower,upper),
             lower_trillionths=floor(lower*10**12),upper_trillionths=ceil(upper*10**12))
    if args.check:
        assert read(OUT)==out
    else:
        OUT.write_text(json.dumps(out,indent=2)+'\n',newline='\n')
    print('full-root mass removed in trillionths',out['lower_trillionths'],out['upper_trillionths'],flush=True)


if __name__=='__main__':
    main()
