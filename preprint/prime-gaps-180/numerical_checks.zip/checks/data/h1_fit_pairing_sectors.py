"""Alternate a Gram-matrix dual witness and a fit of the fixed shell directions."""
import argparse
from hashlib import sha256
import json
from pathlib import Path

import numpy as np
from scipy.linalg import eigh
from h1_pairing_sdp import HERE,solve


def densities(control,sample):
    mats=sample['deltas'].mean(0)
    mats[:,:,0,0]+=np.array(control['sector_energies'])
    return mats,sample['masses'].mean(0)


def uniform_weights(energies,sol,kappa):
    L,M,R=(np.array(sol[name]) for name in ('dual_prime','dual_exceptional','dual_minorant'))
    return affine_weights(energies,sol['groups'],sol['resolved'],L+R,R-M,kappa)


def affine_weights(energies,groups,resolved,A,H,kappa):
    e=np.array([energies[g].sum(0) for g in groups])
    w=np.sqrt(e[:,0])
    def correction(A,cap):
        t=np.sqrt(cap/e[:,0])
        val,vec=eigh(np.outer(t,t)*A)
        return (vec*vec)@np.maximum(-val,0.)/t**2
    prime=correction(np.outer(w,w)-A,e[:,1])
    ex=correction(H,e[:,2])
    # Use the true deficit interval from Section 4 of the source. The
    # lower endpoint differs from its upper endpoint by 1e-18.
    kmin=.000093307088324061
    assert kmin<=kappa and kappa<.00009330708832407
    slope=-np.diag(H)
    diag=np.diag(A)+np.minimum(kmin*slope,kappa*slope)
    coefficients=np.column_stack([diag,-prime,-ex])/e[:,0,None]
    weights=np.zeros_like(energies)
    for g,v in zip(groups,coefficients):weights[g]=v
    if len(resolved):weights[resolved,0]=1.
    return weights


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('sample',type=Path)
    p.add_argument('--coefficients',type=Path,required=True);p.add_argument('--iterations',type=int,default=2)
    p.add_argument('--classes',type=int,default=160);p.add_argument('--seconds',type=float,default=100.)
    p.add_argument('--permissions',type=Path)
    p.add_argument('--tight-deficit',action='store_true')
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();sample=np.load(a.sample)
    control=json.loads((HERE/str(sample['control'])).read_text())
    if a.permissions:
        from h1_cross_ladders import apply_permissions
        apply_permissions(control,a.permissions)
    old=json.loads(a.coefficients.read_text())
    c=np.array(old['coefficients'])
    mats,mass=densities(control,sample)
    assert len(c)<len(mass)
    c=np.pad(c,(0,len(mass)-1-len(c)))
    out=dict(input=a.sample.name,input_sha256=sha256(a.sample.read_bytes()).hexdigest(),control=str(sample['control']),
             source_coefficients=a.coefficients.name,seeds=sample['seeds'].tolist(),
             scope='Sampled cap forms before restoration. Every reported SDP is reevaluated on the full trial.',
             permissions=a.permissions.name if a.permissions else None,tight_deficit=a.tight_deficit,rows=[])
    for i in range(a.iterations+1):
        v=np.r_[1.,c]
        e=v@mats@v
        data=dict(control,sector_energies=e.tolist())
        sol=solve(data,a.classes,a.seconds,1e-6,a.tight_deficit)
        dm=float(v@mass@v)
        row=dict(coefficients=c.tolist(),mass=dm,lower=sol['lower']/dm,upper=sol['primal_upper']/dm,
                 discarded_roundoff_energy=float(e[e[:,0]<=0,0].sum()),
                 solver_status=sol['solver_status'],solver_iterations=sol['iterations'],n=sol['n'])
        out['rows'].append(row)
        best=max(out['rows'],key=lambda t:t['lower'])
        out['coefficients']=best['coefficients']
        if best is row:
            out['best_sdp']=sol
        print(json.dumps(row),flush=True)
        a.output.write_text(json.dumps(out,indent=2)+'\n')
        if i<a.iterations:
            weights=uniform_weights(e,sol,control['kappa_upper'])
            Q=np.einsum('ab,abij->ij',weights,mats)
            val,vec=eigh((Q+Q.T)/2,mass)
            candidate=vec[1:,-1]/vec[0,-1]
            if not np.all(np.isfinite(candidate)) or np.max(abs(candidate))>8:
                raise ValueError('Unstable coefficient fit')
            if np.max(abs(c-candidate))<1.e-4:break
            c=candidate


if __name__=='__main__':
    main()
