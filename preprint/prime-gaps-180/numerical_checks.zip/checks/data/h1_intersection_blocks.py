"""Test unique-disjointness and intersection signs on genuinely new sieve coordinates."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import numpy as np
from scipy.linalg import solve
from h1_coordinate_shape import configured
from h1_markov_resolvent import Cells,draw,fit_line,gain,transition


BANDS=((.010,.012),(.017,.021),(.027,.034),(.043,.061))
M=1<<len(BANDS)


class Occupancy(Cells):
    size=2*M

    def values(self,idx,cat):
        q=self.r.rho*self.r.t[idx]
        mask=np.zeros(len(q),dtype=int)
        for j,(lo,hi) in enumerate(BANDS):
            mask+=np.any((q>=lo)&(q<hi),axis=1).astype(int)<<j
        return (1+self.profile[idx].sum(axis=1))/self.center,mask+M*(q.sum(axis=1)>.25)


def kernel(P,counts,cross,mode):
    # Deletions put their probability on the diagonal. A negative entry is
    # a signed coupling in the Hamiltonian and does not define a probability.
    out=P.copy()
    if mode in ('promise_control','signed_promise','disjoint'):
        drop=cross&(counts>=2)
        if mode=='disjoint':drop|=cross&(counts==1)
        diag=(P*drop).sum(axis=1)
        out[drop]=0.
        out[np.diag_indices(len(out))]+=diag
    if mode=='signed_promise':out[cross&(counts==1)]*=-1
    if mode=='parity':out[cross&(counts%2==1)]*=-1
    return out


def fits(m,B,flow):
    assert min(m)>0,'All subsets must be observed on both sides of the radial split.'
    P=transition(m,flow)
    ids=np.arange(2*M)
    pc=np.array([i.bit_count() for i in range(M)])
    mask=ids%M;counts=pc[np.bitwise_and.outer(mask,mask)]
    cross=(ids[:,None]//M)!=(ids//M)
    overlap=pc[mask][:,None]-counts
    assert not np.any(P[(overlap>1)|(overlap.T>1)])
    r=B.sum(axis=1)/m-B.sum()/m.sum()
    trials={'residual':fit_line(m,B,r)}
    activity={}
    for length in (1,2,4,8):
        walk=np.linalg.matrix_power(P,length)
        block=walk[:M,M:]
        activity[str(length)]=dict(disjoint=int(np.count_nonzero(block[counts[:M,M:]==0])),
                                   unique=int(np.count_nonzero(block[counts[:M,M:]==1])),
                                   wildcard=int(np.count_nonzero(block[counts[:M,M:]>=2])))
        for mode in ('unsigned','promise_control','disjoint','signed_promise','parity'):
            K=kernel(walk,counts,cross,mode)
            root=np.sqrt(m)
            normalized=root[:,None]*K/root[None,:]
            np.testing.assert_allclose(normalized,normalized.T,atol=5e-13)
            assert np.linalg.eigvalsh(normalized)[-1] <= 1+1e-11
            for s in (.15,.75):
                u=solve((1+s)*np.eye(len(m))-K,r)
                trials[f'{mode}_{length}_{s}']=fit_line(m,B,u)
    return trials,activity


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('dual',type=Path);p.add_argument('coordinate',type=Path)
    p.add_argument('--seed',type=int,required=True);p.add_argument('--runs',type=int,default=6)
    p.add_argument('--power',type=int,default=16);p.add_argument('--tilt',type=float,default=15.)
    p.add_argument('--training',type=Path);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();digest=lambda p:sha256(p.read_bytes()).hexdigest()
    coord=json.loads(a.coordinate.read_text())
    assert digest(a.dual)==coord['dual_sha256'] and a.runs>=4 and a.power>=9
    op,feature,_=configured(a.dual);states=Occupancy(op.r,coord)
    seeds=list(range(a.seed,a.seed+a.runs));used=set(coord['seeds'])
    train=None
    if a.training:
        train=json.loads(a.training.read_text());used.update(train['seeds'])
        assert train['bands']==list(map(list,BANDS)) and train['coordinate_sha256']==digest(a.coordinate)
    assert {s+c for s in seeds for c in (0,100000)}.isdisjoint(s+c for s in used for c in (0,100000))
    blocks=[]
    for seed in seeds:
        blocks.append(draw(op,states,feature.base,seed,a.power,a.tilt))
        print(json.dumps(dict(seed=seed,minimum_cell_mass=blocks[-1][0].min())),flush=True)
    raw=tuple(np.stack(x) for x in zip(*blocks))
    if train:
        source=a.training.with_name(train['sample'])
        assert train['sample_sha256']==digest(source)
        with np.load(source,allow_pickle=False) as z:
            fitting=tuple(z[k].mean(0) for k in ('mass','correction','flow'))
        test=raw
    else:
        mid=len(seeds)//2
        fitting=tuple(x[:mid].mean(0) for x in raw)
        test=tuple(x[mid:] for x in raw)
    trial,activity=fits(*fitting)
    m,B,_=(x.mean(axis=0) for x in test)
    rows={}
    for name,h in trial.items():
        pair=np.array([gain(x,y,h) for x,y in zip(*test[:2])])
        rows[name]=dict(gain=float(gain(m,B,h)),gains=pair.tolist(),multiplier=h.tolist(),
                        descriptive_se=float(pair.std(ddof=1)/np.sqrt(len(pair))))
    sample=a.output.with_suffix('.npz')
    np.savez_compressed(sample,mass=raw[0],correction=raw[1],flow=raw[2])
    out=dict(scope='Held-out fixed-dual scores; artificial sign kernels on empirical configuration transitions.',
             bands=BANDS,radial_split=.25,states=2*M,base=feature.base,sampled_coordinate_score=feature.base+B.sum()/m.sum(),
             original_score=feature.base,sample=sample.name,sample_sha256=digest(sample),seeds=seeds,power=a.power,tilt=a.tilt,
             coordinate=a.coordinate.name,coordinate_sha256=digest(a.coordinate),dual=a.dual.name,dual_sha256=digest(a.dual),
             observed_crossings=activity,rows=rows)
    if a.training:out.update(training=a.training.name,training_sha256=digest(a.training))
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:rows[k]['gain'] for k in ('residual','unsigned_4_0.15','disjoint_4_0.15','signed_promise_4_0.15','parity_4_0.15')}))


if __name__=='__main__':main()
