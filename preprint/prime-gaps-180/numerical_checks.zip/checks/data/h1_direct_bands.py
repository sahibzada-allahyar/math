"""Choose a prime or minorant source separately for each pair of cells and each modulus band."""
import argparse
from fractions import Fraction as Q
from hashlib import sha256
import json
from pathlib import Path

import numpy as np

from h1_bilinear_ladders import weak_engine
from h1_cross_ladders import geom
from h1_rectangle_cover import partition,sides,split_groups


UNIT=10**7
HALF=UNIT//2
PAD=2  # two physical ticks of retreat on each root budget


def digest(file):
    return sha256(file.read_bytes()).hexdigest()


def read(file):
    return json.loads(file.read_text())


def corners(base,path):
    record=path.with_name(base['cells'])
    assert digest(record)==base['cells_sha256'] and not base['historical_outward']
    src=read(record)
    bins=path.with_name(src['cell_bins'])
    pieces=path.with_name(base['pieces'])
    assert digest(bins)==src['cell_bins_sha256'] and digest(pieces)==base['pieces_sha256']
    with np.load(bins,allow_pickle=False) as z:
        cells,step=z['cells'],Q(str(z['step']))
    inner,outer=sides(cells,read(pieces)['pieces'],step,src['intervals'])
    pr,ids=partition(cells,inner,outer,base['coverage']['cuts'])
    pr,ids=split_groups(cells,pr,ids,base['targeted_splits'])
    assert pr.tolist()==base['parent_sectors']
    scale=step*geom.RHO*UNIT
    # Convert complete native cells using rho, above the physical rho_star.
    # The right radial endpoint includes all 37 retained coordinate widths.
    tick=lambda a: (a*scale.numerator+scale.denominator-1)//scale.denominator
    # Use Python integers for the multiplication by the exact grid ratio.
    triples=sorted(set((int(i),int(c),int(h)) for i,c,h in zip(ids,cells[:,1],cells[:,3])))
    maxima={}
    for i,c,h in triples:
        maxima[i,c]=max(maxima.get((i,c),-1),h)
    result=[]
    for i in range(len(pr)):
        best=-1
        for (j,c),h in sorted(((k,h) for k,h in maxima.items() if k[0]==i),reverse=True):
            if h>best:
                result.append((i,tick(h+38),tick(c+1)))
                best=h
    owner,radius,fragment=np.array(result,dtype=np.int64).T
    assert radius.max()<29*UNIT//100 and fragment.max()<int((Q('.17277'))*UNIT)
    return owner,radius,fragment


def ceil_div(x,y):
    return -((-x)//y)


def order_three(s,t,z,w):
    # The budget W is B+delta in physical units, and C=W-A.
    # Eliminate L from the plateau and cap constraints, then eliminate A.
    # A lower or upper bound is represented by (slope*W+offset)/den.
    k=np.maximum(3*z,4*w)
    low=[(1,0,2),(0,s+PAD,1),(0,7*z,4),(3,7*z,10)]
    high=[(1,-t-PAD,1),(7,0,12),(5,-5*k,2),(8,-5*k,8)]
    need=k+z
    for a,b,c in low:
        for d,e,f in high:
            assert c*d-a*f>0
            need=np.maximum(need,ceil_div(f*b-c*e,c*d-a*f))
    return need


def needs(s,t,z,w,rule):
    # At a band that actually needs a source s+t > 1/2. Since s,t<.29,
    # the order-two lower-transfer guards then follow from 3*.29-.5<.5.
    # max(z,delta)=z for every stored maximum tested below.
    both=s+t+2*PAD
    def first(x,y,cap):
        return np.maximum(np.maximum(both,2*y+2*PAD),y+2*cap)
    one=np.minimum(first(s,t,z),first(t,s,w))
    two=np.maximum(np.maximum(both,t+2*z),s+2*w)
    if rule in ('owner','transfer'):
        large,small=np.maximum(z,w),np.minimum(z,w)
        flexible=np.maximum(4*large,large+4*small)
        if rule=='transfer':
            # Lemma 4.1 requires the size guard but no source-overlap
            # guard. Proposition 2.3 needs only A+C <= B+delta and
            # the four tail/opposite-root predicates.
            one=np.minimum(np.maximum(2*t,t+2*z),np.maximum(2*s,s+2*w))
            two=np.maximum(t+2*z,s+2*w)
            return [one,two,flexible]
        return [one,two,np.maximum(both,flexible)]
    three=np.minimum(order_three(s,t,z,w),order_three(t,s,w,z))
    return [one,two,three]


def source_rows(fn,limit,width):
    rows=[]
    for lo in range(HALF,limit,width):
        hi=min(lo+width,limit)
        omega=Q(hi-HALF,2*UNIT)
        deltas=[]
        for order in (1,2,3):
            zero,one=[fn(order,omega,x) for x in (0,1)]
            bounds=[-a/(one[k]-a) for k,a in zero.items() if one[k]<a]
            # Stay strictly below every decreasing guard. Check all other
            # guards at the resulting rational point, including rising ones.
            delta=min(bounds)*UNIT
            ticks=(delta.numerator-1)//delta.denominator
            if ticks<=0 or min(fn(order,omega,Q(ticks,UNIT)).values())<=0:
                ticks=0
            deltas.append(ticks)
        rows.append((lo,hi,deltas))
    return rows


def classify(s,t,z,w,rows,rule):
    want=needs(s,t,z,w,rule)
    total=s+t
    possible=total<=rows[-1][1]
    for lo,hi,deltas in rows:
        hit=total<=lo
        for req,delta in zip(want,deltas):
            if delta:
                assert delta<=min(z.min(),w.min())
                hit=hit|(req<=lo+delta)
        possible&=hit
    return possible


def calculate(base,path,book,width,rule):
    owner,r,z=corners(base,path)
    num=len(base['codes'])
    assert 0<width<=5000
    level=Q('.5291')
    weak=weak_engine(book,level,Q(str(base['fragment_cap'])))
    sources=[('prime_mask',geom.fixed.old_input_slacks,5249980),
             ('minorant_mask',geom.fixed.new_input_slacks,5283990),
             ('refined_grant',weak.fixed.new_input_slacks,5290990)]
    results={};stats={};schedule={}
    for key,fn,limit in sources:
        rows=source_rows(fn,limit,width)
        schedule[key]=rows
        if key=='refined_grant':
            prior=np.array([[v=='1' for v in row] for row in base[key]])
        else:
            prior=np.array(base[key],bool)
        # A pair of sectors is covered if every one of its maximal corner
        # products passes. Known whole products are retained.
        failed=np.zeros((num,num),bool)
        for start in range(0,len(owner),128):
            idx=np.arange(start,min(start+128,len(owner)))
            good=classify(r[idx,None],r[None,:],z[idx,None],z[None,:],rows,rule)
            i,j=np.nonzero(~good)
            failed[owner[idx[i]],owner[j]]=True
        fresh=~failed
        assert np.array_equal(fresh,fresh.T)
        added=fresh&~prior
        energy=np.array(base['sector_energies'])[:,0].clip(0)
        stats[key]=dict(added_upper_triangle=int(np.triu(added).sum()),
                        added_product_energy=float(energy@added@energy))
        results[key]=prior|fresh
    return results,dict(corners=len(owner),sectors=num,width=width,channels=stats),schedule


def verify(data,base,path):
    book=path.resolve().parent.parent/'sensitivity'/'bilinear_minorant.json'
    assert digest(book)==data['band_minorant_sha256']
    masks,stats,rows=calculate(base,path,read(book),data['band_summary']['width'],data.get('band_rule','plateau'))
    assert json.dumps(data['band_schedule'])==json.dumps(rows)
    for key,expected in masks.items():
        got=data[key]
        if key=='refined_grant':
            got=[[c=='1' for c in row] for row in got]
        assert np.array_equal(got,expected)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('base',type=Path)
    parser.add_argument('--width',type=int,default=1000)
    parser.add_argument('--rule',choices=('plateau','owner','transfer'),default='plateau')
    parser.add_argument('--transfer-from',type=Path,help='Identify a table with identical permissions for witness reuse.')
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    base=read(args.base)
    book=args.base.resolve().parent.parent/'sensitivity'/'bilinear_minorant.json'
    masks,stats,rows=calculate(base,args.base,read(book),args.width,args.rule)
    # The old outward mask bounds only the original collection of ladders.
    # No outward comparison for the enlarged collection is supplied here.
    out=dict(base)
    out.pop('refined_outward_grant',None)
    out.update(status='Finite cap masks with a separate arithmetic row on each modulus band.',
               band_base=args.base.name,band_base_sha256=digest(args.base),band_minorant_sha256=digest(book),
               band_summary=stats,band_schedule=rows)
    if args.rule!='plateau':
        out['band_rule']=args.rule
    for k,v in masks.items():
        out[k]=[''.join(map(str,a)) for a in v.astype(int)] if k=='refined_grant' else v.astype(int).tolist()
    if args.transfer_from:
        other=read(args.transfer_from)
        assert all(out[k]==other[k] for k in ('codes','sources','intervals','kappa_upper','prime_mask',
                                               'minorant_mask','refined_grant','targeted_splits'))
        assert json.dumps(out['band_schedule'])==json.dumps(other['band_schedule'])
        out.update(base_control=args.transfer_from.name,base_control_sha256=digest(args.transfer_from))
    args.output.write_text(json.dumps(out,separators=(',',':'))+'\n')
    print(json.dumps(stats),flush=True)


if __name__=='__main__':
    main()
