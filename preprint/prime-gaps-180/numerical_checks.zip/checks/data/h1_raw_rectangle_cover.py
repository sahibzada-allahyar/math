"""Certify rectangles of the H1 erased trial against every opposite root and divisor."""
import argparse
from fractions import Fraction as Q
from pathlib import Path
import json

import numpy as np

from h1_bilinear_ladders import weak_engine
from h1_direct_bands import HALF, UNIT, corners, digest, geom, read, source_rows
from h1_cover_pairings import MINORANTS, TABLE


CERT = Path('h1_decoupled_coarsened_1e14.json')
FIT = Path('h1_decoupled_coarsened_1e14_fit.json')
PRICES = Path('h1_decoupled_coarsened_1e14_prices.json')
NORM = Path('h1_combined_mass_native_interval.json')
FIBRES = Path('h1_combined_fibres_native_interval.json')
NAMES = ('prime','sharp','higher','semiprime_low','semiprime_middle','semiprime_high')


def rank_atoms(radius, cap):
    """Two weighted thresholds dominate the tail of every admissible partner."""
    cap = np.minimum(radius,cap)
    n = radius//cap
    lower = (radius+n)//(n+1)  # upward rounding of radius/(n+1)
    return ((cap,n*cap),(lower,radius-n*cap))


def schedules(table, certificate):
    width = table['band_summary']['width']
    assert digest(MINORANTS)==table['band_minorant_sha256']
    high = weak_engine(read(MINORANTS),Q('.5291'),Q(table['fragment_cap']))
    result = []
    for name,fn in (('prime_mask',geom.fixed.old_input_slacks),
                    ('minorant_mask',geom.fixed.new_input_slacks),
                    ('refined_grant',high.fixed.new_input_slacks)):
        rows = table['band_schedule'][name]
        assert json.loads(json.dumps(source_rows(fn,rows[-1][1],width)))==rows
        result.append(np.array([[lo,hi,*d] for lo,hi,d in rows],np.int64))
    cuts = list(map(Q,certificate['cuts']))
    assert cuts==list(map(Q,('.2857','.36','.416407','.5')))
    for b in cuts[:-1]:
        sigma = Q(1,2)-b+Q('1e-6')
        def guards(order,w,d):
            a,c,t = (54,15,5) if order==1 else (56,16,4)
            return dict(high=1-68*w-14*d,bilinear=1-a*w-c*d-t*sigma)
        rows = source_rows(guards,5294100,500)
        result.append(np.array([[lo,hi,*d] for lo,hi,d in rows],np.int64))
    return result


def band_panels(schedule,radii):
    """For each panel use only rows that the particular radius sum can reach."""
    assert schedule[0,0]==HALF and np.array_equal(schedule[:-1,1],schedule[1:,0])
    for start in range(0,len(schedule),40):
        rows = schedule[start:start+40]
        j = np.searchsorted(rows[:,0],radii,side='left')-1
        enabled = j >= 0
        j = np.maximum(j,0)
        d = rows[:,2:]
        delta = np.minimum.accumulate(d,axis=0)[j]
        budget = np.minimum.accumulate(rows[:,0,None]+d,axis=0)[j]
        yield enabled,delta,budget


def compare_atoms(atoms,panels,radii,limit):
    """One source order throughout each panel is sufficient. Orders may change between panels."""
    valid = radii<=limit
    breakpoints = [u for u,_ in atoms]
    tails = [sum(np.where(y>=u,weight,0) for y,weight in atoms) for u in breakpoints]
    for enabled,delta,budget in panels:
        alternatives = ~enabled
        for j in range(3):
            legal = delta[:,j]>0
            for u,tail in zip(breakpoints,tails):
                legal &= (u<=delta[:,j]) | (tail+(j+1)*u<=budget[:,j])
            alternatives |= legal
        valid &= alternatives
    return valid


def geometry_data(table,cert):
    owner,radius,fragment = corners(table,TABLE)
    max_r = np.zeros(len(table['codes']),np.int64)
    max_z = np.zeros_like(max_r)
    np.maximum.at(max_r,owner,radius)
    np.maximum.at(max_z,owner,fragment)
    return tuple(np.array([int(max(v[g])) for g in cert['groups']],np.int64) for v in (max_r,max_z))


def full_checks():
    # Enumerate actual integer parts and each deletion, with ties. Test the
    # two-atom envelope at every integer threshold independently of its formula.
    tested = 0
    for R in range(2,14):
        for Z in range(1,R+1):
            atoms = rank_atoms(R,Z)
            # Unbounded integer knapsack: attainable largest tail sum using
            # only factors between u and Z, capped at total R.
            for u in range(1,Z+2):
                possible = {0}
                for total in range(R+1):
                    if total in possible:
                        possible.update(total+k for k in range(u,Z+1) if total+k<=R)
                upper = sum(int(w) for v,w in atoms if v>=u)
                assert upper>=max(possible)
                if u!=(R//(R//Z+1))+1 or R%(R//Z+1)==0:
                    assert upper==max(possible)
                tested += 1
    return tested


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    table,cert,prices,fit,norm,fibres=map(read,(TABLE,CERT,PRICES,FIT,NORM,FIBRES))
    assert prices['inputs'][CERT.name]==digest(CERT)
    assert fit['inputs'][PRICES.name]==digest(PRICES)
    for p in (TABLE,FIT):
        assert norm['inputs'][p.name]==fibres['inputs'][p.name]==digest(p)
    assert fibres['caps']==norm['caps'] and fibres['step']==norm['step']
    unit_step=Q(norm['step'])*geom.RHO*UNIT
    radius,fragment=geometry_data(table,cert)
    assert len(radius)==len(fragment)==len(cert['groups'])==445
    raw_caps=[int(c) for c in fibres['caps']]
    upper_caps=[int(-((-c*unit_step)//1)) for c in raw_caps]
    schedules_by_channel=schedules(table,cert)
    report=[]
    atom_checks=full_checks()
    for name,A,rows in zip(NAMES,cert['affine'],schedules_by_channel):
        matrix=np.asarray(A,np.int64)
        assert np.array_equal(matrix,matrix.T)
        i,j=np.nonzero(matrix)
        total=radius[i]+radius[j]
        bv=total<=HALF
        a,b=i[~bv],j[~bv]
        # Deduplicate equal geometric triples for efficient exact compilation.
        geo,reverse=np.unique(np.stack((radius[a],radius[b],fragment[a],fragment[b]),axis=1),
                              return_inverse=True,axis=0)
        ra,rb,za,zb=geo.T
        pair_total=ra+rb
        panels=list(band_panels(rows,pair_total))
        opposite=rank_atoms(rb,zb)
        weights=abs(matrix[a,b]).astype(object)
        per_cap=[]
        previous=np.ones(len(a),bool)
        for cap,ctick in zip(raw_caps,upper_caps):
            chosen=np.minimum(za,ctick)
            atoms=(*rank_atoms(ra,chosen),*opposite)
            passing=compare_atoms(atoms,panels,pair_total,rows[-1,1])[reverse]
            assert np.all(~passing|previous)
            previous=passing
            per_cap.append(dict(native_cap=cap,above_half_ordered_mixed_rectangles=int(passing.sum()),
                                absolute_affine_numerator=int(weights[passing].sum())))
        report.append(dict(channel=name,active_ordered=len(i),ordinary_range_ordered=int(bv.sum()),
                           above_half_ordered=len(a),above_half_absolute_affine_numerator=int(weights.sum()),
                           mixed_rectangles=per_cap))
        print(name,'above half',len(a),'cap counts',[v['above_half_ordered_mixed_rectangles'] for v in per_cap],flush=True)
    paths=(Path(__file__),CERT,TABLE,PRICES,FIT,NORM,FIBRES,MINORANTS,Path('h1_direct_bands.py'),
           Path('h1_bilinear_ladders.py'),Path('h1_semiprime_budget.py'))
    doc=dict(scope='Certified mixed raw-support rectangles on the coarsened 38-shift geometry. Counts and affine weights are not error estimates.',
             inputs={p.name:digest(p) for p in paths},small_knapsack_checks=atom_checks,
             price_scale=prices['scale'],native_fragment_ticks=upper_caps,channels=report)
    if args.check: assert doc==read(args.output)
    else: args.output.write_text(json.dumps(doc,indent=2)+'\n',newline='\n')


if __name__=='__main__':
    main()
