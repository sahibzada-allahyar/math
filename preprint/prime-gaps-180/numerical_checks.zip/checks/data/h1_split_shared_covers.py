"""Price all four positive measures and their joint Selberg bounds on the refined sectors."""
import argparse
from math import floor
from pathlib import Path

import numpy as np
from scipy.linalg import eigh

from h1_cover_pairings import model, TILES, FIT, TABLE, DUAL
from h1_shared_rough_pricing import certify
from h1_sunrise_boundary import digest, read
from verify_pairing_envelope import quantize, SCALE


def solve(data, start, iterations, no_joint=False, strips=(), initial_factors=None,
          stages=(2e-4,4e-5,8e-6,1.6e-6), observer=None, linear_spec=None,
          measure_weights=None):
    e,p,m,g,k,kt,fixed,_,upper,coupled=data
    if no_joint:
        coupled=[]
    n=len(e)
    i,j=np.triu_indices(n)
    diag=i==j
    mass=e[:,0].astype(float)
    caps=np.array([v.astype(float) for v in upper])
    scales=np.sqrt(caps[:,i]*caps[:,j])
    beta=np.ones(len(upper)) if measure_weights is None else np.asarray(measure_weights,float)
    assert beta.shape==(len(upper),) and min(beta)>0
    scales*=beta[:,None]
    cs=np.array([b.astype(float) for _,b in coupled]).reshape(-1,n)
    ys=np.sqrt(cs[:,i]*cs[:,j])
    c=len(cs)
    measures=len(upper)
    identities=len(start)
    rows=measures+c
    # First three coefficients multiply the evaluated forms P, P-B and
    # P-B-A-D. The remaining variables are the scaled PSD multipliers.
    if linear_spec is None:
        assert measures==4+len(strips) and identities==3+len(strips)
        core=np.zeros((measures,identities))
        core[:4,:3]=[[-1,-1,-1],[0,1,1],[0,0,1],[0,0,1]]
        for t in range(len(strips)):
            core[t+4,t+3]=-1
        masks=(p,m,g,*(s[0] for s in strips))
        density=[1.,1-float(sum(k)/2),1-float(sum(kt)/2),
                 *[float(sum(s[1])/2) for s in strips]]
    else:
        core,masks,density=linear_spec
        core=np.asarray(core,float)
        assert core.shape==(measures,identities) and len(masks)==len(density)==identities
    design=np.zeros((len(i),rows,identities+c))
    design[:,:measures,:identities]=scales.T[:,:,None]*core
    for t,(alpha,_) in enumerate(coupled):
        design[:,:measures,identities+t]=scales.T*np.array(alpha,float)/ys[t,:,None]
        design[:,measures+t,identities+t]=1.
    allow=np.column_stack([v[i,j] for v in masks])
    weights=np.r_[density,-np.ones(c)]
    projector=np.zeros((rows,rows,len(i)))
    recover=np.zeros((identities+c,rows,len(i)))
    bias=np.zeros((identities+c,len(i)))
    for mask in range(1<<identities):
        valid=np.array([bool(mask&(1<<u)) for u in range(identities)])
        take=np.flatnonzero((allow==valid).all(1))
        cols=np.r_[np.flatnonzero(valid),np.arange(identities,identities+c)]
        if not len(take) or not len(cols):
            continue
        # Work in small batches to bound the temporary footprint.
        for batch in np.array_split(take,1+len(take)//4096):
            b=design[batch][:,:,cols]
            t=b.transpose(0,2,1)
            inv=np.linalg.inv(t@b)
            pinv=inv@t
            projector[:,:,batch]=(b@pinv).transpose(1,2,0)
            for l,col in enumerate(cols):
                recover[col,:,batch]=pinv[:,l,:]
                bias[col,batch]=(inv[:,l,:]@weights[cols])*diag[batch]
    drift=np.einsum('nij,jn->in',design,bias)
    del design
    offset=np.zeros((rows,len(i)))
    offset[0]=np.sqrt(mass[i]*mass[j])*scales[0]
    def pack(x):
        affine=offset.copy()
        affine[:measures]+=scales*(core@x[:identities])
        affine[measures:]=x[identities:]
        for t,(alpha,_) in enumerate(coupled):
            affine[:measures]+=scales*np.array(alpha,float)[:,None]*(x[identities+t]/ys[t])
        return affine
    def full(v):
        out=np.empty((n,n))
        out[i,j]=out[j,i]=v
        return out
    def candidate(x):
        feasible=x.copy()
        fac=[]
        for t in range(c):
            ev,V=eigh(full(x[identities+t]),check_finite=False)
            good=ev>0
            F=V[:,good]*np.sqrt(ev[good])
            feasible[identities+t]=(F@F.T)[i,j]
            fac.append(F/np.sqrt(cs[t])[:,None])
        vals=pack(feasible)
        score=float(fixed)+weights@feasible[:,diag].sum(1)
        for b,a in zip(beta,vals[:measures]):
            score+=np.minimum(eigh(full(a),eigvals_only=True,check_finite=False),0.).sum()/b
        return score,feasible,fac
    lin=np.array([np.asarray(v,float)[i,j]/SCALE for v in start])
    init=np.vstack((lin,np.zeros((c,len(i)))))
    if initial_factors is not None:
        assert len(initial_factors)==c
        for t,f in enumerate(initial_factors):
            scaled=np.asarray(f,float)/SCALE
            init[identities+t]=(scaled@scaled.T)[i,j]*ys[t]
    best,saved,factors=candidate(init)
    history=[]
    prices=None
    for tau in stages:
        z=pack(saved)
        if prices is not None:
            z+=tau*prices
        for t in range(iterations):
            delta=z-offset
            x=offset+np.einsum('ijk,jk->ik',projector,delta)+tau*drift
            if t%30==0 or t==iterations-1:
                coeff=np.einsum('ijk,jk->ik',recover,delta)+tau*bias
                score,trial,fac=candidate(coeff)
                if observer is not None:
                    shadow=(z-x)/tau
                    observer([full(scales[u]*shadow[u]) for u in range(measures)],
                             tau,t,score)
                if score>best:
                    best,saved,factors,prices=score,trial,fac,(z-x)/tau
            for krow in range(rows):
                h=2*x[krow]-z[krow]
                ev,V=eigh(full(h),check_finite=False)
                bad=ev<0
                amount=-ev[bad] if krow>=measures else np.minimum(-ev[bad],tau/beta[krow])
                correction=((V[:,bad]*amount)@V[:,bad].T)[i,j]
                z[krow]+=1.65*(h+correction-x[krow])
        history.append(dict(tau=tau,steps=iterations,lower=best))
        print(history[-1],flush=True)
    affine=[quantize(full(v)) for v in saved[:identities]]
    factors=[quantize(F) for F in factors]
    if no_joint:
        factors=[np.empty((n,0),dtype=object) for _ in data[-1]]
    return affine,factors,history


def main():
    import json
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('cover',type=Path)
    ap.add_argument('--warm',type=Path)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--steps',type=int,default=85)
    ap.add_argument('--no-joint',action='store_true')
    ap.add_argument('--check',action='store_true')
    a=ap.parse_args()
    data,lin,inputs,_=model(a.cover)
    if a.warm:
        warm=read(a.warm)
        assert all(warm['inputs'][f.name]==inputs[f.name] for f in (TILES,FIT,TABLE,DUAL))
        lin=[np.array(x,dtype=object) for x in warm['affine']]
        inputs[a.warm.name]=digest(a.warm)
    if a.check:
        doc=read(a.output)
        assert doc['inputs']==inputs and a.no_joint==doc['no_joint']
        lin=[np.array(x,dtype=object) for x in doc['affine']]
        fac=[np.array(x,dtype=object) for x in doc['factors']]
    else:
        lin,fac,log=solve(data,lin,a.steps,a.no_joint)
    if a.no_joint:
        assert all(F.shape==(len(data[0]),0) for F in fac)
    value=floor(certify(data,lin,fac)*10**9)
    if a.check:
        assert value==doc['lower_billionths']
    else:
        doc=dict(scope='Finite cap-model lower bound on the stored nineteen-tile forms.',
                 inputs=inputs,no_joint=a.no_joint,lower_billionths=value,history=log,
                 affine=[x.tolist() for x in lin],factors=[x.tolist() for x in fac])
        a.output.write_text(json.dumps(doc,separators=(',',':'))+'\n')
    print('four measures',len(data[0]),value,flush=True)


if __name__=='__main__':
    main()
