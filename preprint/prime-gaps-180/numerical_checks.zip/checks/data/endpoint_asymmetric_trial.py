"""Distinguish the risky endpoints with a permutation-averaged signed trial."""
import argparse
from collections import Counter, defaultdict
from itertools import permutations
import json
from pathlib import Path

import numpy as np
from scipy.linalg import eigh
from endpoint_pair_scan import HERE, BACKEND, geometry, setup, first_fibres, double_fibres
from incidence_multicap_spline_ritz import limited_shells


def prefactors(a, erased_sets):
    remaining = len(a)-len(erased_sets[0])
    result = []
    for erased in erased_sets:
        erased_weights = a[list(erased)] if erased else np.empty(0)
        total = erased_weights.sum()
        dispersion = a@a-erased_weights@erased_weights-total**2/remaining
        result.append([total, total*total, dispersion/(remaining-1)])
    return np.mean(result, axis=0)


def check_permutation_formula():
    a = np.array([-.9, -.9, .1, .6, 1.1])
    assert abs(a.sum()) < 1.e-12
    remaining_t = np.array([.13,.22,.39])
    base, tagged = 1.3,.37
    samples = []
    for erased in [(0,2),(0,1),(3,4)]:
        kept = [i for i in range(5) if i not in erased]
        for perm in permutations(kept):
            value = sum(a[list(erased)])*tagged+base*(a[list(perm)] @ remaining_t)
            samples.append([base*value,value**2])
    avg, second, dispersion = prefactors(a, [(0,2),(0,1),(3,4)])
    delta = tagged-base*remaining_t.mean()
    predicted = [avg*base*delta, second*delta**2+dispersion*base**2*np.sum((remaining_t-remaining_t.mean())**2)]
    error = np.max(abs(np.mean(samples,axis=0)-predicted))
    assert error < 1.e-12
    return float(error)


def original_rows(r, vector, limits):
    rows = defaultdict(lambda: defaultdict(lambda: np.zeros(r.n)))
    for v, limit in zip(vector.reshape(-1,r.nb), limits):
        radial = (v*r.scale).reshape(-1,r.nr) @ r.radial_values
        for shell in limited_shells(r.shells['outer'],limit):
            for sig, val in zip(r.signatures,radial):
                rows[shell[2]][sig] += val*r.mask(shell,r.k)
    return rows


def face_weights(r, cap, domains, ell, kappa):
    def mask(shells):
        answer = np.zeros(r.n,dtype=bool)
        for shell in shells:
            if cap<=shell[2]:
                answer |= r.mask(shell,r.k-1)
        return answer
    old = mask(r.shells['base'])
    enlarged = mask(r.shells['enlarged'])
    covered = np.logical_or.reduce([mask(value) for value in domains.values()])
    tail = mask(r.shells['full']) & ~covered
    return old.astype(float)+(1-ell)*(enlarged & ~old)-(1/ell-1)*kappa*r.radial_weight()*tail


def form(r, order, base_rows, tagged_rows, factors, domains, ell, kappa):
    """Integrate the 2x2 pencil for F and F sum_i a_i t_i, sum_i a_i=0."""
    remaining = r.k-order
    total = (np.arange(r.n)+remaining/2)*r.h
    tilt = np.exp(r.tilt*(total-r.center))
    caps = set(base_rows)
    if order==1:
        caps.update(r.caps)
        caps.update(sh[2] for domain in domains.values() for sh in domain)
    caps = sorted(c for c in caps if c<=max(base_rows))
    previous = {}
    result = np.zeros((2,2))
    mean_a, mean_aa, dispersion = factors
    for cap in caps:
        base = defaultdict(lambda: np.zeros(r.n))
        marked = defaultdict(lambda: np.zeros(r.n))
        for limit, part in base_rows.items():
            if limit >= cap:
                for sig, value in part.items():
                    base[sig] += value
        for limit, part in tagged_rows.items():
            if limit >= cap:
                for sig, value in part.items():
                    marked[sig] += value
        weights = tilt*(face_weights(r,cap,domains,ell,kappa) if order==1 else 1.)
        signatures = sorted(base)
        current = {}
        def layer(sig):
            if sig not in current:
                current[sig] = r.moment(cap,remaining,sig).copy()
            return current[sig]-previous.get(sig,0.)
        for i, sig in enumerate(signatures):
            B = base[sig]
            D = marked[sig] - B*total/remaining
            for j in range(i+1):
                other = signatures[j]
                b = base[other]
                d = marked[other] - b*total/remaining
                sig2 = tuple(sorted(sig+other))
                moment = layer(sig2)
                extra = layer(tuple(sorted(sig2+(2,))))
                scale = 1 if i==j else 2
                result[0,0] += scale * (weights @ (B*b*moment))
                result[0,1] += scale*.5*mean_a * (weights @ ((B*d+b*D)*moment))
                result[1,1] += scale*(weights @ (mean_aa*D*d*moment
                    +dispersion*B*b*(extra-total**2/remaining*moment)))
        previous = current
        r.clear_cache()
    result[1,0] = result[0,1]
    return result*(r.rho*r.h/r.Z)**order*(r.k if order==1 else 1)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dimension',type=int,required=True)
    p.add_argument('--reference',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args = p.parse_args()
    baseline = json.loads(args.reference.read_text())
    reference = next(row for row in baseline['rows'] if row['k']==args.dimension)
    source = json.loads((HERE/'h1_k39_control_n32768.json').read_text())
    prior = json.loads((BACKEND/'results/incidence_multicap_spline_a6_n32768.json').read_text())
    shifts = json.loads((HERE/'endpoint_tuple_inputs.json').read_text())[str(args.dimension)]['shifts']
    geom = geometry(shifts)
    edges = [tuple(shifts.index(v) for v in edge) for edge in geom['bad_pairs']]
    degrees = Counter(i for e in edges for i in e)
    a = np.array([degrees[i] for i in range(len(shifts))],dtype=float)
    a -= a.mean()
    r,limits,domains = setup(len(a),baseline['intervals'],source,prior)
    v = np.asarray(source['best_coefficients'])
    ell = reference['ell']
    common = (domains,ell,prior['kappa'])
    zero = original_rows(r,v,limits)
    mass = form(r,0,zero,{},prefactors(a,[()]),*common)
    first = first_fibres(r,v,limits)
    marked = first_fibres(r,v,limits,marked_power=1)
    prime = form(r,1,first,marked,prefactors(a,[(i,) for i in range(r.k)]),*common)
    second,_ = double_fibres(r,v,limits,first=first)
    marked2,_ = double_fibres(r,v,limits,marked_power=1,first=first)
    pair = form(r,2,second,marked2,prefactors(a,edges),*common)*len(edges)
    relative_mass_error = abs(mass[0,0]/reference['mass']-1)
    q_error = abs(prime[0,0]/mass[0,0]-reference['cap_quotient'])
    ratio_error = abs(pair[0,0]/(mass[0,0]*len(edges))-reference['double_fibre_physical_ratio'])
    assert max(relative_mass_error,q_error,ratio_error)<1.e-7
    assert min(eigh(mass,eigvals_only=True))>0 and min(eigh(pair,eigvals_only=True))>0
    assert abs(prime[0,1])+abs(mass[0,1]) < 1.e-11*mass[0,0]
    critical,vec = eigh(prime-mass,pair)
    optimum = vec[:,-1]/vec[0,-1]
    rows = []
    for cost in [1,2,3,4,6,8,12]:
        val,vec = eigh(prime-cost*pair,mass)
        direction = vec[:,-1]/vec[0,-1]
        rows.append(dict(hypothetical_pair_multiplier=cost, cap_score=float(val[-1]),
                         coefficient=float(direction[1])))
    out = dict(status='UNCERTIFIED_ASYMMETRIC_ENDPOINT_PENCIL',dimension=r.k, intervals=r.N,
               bad_pairs=geom['bad_pairs'],degree_contrast=a.tolist(),mass=mass.tolist(),
               prime_form=prime.tolist(),sum_of_pair_forms=pair.tolist(),pencils=rows,
               numerical_controls=dict(relative_mass_error=float(relative_mass_error),
                   quotient_error=float(q_error),pair_ratio_error=float(ratio_error),
                   permutation_enumeration_error=check_permutation_formula()),
               symmetric_critical=reference['break_even_multiplier_before_restoration'],
               optimized_critical=float(critical[-1]),coefficient_at_critical=float(optimum[1]),
               scope='Floating cap integrals. Every tested arithmetic pair multiplier is hypothetical. No restoration or new prime-gap bound.')
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'k':r.k,'critical':out['optimized_critical'],'cost_four':rows[3]}))


if __name__=='__main__':
    main()
