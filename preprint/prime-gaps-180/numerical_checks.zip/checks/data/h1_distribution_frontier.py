"""Exact parameter tradeoffs and numerical 38-shift tests for the sharp minorant."""
import argparse
from fractions import Fraction as Q
from functools import lru_cache
import json
from math import comb
from pathlib import Path
import sys
import numpy as np

from h1_geometry_scan import HERE,BACKEND,BASE_RADIUS,model_on_geometry,cap_shells,scalar_replay
import parametric_fragment_geometry as parametric
from subtraction_from_geometry import build_subtractions
sys.path.insert(0,str(BACKEND/'experiments/analytic_support'))
import sharp_minorant_level_table as table


EPS=Q(1,10**7)
C_GAP=Q(3,10**7)
I_RESERVE=Q(1,10**5)


def cutoffs(theta,delta):
    omega=(theta-Q(1,2))/2
    a=Q(3,10)+8*omega+table.TAU+Q(16,5)*(delta+EPS)
    I=Q(1,4)+7*omega+2*delta+table.TAU+I_RESERVE
    return a,I,a+C_GAP


def constraints(theta,delta):
    return table.full_slacks(theta,*cutoffs(theta,delta),delta)


def feasible_interval(theta):
    # All guards here are affine after substituting the three cutoffs.
    s0=constraints(theta,Q(0));s1=constraints(theta,Q(1))
    middle=constraints(theta,Q(1,2))
    assert all(2*middle[n]==s0[n]+s1[n] for n in s0)
    lower=Q(0);upper=Q(1);wall='delta<1'
    for name,start in s0.items():
        slope=s1[name]-start
        if slope>0:
            lower=max(lower,-start/slope)
        elif slope<0 and start/(-slope)<upper:
            upper=start/(-slope);wall=name
        elif slope==0 and start<=0:
            raise ValueError('Constant guard failed: '+name)
    if lower>=upper:
        raise ValueError('No feasible terminal density')
    return lower,upper,wall


@lru_cache(None)
def moments():
    return json.loads(table.MOMENTS.read_text())


def deficit(a):
    # The signed simplex moments do not depend on u. Recompute the
    # absolute Taylor remainder at the current u, including u above the
    # largest row in the source's six-level interpolation table.
    data=moments()
    u=a-Q(2,5);u0=Q(data['parameters']['u'])
    degree=data['parameters']['series_degree']
    lo=Q(0);hi=Q(0);rhos=[]
    for simplex in data['polytopes'][0]['simplices']:
        rho=Q(simplex['rho'])*u/u0
        assert 0<rho<1
        rhos.append(rho)
        expected=list(map(Q,simplex['homogeneous_expected_moments']))
        assert len(expected)==degree+1
        partial=sum(m*(5*u/12)**n for n,m in enumerate(expected))
        tail=(1-rho)**-5-sum(comb(n+4,4)*rho**n for n in range(degree+1))
        assert 0<tail<partial
        factor=6*5**5*u**4*Q(simplex['volume'])
        lo+=factor*(partial-tail);hi+=factor*(partial+tail)
    rough=1-2*a
    assert Q(390625,144)*u**4<lo<hi<Q(125,144)*u**4/(rough**4*(1-4*rough))
    rounded=table.rounded_interval(lo,hi)
    return dict(lower=rounded['lower'],upper=rounded['upper'],degree=degree,
                max_series_ratio=str(max(rhos)),decimal_upper=rounded['upper_decimal'])


def certify_receipts():
    old=json.loads((table.HERE/'sharp_minorant_level_table.json').read_text())
    for row in old['rows']:
        d=deficit(Q(row['a']))
        assert d['upper']==row['kappa_upper'] and d['lower']==row['kappa_lower']
    # Positive dual combination eliminating three unused variables:
    # 3 * incidence_oscillation + 2 * finite_III_main + 15 * (c-a).
    for theta,a,c,delta in [(Q('.5284'),Q('.41361'),Q('.41364'),Q('.000001')),
                            (Q('.527'),Q('.414'),Q('.415'),Q('.001'))]:
        values=table.full_slacks(theta,a,Q('.35'),c,delta)
        dual=3*values['incidence_oscillation']+2*values['finite_III_main']+15*(c-a)
        assert dual==Q(93,2)-88*theta-30*table.TAU-52*delta
    return {'source_mass_rows_reproduced':len(old['rows']),
            'strict_theta_ceiling_at_positive_density':str((Q(93,2)-30*table.TAU)/88),
            'unrounded_ceiling':str(Q(93,176))}


def exact_point(theta,fraction,standard=False):
    if standard:
        a,I,c=table.cutoffs(theta)
        delta=(5*(a-table.TAU)-Q(3,2)-40*((theta-Q(1,2))/2))/16-EPS
        edge={}
    else:
        low,high,wall=feasible_interval(theta)
        delta=low+fraction*(high-low)
        a,I,c=cutoffs(theta,delta)
        edge=dict(lower=str(low),upper=str(high),limiting_guard=wall)
    slacks=table.full_slacks(theta,a,I,c,delta)
    assert min(slacks.values())>0
    return dict(theta=str(theta),delta=str(delta),a=str(a),I=str(I),c=str(c),
                cap=str(1-2*a-Q('.00001')),minimum_guard=str(min(slacks.values())),
                smallest_guard=min(slacks,key=slacks.get),active_guard_count=len(slacks),
                interval=edge,form='source cutoffs' if standard else 'density tradeoff',
                fraction=str(fraction),deficit=deficit(a))


def install(point,source,radius,k,N):
    a,I,c=map(Q,[point[key] for key in ('a','I','c')])
    g=parametric.build_geometry(theta=Q(point['theta']),a=a,I=I,c=c,
                                prime_cap=Q(point['cap']),S=radius/parametric.RS,k=k,N=N)
    assert g['new_rows'][-1]['delta']==Q(point['delta'])
    sub=build_subtractions(g)
    r,spec=model_on_geometry(source,g)
    maximum=max(s[2] for s in r.shells['outer'])
    limits=sorted({min(maximum,int(Q(x)//r.exact_step)) for x in ['.3788','.4745']}|{maximum})
    assert len(limits)==3
    d=next(row for row in sub['domains'] if row['id']==sub['recommended_id'])
    domains={'L1':r.shells['enlarged'],d['id']:cap_shells(r,d['physical_radius'],d['delta'])}
    row=dict(replayed=sub['geometry_replayed'],geometry_sha256=sub['geometry_sha256'],
             row_counts=g['row_counts'],subtraction_source=d['id'],
             outer=str(g['parameters']['physical_outer']),inner=str(g['parameters']['physical_enlarged']))
    return r,limits,domains,spec,row


def evaluate(point,source,radius,k,N):
    try:
        r,limits,domains,spec,receipt=install(point,source,radius,k,N)
    except ValueError as exc:
        return {'point':point,'status':'geometry rejected','reason':str(exc)}
    kappa=float(Q(point['deficit']['upper']))
    mass,forms=scalar_replay(r,np.array(source['best_coefficients']),limits,domains)
    assert mass>0 and min(forms)>0
    ell=float(np.sqrt(kappa*forms[2]/forms[1]))
    assert 0<ell<1
    score=r.rho*(forms[0]+(1-ell)*forms[1]+(1-1/ell)*kappa*forms[2])/mass
    return dict(point=point,status='checked geometry; floating single-prime cap quotient',
                geometry=receipt,lambda_hybrid=ell,score=float(score),mass=mass,forms=forms)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--intervals',type=int,default=8192)
    parser.add_argument('--radius',default=str(BASE_RADIUS))
    parser.add_argument('--levels',nargs='+',default=['.5253','.526','.527','.528','.5284','.5284085'])
    parser.add_argument('--fractions',nargs='+',default=['.01','.4','.85'])
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    source=json.loads((HERE/'h1_k38_knn6_n32768.json').read_text())
    report=dict(status='EXACT_CUTOFF_CHECKS_AND_UNCERTIFIED_CAP_SCORES',intervals=args.intervals,
                radius=args.radius,dimension=38,checks=certify_receipts(),rows=[],
                scope='Reuses the source analytic estimates and exact simplex moments. Quotients omit restoration and have no integration enclosure.')
    points=[exact_point(Q('.5284'),Q(0),True)]
    for theta in map(Q,args.levels):
        for fraction in map(Q,args.fractions):
            points.append(exact_point(theta,fraction))
    for point in points:
        row=evaluate(point,source,Q(args.radius),38,args.intervals)
        report['rows'].append(row)
        args.output.write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps({'event':'FRONTIER','theta':float(Q(point['theta'])),'delta':float(Q(point['delta'])),
                          'score':row.get('score'),'reason':row.get('reason')}),flush=True)


if __name__=='__main__':
    main()
