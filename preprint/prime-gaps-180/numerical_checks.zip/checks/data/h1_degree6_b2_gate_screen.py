"""Compare the true B2 gate and its one-root envelope on identical marked draws."""
import argparse
from fractions import Fraction as Q
import json
from math import comb,exp,sqrt
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np
from scipy.interpolate import BSpline
from scipy.special import logsumexp

from h1_degree6_b2_gate_reachability import Gates,INFINITY
from h1_degree6_older_triangle import VECTOR
from h1_labelled_restoration_mc import rlib
from h1_signed_gate_fibre import rebuild,stored_frame


class Profile:
    def __init__(self,gate):
        self.gate=gate
        self.frame=stored_frame()
        self.h=float(self.frame['step'])
        self.S=131072*self.h
        self.cap=int(gate.fine[-1])*self.h
        fit=json.loads((VECTOR.parent/self.frame['original']['trial_refit']).read_text())
        knots=list(map(float,map(Q,fit['shape_spec']['knots'])))
        self.nr=len(knots)-4
        self.spline=BSpline(knots,np.eye(self.nr),3,extrapolate=False)
        import h1_degree6_stream as stream
        # Obtain the exact ordering of stored power-sum signatures.
        import contextlib,io
        with contextlib.redirect_stdout(io.StringIO()):
            r,_,_,_,_,_=stream.TS.stored_model(39,1024,6,self.frame)
        self.sigs=r.signatures
        with np.load(VECTOR,allow_pickle=False) as z:v=z['vector']
        self.coeffs=v.reshape(9,3,len(self.sigs),self.nr)*np.array([39**(sum(s)-len(s)) for s in self.sigs])[None,None,:,None]
        self.components=self.frame['original']['component_limits']
        self.cap_ends=np.array([c for c,j in gate.limits])
        self.lasts=np.array([j for c,j in gate.limits])
        self.ticks=float(gate.tick)/self.h
        self.W=rlib.Proposal(self.S,self.prefactor,np.arange(0.,80.,5.),self.cap,ngrid=60000)
        self.cut=np.searchsorted(self.W.edges,.15)
        self.beta=np.flatnonzero((self.W.mean*39>.30)&(self.W.mean*39<1.5))
        self.lowp=self.W.cdf[self.beta,self.cut]
        self.dense_group=np.full((len(gate.fine),gate.lasts[0]+1),-1,dtype=np.int16)
        for i,grp in enumerate(gate.group):
            self.dense_group[i,:len(grp)]=grp
        self.prefix=[]
        self.stride=32
        num,den=gate.tick.as_integer_ratio()
        self.index_hi=np.array([-(-(j*num)//den) for j in range(gate.lasts[0]+1)])
        for i in range(len(gate.fine)):
            j,keys,tops=gate.tile(i)
            by_edge=[]
            for e in range(gate.upper_edge(i)+1):
                a,b=[np.where(top>gate.gates[k,e],gate.gates[k,e],INFINITY) for top,k in zip(tops,keys)]
                local=np.minimum(a,b)
                floor=np.minimum.accumulate(local)
                changes=np.r_[0,np.flatnonzero(np.diff(floor))+1]
                s=np.minimum.accumulate(np.where(local<INFINITY,local-self.index_hi[j],INFINITY))
                ends=np.minimum((1+np.arange((len(s)+self.stride-1)//self.stride))*self.stride-1,len(s)-1)
                by_edge.append((j[changes],floor[changes],s[ends]))
            self.prefix.append(by_edge)

    @staticmethod
    def prefactor(t):
        return .105/(1+.01*t)+.895/(1+181.4*t)

    def draw(self,n,rng,mode):
        beta=rng.integers(len(self.beta),size=n)
        ix=self.beta[beta]
        p=self.lowp[beta,None]
        u=rng.random((n,39))
        if mode==0:
            u*=p
        elif mode==1:
            site=rng.integers(39,size=n)
            u*=p
            u[np.arange(n),site]=self.lowp[beta]+(1-self.lowp[beta])*rng.random(n)
        else:
            pair=np.argpartition(rng.random((n,39)),1,axis=1)[:,:2]
            u[np.arange(n)[:,None],pair]=p+(1-p)*rng.random((n,2))
        t=np.empty_like(u)
        for i in np.unique(ix):
            t[ix==i]=np.interp(u[ix==i],self.W.cdf[i],self.W.edges)
        high_count=(t>=self.W.edges[self.cut]).sum(axis=1)
        assert np.all(high_count==mode) if mode<2 else np.all(high_count>=2)
        positions=np.clip(np.searchsorted(self.W.edges,t,side='right')-1,0,len(self.W.w)-1)
        logp=np.stack([np.log(self.W.dens[i][positions]).sum(axis=1) for i in self.beta])
        if mode==0:
            logp-=39*np.log(self.lowp)[:,None]
        elif mode==1:
            logp-=np.log(39*(1-self.lowp)*self.lowp**38)[:,None]
        else:
            logp+=np.log(high_count*(high_count-1)/2)[None,:]-np.log(comb(39,2)*(1-self.lowp)**2)[:,None]
        j=(t/self.h).astype(int)
        midpoint=(j+.5)*self.h
        lw=np.log(rlib.rho(t/self.cap)).sum(axis=1)+2*np.log(self.prefactor(midpoint)).sum(axis=1)
        lw-=logsumexp(logp,axis=0)-np.log(len(self.beta))
        return t,j,lw

    def amplitude(self,j,m):
        J=j.sum(axis=1)
        radial=np.nan_to_num(self.spline((J+19.5)*self.h))
        tm=(j+.5)*self.h
        powers={p:(tm[:,2:]**p).sum(axis=1) for p in range(2,7)}
        angular=np.stack([np.prod([powers[p] for p in s],axis=0) if s else np.ones(len(j)) for s in self.sigs],axis=1)
        def shape(x):return np.stack([np.ones_like(x),(x/self.S)**2,1/(1+300*x)],axis=1)
        ep=(shape(tm[:,0])[:,:,None]*shape(tm[:,1])[:,None,:]).reshape(len(j),9)
        live=np.array([m<=c*self.h for c in self.components]).T
        return np.einsum('na,nc,ns,nr,acsr->n',ep,live,angular,radial,self.coeffs,optimize=True)

    def compare(self,j,t,largest,marks):
        G=self.gate
        n=len(t)
        edges=G.edges[:-1]
        amounts=marks*self.ticks
        pos=np.maximum(0,np.searchsorted(edges,amounts,side='right')-1)
        hist=np.zeros((n,39,len(edges)))
        np.add.at(hist,(np.arange(n)[:,None,None],np.arange(39)[None,:,None],pos),
                  np.where(amounts>=edges[0],amounts,0.))
        tails=np.cumsum(hist.sum(axis=1)[:,::-1],axis=1)[:,::-1]
        full=j.sum(axis=1)
        classes=np.searchsorted(G.fine,largest.max(axis=1)/self.h)
        envelope=np.zeros(n,bool)
        failed=np.zeros(n,bool)
        # All erasures are evaluated here, including on points outside the
        # envelope; this checks the containment against the same fragments.
        top=np.partition(largest,-2,axis=1)[:,-2:]
        full_t=t.sum(axis=1)
        small_max=np.zeros_like(tails)
        available=np.zeros(n,bool)
        for e in range(39):
            m=np.where(largest[:,e]>=top[:,1],top[:,0],top[:,1])
            i=np.searchsorted(G.fine,m/self.h)
            grp=self.dense_group[i,full-j[:,e]]
            y=(full_t-t[:,e])*self.ticks
            rc=np.maximum(G.base,np.ceil(y/G.step).astype(int))-G.base
            key=G.ls[i,grp,rc]
            assert (grp>=0).all() and (key>=0).all() and np.all(y<=G.R[i,grp])
            own=np.cumsum(hist[:,e,::-1],axis=1)[:,::-1]
            small_max=np.maximum(small_max,t[:,e,None]*self.ticks-own)
            retained=tails-own
            failed|=np.any((retained>G.gates[key])&(retained>edges/2),axis=1)
            allowed=(full-j[:,e]>=102994)&(j[:,e]<=27970)
            available|=allowed&np.any((tails>G.gates[key])&(y[:,None]>G.gates[key]),axis=1)
        sharp=np.zeros(n,bool)
        for i in np.unique(classes):
            use=np.flatnonzero(classes==i)
            for e,(starts,ceilings,slope) in enumerate(self.prefix[i]):
                idj=np.searchsorted(starts,full[use],side='right')-1
                bound=np.where(idj>=0,ceilings[np.maximum(0,idj)],INFINITY)
                anytail=tails[use,e]>bound
                envelope[use]|=anytail
                block=np.maximum(0,(full[use]-starts[0])//self.stride)
                hurdle=G.low[full[use]]+slope[block]-small_max[use,e]
                sharp[use]|=anytail&(tails[use,e]>hurdle)
        assert np.all(~failed|envelope)
        assert np.all(~failed|sharp) and np.all(~failed|available)
        return failed,envelope,sharp,available

    def one(self,n,rng,mode,*,mass_only=False):
        t,j,lw=self.draw(n,rng,mode)
        J=j.sum(axis=1)
        largest=rlib.largest(t,self.cap,rng)
        m=largest.max(axis=1)
        g=np.minimum(np.searchsorted(self.cap_ends,m/self.h),len(self.lasts)-1)
        live=J<=self.lasts[g]
        t,j,lw,largest,m,J=(a[live] for a in (t,j,lw,largest,m,J))
        if not len(j):return 0. if mass_only else np.zeros(9)
        a=self.amplitude(j,m)
        weight=np.exp(lw+200)*a**2
        mass=weight.sum()
        if mass_only:return mass
        # The exact reachability proof rules out all failures below here.
        active=(J>=102994)&(a!=0)
        t,j,largest,w=(arr[active] for arr in (t,j,largest,weight))
        if not len(j):return np.r_[mass,np.zeros(8)]
        cut=1/self.ticks
        rest,dust=rlib.fragments(np.where(largest>=cut,t-largest,0.),largest,cut,rng,maxlev=100)
        marks=np.concatenate([largest[:,:,None],rest],axis=-1)
        assert marks.shape[-1]<101
        d,broad,sharp,available=self.compare(j,t,largest,marks)
        return np.array([mass,w@d,w@broad,w@sharp,w@available,d.sum(),broad.sum(),sharp.sum(),available.sum()])

    def palm(self,n,rng,prop):
        """Sample the two largest marks explicitly, including coincident owners.

        The Poisson insertion formula for q>w then has density
        39^2/(q*w) times the product of the residual one-site measures nu_w.
        Uniform order statistics cover the entire admissible triangle.
        """
        pair=np.sort(rng.uniform(0.,self.cap,(n,2)),axis=1)
        w,q=pair.T
        owner=rng.integers(39,size=(n,2))
        marked=np.zeros((n,39))
        marks=np.zeros((n,39,2))
        for k,v in enumerate((q,w)):
            marked[np.arange(n),owner[:,k]]+=v
            marks[np.arange(n),owner[:,k],k]=v
        # Choose the proposal tilt as a function of the tagged marks alone.
        target=np.maximum(.025,self.S-.09-q-w)
        b=np.abs(prop.mean[None,:]*37-target[:,None]).argmin(axis=1)
        rest=prop.sample(b,39,rng)
        density=prop.density(b,rest)
        pick=marked>0
        rates=np.array([6.,40.,200.])
        blur=rates[rng.integers(len(rates),size=int(pick.sum()))]
        x=-np.log1p(-rng.random(len(blur))*(-np.expm1(-blur*self.S)))/blur
        rest[pick]=x
        density[pick]=np.mean(rates[:,None]*np.exp(-rates[:,None]*x)/(-np.expm1(-rates[:,None]*self.S)),axis=0)
        t=rest+marked
        j=(t/self.h).astype(int)
        J=j.sum(axis=1)
        g=np.searchsorted(self.cap_ends,q/self.h)
        live=(J<=self.lasts[g])&(J>=102994)
        t,j,rest,density,q,w,marks=(a[live] for a in (t,j,rest,density,q,w,marks))
        if not len(j):return np.zeros(8)
        a=self.amplitude(j,q)
        with np.errstate(divide='ignore'):
            lw=(np.log(rlib.rho(rest/w[:,None]))-np.log(density)).sum(axis=1)
            lw+=2*np.log(self.prefactor((j+.5)*self.h)).sum(axis=1)
            lw+=np.log((39*self.cap)**2/(2*q*w))
        wt=np.exp(lw+200)*a*a
        usable=wt>0
        if not np.any(usable):return np.zeros(8)
        rest,t,j,w,wt,marks=(a[usable] for a in (rest,t,j,w,wt,marks))
        frags,_=rlib.fragments(rest,np.broadcast_to(w[:,None],rest.shape),1/self.ticks,rng,maxlev=400)
        assert frags.shape[-1]<400
        all_marks=np.concatenate([marks,frags],axis=-1)
        largest=all_marks.max(axis=-1)
        # The exact retained maximum includes every mark, even if a site's
        # entire residual root is below one tick. Since q and w are present,
        # and are independently tagged, this can matter only if q and w lie
        # on the same site. All unrecorded maxima then belong to fine class 0.
        d,broad,sharp,available=self.compare(j,t,largest,all_marks)
        return [wt@a for a in (d,broad,sharp,available)]+[a.sum() for a in (d,broad,sharp,available)]


def run(g,seed,batches,size,palm=False):
    g.verify()
    target=Profile(g)
    rng=np.random.default_rng(seed)
    if palm:
        prop=rlib.Proposal(target.S,target.prefactor,np.geomspace(1.,6000.,80),target.cap,ngrid=60000)
        totals=np.array([[sum(target.one(size,rng,i,mass_only=True) for i in range(3)),*target.palm(size,rng,prop)]
                         for _ in range(batches)])
    else:
        rows=np.array([[target.one(size,rng,i) for i in range(3)] for _ in range(batches)])
        totals=rows.sum(axis=1)
    def stats(col):
        d=totals[:,0]
        v=col.sum()/d.sum()
        se=(col-v*d).std(ddof=1)/(sqrt(batches)*d.mean())
        return [float(v),float(se)]
    mass=totals[:,0]*exp(-200)/size
    result=dict(draws_per_stratum=size*batches,seed=seed,batches=batches,batch_size=size,
                proposal='top_two_palm' if palm else 'three_ordinary_strata',
                ordinary_mass=[float(mass.mean()),float(mass.std(ddof=1)/sqrt(batches))],
                total_deleted=stats(totals[:,1]),total_envelope=stats(totals[:,2]),
                total_sharp=stats(totals[:,3]),total_available=stats(totals[:,4]),
                sharp_excess=stats(totals[:,3]-totals[:,1]))
    if palm:
        result['palm_hit_counts']=totals[:,5:].sum(axis=0).astype(int).tolist()
    else:
        result['per_stratum']=[dict(mass=stats(a[:,0]),deleted=stats(a[:,1]),envelope=stats(a[:,2]),
                                 sharp=stats(a[:,3]),available=stats(a[:,4]),
                                 hit_counts=a[:,5:].sum(axis=0).astype(int).tolist()) for a in rows.transpose(1,0,2)]
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--batches',type=int,default=32)
    p.add_argument('--batch-size',type=int,default=128)
    p.add_argument('--seed',type=int,default=39296)
    p.add_argument('--palm',action='store_true',help='Explicitly sample the largest two marks in the event numerator.')
    p.add_argument('--gates',type=Path)
    args=p.parse_args()
    with TemporaryDirectory() as tmp:
        G=Gates(args.gates or rebuild(Path(tmp)))
        print(json.dumps(run(G,args.seed,args.batches,args.batch_size,args.palm)))
