"""Projected reversible walks on the 38-shift coordinate profile, at a frozen sieve dual."""
import argparse
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path

import numpy as np
from scipy.linalg import eigh, solve
from scipy.stats import qmc
from h1_coordinate_shape import configured
from h1_harmonic_sector_probe import forms
from h1_shape_replay import MarkLaw


TOTAL = [.17,.205,.23,.245,.254,.261,.267,.273]
RETAINED = [.105,.145,.17,.195,.215,.235,.25]
FRAGMENT = [Fraction('.075'),Fraction('.115')]
DIMS = (len(TOTAL)+1,len(RETAINED)+1,len(FRAGMENT)+1)
SIZE = int(np.prod(DIMS))


class Cells:
    size=SIZE

    def __init__(self,r,training):
        law = MarkLaw(r,training,'coordinate')
        G,_ = forms(np.mean(training['raw'],axis=0),training['base'])
        self.center = float(G[0]@law.vector)
        self.profile = law.shift+law.scale*law.pieces[0]
        self.r = r
        step = r.exact_step*r.geometry['parameters']['rho_star']
        self.cuts = [int(q//step) for q in FRAGMENT]

    def values(self,idx,cat):
        t = self.r.t[idx]
        total = self.r.rho*t.sum(axis=1)
        ids = np.ravel_multi_index((np.searchsorted(TOTAL,total),
                 np.searchsorted(RETAINED,total-self.r.rho*t.max(axis=1)),
                 np.searchsorted(self.cuts,cat.max(axis=1))),DIMS)
        return (1+self.profile[idx].sum(axis=1))/self.center,ids


def signed_difference(left,right,h,g,w,n):
    """Sum w*(h e_left-g e_right)(h e_left-g e_right)^T."""
    same = left==right
    diagonal = np.bincount(left[same],weights=w[same]*(h[same]-g[same])**2,minlength=n).astype(float)
    i,j,h,g,w = (x[~same] for x in (left,right,h,g,w))
    diagonal += np.bincount(i,weights=w*h*h,minlength=n)+np.bincount(j,weights=w*g*g,minlength=n)
    cross = np.bincount(i*n+j,weights=w*h*g,minlength=n*n).reshape(n,n)
    return np.diag(diagonal)-cross-cross.T


def draw(op,cells,base,seed,power,tilt):
    r=op.r
    n=cells.size
    density=r.g**2*np.exp(-tilt*r.t)*op.survival[-1]
    linear=r.g*np.exp(-tilt*r.t/2)*op.survival[-1]
    z,a=density.sum(),linear.sum()
    cdf=np.cumsum(density)/z; insert=np.cumsum(linear)/a
    cdf[-1]=insert[-1]=1.
    norm=np.exp(r.k*np.log(z/r.Z)+(tilt-r.tilt)*r.center)
    gen=qmc.Sobol(2*r.k,scramble=True,seed=seed)
    marked=qmc.Sobol(2*r.k+2,scramble=True,seed=seed+100000)
    mass=np.zeros(n);residual=np.zeros(n)
    D=np.zeros((n,n));flow=D.copy()
    original_mass=original_residual=0.
    for _ in range(2**power//512):
        u=gen.random(512)
        idx=np.searchsorted(cdf,u[:,:r.k]);cat=op.categories(idx,u[:,r.k:])
        F,CF,keep=op.evaluate(idx,cat)
        idx,cat,F,CF=idx[keep],cat[keep],F[keep],CF[keep]
        h,i=cells.values(idx,cat)
        w=norm*np.exp(tilt*(r.t[idx].sum(axis=1)-r.center))
        m=w*F**2; rr=w*F*(r.rho*CF-base*F)
        original_mass+=m.sum();original_residual+=rr.sum()
        mass+=np.bincount(i,weights=m*h*h,minlength=n)
        residual+=np.bincount(i,weights=rr*h*h,minlength=n)
        u=marked.random(512);k=r.k-1
        y=np.searchsorted(cdf,u[:,:k]);total=y.sum(axis=1);keep=total<r.n
        y,total,u=y[keep],total[keep],u[keep]
        if not len(total):continue
        yc=op.categories(y,u[:,k:2*k])
        area=insert[r.n-1-total]
        x=np.searchsorted(insert,u[:,2*k:2*k+2]*area[:,None])
        cat=op.categories(x,u[:,2*k+2:])
        sides=[]
        for j in range(2):
            ix=np.column_stack([y,x[:,j]]);cx=np.column_stack([yc,cat[:,j]])
            F=op.amplitude(ix,cx)
            h,ids=cells.values(ix,cx)
            sides.append((F,h,ids))
        (F,h,i),(V,g,j)=sides
        transport=norm*np.exp(tilt*(r.t[y].sum(axis=1)-r.center))*a*area/z
        tilt1=np.exp(.5*tilt*r.t[x])
        # Accepted probability flux of a one-coordinate independence Metropolis step.
        accept=np.minimum(r.g[x[:,0]]*tilt1[:,0]*(F*h)**2,r.g[x[:,1]]*tilt1[:,1]*(V*g)**2)
        flux=np.bincount(i*n+j,weights=transport*accept,minlength=n*n).reshape(n,n)
        flow+=(flux+flux.T)/2
        weight=.5*transport*r.k*r.rho*r.h*a*area*tilt1.prod(axis=1)*F*V*op.multipliers(total,yc.max(axis=1))
        D+=signed_difference(i,j,h,g,weight,n)
    B=np.diag(residual-original_residual/original_mass*mass)-D
    return mass/2**power,B/2**power,flow/2**power


def group_cells(mass,minimum=.0005):
    keep=np.flatnonzero(mass >= minimum*mass.sum())
    geom=np.array(np.unravel_index(np.arange(len(mass)),DIMS)).T
    dist=((geom[:,None]-geom[keep])**2).sum(axis=2)
    return np.eye(len(keep))[dist.argmin(axis=1)]


def transition(mass,flow):
    f=flow.copy();np.fill_diagonal(f,0.)
    off=f.sum(axis=1)
    scale=np.minimum(1.,np.divide(mass,off,out=np.ones_like(mass),where=off>0))
    f*=np.minimum.outer(scale,scale)
    P=f/mass[:,None]
    P[np.diag_indices(len(P))]=1-P.sum(axis=1)
    assert P.min()>-1e-12 and np.max(abs(P.sum(axis=1)-1))<1e-12
    np.testing.assert_allclose(mass[:,None]*P,(mass[:,None]*P).T,atol=1e-14)
    return P


def gain(m,B,h):
    return h@B@h/(m@(h*h))-B.sum()/m.sum()


def fit_line(m,B,u):
    u=u-m@u/m.sum()
    std=np.sqrt(m@(u*u)/m.sum())
    if std<1e-14:
        return np.ones(len(m))
    u=u/std
    basis=np.column_stack([np.ones(len(u)),u])
    _,v=eigh(basis.T@B@basis,basis.T@(m[:,None]*basis))
    steps=[0.,-.08,.08]
    if abs(v[0,-1])>1e-12:
        steps.append(np.clip(v[1,-1]/v[0,-1],-.08,.08))
    best=max(steps,key=lambda step:gain(m,B,1+step*u))
    return 1+best*u


def freeze(raw):
    m,B,f=(x.mean(axis=0) for x in raw)
    S=group_cells(m)
    m,B,f=m@S,S.T@B@S,S.T@f@S
    P=transition(m,f)
    residual=B.sum(axis=1)/m-B.sum()/m.sum()
    trials={}
    for key,src in [('residual',residual),('bounded',np.clip(residual,-.05,.05))]:
        trials[key]=S@fit_line(m,B,src)
        for s in (.03,.15,.75,3.):
            solution=solve((1+s)*np.eye(len(m))-P,src)
            trials[f'{key}_laplace_{s}']=S@fit_line(m,B,solution)
        for n in (1,2,4):
            # Same geometric weights as the s=.15 resolvent, truncated after n transitions.
            u=src.copy()
            for _ in range(n):u=src+P@u/1.15
            trials[f'{key}_truncated_{n}']=S@fit_line(m,B,u)
    return trials,len(m)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('dual',type=Path);p.add_argument('coordinate',type=Path)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--seed',type=int,required=True);p.add_argument('--runs',type=int,default=6)
    p.add_argument('--power',type=int,default=16);p.add_argument('--tilt',type=float,default=15.)
    p.add_argument('--training',type=Path)
    args=p.parse_args();digest=lambda p:sha256(p.read_bytes()).hexdigest()
    assert args.power>=9 and args.runs>=4
    coordinate=json.loads(args.coordinate.read_text())
    assert coordinate['dual_sha256']==digest(args.dual)
    op,feature,_=configured(args.dual);cells=Cells(op.r,coordinate)
    assert set(cells.cuts).issubset(op.caps)
    seeds=list(range(args.seed,args.seed+args.runs))
    old=set(coordinate['seeds'])
    training=None
    if args.training:
        training=json.loads(args.training.read_text());old.update(training['seeds'])
        assert training['coordinate_sha256']==digest(args.coordinate) and training['dual_sha256']==digest(args.dual)
    assert {s+offset for s in seeds for offset in (0,100000)}.isdisjoint(s+offset for s in old for offset in (0,100000))
    blocks=[]
    for seed in seeds:
        blocks.append(draw(op,cells,feature.base,seed,args.power,args.tilt))
        m,B,_=blocks[-1]
        print(json.dumps(dict(seed=seed,mass=m.sum(),coordinate_fixed_score=feature.base+B.sum()/m.sum())),flush=True)
    raw=tuple(np.stack(x) for x in zip(*blocks))
    fitdata=raw
    if training:
        f=args.training.with_name(training['sample'])
        assert digest(f)==training['sample_sha256']
        with np.load(f,allow_pickle=False) as z:fitdata=tuple(z[k] for k in ('mass','correction','flow'))
    else:
        fitdata=tuple(x[:len(seeds)//2] for x in raw)
    trial,n=freeze(fitdata)
    test=raw if training else tuple(x[len(seeds)//2:] for x in raw)
    m,B,_=(x.mean(axis=0) for x in test)
    rows={}
    for name,h in trial.items():
        gains=[float(gain(v,b,h)) for v,b in zip(*test[:2])]
        rows[name]=dict(gain=float(gain(m,B,h)),gains=gains,
                        descriptive_se=float(np.std(gains,ddof=1)/np.sqrt(len(gains))),multiplier=h.tolist())
    sample=args.output.with_suffix('.npz')
    np.savez_compressed(sample,mass=raw[0],correction=raw[1],flow=raw[2])
    out=dict(scope='Sampled fixed-dual correction on a projected reversible chain, before full support restoration.',
             dual=args.dual.name,dual_sha256=digest(args.dual),coordinate=args.coordinate.name,
             coordinate_sha256=digest(args.coordinate),seeds=seeds,power=args.power,tilt=args.tilt,groups=n,
             original_score=feature.base,sampled_coordinate_score=feature.base+B.sum()/m.sum(),
             radial_edges=TOTAL,retained_edges=RETAINED,fragment_edges=list(map(str,FRAGMENT)),
             rows=rows,sample=sample.name,sample_sha256=digest(sample))
    if training:out.update(training=args.training.name,training_sha256=digest(args.training))
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v['gain'] for k,v in rows.items()}),flush=True)


if __name__=='__main__':main()
