"""Postprocess the frozen ordinary Fourier certificates for square underflow in magnitudes."""
from fractions import Fraction

from flint import arb
import numpy as np

import projected_fourier as F


EXTRA='2^-146'
EPSILON=2.**-146


def enlarged(radii):
    assert np.all(np.isfinite(radii)) and np.all(radii>=0)
    return np.nextafter(radii+EPSILON,np.inf)


def fallback(value):
    """Upper after raising each Gram radius by 2^-146, for any legacy radial panel."""
    assert value>=0
    # A zero here is reserved for an identically empty Fourier acceptance mask.
    if value==0:return 0.
    # Each coefficient vector has l1 < 2^36.  Up to 108 controls occur.  A
    # center and all differences cost < (1+2 sqrt(108))*2^36*sqrt(2^-146).
    return F.upper_float((F.ball(value).sqrt()+arb(2)**-32)**2)


def corrected_baseline(result):
    """Build a corrected view of immutable input certificates without touching their pin."""
    if result.get('extra_gram_radius')==EXTRA:return result
    if 'panel_bounds_before_capture' not in result:
        assert result['outward_scaled_upper']==0
        return result
    assert len(result['subtotals'])<=16 and result['possible_J'][0]>=102994
    assert result['grid'][0]*result['grid'][1]<=2**24
    raw=result['panel_bounds_before_capture']
    capture=F.ball(Fraction(result['minimum_capture']))
    fixed=[fallback(v) for v in raw]
    total=F.upper_float(sum((F.ball(v) for v in fixed),arb(0))/capture)
    return dict(result,extra_gram_radius=EXTRA,correction_method='coefficient-norm square-root allowance',
                old_upper_before_magnitude_correction=result['outward_scaled_upper'],
                panel_bounds_before_capture=fixed,outward_scaled_upper=total,
                fraction_at_previous_floor=F.upper_float(F.ball(total)/F.ball(Fraction('46.1984860121'))))
