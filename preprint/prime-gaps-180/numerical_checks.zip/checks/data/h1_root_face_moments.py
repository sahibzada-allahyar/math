"""Root-level face energies of an exported labelled trial from its erased-profile tables (floating).

Stage 1 of a deterministic restoration integral for the 39-shift pair trial. It recomputes, from
the tables W_core, W_a, W_b of an export of h1_labelled_restoration_mc.py, the face energies

    E_face(l, R) = mult * int_{roots y in layer l, cell sum R} V(y)^2 dnu(y),

with V(y) = h prod_y g * sum W[l, ., R] psi psi P_rest(core of y), by power-sum moments of the
root coordinates (Dickman-capped cell weights h g^2 rho(j / cap), block partitions of the
signatures, FFT convolutions). Up to one normalising constant these must reproduce the
evaluator's face totals and priced one-prime value stored as targets in the export; the step
'check' prints both comparisons. Floating arithmetic, not an enclosure.

    python h1_root_face_moments.py check lrmc_39g6.npz
"""
import argparse
import json
import time
from collections import Counter, defaultdict

import numpy as np
from scipy.fft import irfft, next_fast_len, rfft


def block_partitions(signature):
    """As fast_fragment_ritz.block_partitions: ways to group the parts of a signature onto
    distinct coordinates, as (tuple of block sums, multiplicity)."""
    if not signature:
        return (((), 1),)
    q, answer = signature[-1], defaultdict(int)
    for blocks, multiplicity in block_partitions(signature[:-1]):
        answer[tuple(sorted((*blocks, q)))] += multiplicity
        for value, copies in Counter(blocks).items():
            joined = list(blocks)
            joined.remove(value)
            answer[tuple(sorted(joined + [value + q]))] += multiplicity * copies
    return tuple(answer.items())


def fiber_splits(signature):
    """As fast_fragment_ritz.fiber_splits: P_sig over a set with one distinguished coordinate s
    expands as sum over (rest, e, mult) of mult * s^e * P_rest(others)."""
    from itertools import product
    from math import comb
    counts, answer = tuple(sorted(Counter(signature).items())), []
    for chosen in product(*(range(c + 1) for _, c in counts)):
        rest, exponent, mult = [], 0, 1
        for (power, count), selected in zip(counts, chosen):
            rest.extend([power] * (count - selected))
            exponent += power * selected
            mult *= comb(count, selected)
        answer.append((tuple(rest), exponent, mult))
    return tuple(answer)


def dickman_cells(cap, n):
    """Cell averages of rho(. / cap), about rho((j + 1/2) / cap) on cells 0..n-1, by the backend's
    trapezoidal recurrence (cap in cells)."""
    D = np.ones(n + 1)
    for j in range(cap, n):
        D[j + 1] = D[j] - .5 * (D[j - cap] / j + D[j + 1 - cap] / (j + 1))
    return np.maximum(0., (D[:-1] + D[1:]) / 2)


_IH_TABLES = {}


def irwin_hall_tail(N, a, res=1000):
    """P(U_1 + ... + U_N > a) for independent uniforms on [0, 1], read from an exact table at
    multiples of 1 / res with a rounded down (so the value is an upper bound for the tail at a).
    The table is computed in integer arithmetic: N! res^N P(S <= i / res) = sum_j (-1)^j C(N, j) (i - res j)^N."""
    from math import comb, factorial, inf, nextafter

    def upper_float(num, den):
        value = num / den
        p, q = value.as_integer_ratio()
        return nextafter(value, inf) if p * den < num * q else value

    key = (N, res)
    if key not in _IH_TABLES:
        den = factorial(N) * res ** N
        tab = np.ones(N * res + 1)
        knots = np.empty_like(tab)
        for i in range(N * res + 1):
            acc = 0
            for j_ in range(i // res + 1):
                acc += (-1) ** j_ * comb(N, j_) * (i - res * j_) ** N
            tab[i] = upper_float(den - acc, den)
            knots[i] = upper_float(i, res)
        _IH_TABLES[key] = knots, tab
    knots, tab = _IH_TABLES[key]
    a = np.asarray(a, float)
    # Each knot is the least binary64 number >= the rational grid point.
    # Multiplying a by res and flooring can round up across a grid edge.
    idx = np.clip(np.searchsorted(knots, a, side='right') - 1, 0, N * res)
    return np.where(a <= 0, 1.0, np.where(a >= N, 0.0, tab[idx]))


def tilted_cells(cap, n, u, q, theta):
    """Cell table of f(t) = E[ prod over fragments x of phi(x) | total t ] for the stick-broken
    fragments of one coordinate, with phi(x) = exp(-mu x) for x < u, theta for u <= x <= cap and 0
    above (cap and u in cells; q = exp(-mu h)). A size-biased pick of one fragment is uniform on
    [0, t], so t f(t) = int_0^t f(t - x) phi(x) dx with f(0) = 1; on cells
    f_j = (1 / j) sum_{d=1..j} f_{j-d} phi(d). With mu = 0 and theta = 1 this is rho(t / cap) to first
    order in the cell (dickman_cells is the second-order form). Floating."""
    cap = int(cap); u = int(u)
    f = np.ones(n)
    m = min(max(u - 1, 0), cap)                    # exponential window d = 1 .. m
    P = np.zeros(n + 1)                            # prefix sums of f for the flat window d = u .. cap
    A = 0.0
    qm1 = q ** (m + 1)
    flat = cap >= max(u, 1)
    d0 = max(u, 1)
    P[1] = 1.0
    for j in range(1, n):
        # A = sum_{d=1..m} f_{j-d} q^d
        A = q * (A + f[j - 1])
        if j - 1 - m >= 0:
            A -= qm1 * f[j - 1 - m]
        if m == 0:
            A = 0.0
        B = 0.0
        if flat and j - d0 >= 0:
            B = P[j - d0 + 1] - P[max(j - cap, 0)]
        f[j] = (A + theta * B) / j
        P[j + 1] = P[j] + f[j]
    return f


class Moments:
    """Power-sum moments of `count` i.i.d. coordinates with cell weight w, as functions of the cell
    sum R < n: M(count, sig)[R] = sum_{sum j = R} prod_{d in sig} (sum_i x_i^d) prod w(j_i).

    Convolutions are linear and truncated to n cells after every product, as in the backend: the
    coordinate weights have heavy tails, so the bulk of a many-fold sum lies far beyond n and a
    circular (unrestricted) Fourier power would alias it back. The weights are tilted by
    exp(-beta x) to keep the dynamic range near the top cells; untilt(...) undoes it exactly at
    cell midpoints x_j = (j + 1/2) h."""

    def __init__(self, w, x, n, length, beta=25.0, h=None):
        self.n, self.L, self.beta = n, length, beta
        self.h = h if h is not None else float(x[1] - x[0])
        self.x = x
        self.w = w * np.exp(-beta * x)
        self.cache = {}

    def conv(self, a, b):
        return irfft(rfft(a, self.L) * rfft(b, self.L), self.L)[:self.n]

    def weighted(self, e):
        key = ('w', e)
        if key not in self.cache:
            self.cache[key] = self.w * self.x ** e
        return self.cache[key]

    def power(self, count):
        key = ('pow', count)
        if key not in self.cache:
            if count == 0:
                a = np.zeros(self.n); a[0] = 1.
            elif count == 1:
                a = self.weighted(0)
            else:
                a = self.power(count // 2)
                a = self.conv(a, a)
                if count % 2:
                    a = self.conv(a, self.weighted(0))
            self.cache[key] = a
        return self.cache[key]

    def blocks(self, blocks):
        key = ('blk', blocks)
        if key not in self.cache:
            if not blocks:
                a = self.power(0)
            elif len(blocks) == 1:
                a = self.weighted(blocks[0])
            else:
                a = self.conv(self.blocks(blocks[:-1]), self.weighted(blocks[-1]))
            self.cache[key] = a
        return self.cache[key]

    def moment(self, count, sig):
        """Tilted moment (multiply by untilt(count) to remove the tilt)."""
        sig = tuple(sorted(sig))
        key = ('mom', count, sig)
        if key not in self.cache:
            acc = np.zeros(self.n)
            for blocks, mult in block_partitions(sig):
                b = len(blocks)
                if b > count:
                    continue
                falling = float(np.prod(np.arange(count - b + 1, count + 1))) if b else 1.0
                acc += mult * falling * self.conv(self.power(count - b), self.blocks(blocks))
            self.cache[key] = acc
        return self.cache[key]

    def tilt(self, arr):
        """Tilt an extra coordinate's weight array in the same way."""
        return arr * np.exp(-self.beta * self.x)

    def untilt(self, coordinates):
        """Factor restoring an R-resolved product of `coordinates` tilted coordinate weights."""
        return np.exp(self.beta * (np.arange(self.n) + coordinates / 2) * self.h)


def load(path):
    """An export; if a directory <stem>_npy with one .npy per array exists next to it, its arrays
    are memory-mapped instead (so that many processes share them)."""
    from pathlib import Path as _P
    d = _P(str(path)[:-4] + '_npy') if str(path).endswith('.npz') else None
    if d is not None and d.is_dir():
        z = {f.stem: np.load(f, mmap_mode='r', allow_pickle=False) for f in d.glob('*.npy')}
        m = json.loads(str(z['meta']))
        return z, m
    z = np.load(path, allow_pickle=False)
    m = json.loads(str(z['meta']))
    return z, m


def face_totals(path, layers=None, verbose=True):
    z, m = load(path)
    n, h, k = m['n'], m['h'], m['dimension']
    caps = list(m['caps'])
    rests = [tuple(s) for s in m['rests']]
    sigs = [tuple(s) for s in m['sigs']]
    g, x, psi = z['g'], z['t'], z['psi']
    B = psi.shape[0]
    Wc, Wa, Wb, field = z['W_core'], z['W_a'], z['W_b'], z['field']
    core = k - 2
    L = next_fast_len(2 * n)
    out = dict(core=np.zeros((len(caps), n)), a=np.zeros((len(caps), n)), b=np.zeros((len(caps), n)))
    prev = None
    t0 = time.time()
    upairs = [(p, q) for p in range(B) for q in range(p, B)]
    for li, cap in enumerate(caps):
        if layers is not None and li not in layers and li + 1 not in layers:
            prev = None
            continue
        rho = dickman_cells(int(cap), n)
        w = h * g * g * rho
        mom = Moments(w, x, n, L, h=h)
        fends = {pq: rfft(mom.tilt(w * psi[pq[0]] * psi[pq[1]]), L) for pq in upairs}
        un = mom.untilt(k - 1)
        cur = {}
        # core face: root = core-1 core coordinates + a + b; V^2 contains P_ri P_rj and psi_m psi_p (a), psi_m' psi_p' (b)
        for i, ri in enumerate(rests):
            for rj in rests[i:]:
                sig = tuple(sorted(ri + rj))
                if ('c', sig, upairs[0], upairs[0]) in cur:
                    continue
                fm = rfft(mom.moment(core - 1, sig), L)
                for pa in upairs:
                    fma = rfft(irfft(fm * fends[pa], L)[:n], L)
                    for pb in upairs:
                        cur['c', sig, pa, pb] = irfft(fma * fends[pb], L)[:n] * un
        for i, si in enumerate(sigs):
            for sj in sigs[i:]:
                sig = tuple(sorted(si + sj))
                if ('e', sig, upairs[0]) in cur:
                    continue
                fm = rfft(mom.moment(core, sig), L)
                for pq in upairs:
                    cur['e', sig, pq] = irfft(fm * fends[pq], L)[:n] * un
        if layers is None or li in layers:
            d = {key: val - (prev[key] if prev is not None else 0.) for key, val in cur.items()}
            # assemble V^2 densities per cell with the layer's tables
            dens_core = np.zeros(n)
            for i, ri in enumerate(rests):
                for j, rj in enumerate(rests):
                    sig = tuple(sorted(ri + rj))
                    for ma in range(B):
                        for mb in range(B):
                            for pa_ in range(B):
                                for pb_ in range(B):
                                    ka = (min(ma, pa_), max(ma, pa_)); kb = (min(mb, pb_), max(mb, pb_))
                                    dens_core += Wc[li, i, ma, mb] * Wc[li, j, pa_, pb_] * d['c', sig, ka, kb]
            dens_a = np.zeros(n); dens_b = np.zeros(n)
            for i, si in enumerate(sigs):
                for j, sj in enumerate(sigs):
                    sig = tuple(sorted(si + sj))
                    for p_ in range(B):
                        for q_ in range(B):
                            kk = (min(p_, q_), max(p_, q_))
                            dens_a += Wa[li, i, p_] * Wa[li, j, q_] * d['e', sig, kk]
                            dens_b += Wb[li, i, p_] * Wb[li, j, q_] * d['e', sig, kk]
            out['core'][li] = core * h * h * dens_core
            out['a'][li] = h * h * dens_a
            out['b'][li] = h * h * dens_b
            if verbose:
                print(json.dumps(dict(event='LAYER', layer=li, cap=int(cap), seconds=round(time.time() - t0))), flush=True)
        prev = cur
    return out, field, m


def erased_rows(z, m, mask=None, kernel=None, layers=None):
    """Rebuild the erased-profile tables from the full amplitudes: for root layer l (largest mark in
    (caps[l-1], caps[l]]) and root cell R,

      W_core[l, rest, m, m', R] = sum_c sum_{shell cap v} sum_{sig, splits -> rest} mult *
          sum_j amp[(m,m'), c, sig](R + j) 1[full_cap(R + j) = v] g(t_j) rho(j / cc) t_j^e,

    with cc = min(limit_c, v) the inserted coordinate's fragment cap, used only if caps[l] <= cc;
    W_a and W_b likewise with psi of the inserted endpoint. mask, if given, multiplies amp along the
    full cell R + j; kernel(cc, e, endpoint_shape) may replace the inserted coordinate's weight."""
    n = m['n']
    caps = list(m['caps']); limits = list(m['limits'])
    sigs = [tuple(s) for s in m['sigs']]; rests = [tuple(s) for s in m['rests']]
    pairs = [tuple(p) for p in m['pairs']]
    amp, full_cap, g, x, psi = z['amp'], z['full_cap'], z['g'], z['t'], z['psi']
    B = psi.shape[0]
    L = next_fast_len(2 * n)
    rest_index = {r: i for i, r in enumerate(rests)}
    sig_index = {s_: i for i, s_ in enumerate(sigs)}
    nl = len(caps)
    Wc = np.zeros((nl, len(rests), B, B, n)); Wa = np.zeros((nl, len(sigs), B, n)); Wb = np.zeros((nl, len(sigs), B, n))
    rho_cache = {}
    def rho(cc):
        if cc not in rho_cache:
            rho_cache[cc] = dickman_cells(int(cc), n)
        return rho_cache[cc]
    def kern(cc, e, shape=None):
        if kernel is not None:
            return kernel(cc, e, shape)
        base = g * rho(cc) * x ** e
        return base if shape is None else base * psi[shape]
    caps_arr = np.asarray(caps)
    for c, lim in enumerate(limits):
        for v in sorted(set(int(u) for u in np.unique(full_cap) if u >= 0)):
            cc = min(int(lim), v)
            sel = full_cap == v
            if not sel.any():
                continue
            layers_ok = np.flatnonzero(caps_arr <= cc)
            if not len(layers_ok):
                continue
            fk = {}
            def fkern(e, shape=None):
                key = (e, shape)
                if key not in fk:
                    fk[key] = rfft(kern(cc, e, shape)[::-1], L)
                return fk[key]
            for pi, (ma, mb) in enumerate(pairs):
                for si, sig in enumerate(sigs):
                    a_ = amp[pi, c, si] * sel
                    if mask is not None:
                        a_ = a_ * mask
                    if not a_.any():
                        continue
                    fa = rfft(a_, L)
                    for rest, e, mult in fiber_splits(sig):
                        if rest not in rest_index:
                            continue
                        corr = irfft(fa * fkern(e), L)[n - 1:2 * n - 1]
                        Wc[layers_ok, rest_index[rest], ma, mb] += mult * corr
                    # endpoint a inserted with shape ma (b retained with mb), and b inserted with shape mb
                    ca = irfft(fa * fkern(0, ma), L)[n - 1:2 * n - 1]
                    cb = irfft(fa * fkern(0, mb), L)[n - 1:2 * n - 1]
                    Wa[layers_ok, si, mb] += ca
                    Wb[layers_ok, si, ma] += cb
    return Wc, Wa, Wb


# ---------------------------------------------------------------- stage 3: the canonical cross term
def capped_tilted_cells(cap, n, u, q, theta, sc):
    """As tilted_cells, but the exponential weight of a coordinate is capped: with S the cell sum of its
    fragments below u, the coordinate carries q^min(S, sc) instead of q^S (sc in cells). The recurrence
    of tilted_cells is t f = f * phi, so the table for phi_1 + phi_2 is the discrete convolution of the
    tables for phi_1 and phi_2 (generating functions exp(sum phi(d) z^d / d) multiply). Hence the table
    is (small fragments only, weighted by q^min(j, sc) at small sum j) convolved with (fragments in
    [u, cap] only, theta each). With sc >= n it equals tilted_cells. Floating; direct convolution."""
    cap = int(cap); u = int(u); sc = int(sc)
    small = tilted_cells(max(u - 1, 0), n, u, 1.0, 0.0)          # fragments of 1 .. u - 1 cells, no weight
    large = tilted_cells(cap, n, u, 0.0, theta)                  # fragments of u .. cap cells
    wj = np.minimum(np.arange(n), sc).astype(float)
    return np.convolve(small * q ** wj, large)[:n]


GATE_UNIT = 10 ** 7
GATE_MINRAD = 2_000_000


def shifted_rho(D, j, W, h):
    """rho((t_j - W) / cap) on cells j for a mark sum W, from a cell table D[i] ~ rho((i + 1/2) / cap):
    the rest total (j + 1/2) h - W sits at fractional index j - W / h; zero when the rest is negative."""
    k = j - W / h
    return np.where(j + .5 >= W / h, interp_rho(D, np.maximum(k, 0.0)), 0.0)


def box_tail(lo, hi, theta):
    """P(U_1 + ... + U_m > theta) for independent U_i uniform on [lo_i, hi_i), theta an array: one minus
    the volume fraction of the box below the hyperplane, by inclusion-exclusion,
    vol{x in prod [0, d_i]: sum x <= s} = (1 / m!) sum over S of (-1)^|S| (s - d_S)_+^m."""
    from itertools import combinations
    from math import factorial
    d = [b - a for a, b in zip(lo, hi)]
    m = len(d)
    D = max(d)
    x = (np.asarray(theta, float) - sum(lo)) / D
    x = np.clip(x, -1.0, sum(d) / D + 1.0)
    dn = [v / D for v in d]
    acc = np.zeros_like(x)
    for size in range(m + 1):
        for S in combinations(range(m), size):
            acc += (-1) ** size * np.maximum(x - sum(dn[i] for i in S), 0.0) ** m
    F = acc / (factorial(m) * float(np.prod(dn)))
    return 1.0 - np.clip(F, 0.0, 1.0)


def interp_rho(D, k):
    """rho at fractional cell offsets k (array) from a cell table D[k] = rho(k / cap); 0 below 0."""
    k = np.asarray(k, float)
    out = np.interp(k, np.arange(len(D)), D, left=0.0, right=D[-1])
    return np.where(k < 0, 0.0, out)


class Rank2:
    """<F Phi, C_+ F> restricted to configurations whose two largest marks lie in a given bin
    (w1 > w2, widths dw1, dw2) and whose virtual root fails its rank-2 gate. Floating."""

    def __init__(self, z, m, G, tilt=2, beta=25.0):
        self.z, self.m, self.G = z, m, G
        self.n, self.h, self.k = m['n'], m['h'], m['dimension']
        self.core = self.k - 2
        self.caps = np.asarray(m['caps']); self.limits = list(m['limits'])
        self.sigs = [tuple(s_) for s_ in m['sigs']]; self.rests = [tuple(s_) for s_ in m['rests']]
        self.pairs = [tuple(p_) for p_ in m['pairs']]
        self.g, self.x, self.psi = z['g'], z['t'], z['psi']
        self.B = self.psi.shape[0]
        self.L = next_fast_len(2 * self.n)
        self.beta = beta
        self.tiltv = np.exp(-beta * self.x)
        self.ticks = m['rho_ticks'] * GATE_UNIT
        self.field_pos = np.maximum(z['field'], 0.0)
        self.Wc, self.Wa, self.Wb = z['W_core'], z['W_a'], z['W_b']
        self.rest_index = {r_: i for i, r_ in enumerate(self.rests)}
        self.rho_cache = {}
        self.fft_cache = {}
        self.carried = ['0', '1', '2']

    def D(self, cap):
        cap = int(cap)
        if cap not in self.rho_cache:
            if len(self.rho_cache) > 100:
                self.rho_cache.clear()
            tl_ = getattr(self, 'tilt', None)              # one tilt per process (set before any use)
            if tl_ is None:
                self.rho_cache[cap] = dickman_cells(cap, self.n)
            elif getattr(self, 'tilt_cap', None) is None:
                self.rho_cache[cap] = tilted_cells(cap, self.n, *tl_)
            else:
                self.rho_cache[cap] = capped_tilted_cells(cap, self.n, *tl_, self.tilt_cap)
        return self.rho_cache[cap]

    def conv(self, a, b):
        return irfft(rfft(a, self.L) * rfft(b, self.L), self.L)[:self.n]

    # --- the failure mask of the virtual root along the full cell R
    def mask(self, w1, w2):
        G, h, n = self.G, self.h, self.n
        fine, ls, gates, edges, Rclass = G['fine'], G['ls'], G['gates'], G['edges'], G['R']
        radial_step = int(G['radial_step']); mrad = GATE_MINRAD // radial_step
        ci = int(np.searchsorted(fine, w1 / h))
        lay = int(np.searchsorted(self.caps, w1 / h))
        if lay >= len(self.caps) or ci >= ls.shape[0]:
            return np.ones(n), lay
        gt = self.z['group_table'][lay]
        R = np.arange(n)
        Y = (R + self.k / 2) * h * self.ticks
        rc = np.maximum(mrad, np.ceil(Y / radial_step).astype(int)) - mrad
        grp = gt.astype(int)
        tested = grp >= 0
        ins = tested & (rc < ls.shape[2])
        key = np.full(n, -1)
        key[ins] = ls[ci, grp[ins], rc[ins]]
        over = np.zeros(n, bool)
        over[ins] = Y[ins] > Rclass[ci, grp[ins]]
        b2 = int(np.searchsorted(edges, w2 * self.ticks, side='right') - 1)
        b2 = min(max(b2, 0), gates.shape[1] - 1)
        W = (w1 + w2) * self.ticks
        fail = (key >= 0) & (W > gates[np.maximum(key, 0), b2])
        return (tested & (fail | (key < 0) | over)).astype(float), lay

    # --- masked erased rows with an inserted-coordinate weight `ins` (array over cells, without g)
    def rows(self, maskR, w1, ins):
        n, L = self.n, self.L
        z = self.z
        amp, full_cap = z['amp'], z['full_cap']
        Wc = np.zeros((len(self.rests), self.B, self.B, n)); Wa = np.zeros((len(self.sigs), self.B, n)); Wb = np.zeros_like(Wa)
        base = self.g * ins
        fk = {}
        def fkern(e, shape=None):
            key = (e, shape)
            if key not in fk:
                arr = base * self.x ** e
                if shape is not None:
                    arr = arr * self.psi[shape]
                fk[key] = rfft(arr[::-1], L)
            return fk[key]
        w1c = w1 / self.h
        for c, lim in enumerate(self.limits):
            for v in sorted(set(int(u) for u in np.unique(full_cap) if u >= 0)):
                cc = min(int(lim), v)
                if w1c > cc:
                    continue
                sel = (full_cap == v) * maskR
                if not sel.any():
                    continue
                for pi, (ma, mb) in enumerate(self.pairs):
                    for si, sig in enumerate(self.sigs):
                        a_ = amp[pi, c, si] * sel
                        if not a_.any():
                            continue
                        fa = rfft(a_, L)
                        for rest, e, mult in fiber_splits(sig):
                            if rest in self.rest_index:
                                Wc[self.rest_index[rest], ma, mb] += mult * irfft(fa * fkern(e), L)[n - 1:2 * n - 1]
                        Wa[si, mb] += irfft(fa * fkern(0, ma), L)[n - 1:2 * n - 1]
                        Wb[si, ma] += irfft(fa * fkern(0, mb), L)[n - 1:2 * n - 1]
        return Wc, Wa, Wb

    # --- root moments: plain core coordinates of weight om, core sites, endpoint arrays (all untilted inputs)
    def root_density(self, sig, n_plain, om, core_sites, ends, mom):
        """sum over configurations (cell sum R) of prod weights * P_sig(core coords incl. core sites);
        returns the tilted array (all inputs tilted inside)."""
        tl = self.tiltv
        acc = np.zeros(self.n)
        def splits(sg, sites):
            if not sites:
                yield sg, (), 1
                return
            for rest, e, mult in fiber_splits(sg):
                for rest2, es, mult2 in splits(rest, sites[1:]):
                    yield rest2, (e,) + es, mult * mult2
        fc = getattr(self, '_fcache', None)
        for rest, es, mult in splits(tuple(sorted(sig)), core_sites):
            if fc is None:
                arr = mom.moment(n_plain, rest)
                for site, e in zip(core_sites, es):
                    arr = self.conv(arr, site * tl * self.x ** e)
            else:
                # same arithmetic, with the transforms of repeated operands kept for the current bin
                key = ('m', id(mom), n_plain, rest)
                if key not in fc:
                    fc[key] = (mom.moment(n_plain, rest), rfft(mom.moment(n_plain, rest), self.L))
                arr, A = fc[key]
                for site, e in zip(core_sites, es):
                    sk = ('s', id(site), e)
                    if sk not in fc:
                        fc[sk] = (site, rfft(site * tl * self.x ** e, self.L))
                    if A is None:
                        A = rfft(arr, self.L)
                    arr = irfft(A * fc[sk][1], self.L)[:self.n]
                    A = None
            acc += mult * arr
        for end in ends:
            acc = self.conv(acc, end * tl)
        return acc

    def contribution(self, w1, w2, dw1, dw2):
        """Sum over placements of the two marks relative to the erased coordinate; units of the raw
        root integrals (multiply by kappa = rho / I)."""
        n, h, B = self.n, self.h, self.B
        maskR, lay1 = self.mask(w1, w2)
        if getattr(self, 'nomask', False):
            maskR = (self.z['group_table'][min(lay1, len(self.caps) - 1)] >= 0).astype(float)
        if not maskR.any() or lay1 >= len(self.caps):
            return 0.0, {}
        c2 = max(1, int(w2 / h))
        Drest = self.D(c2)
        j = np.arange(n)
        om = h * self.g ** 2 * Drest                              # plain root coordinate, fragments < w2
        def site(*ws):                                            # root coordinate carrying marks ws
            return h * self.g ** 2 * shifted_rho(Drest, j, sum(ws), h) * np.prod([dw / w for w, dw in zip(ws, (dw1, dw2) if len(ws) == 2 else ((dw1,) if ws[0] == w1 else (dw2,)))])
        def insw(*ws):                                            # inserted coordinate weight without g
            if not ws:
                return Drest.copy()
            fac = np.prod([(dw1 / w1) if w == w1 else (dw2 / w2) for w in ws])
            return shifted_rho(Drest, j, sum(ws), h) * fac
        # the plain root moments depend only on the rest cap: keep them across bins with the same w2
        if getattr(self, '_mom_cap', None) != c2:
            self._mom = Moments(om, self.x, n, self.L, beta=self.beta, h=h)
            self._mom_cap = c2
        mom = self._mom
        un = mom.untilt(self.k - 1)
        lay2 = int(np.searchsorted(self.caps, w2 / h))
        parts = {}
        total = 0.0
        # inserted-coordinate cases: which marks the erased coordinate carries
        for carried in ((), (w1,), (w2,), (w1, w2)):
            if str(len(carried)) not in self.carried:
                continue
            rows = self.rows(maskR, w1, insw(*carried))
            root_marks = tuple(w for w in (w1, w2) if w not in carried)
            if len(root_marks) == 2 or root_marks == (w1,):
                lay = lay1
            elif root_marks == (w2,):
                lay = lay2
            else:
                lay = None                                        # root has no large mark: handled below
            for face in ('core', 'a', 'b'):
                val = self.face_cross(face, rows, root_marks, lay, om, site, mom, un, c2)
                parts[(len(carried), face)] = parts.get((len(carried), face), 0.0) + val
                total += val
        return total, parts

    def mass0(self):
        """int F^2 over all full configurations (no marks), by layers of the largest fragment."""
        n, h, B, k = self.n, self.h, self.B, self.k
        amp, full_cap = self.z['amp'], self.z['full_cap']
        core = self.core
        tl = self.tiltv
        upairs = [(p_, q_) for p_ in range(B) for q_ in range(p_, B)]
        ukey = lambda p_, q_: (min(p_, q_), max(p_, q_))
        total = 0.0
        prev = None
        for l, cap in enumerate(self.caps):
            om = h * self.g ** 2 * self.D(int(cap))
            mom = Moments(om, self.x, n, self.L, beta=self.beta, h=h)
            un = mom.untilt(k)
            fA = {pq: rfft(om * self.psi[pq[0]] * self.psi[pq[1]] * tl, self.L) for pq in upairs}
            cur = {}
            for i, si in enumerate(self.sigs):
                for jj, sj in enumerate(self.sigs):
                    sig = tuple(sorted(si + sj))
                    if sig in cur:
                        continue
                    cp = rfft(mom.moment(core, sig), self.L)
                    dd = {}
                    for ka in upairs:
                        ca = rfft(irfft(cp * fA[ka], self.L)[:n], self.L)
                        for kb in upairs:
                            dd[ka, kb] = irfft(ca * fA[kb], self.L)[:n] * un
                    cur[sig] = dd
            act = np.zeros((len(self.limits), n))
            for c, lim in enumerate(self.limits):
                act[c] = (full_cap >= 0) & (cap <= np.minimum(lim, np.where(full_cap >= 0, full_cap, 0)))
            A = np.einsum('cn,pcsn->psn', act, amp)
            dens = np.zeros(n)
            for i, si in enumerate(self.sigs):
                for jj, sj in enumerate(self.sigs):
                    sig = tuple(sorted(si + sj))
                    d = {key: cur[sig][key] - (prev[sig][key] if prev is not None else 0.) for key in cur[sig]}
                    for pi, (ma, mb) in enumerate(self.pairs):
                        for qi, (pa, pb) in enumerate(self.pairs):
                            dens += A[pi, i] * A[qi, jj] * d[ukey(ma, pa), ukey(mb, pb)]
            total += float(dens.sum())
            prev = cur
            print(json.dumps(dict(event='MASS0_LAYER', layer=l, cumulative=total)), flush=True)
        return total

    def mass2(self, w1, w2, dw1, dw2):
        """int F^2 over full configurations whose two largest marks lie in the bin (no gate), units of
        the raw integrals (multiply by kappa / rho to get units of I)."""
        n, h, B, k = self.n, self.h, self.B, self.k
        c2 = max(1, int(w2 / h))
        Drest = self.D(c2)
        j = np.arange(n)
        om = h * self.g ** 2 * Drest
        def site(*ws):
            fac = np.prod([(dw1 / w1) if w == w1 else (dw2 / w2) for w in ws])
            return h * self.g ** 2 * shifted_rho(Drest, j, sum(ws), h) * fac
        if getattr(self, '_mom_cap', None) != c2:
            self._mom = Moments(om, self.x, n, self.L, beta=self.beta, h=h)
            self._mom_cap = c2
        mom = self._mom
        un = mom.untilt(k)
        core = self.core
        both = site(w1, w2)
        placements = [(float(core), [both], {}), (float(core * (core - 1)), [site(w1), site(w2)], {})]
        for e_ in ('a', 'b'):
            placements += [(1.0, [], {e_: both}), (float(core), [site(w2)], {e_: site(w1)}), (float(core), [site(w1)], {e_: site(w2)})]
        placements += [(1.0, [], {'a': site(w1), 'b': site(w2)}), (1.0, [], {'a': site(w2), 'b': site(w1)})]
        amp, full_cap = self.z['amp'], self.z['full_cap']
        w1c = w1 / h
        act = np.zeros((len(self.limits), n))
        for c, lim in enumerate(self.limits):
            act[c] = (full_cap >= 0) & (w1c <= np.minimum(lim, np.where(full_cap >= 0, full_cap, 0)))
        A = np.einsum('cn,pcsn->psn', act, amp)                 # amplitude of each (pair, sig) at R
        tl = self.tiltv
        upairs = [(p_, q_) for p_ in range(B) for q_ in range(p_, B)]
        ukey = lambda p_, q_: (min(p_, q_), max(p_, q_))
        total = 0.0
        self.mass2_parts = []
        for mult, core_sites, endsites in placements:
            n_plain = core - len(core_sites)
            fA = {pq: rfft(endsites.get('a', om) * self.psi[pq[0]] * self.psi[pq[1]] * tl, self.L) for pq in upairs}
            fB = {pq: rfft(endsites.get('b', om) * self.psi[pq[0]] * self.psi[pq[1]] * tl, self.L) for pq in upairs}
            cache = {}
            dens = np.zeros(n)
            for i, si in enumerate(self.sigs):
                for jj, sj in enumerate(self.sigs):
                    sig = tuple(sorted(si + sj))
                    if sig not in cache:
                        cp = rfft(self.root_density(sig, n_plain, om, core_sites, [], mom), self.L)
                        dd = {}
                        for ka in upairs:
                            ca = rfft(irfft(cp * fA[ka], self.L)[:n], self.L)
                            for kb in upairs:
                                dd[ka, kb] = irfft(ca * fB[kb], self.L)[:n] * un
                        cache[sig] = dd
                    dd = cache[sig]
                    for pi, (ma, mb) in enumerate(self.pairs):
                        for qi, (pa, pb) in enumerate(self.pairs):
                            dens += mult * A[pi, i] * A[qi, jj] * dd[ukey(ma, pa), ukey(mb, pb)]
            total += float(dens.sum())
            self.mass2_parts.append(dict(mult=mult, core_sites=len(core_sites), ends=sorted(endsites), value=float(dens.sum())))
        return total

    def face_cross(self, face, rows, root_marks, lay, om, site, mom, un, c2):
        """rho-free sum over root cells of p_+ * int V V^Phi over roots of the given face with the
        root's marks placed on all possible root coordinates."""
        n, h, B = self.n, self.h, self.B
        Wc_phi, Wa_phi, Wb_phi = rows
        if lay is None:
            # the root's largest fragment is below w2 (its rest cap c2): layer l holds the roots with
            # largest fragment in (caps[l-1], min(caps[l], c2)]; difference the root measure between
            # those caps with the SAME layer-l tables
            total = 0.0
            for l in range(len(self.caps)):
                lo_cap = int(self.caps[l - 1]) if l > 0 else 0
                if lo_cap >= c2:
                    break
                top = min(int(self.caps[l]), c2)
                om_t, mom_t = self._layer_measure(top)
                d = self._face_density(face, (Wc_phi, Wa_phi, Wb_phi), (), l, om_t, site, mom_t, un)
                if lo_cap > 0:
                    om_l, mom_l = self._layer_measure(lo_cap)
                    d = d - self._face_density(face, (Wc_phi, Wa_phi, Wb_phi), (), l, om_l, site, mom_l, un)
                total += float(np.sum(self.field_pos[l] * d))
                self._drop_layer_transforms(mom_t, *((mom_l,) if lo_cap > 0 else ()))
            return total
        dens = self._face_density(face, (Wc_phi, Wa_phi, Wb_phi), root_marks, lay, om, site, mom, un)
        return float(np.sum(self.field_pos[lay] * dens))

    def _drop_layer_transforms(self, *moms):
        """Forget the per-bin transform cache entries of these layer measures (a layer's entries are not
        used by the next layer; keeping all of them holds several GB per box)."""
        fc = getattr(self, '_fcache', None)
        if fc:
            ids = {id(m_) for m_ in moms}
            for key in [k_ for k_ in fc if k_[0] == 'm' and k_[1] in ids]:
                del fc[key]

    def _layer_measure(self, cap):
        """Plain root coordinate weight and its moments for roots with every fragment <= cap."""
        if not hasattr(self, '_layer_moms'):
            self._layer_moms = {}
        cap = int(cap)
        if cap not in self._layer_moms:
            layer_caps = set(int(c_) for c_ in self.caps)
            if cap not in layer_caps:
                # a box's own rest cap: keep only the current one (the layer caps are shared by all boxes)
                for c_ in [c_ for c_ in self._layer_moms if c_ not in layer_caps]:
                    del self._layer_moms[c_]
            om = self.h * self.g ** 2 * self.D(cap)
            self._layer_moms[cap] = (om, Moments(om, self.x, self.n, self.L, beta=self.beta, h=self.h))
        return self._layer_moms[cap]

    def _face_density(self, face, rows_phi, root_marks, lay, om, site, mom, un):
        """Density over the root cell R of int V V^Phi (h^2 included, face multiplicity included)."""
        n, h, B = self.n, self.h, self.B
        Wc_phi, Wa_phi, Wb_phi = rows_phi
        core = self.core
        endw = om                                               # plain endpoint coordinate weight
        # placements of the root's marks: list of (multiplicity, core_sites, a_site, b_site)
        placements = []
        nm = len(root_marks)
        if face == 'core':
            n_core_root = core - 1
            ends_avail = ('a', 'b')
        elif face == 'a':
            n_core_root = core
            ends_avail = ('b',)
        else:
            n_core_root = core
            ends_avail = ('a',)
        if nm == 0:
            placements.append((1.0, [], {}))
        elif nm == 1:
            w = root_marks[0]
            placements.append((float(n_core_root), [site(w)], {}))
            for e_ in ends_avail:
                placements.append((1.0, [], {e_: site(w)}))
        else:
            w1, w2 = root_marks
            both = site(w1, w2)
            placements.append((float(n_core_root), [both], {}))                       # same core site
            placements.append((float(n_core_root * (n_core_root - 1)), [site(w1), site(w2)], {}))
            for e_ in ends_avail:
                placements.append((1.0, [], {e_: both}))
                placements.append((float(n_core_root), [site(w2)], {e_: site(w1)}))
                placements.append((float(n_core_root), [site(w1)], {e_: site(w2)}))
            if len(ends_avail) == 2:
                placements.append((1.0, [], {'a': site(w1), 'b': site(w2)}))
                placements.append((1.0, [], {'a': site(w2), 'b': site(w1)}))
        return self._face_density_p(face, rows_phi, placements, n_core_root, lay, om, mom, un)

    def _face_density_p(self, face, rows_phi, placements, n_core_root, lay, om, mom, un):
        n, h, B = self.n, self.h, self.B
        Wc_phi, Wa_phi, Wb_phi = rows_phi
        endw = om
        dens = np.zeros(n)
        tl = self.tiltv
        upairs = [(p_, q_) for p_ in range(B) for q_ in range(p_, B)]
        ukey = lambda p_, q_: (min(p_, q_), max(p_, q_))
        for mult, core_sites, endsites in placements:
            n_plain = n_core_root - len(core_sites)
            if face == 'core':
                fA = {pq: rfft(endsites.get('a', endw) * self.psi[pq[0]] * self.psi[pq[1]] * tl, self.L) for pq in upairs}
                fB = {pq: rfft(endsites.get('b', endw) * self.psi[pq[0]] * self.psi[pq[1]] * tl, self.L) for pq in upairs}
                sig_d = {}
                for i, ri in enumerate(self.rests):
                    for jj, rj in enumerate(self.rests):
                        sig = tuple(sorted(ri + rj))
                        if sig not in sig_d:
                            cp = rfft(self.root_density(sig, n_plain, om, core_sites, [], mom), self.L)
                            dd = {}
                            for ka in upairs:
                                ca = rfft(irfft(cp * fA[ka], self.L)[:n], self.L)
                                for kb in upairs:
                                    dd[ka, kb] = irfft(ca * fB[kb], self.L)[:n] * un
                            sig_d[sig] = dd
                        dd = sig_d[sig]
                        Wi, Wj = self.Wc[lay, i], Wc_phi[jj]
                        for ma in range(B):
                            for pa in range(B):
                                for mb in range(B):
                                    for pb in range(B):
                                        cf = Wi[ma, mb] * Wj[pa, pb]
                                        dens += mult * cf * dd[ukey(ma, pa), ukey(mb, pb)]
            else:
                Wv = self.Wa[lay] if face == 'a' else self.Wb[lay]
                Wp = Wa_phi if face == 'a' else Wb_phi
                other = 'b' if face == 'a' else 'a'
                fE = {pq: rfft(endsites.get(other, endw) * self.psi[pq[0]] * self.psi[pq[1]] * tl, self.L) for pq in upairs}
                sig_d = {}
                for i, si in enumerate(self.sigs):
                    for jj, sj in enumerate(self.sigs):
                        sig = tuple(sorted(si + sj))
                        if sig not in sig_d:
                            cp = rfft(self.root_density(sig, n_plain, om, core_sites, [], mom), self.L)
                            sig_d[sig] = {pq: irfft(cp * fE[pq], self.L)[:n] * un for pq in upairs}
                        dd = sig_d[sig]
                        for p_ in range(B):
                            for q_ in range(B):
                                dens += mult * Wv[i, p_] * Wp[jj, q_] * dd[ukey(p_, q_)]
        mult_face = float(self.core) if face == 'core' else 1.0
        return mult_face * h * h * dens


def set_partitions(items):
    """All partitions of a tuple into nonempty blocks (tuples)."""
    items = tuple(items)
    if not items:
        yield ()
        return
    first, rest = items[0], items[1:]
    for part in set_partitions(rest):
        yield ((first,),) + part
        for i in range(len(part)):
            yield part[:i] + ((first,) + part[i],) + part[i + 1:]


class RankN(Rank2):
    """The canonical cross term for configurations whose n largest marks lie in a bin (all other
    marks below the smallest), with the virtual root failing at that rank. Floating."""

    def mask_n(self, ws):
        G, h, n = self.G, self.h, self.n
        fine, ls, gates, edges, Rclass = G['fine'], G['ls'], G['gates'], G['edges'], G['R']
        radial_step = int(G['radial_step']); mrad = GATE_MINRAD // radial_step
        w1, wn = ws[0], ws[-1]
        ci = int(np.searchsorted(fine, w1 / h))
        lay = int(np.searchsorted(self.caps, w1 / h))
        if lay >= len(self.caps) or ci >= ls.shape[0]:
            return np.ones(n), lay
        gt = self.z['group_table'][lay]
        R = np.arange(n)
        Y = (R + self.k / 2) * h * self.ticks
        rc = np.maximum(mrad, np.ceil(Y / radial_step).astype(int)) - mrad
        grp = gt.astype(int)
        tested = grp >= 0
        ins = tested & (rc < ls.shape[2])
        key = np.full(n, -1)
        key[ins] = ls[ci, grp[ins], rc[ins]]
        over = np.zeros(n, bool)
        over[ins] = Y[ins] > Rclass[ci, grp[ins]]
        bn = int(np.searchsorted(edges, wn * self.ticks, side='right') - 1)
        bn = min(max(bn, 0), gates.shape[1] - 1)
        W = sum(ws) * self.ticks
        fail = (key >= 0) & (W > gates[np.maximum(key, 0), bn])
        return (tested & (fail | (key < 0) | over)).astype(float), lay

    def contribution_n(self, ws, dws):
        n, h = self.n, self.h
        ws = tuple(ws); dws_list = list(dws)
        maskR, lay1 = self.mask_n(ws)
        if not maskR.any() or lay1 >= len(self.caps):
            return 0.0, {}
        cr = max(1, int(ws[-1] / h))
        Drest = self.D(cr)
        j = np.arange(n)
        om = h * self.g ** 2 * Drest
        # marks are referred to by index, so that equal values in a shared bin stay distinct
        fac = lambda block: float(np.prod([dws_list[i] / ws[i] for i in block]))
        site = lambda *block: h * self.g ** 2 * shifted_rho(Drest, j, sum(ws[i] for i in block), h) * fac(block)
        def insw(block):
            if not block:
                return Drest.copy()
            return shifted_rho(Drest, j, sum(ws[i] for i in block), h) * fac(block)
        if getattr(self, '_mom_cap', None) != cr:
            self._mom = Moments(om, self.x, n, self.L, beta=self.beta, h=h)
            self._mom_cap = cr
        mom = self._mom
        un = mom.untilt(self.k - 1)
        parts = {}
        total = 0.0
        from itertools import combinations
        idx = tuple(range(len(ws)))
        for size in range(len(ws) + 1):
            for carried in combinations(idx, size):
                rows = self.rows(maskR, ws[0], insw(carried))
                root_marks = tuple(i for i in idx if i not in carried)
                lay = int(np.searchsorted(self.caps, max(ws[i] for i in root_marks) / h)) if root_marks else None
                for face in ('core', 'a', 'b'):
                    val = self.face_cross_n(face, rows, root_marks, lay, om, site, mom, un, cr)
                    key = (size, face)
                    parts[key] = parts.get(key, 0.0) + val
                    total += val
        return total, parts

    def placements_n(self, face, root_marks, site):
        core = self.core
        if face == 'core':
            n_core_root, ends_avail = core - 1, ('a', 'b')
        else:
            n_core_root, ends_avail = core, (('b',) if face == 'a' else ('a',))
        if not root_marks:
            return [(1.0, [], {})], n_core_root
        out = []
        for part in set_partitions(root_marks):
            blocks = list(part)
            # assign each block to an available endpoint or to a core coordinate
            for assign in __import__('itertools').product(('core',) + ends_avail, repeat=len(blocks)):
                ends_used = [a_ for a_ in assign if a_ != 'core']
                if len(set(ends_used)) != len(ends_used):
                    continue
                core_blocks = [b_ for b_, a_ in zip(blocks, assign) if a_ == 'core']
                kc = len(core_blocks)
                mult = float(np.prod(np.arange(n_core_root - kc + 1, n_core_root + 1))) if kc else 1.0
                endsites = {a_: site(*b_) for b_, a_ in zip(blocks, assign) if a_ != 'core'}
                out.append((mult, [site(*b_) for b_ in core_blocks], endsites))
        return out, n_core_root

    def face_cross_n(self, face, rows, root_marks, lay, om, site, mom, un, cr, rows_by_layer=None):
        n, h = self.n, self.h
        placements, n_core_root = self.placements_n(face, root_marks, site)
        if lay is None:
            # roots without large marks: layer l holds largest fragments in (caps[l-1], min(caps[l], cr)];
            # difference the root measure between those caps with the SAME layer-l tables
            total = 0.0
            for l in range(len(self.caps)):
                lo_cap = int(self.caps[l - 1]) if l > 0 else 0
                if lo_cap >= cr:
                    break
                top = min(int(self.caps[l]), cr)
                rl = rows if rows_by_layer is None else rows_by_layer(l)
                om_t, mom_t = self._layer_measure(top)
                d = self._face_density_p(face, rl, placements, n_core_root, l, om_t, mom_t, un)
                if lo_cap > 0:
                    om_l, mom_l = self._layer_measure(lo_cap)
                    d = d - self._face_density_p(face, rl, placements, n_core_root, l, om_l, mom_l, un)
                total += float(np.sum(self.field_pos[l] * d))
                self._drop_layer_transforms(mom_t, *((mom_l,) if lo_cap > 0 else ()))
            return total
        dens = self._face_density_p(face, rows, placements, n_core_root, lay, om, mom, un)
        return float(np.sum(self.field_pos[lay] * dens))


class RankGF(RankN):
    """RankN reorganised: one combined amplitude per bin for the erased rows, and the root's mark
    placements as a subset generating function. For root marks R (a set of mark indices),

        root density = sum over A, B, M with A + B + M = R (disjoint) of
                       E_A(endpoint a) * E_B(endpoint b) * K_M(core coordinates),

    where E_A is the endpoint weight carrying the block A (plain if A is empty) and K_M sums the set
    partitions of M onto distinct core coordinates with falling-factorial multiplicities. Three-factor
    products are summed in the Fourier domain with a transform of length >= 3n, so one inverse
    transform serves all placements. Equal to RankN term by term (floating)."""

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.L3 = next_fast_len(3 * self.n)
        upairs = [(p_, q_) for p_ in range(self.B) for q_ in range(p_, self.B)]
        self.upairs = upairs
        self.rest_plan = {}
        for si, sig in enumerate(self.sigs):
            for rest, e, mult in fiber_splits(sig):
                if rest in self.rest_index:
                    self.rest_plan.setdefault(self.rest_index[rest], []).append((si, e, mult))

    # ---- erased rows from one combined amplitude
    def combined_amplitude(self, maskR, w1):
        amp, full_cap = self.z['amp'], self.z['full_cap']
        w1c = w1 / self.h
        act = np.zeros((len(self.limits), self.n))
        fc = np.where(full_cap >= 0, full_cap, 0)
        for c, lim in enumerate(self.limits):
            act[c] = (full_cap >= 0) & (w1c <= np.minimum(lim, fc))
        A = np.einsum('cn,pcsn->psn', act, amp) * maskR
        return rfft(A, self.L, axis=-1)

    def amplitude_alive(self, maskR, w1):
        """Whether the combined amplitude of combined_amplitude is nonzero on some masked cell."""
        amp, full_cap = self.z['amp'], self.z['full_cap']
        w1c = w1 / self.h
        fc = np.where(full_cap >= 0, full_cap, 0)
        cells = np.nonzero(maskR)[0]
        for c, lim in enumerate(self.limits):
            on = cells[(full_cap[cells] >= 0) & (w1c <= np.minimum(lim, fc[cells]))]
            if len(on) and np.any(np.asarray(amp[:, c][:, :, on]) != 0):
                return True
        return False

    def rows_gf(self, FA, ins):
        n, L = self.n, self.L
        base = self.g * ins
        fk = {}
        def fkern(e, shape=None):
            key = (e, shape)
            if key not in fk:
                arr = base * self.x ** e
                if shape is not None:
                    arr = arr * self.psi[shape]
                fk[key] = rfft(arr[::-1], L)
            return fk[key]
        Wc = np.zeros((len(self.rests), self.B, self.B, n))
        Wa = np.zeros((len(self.sigs), self.B, n)); Wb = np.zeros_like(Wa)
        for ri, plan in self.rest_plan.items():
            for pi, (ma, mb) in enumerate(self.pairs):
                acc = np.zeros(L // 2 + 1, complex)
                for si, e, mult in plan:
                    acc += mult * FA[pi, si] * fkern(e)
                Wc[ri, ma, mb] = irfft(acc, L)[n - 1:2 * n - 1]
        for si in range(len(self.sigs)):
            for keep in range(self.B):
                acc_a = np.zeros(L // 2 + 1, complex); acc_b = np.zeros(L // 2 + 1, complex)
                for pi, (ma, mb) in enumerate(self.pairs):
                    if mb == keep:
                        acc_a += FA[pi, si] * fkern(0, ma)
                    if ma == keep:
                        acc_b += FA[pi, si] * fkern(0, mb)
                Wa[si, keep] = irfft(acc_a, L)[n - 1:2 * n - 1]
                Wb[si, keep] = irfft(acc_b, L)[n - 1:2 * n - 1]
        return Wc, Wa, Wb

    # ---- the subset generating function of the root
    def core_part(self, M, N_core, sig, site_of, mom):
        """K_M for one signature (tilted, cell domain): set partitions of M onto distinct core sites."""
        M = tuple(sorted(M))
        acc = np.zeros(self.n)
        for part in set_partitions(M):
            k_ = len(part)
            if k_ > N_core:
                continue
            fall = float(np.prod(np.arange(N_core - k_ + 1, N_core + 1))) if k_ else 1.0
            acc += fall * self.root_density(sig, N_core - k_, None, [site_of(b_) for b_ in part], [], mom)
        return acc

    def face_density_gf(self, face, rows_phi, Rset, lay, om, site_of, mom, un, cache):
        n, h, B, L3 = self.n, self.h, self.B, self.L3
        Wc_phi, Wa_phi, Wb_phi = rows_phi
        tl = self.tiltv
        ukey = lambda p_, q_: (min(p_, q_), max(p_, q_))
        N_core = self.core - 1 if face == 'core' else self.core
        Rset = tuple(sorted(Rset))
        subsets = [tuple(c_) for r_ in range(len(Rset) + 1) for c_ in __import__('itertools').combinations(Rset, r_)]
        def FE(Aset, pq):
            key = ('E', Aset, pq)
            if key not in cache:
                arr = om if not Aset else site_of(Aset)
                cache[key] = rfft(arr * self.psi[pq[0]] * self.psi[pq[1]] * tl, L3)
            return cache[key]
        def FK(Mset, sig):
            key = ('K', N_core, Mset, sig)
            if key not in cache:
                cache[key] = rfft(self.core_part(Mset, N_core, sig, site_of, mom), L3)
            return cache[key]
        dens = np.zeros(n)
        if face == 'core':
            Wv = self.Wc[lay]
            done = {}
            for i, ri in enumerate(self.rests):
                for jj, rj in enumerate(self.rests):
                    sig = tuple(sorted(ri + rj))
                    if sig not in done:
                        dd = {}
                        for ka in self.upairs:
                            for kb in self.upairs:
                                X = np.zeros(L3 // 2 + 1, complex)
                                for Aset in subsets:
                                    restA = tuple(x_ for x_ in Rset if x_ not in Aset)
                                    for r2 in range(len(restA) + 1):
                                        for Bset in __import__('itertools').combinations(restA, r2):
                                            Mset = tuple(x_ for x_ in restA if x_ not in Bset)
                                            X += FE(Aset, ka) * FE(tuple(Bset), kb) * FK(Mset, sig)
                                dd[ka, kb] = irfft(X, L3)[:n] * un
                        done[sig] = dd
                    dd = done[sig]
                    Wi, Wj = Wv[i], Wc_phi[jj]
                    for ma in range(B):
                        for pa in range(B):
                            for mb in range(B):
                                for pb in range(B):
                                    dens += Wi[ma, mb] * Wj[pa, pb] * dd[ukey(ma, pa), ukey(mb, pb)]
        else:
            Wv = self.Wa[lay] if face == 'a' else self.Wb[lay]
            Wp = Wa_phi if face == 'a' else Wb_phi
            done = {}
            for i, si in enumerate(self.sigs):
                for jj, sj in enumerate(self.sigs):
                    sig = tuple(sorted(si + sj))
                    if sig not in done:
                        dd = {}
                        for kk in self.upairs:
                            X = np.zeros(L3 // 2 + 1, complex)
                            for Aset in subsets:
                                Mset = tuple(x_ for x_ in Rset if x_ not in Aset)
                                X += FE(Aset, kk) * FK(Mset, sig)
                            dd[kk] = irfft(X, L3)[:n] * un
                        done[sig] = dd
                    dd = done[sig]
                    for p_ in range(B):
                        for q_ in range(B):
                            dens += Wv[i, p_] * Wp[jj, q_] * dd[ukey(p_, q_)]
        mult_face = float(self.core) if face == 'core' else 1.0
        return mult_face * h * h * dens

    # ---- deleted mass of a bin (for the pair term)
    def _mass_value(self, ws, maskR, om, site_of, mom):
        """int F^2 over the full configurations of the bin on the mask, with the weights that bin_value
        has set up (midpoint or envelope), divided by rho so that kappa times the value is in units
        of I. In mode 'phi' the integrand carries Phi of the pair-restoration fibre bound,
        ((rho S - q) / (1/2 - q - 1e-4))^2 with q = rho times the core total, read at the lower edge
        of the core cell sum (Phi decreases in q) and with S raised by k cells.

        The marks are placed on endpoint a, endpoint b and the core coordinates as in
        face_density_gf, here for all k coordinates. F is constant on cells and F^2 >= 0, so with
        the envelope weights (a measure that dominates the true one on the box) and a mask that
        contains the deleted set this bounds the bin's share of int_D F^2 Phi from above whatever
        the sign of F. Floating."""
        n, h, L3, k = self.n, self.h, self.L3, self.k
        from itertools import combinations
        amp, full_cap = self.z['amp'], self.z['full_cap']
        w1c = ws[0] / h
        fc = np.where(full_cap >= 0, full_cap, 0)
        act = np.zeros((len(self.limits), n))
        for c, lim in enumerate(self.limits):
            act[c] = (full_cap >= 0) & (w1c <= np.minimum(lim, fc))
        A = np.einsum('cn,pcsn->psn', act, amp)
        rho = float(self.m['rho'])
        phi = None
        if self.mass_mode == 'phi':
            q = rho * np.arange(n) * h
            den = 0.5 - q - 1e-4
            assert den.min() > 0
            phi = (np.maximum(rho * (float(self.m['S']) + k * h) - q, 0.0) / den) ** 2
        tl = self.tiltv
        un = mom.untilt(k)
        idx = tuple(range(len(ws)))
        subsets = [tuple(c_) for r_ in range(len(idx) + 1) for c_ in combinations(idx, r_)]
        ukey = lambda p_, q_: (min(p_, q_), max(p_, q_))
        FE = {}
        for Aset in subsets:
            arr = om if not Aset else site_of(Aset)
            for pq in self.upairs:
                FE[Aset, pq] = rfft(arr * self.psi[pq[0]] * self.psi[pq[1]] * tl, L3)
        # the two endpoints together, for each set M of marks left to the core coordinates
        ends = {}
        for Mset in subsets:
            others = tuple(x_ for x_ in idx if x_ not in Mset)
            for ka in self.upairs:
                for kb in self.upairs:
                    X = np.zeros(L3 // 2 + 1, complex)
                    for r2 in range(len(others) + 1):
                        for Aset in combinations(others, r2):
                            Bset = tuple(x_ for x_ in others if x_ not in Aset)
                            X += FE[tuple(Aset), ka] * FE[Bset, kb]
                    ends[Mset, ka, kb] = X
        dens = np.zeros(n)
        done = {}
        for i, si in enumerate(self.sigs):
            for jj, sj in enumerate(self.sigs):
                sig = tuple(sorted(si + sj))
                if sig not in done:
                    FK = {}
                    for Mset in subsets:
                        kp = self.core_part(Mset, self.core, sig, site_of, mom)
                        FK[Mset] = rfft(kp if phi is None else kp * phi, L3)
                    dd = {}
                    for ka in self.upairs:
                        for kb in self.upairs:
                            X = np.zeros(L3 // 2 + 1, complex)
                            for Mset in subsets:
                                X += ends[Mset, ka, kb] * FK[Mset]
                            dd[ka, kb] = irfft(X, L3)[:n] * un
                    done[sig] = dd
                dd = done[sig]
                for pi, (ma, mb) in enumerate(self.pairs):
                    for qi, (pa, pb) in enumerate(self.pairs):
                        dens += A[pi, i] * A[qi, jj] * dd[ukey(ma, pa), ukey(mb, pb)]
        return float(np.sum(maskR * dens)) / rho

    # ---- failure-favourable (envelope) form of a bin
    def env_straddles(self, lo, hi):
        """True if some mark interval meets a layer cap in its interior, or the largest one meets a
        component limit or a full-cap value: the profile and the root's layer tables are then not
        constant on the bin, and the envelope below is not a majorant there."""
        caps = np.asarray(self.caps, float)
        fc = np.unique(np.asarray(self.z['full_cap']))
        brk1 = np.concatenate([caps, np.asarray(self.limits, float), fc[fc >= 0].astype(float)])
        tol = 1e-6                                              # cells; breakpoints closer to an edge count as on it
        inside = lambda b, a, c: bool(np.any((b > a / self.h + tol) & (b < c / self.h - tol)))
        return inside(brk1, lo[0], hi[0]) or any(inside(caps, a, c) for a, c in zip(lo[1:], hi[1:]))

    def boxes(self, parent_lo, step, refine=1, w1max=None, w1min=None, refine_last=None):
        """Sub-boxes of a parent bin (lower edges parent_lo, common width step) on which the envelope is a
        majorant: each mark interval is cut into `refine` equal parts and further at every layer cap,
        component limit and full-cap value inside it (the same cuts for every mark, so that marks sharing
        a parent interval share their pieces). Returns (lo, hi, weight) with marks in descending order;
        pieces shared by several marks are taken once per multiset, with weight 1 / prod(multiplicity!).
        With w1max, every interval is also cut there and boxes whose largest mark lies above it are dropped
        (those configurations go to a separate tail term). With refine_last, the intervals sharing the
        smallest mark's parent interval are cut into refine_last parts instead (the rest density is
        read at the top of the smallest mark's interval and is very sensitive to it)."""
        from itertools import product as _prod
        from math import factorial as _fact
        caps = np.asarray(self.caps, float)
        fc = np.unique(np.asarray(self.z['full_cap']))
        brk = np.unique(np.concatenate([caps, np.asarray(self.limits, float), fc[fc >= 0].astype(float)])) * self.h
        for w_ in (w1max, w1min):
            if w_ is not None:
                brk = np.unique(np.concatenate([brk, [w_]]))
        a_min = min(parent_lo)
        a_max = max(parent_lo)
        # If several top marks share a parent interval, the ordered largest
        # mark has an order-statistic density. Split every member of that
        # tied group before applying the permutation weights below.
        split_top_class = getattr(self, 'class_split', False) and sum(a == a_max for a in parent_lo) > 1
        class_edges = np.asarray(self.G['fine']) * self.h if split_top_class else ()
        def pieces(a):
            rf = refine_last if (refine_last and abs(a - a_min) < 1e-12) else refine
            cuts = sorted([a + i * step / rf for i in range(rf + 1)] + [float(b) for b in brk if a < b < a + step])
            if split_top_class and a == a_max:
                cuts = sorted(cuts + [float(b) for b in class_edges if a < b < a + step])
            keep = [cuts[0]]
            for c in cuts[1:]:
                if c - keep[-1] > 1e-12:
                    keep.append(c)
            return list(zip(keep[:-1], keep[1:]))
        parent = sorted(parent_lo, reverse=True)
        per = [pieces(a) for a in parent]
        seen = {}
        for combo in _prod(*per):
            key = tuple(sorted(combo, reverse=True))
            seen[key] = seen.get(key, 0) + 1
        out = []
        for key in seen:
            if w1max is not None and key[0][0] >= w1max - 1e-12:
                continue
            if w1min is not None and key[0][1] <= w1min + 1e-12:
                continue
            weight = 1.0 / float(np.prod([_fact(c) for c in Counter(key).values()]))
            out.append((tuple(p[0] for p in key), tuple(p[1] for p in key), weight))
        return out

    def env_box_value(self, parent_lo, step, refine=1, cover=False, w1max=None, w1min=None, refine_last=None):
        """Envelope value of a parent bin, summed over its sub-boxes (raw units; multiply by kappa)."""
        tot = 0.0; parts = {}
        for lo, hi, weight in self.boxes(parent_lo, step, refine, w1max, w1min, refine_last):
            assert not self.env_straddles(lo, hi)
            ws = [(a + b) / 2 for a, b in zip(lo, hi)]; dws = [b - a for a, b in zip(lo, hi)]
            c, p = self.bin_value(ws, dws, env=True, cover=cover)
            if not np.isfinite(c):
                # seen once in long runs and not reproduced in isolation: recompute without the transform cache
                fc_ = getattr(self, 'fft_cache_on', False); self.fft_cache_on = False
                c, p = self.bin_value(ws, dws, env=True, cover=cover)
                self.fft_cache_on = fc_
                print(json.dumps(dict(event='NONFINITE_RECOMPUTED', lo=list(lo), hi=list(hi), value=float(c))), flush=True)
                assert np.isfinite(c), (lo, hi)
            tot += c * weight
            for k_, v in p.items():
                parts[k_] = parts.get(k_, 0.0) + v * weight
        return tot, parts

    def mask_scan(self, parent_lo, step, refine=1, w1max=None):
        """Cells where the covering mask exceeds the Phi_0 envelope, summed over the sub-boxes of a bin."""
        extra = 0; base = 0; rng = None
        for lo, hi, weight in self.boxes(parent_lo, step, refine, w1max):
            mv, _ = self.mask_env(lo, hi, False)
            mc, _ = self.mask_env(lo, hi, True)
            d = (mc > 0) & ~(mv > 0)
            extra += int(d.sum()); base += int((mv > 0).sum())
            if d.any():
                idx = np.flatnonzero(d)
                lo_r, hi_r = float(idx.min() * self.h), float(idx.max() * self.h)
                rng = (lo_r, hi_r) if rng is None else (min(rng[0], lo_r), max(rng[1], hi_r))
        return dict(base_cells=base, extra_cells=extra, extra_range=rng)

    def mask_env(self, lo, hi, cover=False):
        """Superset of the rank-n failure set of the virtual root for marks w_m in [lo_m, hi_m): the
        tails are bounded by the sum of upper ends; the gate is read at the highest gate bin that
        I_n meets (gate rows are nonincreasing in the bin, checked on the tables); and the union is
        taken over the classes and layers met by I_1 and over the radial bins met by the exact total
        Y in [R h, (R + k) h), with the radius test at the top of that interval. With cover=True it also
        contains every configuration of the bin some erasure of which fails at a bin >= that of w_n
        (prefix_gate; the erasure of u_1's carrier by its own term, whose tails are at most
        w_2 + ... + w_n), so that it covers the deleted set D at these bins and not only Phi_0.

        At each cell the condition is a half-space sum(w) > theta(r) (theta the least gate met). With
        self.fractional the 0/1 mask is replaced by the volume fraction of the mark box in that
        half-space (plus the carrier's fraction, capped at 1): with the box's supremum weights of
        bin_value(env=True) this still bounds the integral over the box from above. Floating."""
        G, h, n = self.G, self.h, self.n
        if getattr(self, 'unmasked', False):
            # every configuration of the box counts (a majorant of any failure set)
            return np.ones(n), int(np.searchsorted(self.caps, lo[0] / h))
        if getattr(self, 'ymin', None) is not None:
            # every configuration of the box with room for one more fragment of at least ymin: its total is
            # then at least sum(lo) + ymin, and it is below (R + k) h. This counts all configurations with
            # these top marks and a further fragment of that size, whatever makes them fail.
            return ((np.arange(n) + self.k) * h > sum(lo) + self.ymin).astype(float), int(np.searchsorted(self.caps, lo[0] / h))
        fine, ls, gates, edges, Rclass = G['fine'], G['ls'], G['gates'], G['edges'], G['R']
        radial_step = int(G['radial_step']); mrad = GATE_MINRAD // radial_step
        force_ci = getattr(self, '_force_ci', None)
        tied_max = len(lo) >= 2 and (lo[0], hi[0]) == (lo[1], hi[1])
        if getattr(self, 'class_split', False) and force_ci is None and not tied_max:
            # the gate changes sharply between fine classes of the largest mark: split its interval at
            # the class edges and give each piece its own class's gates (a volume-weighted sum of masks,
            # each a superset on its piece), instead of the least gate over all classes the box meets
            c0, c1 = int(np.searchsorted(fine, lo[0] / h)), int(np.searchsorted(fine, hi[0] / h))
            if c1 > c0:
                cuts = [lo[0]] + [float(fine[c]) * h for c in range(c0, min(c1 + 1, len(fine))) if lo[0] < fine[c] * h < hi[0]] + [hi[0]]
                acc = np.zeros(n)
                for a_, b_ in zip(cuts[:-1], cuts[1:]):
                    if b_ - a_ <= 0:
                        continue
                    if b_ - a_ < 1e-9 and getattr(self, 'chernoff', None) is None:
                        # a rounding sliver next to a class edge: count all of it (a superset)
                        acc += (b_ - a_) / (hi[0] - lo[0])
                        continue
                    if b_ - a_ < 1e-9:
                        # same sliver under a Chernoff mask: give it the neighbouring class's mask
                        # (computed below with the midpoint class; the piece has width < 1e-9)
                        pass
                    self._force_ci = int(np.searchsorted(fine, (a_ + b_) / 2 / h))
                    try:
                        mk, _ = self.mask_env((a_,) + tuple(lo[1:]), (b_,) + tuple(hi[1:]), cover)
                    finally:
                        self._force_ci = None
                    acc += mk * (b_ - a_) / (hi[0] - lo[0])
                if getattr(self, 'chernoff', None) is None:
                    acc = np.minimum(acc, 1.0)
                return acc, int(np.searchsorted(self.caps, lo[0] / h))
        # the open interval (lo, hi) of the largest mark: a box edge lying on a class edge or layer cap
        # (boxes are cut there, up to 1e-6 cells) does not bring in the class or layer below it
        eps = 1e-6
        cis = range(int(np.searchsorted(fine, lo[0] / h + eps)), int(np.searchsorted(fine, hi[0] / h - eps)) + 1)
        if force_ci is not None:
            cis = range(force_ci, force_ci + 1)
        lays = range(int(np.searchsorted(self.caps, lo[0] / h + eps)), int(np.searchsorted(self.caps, hi[0] / h - eps)) + 1)
        lay1 = int(np.searchsorted(self.caps, lo[0] / h + eps))
        mid0 = (lo[0] + hi[0]) / 2 / h
        if len(cis) == 0:                                  # a box thinner than the tolerance: its midpoint's class
            c_ = int(np.searchsorted(fine, mid0)); cis = range(c_, c_ + 1)
        if len(lays) == 0:
            l_ = int(np.searchsorted(self.caps, mid0)); lays = range(l_, l_ + 1); lay1 = l_
        if lay1 >= len(self.caps) or cis[-1] >= ls.shape[0] or lays[-1] >= len(self.caps):
            return np.ones(n), lay1
        R = np.arange(n)
        Ylo = R * h * self.ticks
        Yhi = (R + self.k) * h * self.ticks
        rcs = [np.maximum(mrad, np.ceil(Y / radial_step).astype(int)) - mrad for Y in (Ylo, Yhi)]
        big = 1e300
        t = self.ticks
        keys = []                                    # (tested, key, over) per layer, class and radial bin
        certain = np.zeros(n, bool)                  # fails whatever the marks
        cfrac = np.zeros(n)                          # the same as a fraction of the cell (see below)
        # Lookup failures as a fraction of the cell. A configuration of cell sum R has total
        # Y = R h + (sum of the k coordinates' offsets within their cells). Given the cells, the offsets
        # are independent, and the density of an unmarked coordinate within its cell is proportional to
        # rho, which is nonincreasing, so its offset is stochastically at most uniform. A coordinate
        # carrying marks is given the full cell. Hence P(Y > y) <= P(m + U_1 + ... + U_(k-m) > (y - R h) / h),
        # with m the number of marks: an Irwin-Hall tail, tabulated exactly.
        m_ = len(lo)
        cellw = h * t
        for lay in lays:
            grp = self.z['group_table'][lay].astype(int)
            tested = grp >= 0
            for ci in cis:
                part = np.zeros(n)
                klo = None
                for rc in rcs:
                    ins = tested & (rc < ls.shape[2])
                    key = np.full(n, -1)
                    key[ins] = ls[ci, grp[ins], rc[ins]]
                    over = np.zeros(n, bool)
                    over[ins] = Yhi[ins] > Rclass[ci, grp[ins]]
                    certain |= tested & ((key < 0) | over)
                    keys.append((tested & (key >= 0), np.maximum(key, 0)))
                    if klo is None:
                        klo = key
                        rad_ = np.full(n, big); rad_[ins] = Rclass[ci, grp[ins]]
                        # total above the class radius
                        part += np.where(tested, irwin_hall_tail(self.k - m_, (rad_ - Ylo) / cellw - m_), 0.0)
                        part += (tested & (key < 0)).astype(float)          # the lower radial bin has no class
                    else:
                        # only the upper radial bin has no class: the total must pass the bin's edge
                        edge_ = (rcs[0] + mrad) * float(radial_step)
                        part += np.where(tested & (klo >= 0) & (key < 0), irwin_hall_tail(self.k - m_, (edge_ - Ylo) / cellw - m_), 0.0)
                cfrac = np.maximum(cfrac, np.minimum(part, 1.0))
        carriers = []
        rest_cap = getattr(self, 'rest_cap', None)
        # the carrier's erasure leaves a root whose largest fragment is at most the second mark; with one
        # mark and no rest cap that is only known to be at most the largest mark itself
        second = hi[1] if len(lo) >= 2 else (rest_cap if rest_cap is not None else hi[0])
        if cover and second is not None:
            ci2 = int(np.searchsorted(fine, second / h)); lay2 = int(np.searchsorted(self.caps, second / h))
            carriers = [(ci_e, lay_e) for lay_e in range(0, min(lay2, len(self.caps) - 1) + 1)
                        for ci_e in range(0, min(ci2, ls.shape[0] - 1) + 1)]

        fin = bool(getattr(self, 'finite_only', False)) or getattr(self, 'chernoff', None) is not None

        def thetas(b):
            """Least gate met at gate bin b (ticks), and the carrier's."""
            th = np.full(n, big)
            for ok, key in keys:
                th = np.minimum(th, np.where(ok, gates[key, b].astype(float), big))
            if cover:
                for lay in lays:
                    for ci in cis:
                        th = np.minimum(th, self.prefix_gate(ci, lay, b, fin))
            thc = np.full(n, big)
            if carriers:
                # the carrier term depends on the carriers' set (all classes and layers up to those of the
                # second mark) only: cache its minimum, not each carrier's prefix (memory)
                ckey = ('carrier', ci2, lay2, b, fin)
                cc = self.__dict__.setdefault('_carrier_cache', {})
                if ckey not in cc:
                    if len(cc) > 400:
                        cc.clear()
                    acc_ = np.full(n, big)
                    for ci_e, lay_e in carriers:
                        acc_ = np.minimum(acc_, self.prefix_gate(ci_e, lay_e, b, fin, store=False))
                    cc[ckey] = acc_
                thc = cc[ckey]
            return th, thc

        if getattr(self, 'certain_only', False):
            return (cfrac if getattr(self, 'fractional', False) else certain.astype(float)), lay1
        if getattr(self, 'bin0', False):
            # Failures at gate bin 0. Its edge is one tick, so the tails there are the root's whole total
            # and the root fails as soon as its total exceeds the gate: a radius condition with no marks
            # in it. Given the cells, the total is Ylo plus the coordinates' offsets, at most an
            # Irwin-Hall sum as for the lookup failures above. An erasure's root at r - j has total at most
            # (r - j) h plus the same offsets, so it fails only if the offsets exceed
            # gate(r - j) - (r - j) h, at least the sharp prefix gate minus Ylo; the carrier's root lies at
            # least jw cells lower.
            thv = np.full(n, big)
            for ok, key in keys:
                thv = np.minimum(thv, np.where(ok, gates[key, 0].astype(float), big))
            lim_ = 1e17
            fr = np.where(thv < lim_, irwin_hall_tail(self.k - m_, (np.minimum(thv, lim_) - Ylo) / cellw - m_), 0.0)
            if cover:
                ths = np.full(n, big)
                for lay in lays:
                    for ci in cis:
                        ths = np.minimum(ths, self.prefix_gate(ci, lay, 0, True, sharp=True))
                fr = fr + np.where(ths < lim_, irwin_hall_tail(self.k - m_, (np.minimum(ths, lim_) - Ylo) / cellw - m_), 0.0)
                if carriers:
                    ckey = ('carrier_sharp', ci2, lay2, 0)
                    cc = self.__dict__.setdefault('_carrier_cache', {})
                    if ckey not in cc:
                        if len(cc) > 400:
                            cc.clear()
                        acc_ = np.full(n, big)
                        for ci_e, lay_e in carriers:
                            acc_ = np.minimum(acc_, self.prefix_gate(ci_e, lay_e, 0, True, store=False, sharp=True))
                        cc[ckey] = acc_
                    jw = int(np.floor(lo[0] / h))
                    thcs = np.full(n, big)
                    if jw < n:
                        thcs[jw:] = cc[ckey][:n - jw] + jw * h * t
                    fr = fr + np.where(thcs < lim_, irwin_hall_tail(self.k - m_, (np.minimum(thcs, lim_) - Ylo) / cellw - m_), 0.0)
            return np.minimum(fr, 1.0), lay1
        ch = getattr(self, 'chernoff', None)
        if ch is not None:
            # Chernoff mask for failures at gate bins b_lo .. b_top (of the virtual root or of an erasure):
            # the tails at such a bin are at most Y - s, s the mass of fragments below edge(b_lo), and the
            # gate is at least that of b_top. So 1[fail] <= exp(mu (Y - gate - s)); exp(-mu s) is carried by
            # the tilted coordinate tables (self.tilt), and theta^(N - n0) >= 1 when at least n0 further
            # fragments lie at or above the edge. Lookup failures are counted elsewhere (cells left out).
            b_lo, b_top, mu_, n0 = ch
            u_ = edges[b_lo] / t
            if hi[0] <= u_:
                return np.zeros(n), lay1
            sc_ = getattr(self, 'tilt_cap', None)
            if cover and sc_ is not None:
                # Sharp cover. An erasure of coordinate i (cell j_i, total at least j_i h) leaves a root at
                # r - j_i whose tails at these bins are at most Y - j_i h - h (S - S_i), S the cell sum of
                # all fragments below the edge and S_i that of coordinate i. So it fails only if
                # Y - h (S - S_i) > gate(r - j_i) + j_i h >= the sharp prefix gate at r. Since
                # S - max_i S_i >= sum_i min(S_i, sc) - sc, the indicator is at most
                # exp(mu sc h) exp(mu (Y - sharp gate)) prod_i q^min(S_i, sc): the capped tilt of
                # capped_tilted_cells. The carrier's coordinate holds at least the largest mark, so its
                # root lies at least jw cells lower. The virtual root keeps its own gate and needs no
                # factor exp(mu sc h) (the capped weight is at least the uncapped one).
                thv = np.full(n, big)
                for ok, key in keys:
                    thv = np.minimum(thv, np.where(ok, gates[key, b_top].astype(float), big))
                ths = np.full(n, big)
                for lay in lays:
                    for ci in cis:
                        ths = np.minimum(ths, self.prefix_gate(ci, lay, b_top, True, sharp=True))
                thcs = np.full(n, big)
                if carriers:
                    ckey = ('carrier_sharp', ci2, lay2, b_top)
                    cc = self.__dict__.setdefault('_carrier_cache', {})
                    if ckey not in cc:
                        if len(cc) > 400:
                            cc.clear()
                        acc_ = np.full(n, big)
                        for ci_e, lay_e in carriers:
                            acc_ = np.minimum(acc_, self.prefix_gate(ci_e, lay_e, b_top, True, store=False, sharp=True))
                        cc[ckey] = acc_
                    jw = int(np.floor(lo[0] / h))
                    if jw < n:
                        thcs[jw:] = cc[ckey][:n - jw] + jw * h * t
                lim_ = 1e17                                  # prefix_gate's sentinel is about 2e18
                es_ = float(np.exp(mu_ * sc_ * h))
                e0 = np.where(thv < lim_, np.minimum(mu_ * (Yhi - thv) / t, 700.0), -np.inf)
                e1 = np.where(ths < lim_, np.minimum(mu_ * (Yhi - ths) / t, 700.0), -np.inf)
                e2 = np.where(thcs < lim_, np.minimum(mu_ * (Yhi - thcs) / t, 700.0), -np.inf)
                mk_ = (np.exp(e0) + es_ * (np.exp(e1) + np.exp(e2))) * float(self.tilt[2]) ** (-n0)
                return mk_, lay1
            th_, thc_ = thetas(b_top)
            if carriers:
                # the carrier's coordinate holds the largest mark, at least lo[0]: its cell is at least
                # jw, so the root it leaves lies at a cell sum of at most r - jw, and only gates met
                # there count (thc_ is a prefix minimum in the root's cell sum)
                jw = int(np.floor(lo[0] / h))
                shifted = np.full(n, big)
                if jw < n:
                    shifted[jw:] = thc_[:n - jw]
                thc_ = shifted
            ex1 = np.where(th_ < big / 2, np.minimum(mu_ * (Yhi - th_) / t, 700.0), -np.inf)
            ex2 = np.where(thc_ < big / 2, np.minimum(mu_ * (Yhi - lo[0] * t - thc_) / t, 700.0), -np.inf)
            mk_ = (np.exp(ex1) + np.exp(ex2)) * float(self.tilt[2]) ** (-n0)
            return mk_, lay1
        ymode = getattr(self, 'ymask', None)
        ystash = np.zeros(n, bool)
        if ymode is not None:
            # total-based mask: any failure of the virtual root or of an erasure at a gate bin b at or below
            # that of `ybin` (default: the top of the smallest mark's interval, or the rest cap) has tails at
            # most the total Y < (R + k) h, and a gate at least the gate at that bin (rows nonincreasing)
            ybin = rest_cap if rest_cap is not None else hi[-1]
            by = min(max(int(np.searchsorted(edges, ybin * t, side='left') - 1), 0), gates.shape[1] - 1)
            cert = certain if not getattr(self, 'finite_only', False) else np.zeros(n, bool)
            th_y, thc_y = thetas(by)
            Yt = Yhi
            ym = cert | (Yt > th_y) | (Yt - lo[0] * t > thc_y)
            if ymode == 'only':
                return ym.astype(float), lay1
            ystash = ym
        if getattr(self, 'finite_only', False):
            # lookup failures of the virtual root (and, in prefix_gate, of the erasures) depend only on the
            # largest fragments' classes and the radius; they are counted once, by the rank-2 grid and the
            # rank-1 lookup tail, and are left out here
            certain = np.zeros(n, bool)
            cfrac = np.zeros(n)
        bn = min(max(int(np.searchsorted(edges, hi[-1] * t, side='left') - 1), 0), gates.shape[1] - 1)
        lower = np.zeros(n, bool)
        if getattr(self, 'skip_lower', False):
            # Cells where every configuration of the box already fails at a lower rank m < n: the virtual
            # root's tails at the bin of w_m are at least lo_1 + ... + lo_m, and its gate there is at most
            # the gate at the lowest bin that I_m meets (rows are nonincreasing in the bin), for every
            # layer, class and radial bin the box and cell allow. Such a configuration lies in the rank-m
            # ledger's box of its top m marks and in that box's mask, so it is counted there and is left
            # out here (the ranks are added, and a configuration need only be counted once).
            for m in range(1, len(lo)):
                bl = min(max(int(np.searchsorted(edges, lo[m - 1] * t, side='right') - 1), 0), gates.shape[1] - 1)
                allfail = np.ones(n, bool)
                for ok, key in keys:
                    allfail &= ok & (sum(lo[:m]) * t > gates[key, bl])
                lower |= allfail
            self.skipped_cells = getattr(self, 'skipped_cells', 0) + int(lower.sum())
        if not getattr(self, 'fractional', False):
            theta, theta_c = thetas(bn)
            fail = certain | ystash | (((sum(hi) * t > theta) | (sum(hi[1:]) * t > theta_c)) & ~lower)
            return fail.astype(float), lay1
        # split the smallest mark's interval at the gate-bin edges: on each piece the gate bin of that
        # mark is fixed (for marks sharing its interval the smallest one's bin is lower, and its gate
        # higher, so this stays a superset)
        b0 = min(max(int(np.searchsorted(edges, lo[-1] * t, side='right') - 1), 0), gates.shape[1] - 1)
        frac = np.zeros(n)
        width = hi[-1] - lo[-1]
        for b in range(b0, bn + 1):
            a_ = max(lo[-1], edges[b] / t) if b > b0 else lo[-1]
            c_ = min(hi[-1], edges[b + 1] / t) if b < bn else hi[-1]
            if c_ <= a_:
                continue
            theta, theta_c = thetas(b)
            lo_b = list(lo[:-1]) + [a_]; hi_b = list(hi[:-1]) + [c_]
            part = box_tail([x * t for x in lo_b], [x * t for x in hi_b], theta)
            if len(lo) >= 2:
                part = part + box_tail([x * t for x in lo_b[1:]], [x * t for x in hi_b[1:]], theta_c)
            frac += np.minimum(part, 1.0) * (c_ - a_) / width
        frac = np.where(lower, 0.0, frac)
        return np.where(ystash, 1.0, np.minimum(frac + cfrac, 1.0)), lay1

    def prefix_gate(self, ci, lay, b, finite=False, store=True, sharp=False):
        """The least gate at bin b that a root with k - 1 coordinates, largest fragment in class ci and
        layer lay, can meet at any cell sum r' <= r (minimum over the radial bins its total can occupy;
        -inf where its class lookup can fail; +inf where untested); as a function of r. An erasure of a
        coordinate not carrying the largest fragment keeps class and layer, lowers the tails and moves
        the root to r - j_e <= r, so 'W > prefix_gate' at the virtual root's cell covers every such
        erasure failing at a bin >= b (gate rows are nonincreasing in the bin). Integer ticks.
        With finite=True lookup failures are left out (+inf instead of -inf): they are counted elsewhere.
        With sharp=True the minimum is of gate(r') + (r - r') h (see below)."""
        key_ = (ci, lay, b, finite, sharp)
        assert finite or not sharp
        cache = self.__dict__.setdefault('_pg_cache', {})
        if key_ in cache:
            return cache[key_]
        if len(cache) > 400:
            cache.clear()
        G, h, n = self.G, self.h, self.n
        ls, gates, Rclass = G['ls'], G['gates'], G['R']
        radial_step = int(G['radial_step']); mrad = GATE_MINRAD // radial_step
        big = float(np.iinfo(np.int64).max // 4)
        if lay >= self.z['group_table'].shape[0]:
            out = np.full(n, big)
        elif ci >= ls.shape[0]:
            grp = self.z['group_table'][lay].astype(int)
            out = np.full(n, big) if finite else np.minimum.accumulate(np.where(grp >= 0, -big, big))
        else:
            grp = self.z['group_table'][lay].astype(int)
            tested = grp >= 0
            R = np.arange(n)
            ylo = np.floor(R * h * self.ticks); yhi = np.ceil((R + self.k - 1) * h * self.ticks)
            g = np.full(n, big)
            for Y in (ylo, yhi):
                rc = np.maximum(mrad, np.ceil(Y / radial_step).astype(int)) - mrad
                ins = tested & (rc < ls.shape[2])
                key = np.full(n, -1)
                key[ins] = ls[ci, grp[ins], rc[ins]]
                rad = np.full(n, big)
                rad[ins] = Rclass[ci, grp[ins]]
                gv = gates[np.maximum(key, 0), b].astype(float)
                # a root whose largest possible total does not exceed the gate cannot fail there: its tails
                # at any bin are at most its total. Such cells are left out of the prefix minimum.
                gv[gv >= yhi] = big
                # A cell crossing the radius can contain both a lookup
                # failure and a valid lookup whose tail exceeds its gate.
                # The finite pass retains the latter until the entire
                # cell lies beyond the radius.
                outside = (ylo > rad) if finite else (yhi > rad)
                gv[tested & ((key < 0) | outside)] = big if finite else -big
                gv[~tested] = big
                g = np.minimum(g, gv)
            if sharp:
                # the erased coordinate's own total: a root at cell r' comes from a full cell r by erasing a
                # coordinate of at least (r - r') h, and every fragment of that coordinate at or above the
                # edge leaves the tails. So the threshold for the full configuration's
                # (total - small fragments of the other coordinates) is gate(r') + (r - r') h, not gate(r').
                step_ = R * h * self.ticks
                out = np.where(g < big / 2, g - step_, big)
                out = np.minimum.accumulate(out)
                out = np.where(out < big / 2, out + step_, big)
            else:
                out = np.minimum.accumulate(g)
        if store:
            cache[key_] = out
        return out

    def bin_value(self, ws, dws, env=False, cover=False):
        """Midpoint form (env False) or envelope form (env True): marks w_m in [ws_m - dws_m / 2,
        ws_m + dws_m / 2), with the mask of mask_env, Mecke factors dw / w at the lower ends, each
        marked coordinate's rest density at its largest value over the bin (rho is nonincreasing),
        and the rest capped at the top of I_n (rho(. / cap) increases with cap). For the majority-signed
        profile every factor of the integrand is then at least its true value on the bin, provided
        env_straddles is False. Floating."""
        n, h = self.n, self.h
        ws = tuple(ws); dws = list(dws)
        lo = tuple(w - d / 2 for w, d in zip(ws, dws)); hi = tuple(w + d / 2 for w, d in zip(ws, dws))
        maskR, lay1 = self.mask_env(lo, hi, cover) if env else self.mask_n(ws)
        if env and getattr(self, 'feasible_cut', False):
            # a configuration of the box at cell sum R has total below (R + k) h and at least the sum of
            # its marks: cells with (R + k) h <= sum(lo) hold none of them (exact; the transforms would
            # return rounding noise there)
            maskR = np.where((np.arange(n) + self.k) * h > sum(lo), maskR, 0.0)
        if not maskR.any() or lay1 >= len(self.caps):
            return 0.0, {}
        if env and getattr(self, 'feasible_cut', False) and not self.amplitude_alive(maskR, ws[0]):
            return 0.0, {}                                    # the profile vanishes on every masked cell
        if getattr(self, 'fft_cache_on', False):
            self._fcache = {}                                 # per bin: ids of this bin's arrays stay alive in it
        cr = max(1, int(np.ceil(hi[-1] / h))) if env else max(1, int(ws[-1] / h))
        if getattr(self, 'rest_cap', None) is not None:
            # every other fragment is below a fixed cap (configurations whose second mark is below it)
            assert self.rest_cap <= lo[-1] + 1e-12
            cr = max(1, int(np.ceil(self.rest_cap / h)))
        Drest = self.D(cr)
        j = np.arange(n)
        om = h * self.g ** 2 * Drest
        if env:
            fac = lambda block: float(np.prod([dws[i] / lo[i] for i in block]))
            def shift(block):
                Wlo = sum(lo[i] for i in block); Whi = sum(hi[i] for i in block)
                if getattr(self, 'tilt', None) is None:
                    return np.where(j + 1 > Wlo / h, interp_rho(Drest, np.maximum(j - Whi / h, 0.0)), 0.0)
                # a tilted table is not monotone: supremum over the rest indices the box allows,
                # k in [j - Whi / h, j + 1 - Wlo / h]
                from scipy.ndimage import maximum_filter1d
                a_ = np.floor(j - Whi / h).astype(np.int64); b_ = np.ceil(j + 1 - Wlo / h).astype(np.int64)
                w_ = int((b_ - a_).max()) + 3
                M_ = maximum_filter1d(Drest, size=w_, mode='constant', cval=0.0)     # centred window
                c_ = np.clip((a_ + b_) // 2, 0, n - 1)
                return np.where(b_ >= 0, M_[c_], 0.0)
        else:
            fac = lambda block: float(np.prod([dws[i] / ws[i] for i in block]))
            shift = lambda block: shifted_rho(Drest, j, sum(ws[i] for i in block), h)
        site_cache = {}
        def site_of(block):
            block = tuple(sorted(block))
            if block not in site_cache:
                site_cache[block] = h * self.g ** 2 * shift(block) * fac(block)
            return site_cache[block]
        def insw(block):
            if not block:
                return Drest.copy()
            return shift(block) * fac(block)
        if getattr(self, '_mom_cap', None) != cr:
            self._mom = Moments(om, self.x, n, self.L, beta=self.beta, h=h)
            self._mom_cap = cr
        mom = self._mom
        if getattr(self, 'mass_mode', None):
            return self._mass_value(ws, maskR, om, site_of, mom), {}
        un = mom.untilt(self.k - 1)
        FA = self.combined_amplitude(maskR, ws[0])
        cache = {}
        idx = tuple(range(len(ws)))
        parts = {}
        total = 0.0
        from itertools import combinations
        for size in range(len(ws) + 1):
            for carried in combinations(idx, size):
                rows_phi = self.rows_gf(FA, insw(carried))
                Rset = tuple(i for i in idx if i not in carried)
                for face in ('core', 'a', 'b'):
                    if Rset:
                        lay = int(np.searchsorted(self.caps, max(ws[i] for i in Rset) / h))
                        if lay >= len(self.caps):
                            # the sliver between the last layer cap and zeta (about 2e-6 wide) has no
                            # layer table; it is left out here and listed as an open item
                            self.sliver_skipped = getattr(self, 'sliver_skipped', 0) + 1
                            continue
                        dens = self.face_density_gf(face, rows_phi, Rset, lay, om, site_of, mom, un, cache)
                        val = float(np.sum(self.field_pos[lay] * dens))
                    else:
                        site = lambda *b_: site_of(b_)
                        val = self.face_cross_n(face, rows_phi, (), None, om, site, mom, un, cr)
                    parts[(size, face)] = parts.get((size, face), 0.0) + val
                    total += val
        return total, parts


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest='step', required=True)
    p = sub.add_parser('check')
    p.add_argument('trial')
    p.add_argument('--layers', default=None, help='comma-separated layer indices (default: all)')
    p = sub.add_parser('rows')
    p.add_argument('trial')
    p = sub.add_parser('rank2')
    p.add_argument('trial')
    p.add_argument('--gates', required=True)
    p.add_argument('--kappa', type=float, required=True, help='rho / I(F), from the step check')
    p.add_argument('--w1', type=float, nargs=3, required=True, help='first, last, step of the larger mark')
    p.add_argument('--w2', type=float, nargs=3, required=True, help='first, last, step of the smaller mark')
    p.add_argument('--carried', default='0,1,2', help='which numbers of marks on the erased coordinate to include')
    p.add_argument('--nomask', action='store_true', help='diagnostic: no gate mask (every tested full cell counts)')
    p.add_argument('--mass', action='store_true', help='diagnostic: the F^2 mass of the bin instead of the cross term')
    p = sub.add_parser('regress', help='checks of the paths that produce the cross term')
    p.add_argument('trial')
    p.add_argument('--gates', required=True)
    p.add_argument('--layers', default='3,20', help='layers for the rows check')
    p.add_argument('--rest-cap', type=float, default=0.25, help='inserted cap for the rows check (normalised units)')
    p = sub.add_parser('rankn')
    p.add_argument('trial')
    p.add_argument('--gates', required=True)
    p.add_argument('--kappa', type=float, required=True)
    p.add_argument('--n', type=int, default=3)
    p.add_argument('--lo', type=float, default=0.10, help='smallest mark considered')
    p.add_argument('--hi', type=float, default=0.66, help='largest mark considered')
    p.add_argument('--step', dest='bin', type=float, default=0.03)
    p.add_argument('--smallest', type=float, nargs=2, default=None, help='restrict the smallest mark to this bin range')
    p.add_argument('--diagonal-only', action='store_true', help='only bins shared by two or more marks')
    p.add_argument('--engine', default='gf', choices=['gf', 'placements'], help='gf: subset generating function (fast)')
    p.add_argument('--compare', action='store_true', help='evaluate each bin with both engines and print both')
    p.add_argument('--bins', default=None, help='explicit bins: semicolon-separated comma lists of lower edges')
    p.add_argument('--part', type=int, nargs=2, default=[0, 1], help='this process takes bins with index %% N == i')
    p.add_argument('--resume', nargs='*', default=[], help='earlier logs: bins already there are reprinted, not recomputed')
    p.add_argument('--envelope', action='store_true', help='failure-favourable form of each bin (a floating majorant)')
    p.add_argument('--cover', action='store_true', help='with --envelope: mask covering every failing erasure, not only Phi_0')
    p.add_argument('--maskscan', action='store_true', help='with --envelope: only compare the covering mask with the Phi_0 envelope')
    p.add_argument('--w1max', type=float, default=None, help='with --envelope: drop configurations whose largest mark is at least this')
    p.add_argument('--w1min', type=float, default=None, help='with --envelope: drop configurations whose largest mark is below this')
    p.add_argument('--unmasked', action='store_true', help='with --envelope: count every configuration of each box (tail majorant)')
    p.add_argument('--fractional', action='store_true', help='with --envelope: volume-fraction mask instead of 0/1 (still a majorant)')
    p.add_argument('--refine', type=int, default=1, help='with --bins: split each bin into this many sub-bins per mark')
    p.add_argument('--refine-last', type=int, default=None, help='with --envelope: cut the smallest mark\'s interval (and those sharing it) into this many parts')
    p.add_argument('--finite-only', action='store_true', help='with --envelope: leave out lookup failures (counted by the rank-2 grid and the rank-1 lookup tail)')
    p.add_argument('--chernoff', type=float, nargs=5, default=None, metavar=('BLO', 'BTOP', 'MU', 'THETA', 'N0'),
                   help='with --envelope --n 1: Chernoff bound for failures at gate bins BLO..BTOP; fragments below edge(BLO) '
                        'tilted by exp(-MU x), those at or above it by THETA, with the factor THETA^-N0')
    p.add_argument('--sharp', type=float, default=None, metavar='SIGMA',
                   help='with --chernoff: cap each coordinate\'s exponential weight at SIGMA (normalised units) and, with --cover, use the sharp cover (erasures charged with their own total)')
    p.add_argument('--ymin', type=float, default=None,
                   help='with --envelope: count every configuration of each box that has room for a further fragment of at least this size (covers all higher ranks of the box)')
    p.add_argument('--pair-covered', type=float, default=None,
                   help='skip bins whose two largest marks (lower edges on the 0.05 grid) sum to at least this: covered by a --ymin pass')
    p.add_argument('--pair-min', type=float, default=None,
                   help='only bins whose two largest marks (lower edges on the 0.05 grid) sum to at least this')
    p.add_argument('--feasible', action='store_true',
                   help='with --envelope: leave out cells whose total cannot hold the marks, and boxes on which the profile vanishes (exact)')
    p.add_argument('--skip-lower', action='store_true',
                   help='with --envelope: leave out cells where the whole box already fails at a lower rank (counted by that rank\'s ledger)')
    p.add_argument('--bin0', action='store_true',
                   help='with --envelope: only failures at gate bin 0 (the root\'s total against that gate), as a cell fraction')
    p.add_argument('--class-split', action='store_true', help='with --envelope: split the largest mark at the fine class edges (sharper mask)')
    p.add_argument('--fft-cache', action='store_true', help='keep transforms of repeated operands within a bin (same values, faster)')
    p.add_argument('--no-prefilter', action='store_true', help='keep bins whose marks cannot reach the least tilted line (they may hold lookup failures)')
    p.add_argument('--ymask', default=None, choices=['only', 'or'], help='with --envelope: total-based mask for failures at gate bins at or below the smallest mark (or the rest cap)')
    p.add_argument('--rest-cap', type=float, default=None, help='with --envelope: cap every unmarked fragment at this value (normalised units) instead of the smallest mark')
    p.add_argument('--mass', default=None, choices=['phi', 'plain'],
                   help='the F^2 mass of each bin on its mask instead of the cross term, in units of I; phi: weighted by the fibre factor of the pair bound')
    p.add_argument('--certain-only', action='store_true', help='with --envelope: only lookup failures of the virtual root (the rank-1 lookup tail)')
    args = ap.parse_args()
    if args.step == 'regress':
        z, m = load(args.trial)
        G = dict(np.load(args.gates, allow_pickle=False))
        Rk = RankGF(z, m, G)
        n, h = Rk.n, Rk.h
        t0 = time.time()
        # (c) rows of the generating-function engine against erased_rows, same cc-independent kernel
        c_ins = max(1, int(args.rest_cap / h))
        Dc = Rk.D(c_ins)
        kern = lambda cc, e, shape: Rk.g * Dc * Rk.x ** e * (1.0 if shape is None else Rk.psi[shape])
        Wc_ref, Wa_ref, Wb_ref = erased_rows(z, m, mask=None, kernel=kern)
        rows_rep = {}
        for l in [int(v) for v in args.layers.split(',')]:
            FA = Rk.combined_amplitude(np.ones(n), float(Rk.caps[l]) * h)
            Wc, Wa, Wb = Rk.rows_gf(FA, Dc)
            rows_rep[l] = {name: float(np.abs(mine - ref).max() / max(np.abs(ref).max(), 1e-300))
                           for name, mine, ref in (('core', Wc, Wc_ref[l]), ('a', Wa, Wa_ref[l]), ('b', Wb, Wb_ref[l]))}
        print(json.dumps(dict(event='ROWS_CHECK', max_rel_diff=rows_rep, seconds=round(time.time() - t0))), flush=True)
        # (a) the root-without-marks path with the evaluator's own tables against stage 1
        out, field, _ = face_totals(args.trial, verbose=False)
        ref = sum(float((out[f] * np.maximum(field, 0)).sum()) for f in out)
        om, mom = Rk._layer_measure(int(Rk.caps[-1]))
        un = mom.untilt(Rk.k - 1)
        rbl = lambda l: (Rk.Wc[l], Rk.Wa[l], Rk.Wb[l])
        mine = sum(Rk.face_cross_n(face, None, (), None, om, None, mom, un, int(Rk.caps[-1]), rows_by_layer=rbl)
                   for face in ('core', 'a', 'b'))
        print(json.dumps(dict(event='LAYER_PATH_CHECK', stage1_positive_priced_raw=ref, no_mark_path_raw=mine,
                              rel_diff=abs(mine - ref) / abs(ref), seconds=round(time.time() - t0))), flush=True)
        return
    if args.step == 'rankn':
        z, m = load(args.trial)
        G = dict(np.load(args.gates, allow_pickle=False))
        Rk = RankGF(z, m, G) if args.engine == 'gf' or args.compare else RankN(z, m, G)
        Rk.unmasked = args.unmasked
        Rk.fractional = args.fractional
        Rk.finite_only = args.finite_only
        Rk.certain_only = args.certain_only
        Rk.ymask = args.ymask
        Rk.fft_cache_on = args.fft_cache
        Rk.class_split = args.class_split
        Rk.mass_mode = args.mass
        Rk.bin0 = args.bin0
        Rk.skip_lower = args.skip_lower
        Rk.ymin = args.ymin
        Rk.feasible_cut = args.feasible
        if args.mass:
            assert args.engine == 'gf' and not args.compare
        if args.chernoff is not None:
            b_lo, b_top, mu_, th_, n0_ = args.chernoff
            edges_g = G['edges']
            u_cells = int(np.floor(float(edges_g[int(b_lo)]) / Rk.ticks / Rk.h))    # fragments below this are tilted down
            Rk.tilt = (u_cells, float(np.exp(-mu_ * Rk.h)), float(th_))
            Rk.chernoff = (int(b_lo), int(b_top), float(mu_), float(n0_))
            if args.sharp is not None:
                Rk.tilt_cap = int(np.floor(args.sharp / Rk.h))
            print(json.dumps(dict(event='CHERNOFF', b_lo=int(b_lo), b_top=int(b_top), edge_lo=float(edges_g[int(b_lo)] / Rk.ticks),
                                  edge_top=float(edges_g[int(b_top)] / Rk.ticks), mu=mu_, theta=th_, n0=n0_, sharp=args.sharp)), flush=True)
        Rk.rest_cap = args.rest_cap
        t0 = time.time()
        edges = np.round(np.arange(args.lo, args.hi, args.bin), 10)
        if args.bins is not None:
            from itertools import product as _prod
            from math import factorial as _fact
            sub = args.bin / args.refine
            bins_total = 0.0
            for spec in args.bins.split(';'):
                parent = sorted([float(v) for v in spec.split(',')], reverse=True)
                boxes = sorted({tuple(sorted((round(w + i * sub, 6) for w, i in zip(parent, ii)), reverse=True))
                                for ii in _prod(range(args.refine), repeat=len(parent))}, reverse=True)
                tot = 0.0; tparts = {}; t1 = time.time(); straddle = False
                if args.envelope:
                    if args.maskscan:
                        print(json.dumps(dict(event='MASKSCAN', marks=parent, step=args.bin, refine=args.refine,
                                              **Rk.mask_scan(parent, args.bin, args.refine, args.w1max))), flush=True)
                        continue
                    c1, p1 = Rk.env_box_value(parent, args.bin, args.refine, cover=args.cover, w1max=args.w1max,
                                              w1min=args.w1min, refine_last=args.refine_last)
                    boxes = []
                    tot = c1
                    tparts = {'%d%s' % k_: v * args.kappa for k_, v in p1.items()}
                for ws_lo in boxes:
                    ws = [w + sub / 2 for w in ws_lo]
                    weight = 1.0 / float(np.prod([_fact(c_) for c_ in Counter(ws_lo).values()]))
                    if args.envelope:
                        straddle |= Rk.env_straddles(ws_lo, [w + sub for w in ws_lo])
                    c1, p1 = Rk.bin_value(ws, [sub] * len(ws), env=args.envelope, cover=args.cover)
                    tot += c1 * weight
                    for k_, v in p1.items():
                        tparts['%d%s' % k_] = tparts.get('%d%s' % k_, 0.0) + v * weight * args.kappa
                row = dict(event='BIN', marks=parent, step=args.bin, refine=args.refine, envelope=args.envelope, cover=args.cover,
                           fractional=args.fractional, refine_last=args.refine_last, finite_only=args.finite_only,
                           class_split=args.class_split, w1min=args.w1min, w1max=args.w1max, value=tot * args.kappa,
                           gf=tot * args.kappa, parts_gf=tparts, seconds_gf=round(time.time() - t1))
                bins_total += tot * args.kappa
                if args.mass:
                    row['mass'] = args.mass
                if args.chernoff is not None:
                    row.update(chernoff=args.chernoff, sharp=args.sharp)
                if args.bin0:
                    row['bin0'] = True
                if args.skip_lower:
                    row['skip_lower'] = True
                if args.ymin is not None or args.feasible:
                    row.update(ymin=args.ymin, feasible=args.feasible)
                if args.envelope:
                    row['split_at_breakpoints'] = True
                if args.compare:
                    ws = [w + args.bin / 2 for w in parent]
                    weight = 1.0 / float(np.prod([_fact(c_) for c_ in Counter(parent).values()]))
                    t1 = time.time()
                    c2, p2 = RankN.contribution_n(Rk, ws, [args.bin] * len(ws))
                    row.update(placements=c2 * weight * args.kappa, seconds_placements=round(time.time() - t1),
                               rel_diff=abs(tot - c2 * weight) / max(abs(c2 * weight), 1e-300))
                print(json.dumps(row), flush=True)
            print(json.dumps(dict(event='RANKN', n=args.n, total=bins_total, bins=args.bins, mass=args.mass,
                                  seconds=round(time.time() - t0))), flush=True)
            return
        grand = 0.0
        from itertools import combinations
        from itertools import combinations_with_replacement
        total_cap = m['n'] * m['h']
        done_bins = {}
        for fn in args.resume:
            try:
                for line in open(fn):
                    if line.startswith('{') and '"BIN"' in line:
                        r_ = json.loads(line)
                        done_bins[tuple(round(v, 4) for v in r_['marks'])] = r_
            except FileNotFoundError:
                pass
        for ci_, combo in enumerate(combinations_with_replacement(range(len(edges)), args.n)):
            if ci_ % args.part[1] != args.part[0]:
                continue
            if sum(edges[i] for i in combo) >= total_cap or max(edges[i] for i in combo) >= m['zeta']:
                continue                                       # no configuration of the support has these marks
            ws_lo = [edges[i] for i in sorted(combo, reverse=True)]
            reps = __import__('collections').Counter(combo)
            weight = 1.0 / float(np.prod([__import__('math').factorial(c_) for c_ in reps.values()]))
            if args.diagonal_only and max(reps.values()) == 1:
                continue
            if (args.pair_covered is not None or args.pair_min is not None) and len(ws_lo) >= 2:
                # the two largest marks' lower edges, rounded down to the 0.05 grid from 0.10 on which the
                # covering pass (--ymin with --pair-min) is run: a bin whose rounded sum reaches the level
                # lies inside that pass's bins, which count all its configurations with a third fragment
                g5 = lambda v: 0.10 + 0.05 * np.floor((v - 0.10) / 0.05 + 1e-9)
                psum = g5(ws_lo[0]) + g5(ws_lo[1])
                if args.pair_covered is not None and psum >= args.pair_covered - 1e-9:
                    continue
                if args.pair_min is not None and psum < args.pair_min - 1e-9:
                    continue
            if args.smallest is not None and not (args.smallest[0] <= ws_lo[-1] < args.smallest[1]):
                continue
            # necessary for any failure under the tilted line: sum of marks + smallest > least level
            if sum(w + args.bin for w in ws_lo) + ws_lo[-1] + args.bin < 0.80 and not (args.unmasked or args.certain_only or args.ymask or args.no_prefilter or args.chernoff or args.bin0 or args.ymin is not None):
                continue
            ws = [w + args.bin / 2 for w in ws_lo]
            key_ = tuple(round(float(v), 4) for v in ws_lo)
            if key_ in done_bins:
                r_ = done_bins[key_]
                grand += r_['value'] / args.kappa
                print(json.dumps(dict(r_, cumulative=grand * args.kappa, resumed=True)), flush=True)
                continue
            if args.envelope and args.engine != 'gf':
                raise SystemExit('--envelope needs the gf engine')
            if args.envelope and args.maskscan:
                print(json.dumps(dict(event='MASKSCAN', marks=[round(float(w), 4) for w in ws_lo],
                                      **Rk.mask_scan(ws_lo, args.bin, args.refine, args.w1max))), flush=True)
                continue
            if args.envelope:
                if args.w1max is not None and ws_lo[0] >= args.w1max - 1e-12:
                    continue
                if args.w1min is not None and ws_lo[0] + args.bin <= args.w1min + 1e-12:
                    continue
                c, parts = Rk.env_box_value(ws_lo, args.bin, args.refine, cover=args.cover, w1max=args.w1max, w1min=args.w1min,
                                            refine_last=args.refine_last)
                weight = 1.0                                   # the sub-boxes carry their own multiplicities
            else:
                c, parts = Rk.bin_value(ws, [args.bin] * args.n) if args.engine == 'gf' else Rk.contribution_n(ws, [args.bin] * args.n)
            c *= weight
            parts = {k_: v * weight for k_, v in parts.items()}
            grand += c
            row = dict(event='BIN', marks=[round(float(w), 4) for w in ws_lo], value=c * args.kappa,
                       parts={'%d%s' % k_: v * args.kappa for k_, v in parts.items()},
                       cumulative=grand * args.kappa, seconds=round(time.time() - t0))
            if args.envelope:
                row.update(envelope=True, cover=args.cover, refine=args.refine, w1max=args.w1max, w1min=args.w1min, unmasked=args.unmasked,
                           fractional=args.fractional, finite_only=args.finite_only, certain_only=args.certain_only,
                           ymask=args.ymask, rest_cap=args.rest_cap, class_split=args.class_split, chernoff=args.chernoff, sharp=args.sharp, bin0=args.bin0, skip_lower=args.skip_lower, ymin=args.ymin, feasible=args.feasible,
                           refine_last=args.refine_last)
            if args.mass:
                row['mass'] = args.mass
            print(json.dumps(row), flush=True)
        print(json.dumps(dict(event='RANKN', n=args.n, total=grand * args.kappa, mass=args.mass, seconds=round(time.time() - t0))), flush=True)
        return
    if args.step == 'rank2':
        z, m = load(args.trial)
        G = dict(np.load(args.gates, allow_pickle=False))
        Rk = Rank2(z, m, G)
        Rk.carried = args.carried.split(',')
        Rk.nomask = args.nomask
        t0 = time.time()
        grand = 0.0
        if args.w1[0] < 0:
            val = Rk.mass0()
            print(json.dumps(dict(event='MASS0', raw=val, I_from_kappa=float(m['rho']) / args.kappa)), flush=True)
            return
        if args.mass:
            w1, w2 = args.w1[0], args.w2[0]
            val = Rk.mass2(w1 + args.w1[2] / 2, w2 + args.w2[2] / 2, args.w1[2], args.w2[2])
            print(json.dumps(dict(event='MASS', w1=w1, w2=w2, value=val * args.kappa / float(m['rho']),
                                  parts=[dict(pp, value=pp['value'] * args.kappa / float(m['rho'])) for pp in Rk.mass2_parts])), flush=True)
            return
        for w2 in np.arange(args.w2[0], args.w2[1], args.w2[2]):
            for w1 in np.arange(max(w2 + args.w1[2], args.w1[0]), args.w1[1], args.w1[2]):
                c, parts = Rk.contribution(w1 + args.w1[2] / 2, w2 + args.w2[2] / 2, args.w1[2], args.w2[2])
                grand += c
                print(json.dumps(dict(event='BIN', w1=round(float(w1), 4), w2=round(float(w2), 4), value=c * args.kappa,
                                      parts={'%d%s' % k_: v * args.kappa for k_, v in parts.items()},
                                      cumulative=grand * args.kappa, seconds=round(time.time() - t0))), flush=True)
        print(json.dumps(dict(event='RANK2', total=grand * args.kappa, seconds=round(time.time() - t0))), flush=True)
        return
    if args.step == 'rows':
        z, m = load(args.trial)
        t0 = time.time()
        Wc, Wa, Wb = erased_rows(z, m)
        rep_ = {}
        for name, mine, ref in (('core', Wc, z['W_core']), ('a', Wa, z['W_a']), ('b', Wb, z['W_b'])):
            scale = np.abs(ref).max()
            diff = np.abs(mine - ref).max() / scale
            ratio = float(np.sum(mine * ref) / np.sum(ref * ref))
            rep_[name] = dict(max_rel_diff=float(diff), projection_ratio=ratio, ref_max=float(scale))
        print(json.dumps(dict(event='ROWS', comparison=rep_, seconds=round(time.time() - t0))), flush=True)
        return
    layers = None if args.layers is None else [int(v) for v in args.layers.split(',')]
    out, field, m = face_totals(args.trial, layers)
    t = m['targets']
    tot = {f: float(out[f].sum()) for f in out}
    priced = sum(float((out[f] * field).sum()) for f in out)
    kappa = t['faces']['core'] / tot['core']
    print(json.dumps(dict(event='CHECK', raw_totals=tot, raw_priced=priced, kappa=kappa,
                          scaled=dict(core=tot['core'] * kappa, a=tot['a'] * kappa, b=tot['b'] * kappa, priced=priced * kappa),
                          targets=dict(faces=t['faces'], priced=t['priced_one_prime']))), flush=True)


if __name__ == '__main__':
    main()
