"""Bound the complete H1 error budget, including pairs without a local estimate."""
import argparse
from fractions import Fraction as Q
import json
from pathlib import Path

import numpy as np

from h1_graded_coverage import GLOBAL, provenance
from h1_combined_margin import prefix_hash
from h1_graded_cross_block import native_layout
from h1_graded_outer_cross import operator_caps
from h1_outer_staircase_audit import BASE, BANDS, PATCH, SECOND_PATCH, OUTPUT as AUDIT
from h1_raw_diagonal_bound import (CERT, FIBRES, FIT, MINORANTS, NORM, PRICES, TABLE, UNIT,
                                   ceil, digest, geom, mixture_energies, read)
from h1_strip_free_integral_budget import PRODUCER, affine_majorant
from h1_strip_free_prices import FORMS, FROZEN
from h1_sunrise_boundary import geometry


SCORE = Path('h1_combined_score_native_interval.json')
GRID = 10**12


def upper(value):
    return Q(ceil(value*GRID), GRID)


def remaining_entries(cert, radii, ledger):
    risk = radii[:, None] + radii[None, :] > UNIT//2
    affine = np.asarray(cert['affine'][:3], dtype=object)
    assert all(np.array_equal(a, a.T) for a in affine)
    mask = risk & np.any(affine != 0, axis=0)
    def remove(left, right):
        mask[np.ix_(left, right)] = False
        mask[np.ix_(right, left)] = False
    base = read(BASE)
    paths = [BASE, AUDIT, *(Path(b['receipt']) for b in base['blocks']),
             *BANDS, PATCH, SECOND_PATCH, *(Path(b['receipt']) for b in ledger['extra'])]
    square = read(paths[2])['selected_groups']
    remove(square, square)
    for path in [*(Path(b['receipt']) for b in base['blocks'][1:]), *BANDS, PATCH, SECOND_PATCH]:
        block = read(path)
        remove(block['left_groups'], block['right_groups'])
    for block in ledger['extra']:
        row = read(Path(block['receipt']))
        remove(row['left'], row['right'])
    assert mask.sum() == ledger['unresolved_active_ordered_pairs']
    return affine*mask, paths


def sector_charges(cert, radii, affine, prices, cover):
    reference = mixture_energies(FORMS, FROZEN)
    energies = [sum(reference[g, 0]) for g in cert['groups']]
    assert min(energies) > 0
    data = next(row for row in read(MINORANTS)['rows'] if Q(row['theta']) == Q('.5291'))
    means = [Q(1), Q(str(read(TABLE)['kappa_upper'])),
             Q(data['five_mass']['upper']) + Q(cert['arithmetic']['three_error_mass'][1])]
    # Each cap is nondecreasing with the radius. Share its construction over narrow bands.
    buckets = radii//50000
    caps = {b: operator_caps(int(max(radii[buckets == b])), data, cover) for b in np.unique(buckets)}
    left, sharp, higher = affine
    cost = [Q(0) for _ in energies]
    for channel, matrix in enumerate((left+sharp+higher, -sharp-higher, -higher)):
        for i, row_sum in enumerate(np.abs(matrix).sum(axis=1)):
            actual = int(row_sum)*caps[buckets[i]][channel]
            diagonal = abs(int(matrix[i,i]))*means[channel]
            cost[i] += (actual+diagonal)/(prices['scale']*energies[i])
    sectors = [Q(0) for _ in prices['sector_prices']]
    for group, allowance in zip(cert['groups'], cost):
        for i in group:
            sectors[i] = upper(allowance)
    return sectors


def bounds(score, through, norm, prices, loss, weighted):
    caps = score['caps']
    index = np.arange(norm['intervals']-norm['dimension'])
    table, original, layout = geometry(TABLE)
    with np.load(original['cell_bins'], allow_pickle=False) as arc:
        strata = np.unique(arc['cells'][:,1])
    assert score['dimension'] == norm['dimension'] == 38
    assert len(loss) == len(table['codes'])
    completed = [r['cap'] for r in score['layers']]
    assert completed == caps[:len(completed)] and through in completed
    layers = score['layers'][:caps.index(through)+1]
    dlo, dhi = (Q(norm['normalized_norm'][name]) for name in ('lower','upper'))
    erasure = Q(read(GLOBAL)['erasure_constant_upper'])
    h = Q(norm['step'])
    assert erasure >= geom.RS*Q(norm['S'])*38*Q('3.638')/37
    assert geom.RS == Q(2624989,10000000)
    products = prices['sector_prices']
    assert all(slope <= 0 and third == 0 for _,slope,third in products)
    def price(i, j):
        a, b, _ = products[i]
        denom = Q(1,2)-geom.RS*h*(int(j)+37)-Q('.0001')
        assert denom > 0
        return (a + b/denom)/prices['scale']
    shapes = {}
    paid, income = Q(0), Q(0)
    unpaid_loss = unpaid_negative = Q(0)
    highest_loss = highest_negative = Q(0)
    for k, cap in enumerate(caps):
        stratum = strata[np.searchsorted(strata, cap)]
        if stratum not in shapes:
            ids = layout(stratum, index)
            present = np.unique(ids)
            lo = np.full(len(loss),len(index),int)
            hi = np.full(len(loss),-1,int)
            np.minimum.at(lo,ids,index)
            np.maximum.at(hi,ids,index)
            charges = [loss[i] for i in present]
            maxima = [price(i,lo[i]) for i in present]
            negative = max([Q(0), *(-price(i,hi[i]) for i in present)])
            shapes[stratum] = charges, maxima, max(charges), negative
        charges, maxima, worst, negative = shapes[stratum]
        if k < len(layers):
            energy = Q(layers[k]['unweighted_contribution']['upper'])
            numerator = Q(layers[k]['priced_contribution']['lower'])
            a, b = affine_majorant(charges, maxima, energy, numerator)
            paid += min(worst*energy, (a+b)*energy-b*numerator)
            income += numerator
        else:
            mass = sum(Q(r['contribution']['upper']) for r in norm['layers'] if r['cap'] > caps[k-1])
            tail = erasure*mass/dlo
            unpaid_loss += max(0,worst-highest_loss)*tail
            unpaid_negative += max(0,negative-highest_negative)*tail
            highest_loss = max(highest_loss,worst)
            highest_negative = max(highest_negative,negative)
    assert paid >= 0
    total = paid/dlo+unpaid_loss
    if weighted is not None:
        unpaid_negative = min(unpaid_negative, Q(weighted['negative_tail_upper']))
        total = min(total, Q(weighted['generic_upper']))
    lower = min(income/dlo,income/dhi)-unpaid_negative
    if through == caps[-1]:
        assert score['status'] == 'CONTINUOUS_CAP_SCORE_ENCLOSED'
        total = min(total,sum(x*Q(row[0]['upper']) for x,row in zip(loss,score['normalized_sector_energies'],strict=True)))
        lower = max(lower,Q(score['cap_quotient']['lower']))
    return dict(through=through, layers_in_prefix=len(layers), cap_count=len(caps),
                prefix_sha256=prefix_hash(layers), cap_lower=str(-upper(-lower)),
                tail_negative_income_upper=str(upper(unpaid_negative)),
                generic_divisor_charge_upper=str(upper(total)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--through',required=True,type=int)
    parser.add_argument('--ledger',type=Path,required=True)
    parser.add_argument('--weighted',type=Path,help='Additional angular-moment bounds on the same expenses')
    parser.add_argument('--matrix',action='store_true',help='Also enclose the charge with signed matrix factors')
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--check',action='store_true')
    args = parser.parse_args()
    ledger, cert, norm, score, prices = map(read,(args.ledger,CERT,NORM,SCORE,PRICES))
    provenance(ledger,Path.cwd())
    for doc, paths in ((score,(FIBRES,NORM,FIT,PRICES,TABLE,PRODUCER)),
                       (prices,(FORMS,FORMS.with_suffix('.npz'),FROZEN,CERT))):
        assert all(doc['inputs'][p.name] == digest(p) for p in paths)
    assert norm['status'] == 'ORDINARY_NORM_ENCLOSED'
    assert [v['cap'] for v in norm['layers']] == norm['caps']
    cover_path = Path('h1_exception_cover_72.json')
    cover = read(cover_path)
    assert prices['inputs'][cover_path.name] == digest(cover_path) and cover['source_sha256'] == digest(MINORANTS)
    _, last, _, _ = native_layout(read(FIBRES),cert)
    step = Q(norm['step'])*geom.RHO*UNIT
    radii = np.array([int(ceil((int(j)+37)*step)) for j in last])
    affine, blocks = remaining_entries(cert,radii,ledger)
    loss = sector_charges(cert,radii,affine,prices,cover)
    weighted = None
    if args.weighted:
        weighted = read(args.weighted)
        provenance(weighted,Path.cwd())
        weighted_ledger = Path(weighted['ledger'])
        assert weighted['inputs'][weighted_ledger.name] == digest(weighted_ledger)
        if weighted_ledger.resolve() != args.ledger.resolve():
            # A tighter local allowance may cover exactly the same matrix entries.
            prior_affine, _ = remaining_entries(cert,radii,read(weighted_ledger))
            assert np.array_equal(prior_affine,affine)
        assert weighted['cap_schedule'] == score['caps'] and weighted['through'] == args.through
        assert weighted['generic_ordered_pairs'] == ledger['unresolved_active_ordered_pairs']
    out = bounds(score,args.through,norm,prices,loss,weighted)
    alternatives = []
    if args.matrix:
        from h1_margin_matrix import direct_checks, sector_charges as matrix_charges
        out['signed_matrix_checks'] = direct_checks()
        alternative = list(map(upper,matrix_charges(cert,radii,affine,prices,cover)))
        alts = bounds(score,args.through,norm,prices,alternative,None)
        out['row_sum_upper'] = out['generic_divisor_charge_upper']
        out['matrix_upper'] = alts['generic_divisor_charge_upper']
        out['generic_divisor_charge_upper'] = str(min(Q(out['row_sum_upper']),Q(out['matrix_upper'])))
        alternatives.append([str(v) for v in alternative])
    paths = [Path(__file__),args.ledger,*blocks,CERT,FIBRES,FIT,NORM,PRICES,TABLE,GLOBAL,MINORANTS,
             FORMS,FORMS.with_suffix('.npz'),FROZEN,cover_path,PRODUCER,Path('h1_graded_outer_cross.py'),
             Path('h1_graded_cross_block.py'),Path('h1_strip_free_integral_budget.py'),Path('h1_combined_margin.py')]
    if args.weighted:
        paths.append(args.weighted)
    if args.matrix:
        paths.extend([Path('h1_margin_matrix.py'),Path('h1_exception_cover.py'),Path('verify_pairing_envelope.py')])
    out.update(scope='Full error allowance under the stated sieve inputs. The generic charge applies only outside the local divisor ledger.',
               ledger=args.ledger.name, generic_ordered_pairs=ledger['unresolved_active_ordered_pairs'],
               sector_charge_uppers=[[str(v) for v in loss],*alternatives],
               cap_schedule=score['caps'], cap_inputs=score['inputs'], inventory_inputs=score['inventory_inputs'],
               inputs={p.name:digest(p) for p in paths})
    if args.check:
        assert out == read(args.output)
    else:
        args.output.write_text(json.dumps(out,indent=2)+'\n',newline='\n')
    print('continuous cap lower',out['cap_lower'],'generic divisor charge',float(Q(out['generic_divisor_charge_upper'])),flush=True)


if __name__ == '__main__':
    main()
