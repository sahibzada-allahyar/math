"""Use spectral splitting to price both minorants on a refined H1 partition."""
import argparse
from decimal import Decimal
from fractions import Fraction as Q
import json
from math import floor
from pathlib import Path
import numpy as np
from scipy.linalg import eigh
from h1_bilinear_pricing import proof_data,lower
from h1_refine_prices import digest,read
from verify_pairing_envelope import SCALE,quantize


def data_and_start(a):
    data,sets,fixed,extra=proof_data(a,with_layout=True)
    _,_,_,_,_,k0,kt,fc,omitted=data
    assert not omitted
    table=json.loads(a.control.read_text(),parse_float=Decimal)
    prior=read(a.price);base=read(a.price_table)
    assert prior['inputs'][a.price_table.name]==digest(a.price_table)
    assert all(base[k]==table[k] for k in ('codes','prime_mask','minorant_mask','refined_grant'))
    raw=np.array([[Q(v) for v in row] for row in table['sector_energies']],dtype=object)
    ids=np.full((len(raw),2),-1,int)
    for j,g in enumerate(sets):ids[g,0]=j
    for j,g in enumerate(prior['groups']):ids[g,1]=j
    active=np.flatnonzero(ids[:,0]>=0);assert min(ids[active,1])>=0
    _,labels=np.unique(ids[active],axis=0,return_inverse=True)
    groups=[active[labels==i] for i in range(labels.max()+1)]
    rep=np.array([g[0] for g in groups]);src=ids[rep,1]
    e=np.array([raw[g].sum(0) for g in groups])
    J=np.array([sum(raw[g,0]*extra[g])/v for g,v in zip(groups,e[:,0])])
    p,m=[np.array(table[k],bool)[np.ix_(rep,rep)] for k in ('prime_mask','minorant_mask')]
    g=np.array([[v=='1' for v in row] for row in table['refined_grant']])[np.ix_(rep,rep)]
    eb=np.array(base['sector_energies'])[:,0]
    scale=np.sqrt(e[:,0].astype(float)/np.array([eb[h].sum() for h in prior['groups']])[src])
    A,H=[(np.asarray(v,float)/SCALE)[np.ix_(src,src)]*np.outer(scale,scale) for v in prior['affine']]
    return (e,p,m,g,J,k0,kt,fc),(A,H,np.zeros_like(A)),groups


def solve(data,initial,steps):
    e,p,m,g,J,k0,kt,fixed=data
    E=e[:,0].astype(float);w=np.sqrt(E);caps=[e[:,1].astype(float)/E,e[:,2].astype(float)/E,J.astype(float)]
    scale=np.array([np.sqrt(np.outer(v,v)) for v in caps]);weights=scale**2;n=len(w);I=np.eye(n)
    D=np.outer(w,w)*scale[0]
    beta=np.array([1,-float(sum(k0)/2),-float(sum(kt)/2-sum(k0)/2)])
    def residual(a):return np.array([D-scale[0]*a[0],scale[1]*a[1],scale[2]*a[2]])
    def score(a,x):
        return float(fixed)+beta@np.trace(a,axis1=1,axis2=2)+sum(np.minimum(eigh(v,eigvals_only=True,check_finite=False),0).sum() for v in x)
    # The independent supported differences are A-H, H-S and S.
    # On each run of tied entries the projection is a weighted average.
    permissions=(p,m,g);blocks=[]
    for i in range(3):
        mask=np.ones_like(p) if i==0 else permissions[i-1].copy()
        for j in range(i,3):
            ix=np.where(mask&permissions[j]);den=weights[i:j+1].sum(0)[ix]
            blocks.append((i,j,ix,den));mask &= ~permissions[j]
    a=np.array(initial);best=score(a,residual(a));saved=a.copy();prices=None;log=[]
    for tau in (2e-4,4e-5,8e-6,1.6e-6):
        z=residual(saved)
        if prices is not None:z+=tau*prices
        for t in range(steps):
            rhs=scale*z;rhs[0]=scale[0]*(D-z[0]);rhs+=tau*beta[:,None,None]*I
            a=np.zeros_like(z)
            for i,j,ix,den in blocks:
                v=sum(rhs[k][ix] for k in range(i,j+1))/den
                for k in range(i,j+1):a[k][ix]=v
            x=residual(a)
            if t%40==0 or t==steps-1:
                v=score(a,x)
                if v>best:
                    best=v;saved=a.copy();prices=(z-x)/tau
            for j in range(3):
                h=2*x[j]-z[j];ev,V=eigh(h,check_finite=False);sel=ev<0
                prox=h+(V[:,sel]*np.minimum(-ev[sel],tau))@V[:,sel].T
                z[j]+=1.65*(prox-x[j])
        log.append(dict(tau=tau,iterations=steps,score=best));print(log[-1],flush=True)
    A,H,S=[quantize(v) for v in saved]
    return [A-H,H-S,S],log


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('control',type=Path);p.add_argument('price',type=Path)
    p.add_argument('--price-table',type=Path,required=True);p.add_argument('--steps',type=int,default=230)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--check',action='store_true')
    p.add_argument('--no-higher',action='store_true',help='Drop the higher-level identities as a matched control.')
    p.set_defaults(permissions=Path('h1_refit280_step2_permissions_131072.json'),level='.5291',grant='ladder',
                   ladder_receipt=Path('h1_bilinear_ladders_131072.json'),minorants=Path('../sensitivity/bilinear_minorant.json'))
    a=p.parse_args();data,start,groups=data_and_start(a)
    if a.no_higher:
        e,p0,m,g,J,k0,kt,fc=data
        data=(e,p0,m,np.zeros_like(g),J,k0,kt,fc)
    hashes={f.name:digest(f) for f in (a.control,a.price_table,a.price,a.permissions,a.ladder_receipt,a.minorants)}
    if a.check:
        d=read(a.output);assert d['inputs']==hashes and d['groups']==[v.tolist() for v in groups]
        assert bool(d.get('no_higher'))==a.no_higher
        aff=[np.array(v,dtype=object) for v in d['affine']]
        assert floor(lower(*data,aff)*10**9)==d['lower_billionths']
    else:
        aff,log=solve(data,start,a.steps)
        d=dict(scope='Verified finite lower bound with two minorants on the supplied uncoupled norm budgets.',
               inputs=hashes,groups=[v.tolist() for v in groups],affine=[v.tolist() for v in aff],history=log,
               lower_billionths=floor(lower(*data,aff)*10**9))
        if a.no_higher:d['no_higher']=True
        a.output.write_text(json.dumps(d,separators=(',',':'))+'\n')
    print(len(groups),d['lower_billionths'],flush=True)


if __name__=='__main__':main()
