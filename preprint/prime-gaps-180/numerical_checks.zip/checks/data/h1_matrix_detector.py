"""Two-component single-prime detector on the 41-shift diameter-188 tuple."""
import argparse,json
from collections import defaultdict
from fractions import Fraction as Q
from itertools import combinations,permutations
from pathlib import Path
import numpy as np
from scipy.linalg import eigh
from endpoint_pair_scan import HERE,BACKEND,setup,first_fibres,scalar_replay
from endpoint_edge_trial import overlaps,contract_form,moment_numerator
from endpoint_asymmetric_trial import original_rows
from math import prod


TAGS=[(),*[(i,) for i in range(6)],*combinations(range(6),2)]


def rules(k,marked,tags=TAGS):
    kept=[i for i in range(k) if i!=marked]
    groups=[]
    for tag in tags:
        rel=[kept.index(i) for i in tag if i!=marked]
        if not rel:
            coeff=np.array(1.)
        elif len(rel)==1:
            coeff=np.zeros(len(kept));coeff[rel[0]]=1.
        else:
            coeff=np.zeros((len(kept),len(kept)));coeff[tuple(sorted(rel))]=1.
        groups.append((int(marked in tag),coeff))
    result=defaultdict(lambda:defaultdict(lambda:np.zeros((len(tags),len(tags)))))
    for i,(u,a) in enumerate(groups):
        for j in range(i,len(groups)):
            v,b=groups[j]
            for pat,w in overlaps(a,b).items():
                if w:
                    result[tuple(sorted((u,v)))][pat][i,j]+=w
    return result


def check_rules():
    tags=[(),(0,),(1,),(0,1),(0,2),(2,3)]
    error=0.
    for marked in [None,0,4]:
        kept=[i for i in range(5) if i!=marked];n=len(kept)
        t=np.array([.1,.15,.21,.26,.34])[:n]
        direct=np.zeros((len(tags),len(tags)));fib=[1.3,.29]
        for perm in permutations(kept):
            tt=dict(zip(perm,t))
            values=[fib[int(marked in tag)]*prod(tt[i] for i in tag if i!=marked) for tag in tags]
            direct+=np.outer(values,values)
        direct/=prod(range(1,n+1))
        comparison=np.zeros_like(direct)
        for (u,v),parts in rules(5,marked,tags).items():
            for pattern,M in parts.items():
                comparison+=fib[u]*fib[v]*M*moment_numerator(t,pattern)/prod(range(n-len(pattern)+1,n+1))
        error=max(error,np.max(abs(comparison-np.triu(direct))))
    assert error<1.e-12
    return float(error)


def effects(b,u):
    # A0,A1 have distinct minimal common upper bounds X+ and X-.
    # Keeping rationals here gives an independently checkable finite witness.
    a=b-u*u/b
    A0=np.array([[a,0],[0,0]],dtype=object);A1=np.array([[0,0],[0,a]],dtype=object)
    plus=np.array([[b,u],[u,b]],dtype=object);minus=np.array([[b,-u],[-u,b]],dtype=object)
    I=np.array([[1,0],[0,1]],dtype=object)
    E=[A0,A1,minus,I-A0,I-plus,I-minus]
    wide=[(0,3),(0,4),(0,5),(1,4),(1,5),(2,5)]
    def psd(M):
        return M[0,0]>=0 and M[1,1]>=0 and M[0,0]*M[1,1]>=M[0,1]**2 and M[0,1]==M[1,0]
    assert all(psd(M) and psd(I-M) for M in E)
    assert all(psd(I-E[i]-E[j]) for i,j in wide)
    return np.asarray(E,dtype=float)


def matrices(source,N):
    k=41
    prior=json.loads((BACKEND/'results/incidence_multicap_spline_a6_n32768.json').read_text())
    r,limits,domains=setup(k,N,source,prior)
    v=np.array(source['best_coefficients'])
    ell=source['rows'][source['best_index']]['hybrid_lambda']
    kappa=prior['kappa'];args=(domains,ell,kappa)
    mass=contract_form(r,0,[original_rows(r,v,limits)],rules(k,None),*args)
    first=[first_fibres(r,v,limits),first_fibres(r,v,limits,marked_power=1)]
    outer=contract_form(r,1,first,rules(k,0),*args)/k
    core=contract_form(r,1,first,rules(k,6),*args)/k
    forms=[]
    for i in range(6):
        def swap(x):return i if x==0 else (0 if x==i else x)
        indices=[TAGS.index(tuple(sorted(swap(x) for x in tag))) for tag in TAGS]
        forms.append(outer[np.ix_(indices,indices)])
    scalar,components=scalar_replay(r,v,limits,domains)
    expected=r.rho*(components[0]+(1-ell)*components[1]+(1-1/ell)*kappa*components[2])/scalar
    observed=(35*core[0,0]+sum(D[0,0] for D in forms))/mass[0,0]
    assert abs(expected-observed)<1.e-8 and abs(mass[0,0]/scalar-1)<1.e-8
    return mass,core,forms,dict(single_prime_calibration_error=abs(expected-observed),scalar_score=expected)


def solve(mass,core,forms):
    # Transformation to dimensionless, mass-orthonormal basis.
    d=np.sqrt(np.diag(mass))
    e,v=eigh(mass/d[:,None]/d[None,:])
    assert e[0]>-1e-8*e[-1]
    active=e>1.e-9*e[-1]
    W=v[:,active]/np.sqrt(e[active])/d[:,None]
    core=W.T@core@W;forms=[W.T@D@W for D in forms]
    def fit(E):
        A=np.kron(np.eye(2),35*core)+sum(np.kron(M,D) for M,D in zip(E,forms))
        val,vec=eigh((A+A.T)/2,subset_by_index=(len(A)-1,len(A)-1))
        V=vec[:,-1].reshape(2,-1)@W.T
        return float(val[0]),V
    windows=[]
    # Maximal windows on the six ordered endpoint labels: 012, 123, 234, 345.
    for i in range(4):
        E=np.array([np.eye(2)*(i<=j<i+3) for j in range(6)])
        q,_=fit(E);windows.append(q)
    best=None;example=None
    for n in range(1,20):
        b=Q(n,20)
        for m in range(1,11):
            u=min(b,1-b)*Q(m,10)
            if u==b:continue
            E=effects(b,u);q,V=fit(E)
            row=dict(b=str(b),u=str(u),score=q,coefficients=V.tolist())
            if best is None or q>best['score']:best=row
            if b==Q(1,2) and u==Q(1,4):example=row
    return dict(rank=int(active.sum()),normalized_gram_min=float(e[0]),window_scores=windows,
                best_matrix=best,explicit_example=example)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--intervals',type=int,default=32768);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    source=json.loads((HERE/'h1_k39_control_n32768.json').read_text())
    shifts=json.loads((HERE/'endpoint_tuple_inputs.json').read_text())['41']['shifts']
    points=shifts[:3]+shifts[-3:]
    assert [(i,j) for i,j in combinations(range(6),2) if points[j]-points[i]>180]==[(0,3),(0,4),(0,5),(1,4),(1,5),(2,5)]
    assert all(max(h-shifts[0],shifts[-1]-h)<=180 for h in shifts[3:-3])
    mass,core,forms,cal=matrices(source,args.intervals)
    fit=solve(mass,core,forms)
    out=dict(status='SINGLE_PRIME_MATRIX_CRITERION_UNCERTIFIED_CAP_EVALUATION',intervals=args.intervals,
             labels=points,common_shifts=len(shifts)-6,tags=TAGS,control=cal,
             permutation_error=check_rules(),mass=mass.tolist(),common_form=core.tolist(),
             endpoint_forms=[D.tolist() for D in forms],fit=fit,
             scope='Pointwise detector is exact. Cap evaluation is floating and excludes support restoration.')
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'windows':fit['window_scores'],'best':fit['best_matrix']['score'],
                      'explicit_example':fit['explicit_example']['score']}),flush=True)


if __name__=='__main__':
    main()
