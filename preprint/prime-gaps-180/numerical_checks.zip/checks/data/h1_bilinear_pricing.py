"""Dual lower certificate for two nested minorants on the finite H1 sector table."""
import argparse
from decimal import Decimal
from fractions import Fraction as Q
from hashlib import sha256
import json
from math import floor,ceil,isqrt
from pathlib import Path
import sys
import numpy as np
from scipy import sparse
from h1_pairing_sdp import scs
from h1_third_measure import masks,ladder_mask,apply_old
from verify_pairing_envelope import SCALE,quantize,lower_factor
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'sensitivity'))
from bilinear_minorant import kernel


def five_upper(a,q,bins=128):
    lam=1-2*a;step=(a-2*lam)/bins;total=0;unit=10**10
    for i in range(bins):
        l=2*lam+i*step;r=l+step
        bottom=min(lam,(1-r)/2-q)-Q(1,10000);assert bottom>0
        hinge=Q(12,5)*max(0,r-Q('.38'))/Q('.02')
        total+=ceil(unit*step*hinge*(r-2*lam)/(l*lam*bottom))
    return Q(total,unit)


def proof_data(args,with_layout=False):
    data=json.loads(args.control.read_text(),parse_float=Decimal);apply_old(data,args.permissions)
    book=json.loads(args.minorants.read_text());level=Q(args.level)
    row=next(x for x in book['rows'] if Q(x['theta'])==level)
    a=Q(row['a']);zeta=Q(row['zeta'])
    # Upward rounding of all physical cell endpoints; use the largest radius
    # in each sector with the monotone root budgets.
    radius=[Q(ceil(Q(x)*10000)+1,10000) for x in data['physical_upper']]
    p=np.array(data['prime_mask'],bool);m=np.array(data['minorant_mask'],bool)
    if args.grant in ('ladder','ladder-outward'):
        assert args.ladder_receipt is not None
        g=ladder_mask(data,args.ladder_receipt,level,args.grant=='ladder-outward')
    elif args.grant=='global':g=np.ones_like(p)
    elif args.grant=='inner':g=np.add.outer(radius,radius)<=level
    else:_,g=masks(data,level)
    energy=np.array([[Q(x) for x in r] for r in data['sector_energies']],dtype=object)
    keep=energy[:,0]>0;omitted=sum(abs(energy[~keep,0]));ids=np.flatnonzero(keep)
    pp=p[np.ix_(ids,ids)];fixed=ids[pp.all(axis=1)];ids=ids[~pp.all(axis=1)]
    fixed_cost=sum(energy[fixed,0])
    p,m,g=[x[np.ix_(ids,ids)] for x in (p,m,g)]
    _,labs=np.unique(np.column_stack([p,m,g]),axis=0,return_inverse=True)
    parts=[np.flatnonzero(labs==n) for n in range(labs.max()+1)]
    r=[x[0] for x in parts];p,m,g=[x[np.ix_(r,r)] for x in (p,m,g)]
    sets=[ids[s] for s in parts];e=np.array([energy[s].sum(0) for s in sets],dtype=object)
    k0=(Q('.000093307088324061'),Q('.000093307088324062'))
    kt=(Q(row['three_mass']['lower_millionths'],10**6)+Q(row['five_mass']['lower']),
        Q(row['three_mass']['upper_millionths'],10**6)+Q(row['five_mass']['upper']))
    budgets={}
    for q in set(radius):
        budgets[q]=Q(kernel(zeta,a,q,bins=128)[1],10**12)+five_upper(a,q)
    # The incremental positive error is bounded by the full new five-prime
    # error plus the three-prime error. The former includes the old error.
    J=np.array([sum(energy[i,0]*budgets[radius[i]] for i in s)/sum(energy[s,0]) for s in sets],dtype=object)
    result=e,p,m,g,J,k0,kt,fixed_cost,omitted
    if with_layout:return result,sets,fixed,np.array([budgets[q] for q in radius],dtype=object)
    return result


def solve(e,p,m,g,J,k,kt,seconds):
    n=len(e);i,j=np.triu_indices(n);l=len(i);scale=np.where(i==j,1.,np.sqrt(2.))
    def unpack(y):
        t=np.zeros((n,n));t[i,j]=y/scale;t[j,i]=t[i,j];return t
    diag=(i==j).astype(float);I=sparse.eye(l,format='csc');Z=sparse.csc_matrix((l,l))
    z=np.where(np.diag(p&m),np.sqrt(k),1.);zz=z[i]*z[j];B=sparse.diags(zz)
    P=sparse.hstack([I,Z,Z],format='csr');Y=sparse.hstack([Z,B,Z],format='csr')
    Yn=sparse.hstack([Z,I,Z],format='csr');H=sparse.hstack([Z,Z,I],format='csr')
    pm,mm,gm=p[i,j],m[i,j],g[i,j]
    masks_list=[pm,pm&mm,mm&~pm,gm&mm,gm&pm&~mm,gm&~pm&~mm]
    forms=[P,Yn,P-Y,H,Y+H,P-Y-H]
    rhs=[diag,k*diag/zz,(1-k)*diag,(kt-k)*diag,kt*diag,(1-kt)*diag]
    A=[f[mask] for f,mask in zip(forms,masks_list)]
    b=[v[mask] for v,mask in zip(rhs,masks_list)];nzero=sum(map(len,b))
    U=e[:,1]/e[:,0];K=e[:,2]/e[:,0]
    spec=dict(A=sparse.vstack([*A,-P,P,-Yn,Y,-H,H],format='csc'),
              b=np.r_[*b,np.zeros(l),U[i]*diag,np.zeros(l),K[i]*diag,np.zeros(l),J[i]*diag],
              c=np.r_[np.sqrt(e[i,0]*e[j,0])*scale,np.zeros(2*l)])
    sol=scs.solve(spec,dict(z=nzero,s=[n]*6),time_limit_secs=seconds,max_iters=100000,eps_abs=3e-7,eps_rel=3e-7,verbose=False)
    y=-sol['y'];packed=[];start=0
    for mask in masks_list:
        a=np.zeros(l);length=int(mask.sum());a[mask]=y[start:start+length];packed.append(a);start+=length
    a,b,c,h,ph,last=packed
    # Undo the transformed equalities to recover multipliers of P, P-B and P-B-H.
    L=a+b/zz+ph;R=c-b/zz+h;S=last-h-ph
    return [quantize(unpack(t)) for t in (L,R,S)],sol['info']['status']


def lower(e,p,m,g,J,k0,kt,fixed,mults):
    L,R,S=mults;n=len(e)
    assert all(np.array_equal(x,x.T) and not x[~mask].any() for x,mask in zip(mults,(p,m,g)))
    # Rational lower approximation to sqrt(e), only in the objective.
    w=np.array([isqrt(int(x*SCALE**2)) for x in e[:,0]],dtype=object)
    U=e[:,1]/e[:,0];K=e[:,2]/e[:,0]
    err=max(U)*(2*sum(w)*n+n*n)*Q(1,SCALE**2)
    mats=[np.outer(w,w)-SCALE*(L+R+S),SCALE*(R+S),SCALE*S]
    cost=Q(0)
    for mat,budget in zip(mats,(U,K,J)):
        penalty,_=lower_factor(mat,budget);cost+=sum(penalty*budget)
    # Outward independently on the two narrow deficit intervals.
    trace=lambda x:Q(int(x.trace()),SCALE)
    const=trace(L)+min((1-k)*trace(R) for k in k0)+min((1-k)*trace(S) for k in kt)
    return fixed+const-cost-err


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('control',type=Path);ap.add_argument('permissions',type=Path)
    ap.add_argument('minorants',type=Path);ap.add_argument('--level',default='.5291')
    ap.add_argument('--grant',choices=('global','inner','outer','ladder'),default='inner');ap.add_argument('--ladder-receipt',type=Path)
    ap.add_argument('--seconds',type=int,default=85);ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--check',action='store_true');args=ap.parse_args()
    e,p,m,g,J,k,kt,fixed,omitted=proof_data(args)
    hashes={f.name:sha256(f.read_bytes()).hexdigest() for f in (args.control,args.permissions,args.minorants)}
    if args.ladder_receipt:hashes[args.ladder_receipt.name]=sha256(args.ladder_receipt.read_bytes()).hexdigest()
    if args.check:
        out=json.loads(args.output.read_text());assert out['inputs']==hashes and out['level']==args.level and out['grant']==args.grant
        mats=[np.array(x,dtype=object) for x in out['multipliers']]
    else:
        mats,status=solve(e.astype(float),p,m,g,J.astype(float),float(sum(k)/2),float(sum(kt)/2),args.seconds)
    value=lower(e,p,m,g,J,k,kt,fixed,mats);v=floor(value*10**9)
    if args.check:assert v==out['lower_billionths']
    else:
        out=dict(scope='Exact finite dual lower witness conditional on the specified hypothetical additional identities. No arithmetic, integration, or support restoration certificate.',
                 inputs=hashes,level=args.level,grant=args.grant,n=len(e),high_pairs=int(np.triu(g).sum()),
                 solver_status=status,omitted_absolute_energy=str(omitted),scale=SCALE,
                 multipliers=[x.tolist() for x in mats],lower_billionths=v)
        args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(args.grant,len(e),v,flush=True)


if __name__=='__main__':main()
