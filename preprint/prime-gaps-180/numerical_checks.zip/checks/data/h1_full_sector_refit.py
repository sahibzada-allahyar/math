"""Refit the full 726-dimensional spline against a transferred sector dual."""
import argparse
from fractions import Fraction as Q
import json
from pathlib import Path
import numpy as np
from scipy.linalg import eigh
from h1_fit_pairing_sectors import HERE,densities,uniform_weights
from h1_geometry_scan import instantiate
from h1_pairing_sectors import model,trial_model,Sectors,first_fibres,radial,coefficients
from h1_knn_harmonic import basis_components


def guide(fit):
    f=json.loads(fit.read_text())
    if 'best_sdp' in f:
        s=np.load(HERE/f['input']);c=json.loads((HERE/str(s['control'])).read_text())
        v=np.r_[1.,f['coefficients']];m,g=densities(c,s);energies=v@m@v;sol=f['best_sdp']
    else:
        c=json.loads((HERE/f['source']).read_text());energies=np.array(c['sector_energies']);sol=f
    old,prior,base,r,lim,dom=trial_model(c['intervals'],c.get('trial_refit'))
    sectors=Sectors(r,dom,[d['radius'] for d in c['sources']],c['max_radius'])
    assert sectors.codes==c['codes']
    return r,sectors,uniform_weights(energies,sol,c['kappa_upper'])


def weighted_forms(r,lim,old,sec,weights,clip,field_at=None):
    gram,parts,axes=basis_components(r,lim);size=len(gram)
    out=np.zeros((size,size));idx=np.clip(np.rint(r.sy/old.h-(r.k-1)/2).astype(int),0,sec.count-1)
    intrinsic=sorted({s[2] for shells,a in parts for s in shells});last=intrinsic[-1]
    converted={int(Q(int(c))*old.exact_step//r.exact_step) for c in sec.caps}
    cuts=sorted(x for x in converted|set(intrinsic) if 0<x<=last)
    address={sig:np.concatenate([ids+i*r.nb for i in range(len(parts))]) for sig,ids in axes.items()}
    prev={};acc={};allweights={}
    for cap in cuts:
        cref=int(-((-cap*r.exact_step)//old.exact_step));level=np.searchsorted(sec.caps,cref)
        if field_at is not None:
            w=field_at(cref,idx)
        elif level<len(sec.caps):
            ids=sec.index[level,idx]
            w=weights[ids,0]+weights[ids,1]*sec.prime_upper[idx]+weights[ids,2]*sec.kernel[idx]
        else:w=np.full(r.n,-clip)
        if np.isfinite(clip):w=np.clip(w,-clip,1.)
        allweights[cap]=w
        field=r.rho*r.norm*r.inner_exp*w
        sigs=sorted(axes,key=lambda s:(sum(s),s))
        combined={tuple(sorted(x+y)) for i,x in enumerate(sigs) for y in sigs[i:]}
        now={}
        for sig in combined:
            now[sig]=r.moment(cap,r.k-1,sig).copy()
            val=field*(now[sig]-prev.get(sig,0.))
            if sig in acc:acc[sig]+=val
            else:acc[sig]=val
        if cap in intrinsic:
            blocks={s:np.zeros((len(address[s]),r.n)) for s in sigs}
            for j,(shells,components) in enumerate(parts):
                for shell,part in zip(shells,components):
                    if shell[2]<cap:continue
                    for sig,v in part.items():
                        n=len(axes[sig]);blocks[sig][j*n:(j+1)*n]+=v
            for i,x in enumerate(sigs):
                for y in sigs[i:]:
                    v=(blocks[x]*acc[tuple(sorted(x+y))])@blocks[y].T
                    out[np.ix_(address[x],address[y])]+=v
                    if x!=y:out[np.ix_(address[y],address[x])]+=v.T
            acc={}
        prev=now;r.clear_cache()
    return gram,(out+out.T)/2,allweights


def scalar(r,lim,v,weights):
    f=first_fibres(r,v,lim);prev={};q=0.
    for cap,w in weights.items():
        fields=radial(f,cap,r.n);poly=coefficients(fields,fields);now={};d=np.zeros(r.n)
        for s,a in poly.items():
            now[s]=r.moment(cap,r.k-1,s).copy()
            d+=a*(now[s]-prev.get(s,0.))
        q+=float(d@(r.rho*r.norm*r.inner_exp*w));prev=now;r.clear_cache()
    return q


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('guide',type=Path)
    p.add_argument('--radius',default='.282');p.add_argument('--intervals',type=int,default=8192)
    p.add_argument('--clip',type=float,default=5.);p.add_argument('--flat',action='store_true')
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    old,sec,wt=guide(a.guide);profile=json.loads((HERE/'h1_k38_knn6_n32768.json').read_text())
    r,lim,dom,spec,record=instantiate(profile,dict(radius=a.radius),38,a.intervals)
    if a.flat:r.shells['outer']=[(Q(0),r.geometry['parameters']['S'],max(lim))]
    G,A,weights=weighted_forms(r,lim,old,sec,wt,a.clip)
    diag=np.diag(G);active=diag>diag.max()*1e-18
    scale=np.sqrt(diag[active]);gn=G[np.ix_(active,active)]/np.outer(scale,scale)
    ev,vec=eigh((gn+gn.T)/2)
    assert ev[0]>-1e-8*ev[-1]
    use=ev>1e-8*ev[-1];X=vec[:,use]/np.sqrt(ev[use])/scale[:,None]
    small=X.T@A[np.ix_(active,active)]@X
    val,vec=eigh((small+small.T)/2);v=np.zeros(len(diag));v[active]=X@vec[:,-1]
    mass=float(v@G@v);direct=scalar(r,lim,v,weights)/mass
    assert abs(direct-val[-1])<1e-6,(direct,val[-1])
    out=dict(status='HEURISTIC_TRANSFERRED_DUAL_WEIGHT_REFIT_REQUIRES_NEW_SECTOR_EVALUATION',guide=a.guide.name,
             radius=a.radius,flat=a.flat,intervals=a.intervals,clip=a.clip if np.isfinite(a.clip) else None,
             shape_spec=spec,geometry=record,gram_rank=int(use.sum()),mass=mass,
             weighted_score=float(val[-1]),scalar_replay=direct,coefficients=v.tolist())
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(score=direct,rank=int(use.sum()))))


if __name__=='__main__':
    main()
