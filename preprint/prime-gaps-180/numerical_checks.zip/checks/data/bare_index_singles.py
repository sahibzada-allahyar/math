"""Reprice localized single-root squares using the erased site's share of the full native total."""
import argparse
from fractions import Fraction as Q
from hashlib import sha256
import json
from math import ceil
from pathlib import Path
import numpy as np

from radial_rounding import captured

EDGES=tuple(range(90000,940000,40000))
CAPS=(9764,19529,29293,39058,46567,47096,58332,60089,61104,63177,64599,65536,78116)
FULL_LO=102994
EDGE_FLOOR=dict(zip(EDGES,(110019,110019,110019,110019,110019,110019,109082,
    108520,108520,108145,106272,104399,*([FULL_LO]*10)),strict=True))
TICK=Q(1399373467,1312494500)/131072*2624990
DEN=10**30
PRODUCTION_PIN='123572768d6cc3e4e386d0bbec1c12bff5d8f16c9264f36d0d6988ea5bde62ec'


def ceilq(x):
    return Q(-(-x.numerator*DEN//x.denominator),DEN)


def root(x):
    from math import isqrt
    k=isqrt(x.numerator*DEN**2//x.denominator)
    return Q(k+(k*k*x.denominator<x.numerator*DEN**2),DEN)


def fingerprint(p):return sha256(p.read_bytes()).hexdigest()


def verify_edge_floors(path):
    """First reachable retained indices on any genuinely failing erased face."""
    from h1_degree6_b2_gate_reachability import Gates
    g=Gates(path)
    assert min(g.verify()['first_potential_failure'])==FULL_LO
    floors={e:10**12 for e in EDGES}
    tick=Q(*g.tick.as_integer_ratio())
    assert tick==TICK
    for i,cap in enumerate(g.fine):
        j,keys,tops=g.tile(i,start=FULL_LO)
        last_possible=np.searchsorted(g.edges,int(int(cap)*tick),side='right')-1
        for e in EDGES:
            k=min(last_possible,np.searchsorted(g.edges,min(e+40000,940000))-1)
            if g.edges[k]<e:continue
            # True tail <= true retained total <= top. The gates decrease
            # with the threshold, so check only the last possible crossing.
            ok=np.logical_or.reduce([top>g.gates[key,k] for key,top in zip(keys,tops)])
            if np.any(ok):floors[e]=min(floors[e],int(j[np.flatnonzero(ok)[0]]))
    assert floors==EDGE_FLOOR
    return floors


def panels(v,options):
    low=v['retained_cap'][0];first,last=v['full_J'];assert first==FULL_LO and last<=130964
    w=v['radial'];r=v['balanced_radius'];b=(r+1)*w
    j=max(0,ceil(Q(low-b,w)));stop=min((last+r*w)//w+1,(last+b)//w+1)
    bounds=[];starts=[]
    while j<stop:
        size=min(options['count'],v['terminal_count']) if j*w>=126000 else options['count']
        end=min(stop,j+size);starts.append(max(0,low,j*w-b));bounds.append(min(last,(end-1)*w+b));j=end
    assert v['panels']==len(bounds) and v['retained_J']==[starts[0],bounds[-1]]
    return bounds


def weight(a,all_base,t,beta,power,hinge):
    # t is an upper on the retained share q/J, so 1-t is a lower on
    # the erased share.  Positive powers of (s-hinge)_+ are superadditive.
    pos=lambda s:max(0,s-hinge)**power
    return 1+(all_base-a+beta*pos(t))/(a+beta*pos(1-t))


def load(directory,only=None):
    manifest=json.loads((directory/'manifest.json').read_text())
    record={k:v for k,v in manifest.items() if k!='calculation'}
    assert sha256(json.dumps(record,sort_keys=True).encode()).hexdigest()==manifest['calculation']
    if manifest['calculation']==PRODUCTION_PIN:
        from h1_degree6_native_schur_support import replay_limits
        limits = replay_limits(2)
        reference = Path(__file__).with_name('localized_middle_pair_39058_290000.json')
        field_source = json.loads(reference.read_bytes())['native_field_source']
        from archived_sources import PREFIX, recorded_digest
        for name, expected in field_source.items():
            assert recorded_digest(name) == expected, name
        for name,expected in manifest['sources'].items():
            actual=recorded_digest(name)
            # The manifest records the driver as it was when the certificates were computed.
            # The only later change serializes numpy integral metadata as native JSON integers.
            if name==PREFIX+'localized_middle_sweep.py' and actual=='999427def6cc0a5ecfbc55ab679a0ac039ac64719f1787720b30cdfdd1614da6':
                assert expected=='3daf884e437c59a8240c30341da28ef84f69d34fca5ff7aa614405405bdc0c27'
            else:
                assert actual==expected, name
    opt=manifest['options'];assert opt['owner_weight']==0 and not opt['same_full_only'] and opt['role']=='singles'
    assert {(c,e)for c,e in manifest['tasks']}=={(c,e)for c in CAPS for e in EDGES}
    out={};files={}
    for c,e in manifest['tasks']:
        if only and (c,e)!=only:continue
        path=directory/f'{c}_{e}.json'
        if not path.exists():continue
        raw=path.read_bytes();obj=json.loads(raw);v=obj['value']
        assert obj['calculation']==manifest['calculation'] and v['owner_weight']==0
        if manifest['calculation'] == PRODUCTION_PIN:
            assert v['field_geometry'] == next(g for g in CAPS[4:] if g >= c)
            assert v['native_field_bits'] == 256 and v['native_field_source'] == field_source
            assert v['full_J'] == [FULL_LO, next(j for cap, j in limits if cap >= c)]
            assert all(v[k] == opt[k] for k in ('dust', 'micro', 'tail', 'price_coupled', 'terminal_count'))
            assert v['spectral_tail_cutoff'] == opt['spectral_tail']
        idx=CAPS.index(c)
        assert v['retained_cap']==[CAPS[idx-1] if idx else -1,c] and v['edges']==[e,min(940000,e+40000)]
        assert v['covered_full_caps']==[c,*(f for f in CAPS[idx+1:] if f*TICK>e)]
        assert v['role']=='singles' and v['balanced_radius']==opt['radius'] and v['radial']==opt['radial']
        q=panels(v,opt);cap=captured(v['radial'],v['balanced_radius'])[0]
        t=tuple(min(Q(1),Q(h,EDGE_FLOOR[e])) for h in q)
        costs={}
        for role in ('core','a'):
            vals=v['charges'][role]['panel_bounds_before_capture']
            assert len(vals)==len(q) and all(Q(x)>=0 for x in vals)
            costs[role]=tuple(ceilq(Q(x)/cap) for x in vals)
            assert Q(v['charges'][role]['scaled_upper'])>=sum(map(Q,vals))/cap
        whole={role:Q(v['charges'][role]['scaled_upper']) for role in costs}
        whole['native_panel_upper']=tuple(q)
        out[c,e]=(t,costs,whole)
        files[f'{c}_{e}']=sha256(raw).hexdigest()
    return out,dict(manifest=manifest['calculation'],receipts=files)


def proposals(sources):
    """Floating arithmetic proposes three choices; every reported price is reevaluated exactly."""
    tuples=[]
    for sc in sources:
        t,c,_=sc
        tuples.append((np.array(list(map(float,t))),np.array(list(map(float,c['core']))),np.array(list(map(float,c['a'])))))
    # Combine source alternatives later using exact minima for each cap and
    # role. A proposal picked from the first collection remains valid.
    t,c,a=np.hstack([np.vstack(row) for row in tuples])
    best=[];af=sum(a);cf=sum(c)
    if not cf or not af:base=1.
    else:base=np.sqrt(af/cf)
    endpoint=sorted(set([.12,.2,.32,.5,.7,1.,1.4,2.,round(np.clip(base,.04,5.),3)]))
    for p,h in [(1,0.),(2,0.),(3,0.),(1,.10),(1,.25),(1,.4)]:
        u=np.maximum(0.,t-h)**p;v=np.maximum(0.,1-t-h)**p
        record=(float('inf'),None)
        for x in (0,2,4,8,12,16,24,32,48,64,96,128,192,256,384,512):
            ux=x*u;vx=x*v
            for er in endpoint:
                cost=37*np.sum(c*(1+(36+2*er+ux)/(1+vx)))+2*np.sum(a*(1+(37+er+ux)/(er+vx)))
                if cost<record[0]:record=(cost,(Q(x),Q(str(er)),p,Q(str(h))))
        best.append(record)
    return [v for _,v in sorted(best,key=lambda t:t[0])[:3]]


def exact(cap_cases,parameters):
    beta,er,p,h=parameters;all_base=37+2*er;factors={};total=Q(0)
    for alternatives in cap_cases:
        def one(row):
            t,c,_=row
            for z in set(t):
                if z not in factors:factors[z]=weight(1,all_base,z,beta,p,h),weight(er,all_base,z,beta,p,h)
            return (ceilq(sum(val*factors[z][0] for z,val in zip(t,c['core']))),
                    ceilq(sum(val*factors[z][1] for z,val in zip(t,c['a']))))
        options=[one(row) for row in alternatives]
        total+=37*min(k for k,_ in options)+2*min(k for _,k in options)
    return total


def summarize(dirs,only=None):
    sources=[];evidence=[]
    for d in dirs:
        values,pin=load(d,only);sources.append(values);evidence.append(pin)
    result={};allcases=0;total=Q(0);prior=Q(0)
    for e in EDGES:
        cases=[];caps=[]
        for c in CAPS:
            rows=[v[c,e] for v in sources if (c,e)in v]
            if rows:cases.append(rows);caps.append(c)
        allcases+=len(cases)
        core=sum((min(v[2]['core'] for v in r) for r in cases),Q(0));a=sum((min(v[2]['a'] for v in r) for r in cases),Q(0))
        orig=(37*root(core)+2*root(a))**2
        winning=(orig,None)
        if cases:
            for par in proposals([r[0] for r in cases]):
                z=exact(cases,par)
                if z<winning[0]:winning=(z,par)
        value,par=winning;total+=value;prior+=orig
        result[e]=dict(complete=len(caps)==13,caps=caps,raw_core=str(core),raw_endpoint=str(a),
                       raw_singles_upper=str(value),unweighted_singles_upper=str(orig),
                       parameters=list(map(str,par)) if par else None)
    return dict(scope='Directed Cauchy price using erased fraction of the full native total on captured radial panels.',
        version=2,evidence=evidence,full_index_floors=EDGE_FLOOR,
        normalization='100^39 raw squared integral of the tabulated proxy; field and swap comparison separate',
        complete=allcases,expected=286,all_covered=allcases==286,raw_subtotal=str(total),unweighted_subtotal=str(prior),by_edge=result)


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--directory',type=Path,nargs='+',required=True)
    ap.add_argument('--case',type=int,nargs=2,help='One genuine retained-cap and edge pair');ap.add_argument('--output',type=Path)
    a=ap.parse_args();result=summarize(a.directory,tuple(a.case) if a.case else None)
    if a.output:a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(cases=result['complete'],raw_upper=float(Q(result['raw_subtotal'])),old=float(Q(result['unweighted_subtotal'])),
          relative=float(Q(result['raw_subtotal'])/Q(result['unweighted_subtotal'])) if Q(result['unweighted_subtotal']) else None)))
