"""Certify hereditary native supports for a uniform negative-price fibre bound."""
import argparse
from dataclasses import dataclass
from fractions import Fraction as Q
from functools import lru_cache
import json
from types import SimpleNamespace

import numpy as np

import h1_two_source_endpoints as TS
from h1_geometry_scan import fit_geometry


@dataclass(frozen=True)
class Cap:
    upper: int
    full_last: int
    # Inclusive radial interval and the integer coefficients a,b of its price
    # scale^{-1}(a+b/(0.4999-rho*h*(j+38))).
    sectors: tuple


@lru_cache(maxsize=1)
def inputs():
    frame = TS.stored_frame()
    fit = json.loads((TS.HERE/frame['original']['trial_refit']).read_text())
    g,_,_ = fit_geometry({'radius':fit['radius']},39,131072)
    par = g['parameters']
    h = par['cell_step']
    assert h == frame['step']
    rate = par['rho_star']*h
    src = json.loads((TS.HERE/'h1_multilevel_strip_free.json').read_text())
    scale = int(src['scale'])
    prices = src['sector_prices']
    assert len(prices)==521 and all(len(v)==3 and v[1]<=0 and v[2]==0 for v in prices)
    original = g['cell_masks']['outer']
    assert [v['index_last'] for v in original] == [117732,125536,131032]
    n = original[-1]['index_last']+1
    r = SimpleNamespace(k=39,n=n)
    labels = TS.labeller(r,frame,1)
    caps = []
    for c in frame['caps']:
        c = int(c)
        last = max(v['index_last'] for v in original if c<=v['cap_index'])
        ids = labels(c)[:last+1]
        # At native resolution the direct retained index in the original
        # 38-coordinate frame is j+1. Verify the shifted labels at every cell.
        assert np.array_equal(ids,frame['layout'](c,np.arange(1,last+2)))
        endpoints = np.r_[0,np.flatnonzero(ids[1:]!=ids[:-1])+1,last+1]
        sectors = []
        for left,right in zip(endpoints,endpoints[1:]):
            i = ids[left]
            a,b = prices[i][:2] if i>=0 else (0,0)
            sectors.append((int(left),int(right)-1,int(a),int(b)))
        caps.append(Cap(c,last,tuple(sectors)))
    assert caps[-1].upper==frame['original']['cutoff']
    assert all(a.full_last>=b.full_last for a,b in zip(caps,caps[1:]))
    assert Q(4999,10000)>(n+38)*rate
    return rate,scale,caps


def feasible(cap, last, budget, rate, scale):
    """Exact minimum of the price-cleared quadratic on every occupied run."""
    u,v = rate.as_integer_ratio()
    d = 10000*v
    r0 = 4999*v-38*10000*u
    r1 = -10000*u
    bnum,bden = budget.as_integer_ratio()
    for start,end,a,b in cap.sectors:
        if start>last:
            break
        end=min(end,last)
        # H(j) = B_num*scale*v*(r0+r1*j) +
        #     39*u*B_den*(last+1-j)*(a*(r0+r1*j)+b*d).
        x = bnum*scale*v
        y = 39*u*bden
        const = a*r0+b*d
        slope = a*r1
        c0 = x*r0+y*(last+1)*const
        c1 = x*r1+y*((last+1)*slope-const)
        c2 = -y*slope
        points = [start,end]
        if c2>0:
            vertex = -c1//(2*c2)
            if start<=vertex<=end:
                points.append(vertex)
            if start<=vertex+1<=end:
                points.append(vertex+1)
        if any(c0+j*(c1+j*c2)<0 for j in points):
            return False
    return True


@lru_cache
def limits_for(budget):
    """Return successive (inclusive fragment cap, inclusive full radial J)."""
    budget = Q(budget)
    if budget<0:
        raise ValueError('the Schur budget must be nonnegative')
    rate,scale,caps=inputs()
    out=[]
    inherited=caps[0].full_last
    for cap in caps:
        lower,upper=-1,min(cap.full_last,inherited)+1
        while upper-lower>1:
            middle=(upper+lower)//2
            if feasible(cap,middle,budget,rate,scale):
                lower=middle
            else:
                upper=middle
        assert feasible(cap,lower,budget,rate,scale)
        assert lower==min(cap.full_last,inherited) or not feasible(cap,lower+1,budget,rate,scale)
        inherited=lower
        if out and out[-1][1]==lower:
            out[-1]=(cap.upper,lower)
        else:
            out.append((cap.upper,lower))
    return tuple(out)


def extreme_classes(limit=10000):
    """All reachable native retained cells whose price is below -limit."""
    rate,scale,caps=inputs()
    u,v=rate.as_integer_ratio()
    denominator=10000*v
    def exceptional(j,a,b):
        r=4999*v-10000*u*(j+38)
        return (a+limit*scale)*r+b*denominator<0
    out=[]
    for cap in caps:
        interval=[]
        for left,right,a,b in cap.sectors:
            # The sign criterion is affine in j, so only straddling runs
            # require a cell-by-cell search.
            x,y=exceptional(left,a,b),exceptional(right,a,b)
            if x and y:
                interval.extend(range(left,right+1))
            elif x or y:
                interval.extend(j for j in range(left,right+1) if exceptional(j,a,b))
        if interval:
            assert interval==list(range(interval[0],interval[-1]+1))
            out.append((cap.upper,interval[0],interval[-1]))
    return out


def replay_limits(budget):
    """Explicit schedule used by the native B=6,8 score and residual replays."""
    budget=Q(budget)
    bounds=limits_for(budget)
    rate,scale,caps=inputs()
    out=[]
    for cap in caps:
        last=next(j for c,j in bounds if cap.upper<=c)
        if cap.upper>60089:
            last=min(last,130995)
        if cap.upper>63177:
            last=min(last,125499)
        assert feasible(cap,last,budget,rate,scale)
        if out and out[-1][1]==last:
            out[-1]=(cap.upper,last)
        else:
            out.append((cap.upper,last))
    assert all(x[0]<y[0] and x[1]>y[1] for x,y in zip(out,out[1:]))
    return tuple(out)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--budgets',nargs='+',default=['2','4','6','8','10'])
    args=p.parse_args()
    rare=extreme_classes()
    assert rare==[(c,130996,131032) for c in (60320,60601,61104)]+[(c,125500,125536) for c in (63645,63926,64599,65536)]
    print(json.dumps(dict(extreme_classes=rare,maximal_limits={b:limits_for(Q(b)) for b in args.budgets},
                          replay_limits={b:replay_limits(Q(b)) for b in args.budgets})))
