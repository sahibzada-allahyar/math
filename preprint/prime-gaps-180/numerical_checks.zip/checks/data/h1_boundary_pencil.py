"""Compute fine-grid mass and refined sector pencils for splines cut at the two new rectangles."""
import argparse
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
import json
from pathlib import Path
import numpy as np
from scipy.interpolate import BSpline
from endpoint_pair_scan import first_fibres
from h1_geometry_scan import instantiate
from h1_refit_two_minorants import field_from_dual,HERE
from h1_window_spectators import radial


def insert_columns(model,profile):
    spec=profile['shape_spec'];knots=list(map(Q,spec['knots']));degree=spec['degree']
    remaining=Counter(model.knots);remaining.subtract(knots)
    assert min(remaining.values())>=0 and model.spline_degree==degree
    v=np.array(profile['coefficients']).reshape(3,len(model.signatures),len(knots)-degree-1)
    s=BSpline([float(k) for k in knots],v.transpose(2,0,1),degree,axis=0)
    for k,n in sorted(remaining.items()):
        if n:s=s.insert_knot(float(k),n)
    np.testing.assert_array_equal(s.t,list(map(float,model.knots)))
    return s.c.transpose(1,2,0).reshape(3,-1)


def restrict(shells,lo,hi):
    return [(max(a,lo),min(b,hi),c) for a,b,c in shells if max(a,lo)<min(b,hi)]


def evaluate(r,trials,profiles,limits,sec,layout,nsector):
    original=r.shells['outer'];n=r.n;ng=len(trials);signatures=r.signatures
    mass=np.zeros((ng,ng));energy=np.zeros((nsector,3,ng,ng));fibres=[];arrays=[]
    for v in profiles:
        arrays.append(np.stack([((part*r.scale).reshape(-1,r.nr)@r.radial_values) for part in v]))
    for source,lo,hi,c in trials:
        try:
            r.shells['outer']=restrict(original,lo,hi)
            fibres.append(first_fibres(r,profiles[source].ravel(),[min(x,c) for x in limits]))
        finally:r.shells['outer']=original
    native=sorted(set().union(*[set(f) for f in fibres]))
    index=np.arange(n);full_cap=np.full(n,-1)
    for shell in original:full_cap[r.mask(shell,r.k)]=shell[2]
    gates=[r.mask((lo,hi,c),r.k) for _,lo,hi,c in trials]
    # Moment table entries are shared by all profiles. Keep only the sectors'
    # mass, prime-budget and five-prime-budget cross products.
    for erased in (False,True):
        cuts=sorted(set(native)|{int(c) for c in sec.caps if c<native[-1]}) if erased else native
        prev={}
        for cap in cuts:
            if erased:
                fields=[radial(f,cap,n) for f in fibres]
                sig=sorted(set().union(*[set(f) for f in fields]))
                blocks=[[f.get(s) for s in sig] for f in fields]
                ids=layout(cap,index);mults=(np.ones(n),sec.prime_upper[:n],sec.kernel[:n])
            else:
                sig=signatures
                amplitudes=[a[np.array(limits)>=cap].sum(axis=0) for a in arrays]
                blocks=[[amplitudes[j][h] if cap<=c else None for h in range(len(sig))] for j,lo,hi,c in trials]
            keys=[[tuple(sorted(x+y)) for y in sig] for x in sig]
            now={s:r.moment(cap,r.k-int(erased),s).copy() for s in set(k for row in keys for k in row)}
            delta={s:v-prev.get(s,0.) for s,v in now.items()}
            for first in range(0,n,512):
                sl=slice(first,min(n,first+512));length=sl.stop-sl.start
                M=np.empty((length,len(sig),len(sig)))
                for i,row in enumerate(keys):
                    for j,key in enumerate(row):M[:,i,j]=delta[key][sl]
                A=np.zeros((length,ng,len(sig)))
                for i,row in enumerate(blocks):
                    for j,value in enumerate(row):
                        if value is not None:A[:,i,j]=value[sl]
                    if not erased:A[:,i,:]*=(gates[i][sl]&(full_cap[sl]>=cap))[:,None]
                value=(A@M)@A.transpose(0,2,1)
                if erased:
                    value*=(r.rho*r.norm*r.inner_exp[sl])[:,None,None]
                    labels=ids[sl];starts=np.r_[0,np.flatnonzero(np.diff(labels))+1]
                    for j,m in enumerate(mults):
                        grouped=np.add.reduceat(value*m[sl,None,None],starts,axis=0)
                        np.add.at(energy[:,j],labels[starts],grouped)
                else:mass+=(value*r.outer_exp[sl,None,None]).sum(axis=0)
            prev=now;r.clear_cache()
        print('finished',('erased' if erased else 'ordinary'),'native caps',len(cuts),flush=True)
    return (mass+mass.T)/2,(energy+energy.swapaxes(-1,-2))/2


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--guide',type=Path,default=HERE/'h1_bilinear_refined_lower.json')
    ap.add_argument('--fits',nargs='+',type=Path,required=True)
    a=ap.parse_args();prev,sec,field,target,record,layout,prices=field_from_dual(a.guide,with_sectors=True)
    files=[HERE/record['trial_refit'],*a.fits];fits=[json.loads(f.read_text()) for f in files]
    base=fits[0];last=fits[-1]
    assert all(f['radius']==base['radius'] for f in fits)
    src=json.loads((HERE/'h1_k38_knn6_n32768.json').read_text())
    r,lim,_,spec,_=instantiate(src,dict(radius=base['radius'],extra_knots=last.get('extra_knots',[])),38,record['intervals'])
    assert r.exact_step==prev.exact_step and spec==last['shape_spec']
    del prev
    rho=Q(str(r.geometry['parameters']['rho_star']));S=r.geometry['parameters']['S']
    lim=record['component_limits'];v=[insert_columns(r,f) for f in fits]
    trials=[(i,Q(0),S,lim[-1]) for i in range(len(v))]
    # Local changes of the full trial, before erasure. The two fragment caps
    # give independent angular/fragment perturbations near the new boundaries.
    edges=[Q(x)/rho for x in ('.245','.252','.260099','.262099','.267','.269','.274')]+[S]
    for l,h in zip(edges,edges[1:]):trials.append((len(v)-1,l,h,lim[-1]))
    for l,h in [(edges[1],edges[4]),(edges[4],edges[-1])]:
        for c in lim[:2]:trials.append((len(v)-1,l,h,c))
    G,E=evaluate(r,trials,v,lim,sec,layout,len(prices))
    old=json.loads((HERE/'h1_bilinear_refined.json').read_text())
    error=float(abs(E[:,:,0,0]/G[0,0]-old['sector_energies']).max())
    assert error<1e-8,error
    f=a.output.with_suffix('.npz');np.savez_compressed(f,mass=G,energies=E,prices=prices)
    digest=lambda p:sha256(p.read_bytes()).hexdigest()
    out=dict(scope='Deterministic floating-point fine-grid cross forms on the frozen 209-sector partition.',
             data=f.name,data_sha256=digest(f),inputs={p.name:digest(p) for p in [*files,a.guide,HERE/'h1_bilinear_refined.json']},
             fits=[f.name for f in files],trials=[[i,str(l),str(h),c] for i,l,h,c in trials],intervals=r.N,base_error=error)
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(directions=len(trials),base_error=error)),flush=True)


if __name__=='__main__':main()
