"""Positive angular kernels, signed erasures, and cap-by-cap bilinear forms."""
import ctypes
from collections import defaultdict
from fractions import Fraction as Q
from functools import cache
from math import factorial

import numpy as np

import quotient_poly as P
from h1_two_source_endpoints import stored_frame  # installs the source dependency path
from fast_fragment_ritz import block_partitions,fiber_splits


IARRAY=np.ctypeslib.ndpointer(dtype=np.int32,ndim=1,flags='C_CONTIGUOUS')


def configure(library,bits):
    P.configure(library,bits)
    arr=P.ARRAY;ci=ctypes.c_int;dbl=ctypes.c_double
    P.LIB.gram_scalar.argtypes=[ci,arr,arr,arr,arr,IARRAY,IARRAY,ci,IARRAY,ci,
                                 arr,dbl,dbl,arr,arr,arr]
    P.LIB.gram_scalar.restype=None


def scaled_ball(a,m):
    x,r=a
    if m==1:return a
    z=m*x
    return z,P.up(P.up(m*r)+P.up(P.EPS*np.abs(z)+P.TINY))


def empty(shape):return np.zeros(shape),np.zeros(shape)


def pack(row):
    return tuple(np.vstack([v[j] for v in row]) for j in range(2))


class Laws:
    def __init__(self,site,cdf,width,core,sigs):
        self.n=len(cdf[0]);self.sigs=sigs;self.core=core
        self.t=site['t'];self.shapes=site['shapes'];self.endpoint=site['pair_shapes']
        self.marks=P.positive_product(width,P.positive_product(cdf,site['g']))
        self.square=P.positive_product(self.marks,site['g'])
        self.pair_order=[(a,b) for a in range(len(self.shapes[0])) for b in range(a,len(self.shapes[0]))]
        self.cache={}

    def get(self,key,fn):
        if key not in self.cache:self.cache[key]=fn()
        return self.cache[key]

    def tp(self,e):
        if not e:return np.ones(self.n),np.ones(self.n)
        if e==1:return self.t
        return self.get(('t',e),lambda:P.positive_product(self.tp(e//2),self.tp(e-e//2)))

    def ins(self,key):
        tag,v=key
        if tag=='power':return self.get(('i',key),lambda:P.positive_product(self.marks,self.tp(v)))
        if tag=='shape':return self.get(('i',key),lambda:P.positive_product(self.marks,tuple(x[v] for x in self.shapes)))
        assert tag=='both';a,b=v
        return self.get(('i',key),lambda:P.Positive.interval(*self.ins(('shape',a))).multiply(
                         P.Positive.interval(*self.ins(('shape',b))),self.n).bounds())

    def atom(self,e):
        return self.get(('a',e),lambda:P.Positive.interval(*P.positive_product(self.square,self.tp(e))))

    def endpoint_atom(self,e):
        return self.get(('ea',e),lambda:P.Positive.interval(*P.positive_product(self.square,tuple(v[e] for v in self.endpoint))))

    def endpoint_product(self,key):
        if len(key)==1:return self.endpoint_atom(key[0])
        return self.get(('ep',key),lambda:self.endpoint_atom(key[0]).multiply(self.endpoint_atom(key[1]),self.n))

    def count(self,d):
        if d==0:return P.Positive(np.array([1.]))
        if d==1:return self.atom(0)
        return self.get(('c',d),lambda:self.count(d//2).multiply(self.count(d-d//2),self.n))

    def group(self,part):
        if len(part)==1:return self.atom(part[0])
        return self.get(('g',part),lambda:self.group(part[:-1]).multiply(self.atom(part[-1]),self.n))

    def distinct(self,d,part):
        if not part:return self.count(d)
        if len(part)==d:return self.group(part)
        return self.get(('d',d,part),lambda:self.count(d-len(part)).multiply(self.group(part),self.n))

    def angular(self,d,sig):
        out=None
        for part,m in block_partitions(sig):
            if len(part)>d:continue
            factor=m*factorial(d)//factorial(d-len(part))
            a=self.distinct(d,part).times_integer(factor)
            out=a if out is None else out.plus(a)
        if out is None:return P.Positive(np.zeros(self.n))
        return out

    def erase(self,full):
        sigs=self.sigs;n=self.n;sh=len(self.shapes[0]);ns=len(sigs)
        dest={key:empty((rows,n)) for key,rows in [('core',ns*sh**2),('a',ns*sh),('b',ns*sh),('pair',ns)]}
        def add(key,ix,val,m=1):
            old=tuple(a[ix] for a in dest[key]);out=P.ball_add(old,scaled_ball(val,m))
            for a,b in zip(dest[key],out):a[ix]=b
        for z,s in enumerate(sigs):
            for a in range(sh):
                for b in range(sh):
                    ix=z*sh**2+a*sh+b
                    row=tuple(v[ix] for v in full);memo={}
                    def corr(key):
                        if key==('shape',0):key=('power',0)
                        if key not in memo:memo[key]=P.correlated(row,self.ins(key))
                        return memo[key]
                    for rest,e,m in fiber_splits(s):
                        add('core',sigs.index(rest)*sh**2+a*sh+b,corr(('power',e)),m)
                    add('a',z*sh+b,corr(('shape',a)))
                    add('b',z*sh+a,corr(('shape',b)))
                    add('pair',z,corr(('both',tuple(sorted((a,b))))))
        dest['full']=full
        return dest


@cache
def gram_groups(sigs,sh,retained):
    from itertools import product
    keys=tuple(product(range(sh),repeat=retained))
    pairs=[(a,b) for a in range(sh) for b in range(a,sh)]
    groups=defaultdict(lambda:defaultdict(lambda:([],[])))
    for i,s in enumerate(sigs):
        for j,t in enumerate(sigs):
            sig=tuple(sorted(s+t))
            for a,left in enumerate(keys):
                for b,right in enumerate(keys):
                    key=tuple(sorted(pairs.index(tuple(sorted(pos))) for pos in zip(left,right)))
                    l,r=groups[sig][key];l.append(i*len(keys)+a);r.append(j*len(keys)+b)
    return {sig:{key:tuple(np.asarray(v,dtype=np.int32) for v in values) for key,values in group.items()}
            for sig,group in groups.items()}


class Integral:
    def __init__(self):self.low=Q(0);self.high=Q(0)

    def add(self,centre,error):
        c,r=Q(float(centre)),Q(float(error))
        self.low+=c-r;self.high+=c+r


def contract(law,d,retained,forms):
    """A form is (accumulator, left field, right field, weight ball, indices)."""
    if not forms:return
    sh=len(law.shapes[0]);n=law.n
    groups=gram_groups(tuple(law.sigs),sh,retained)
    cast=lambda a:tuple(np.ascontiguousarray(v).reshape(-1) for v in a)
    prepared=[(out,cast(a),cast(b),cast(w),np.ascontiguousarray(ix,dtype=np.int32)) for out,a,b,w,ix in forms if len(ix)]
    if not prepared:return
    result=np.empty(2)
    for sig,keys in groups.items():
        core=law.angular(d,sig)
        for key,(left,right) in keys.items():
            kernel=core.multiply(law.endpoint_product(key),n) if key else core
            for out,a,b,w,ix in prepared:
                P.LIB.gram_scalar(n,*a,*b,left,right,len(left),ix,len(ix),kernel.low,kernel.relative,kernel.absolute,*w,result)
                out.add(*result)
