"""Exact volume and prime mass of the parent triples in the scale-only obstruction."""
import argparse
from fractions import Fraction as Q
from itertools import product
import json
from math import ceil,comb,factorial,floor
from pathlib import Path


def product_moment(n,lo,hi):
    # Inclusion-exclusion over the three upper faces in alpha_1+alpha_2+alpha_3=1.
    result=Q(0)
    for j in range(4):
        b=[hi]*j+[lo]*(3-j);r=1-sum(b)
        if r<=0:continue
        coeff=[[comb(n,i)*u**(n-i)*factorial(i) for i in range(n+1)] for u in b]
        integral=sum(coeff[0][i]*coeff[1][j]*coeff[2][k]*r**(i+j+k+2)/factorial(i+j+k+2)
                     for i,j,k in product(range(n+1),repeat=3))
        result+=(-1)**j*comb(3,j)*integral
    return result


def obstruction(colors,I,a,c):
    b=sorted(colors,reverse=True);L=1-a
    assert sum(b)==1 and b[0]<a and b[-1]>L-I
    upper=[min(x,I) for x in b]
    cap=upper[1]+upper[2]
    S=(L+min(1-c,cap))/2
    v2,v3=(S*u/cap for u in upper[1:]);large=[v2,v2,v3]
    tail=[(u-v)/4 for u,v in zip(b,large)]
    assert L<S<1-c and max(large)<I and min(large)>L-I
    assert min(tail)>0 and max(tail)<Q(1,20)
    # With at most one large factor, even the largest subset stays below a.
    # With two or more, even the smallest pair is above L.
    assert max(large)+4*sum(tail)<a and min(large[0]+large[1],large[1]+large[2])>L
    assert 4*sum(tail)<1-2*c
    return dict(colors=list(map(str,b)),large=list(map(str,large)),four_equal_tail_factors_per_color=list(map(str,tail)))


def mass_bounds(lo,hi,degree):
    verts=sorted(set((x,y,1-x-y) for x,y in product((lo,hi),repeat=2) if lo<=1-x-y<=hi))
    area=product_moment(0,lo,hi)
    qmax=max(1-27*x*y*z for x,y,z in verts)
    assert 0<qmax<1
    moments=[product_moment(j,lo,hi) for j in range(degree+1)]
    integ=[sum(comb(j,n)*(-27)**n*moments[n] for n in range(j+1)) for j in range(degree+1)]
    assert all(0<x<=area*qmax**j for j,x in enumerate(integ))
    lower=9*sum(integ);upper=lower+9*area*qmax**(degree+1)/(1-qmax)
    return dict(parent_area=str(area/3),amgm_lower=str(9*area),max_geometric_ratio=str(qmax),
                degree=degree,lower_millionths=floor(lower*10**6),upper_millionths=ceil(upper*10**6)),verts


def enclose(theta,delta,degree=6):
    omega=(theta-Q(1,2))/2
    a=Q(3,10)+8*omega+Q(16,5)*delta
    I=Q(1,4)+7*omega+2*delta
    c=Q(7,15)-Q(56,15)*omega-Q(4,15)*delta
    L=1-a;zeta=L-I
    assert Q(2,5)<a<Q(5,12) and Q(1,10)<1-2*a<zeta<I<c<a
    assert 3*I+7*a<4 and 2*I+3*a<2 and 2*I+a>1
    assert 68*omega+14*delta<1 and 1-3*L/2<min(Q(1,5),1-2*c)
    bounds,verts=mass_bounds(zeta,a,degree)
    residual_limit=(8-14*theta-2*delta)/5
    ub=min((1-c)/2,(1-residual_limit)/3,I,Q(1,3))
    assert zeta<L/2<ub
    central,_=mass_bounds(L/2,a,degree)
    centre=(Q(1,3),)*3
    examples=[obstruction(centre,I,a,c)]+[obstruction([(x+y)/2 for x,y in zip(v,centre)],I,a,c) for v in verts]
    return dict(theta=str(theta),delta=str(delta),a=str(a),I=str(I),c=str(c),zeta=str(zeta),
                **bounds,examples=examples,residual_limit=str(residual_limit),central_subregion=central)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    rows=[enclose(Q(t),Q('0.000001')) for t in ('.52842','.5285','.5288','.5290','.5291')]
    data=dict(scope='Parent-level Gamma3 discard in the stated scale-only model; not an unavoidable deficit for general minorants.',rows=rows)
    a.output.write_text(json.dumps(data,indent=2)+'\n')
    for r in rows:print(float(Q(r['theta'])),r['lower_millionths'],r['upper_millionths'])


if __name__=='__main__':main()
