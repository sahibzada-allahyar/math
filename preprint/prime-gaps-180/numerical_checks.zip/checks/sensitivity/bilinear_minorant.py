"""Check strict Type I/II-only cutoffs, both defect masses, and a singleton-mark square kernel."""
import argparse
from fractions import Fraction as Q
from hashlib import sha256
import json
from math import ceil,floor
from pathlib import Path
import sys
from gamma3_projection import mass_bounds

HERE=Path(__file__).resolve().parent
OTHER=HERE.parent/'data'
sys.path.insert(0,str(OTHER))
from h1_distribution_frontier import deficit


def kernel(zeta,a,q,retreat=Q(1,10000),bins=512):
    # Bound (2/3) integral ds/(s z(s,q)) by enclosing each factor per bin.
    # The upper/lower running sums use directed fixed-point rounding.
    unit=10**12;dx=(a-zeta)/bins;lo=hi=0
    for i in range(bins):
        l=zeta+i*dx;r=l+dx
        Zlo=min(zeta,(1-r)/2-q)-retreat
        Zhi=min(zeta,(1-l)/2-q)-retreat
        assert 0<Zlo<=Zhi
        lo+=floor(unit*2*dx/(3*r*Zhi));hi+=ceil(unit*2*dx/(3*l*Zlo))
    return [lo,hi]


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    guards=OTHER/'h1_exact_distribution_frontier.json'
    data=json.loads(guards.read_text())
    tau=Q(data['band_padding'])
    rows=[];delta=Q(1,10**6);handoff=Q('.46')
    handoff_slopes={'handoff_above_lower_band':1,'handoff_Polymath_lower':1,
                    'source_upper_at_handoff':-1,'Farey_volume_at_handoff':-2,'DD_u_target_lower':-1}
    # c occurs only in the Type III part of this construction. Keep the
    # redundant color-capacity guards used again for the five-prime addback.
    omitted={'a_lt_c','c_lt_1_over_2','III_individual_singleton_lower','III_individual_singleton_upper',
             'III_individual_pair_lower','III_rough_singleton_lower','finite_III_main','finite_III_secondary',
             'negative_III_diagonal','negative_III_zero_frequency','negative_III_o1','negative_III_o2',
             'negative_III_o4','III_split_positive','III_split_below_extraction_endpoint'}
    assert omitted<=data['affine_guard_coefficients'].keys()
    for theta in map(Q,('.52842','.5285','.5288','.5290','.5291','.52916')):
        w=(theta-Q(1,2))/2
        a=Q(3,10)+8*w+Q(16,5)*delta+tau+Q('0.000002')
        I=Q(1,4)+7*w+2*delta+tau+Q('0.00001')
        zeta=1-a-I;rough=1-2*a
        slacks={}
        for name,coeff in data['affine_guard_coefficients'].items():
            if name in omitted:continue
            v=list(map(Q,coeff));assert not v[4]
            slack=sum(x*y for x,y in zip(v,[1,theta,a,I,0,delta]))+handoff_slopes.get(name,0)*(handoff-Q('.45'))
            assert slack>0,(theta,name,slack)
            slacks[name]=str(slack)
        assert theta+a<1 and rough>Q(1,6) and zeta>rough
        three,_=mass_bounds(zeta,a,7);five=deficit(a)
        lower=1-Q(three['upper_millionths'],10**6)-Q(five['upper'])
        upper=1-Q(three['lower_millionths'],10**6)-Q(five['lower'])
        qs=list(map(Q,('0','.1','.2','.24','.26','.275','.284')))
        kernels={str(q):kernel(zeta,a,q) for q in qs}
        rows.append(dict(theta=str(theta),delta=str(delta),a=str(a),I=str(I),zeta=str(zeta),rough=str(rough),
                         strict_slacks=slacks,three_mass=three,five_mass=five,
                         retained_lower_millionths=floor(lower*10**6),retained_upper_millionths=ceil(upper*10**6),
                         singleton_kernel_trillionths=kernels))
        print(float(theta),rows[-1]['retained_lower_millionths'],kernels['0'][0]/1e12,
              kernels[str(qs[-1])][1]/1e12,flush=True)
    out=dict(scope='Conditional on the cited convolution and Harman decomposition inputs. No finite H1 sieve crossing.',
             guards=guards.name,guards_sha256=sha256(guards.read_bytes()).hexdigest(),
             unused_Type_III_guards=sorted(omitted),bilinear_handoff=str(handoff),
             kernel_bins=512,kernel_retreat='1/10000',rows=rows)
    args.output.write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
