"""Shared Monte Carlo machinery for restoration estimates (heuristic, floating point).

Measure: each coordinate is an independent copy of nu_zeta (Poisson du/u on (0,zeta],
mass e^gamma zeta); its total has density rho_D(t/zeta) dt and, given the total, the
largest fragment u satisfies P(u <= y | t, cap c) = rho(t/y)/rho(t/c)  (y <= min(c,t)).
Profiles are evaluated exactly as in Theo's cell model (cell midpoints, whole-cell upper
totals for the cap shells); the arithmetic predicates use the actual fragments and totals.
"""
import json, os
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent

# ---------------------------------------------------------------- Dickman rho
_DX = 1.0e-4
_XMAX = 60.0
_per = int(round(1 / _DX))
_npts = int(round(_XMAX / _DX)) + 1
_xs = np.arange(_npts) * _DX
_lst = [1.0] * (_per + 1)          # rho = 1 on [0,1]
for m in range(1, int(_XMAX)):
    prev = _lst[(m - 1) * _per:(m * _per) + 1]          # values on [m-1, m], length per+1
    suff = np.concatenate([np.cumsum(np.array(prev[::-1]))[::-1], [0.0]])  # suff[a] = sum prev[a:]
    run = 0.0
    base = m * _per
    for d in range(1, _per + 1):                        # i = base + d
        i = base + d
        x = i * _DX
        # interior l in [i-per+1, base] -> prev index [d+1-1 ... per] i.e. prev[d:per+1]... minus endpoint handling
        first = suff[d + 1] if d + 1 <= _per else 0.0   # prev[d+1 .. per]  == l in [i-per+1, base]
        # prev[d] is rho_{i-per}; prev[per] == rho_base already counted in first (when d+1<=per)
        val = _DX * (prev[d] / 2 + first + run) / (x - _DX / 2)
        _lst.append(val)
        run += val
_rho = np.array(_lst[:_npts])
_xs = _xs[:len(_rho)]
_rho = np.maximum(_rho, 1e-300)
_logrho = np.log(_rho)
# decreasing branch x>=1 for inversion
_i1 = _per
_xinv = _xs[_i1:][::-1]
_linv = _logrho[_i1:][::-1]      # increasing


def rho(x):
    x = np.asarray(x, float)
    out = np.exp(np.interp(np.minimum(x, _XMAX), _xs, _logrho))
    return np.where(x > _XMAX, 0.0, np.where(x <= 1, 1.0, out))


def rho_inv(y):
    """x>=1 with rho(x)=y, for 0<y<=1."""
    ly = np.log(np.maximum(y, 1e-300))
    return np.interp(ly, _linv, _xinv)


def largest(t, cap, rng):
    """Sample the largest fragment of a coordinate with total t and fragment cap `cap`."""
    t = np.asarray(t, float); cap = np.broadcast_to(cap, t.shape)
    u = rng.random(t.shape)
    pos = t > 0
    r0 = rho(np.where(pos, t / np.maximum(cap, 1e-300), 0.))
    x = rho_inv(u * r0)                 # t/u1
    out = np.where(pos, t / np.maximum(x, 1e-300), 0.)
    return np.minimum(out, np.minimum(cap, t))


def fragments(t, cap, umin, rng, maxlev=40):
    """All fragments >= umin (descending, padded with 0) and the dust below umin.
    t, cap: arrays of equal shape (...,).  Returns (frags[..., L], dust[...])."""
    t = np.asarray(t, float).copy(); cap = np.broadcast_to(np.asarray(cap, float), t.shape).copy()
    out = []
    active = t > 0
    for _ in range(maxlev):
        if not active.any():
            break
        u = np.zeros_like(t)
        idx = np.flatnonzero(active.ravel())
        tt = t.ravel()[idx]; cc = cap.ravel()[idx]
        v = largest(tt, cc, rng)
        ok = v >= umin
        vv = np.where(ok, v, 0.)
        u.ravel()[idx] = vv
        out.append(u)
        t.ravel()[idx] = tt - vv
        cap.ravel()[idx] = np.where(ok, vv, cc)
        act = active.ravel().copy(); act[idx] = ok & (tt - vv > 0)
        active = act.reshape(t.shape)
    frags = np.stack(out, axis=-1) if out else np.zeros(t.shape + (1,))
    return frags, t   # remaining t is dust (< umin)


# ---------------------------------------------------------------- trial
class Trial:
    def __init__(self, folder=HERE, name=None):
        name = name or os.environ.get('RTRIAL', 'trial38')
        z = np.load(folder / f'{name}.npz')
        self.z = {k: z[k] for k in z.files}
        self.m = json.loads((folder / f'{name}_meta.json').read_text())
        m = self.m
        self.k, self.n, self.h, self.S, self.rhos = m['k'], m['n'], m['h'], m['S'], m['rho']
        self.zeta = m['zeta']
        self.sigs = [tuple(s) for s in m['signatures']]
        self.rests = [tuple(s) for s in m['rests']]
        self.amp = self.z['amp']; self.full_cap = self.z['full_cap']; self.W = self.z['W']
        self.fcaps = self.z['fibre_caps']; self.limits = self.z['limits']
        self.g = self.z['g']
        self.tcaps = self.z['tcaps']; self.sector = self.z['sector']; self.prices = self.z['prices']
        self.pu = self.z['prime_upper']; self.ker = self.z['kernel']
        self.redges = self.z['radius_edges']; self.cedges = self.z['cap_edges']
        self.leaf = self.z['leaf']; self.tiles = m['tiles']
        # leaf lookup table over (radial bin 0..7 by eighths of x, cap bin 0..7)
        L = np.full((8, 8), -1)
        for i, (a, b, c, d) in enumerate(self.tiles):
            L[a:b, c:d] = i
        assert (L >= 0).all()
        self.leaf_table = self.leaf[L]

    # power sums of midpoints, p=2..6
    def psums(self, tmid):
        return {p: (tmid ** p).sum(axis=-1) for p in range(2, 7)}

    @staticmethod
    def sigval(ps, sig):
        out = 1.0
        for p in sig:
            out = out * ps[p]
        return out

    def cells(self, t):
        j = np.floor(t / self.h).astype(np.int64)
        return np.minimum(j, self.n + 10)

    def F(self, t, M0, tile=True):
        """Profile at full roots: t[...,k] coordinate totals, M0[...] largest fragment."""
        k, h, n = self.k, self.h, self.n
        j = self.cells(t)
        r = j.sum(axis=-1)
        tmid = (j + .5) * h
        inside = r <= n - 1
        rr = np.where(inside, r, 0)
        ps = self.psums(tmid)
        m_cells = M0 / h
        ok = inside & (m_cells <= self.full_cap[rr])
        val = np.zeros(r.shape)
        for c in range(len(self.limits)):
            act = ok & (m_cells <= self.limits[c])
            if not act.any():
                continue
            acc = np.zeros(r.shape)
            for si, sig in enumerate(self.sigs):
                acc += self.amp[c, si][rr] * self.sigval(ps, sig)
            val += np.where(act, acc, 0.)
        val *= np.prod(self.gfun(tmid), axis=-1)
        if tile:
            end = (r + k) * h
            xb = self.eighth_radial(end)
            yb = np.clip(np.searchsorted(self.cedges * h, M0, side='left') - 1, 0, 7)
            val *= self.leaf_table[xb, yb]
        return np.where(ok, val, 0.)

    def eighth_radial(self, end):
        # redges[i] = S*(0.7+3i/80) for i>=1, 0 for i=0: bin i means end in (redges[i], redges[i+1]]
        e = self.redges
        xb = np.searchsorted(e, end, side='left') - 1
        return np.clip(xb, 0, 7)

    def gfun(self, t):
        # exact one-coordinate factor (7.2) with the trial's profile constants
        return (21 / 200) / (1 + t / 100) + (179 / 200) / (1 + (907 / 5) * t)

    def V(self, t, M0):
        """Erased fibre at retained roots: t[..., k-1], M0[...]. Includes h * prod g."""
        h, n = self.h, self.n
        j = self.cells(t)
        r = j.sum(axis=-1)
        tmid = (j + .5) * h
        inside = r <= n - 1
        rr = np.where(inside, r, 0)
        ps = self.psums(tmid)
        layer = np.searchsorted(self.fcaps, M0 / h, side='left')
        okl = layer < len(self.fcaps)
        ll = np.where(okl, layer, 0)
        acc = np.zeros(r.shape)
        for si, sig in enumerate(self.rests):
            acc += self.W[ll, si, rr] * self.sigval(ps, sig)
        acc *= h * np.prod(self.gfun(tmid), axis=-1)
        return np.where(inside & okl, acc, 0.)

    def multiplier(self, t, M0):
        """Theo's four-measure sector price a'(Y) at retained roots (prices of h1_cover_72_prices)."""
        h, n = self.h, self.n
        j = self.cells(t)
        r = j.sum(axis=-1)
        inside = r <= self.sector.shape[1] - 1
        rr = np.where(inside, r, 0)
        ci = np.searchsorted(self.tcaps, M0 / h, side='left')
        okc = ci < len(self.tcaps)
        cc = np.where(okc, ci, 0)
        sec = self.sector[cc, rr]
        p = self.prices[sec]
        a = p[..., 0] + p[..., 1] * self.pu[rr] + p[..., 2] * self.ker[rr]
        return np.where(inside & okc, a, 0.), np.where(inside & okc, sec, -1)


# ---------------------------------------------------------------- proposals
class Proposal:
    """Piecewise-constant density pi_beta(t) ~ g(t)^2 rho(t/cap) exp(-beta t) on [0,S]."""
    def __init__(self, S, gfun, betas, cap, ngrid=200000):
        self.edges = np.linspace(0, S, ngrid + 1)
        mid = (self.edges[1:] + self.edges[:-1]) / 2
        self.w = np.diff(self.edges)
        base = gfun(mid) ** 2 * rho(mid / cap)
        self.betas = np.array(betas, float)
        self.dens = []; self.cdf = []; self.mean = []
        for b in self.betas:
            d = base * np.exp(-b * mid)
            mass = d * self.w
            Z = mass.sum()
            self.dens.append(d / Z)
            c = np.concatenate([[0.], np.cumsum(mass) / Z])
            self.cdf.append(c)
            self.mean.append((mass * mid).sum() / Z)
        self.dens = np.array(self.dens); self.cdf = np.array(self.cdf); self.mean = np.array(self.mean)

    def sample(self, bi, size, rng):
        """bi: beta index per row (shape (R,)), size: columns per row."""
        bi = np.asarray(bi)
        u = rng.random((len(bi), size))
        out = np.empty_like(u)
        for b in np.unique(bi):
            rows = bi == b
            out[rows] = np.interp(u[rows], self.cdf[b], self.edges)
        return out

    def density(self, bi, t):
        k = np.clip(np.searchsorted(self.edges, t, side='right') - 1, 0, len(self.w) - 1)
        return self.dens[np.asarray(bi)[:, None], k]


# ---------------------------------------------------------------- retained-root helpers
def _shell_member(shells, end, M0, h):
    ok = np.zeros(np.shape(end), bool)
    for lo, hi, cap in shells:
        ok |= (end > lo) & (end <= hi) & (M0 <= cap * h)
    return ok


def V_from(T, r, ps, prodg, M0):
    """V at retained roots given retained cell sum r, midpoint power sums ps{p:...}, prod g, M0."""
    inside = (r >= 0) & (r <= T.n - 1)
    rr = np.where(inside, r, 0)
    layer = np.searchsorted(T.fcaps, M0 / T.h, side='left')
    okl = layer < len(T.fcaps)
    ll = np.where(okl, layer, 0)
    acc = np.zeros(np.shape(r))
    for si, sig in enumerate(T.rests):
        acc += T.W[ll, si, rr] * T.sigval(ps, sig)
    return np.where(inside & okl, acc * T.h * prodg, 0.)


def mult_from(T, r, M0):
    inside = (r >= 0) & (r <= T.sector.shape[1] - 1)
    rr = np.where(inside, r, 0)
    ci = np.searchsorted(T.tcaps, M0 / T.h, side='left')
    okc = ci < len(T.tcaps)
    cc = np.where(okc, ci, 0)
    sec = T.sector[cc, rr]
    p = T.prices[sec]
    a = p[..., 0] + p[..., 1] * T.pu[rr] + p[..., 2] * T.ker[rr]
    return np.where(inside & okc, a, 0.), np.where(inside & okc, sec, -1)


def aH_from(T, r, M0):
    """182-style hybrid multiplier on retained roots for the main 38-shift geometry:
    1 on H0, 1-ell on H1\\H0, 0 on HC\\H1, -d_h K outside HC (d_h K=(1/ell-1)kappa K(q))."""
    m = T.m
    end = (r + T.k - 1) * T.h
    ell = m['hybrid_lambda']; kap = m['kappa']
    H0 = _shell_member(m['shells_base'], end, M0, T.h)
    H1 = _shell_member(m['shells_enlarged'], end, M0, T.h)
    HC = _shell_member(m['domains']['row_14_optimized'], end, M0, T.h) | H1
    rr = np.clip(r, 0, T.n - 1)
    dK = (1 / ell - 1) * kap * T.ker[rr]
    return np.where(H0, 1., np.where(H1, 1 - ell, np.where(HC, 0., -dK))), H0, H1, HC
