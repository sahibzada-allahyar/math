import Mathlib.Analysis.Real.Sqrt
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity

/-! A rational upper bound on square-root discrepancy, including zero atoms.
This avoids millions of directed square roots in the physical-law comparison. -/
namespace PrimeGap180.RationalHellinger

theorem atom {x u l v e : ℝ} (xp : 0 ≤ x) (up : 0 ≤ u) (lp : 0 < l) (l1 : l ≤ 1)
    (low : l*u ≤ x) (high : x ≤ v*u) (err : |x-u| ≤ e) :
    (Real.sqrt x-Real.sqrt u)^2 ≤ e^2/((1+l)^2*u) := by
  by_cases off : u=0
  · subst u
    have z : x=0 := le_antisymm (by simpa using high) xp
    simp [z]
  have positive : 0 < u := lt_of_le_of_ne up (Ne.symm off)
  have h1 := Real.sq_sqrt xp
  have h2 := Real.sq_sqrt up
  have lowerRoot : l*Real.sqrt u ≤ Real.sqrt x := by
    apply (sq_le_sq₀ (mul_nonneg lp.le (Real.sqrt_nonneg u)) (Real.sqrt_nonneg x)).mp
    rw [mul_pow,h2,h1]
    have ll : l^2 ≤ l := by nlinarith only [mul_nonneg lp.le (sub_nonneg.mpr l1)]
    exact (mul_le_mul_of_nonneg_right ll up).trans low
  have order : (1+l)*Real.sqrt u ≤ Real.sqrt x+Real.sqrt u := by linarith only [lowerRoot]
  have sl := pow_le_pow_left₀ (mul_nonneg (by linarith : (0:ℝ) ≤ 1+l) (Real.sqrt_nonneg u)) order 2
  rw [mul_pow,h2] at sl
  have dif : x-u=(Real.sqrt x-Real.sqrt u)*(Real.sqrt x+Real.sqrt u) := by nlinarith only [h1,h2]
  have ed := pow_le_pow_left₀ (abs_nonneg (x-u)) err 2
  rw [sq_abs,dif,mul_pow] at ed
  apply (le_div_iff₀ (by positivity)).mpr
  exact (mul_le_mul_of_nonneg_left sl (sq_nonneg _)).trans ed

theorem interval {x u a b : ℝ} (low : a ≤ x) (high : x ≤ b) :
    |x-u| ≤ max (u-a) (b-u) := by
  apply abs_le.mpr
  constructor
  · linarith only [le_max_left (u-a) (b-u),low]
  · linarith only [le_max_right (u-a) (b-u),high]

/-- The already recorded site bounds retain enough margin for this denominator. -/
theorem slack : ((0.000000006158887:ℝ)^2*(1+(1.000003698086+1)/2)^2)/(4*0.9999999996734)
    < (0.000000006159:ℝ)^2 := by norm_num

#print axioms atom
end PrimeGap180.RationalHellinger
