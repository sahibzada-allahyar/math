import TrialCentralResidual180

/-! Decode the comparisons that can occur on a noncentral ordered tuple.
The integer counts can be reduced in Lean's kernel. -/
namespace PrimeGap180.Central

def bitAt {n : ℕ} (s l : Fin n → Bool) (p : Fin n → Fin n → Bool) : Keys n → Bool
  | .inl _ => true
  | .inr (.inl (j,i)) => ![true,s i,l i] j
  | .inr (.inr (j,t)) => ![true,p t.1.1 t.1.2,!(p t.1.1 t.1.2)] j

def signature {n : ℕ} (s l : Fin n → Bool) (p : Fin n → Fin n → Bool) :=
  Finset.univ.filter fun j => bitAt s l p j = true

@[simp] theorem mem_signature {n : ℕ} (s l : Fin n → Bool) (p : Fin n → Fin n → Bool) (k : Keys n) :
    k ∈ signature s l p ↔ bitAt s l p k = true := by
  simp only [signature,Finset.mem_filter,Finset.mem_univ,true_and]

def signatureWeight {n : ℕ} (s l : Fin n → Bool) (p : Fin n → Fin n → Bool) : ℤ :=
  let T₁ := (Finset.univ.filter (fun i => s i = true)).card
  let T₂ := (Finset.univ.filter fun t : Fin n × Fin n =>
    s t.2 = true ∧ t.1 < t.2 ∧ p t.1 t.2 = true).card
  let T₃ := (Finset.univ.filter fun t : Fin n × Fin n =>
    s t.2 = true ∧ (t.1 < t.2 ∧ p t.1 t.2 = false) ∧ l t.1 = true).card
  let T₄ := (Finset.univ.filter fun t : Fin n × Fin n × Fin n =>
    t.1 < t.2.1 ∧ l t.1 = true ∧ (t.2.1 < t.2.2 ∧ p t.2.1 t.2.2 = true) ∧ s t.2.2 = true).card
  let T₅ := (Finset.univ.filter fun t : Fin n × Fin n × Fin n =>
    t.1 < t.2.1 ∧ t.2.1 ≠ t.2.2 ∧ l t.2.1 = true ∧ s t.2.2 = true ∧
    t.1 < t.2.2 ∧ p t.1 t.2.2 = true).card
  let five := n = 5 ∧ ∀ i j, i < j → p i j = true
  let three := n = 3 ∧ ∀ i, l i = false ∧ s i = true
  show ℤ from -(if five then 24 else 0) - (if three then 2 else 0) - (1-(T₁:ℤ)+T₂+T₃-T₄-T₅)

theorem residual_signature {n : ℕ} (s l : Fin n → Bool) (p : Fin n → Fin n → Bool) :
    residualWeight (signature s l p) = signatureWeight s l p := by
  classical
  have h : (∀ i j, i < j → i < j ∧ p i j = true) ↔ (∀ i j, i < j → p i j = true) :=
    ⟨fun h i j hij => (h i j hij).2, fun h i j hij => ⟨hij,h i j hij⟩⟩
  simp [residualWeight,bitAt,signatureWeight,and_assoc,h]

noncomputable section
open scoped BigOperators Classical

def initialFlags {n : ℕ} (u : Fin n → ℝ) (a : ℝ) : Fin n → Bool :=
  fun i => decide (u i < a)

def pairFlags {n : ℕ} (u : Fin n → ℝ) (a : ℝ) : Fin n → Fin n → Bool :=
  fun i j => decide (i < j ∧ u i + u j < a)

abbrev collar : ℝ := 1 / 1000000000000

def separated (a v : ℝ) : Prop := v < a-collar ∨ 1-a+collar < v

structure CutParameters (a ζ : ℝ) : Prop where
  low : 41361/100000 ≤ a
  high : a ≤ 41657/100000
  zlow : 23/100 < ζ
  zhigh : ζ < 24/100
  zfive : 4*a-1 < 3*ζ

end
end PrimeGap180.Central
