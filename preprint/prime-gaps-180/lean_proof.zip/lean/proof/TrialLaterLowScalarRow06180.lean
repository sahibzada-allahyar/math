import TrialLaterLowFixedGrid180
namespace PrimeGap180.LaterLowFixed
set_option maxHeartbeats 0
set_option maxRecDepth 131072

theorem scalar_row_06 : bookU 30000 6 0 = 9105556386512150577812 ∧ bookU 30000 6 1050 = 992918267150902035195 ∧
    rawQ 40000 6 1050 9105556386512150577812 992918267150902035195 * 100^39 / (94.17312:ℚ) ≤ 77804134/10^18 := by decide +kernel

#print axioms scalar_row_06
end PrimeGap180.LaterLowFixed
