import PrimeGaps186

/-! Selection of one long smooth factor in each of three prime intervals.
The interval endpoints are variables. A large slot has exponent > B-A. -/

open scoped BigOperators
open Finset
namespace PrimeGap180
noncomputable section
variable {ι : Type*} [DecidableEq ι]

private theorem heavy_pair {w : ι → ℝ} {A B : ℝ} {s : Finset ι}
    (hgap : ∀ t : Finset ι, (∑ i ∈ t, w i) < A ∨ B < ∑ i ∈ t, w i)
    (hlarge : A ≤ ∑ i ∈ s, w i) :
    B < ∑ i ∈ s.filter (fun i => B-A < w i), w i := by
  classical
  let t := s.filter (fun i => B-A < w i)
  rcases hgap t with h | h
  · have sub : t ⊆ s := filter_subset _ _
    have inc := PrimeGap186.sum_add_sum_lt_of_no_subset_sum_in_Icc w A B
      (fun u hu => (hgap u).elim (fun h => (not_lt_of_ge hu.1) h)
                                  (fun h => (not_lt_of_ge hu.2) h))
      t (s \ t) disjoint_sdiff_self_left.symm h (by
        intro i hi
        exact le_of_not_gt (fun hwi => (mem_sdiff.mp hi).2 (mem_filter.mpr ⟨(mem_sdiff.mp hi).1, hwi⟩)))
    have heq := sum_sdiff (f := w) sub
    linarith only [hlarge, inc, heq]
  · exact h

private theorem at_most_three {w : ι → ℝ} {A B : ℝ} {s : Finset ι}
    (hn : ∀ i, 0 ≤ w i) (hthree : A ≤ 3 * (B-A))
    (hgap : ∀ t : Finset ι, (∑ i ∈ t, w i) < A ∨ B < ∑ i ∈ t, w i)
    (hs : (∑ i ∈ s, w i) < 4*B/3) :
    (s.filter (fun i => B-A < w i)).card ≤ 3 := by
  classical
  by_contra! h
  obtain ⟨v, hv, hcard⟩ := exists_subset_card_eq (s := s.filter (fun i => B-A < w i))
    (n := 4) (by omega)
  have htrip (i : ι) (hi : i ∈ v) : B < ∑ j ∈ v.erase i, w j := by
    have hc : (v.erase i).card = 3 := by rw [card_erase_of_mem hi, hcard]
    have hbound := sum_le_sum (s := v.erase i) (f := fun _ => B-A) (g := w)
      (fun j hj => (mem_filter.mp (hv (mem_of_mem_erase hj))).2.le)
    simp only [sum_const, nsmul_eq_mul, hc, Nat.cast_ofNat] at hbound
    exact (hgap _).resolve_left (not_lt_of_ge (hthree.trans hbound))
  have htotal := sum_le_sum (s := v) (f := fun _ => B)
    (g := fun i => (∑ j ∈ v, w j) - w i) (fun i hi => by
      have heq := sum_erase_add v w hi
      linarith only [htrip i hi, heq])
  simp only [sum_sub_distrib, sum_const, nsmul_eq_mul, hcard, Nat.cast_ofNat] at htotal
  have hsub := sum_le_sum_of_subset_of_nonneg (hv.trans (filter_subset _ _))
    (fun i _ _ => hn i)
  linarith only [hs, htotal, hsub]

private theorem one_heavy {w : ι → ℝ} {A B I : ℝ} {p q r : Finset ι}
    (hn : ∀ i, 0 ≤ w i) (hI : ∀ i, w i < I)
    (hAB : A < B) (hB : 0 < B) (hjump : A ≤ B/2 + (B-A)) (hshort : A ≤ 2*(B-I))
    (hgap : ∀ t : Finset ι, (∑ i ∈ t, w i) < A ∨ B < ∑ i ∈ t, w i)
    (hpq : Disjoint p q) (hpr : Disjoint p r) (hqr : Disjoint q r)
    (hp : (∑ i ∈ p, w i) < A) (hq : (∑ i ∈ q, w i) < A)
    (hheavy : ∀ i ∈ p, B-A < w i)
    (hpqc : p.card + q.card ≤ 3) (hprc : p.card + r.card ≤ 3)
    (hpql : B < (∑ i ∈ p, w i) + ∑ i ∈ q, w i)
    (hqrl : B < (∑ i ∈ q, w i) + ∑ i ∈ r, w i) : p.card = 1 := by
  classical
  have hpne : p ≠ ∅ := by
    rintro rfl
    simp only [sum_empty, zero_add] at hpql
    linarith
  have hpos := card_pos.mpr (nonempty_iff_ne_empty.mpr hpne)
  by_contra hnot
  have hc : (q ∪ r).card ≤ 2 := by rw [card_union_of_disjoint hqr]; omega
  have hex : ∃ b ∈ q ∪ r, B/2 < w b := by
    by_contra! h
    have hs := sum_le_sum h
    simp only [sum_const, nsmul_eq_mul, sum_union hqr] at hs
    have hc' : ((q ∪ r).card : ℝ) ≤ 2 := by exact_mod_cast hc
    rw [card_union_of_disjoint hqr, Nat.cast_add] at hc'
    nlinarith only [hs, hqrl, mul_le_mul_of_nonneg_right hc' (show 0 ≤ B/2 by linarith only [hB])]
  obtain ⟨b, hb, hb'⟩ := hex
  have hbn : b ∉ p := fun hbp => (mem_union.mp hb).elim
    (fun hbq => disjoint_left.mp hpq hbp hbq) (fun hbr => disjoint_left.mp hpr hbp hbr)
  have hweight (i : ι) (hi : i ∈ p) : B-I < w i := by
    have hne : i ≠ b := fun e => hbn (e ▸ hi)
    have split := hgap {i,b}
    simp [sum_insert, hne] at split
    rcases split with small | large
    · linarith only [small, hheavy i hi, hb', hjump]
    · linarith only [large, hI b]
  obtain ⟨t, htp, ht⟩ := exists_subset_card_eq (s := p) (n := 2) (by omega)
  have hl := sum_le_sum (s := t) (f := fun _ => B-I) (g := w) (fun i hi => (hweight i (htp hi)).le)
  simp only [sum_const, nsmul_eq_mul, ht, Nat.cast_ofNat] at hl
  have hl' := sum_le_sum_of_subset_of_nonneg htp (fun i _ _ => hn i)
  linarith only [hl, hl', hp, hshort]

/-- If no middle subset or long smooth slot occurs, each of the three parents
has precisely one slot exceeding the gap width, and every selected pair exceeds B. -/
theorem select_three_parent_slots (w : ι → ℝ) (parent : Fin 3 → Finset ι) (A B I : ℝ)
    (hn : ∀ i, 0 ≤ w i) (hI : ∀ i, w i < I) (hAB : A < B) (hB : 0 < B)
    (hthree : A ≤ 3*(B-A)) (hjump : A ≤ B/2 + (B-A)) (hshort : A ≤ 2*(B-I))
    (hgap : ∀ t : Finset ι, (∑ i ∈ t, w i) < A ∨ B < ∑ i ∈ t, w i)
    (hdis : ∀ c d, c ≠ d → Disjoint (parent c) (parent d))
    (hsingle : ∀ c, (∑ i ∈ parent c, w i) < A)
    (hpair : ∀ c d, c ≠ d →
      A ≤ ∑ i ∈ parent c ∪ parent d, w i) (hfour : ∀ c d, c ≠ d →
      (∑ i ∈ parent c ∪ parent d, w i) < 4*B/3) :
    ∃ pick : Fin 3 → ι,
      (∀ c, (parent c).filter (fun i => B-A < w i) = {pick c}) ∧
      (∀ c d, c ≠ d → B < w (pick c) + w (pick d)) := by
  classical
  let H (c : Fin 3) := (parent c).filter (fun i => B-A < w i)
  have hsub (c : Fin 3) : H c ⊆ parent c := filter_subset _ _
  have dis (c d : Fin 3) (hne : c ≠ d) := (hdis c d hne).mono (hsub c) (hsub d)
  have small (c : Fin 3) : (∑ i ∈ H c, w i) < A :=
    (sum_le_sum_of_subset_of_nonneg (hsub c) (fun i _ _ => hn i)).trans_lt (hsingle c)
  have low (c d : Fin 3) (hne : c ≠ d) : B < (∑ i ∈ H c, w i) + ∑ i ∈ H d, w i := by
    simpa only [H, filter_union, sum_union (dis c d hne)] using heavy_pair hgap (hpair c d hne)
  have card (c d : Fin 3) (hne : c ≠ d) : (H c).card + (H d).card ≤ 3 := by
    simpa only [H, filter_union, card_union_of_disjoint (dis c d hne)] using
      at_most_three hn hthree hgap (hfour c d hne)
  have cyclic (c d e : Fin 3) (hcd : c ≠ d) (hce : c ≠ e) (hde : d ≠ e) : (H c).card = 1 :=
    one_heavy hn hI hAB hB hjump hshort hgap (dis c d hcd) (dis c e hce) (dis d e hde)
      (small c) (small d) (fun _ hi => (mem_filter.mp hi).2)
      (card c d hcd) (card c e hce) (low c d hcd) (low d e hde)
  have unique (c : Fin 3) : ∃ i, H c = {i} := card_eq_one.mp (by
    fin_cases c
    · exact cyclic 0 1 2 (by decide) (by decide) (by decide)
    · exact cyclic 1 2 0 (by decide) (by decide) (by decide)
    · exact cyclic 2 0 1 (by decide) (by decide) (by decide))
  choose pick h using unique
  refine ⟨pick, h, ?_⟩
  intro c d hne
  simpa only [h c, h d, sum_singleton] using low c d hne

/-- The three alternatives for the actual colored factors of one supported box.
The tolerance e permits the dyadic interval and the slot localization constants. -/
theorem three_parent_alternatives (w : ι → ℝ) (p : Fin 3 → Finset ι)
    (smooth : ι → Prop) (a b I e z : ℝ)
    (hn : ∀ i, 0 ≤ w i) (hmu : ∀ i, ¬smooth i → w i ≤ b-a)
    (hdis : ∀ c d, c ≠ d → Disjoint (p c) (p d))
    (lo hi : ℝ) (hc : ∀ c, lo ≤ ∑ i ∈ p c, w i)
    (hu : ∀ c, (∑ i ∈ p c, w i) ≤ hi)
    (ht : |((∑ i ∈ p 0, w i) + (∑ i ∈ p 1, w i) + (∑ i ∈ p 2, w i)) - 1| ≤ e)
    (hab : a < b) (hb : 0 < b) (hthree : a ≤ 3*(b-a))
    (hjump : a ≤ b/2+(b-a)) (hshort : a ≤ 2*(b-I))
    (hup : hi ≤ b) (hlo : a ≤ 1-e-hi) (hfour : 1+e-lo < 4*b/3)
    (hmuI : b-a < I) (hz : z ≤ b-I) :
    (∃ i, smooth i ∧ I ≤ w i) ∨
    (∃ t : Finset ι, a ≤ ∑ i ∈ t, w i ∧ (∑ i ∈ t, w i) ≤ b) ∨
    ∃ pick : Fin 3 → ι,
      (∀ c, pick c ∈ p c ∧ smooth (pick c) ∧ z < w (pick c)) ∧
      (∀ c d, c ≠ d → b < w (pick c) + w (pick d)) := by
  classical
  by_cases long : ∃ i, smooth i ∧ I ≤ w i
  · exact Or.inl long
  right
  by_cases middle : ∃ t : Finset ι, a ≤ ∑ i ∈ t, w i ∧ (∑ i ∈ t, w i) ≤ b
  · exact Or.inl middle
  right
  have hgap (t : Finset ι) : (∑ i ∈ t, w i) < a ∨ b < ∑ i ∈ t, w i := by
    by_contra! bad
    exact middle ⟨t, bad.1, bad.2⟩
  have hI (i : ι) : w i < I := by
    by_cases h : smooth i
    · exact lt_of_not_ge (fun hw => long ⟨i, h, hw⟩)
    · exact (hmu i h).trans_lt hmuI
  have hs (c : Fin 3) := (hgap (p c)).resolve_right (not_lt_of_ge ((hu c).trans hup))
  obtain ⟨htl, htu⟩ := abs_le.mp ht
  have pair (c d : Fin 3) (hd : c ≠ d) :
      a ≤ (∑ i ∈ p c ∪ p d, w i) ∧ (∑ i ∈ p c ∪ p d, w i) < 4*b/3 := by
    rw [sum_union (hdis c d hd)]
    have l0 := hc 0
    have l1 := hc 1
    have l2 := hc 2
    have u0 := hu 0
    have u1 := hu 1
    have u2 := hu 2
    have cases : ∀ n : Fin 3, n = 0 ∨ n = 1 ∨ n = 2 := by decide
    rcases cases c with rfl | rfl | rfl <;> rcases cases d with rfl | rfl | rfl <;> first
      | exact (hd rfl).elim
      | constructor <;> linarith only [htl, htu, hlo, hfour, l0, l1, l2, u0, u1, u2]
  obtain ⟨pick, hp, pairs⟩ := select_three_parent_slots w p a b I hn hI hab hb
    hthree hjump hshort hgap hdis hs (fun c d h => (pair c d h).1)
    (fun c d h => (pair c d h).2)
  refine ⟨pick, ?_, pairs⟩
  intro c
  have hmem : pick c ∈ (p c).filter (fun i => b-a < w i) := by rw [hp]; simp
  obtain ⟨hc', hw⟩ := mem_filter.mp hmem
  have other : ∃ d : Fin 3, c ≠ d := by
    fin_cases c
    · exact ⟨1, by decide⟩
    · exact ⟨2, by decide⟩
    · exact ⟨0, by decide⟩
  obtain ⟨d, hd⟩ := other
  refine ⟨hc', Classical.byContradiction (fun h => (not_lt_of_ge (hmu _ h)) hw), ?_⟩
  linarith only [pairs c d hd, hI (pick d), hz]

/-- Total exponent of the other slots, including the dyadic tolerance. -/
theorem residual_of_selected_pairs {u v w T B e : ℝ}
    (hT : T ≤ 1+e) (huv : B < u+v) (huw : B < u+w) (hvw : B < v+w) :
    T-(u+v+w) < 1+e-3*B/2 ∧
      ∀ c, u ≤ c+e → T-(u+v+w) < 1+2*e-2*B+c := by
  constructor
  · linarith
  · intro c hc
    linarith

#print axioms three_parent_alternatives
#print axioms residual_of_selected_pairs
#print axioms select_three_parent_slots
end
end PrimeGap180
