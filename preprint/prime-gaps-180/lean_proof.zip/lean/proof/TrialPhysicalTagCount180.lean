import TrialFixedTagIntegral180
import TrialHighTagEnergy180

/-! Identify the natural-valued site count used by the high-edge energy with
the physical counting-measure event in the fixed-count disintegration. -/
noncomputable section
open scoped ENNReal Classical
open MeasureTheory PrimeGap186 PrimeGap180.Sector PrimeGap180.FrozenProfile
open PrimeGap180.RemovedHighTags PrimeGap180.RemovedHighMass
namespace PrimeGap180.PhysicalTagCount
open FixedTagIntegral
open HighTagEnergy

theorem integer_ae : ∀ᵐ X ∂NativeSiteLaw.phys cap, markCount cutoff X = (count X:ℝ≥0∞) := by
  apply Measure.ae_smul_measure
  let P := fun X : FiniteMeasure ℝ => markCount cutoff X = (count X:ℝ≥0∞)
  have hP : MeasurableSet {X | P X} := measurableSet_eq_fun (FixedTagIntegral.count_meas _)
    ((measurable_of_countable (fun k : ℕ => (k : ℝ≥0∞))).comp HighTagEnergy.count_meas)
  let chart := MeasurableEquiv.funUnique (Fin 1) (FiniteMeasure ℝ)
  have mp := measurePreserving_funUnique (fragmentLaw cap) (Fin 1)
  change ∀ᵐ X ∂fragmentLaw cap, P X
  rw [←mp.map_eq,ae_map_iff mp.measurable.aemeasurable hP]
  apply fragmentLaw_ae_finite_tail_elim cap cutoff (by norm_num [cap,physicalCap,rho])
    (by norm_num [cutoff,Lookup.ticks]) 1
  · exact mp.measurable hP
  · intro Y n x hY hx
    change markCount cutoff (Y 0 + weightedEmpirical (n 0) (x 0)) =
      (count (Y 0 + weightedEmpirical (n 0) (x 0)) : ℝ≥0∞)
    have h := after_insert (by norm_num [cutoff,Lookup.ticks]) (Y 0) (n 0) (x 0) (hY 0) (fun j => (hx 0 j).1)
    change _ = ((⌊(markCount cutoff (Y 0 + weightedEmpirical (n 0) (x 0))).toReal⌋₊ : ℕ) : ℝ≥0∞)
    simp [h]

/-- The same events are interchangeable inside all 39-site restricted
integrals, including ones whose integrands use other coordinates. -/
theorem product_ae (k : ℕ) : ∀ᵐ X ∂law, ∀ i : Fin 39,
    (count (X i) = k ↔ markCount cutoff (X i) = k) := by
  let : IsProbabilityMeasure (fragmentLaw cap) := fragmentLaw_isProbabilityMeasure _
  let : IsFiniteMeasure (NativeSiteLaw.phys cap) := (fragmentLaw cap).smul_finite (by simp)
  apply ae_all_iff.mpr
  intro i
  have h := (Measure.quasiMeasurePreserving_eval (fun _ : Fin 39 => NativeSiteLaw.phys cap) i).ae integer_ae
  filter_upwards [h] with X hx
  change markCount cutoff (X i) = _ at hx
  rw [hx]
  exact Nat.cast_inj.symm

#print axioms integer_ae
#print axioms product_ae
end PrimeGap180.PhysicalTagCount
