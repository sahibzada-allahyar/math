import TrialPhysicalPrices180
import TrialResourceEvents180

/-! Apply only the signed columns and diagonal tests used by the integer
certificate. The physical amplitudes may depend on the scale and the shift. -/
noncomputable section
open scoped BigOperators Classical
open Filter PrimeGap180.Dual
namespace PrimeGap180.Price

variable {I J K E : Type*} [Fintype I] [Fintype J] [Fintype K] [Fintype E]

def Upper (L : Filter ℝ) (f : ℝ → ℝ) (v : ℝ) :=
  ∀ ε > 0, ∀ᶠ x in L, f x ≤ v + ε

private theorem upper_sum {L : Filter ℝ} {f : J → ℝ → ℝ} {c : J → ℝ}
    (upper : ∀ j, Upper L (f j) (c j)) :
    Upper L (fun x => ∑ j, f j x) (∑ j, c j) := by
  intro ε he
  let d := (Fintype.card J : ℝ)+1
  have dp : 0 < d := by dsimp [d]; positivity
  filter_upwards [eventually_all.mpr (fun j => upper j (ε/d) (div_pos he dp))] with x hx
  have z := Finset.sum_le_sum (s := Finset.univ) (fun j _ => hx j)
  rw [Finset.sum_add_distrib,Finset.sum_const,Finset.card_univ,nsmul_eq_mul] at z
  have sub := mul_le_mul_of_nonneg_right (show (Fintype.card J : ℝ) ≤ d by dsimp [d]; linarith)
    (div_nonneg he.le dp.le)
  rw [mul_div_cancel₀ _ dp.ne'] at sub
  linarith

private theorem upper_mul {L : Filter ℝ} {f : ℝ → ℝ} {b c : ℝ} (h : Upper L f b)
    (hc : 0 ≤ c) : Upper L (fun x => c*f x) (c*b) := by
  rcases hc.eq_or_lt with e | hp
  · subst c
    exact fun _ he => .of_forall (fun _ => by simpa using he.le)
  intro ε he
  filter_upwards [h (ε/c) (div_pos he hp)] with x hx
  have z := mul_le_mul_of_nonneg_left hx hp.le
  rwa [mul_add,mul_div_cancel₀ _ hp.ne'] at z

def squareCount (s : Finset ℕ) (μ : ℕ → ℝ) (v : ℕ → I → ℝ) (c : I → ℝ) :=
  ∑ n ∈ s, μ n*(∑ i, c i*v n i)^2

theorem quad_moment (s : Finset ℕ) (μ : ℕ → ℝ) (v : ℕ → I → ℝ) (c : I → ℝ) :
    quad (moment s μ v) c = squareCount s μ v c := by
  simp only [quad,moment,squareCount,pow_two,Finset.sum_mul,Finset.mul_sum]
  rw [Finset.sum_comm]
  -- Match the sample index before expanding any coordinate sums.
  simp_rw [Finset.sum_comm (s := (Finset.univ : Finset I)) (t := s)]
  apply Finset.sum_congr rfl
  intro n _
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro j _
  ring

omit [Fintype I] in
private theorem diag_moment (s : Finset ℕ) (μ : ℕ → ℝ) (v : ℕ → I → ℝ) (i : I) :
    moment s μ v i i = ∑ n ∈ s, μ n*(v n i)^2 := by
  simp only [moment,pow_two,mul_assoc]

private theorem sum_column_cost (F : I → J → ℝ) (B : I → ℝ) :
    (∑ j, ∑ i, B i*(F i j)^2) = ∑ i, B i*factorGram F i i := by
  rw [Finset.sum_comm]
  simp [factorGram,pow_two,Finset.mul_sum]

/-- The clean upper-square statements for the marked and rough resource
are about the integer count on the left. The coefficient function b already
contains the division by 24 converting the archive's incidence numerators. -/
theorem coupled_of_squares {L : Filter ℝ} (s : ℝ → Finset ℕ) (μ : ℝ → E → ℕ → ℝ)
    (v : ℝ → ℕ → I → ℝ) (b : E → ℝ) (F : I → J → ℝ) (B : I → ℝ)
    (upper : ∀ k, Upper L (fun x => squareCount (s x) (fun n => ∑ e, b e * μ x e n)
      (v x) (fun i => F i k)) (∑ i, B i*(F i k)^2)) :
    Lower (fun x => -pair (factorGram F) (mix b (fun e => moment (s x) (μ x e) (v x))))
      (-(∑ i, B i*factorGram F i i)) L := by
  intro ε he
  filter_upwards [upper_sum upper ε he] with x hx
  rw [mix_moment,columns]
  simp_rw [quad_moment]
  rw [sum_column_cost] at hx
  linarith

def rowDeficit (T : I → I → ℝ) (i : I) :=
  max 0 ((∑ j, if i=j then 0 else |T i j|) - T i i)

theorem residual_of_squares {L : Filter ℝ} (s : ℝ → Finset ℕ) (μ : ℝ → ℕ → ℝ)
    (v : ℝ → ℕ → I → ℝ) (hμ : ∀ᶠ x in L, ∀ n ∈ s x, 0 ≤ μ x n)
    (R T : I → I → ℝ) (P : I → K → ℝ) (N : I → J → ℝ) (B : I → ℝ) {a : ℝ} (ha : 0 < a)
    (symm : ∀ i j, T i j = T j i)
    (balance : ∀ i j, a*R i j + factorGram N i j = factorGram P i j + T i j)
    (upper : ∀ k, Upper L (fun x => squareCount (s x) (μ x) (v x) (fun i => N i k))
      (∑ i, B i*(N i k)^2))
    (diag : ∀ i, Upper L (fun x => ∑ n ∈ s x, μ x n*(v x n i)^2) (B i)) :
    Lower (fun x => pair R (moment (s x) (μ x) (v x)))
      (-(∑ i, B i*(factorGram N i i + rowDeficit T i)/a)) L := by
  let d := rowDeficit T
  have non i : 0 ≤ d i := le_max_left _ _
  have rows i : (∑ j, if i=j then 0 else |T i j|) ≤ T i i + d i := by
    have z : (∑ j, if i=j then 0 else |T i j|) - T i i ≤ d i := le_max_right _ _
    linarith
  intro ε he
  have hp : 0 < a*ε/2 := by positivity
  filter_upwards [hμ,upper_sum upper _ hp,
    upper_sum (fun i => upper_mul (diag i) (non i)) _ hp] with x pos neg bound
  have z := finite_residual (s x) (μ x) (v x) pos R T P N d a symm balance rows
  simp only [quad_moment,diag_moment] at z
  rw [sum_column_cost] at neg
  have eq : (∑ i, B i*(factorGram N i i + rowDeficit T i)/a) =
      ((∑ i, B i*factorGram N i i) + ∑ i, d i*B i)/a := by
    simp [d,←Finset.sum_div,mul_add,add_div,Finset.sum_add_distrib,mul_comm]
  rw [eq]
  apply (le_of_mul_le_mul_left (a := a) _ ha)
  rw [mul_sub,mul_neg,mul_div_cancel₀ _ ha.ne']
  linarith only [z,neg,bound]


/-- Gauge change for a physical sector array V, using the positive *reference*
mass from the integer certificate. B is the integral of the actual squared
sector erasure against the upper kernel, in physical units. -/
theorem reference_square {L : Filter ℝ} (s : ℝ → Finset ℕ) (μ : ℝ → ℕ → ℝ)
    (V : ℝ → ℕ → I → ℝ) (ref B c : I → ℝ) (hr : ∀ i, 0 < ref i)
    (upper : Upper L (fun x => squareCount (s x) (μ x) (V x)
      (fun i => c i/Real.sqrt (ref i))) (∑ i, B i*(c i/Real.sqrt (ref i))^2)) :
    Upper L (fun x => squareCount (s x) (μ x) (fun n i => V x n i/Real.sqrt (ref i)) c)
      (∑ i, (B i/ref i)*(c i)^2) := by
  have eq i : B i*(c i/Real.sqrt (ref i))^2 = B i/ref i*(c i)^2 := by
    rw [div_pow,Real.sq_sqrt (hr i).le]
    ring
  simpa only [squareCount,mul_div_assoc,div_mul_eq_mul_div,eq] using upper

def roundingRow (w : I → ℝ) (i : I) :=
  (Fintype.card I : ℝ)*w i + ∑ j, w j + Fintype.card I

/-- Undo the objective floor after solving for the physical lower bound.
The extra cost is the prime diagonal times the integer rounding row / unit². -/
theorem unfloor_prime {L : Filter ℝ} (s : ℝ → Finset ℕ) (μ : ℝ → ℕ → ℝ)
    (v : ℝ → ℕ → I → ℝ) (hμ : ∀ᶠ x in L, ∀ n ∈ s x, 0 ≤ μ x n)
    (u w B : I → ℝ) {unit earned : ℝ} (hu : 0 < unit) (hn : ∀ i, 0 ≤ w i)
    (lo : ∀ i, w i ≤ u i) (hi : ∀ i, u i ≤ w i+1)
    (diag : ∀ i, Upper L (fun x => ∑ n ∈ s x, μ x n*(v x n i)^2) (B i))
    (lower : Lower (fun x => squareCount (s x) (μ x) (v x) (fun i => w i/unit)) earned L) :
    Lower (fun x => squareCount (s x) (μ x) (v x) (fun i => u i/unit))
      (earned - ∑ i, roundingRow w i / unit^2 * B i) L := by
  let d := fun i => roundingRow w i / unit^2
  have nnd i : 0 ≤ d i := by
    dsimp [d,roundingRow]
    exact div_nonneg (add_nonneg (add_nonneg (mul_nonneg (Nat.cast_nonneg _) (hn i))
      (Finset.sum_nonneg fun j _ => hn j)) (Nat.cast_nonneg _)) (sq_pos_of_pos hu).le
  intro ε he
  filter_upwards [hμ,lower (ε/2) (half_pos he),
    upper_sum (fun i => upper_mul (diag i) (nnd i)) _ (half_pos he)] with x pos lb cap
  have pt (n : ℕ) : (∑ i, w i/unit*v x n i)^2 ≤ (∑ i, u i/unit*v x n i)^2 +
      ∑ i, d i*(v x n i)^2 := by
    have z := rounding_lower u w (fun i => v x n i / unit) hn lo hi
    have adj (c : I → ℝ) : (∑ i, c i*(v x n i/unit)) = ∑ i, c i/unit*v x n i :=
      Finset.sum_congr rfl fun i _ => by ring
    have dz : (∑ i, (((Fintype.card I : ℝ)*w i + ∑ j, w j) + Fintype.card I) *
        (v x n i/unit)^2) = ∑ i, d i*(v x n i)^2 :=
      Finset.sum_congr rfl fun i _ => by dsimp [d,roundingRow]; ring
    rw [dz,adj,adj] at z
    linarith
  have z := Finset.sum_le_sum (s := s x) (fun n hn => mul_le_mul_of_nonneg_left (pt n) (pos n hn))
  rw [show (∑ n ∈ s x, μ x n*((∑ i, u i/unit*v x n i)^2 + ∑ i, d i*(v x n i)^2)) =
      squareCount (s x) (μ x) (v x) (fun i => u i/unit) +
      ∑ i, d i*∑ n ∈ s x, μ x n*(v x n i)^2 by
        simp only [squareCount,mul_add,Finset.mul_sum,Finset.sum_add_distrib]
        congr 1
        rw [Finset.sum_comm]
        exact Finset.sum_congr rfl (fun i _ => Finset.sum_congr rfl fun n _ => by ring)] at z
  change squareCount (s x) (μ x) (v x) (fun i => w i/unit) ≤ _ at z
  change earned - ∑ i, d i*B i - ε ≤ _
  linarith only [z,cap,lb]

abbrev priceUnit : ℝ := 10^14

def intGram (F : I → J → ℤ) (i j : I) : ℤ := ∑ k, F i k * F j k

def intRemainder (M : I → I → ℤ) (P : I → K → ℤ) (N : I → J → ℤ) (i j : I) : ℤ :=
  32^2*M i j + intGram N i j - intGram P i j

def intDeficit (T : I → I → ℤ) (i : I) :=
  max 0 ((∑ j, if i=j then 0 else |T i j|) - T i i)

omit [Fintype I] in
private theorem cast_gram (F : I → J → ℤ) (i j : I) :
    factorGram (fun a k => (F a k:ℝ)) i j = (intGram F i j:ℝ) := by
  simp [factorGram,intGram]

private theorem cast_deficit (T : I → I → ℤ) (i : I) :
    rowDeficit (fun i j => (T i j:ℝ)) i = (intDeficit T i:ℝ) := by
  simp [intDeficit,rowDeficit,Int.cast_max,Int.cast_abs,apply_ite]

/-- Apply the coupled integer factor at its actual scale. The supplied
upper bound is needed on precisely its columns, including the 1/unit
factor in their signed amplitudes. -/
theorem integer_coupled {L : Filter ℝ} (s : ℝ → Finset ℕ) (μ : ℝ → E → ℕ → ℝ)
    (v : ℝ → ℕ → I → ℝ) (count : E → ℤ) (F : I → J → ℤ) (B : I → ℝ)
    (upper : ∀ k, Upper L (fun x => squareCount (s x)
      (fun n => ∑ e, (count e:ℝ)/24 * μ x e n) (v x) (fun i => (F i k:ℝ)/priceUnit))
      (∑ i, B i*((F i k:ℝ)/priceUnit)^2)) :
    Lower (fun x => -pair (fun i j => (intGram F i j:ℝ)/priceUnit^2)
      (mix (fun e => (count e:ℝ)/24) (fun e => moment (s x) (μ x e) (v x))))
      (-(∑ i, B i*((intGram F i i:ℝ)/priceUnit^2))) L := by
  have eq i j : factorGram (fun i k => (F i k:ℝ)/priceUnit) i j = (intGram F i j:ℝ)/priceUnit^2 := by
    unfold factorGram intGram
    push_cast
    rw [Finset.sum_div]
    apply Finset.sum_congr rfl
    intro k _
    ring
  have mat := funext (fun i => funext (eq i))
  simpa only [mat] using coupled_of_squares s μ v (fun e => (count e:ℝ)/24)
    (fun i k => (F i k:ℝ)/priceUnit) B upper

/-- The certificate uses precisely 32² times the integer affine residual,
adds the negative Gram, and subtracts the positive Gram. -/
theorem integer_residual {L : Filter ℝ} (s : ℝ → Finset ℕ) (μ : ℝ → ℕ → ℝ)
    (v : ℝ → ℕ → I → ℝ) (hμ : ∀ᶠ x in L, ∀ n ∈ s x, 0 ≤ μ x n)
    (M : I → I → ℤ) (P : I → K → ℤ) (N : I → J → ℤ) (B : I → ℝ)
    (symm : ∀ i j, M i j = M j i)
    (upper : ∀ k, Upper L (fun x => squareCount (s x) (μ x) (v x) (fun i => (N i k:ℝ)))
      (∑ i, B i*(N i k:ℝ)^2))
    (diag : ∀ i, Upper L (fun x => ∑ n ∈ s x, μ x n*(v x n i)^2) (B i)) :
    Lower (fun x => pair (fun i j => (M i j:ℝ)/(24*priceUnit^2)) (moment (s x) (μ x) (v x)))
      (-(∑ i, B i*((intGram N i i + intDeficit (intRemainder M P N) i:ℤ):ℝ) /
        (24*(32*priceUnit)^2))) L := by
  let T := intRemainder M P N
  have symmetric (i j : I) : T i j=T j i := by
    simp [T,intRemainder,intGram,symm i j,mul_comm]
  have balance (i j : I) : 24*(32*priceUnit)^2*((M i j:ℝ)/(24*priceUnit^2)) +
      factorGram (fun i k => (N i k:ℝ)) i j = factorGram (fun i k => (P i k:ℝ)) i j + (T i j:ℝ) := by
    simp only [T,intRemainder,cast_gram]
    push_cast
    norm_num [priceUnit]
    ring
  have result := residual_of_squares s μ v hμ (fun i j => (M i j:ℝ)/(24*priceUnit^2))
    (fun i j => (T i j:ℝ)) (fun i k => (P i k:ℝ)) (fun i k => (N i k:ℝ)) B
    (by norm_num [priceUnit] : 0 < 24*(32*priceUnit)^2)
    (fun i j => by rw [symmetric i j]) balance upper diag
  simpa only [cast_gram,cast_deficit,Int.cast_add,T] using result

/-- The two floors in the producer are adverse even when the intercept
or the coefficient of the prime upper kernel is negative. -/
theorem floor_sector_price {earn fixed primeCost ref kernel : ℝ} (hr : 0 < ref)
    (hk : 0 ≤ kernel) :
    ((⌊(earn-fixed)*priceUnit/ref⌋:ℤ):ℝ)/priceUnit +
      ((⌊-primeCost*priceUnit/ref⌋:ℤ):ℝ)/priceUnit*kernel ≤
        (earn-fixed-primeCost*kernel)/ref := by
  have u : 0 < priceUnit := by norm_num [priceUnit]
  have floorBound (z : ℝ) : ((⌊z*priceUnit/ref⌋:ℤ):ℝ)/priceUnit ≤ z/ref := by
    apply (div_le_iff₀ u).mpr
    simpa only [div_mul_eq_mul_div] using Int.floor_le (z*priceUnit/ref)
  have h := add_le_add (floorBound (earn-fixed))
    (mul_le_mul_of_nonneg_right (floorBound (-primeCost)) hk)
  exact h.trans_eq (by ring)

/-- Endpoints suffice to compare both affine prices on their entire
sector. Multiplying by the positive denominator makes the gap linear. -/
theorem price_interval {s qmax q da db : ℝ} (inside : 0 ≤ q ∧ q ≤ qmax)
    (room : qmax < s) (left : 0 ≤ da*s+db) (right : 0 ≤ da*(s-qmax)+db) :
    0 ≤ da+db/(s-q) := by
  have den : 0 < s-q := by linarith [inside.2]
  suffices z : 0 ≤ da*(s-q)+db by
    rw [←mul_div_cancel_right₀ da den.ne',←add_div]
    exact div_nonneg z den.le
  rcases le_total 0 da with pos|neg
  · nlinarith only [right,mul_nonneg pos (sub_nonneg.mpr inside.2)]
  · nlinarith only [left,mul_nonneg (neg_nonneg.mpr neg) inside.1]

/-- Use the marked bound for the actual resource indicator, including the
factor two or 24 in the cumulative event. -/
theorem resource_square {L : Filter ℝ} (cofinal : L ≤ atTop) (s : ℝ → Finset ℕ)
    (v : ℝ → ℕ → I → ℝ) (Z : ℝ → ℕ → ℝ) (h : ℕ) (r : Resources.Resource)
    (count : PriceEvents.Event → ℤ) (c : I → ℝ) (B : ℝ)
    (table : ∀ e, (count e:ℝ)/24=Resources.coefficient r e)
    (upper : Upper L (fun x => squareCount (s x) (fun n => Resources.physical x (n+h) r*Z x n)
      (v x) c) B) :
    Upper L (fun x => squareCount (s x)
      (fun n => ∑ e, (count e:ℝ)/24*(PriceEvents.mass x (n+h) e*Z x n)) (v x) c) B := by
  intro ε he
  filter_upwards [upper ε he,cofinal (eventually_ge_atTop (1:ℝ))] with x ub hx
  have eq (n : ℕ) : (∑ e, (count e:ℝ)/24*(PriceEvents.mass x (n+h) e*Z x n)) =
      Resources.physical x (n+h) r*Z x n := by
    simp_rw [table,←mul_assoc]
    rw [←Finset.sum_mul,Resources.physical_resource hx]
  simpa only [eq] using ub

/-- The physical prime lower bound with the coupled and residual premises
discharged. P and N are the integer factors chosen by the witness generator.
All square tests are for finitely many specified physical arrays. -/
theorem lower_prime_from_columns {L : Filter ℝ} {U : Type*} [Fintype U]
    (s : ℝ → Finset ℕ) (v : ℝ → ℕ → I → ℝ) (Z : ℝ → ℕ → ℝ) (h : ℕ)
    (hz : ∀ᶠ x in L, ∀ n ∈ s x, 0 ≤ Z x n)
    (w : I → ℝ) (A : PhysicalPrices.Row → I → I → ℝ)
    (count : U → PriceEvents.Event → ℤ)
    (rank : U → ℕ) (F : ∀ u, I → Fin (rank u) → ℤ)
    (M : PriceEvents.Event → I → I → ℤ)
    (pos neg : PriceEvents.Event → ℕ)
    (P : ∀ e, I → Fin (pos e) → ℤ) (N : ∀ e, I → Fin (neg e) → ℤ)
    (B : U → I → ℝ) (D : PriceEvents.Event → I → ℝ) (earned : PhysicalPrices.Row → ℝ)
    (symm : ∀ e i j, M e i j=M e j i)
    (balance : ∀ e i j, (M e i j:ℝ)/(24*priceUnit^2) = PhysicalPrices.objective w e i j -
      (∑ k, PhysicalPrices.coefficient k e*A k i j) +
      ∑ u, (count u e:ℝ)/24*((intGram (F u) i j:ℝ)/priceUnit^2))
    (rows : ∀ k, Lower (fun x => pair (A k) (moment (s x)
      (fun n => Literal.value (PhysicalPrices.channel x k) (n+h)*Z x n) (v x))) (earned k) L)
    (resource : ∀ u k, Upper L (fun x => squareCount (s x)
      (fun n => ∑ e, (count u e:ℝ)/24*(PriceEvents.mass x (n+h) e*Z x n)) (v x)
        (fun i => (F u i k:ℝ)/priceUnit)) (∑ i, B u i*((F u i k:ℝ)/priceUnit)^2))
    (negative : ∀ e k, Upper L (fun x => squareCount (s x)
      (fun n => PriceEvents.mass x (n+h) e*Z x n) (v x) (fun i => (N e i k:ℝ)))
      (∑ i, D e i*(N e i k:ℝ)^2))
    (diagonal : ∀ e i, Upper L (fun x => ∑ n ∈ s x, (PriceEvents.mass x (n+h) e*Z x n)*(v x n i)^2)
      (D e i))
    (cofinal : L ≤ atTop) :
    Lower (fun x => ∑ n ∈ s x, (if (n+h).Prime then 1 else 0)*Z x n*(∑ i, w i*v x n i)^2)
      ((∑ k, earned k) - (∑ u, ∑ i, B u i*((intGram (F u) i i:ℝ)/priceUnit^2)) -
        ∑ e, ∑ i, D e i*((intGram (N e) i i + intDeficit (intRemainder (M e) (P e) (N e)) i:ℤ):ℝ) /
          (24*(32*priceUnit)^2)) L := by
  apply PhysicalPrices.lower_prime_count s v Z h w A
    (fun u i j => (intGram (F u) i j:ℝ)/priceUnit^2) (fun u e => (count u e:ℝ)/24)
    (fun e i j => (M e i j:ℝ)/(24*priceUnit^2)) earned _ _ balance rows _ _ cofinal
  · intro u
    exact integer_coupled s (fun x e n => PriceEvents.mass x (n+h) e*Z x n) v (count u) (F u)
      (B u) (resource u)
  · intro e
    exact integer_residual s (fun x n => PriceEvents.mass x (n+h) e*Z x n) v
      (hz.mono fun x z n hn => mul_nonneg (PriceEvents.nonnegative x (n+h) e) (z n hn))
      (M e) (P e) (N e) (D e) (symm e) (negative e) (diagonal e)

#print axioms lower_prime_from_columns
#print axioms integer_coupled
#print axioms integer_residual
#print axioms reference_square
#print axioms unfloor_prime
end PrimeGap180.Price
