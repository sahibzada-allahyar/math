import TrialPriceTransposeGroupCommand180
import TrialPriceIsolatedChecks180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section
namespace PrimeGap180.PriceIsolatedGroup.G415
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 415

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G415
namespace PrimeGap180.PriceIsolatedGroup.G419
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 419

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G419
namespace PrimeGap180.PriceIsolatedGroup.G420
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 420

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G420
namespace PrimeGap180.PriceIsolatedGroup.G421
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 421

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G421
