import TrialStructuralGate180

/-! Exact edges of the deposited low, middle and high mass workers, in
working ticks. Adjacent upper edges and lower edges really coincide. -/
noncomputable section
open PrimeGap180.FrozenProfile PrimeGap180.GateDeletion PrimeGap180.Sector
namespace PrimeGap180.RemovalEdgeBook

def lowerNat (e : Active) : ℕ := if e.val=0 then 1 else FrozenData.parentUpperNat ⟨e.val-1,by have:=e.isLt; omega⟩

def groupOf (j : ℕ) : Fin 24 :=
  if j<90000 then 0 else if h : j<940000 then ⟨1+(j-90000)/40000,by omega⟩ else 23

private def exactEdge (e : Active) : Prop :=
  (2624990:ℚ)*FrozenData.meshQ (T.tailEdge e).castSucc = (lowerNat e:ℚ)
private instance (e) : Decidable (exactEdge e) := by unfold exactEdge; infer_instance

set_option maxHeartbeats 0
set_option maxRecDepth 65536

private theorem edge_checked : ∀ e : Active, exactEdge e := by decide +kernel
private theorem low_checked : ∀ e : Active, groupOf (lowerNat e)=0 ↔ e.val<14 := by decide +kernel
private theorem high_checked : ∀ e : Active, groupOf (lowerNat e)=23 ↔ 940000≤lowerNat e := by decide +kernel

theorem ticks_eq (e : Active) :
    Lookup.ticks*FrozenData.mesh (T.tailEdge e).castSucc = (lowerNat e:ℝ) := by
  rw [FrozenData.mesh_eq_rat]
  change (2624990:ℝ)*(FrozenData.meshQ (T.tailEdge e).castSucc:ℝ)=(lowerNat e:ℝ)
  have h : (2624990:ℚ)*FrozenData.meshQ (T.tailEdge e).castSucc = (lowerNat e:ℚ) := edge_checked e
  exact_mod_cast h

theorem group_eq (e : Active) : edgeGroup e=groupOf (lowerNat e) := by
  change groupOf ⌊Lookup.ticks*FrozenData.mesh (T.tailEdge e).castSucc⌋₊ = _
  exact congrArg groupOf (by rw [ticks_eq,Nat.floor_natCast])

theorem low (e : Active) : edgeGroup e=0 ↔ e.val<14 := by rw [group_eq]; exact low_checked e
theorem high (e : Active) : edgeGroup e=23 ↔ 940000≤lowerNat e := by rw [group_eq]; exact high_checked e

#print axioms ticks_eq
#print axioms low
#print axioms high
end PrimeGap180.RemovalEdgeBook
