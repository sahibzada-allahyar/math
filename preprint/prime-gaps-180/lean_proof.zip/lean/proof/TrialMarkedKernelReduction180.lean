import TrialRoughPhysicalPrices180
import TrialMarkedBandPrices180
import TrialHingePhysicalPrices180
import TrialFrozenFiveCovers180

namespace PrimeGap180.MarkedKernelReduction
open Book ClippedPair

/-- Price slot assigned to each of the 25 five-prime rectangle tables. -/
noncomputable def budget (row : FiveRow) (s : SectorId) : ℝ :=
  match row with
  | .old => FrozenLedger.ledger.eventKernel .oldFive s
  | .full j => FrozenLedger.ledger.resourceKernel (.fullFive j) s
  | .firstExtra => FrozenLedger.ledger.eventKernel (.newFive 0) s
  | .extras j => FrozenLedger.ledger.resourceKernel (.extraFives j) s

abbrev TableBounds := ∀ row s, Book.tablePrice row s ≤ budget row s

/-- The other 48 price rows and the three finite covering inequalities
are supplied by closed proofs. -/
theorem kernels (tables : TableBounds) : Book.KernelChecks FrozenLedger.ledger where
  covers := FrozenFiveCovers.checked
  resource := RoughKernel.resources (fun j s => tables (.full j) s)
    HingePrices.higher (fun j s => tables (.extras j) s)
  event e he s := by
    cases e with
    | prime => exact (he rfl).elim
    | oldFive => exact tables .old s
    | three j => exact Fin.cases (HingePrices.first s) (fun i => BandPrices.triple i s) j
    | newFive j => exact Fin.cases (tables .firstExtra s) (fun i => BandPrices.five i s) j
#print axioms kernels
end PrimeGap180.MarkedKernelReduction
