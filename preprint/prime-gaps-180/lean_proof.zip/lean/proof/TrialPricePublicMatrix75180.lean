import TrialPriceSlotReflect180

namespace PrimeGap180.PriceBindings.M75
open PrimeGap180.PriceProjection PrimeGap180.PriceWordText
set_option maxRecDepth 24000000
set_option maxHeartbeats 400000000

declareSlotParts 75

theorem selected_public : PackedLedger.raw.matrices[89]! = (rank,whole) := by rfl
theorem selected_rows : PriceFactorSource.factorShapes[75]! = (rank,numerals.toArray) := by rfl
theorem group_count : numerals.length=445 := by decide +kernel

proveWholeText 75
proveSlotRows 75 0 445
collectSlotRows 75

theorem bound : PackedLedger.raw.matrices[89]! = PriceFactorSource.physical (PriceFactorSource.factorShapes[75]!) :=
  slot group_count selected_rows (selected_public.trans (congrArg (fun s : String => (rank,s)) whole_text)) all_rows

#print axioms bound
end PrimeGap180.PriceBindings.M75
