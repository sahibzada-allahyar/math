import TrialLaterLowTransformTail180

/-! Change of variables to the two scalar E1 arguments evaluated in
the deposited one-site transform bounds. -/
noncomputable section
open MeasureTheory Set Filter PrimeGap180.Sector PrimeGap180.FrozenProfile
open scoped NNReal
namespace PrimeGap180.LaterLowTransform

def E1 (z : ℝ) := ∫ x in Ioi z, Real.exp (-x)/x

private theorem integrable {s e : ℝ} (hs : 0<s) (he : 0<e) :
    IntegrableOn (fun x : ℝ=>Real.exp (-s*x)/x) (Ioi e) := by
  have m : Measurable (fun x : ℝ=>Real.exp (-s*x)/x) := by fun_prop
  apply ((integrableOn_exp_mul_Ioi (neg_neg_of_pos hs) e).div_const e).mono' m.aestronglyMeasurable
  filter_upwards [ae_restrict_mem (μ:=volume) measurableSet_Ioi] with x hx
  rw [Real.norm_eq_abs,abs_of_nonneg (div_nonneg (Real.exp_pos _).le (he.trans hx).le)]
  exact div_le_div_of_nonneg_left (Real.exp_pos _).le he hx.le

private theorem rescale {s : ℝ} (hs : 0<s) (e : ℝ) :
    (∫ x in Ioi e, Real.exp (-s*x)/x)=E1 (s*e) := by
  have h:=integral_comp_mul_left_Ioi (fun x : ℝ=>Real.exp (-x)/x) e hs
  rw [smul_eq_mul] at h
  calc
    _ = ∫ x in Ioi e,s*(Real.exp (-(s*x))/(s*x)) := by
      apply setIntegral_congr_fun measurableSet_Ioi
      intro x _
      change Real.exp (-s*x)/x = s*(Real.exp (-(s*x))/(s*x))
      rw [neg_mul]
      by_cases hx : x=0
      · simp [hx]
      · field_simp
    _ = _ := by rw [integral_const_mul,h]; unfold E1; rw [←mul_assoc,mul_inv_cancel₀ hs.ne',one_mul]

theorem tail_eq_E1 {s e r : ℝ} (hs : 0<s) (he : 0<e) (hr : 0≤r) :
    tailCorrection e s r = E1 (s*e)-E1 ((s+r)*e) := by
  have hz := add_pos_of_pos_of_nonneg hs hr
  unfold tailCorrection
  simp_rw [sub_div]
  rw [integral_sub (integrable hs he) (integrable hz he),rescale hs e,rescale hz e]

theorem bound_E1 (a : Active) (s r : ℝ≥0) (hs : 0<s) :
    site (FrozenData.tables.tailEdge a) s r ≤
    Real.exp (E1 ((s:ℝ)*edge (FrozenData.tables.tailEdge a))-
      E1 (((s:ℝ)+r)*edge (FrozenData.tables.tailEdge a)))/((s:ℝ)+r) := by
  have h := bound_tail a s r hs
  have he : 0<edge (FrozenData.tables.tailEdge a) := FrozenData.tables.tailPos a
  have eq := tail_eq_E1 (s:=(s:ℝ)) (by exact_mod_cast hs) he r.2
  apply h.trans_eq
  calc
    _ = (1/((s:ℝ)+r))*Real.exp (E1 ((s:ℝ)*edge (FrozenData.tables.tailEdge a))-
        E1 (((s:ℝ)+r)*edge (FrozenData.tables.tailEdge a))) := congrArg (fun q : ℝ=>(1/((s:ℝ)+r))*Real.exp q) eq
    _ = _ := by ring

#print axioms bound_E1
end PrimeGap180.LaterLowTransform
