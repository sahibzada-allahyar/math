import TrialSourceOwnerLookup180
import TrialSourceInterval180
import TrialSourceFrontierData180

/-! Match each true retained receipt, including its refined native bucket,
to a maximal point in its own group. The last possible bucket inside an
owner/gate intersection is one below its exclusive end. -/
noncomputable section
open PrimeGap180.FrozenProfile PrimeGap180.Sector PrimeGap180.FrozenData.FiniteInput
open PrimeGap180.SourceFrontier
namespace PrimeGap180.SourcePhysicalFrontier

structure Span where
  start : Nat
  stop : Nat
  bucket : Nat
  group : Nat
  cap : Nat
  radius : Nat
  deriving Inhabited

private def caps : Array Nat := #[208489,416998,625487,833996,962305,963971,978554,980476,984341,984362,994291,994334,1005630,1010349,1042485,1204958,1221976,1225606,1242539,1242624,1245549,1245592,1250994,1259984,1261436,1262610,1265963,1276981,1282959,1283066,1287999,1293999,1304739,1306704,1308369,1328398,1349003,1358996,1364997,1379367,1399375,1419980,1459482,1667992]

private def tag (c : Fine) (r : Array Nat) : Span :=
  ⟨field r 4,field r 4+(field r 3-field r 2),field r 2,field r 0,caps[c.val]!,field r 1⟩
private def spans := (List.finRange 44).flatMap (fun c => (FrozenData.FiniteInput.owners c).toList.map (tag c))
private def stop (r : Array Nat) := field r 0
private def lastBucket (s : Span) (r : Array Nat) := s.bucket+(min s.stop (stop r)-s.start-1)
private def top (s : Span) (r : Array Nat) := min s.radius (2000*(lastBucket s r+1000))
private def dominates (s : Span) (r : Array Nat) (o : Owner) : Prop :=
  s.cap ≤ o.cap ∧ s.radius ≤ o.radius ∧ top s r ≤ o.upper ∧ field r 3 ≤ o.level
private instance (s r o) : Decidable (dominates s r o) := by unfold dominates; infer_instance
private def fits (s : Span) (r : Array Nat) :=
  decide (445 ≤ s.group) || (SourceFrontier.owners s.group).any (fun o => decide (dominates s r o))

def Bound (a : Receipt) (o : Owner) : Prop :=
  (FrozenPairGate.k a).capTicks ≤ o.cap ∧ (FrozenPairGate.k a).radiusTicks ≤ o.radius ∧
    FrozenPairGate.upper a ≤ o.upper ∧ (FrozenPairGate.k a).levelTicks ≤ o.level

set_option maxRecDepth 131072
set_option maxHeartbeats 100000000

private theorem ceiling : ∀ c : Fine, SourceOwners.capTicks c = caps[c.val]! := by decide +kernel
private theorem ordered : SourceInterval.ordered Span.start Span.stop 0 spans = true := by decide +kernel
private theorem aligned : SourceInterval.aligned Span.stop stop fits 8192 spans gates.toList = true := by decide +kernel

theorem dominant {a : Receipt} (occ : FrozenPairGate.occurs a)
    (live : (FrozenData.tables.group a.sector).val < 445) :
    ∃ o ∈ SourceFrontier.owners (FrozenData.tables.group a.sector).val, Bound a o := by
  obtain ⟨r,mem,group,beginB,endB,eqKey,radius⟩ := SourceOwners.fields occ
  let s := tag a.fine r
  have inside : s ∈ spans := List.mem_flatMap.mpr ⟨a.fine,by simp,List.mem_map.mpr ⟨r,mem,rfl⟩⟩
  have low : s.start ≤ a.key.val := by change field r 4 ≤ a.key.val; omega
  have high : a.key.val < s.stop := by change a.key.val < field r 4 + (field r 3-field r 2); omega
  have selected := SourceInterval.find_owner Span.start Span.stop ordered inside low high
  obtain ⟨q,found,pass⟩ := SourceInterval.aligned_at Span.stop stop fits aligned selected
  have lastGate : a.key.val < stop q := by simpa using List.find?_some found
  have allFound : (SourceFrontier.owners s.group).any (fun o => decide (dominates s q o)) = true := by
    have small : s.group < 445 := by change field r 0 < 445; omega
    simpa [fits,Nat.not_le_of_gt small] using pass
  obtain ⟨o,member,truth⟩ := List.any_eq_true.mp allFound
  have dom : dominates s q o := of_decide_eq_true truth
  have same : s.group = (FrozenData.tables.group a.sector).val := group
  rw [same] at member
  refine ⟨o,member,?_,?_,?_,?_⟩
  · rw [SourceOwners.cap_ticks,ceiling]
    exact Nat.cast_le.mpr dom.1
  · change (FrozenData.tables.upper a.fine (FrozenData.tables.group a.sector):ℝ) ≤ (o.radius:ℝ)
    rw [radius]
    exact Nat.cast_le.mpr ((min_le_right _ _).trans dom.2.1)
  · have gate : a.key.val < min s.stop (stop q) := lt_min high lastGate
    have bucket : a.bucket.val ≤ lastBucket s q := by
      unfold lastBucket
      change a.bucket.val ≤ field r 2+(min s.stop (stop q)-field r 4-1)
      omega
    have byB : 2000*(a.bucket.val+1000) ≤ 2000*(lastBucket s q+1000) := by omega
    have both : min (FrozenData.tables.upper a.fine (FrozenData.tables.group a.sector)) (2000*(a.bucket.val+1000)) ≤ top s q := by
      apply min_le_min _ byB
      rw [radius]
      exact min_le_right _ _
    have final := both.trans dom.2.2.1
    change min (FrozenData.tables.upper a.fine (FrozenData.tables.group a.sector):ℝ) (2000*((a.bucket.val:ℝ)+1000)) ≤ (o.upper:ℝ)
    exact_mod_cast final
  · have eq := (gate_row a.key q found).1
    change FrozenData.plateau a.key ≤ (o.level:ℝ)
    rw [eq]
    exact Nat.cast_le.mpr dom.2.2.2

#print axioms dominant
end PrimeGap180.SourcePhysicalFrontier
