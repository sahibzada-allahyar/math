import PrimeGaps186

/-! A residual bound for rational polynomials on the two consecutive
Dickman charts. The coordinate z = 2u-c runs from -1 to 1, and shifting
u by -1 preserves z on the preceding chart. -/
noncomputable section
open Set PrimeGap186
namespace PrimeGap180.DickmanPolynomial
set_option backward.isDefEq.respectTransparency false

def evalQ (q : List ℚ) (z : ℚ) : ℚ := q.foldr (fun a t => a+z*t) 0
def evalR (q : List ℚ) (z : ℝ) : ℝ := q.foldr (fun a t => (a:ℝ)+z*t) 0
def add : List ℚ → List ℚ → List ℚ
  | [], b => b
  | a, [] => a
  | a::as, b::bs => (a+b)::add as bs
def diff : List ℚ → List ℚ
  | [] => []
  | _::as => add as (0::diff as)
def size (q : List ℚ) : ℚ := (q.map abs).sum
def residual (c : ℚ) (q prev : List ℚ) : List ℚ :=
  let d := diff q
  add (add (d.map (c*·)) (0::d)) prev

theorem eval_cons (a : ℚ) (q : List ℚ) (z : ℝ) : evalR (a::q) z = (a:ℝ)+z*evalR q z := rfl

theorem eval_rat (q : List ℚ) (z : ℚ) : evalR q (z:ℝ) = (evalQ q z : ℚ) := by
  induction q with
  | nil => simp [evalR,evalQ]
  | cons a as ih =>
    change (a:ℝ)+(z:ℝ)*evalR as (z:ℝ) = ((a+z*evalQ as z : ℚ):ℝ)
    rw [ih]; push_cast; rfl

private theorem eval_add (q r : List ℚ) (z : ℝ) : evalR (add q r) z = evalR q z + evalR r z := by
  induction q generalizing r with
  | nil => simp [add,evalR]
  | cons a as ih =>
    cases r with
    | nil => simp [add,evalR]
    | cons b bs =>
      change ((a+b:ℚ):ℝ)+z*evalR (add as bs) z = ((a:ℝ)+z*evalR as z)+((b:ℝ)+z*evalR bs z)
      rw [ih]; push_cast; ring

private theorem eval_scale (c : ℚ) (q : List ℚ) (z : ℝ) :
    evalR (q.map (c*·)) z = (c:ℝ)*evalR q z := by
  induction q with
  | nil => simp [evalR]
  | cons a as ih =>
    change ((c*a:ℚ):ℝ)+z*evalR (as.map (c*·)) z = (c:ℝ)*((a:ℝ)+z*evalR as z)
    rw [ih]; push_cast; ring

theorem value_residual (c : ℚ) (q prev : List ℚ) (z : ℝ) :
    evalR (residual c q prev) z = ((c:ℝ)+z)*evalR (diff q) z + evalR prev z := by
  simp only [residual,eval_add,eval_scale]
  rw [eval_cons,Rat.cast_zero,zero_add]
  ring

theorem derivative (q : List ℚ) (z : ℝ) : HasDerivAt (evalR q) (evalR (diff q) z) z := by
  induction q with
  | nil => exact hasDerivAt_const z 0
  | cons a as ih =>
    change HasDerivAt (fun x => (a:ℝ)+x*evalR as x) (evalR (diff (a::as)) z) z
    rw [diff,eval_add,eval_cons,Rat.cast_zero,zero_add]
    have hmul : HasDerivAt (fun x : ℝ => x * evalR as x)
        (1 * evalR as z + z * evalR (diff as) z) z := (hasDerivAt_id z).mul ih
    rw [one_mul] at hmul
    exact hmul.const_add (a:ℝ)

theorem abs_eval (q : List ℚ) (z : ℝ) (hz : |z| ≤ 1) : |evalR q z| ≤ (size q : ℝ) := by
  induction q with
  | nil => simp [evalR,size]
  | cons a as ih =>
    change |(a:ℝ)+z*evalR as z| ≤ ((|a|+size as:ℚ):ℝ)
    push_cast
    apply (abs_add_le _ _).trans
    rw [abs_mul]
    exact add_le_add le_rfl ((mul_le_mul_of_nonneg_right hz (abs_nonneg _)).trans (by simpa using ih))

def density (c z : ℝ) : ℝ := dickmanRho ((c+z)/2)

private theorem density_cont (c : ℝ) (hc : 3 ≤ c) :
    ContinuousOn (density c) (Icc (-1) 1) := by
  apply dickmanRho_analytic.2.2.1.comp (f := fun z : ℝ => (c+z)/2) (by fun_prop)
  intro z hz
  change 0 ≤ (c+z)/2
  linarith [hz.1]

private theorem density_deriv (c z : ℝ) (hc : 3 ≤ c) (hz : -1 < z) :
    HasDerivAt (density c) (-(density (c-2) z)/(c+z)) z := by
  have hp : 1 < (c+z)/2 := by linarith
  have dh : HasDerivAt (fun t : ℝ => (c+t)/2) (1/2) z := by
    exact ((hasDerivAt_id z).const_add c).div_const 2
  have h := (dickmanRho_analytic.2.2.2.2.1 _ hp).comp z dh
  change HasDerivAt (dickmanRho ∘ fun t => (c+t)/2) _ z
  rw [show -density (c-2) z/(c+z) = -(dickmanRho ((c+z)/2-1) / ((c+z)/2)) * (1/2) by
    unfold density
    rw [show (c-2+z)/2 = (c+z)/2-1 by ring]
    field_simp [show c+z ≠ 0 by linarith] <;> ring]
  exact h

/-- Starting error e and a coefficient-norm bound on the residual control
the entire next chart, including both endpoints. -/
theorem chart (c : ℚ) (hc : 3 ≤ c) (q prev : List ℚ) (e : ℝ) (he : 0 ≤ e)
    (join : evalQ q (-1) = evalQ prev 1)
    (prior : ∀ z ∈ Icc (-1:ℝ) 1, |density ((c:ℝ)-2) z-evalR prev z| ≤ e)
    (z : ℝ) (hz : z ∈ Icc (-1:ℝ) 1) :
    |density c z-evalR q z| ≤ e + 2*((size (residual c q prev) : ℝ)+e)/((c:ℝ)-1) := by
  let f := fun z : ℝ => density c z - evalR q z
  let g := fun z : ℝ => -(density ((c:ℝ)-2) z)/((c:ℝ)+z) - evalR (diff q) z
  let B := ((size (residual c q prev):ℝ)+e)/((c:ℝ)-1)
  have rc : (3:ℝ) ≤ c := by exact_mod_cast hc
  have sn : 0 ≤ size (residual c q prev) := List.sum_nonneg (fun a ha => by
    obtain ⟨b,_,rfl⟩ := List.mem_map.mp ha; exact abs_nonneg _)
  have sb : (0:ℝ) ≤ (size (residual c q prev):ℝ) := by exact_mod_cast sn
  have Bpos : 0 ≤ B := div_nonneg (add_nonneg sb he) (by linarith)
  have start : |f (-1)| ≤ e := by
    have v := prior 1 (by constructor <;> norm_num)
    have eq : evalR q (-1) = evalR prev 1 := by
      simpa only [Rat.cast_neg,Rat.cast_one] using (eval_rat q (-1)).trans
        ((congrArg (fun x : ℚ => (x:ℝ)) join).trans (eval_rat prev 1).symm)
    change |density c (-1)-evalR q (-1)| ≤ e
    rw [eq,show density (c:ℝ) (-1) = density ((c:ℝ)-2) 1 by unfold density; congr 1; ring]
    exact v
  have slope (t : ℝ) (ht : t ∈ Ioo (-1:ℝ) 1) : |g t| ≤ B := by
    have denpos : 0 < (c:ℝ)+t := by linarith [ht.1]
    have er := prior t ⟨ht.1.le,ht.2.le⟩
    have residualBound := abs_eval (residual c q prev) t (abs_le.mpr ⟨ht.1.le,ht.2.le⟩)
    have ident : g t = -((density ((c:ℝ)-2) t-evalR prev t)+evalR (residual c q prev) t)/((c:ℝ)+t) := by
      rw [value_residual]; dsimp only [g]; field_simp [denpos.ne'] <;> ring
    rw [ident,abs_div,abs_neg,abs_of_pos denpos]
    exact (div_le_div_of_nonneg_right ((abs_add_le _ _).trans ((add_le_add er residualBound).trans_eq (add_comm _ _))) denpos.le).trans
      (div_le_div_of_nonneg_left (add_nonneg sb he) (by linarith) (by linarith [ht.1]))
  have drift : |f z-f (-1)| ≤ 2*B := by
    by_cases left : z = -1
    · rw [left,sub_self,abs_zero]; positivity
    have lt : -1 < z := lt_of_le_of_ne hz.1 (Ne.symm left)
    have fc : ContinuousOn f (Icc (-1) z) :=
      ((density_cont c rc).sub (fun t _ => (derivative q t).continuousAt.continuousWithinAt)).mono
        (Icc_subset_Icc le_rfl hz.2)
    obtain ⟨t,ht,mean⟩ := exists_hasDerivAt_eq_slope f g lt fc (fun t ht =>
      (density_deriv c t rc ht.1).sub (derivative q t))
    have length : 0 < z-(-1) := sub_pos.mpr lt
    have bound := slope t ⟨ht.1,ht.2.trans_le hz.2⟩
    rw [mean,abs_div,abs_of_pos length,div_le_iff₀ length] at bound
    exact bound.trans (by nlinarith only [mul_nonneg Bpos (sub_nonneg.mpr hz.2)])
  change |f z| ≤ _
  calc
    |f z| = |(f z-f (-1))+f (-1)| := by ring_nf
    _ ≤ |f z-f (-1)|+|f (-1)| := abs_add_le _ _
    _ ≤ 2*B+e := add_le_add drift start
    _ = _ := by dsimp only [B]; ring

#print axioms chart
end PrimeGap180.DickmanPolynomial
