import TrialHigherMeans180

/-! Identify the limiting masses with the unclipped ordinary Lebesgue
integrals used in the frozen high-row density enclosures. -/
noncomputable section
open scoped Classical BigOperators Topology ENNReal
open MeasureTheory Filter PrimeGap180.Density PrimeGap180.LiteralDensity
namespace PrimeGap180.HigherMeans

private def siteDensity (B : Box) (t : ℝ) : ℝ≥0∞ :=
  (Set.Ioc B.lo B.hi).indicator (fun t : ℝ => ENNReal.ofReal t⁻¹) t

@[fun_prop] private theorem siteDensity_meas (B : Box) : Measurable (siteDensity B) :=
  (by fun_prop : Measurable (fun t : ℝ => ENNReal.ofReal t⁻¹)).indicator measurableSet_Ioc

private theorem site_law (B : Box) : (law B : Measure ℝ) = volume.withDensity (siteDensity B) :=
  (withDensity_indicator measurableSet_Ioc _).symm

private theorem map_density {X Y : Type*} [MeasurableSpace X] [MeasurableSpace Y]
    {μ : Measure X} {ν : Measure Y} (e : X ≃ᵐ Y) (pres : MeasurePreserving e μ ν)
    (f : Y → ℝ≥0∞) : (μ.withDensity (f ∘ e)).map e = ν.withDensity f := by
  ext s hs
  rw [Measure.map_apply e.measurable hs,withDensity_apply _ (e.measurable hs),withDensity_apply _ hs]
  exact pres.setLIntegral_comp_preimage_emb e.measurableEmbedding f s

private theorem product_law (B : Box) (d : ℕ) :
    productLaw B d = volume.withDensity (fun t : Fin d → ℝ => ∏ i, siteDensity B (t i)) := by
  induction d with
  | zero =>
    simp only [Finset.univ_eq_empty,Finset.prod_empty]
    rw [show (fun _ : Fin 0 → ℝ => (1:ℝ≥0∞)) = 1 by rfl,withDensity_one]
    exact (Measure.pi_of_empty _ (fun i => Fin.elim0 i)).trans (Measure.pi_of_empty _ _).symm
  | succ n ih =>
    let e := (MeasurableEquiv.piFinSuccAbove (fun _ : Fin (n+1) => ℝ) 0).symm
    let g := fun t : Fin (n+1) → ℝ => ∏ i, siteDensity B (t i)
    have toV := (measurePreserving_piFinSuccAbove (fun _ : Fin (n+1) => (volume : Measure ℝ)) 0).symm
    have toL := (measurePreserving_piFinSuccAbove (fun _ : Fin (n+1) => (law B : Measure ℝ)) 0).symm
    have eq : g ∘ e = fun p : ℝ × (Fin n → ℝ) => siteDensity B p.1 * ∏ i, siteDensity B (p.2 i) := by
      funext p
      simp only [g,e,Function.comp_apply,Fin.prod_univ_succ,MeasurableEquiv.piFinSuccAbove_symm_apply,
        Fin.insertNthEquiv,Fin.insertNth_zero,Equiv.coe_fn_mk,Fin.cons_succ,Fin.zero_succAbove,
        cast_eq,Fin.cons_zero]
    have e1 : (law B : Measure ℝ).prod (productLaw B n) =
        ((volume : Measure ℝ).prod (volume : Measure (Fin n → ℝ))).withDensity (g ∘ e) := by
      rw [eq,ih,site_law,prod_withDensity (siteDensity_meas B)]
      fun_prop (disch := exact siteDensity_meas B)
    exact toL.map_eq.symm.trans ((congrArg (Measure.map e) e1).trans (map_density e toV g))

private theorem mass_integral {d : ℕ} {B : Box} {s : Set (Fin d → ℝ)} (hs : MeasurableSet s)
    (inside : ∀ t ∈ s, (∀ i, B.lo < t i ∧ t i ≤ B.hi) ∧ 4/25 ≤ residual t) :
    mass B s = ∫ t in s, (∏ i, (t i)⁻¹) * (residual t)⁻¹ := by
  rw [mass,product_law,← integral_indicator hs]
  have mf : Measurable (fun t : Fin d → ℝ => ∏ i, siteDensity B (t i)) := by
    fun_prop (disch := exact siteDensity_meas B)
  have fin (t : Fin d → ℝ) : (∏ i, siteDensity B (t i)) < ⊤ := by
    apply ENNReal.prod_lt_top
    intro i _
    by_cases mem : t i ∈ Set.Ioc B.lo B.hi
    · simp [siteDensity,mem]
    · simp [siteDensity,mem]
  rw [integral_withDensity_eq_integral_toReal_smul mf (.of_forall fin)]
  apply integral_congr_ae
  apply Filter.Eventually.of_forall
  intro t
  by_cases h : t ∈ s
  · obtain ⟨ht,floor⟩ := inside t h
    have ev (i : Fin d) : (siteDensity B (t i)).toReal = (t i)⁻¹ := by
      have mem : t i ∈ Set.Ioc B.lo B.hi := ht i
      simp [siteDensity,mem,ENNReal.toReal_ofReal (inv_nonneg.mpr (B.low_pos.trans mem.1).le)]
    simp only [h,Set.indicator_of_mem,smul_eq_mul,ENNReal.toReal_prod,ev,weight,max_eq_right floor]
  · simp [h]

theorem threeMass_integral {a c : ℝ} (hc : 4/25 ≤ c) (ha : a ≤ 42/100) :
    threeMass a c = ∫ t in {t | threeRegion a c 0 0 t}, (∏ i, (t i)⁻¹)*(residual t)⁻¹ := by
  apply mass_integral (three_regular a c 0 0).1.measurableSet
  intro t ht
  obtain ⟨⟨h1,h2⟩,h3,h4⟩ := ht
  simp only [add_zero] at h3 h4
  have lo := hc.trans_lt h1
  have up := h4.trans_le ha
  exact ⟨fun i => by fin_cases i <;> dsimp [box] <;> constructor <;> linarith,by linarith⟩

theorem fiveMass_integral {a : ℝ} (ha : a ≤ 417/1000) :
    fiveMass a = ∫ t in {t | fiveRegion a 0 0 t}, (∏ i, (t i)⁻¹)*(residual t)⁻¹ := by
  apply mass_integral (five_regular a 0 0).1.measurableSet
  intro t ht
  obtain ⟨⟨h1,h2,h3⟩,h4,h5⟩ := ht
  simp only [add_zero,LiteralDensity.residual,Fin.sum_univ_four] at h4 h5
  constructor
  · intro i
    fin_cases i <;> dsimp [box] <;> constructor <;> linarith
  · simp only [LiteralDensity.residual,Fin.sum_univ_four]
    linarith

#print axioms threeMass_integral
#print axioms fiveMass_integral
end PrimeGap180.HigherMeans
