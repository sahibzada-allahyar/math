import TrialPureSquares180
import TrialRepeatedSupport180
import TrialPrimeDistribution180

noncomputable section
open scoped BigOperators Topology
open Filter PrimeGap186 PrimeGap182Analytic Classical
namespace PrimeGap180.Collisions

def isPrimeSquare (n : ℕ) : Prop := ∃ p : ℕ, p.Prime ∧ n = p^2

theorem square_reindex {x : ℝ} (hx : 0 ≤ x) (e : ℕ → ℂ) :
    (∑ n ∈ Finset.Icc 1 ⌊2*x⌋₊, Finsupp.single n (if isPrimeSquare n then e n else 0)) =
      squareSequence ⌊Real.sqrt (2*x)⌋₊ (fun p => if p.Prime then e (p^2) else 0) := by
  classical
  let T := (Finset.Ioc 0 ⌊Real.sqrt (2*x)⌋₊).filter Nat.Prime
  let N := Finset.Icc 1 ⌊2*x⌋₊
  have sets : N.filter isPrimeSquare = T.image (fun p => p^2) := by
    ext n
    constructor
    · intro h
      obtain ⟨hn,p,hp,rfl⟩ := Finset.mem_filter.mp h
      have bound := (Nat.cast_le.mpr (Finset.mem_Icc.mp hn).2).trans
        (Nat.floor_le (mul_nonneg zero_le_two hx))
      rw [Nat.cast_pow] at bound
      exact Finset.mem_image.mpr ⟨p,Finset.mem_filter.mpr ⟨Finset.mem_Ioc.mpr
        ⟨hp.pos,Nat.le_floor (Real.le_sqrt_of_sq_le bound)⟩,hp⟩,rfl⟩
    · intro h
      obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp h
      obtain ⟨hi,pp⟩ := Finset.mem_filter.mp hp
      have le := (Nat.cast_le.mpr (Finset.mem_Ioc.mp hi).2).trans
        (Nat.floor_le (Real.sqrt_nonneg (2*x)))
      have sqle := (Real.le_sqrt (Nat.cast_nonneg p) (mul_nonneg zero_le_two hx)).mp le
      exact Finset.mem_filter.mpr ⟨Finset.mem_Icc.mpr ⟨pow_pos pp.pos _,
        Nat.le_floor (by simpa only [Nat.cast_pow] using sqle)⟩,p,pp,rfl⟩
  calc
    _ = ∑ n ∈ N.filter isPrimeSquare, Finsupp.single n (e n) := by
      rw [Finset.sum_filter]
      apply Finset.sum_congr rfl
      intro n _
      by_cases h : isPrimeSquare n <;> simp [h]
    _ = ∑ p ∈ T, Finsupp.single (p^2) (e (p^2)) := by
      rw [sets,Finset.sum_image]
      intro p _ q _ eq
      exact Nat.pow_left_injective (by decide : 2 ≠ 0) eq
    _ = _ := by
      rw [squareSequence,show T = _ from rfl,Finset.sum_filter]
      apply Finset.sum_congr rfl
      intro p _
      by_cases pp : p.Prime <;> simp [pp]

/-- Arbitrary fixed divisor weights and primitive residues. The estimate is
uniform over coefficient choices, squarefree moduli and rough support. -/
theorem rough_collision_distribution (k J : ℕ) (A : ℝ) (hA : 0 < A) :
    ∃ K : ℝ, 0 < K ∧ ∀ᶠ x : ℝ in atTop, ∀ (S : Finset ℕ) (a : ℕ → ℕ) (e : ℕ → ℂ),
    S ⊆ Finset.Icc 1 ⌊x^((54:ℝ)/100)⌋₊ →
    (∀ q ∈ S, Squarefree q) → (∀ q ∈ S, (a q).Coprime q) →
    (∀ n ∈ Finset.Icc 1 ⌊2*x⌋₊, ‖e n‖ ≤ (n.divisors.card:ℝ)^k) →
    (∀ n ∈ Finset.Icc 1 ⌊2*x⌋₊, e n ≠ 0 → ¬Squarefree n ∧
      ∀ p : ℕ, p.Prime → p ∣ n → x^(1/6:ℝ) ≤ (p:ℝ)) →
    ∑ q ∈ S, (q.divisors.card:ℝ)^J *
      ‖fullDiscrepancy (∑ n ∈ Finset.Icc 1 ⌊2*x⌋₊, Finsupp.single n (e n)) q (a q)‖ ≤
        K*x/(Real.log x)^A := by
  classical
  obtain ⟨C,X,hC,_,modest⟩ := moderate_square_saving k J A hA
  obtain ⟨D,hD,squares⟩ := pure_square_saving J ((3:ℝ)^k) A (by positivity)
  refine ⟨C+D,add_pos hC hD,?_⟩
  filter_upwards [squares,rough_repeat_split,eventually_ge_atTop X,eventually_ge_atTop (1:ℝ)]
    with x pure split hx hx1
  intro S a e sub sq prim bounded supp
  let N := Finset.Icc 1 ⌊2*x⌋₊
  let f := fun n => if isPrimeSquare n then 0 else e n
  let g := fun n => if isPrimeSquare n then e n else 0
  have fbound (n : ℕ) (hn : n ∈ N) : ‖f n‖ ≤ (n.divisors.card:ℝ)^k := by
    by_cases h : isPrimeSquare n
    · simp only [f,ite_eq_left h,norm_zero]; positivity
    · simpa only [f,ite_eq_right h] using bounded n hn
  have fsupp (n : ℕ) (hn : n ∈ N) (ne : f n ≠ 0) : ∃ p : ℕ, p.Prime ∧
      x^((4:ℝ)/25) ≤ (p:ℝ) ∧ (p:ℝ) ≤ x^((417:ℝ)/1000) ∧ p^2 ∣ n := by
    by_cases h : isPrimeSquare n
    · exact False.elim (ne (ite_eq_left h))
    have en : e n ≠ 0 := by simpa only [f,ite_eq_right h] using ne
    obtain ⟨ns,rough⟩ := supp n hn en
    exact (split n (Finset.mem_Icc.mp hn).1
      ((Nat.cast_le.mpr (Finset.mem_Icc.mp hn).2).trans (Nat.floor_le (by linarith)))
      rough ns).resolve_right h
  have hb := modest x hx S sub a prim f fbound fsupp
  let root := fun p : ℕ => if p.Prime then e (p^2) else 0
  have rootbound (p : ℕ) (hp : p ∈ Finset.Ioc 0 ⌊Real.sqrt (2*x)⌋₊) : ‖root p‖ ≤ (3:ℝ)^k := by
    by_cases pp : p.Prime
    · have le := (Nat.cast_le.mpr (Finset.mem_Ioc.mp hp).2).trans (Nat.floor_le (Real.sqrt_nonneg (2*x)))
      have sqle := (Real.le_sqrt (Nat.cast_nonneg p) (by linarith : 0 ≤ 2*x)).mp le
      have h := bounded (p^2) (Finset.mem_Icc.mpr ⟨pow_pos pp.pos _,
        Nat.le_floor (by simpa only [Nat.cast_pow] using sqle)⟩)
      simpa [root,pp,Nat.divisors_prime_pow pp] using h
    · simp [root,pp]
  have hg := pure S a root sub sq rootbound
  rw [← square_reindex (by linarith : 0 ≤ x) e] at hg
  have eq : (∑ n ∈ N, Finsupp.single n (e n)) =
      (∑ n ∈ N, Finsupp.single n (f n)) + (∑ n ∈ N, Finsupp.single n (g n)) := by
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro n _
    by_cases h : isPrimeSquare n <;> simp [f,g,h]
  change ∑ q ∈ S, _ * ‖fullDiscrepancy (∑ n ∈ N, Finsupp.single n (e n)) q (a q)‖ ≤ _
  rw [eq]
  simp only [hbBoundary_fullDiscrepancy_add]
  calc
    _ ≤ ∑ q ∈ S, ((q.divisors.card:ℝ)^J *
          ‖fullDiscrepancy (∑ n ∈ N, Finsupp.single n (f n)) q (a q)‖ +
        (q.divisors.card:ℝ)^J * ‖fullDiscrepancy (∑ n ∈ N, Finsupp.single n (g n)) q (a q)‖) := by
      apply Finset.sum_le_sum
      intro q _
      rw [← mul_add]
      exact mul_le_mul_of_nonneg_left (norm_add_le _ _) (by positivity)
    _ ≤ _ := by
      rw [Finset.sum_add_distrib]
      exact (add_le_add hb hg).trans_eq (by ring)

/-- Nominal trial bands and any coherent subfamily. The actual row exponent
1−2a exceeds 1/6 at all twelve cutoffs. -/
theorem dense_rough_collisions (k J j : ℕ) (A θ δ a : ℝ) (hA : 0 < A)
    (level : θ ≤ 54/100) (cut : a ≤ 5/12) :
    ∃ K : ℝ, 0 < K ∧ ∀ᶠ x : ℝ in atTop, ∀ (I S : Finset ℕ) (b : ℕ) (e : ℕ → ℂ),
    (∀ p ∈ I, p.Prime) → b.Coprime (∏ p ∈ I, p) →
    S ⊆ PrimeGap180.Distribution.dense j θ δ x I →
    (∀ n ∈ Finset.Icc 1 ⌊2*x⌋₊, ‖e n‖ ≤ (n.divisors.card:ℝ)^k) →
    (∀ n ∈ Finset.Icc 1 ⌊2*x⌋₊, e n ≠ 0 → ¬Squarefree n ∧
      ∀ p : ℕ, p.Prime → p ∣ n → x^(1-2*a) ≤ (p:ℝ)) →
    ∑ q ∈ S, (q.divisors.card:ℝ)^J *
      ‖fullDiscrepancy (∑ n ∈ Finset.Icc 1 ⌊2*x⌋₊, Finsupp.single n (e n)) q b‖ ≤
        K*x/(Real.log x)^A := by
  obtain ⟨K,hK,bound⟩ := rough_collision_distribution k J A hA
  refine ⟨K,hK,?_⟩
  filter_upwards [bound,eventually_ge_atTop (1:ℝ)] with x raw hx
  intro I S b e primes cop sub size support
  have sf : Squarefree (∏ p ∈ I, p) := by
    refine Finset.squarefree_prod_of_pairwise_isCoprime
      (fun p hp q hq hpq => ?_) (fun p hp => (primes p hp).squarefree)
    exact Nat.coprime_iff_isRelPrime.mp ((Nat.coprime_primes (primes p hp) (primes q hq)).2 hpq)
  refine raw S (fun _ => b) e ?_ ?_ ?_ size ?_
  · intro q hq
    have h := Finset.mem_Icc.mp (Finset.mem_filter.mp (sub hq)).1
    exact Finset.mem_Icc.mpr ⟨h.1,h.2.trans (Nat.floor_mono
      (Real.rpow_le_rpow_of_exponent_le hx level))⟩
  · exact fun q hq => sf.squarefree_of_dvd (Finset.mem_filter.mp (sub hq)).2.1
  · exact fun q hq => Nat.Coprime.of_dvd_right (Finset.mem_filter.mp (sub hq)).2.1 cop
  · intro n hn ne
    obtain ⟨ns,rough⟩ := support n hn ne
    exact ⟨ns,fun p hp div => (Real.rpow_le_rpow_of_exponent_le hx
      (by linarith only [cut] : (1:ℝ)/6 ≤ 1-2*a)).trans (rough p hp div)⟩

#print axioms dense_rough_collisions
end PrimeGap180.Collisions
