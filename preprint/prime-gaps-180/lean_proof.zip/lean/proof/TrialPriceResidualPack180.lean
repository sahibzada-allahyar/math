import TrialPricePackedRows180
import TrialLedgerIdentities180

/-! Matrix-vector identities for the literal signed residual of each event.
Each column's positional sum is reused for all 445 output rows. -/
noncomputable section
open scoped BigOperators
open PrimeGap180.Book PrimeGap180.Price PrimeGap180.PricePackedRows
namespace PrimeGap180.PriceResidualPack

variable {n : ℕ}

theorem add (B : ℤ) (f g : Fin n → ℤ) :
    pack B (fun h => f h+g h) = pack B f+pack B g := by
  simp only [pack,add_mul,Finset.sum_add_distrib]

theorem sub (B : ℤ) (f g : Fin n → ℤ) :
    pack B (fun h => f h-g h) = pack B f-pack B g := by
  simp only [pack,sub_mul,Finset.sum_sub_distrib]

theorem scale (B a : ℤ) (f : Fin n → ℤ) :
    pack B (fun h => a*f h) = a*pack B f := by
  simp only [pack,Finset.mul_sum,mul_assoc]

theorem sum {ι : Type*} [Fintype ι] (B : ℤ) (f : ι → Fin n → ℤ) :
    pack B (fun h => ∑ i, f i h) = ∑ i, pack B (f i) := by
  simp only [pack,Finset.sum_mul]
  exact Finset.sum_comm

def gramAction {r : ℕ} (B : ℤ) (F : Fin n → Fin r → ℤ) (g : Fin n) :=
  ∑ k, F g k * pack B (fun h => F h k)

def action (B : ℤ) (b : Ledger) (e : Book.Event) (g : Group) : ℤ :=
  (if e=.prime then 24*b.floors g*pack B b.floors else 0) -
  (24*10^14)*∑ k, LedgerData.rowValue k e * pack B (b.affine k g) +
  ∑ u, LedgerData.incidence u e * gramAction B (b.factor u) g

private theorem physical_form (B : ℤ) (b : Ledger) (e : Book.Event) (g : Group) :
    pack B (LedgerData.residual b.floors b.affine b.rank b.factor e g) = action B b e g := by
  unfold LedgerData.residual action
  by_cases isPrime : e = .prime
  · simp only [isPrime,ite_true,add,sub,scale,sum,gram,gramAction]
  · simp only [isPrime,ite_false,add,sub,scale,sum,gram,gramAction] <;> simp [pack]

theorem signed (B : ℤ) (b : Ledger)
    (form : b.remainder = LedgerData.residual b.floors b.affine b.rank b.factor)
    (e : Book.Event) (g : Group) :
    pack B (intRemainder (b.remainder e) (b.positive e) (b.negative e) g) =
      32^2*action B b e g+gramAction B (b.negative e) g-gramAction B (b.positive e) g := by
  change pack B (fun h => 32^2*b.remainder e g h +
    intGram (b.negative e) g h - intGram (b.positive e) g h) = _
  rw [sub,add,scale,form,physical_form,gram,gram] <;> rfl

#print axioms signed
end PrimeGap180.PriceResidualPack
