import TrialPriceWitnessGroupCommand180
import TrialPriceIsolatedChecks180
import TrialPriceWitnessCharge180
import TrialPriceAffinePhysical180

noncomputable section
namespace PrimeGap180.PriceAssemblyGroup.G001
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyWitnessPriceGroup 1

#print axioms events
end PrimeGap180.PriceAssemblyGroup.G001
namespace PrimeGap180.PriceAssemblyGroup.G002
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyWitnessPriceGroup 2

#print axioms events
end PrimeGap180.PriceAssemblyGroup.G002
namespace PrimeGap180.PriceAssemblyGroup.G003
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyWitnessPriceGroup 3

#print axioms events
end PrimeGap180.PriceAssemblyGroup.G003
namespace PrimeGap180.PriceAssemblyGroup.G004
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyWitnessPriceGroup 4

#print axioms events
end PrimeGap180.PriceAssemblyGroup.G004
