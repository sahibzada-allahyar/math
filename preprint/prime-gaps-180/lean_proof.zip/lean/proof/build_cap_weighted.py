"""Build validated weighted angular sums on the historical grid of one cap (default 36)."""
import argparse
from pathlib import Path
from check_exact_endpoint_pair import Gram,SIGNATURES
from build_historical_site_rows import columns
from build_cap_gram_nodes import name
from build_angular_plans import collected
from cap_bank_names import Names, cap_argument
from endpoint_pair_arithmetic import COUNT,encode


def signatures():
    return sorted({tuple(sorted(s+t)) for s in SIGNATURES for t in SIGNATURES})


def empty_text(names):
    """Signature 0 is the 37th ordinary power (the cap-36 text is `TrialCapWeighted00180.lean.in`)."""
    c,um=names.cap,names.ns('Unmarked')
    ns=names.ns('Weighted00')
    return '\n'.join([f'import {names.module("Power37")}','import TrialCapBankRules180','',
                      f'namespace PrimeGap180.{ns}',f'abbrev lo := {um}.lo37',f'abbrev hi := {um}.hi37','',
                      f'theorem masks : MassAngularBank.safe lo hi := {um}.masks37','',
                      f'theorem actual : MassAngularBank.kept (MassAngularGroups.angular PositiveCap.physicalGrid {c} []) lo hi :=',
                      f'  CapBank.empty {c} lo hi {um}.power37','',
                      '#print axioms actual',f'end PrimeGap180.{ns}',''])


def generate(destination,indices=None,gram=None,cap=36,dry_run=False):
    names=Names(cap)
    legacy=names.legacy
    um=names.ns('Unmarked')
    if gram is None and not dry_run:
        temp=destination/'packed-intermediates';temp.mkdir(parents=True,exist_ok=True)
        gram=Gram(columns()[cap][:COUNT],temp)
    destination.mkdir(parents=True,exist_ok=True)
    sigs=signatures()
    srcs={}
    for k,sig in enumerate(sigs):
        if indices is not None and k not in indices:continue
        num=f'{k:02d}';mod=names.module('Weighted'+num);ns=names.ns('Weighted'+num)
        if not sig:
            path = destination/(mod+'.lean')
            if legacy:
                template = Path(__file__).resolve().with_name('TrialCapWeighted00180.lean.in')
                path.write_bytes(template.read_bytes())
            else:
                path.write_text(empty_text(names))
            srcs[mod] = path
            continue
        def lit(es):return '['+','.join(map(str,es))+']'
        imports={names.fast_module,'TrialMassAngularPlans180'}
        rows=[];proofs=[]
        simp_blocks='blocks,occupied' if legacy else 'CapBank.blocks,CapBank.occupied'
        base='base 37' if legacy else f'CapBank.base {cap} 37'
        for es,m in collected(sig):
            if es:
                module=name('distinct',es,cap);short=module.removeprefix('Trial').removesuffix('180')
                imports.add(module);lo,hi,proof,masks=[short+'.'+n for n in ['lo','hi','actual','masks']]
            else:
                imports.add(names.module('Power37'));lo,hi=f'{um}.lo37',f'{um}.hi37'
                proof=f'(by simpa only [{simp_blocks},List.length_nil,Nat.sub_zero,List.map_nil,List.prod_nil,mul_one] using {base} _ _ {um}.power37)'
                masks=f'{um}.masks37'
            rows.append('⟨'+','.join([lit(es),str(m),lo,hi])+'⟩')
            proofs.append('exact ⟨'+proof+','+masks+'⟩')
        src=['import '+s for s in sorted(imports)]
        src.extend(['',f'namespace PrimeGap180.{ns}','open MassAngularBank MassWeightedBank MassAngularPlan CapWordConvolution',
               'set_option maxRecDepth 32000','set_option maxHeartbeats 0','set_option exponentiation.threshold 100000000'])
        arr=None if dry_run else gram.polynomial(sig)
        for tag in ('lo','hi'):
            fn=f'weighted-{num}-{tag}.bin'
            if arr is not None:(destination/fn).write_bytes(encode(arr.low if tag=='lo' else arr.high,80))
            src.append(f'def {tag} := {names.word} "{fn}" {COUNT*80}')
        verified='Verified inputs' if legacy else f'CapBank.VerifiedAt {cap} inputs'
        src.extend(['private def inputs : List Row := ['+',\n '.join(rows)+']',f'private theorem witness : {verified} := by',
                    '  intro r hr','  simp only [inputs,List.mem_cons,List.not_mem_nil,or_false] at hr'])
        if len(rows)>1:src.append('  rcases hr with '+' | '.join('rfl' for _ in rows));src.extend('  · '+s for s in proofs)
        else:src.extend(['  subst r','  '+proofs[0]])
        if legacy:
            assembly=[f'  exact CapFastAssembly.replaceWords {lit(sig)} inputs lo hi',
                      f'    (assemble {lit(sig)} inputs witness (by decide +kernel) table) decoded.1 decoded.2']
        else:
            assembly=[f'  exact CapBank.replaceWords {cap} {lit(sig)} inputs lo hi',
                      f'    (CapBank.assemble {cap} {lit(sig)} inputs witness (by decide +kernel) table) decoded.1 decoded.2']
        src.extend([f'private theorem table : collect (plan {lit(sig)} (fun _ : Fin 37 => 0) 0)=inputs.map row := check{num}.trans (by rfl)',
                    'private theorem decoded : word inputs false=lo ∧ word inputs true=hi := by decide +kernel',
                    'theorem masks : mask 640 296 130965 lo=true ∧ mask 640 296 130965 hi=true := by decide +kernel',
                    f'theorem actual : kept (MassAngularGroups.angular PositiveCap.physicalGrid {cap} {lit(sig)}) lo hi := by',
                    *assembly,
                    '#print axioms actual',f'end PrimeGap180.{ns}',''])
        f=destination/(mod+'.lean');f.write_text('\n'.join(src));srcs[mod]=f
    return srcs


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    cap_argument(p)
    p.add_argument('--output-dir', type=Path, required=True)
    p.add_argument('--dry-run', action='store_true', help='write Lean text without words')
    a = p.parse_args()
    for n in generate(a.output_dir, cap=a.cap, dry_run=a.dry_run):
        print(n)
