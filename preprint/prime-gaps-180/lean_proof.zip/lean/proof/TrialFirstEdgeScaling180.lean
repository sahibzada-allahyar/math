import TrialFirstEdgeCappedCDF180

/-! The physical regular-cell measure has length h and the reference in
gate ticks has length T*h. These factors cancel after normalizing each
cell. -/
noncomputable section
open MeasureTheory Set
open scoped ENNReal
namespace PrimeGap180.FirstEdgeScaling

theorem pi_scales {X : Type*} [MeasurableSpace X] (d : ℕ) (μ : Fin d→Measure X)
    [∀ i,IsFiniteMeasure (μ i)] (c : Fin d→ℝ≥0∞) (hc : ∀ i,c i<∞) :
    Measure.pi (fun i=>c i • μ i)=(∏ i,c i) • Measure.pi μ := by
  have inst (i : Fin d) : IsFiniteMeasure (c i • μ i):=
    ⟨by rw [Measure.smul_apply,smul_eq_mul];exact ENNReal.mul_lt_top (hc i) (measure_lt_top _ _)⟩
  apply Measure.pi_eq
  intro s _
  rw [Measure.smul_apply,smul_eq_mul,Measure.pi_pi]
  simp only [Measure.smul_apply,smul_eq_mul,Finset.prod_mul_distrib]

theorem pi_scale {X : Type*} [MeasurableSpace X] (d : ℕ) (μ : Fin d→Measure X) [∀ i,IsFiniteMeasure (μ i)]
    (c : ℝ≥0∞) (hc : c<∞) :
    Measure.pi (fun i=>c • μ i)=(c^d) • Measure.pi μ := by
  simpa using pi_scales d μ (fun _=>c) (fun _=>hc)

private theorem saturated (h e z : ℝ) (he : 0<e) (hz : h≤z) :
    FirstEdgeReference.law h e (Iic z)=ENNReal.ofReal h := by
  have eq : FirstEdgeReference.clip h ⁻¹' Iic z=univ:=
    eq_univ_of_forall fun x=>(min_le_left _ _).trans hz
  rw [←FirstEdgeReference.mass (h:=h) he,FirstEdgeReference.law,Measure.smul_apply,Measure.smul_apply,
    Measure.map_apply (by unfold FirstEdgeReference.clip;fun_prop) measurableSet_Iic,
    Measure.map_apply (by unfold FirstEdgeReference.clip;fun_prop) MeasurableSet.univ,preimage_univ,eq]

private theorem negative {h e z : ℝ} (hh : 0<h) (he : 0<e) (hz : z≤0) :
    FirstEdgeReference.law h e (Iic z)=0 := by
  have zw:=FirstEdgeReference.cdf (h:=h) he (z:=0) le_rfl hh
  have le:=measure_mono (μ:=FirstEdgeReference.law h e) (Iic_subset_Iic.mpr hz)
  apply le_zero_iff.mp
  refine le.trans ?_
  simp [zw,min_eq_right he.le]

theorem cdf_units {h e T : ℝ} (hh : 0<h) (he : 0<e) (hT : 0<T) (z : ℝ) :
    (ENNReal.ofReal h)⁻¹*FirstEdgeReference.law h e (Iic (z/T))=
    (ENNReal.ofReal (T*h))⁻¹*FirstEdgeReference.law (T*h) (T*e) (Iic z) := by
  have ht:=mul_pos hT hh
  have et:=mul_pos hT he
  by_cases neg : z≤0
  · rw [negative hh he (div_nonpos_of_nonpos_of_nonneg neg hT.le),negative ht et neg,mul_zero,mul_zero]
  by_cases high : T*h≤z
  · rw [saturated h e _ he (by apply (le_div_iff₀ hT).mpr; linarith only [high]),
        saturated _ _ _ et high,ENNReal.inv_mul_cancel (ENNReal.ofReal_ne_zero_iff.mpr hh) ENNReal.ofReal_ne_top,
        ENNReal.inv_mul_cancel (ENNReal.ofReal_ne_zero_iff.mpr ht) ENNReal.ofReal_ne_top]
  have below : z/T<h := (div_lt_iff₀ hT).mpr (by linarith only [high])
  have nonneg : 0≤z:=le_of_not_ge neg
  rw [FirstEdgeReference.cdf he (div_nonneg nonneg hT.le) below,FirstEdgeReference.cdf et nonneg (lt_of_not_ge high),
      ←ENNReal.div_eq_inv_mul,←ENNReal.div_eq_inv_mul,←ENNReal.ofReal_div_of_pos hh,←ENNReal.ofReal_div_of_pos ht]
  congr 1
  have scale : min (T*e) z=T*min e (z/T) := by
    rw [mul_min_of_nonneg _ _ hT.le,mul_div_cancel₀ _ hT.ne']
  rw [scale]
  field_simp <;> ring

#print axioms pi_scale
#print axioms cdf_units
end PrimeGap180.FirstEdgeScaling
