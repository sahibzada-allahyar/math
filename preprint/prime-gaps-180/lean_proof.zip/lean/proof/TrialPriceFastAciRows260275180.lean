import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G260
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 260

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G260

namespace PrimeGap180.PriceIsolatedGroup.G265
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 265

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G265

namespace PrimeGap180.PriceIsolatedGroup.G270
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 270

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G270

namespace PrimeGap180.PriceIsolatedGroup.G275
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 275

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G275
