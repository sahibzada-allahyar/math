"""Specialize the pinned modulus-sum proof to the four-term matrix hypothesis."""
import argparse
from hashlib import sha256
from pathlib import Path
import re

from build_averaged_slot_proof import DIGESTS as UPPER_DIGESTS, FOOTER, HEADER
from build_sampled_slot_proof import generate as generate_slots


DIGESTS = {
    "MatrixEstimate": "b563b1fa21803bbbcfa3ca8a2b546cd730f274bcb3901bcf82ce1aca3f32cfbf",
    "SharedAveraging": "91bccade94ead41882e9a62a9a37e0e6e41d314fba0c878c0dc591bbc6dbb681",
    "FrequencyAverage": "1f8ee63215099b76d302435f2ca6216f677717936488dbfde6810f514be23c37",
    "OriginalFrequency": "24785b170c2eb0f189d71e6dd12b3d6b7f38be81056b221f1efc3e8c638122bb",
    "CompletedBlock": "79e34afd3e2df1b419504bfe8e12df0c8782c8c142fe3a161427aefb6827256a",
    "ResidualNonzero": "625c026eaf7125c2920857c51e54c397d9e825b64f1da59bf81af7d1268e5429",
    "ResidualTotal": "0a6cf7172583b26b23a34101987075d5480aba4918bee293591e28c8c0c5e9b4",
    "ResidualProfile": "4539fb878c1d8388e574cc24172ac5e4f1caa7f56f69daa7398ec2b2dc415b43",
    "SelectedEstimate": "f84af867420aa4d754afac116d21caeeed45efa0564ad98318a0743d97aad018",
    "SelectedKernelBound": UPPER_DIGESTS["SelectedKernelBound"],
}
SCALES = {
    "matrixThreeScale": "matrixFourScale", "sharedThreeScale": "sharedFourScale",
    "dyadicNonzeroScale": "dyadicFourScale", "nonzeroSGScale": "nonzeroFourSGScale",
    "outer_matrix_scale_comparison": "outer_matrixFourScale_comparison",
    "exists_nonzero_sg_sum_bound": "exists_nonzero_four_sg_sum_bound",
}


def declarations(root, module):
    data = (root / "formal" / f"TypeIII{module}.lean").read_bytes()
    if sha256(data).hexdigest() != DIGESTS[module]:
        raise ValueError(f"Unexpected source revision for {module}")
    source = data.decode()
    start = source.index("theorem LocalFourierHypothesis.exists_matrix_estimate" if module == "MatrixEstimate"
                         else "theorem LocalFourierHypothesis.")
    return source[start:source.index("\n#print axioms", start)].strip()


def adapt(source):
    source = re.sub(r"^    \{C₀? : ℝ\}.*\(hlocal : LocalFourierHypothesis .*\)$",
                    "    (hmatrix : MatrixEstimate)", source, flags=re.MULTILINE)
    source = source.replace("theorem LocalFourierHypothesis.", "theorem ")
    source = re.sub(r"hlocal\.(\w+) hC\b", r"\1 hmatrix", source)
    source = source.replace("exists_matrix_estimate hmatrix", "hmatrix")
    for old, new in SCALES.items():
        source = source.replace(old, new)
    return source.replace("[A, nonzeroFourSGScale]", "[A, nonzeroFourSGScale, nonzeroSGScale]")


def generate(root, output):
    raw = declarations(root, "MatrixEstimate")
    signature = raw[raw.index("    {ε : ℝ}"):raw.index(" := by")].replace(
        "{ε : ℝ} (hε : 0 < ε) :", "∀ {ε : ℝ}, 0 < ε →", 1)
    matrix = "def MatrixEstimate : Prop :=\n" + adapt(signature.replace("Type u", "Type"))
    modules = [
        ("TrialMatrixFrequencies180", ["SharedAveraging", "FrequencyAverage"]),
        ("TrialMatrixResidual180", ["OriginalFrequency", "CompletedBlock", "ResidualNonzero"]),
        ("TrialMatrixBlock180", ["ResidualTotal", "ResidualProfile", "SelectedEstimate", "SelectedKernelBound"]),
    ]
    dependency = "TrialMatrixScales180"
    for index, (name, sources) in enumerate(modules):
        header = HEADER.format(dependency=dependency)
        if index == 2:
            header = "import TrialAveragedSlots180\n" + header
        header += "\nopen scoped Matrix.Norms.L2Operator FourierTransform\nattribute [local instance] familyProductNeZero\n"
        body = [matrix] if index == 0 else []
        for module in sources:
            proof = adapt(declarations(root, module))
            if module == "SelectedKernelBound":
                proof = proof.replace("selectedMomentScale", "selectedSixMoment")
                proof = proof.replace("unfold selectedSixMoment nonzeroFourSGScale",
                                      "unfold selectedSixMoment selectedMomentScale nonzeroSGScale")
                proof = proof.replace("  rw [heq] at hmass", """  rw [heq] at hmass
  have scaleEq : ((R : ℝ) * S)^ε * nonzeroFourSGScale N R S +
      H * (1 + 2 * (S : ℝ) * R)^ε * (1 + (N : ℝ) * (2 * (R : ℝ))^3)^ε *
        zeroSGScale N R S = selectedSixMoment N R S H ε := by
    unfold nonzeroFourSGScale selectedSixMoment selectedMomentScale
    ring
  rw [scaleEq] at hmass""")
            body.append(proof)
        if index == 2:
            body.append("""theorem matrixToBlock (hmatrix : MatrixEstimate) : SelectedBlockEstimate :=
  fun he => exists_selected_kernel_square_estimate hmatrix he""")
            slots = generate_slots(root, "182")
            sig = slots[slots.index("theorem sampledSlots"):].split(" := by", 1)[0]
            sig = adapt(sig.replace("theorem sampledSlots", "theorem sampledSlotsOfMatrix"))
            body.append(sig + """ := by
  exact sampledSlots (matrixToBlock hmatrix) density hdensity D hD «ω» δ σ C0 hω hωupper
    hδ hC0 hσupper hσ hswitch""")
        checks = re.findall(r"^theorem (\w+)", "\n".join(body), re.MULTILINE)
        body.extend("#print axioms " + theorem for theorem in checks)
        (output / (name + ".lean")).write_text(header + "\n\n".join(body) + FOOTER)
        dependency = name
    return [name for name, _ in modules]


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    for name in generate(args.source, args.destination):
        print(name)
