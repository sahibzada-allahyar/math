import TrialDensityTriangleInputs180
namespace PrimeGap180.DensitySimplex.Horner.TriangleChecks
private theorem lower_den9 (z : Fin 2 → ℝ) :
    ((L 9).map (factorValue z)).prod/((unit^3:Int):ℝ) = threeDen (lowerMap (r 9) (s 9) z) := by
  have hr : r 9 = 112993999/10000000000 := by decide +kernel
  have hs : s 9 = 593290501/5000000000 := by decide +kernel
  have forms : L 9 = factors 1412569000 225987998 0 2373162004 := rfl
  rw [hr,hs,forms]
  norm_num [factors,unit,factorValue,Fin.sum_univ_two,threeDen,lowerMap] <;> ring
private theorem upper_den9 (z : Fin 2 → ℝ) :
    ((U 9).map (factorValue z)).prod/((unit^3:Int):ℝ) = threeDen (upperMap (r 9) (s 9) z) := by
  have hr : r 9 = 112993999/10000000000 := by decide +kernel
  have hs : s 9 = 593290501/5000000000 := by decide +kernel
  have forms : U 9 = factors 225987998 0 2373162004 2486156003 := rfl
  rw [hr,hs,forms]
  norm_num [factors,unit,factorValue,Fin.sum_univ_two,threeDen,upperMap] <;> ring

set_option maxRecDepth 65536 in
set_option maxHeartbeats 0 in
theorem row09 : triangleQ (r 9) (s 9) = FrozenNumbers.triangles 9 := by
  rw [triangle_from_forms _ _ (L 9) (U 9) (unit^3) (unit^3) (by decide) (by decide)
    lower_den9 upper_den9]
  decide +kernel

#print axioms row09
end PrimeGap180.DensitySimplex.Horner.TriangleChecks
