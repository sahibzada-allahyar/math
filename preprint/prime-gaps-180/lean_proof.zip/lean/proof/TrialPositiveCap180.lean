import TrialMonotoneSitePrices180
import TrialIdenticalPriceCap180

noncomputable section
open scoped BigOperators Classical
open PrimeGap180.PackedLaw PrimeGap180.PackedSingleFields PrimeGap180.PackedRoleKernels
open PrimeGap180.SignedCapContractions PrimeGap180.CoarseLaw PrimeGap180.DebitNativeClasses
open PrimeGap180.MonotonePriceCaps PrimeGap180.CapPriceRules

namespace PrimeGap180.PositiveCap

private theorem gram_nn (g : Grid) (pos : ∀ t,0 ≤ law g t) (i : Fin 39) (c : Hist) (j k : ℕ) :
    0 ≤ singleGram g i c j k := by
  rw [←single_square]
  apply Finset.sum_nonneg
  intro t _
  split
  · exact mul_nonneg (sq_nonneg _) (Finset.prod_nonneg (fun p _ => pos (t p)))
  · exact le_rfl

private theorem single_nn (g : Grid) (pos : ∀ t,0 ≤ law g t) (i : Fin 39) (c : Hist)
    (inactive : InactiveCaps.changes c=false)
    (prices : ∀ j : Tick,keyPrice j.val (c.val+1) ≤ keyPrice j.val c.val) :
    0 ≤ RoundedCaps.s g i c := by
  unfold RoundedCaps.s
  apply mul_nonneg (by norm_num [Sector.rho])
  apply Finset.sum_nonneg
  intro j _
  rw [InactiveCaps.single g i c inactive j.val,←sub_mul]
  exact mul_nonneg (sub_nonneg.mpr (prices j)) (gram_nn _ pos _ _ _ _)

def settled (c : Hist) := c=0 ∨ c=3 ∨ c=35

theorem bound (g : Grid) (pos : ∀ t,0 ≤ law g t) (c : Hist) (hit : settled c) :
    RoundedCaps.dyad c 1 ≤ RoundedCaps.s g 1 c ∧
    RoundedCaps.dyad c 2 ≤ RoundedCaps.s g 0 c ∧
    RoundedCaps.dyad c 3 ≤ RoundedCaps.s g (Fin.last 38) c := by
  rcases hit with rfl|rfl|rfl
  · have data (i : Fin 39) := single_nn g pos i (0:Hist) (by decide) monotone0
    have q : RoundedCaps.target 0 1=0 ∧ RoundedCaps.target 0 2=0 ∧ RoundedCaps.target 0 3=0 := by decide +kernel
    simpa [RoundedCaps.dyad,q.1,q.2.1,q.2.2] using And.intro (data 1) (And.intro (data 0) (data (Fin.last 38)))
  · have data (i : Fin 39) := single_nn g pos i (3:Hist) (by decide) monotone3
    have q : RoundedCaps.target 3 1=0 ∧ RoundedCaps.target 3 2=0 ∧ RoundedCaps.target 3 3=0 := by decide +kernel
    simpa [RoundedCaps.dyad,q.1,q.2.1,q.2.2] using And.intro (data 1) (And.intro (data 0) (data (Fin.last 38)))
  · exact IdenticalPriceCap.all_three g

#print axioms bound
end PrimeGap180.PositiveCap
