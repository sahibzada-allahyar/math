import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G262
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 262

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G262

namespace PrimeGap180.PriceIsolatedGroup.G267
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 267

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G267

namespace PrimeGap180.PriceIsolatedGroup.G272
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 272

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G272

namespace PrimeGap180.PriceIsolatedGroup.G277
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 277

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G277
