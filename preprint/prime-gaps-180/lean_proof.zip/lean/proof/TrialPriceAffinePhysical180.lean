import TrialPriceAffineTranspose180

noncomputable section
namespace PrimeGap180.PriceAffinePhysical
open Book PriceAffineScatter PriceAffineWord
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

namespace C00
declareAffineFlat 0
private theorem binding : pack 32768 (PriceAffineWord.rows 0) = flat := by decide +kernel
private theorem symmetric : PriceTranspose.run 9 flat = flat := by decide +kernel
theorem row (g : Group) : PriceRows.affine g .prime = encode 445 (word 0 g.val) :=
  affine_of_transpose .prime flat binding symmetric g
end C00

namespace C01
declareAffineFlat 1
private theorem binding : pack 32768 (PriceAffineWord.rows 1) = flat := by decide +kernel
private theorem symmetric : PriceTranspose.run 9 flat = flat := by decide +kernel
theorem row (g : Group) : PriceRows.affine g .sharp = encode 445 (word 1 g.val) :=
  affine_of_transpose .sharp flat binding symmetric g
end C01

namespace C02
declareAffineFlat 2
private theorem binding : pack 32768 (PriceAffineWord.rows 2) = flat := by decide +kernel
private theorem symmetric : PriceTranspose.run 9 flat = flat := by decide +kernel
theorem row (g : Group) : PriceRows.affine g (.higher 0) = encode 445 (word 2 g.val) :=
  affine_of_transpose (.higher 0) flat binding symmetric g
end C02

namespace C03
declareAffineFlat 3
private theorem binding : pack 32768 (PriceAffineWord.rows 3) = flat := by decide +kernel
private theorem symmetric : PriceTranspose.run 9 flat = flat := by decide +kernel
theorem row (g : Group) : PriceRows.affine g (.higher 1) = encode 445 (word 3 g.val) :=
  affine_of_transpose (.higher 1) flat binding symmetric g
end C03

namespace C04
declareAffineFlat 4
private theorem binding : pack 32768 (PriceAffineWord.rows 4) = flat := by decide +kernel
private theorem symmetric : PriceTranspose.run 9 flat = flat := by decide +kernel
theorem row (g : Group) : PriceRows.affine g (.higher 2) = encode 445 (word 4 g.val) :=
  affine_of_transpose (.higher 2) flat binding symmetric g
end C04

namespace C05
declareAffineFlat 5
private theorem binding : pack 32768 (PriceAffineWord.rows 5) = flat := by decide +kernel
private theorem symmetric : PriceTranspose.run 9 flat = flat := by decide +kernel
theorem row (g : Group) : PriceRows.affine g (.higher 3) = encode 445 (word 5 g.val) :=
  affine_of_transpose (.higher 3) flat binding symmetric g
end C05

namespace C06
declareAffineFlat 6
private theorem binding : pack 32768 (PriceAffineWord.rows 6) = flat := by decide +kernel
private theorem symmetric : PriceTranspose.run 9 flat = flat := by decide +kernel
theorem row (g : Group) : PriceRows.affine g (.higher 4) = encode 445 (word 6 g.val) :=
  affine_of_transpose (.higher 4) flat binding symmetric g
end C06

namespace C07
declareAffineFlat 7
private theorem binding : pack 32768 (PriceAffineWord.rows 7) = flat := by decide +kernel
private theorem symmetric : PriceTranspose.run 9 flat = flat := by decide +kernel
theorem row (g : Group) : PriceRows.affine g (.higher 5) = encode 445 (word 7 g.val) :=
  affine_of_transpose (.higher 5) flat binding symmetric g
end C07

namespace C08
declareAffineFlat 8
private theorem binding : pack 32768 (PriceAffineWord.rows 8) = flat := by decide +kernel
private theorem symmetric : PriceTranspose.run 9 flat = flat := by decide +kernel
theorem row (g : Group) : PriceRows.affine g (.higher 6) = encode 445 (word 8 g.val) :=
  affine_of_transpose (.higher 6) flat binding symmetric g
end C08

namespace C09
declareAffineFlat 9
private theorem binding : pack 32768 (PriceAffineWord.rows 9) = flat := by decide +kernel
private theorem symmetric : PriceTranspose.run 9 flat = flat := by decide +kernel
theorem row (g : Group) : PriceRows.affine g (.higher 7) = encode 445 (word 9 g.val) :=
  affine_of_transpose (.higher 7) flat binding symmetric g
end C09

namespace C10
declareAffineFlat 10
private theorem binding : pack 32768 (PriceAffineWord.rows 10) = flat := by decide +kernel
private theorem symmetric : PriceTranspose.run 9 flat = flat := by decide +kernel
theorem row (g : Group) : PriceRows.affine g (.higher 8) = encode 445 (word 10 g.val) :=
  affine_of_transpose (.higher 8) flat binding symmetric g
end C10

namespace C11
declareAffineFlat 11
private theorem binding : pack 32768 (PriceAffineWord.rows 11) = flat := by decide +kernel
private theorem symmetric : PriceTranspose.run 9 flat = flat := by decide +kernel
theorem row (g : Group) : PriceRows.affine g (.higher 9) = encode 445 (word 11 g.val) :=
  affine_of_transpose (.higher 9) flat binding symmetric g
end C11

namespace C12
declareAffineFlat 12
private theorem binding : pack 32768 (PriceAffineWord.rows 12) = flat := by decide +kernel
private theorem symmetric : PriceTranspose.run 9 flat = flat := by decide +kernel
theorem row (g : Group) : PriceRows.affine g (.higher 10) = encode 445 (word 12 g.val) :=
  affine_of_transpose (.higher 10) flat binding symmetric g
end C12

namespace C13
declareAffineFlat 13
private theorem binding : pack 32768 (PriceAffineWord.rows 13) = flat := by decide +kernel
private theorem symmetric : PriceTranspose.run 9 flat = flat := by decide +kernel
theorem row (g : Group) : PriceRows.affine g (.higher 11) = encode 445 (word 13 g.val) :=
  affine_of_transpose (.higher 11) flat binding symmetric g
end C13

/-- All fourteen original affine matrices permit a direct signed-row encoding
at every physical group. The finite whole-matrix equalities are checked above. -/
theorem row (g : Group) (k : Book.Row) :
    PriceRows.affine g k = encode 445 (word (FrozenGuards.code k) g.val) := by
  cases k with
  | prime => exact C00.row g
  | sharp => exact C01.row g
  | higher i =>
    fin_cases i
    · exact C02.row g
    · exact C03.row g
    · exact C04.row g
    · exact C05.row g
    · exact C06.row g
    · exact C07.row g
    · exact C08.row g
    · exact C09.row g
    · exact C10.row g
    · exact C11.row g
    · exact C12.row g
    · exact C13.row g

#print axioms row
end PrimeGap180.PriceAffinePhysical
