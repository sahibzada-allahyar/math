import TrialCutGeometry180
import TrialThreePrimeBoxes180

/-! Ordinary distribution with the cutoffs used for diameter 180. Adapted
from the indicated Harman modules in romyar1/prime-gaps-lean, revision
b77bf175bdedc5123027b3fcf0abc38427975770, by GPT-6 Astra (OpenAI),
prompted by Romyar Sharifi, and the upstream OpenAI PrimeGaps186 proof.
Apache 2.0 notices are retained in tmp/prime-gap-upstream/LICENSE-OpenAI. -/
noncomputable section
open scoped BigOperators Topology
open Filter PrimeGap186
namespace PrimeGap180.Ordinary
variable {k : ℕ}

def ClosedBoxBV (k : ℕ) (θ : ℝ) : Prop :=
    ∀ A : ℝ, 0 < A → ∃ K X : ℝ, 0 < K ∧ Real.exp 100 ≤ X ∧
      ∀ x : ℝ, X ≤ x → ∀ L U : Fin k → ℝ,
      (∀ i, x ^ (1 / 10 : ℝ) ≤ L i ∧ L i ≤ U i ∧ U i ≤ 2 * L i) →
      x / 32 ≤ (∏ i, L i) → (∏ i, L i) ≤ 2 * x →
      ∀ Q : Finset ℕ, Q ⊆ Finset.Icc 1 ⌊x ^ θ⌋₊ →
      ∀ a : ℕ → ℕ, (∀ q ∈ Q, Nat.Coprime (a q) q) →
      let P (i : Fin k) := (Finset.Icc ⌈L i⌉₊ ⌊U i⌋₊).filter Nat.Prime
      (∑ q ∈ Q, ‖fullDiscrepancy
        (∑ p ∈ Fintype.piFinset P, Finsupp.single (∏ i, p i) (1 : ℂ)) q (a q)‖) ≤
        K * x / (Real.log x) ^ A

open Classical in
theorem ordinary_cut_distribution
    (hk : k ≤ 4) (θ : ℝ) (box : ClosedBoxBV (k+1) θ) (hθ0 : 0 < θ) (hθ : θ < 1 / 2) :
    ∀ A : ℝ, 0 < A → ∃ K X : ℝ, 0 < K ∧ Real.exp 100 ≤ X ∧
      ∀ x : ℝ, X ≤ x →
      ∀ M : Finset (PrimeGap182Analytic.Harman.MinorantSmallMonomialCut (k+1)), ∀ C : (Fin (k+1) → ℕ) → Prop,
      M.card ≤ 32 →
      (∀ d ∈ M, d.numerator.Nonempty ∧ Disjoint d.numerator d.denominator ∧
        d.numerator.card + d.denominator.card ≤ k+1 ∧ 0 < d.threshold) →
      let P : Finset ℕ :=
        (Finset.Icc ⌈x ^ ((4 : ℝ) / 25)⌉₊
          ⌊x ^ ((9 : ℝ) / 10)⌋₊).filter Nat.Prime
      let T := Fintype.piFinset (fun _ : Fin (k+1) => P)
      (∀ p ∈ T, ∀ q ∈ T,
        (∀ d ∈ M,
          (if d.lower then
            if d.strict then d.threshold < d.value p else d.threshold ≤ d.value p
          else if d.strict then d.value p < d.threshold else d.value p ≤ d.threshold) ↔
          (if d.lower then
            if d.strict then d.threshold < d.value q else d.threshold ≤ d.value q
          else if d.strict then d.value q < d.threshold else d.value q ≤ d.threshold)) →
        (C p ↔ C q)) →
      (∀ p ∈ T, C p → (∏ i, p i) ∈ Finset.Icc ⌈x⌉₊ ⌊2 * x⌋₊) →
      ∀ Q : Finset ℕ, Q ⊆ Finset.Icc 1 ⌊x ^ θ⌋₊ →
      ∀ a : ℕ → ℕ, (∀ q ∈ Q, Nat.Coprime (a q) q) →
        let F : ℕ →₀ ℂ :=
          ∑ p ∈ T, Finsupp.single (∏ i, p i) (if C p then 1 else 0)
        (∑ q ∈ Q, ‖fullDiscrepancy F q (a q)‖) ≤ K * x / (Real.log x) ^ A := by
  intro A hA
  have hθ1 : θ < 1 := by linarith
  let D : ℝ := A + 20
  let E : ℝ := 5 * (D + 1)
  have hD : 0 ≤ D := by dsimp [D]; linarith
  have hE : 0 ≤ E := by dsimp [E]; positivity
  obtain ⟨Kb, Xb, hKb, hXb, hbox⟩ :=
    box (A + E) (by linarith)
  obtain ⟨Xs, hXs⟩ := Filter.eventually_atTop.mp
    ((isLittleO_log_rpow_rpow_atTop (A + 18)
      (by norm_num : (0 : ℝ) < 4 / 25)).eventuallyLE)
  let C0 : ℝ := 2 + Real.log 64
  let Cb : ℝ := 8 * (17 * 64) * (1023 + 1) * C0 ^ 16
  let K : ℝ := (6 : ℝ) ^ 5 * Kb + 32 * Cb
  have hC0 : 0 < C0 := by
    have := Real.log_nonneg (by norm_num : (1 : ℝ) ≤ 64)
    dsimp only [C0]
    linarith
  have hK : 0 < K := by dsimp only [K, Cb]; positivity
  refine ⟨K, max Xb Xs, hK, hXb.trans (le_max_left _ _), ?_⟩
  intro x hx M C hMcard hM P T hboolean hsupport Q hQ a ha F
  have hxb : Xb ≤ x := (le_max_left _ _).trans hx
  have hxs : Xs ≤ x := (le_max_right _ _).trans hx
  have hx100 : Real.exp 100 ≤ x := hXb.trans hxb
  have hx0 : 0 < x := (Real.exp_pos 100).trans_le hx100
  have hx2 : 2 ≤ x := by
    have := Real.add_one_le_exp (100 : ℝ)
    linarith
  have hx1 : 1 ≤ x := by linarith
  have hxexp : Real.exp 1 ≤ x :=
    (Real.exp_le_exp.mpr (by norm_num : (1 : ℝ) ≤ 100)).trans hx100
  have hlog100 : 100 ≤ Real.log x := (Real.le_log_iff_exp_le hx0).mpr hx100
  have hlog1 : 1 ≤ Real.log x := by linarith
  have hlog0 : 0 < Real.log x := by linarith
  let l : ℝ := Real.log x
  let h : ℝ := l ^ (-D)
  let bin (p : ℕ) := ⌊Real.logb (1 + h) (p : ℝ)⌋₊
  let label (p : Fin (k+1) → ℕ) : Fin (k+1) → ℕ := fun i => bin (p i)
  let B := T.image label
  let U (b : Fin (k+1) → ℕ) := T.filter (fun p => label p = b)
  let V := B.filter (fun b => ∃ p ∈ U b, C p)
  let W := V.filter (fun b => ¬∀ p ∈ U b, C p)
  let Fbox (b : Fin (k+1) → ℕ) : ℕ →₀ ℂ :=
    ∑ p ∈ U b, Finsupp.single (∏ i, p i) 1
  have hmesh := geometric_log_mesh_spec D x hD hxexp
  have hh : 0 < h := hmesh.1
  have hh1 : h ≤ 1 := hmesh.2.1
  have hcardB : (B.card : ℝ) ≤ (6 : ℝ) ^ 5 * l ^ E :=
    PrimeGap182Analytic.Harman.trial_small_prime_geometric_box_card_polylog hk D x hD hxexp
  have hcardV : (V.card : ℝ) ≤ (6 : ℝ) ^ 5 * l ^ E :=
    (Nat.cast_le.mpr (Finset.card_filter_le B _)).trans hcardB
  have hBbound (b : Fin (k+1) → ℕ) (hb : b ∈ V) :
      (∑ q ∈ Q, ‖fullDiscrepancy (Fbox b) q (a q)‖) ≤ Kb * x / l ^ (A + E) := by
    obtain ⟨p, hp, hCp⟩ := (Finset.mem_filter.mp hb).2
    have hpT := (Finset.mem_filter.mp hp).1
    have hlabel := (Finset.mem_filter.mp hp).2
    have hprod := hsupport p hpT hCp
    let Lb (i : Fin (k+1)) : ℝ := max (x ^ ((4 : ℝ) / 25)) ((1 + h) ^ b i)
    let Rb (i : Fin (k+1)) : ℝ := min (x ^ ((9 : ℝ) / 10))
      ((⌈(1 + h) ^ (b i + 1)⌉₊ - 1 : ℕ) : ℝ)
    have hscales := PrimeGap182Analytic.Harman.trial_small_prime_geometric_active_scales hk x h hx2 hh hh1 b p
      (Fintype.mem_piFinset.mp hpT) (fun i => congrFun hlabel i) hprod
    have hU : U b = Fintype.piFinset (fun i : Fin (k+1) =>
        (Finset.Icc ⌈Lb i⌉₊ ⌊Rb i⌋₊).filter Nat.Prime) := by
      have hboxes := (finite_small_prime_box_cut_decomposition P bin C).1 b
      change U b = Fintype.piFinset (fun i : Fin (k+1) => P.filter (fun p => bin p = b i)) at hboxes
      rw [hboxes]
      congr 1
      funext i
      exact PrimeGap182Analytic.Harman.trial_small_prime_geometric_bin_eq_closed_interval x h hx0 hh (b i)
    have hb' := hbox x hxb Lb Rb hscales.1 hscales.2.1 hscales.2.2 Q hQ a ha
    simpa only [Fbox, hU, l] using hb'
  have hinterior :
      (∑ b ∈ V, ∑ q ∈ Q, ‖fullDiscrepancy (Fbox b) q (a q)‖) ≤
        (6 : ℝ) ^ 5 * Kb * x / l ^ A := by
    calc
      _ ≤ ∑ b ∈ V, Kb * x / l ^ (A + E) := Finset.sum_le_sum hBbound
      _ = (V.card : ℝ) * (Kb * x / l ^ (A + E)) := by simp
      _ ≤ ((6 : ℝ) ^ 5 * l ^ E) * (Kb * x / l ^ (A + E)) :=
        mul_le_mul_of_nonneg_right hcardV (by positivity)
      _ = _ := by
        dsimp only [l]
        rw [Real.rpow_add hlog0]
        field_simp [(Real.rpow_pos_of_pos hlog0 A).ne',
          (Real.rpow_pos_of_pos hlog0 E).ne']
  have hW : W = B.filter
      (fun b => (∃ p ∈ U b, C p) ∧ ¬∀ p ∈ U b, C p) := by
    ext b
    simp only [W, V, Finset.mem_filter, and_assoc]
  have hmass : (∑ b ∈ W, ((U b).card : ℝ)) ≤
      (M.card : ℝ) * 64 * (1023 * h * x + x ^ (1 - (4 : ℝ) / 25)) *
        (1 + Real.log (64 * x)) ^ 16 := by
    rw [hW]
    apply PrimeGap182Analytic.Harman.trial_boolean_small_monomial_mixed_geometric_box_card hk x h hx2 hh hh1 M C hM hboolean
    intro p hp hCp
    exact (Nat.cast_le.mpr (Finset.mem_Icc.mp (hsupport p hp hCp)).2).trans
      (Nat.floor_le (by positivity))
  have hQsub : Q ⊆ Finset.Icc 1 ⌊x ^ θ⌋₊ := hQ
  clear_value P bin
  have hφsum : (∑ q ∈ Q, 1 / (q.totient : ℝ)) ≤ 4 * l ^ 2 := by
    let Q₀ := Finset.Icc 1 ⌊x ^ θ⌋₊
    have hq1 : 1 ≤ ⌊x ^ θ⌋₊ :=
      Nat.le_floor (by simpa only [Nat.cast_one] using Real.one_le_rpow hx1 hθ0.le)
    have hqx : (⌊x ^ θ⌋₊ : ℝ) ≤ x :=
      (Nat.floor_le (Real.rpow_nonneg hx0.le θ)).trans
        (Real.rpow_le_self_of_one_le hx1 hθ1.le)
    have hlogQ : Real.log (⌊x ^ θ⌋₊ : ℝ) ≤ l :=
      Real.log_le_log (by exact_mod_cast zero_lt_one.trans_le hq1) hqx
    have hmoment : (∑ q ∈ Q₀, 1 / (q.totient : ℝ)) ≤
        (harmonic ⌊x ^ θ⌋₊ : ℝ) ^ 2 := by
      calc
        _ ≤ ∑ q ∈ Q₀, (q.divisors.card : ℝ) / (q : ℝ) := by
          apply Finset.sum_le_sum
          intro q hq
          have hq0 : 0 < (q : ℝ) := Nat.cast_pos.mpr (Finset.mem_Icc.mp hq).1
          have ht := div_totient_le_card_divisors q
          calc
            1 / (q.totient : ℝ) = ((q : ℝ) / (q.totient : ℝ)) / q := by
              field_simp [hq0.ne']
            _ ≤ _ := div_le_div_of_nonneg_right ht hq0.le
        _ ≤ ∑ q ∈ Q₀,
            (((ArithmeticFunction.zeta : ArithmeticFunction ℕ) ^ 2) q : ℝ) / (q : ℝ) := by
          apply Finset.sum_le_sum
          intro q hq
          apply div_le_div_of_nonneg_right _ (Nat.cast_nonneg q)
          have ht := card_divisors_pow_le_zeta_pow 1 q
            (Finset.mem_Icc.mp hq).1
          norm_num only [pow_one, pow_one] at ht
          exact_mod_cast ht
        _ ≤ _ := sum_zeta_pow_div_le_harmonic_pow 2 _
    have hH : (harmonic ⌊x ^ θ⌋₊ : ℝ) ≤ 2 * l := by
      have ht := (harmonic_le_one_add_log ⌊x ^ θ⌋₊).trans (add_le_add (le_refl 1) hlogQ)
      dsimp only [l] at *
      linarith
    have hsub : Q ⊆ Q₀ := hQsub
    exact (Finset.sum_le_sum_of_subset_of_nonneg hsub
      (fun _ _ _ => by positivity)).trans
      (hmoment.trans ((pow_le_pow_left₀ (by unfold harmonic; positivity) hH 2).trans_eq
        (by ring)))
  have hsmallx : l ^ (A + 18) ≤ x ^ ((4 : ℝ) / 25) := by
    simpa only [Real.norm_of_nonneg (Real.rpow_nonneg hlog0.le _),
      Real.norm_of_nonneg (Real.rpow_nonneg hx0.le _), l] using hXs x hxs
  have hmassScaled : (∑ b ∈ W, ((U b).card : ℝ)) / 32 ≤
      17 * 64 * (1023 * h * x + x ^ (1 - (4 : ℝ) / 25)) *
        (1 + Real.log (64 * x)) ^ 16 := by
    apply (div_le_iff₀ (by norm_num : (0 : ℝ) < 32)).mpr
    have hcount : (M.card : ℝ) ≤ 32 := by exact_mod_cast hMcard
    have hz : 0 ≤ 64 * (1023 * h * x + x ^ (1 - (4 : ℝ) / 25)) *
        (1 + Real.log (64 * x)) ^ 16 := by positivity
    nlinarith only [hmass, mul_le_mul_of_nonneg_right hcount hz, hz]
  have hboundary :
      2 * (∑ b ∈ W, ((U b).card : ℝ)) * (∑ q ∈ Q, 1 / (q.totient : ℝ)) ≤
        (32 * Cb) * x / l ^ A := by
    have hmassNonneg : 0 ≤ ∑ b ∈ W, ((U b).card : ℝ) :=
      Finset.sum_nonneg fun _ _ => Nat.cast_nonneg _
    have hφNonneg : 0 ≤ ∑ q ∈ Q, 1 / (q.totient : ℝ) :=
      Finset.sum_nonneg fun _ _ => one_div_nonneg.mpr (Nat.cast_nonneg _)
    have hb := PrimeGap182Analytic.Harman.trial_minorant_boundary_log_arithmetic A x
      ((∑ b ∈ W, ((U b).card : ℝ)) / 32) (∑ q ∈ Q, 1 / (q.totient : ℝ))
      hA hxexp (div_nonneg hmassNonneg (by norm_num)) hφNonneg hmassScaled hφsum hsmallx
    calc
      _ = 32 * (2 * ((∑ b ∈ W, ((U b).card : ℝ)) / 32) *
          (∑ q ∈ Q, 1 / (q.totient : ℝ))) := by ring
      _ ≤ 32 * (Cb * x / l ^ A) := mul_le_mul_of_nonneg_left hb (by norm_num)
      _ = _ := by ring
  have harith : (6 : ℝ) ^ 5 * Kb * x / l ^ A +
      (32 * Cb) * x / l ^ A = K * x / l ^ A := by
    dsimp only [K]
    ring
  have hcover := finite_small_prime_box_discrepancy_cover P bin C Q a
  exact hcover.trans ((add_le_add hinterior hboundary).trans_eq harith)


#print axioms ordinary_cut_distribution
end PrimeGap180.Ordinary
