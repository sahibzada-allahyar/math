import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G283
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 283

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G283

namespace PrimeGap180.PriceIsolatedGroup.G288
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 288

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G288

namespace PrimeGap180.PriceIsolatedGroup.G293
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 293

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G293

namespace PrimeGap180.PriceIsolatedGroup.G298
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 298

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G298
