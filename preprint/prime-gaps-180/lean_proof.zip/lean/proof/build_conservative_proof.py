"""Generate, audit and compile the diameter-180 conservative Lean application."""
import argparse
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
import fcntl
from graphlib import TopologicalSorter
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
REPO = HERE.parent
PIN = 'b77bf175bdedc5123027b3fcf0abc38427975770'
TOOLCHAIN = 'leanprover/lean4:v4.34.0-rc2'
TARGETS = ['TrialRobustTransfer180', 'TrialNativeContractions180', 'TrialDeletionSymmetry180',
           'TrialPhysicalProjection180', 'TrialOccupiedEdge180']
ALLOWED_AXIOMS = {'propext', 'Classical.choice', 'Quot.sound'}
MODULE = re.compile(r'[\w.]+')


def file_hash(path):
    h = sha256()
    with path.open('rb') as stream:
        while block := stream.read(2**20):
            h.update(block)
    return h.hexdigest()


def save(path, data):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, indent=2, sort_keys=True)+'\n')
    tmp.replace(path)


def output(cmd, **kwargs):
    return subprocess.check_output(cmd, text=True, **kwargs).strip()


def pinned(upstream):
    git = ['git', '-C', str(upstream)]
    if output(git+['rev-parse', 'HEAD']) != PIN or (upstream/'lean-toolchain').read_text().strip() != TOOLCHAIN:
        raise ValueError(f'Expected upstream revision {PIN} and toolchain {TOOLCHAIN}')
    tracked = ['formal', 'vendor', 'lakefile.toml', 'lake-manifest.json', 'lean-toolchain']
    if output(git+['diff', '--name-only', 'HEAD', '--', *tracked]):
        raise ValueError('Tracked upstream sources or Lake configuration differ from the pinned commit')
    names = output(git+['ls-tree','--name-only','-r','HEAD','--','formal','vendor/primegaps186']).splitlines()
    result = {}
    for name in names:
        if name.endswith('.lean'):
            relative = name.removeprefix('formal/').removeprefix('vendor/primegaps186/')
            result[relative[:-5].replace('/','.')] = upstream/name
    return result


def write_generated(upstream, build):
    sources = {}
    for stem in ('sifted_families','averaged_slot_proof','matrix_block_proof'):
        dest = build/'generated'/stem
        dest.mkdir(parents=True, exist_ok=True)
        with (build/'logs'/f'generate_{stem}.log').open('w') as log:
            subprocess.run([sys.executable, HERE/f'build_{stem}.py', upstream, dest], check=True,
                           cwd=HERE, stdout=log, stderr=subprocess.STDOUT)
        # Only known outputs are available as imports, even with an old build directory.
        if stem == 'sifted_families':
            from build_sifted_families import MODULES, module_name
            names = ['TrialSiftedFamilies180', *(module_name(i,m) for i in range(12) for m in MODULES)]
        else:
            names = (build/'logs'/f'generate_{stem}.log').read_text().splitlines()
        for name in names:
            path = dest/(name+'.lean')
            if not MODULE.fullmatch(name) or not path.is_file() or name in sources:
                raise ValueError(f'Invalid generated module {name}')
            sources[name] = path
    return sources


def imports(path):
    # All historical and generated sources use plain import commands at column zero.
    for line in path.read_text().splitlines():
        m = re.match(r'^(?:(?:public|meta)\s+)*import\s+(.+)', line)
        if m:
            for name in m[1].partition('--')[0].split():
                if not MODULE.fullmatch(name):
                    raise ValueError(f'Unsupported import in {path}: {line}')
                yield name


def graph(upstream, build, targets):
    upstream_modules = pinned(upstream)
    archive = {p.stem:p for p in HERE.glob('*.lean')}
    generated = write_generated(upstream,build)
    for n in archive.keys() & generated.keys():
        if archive[n].read_bytes() != generated[n].read_bytes():
            raise ValueError(f'Generated and tracked copies differ for {n}')
    available = {**archive, **generated}
    legacy_names = output(['git','-C',REPO,'ls-files','--','tmp/prime-gap-upstream/*.lean']).splitlines()
    legacy = {Path(name).stem:REPO/name for name in legacy_names}
    sources, deps, externals = {}, {}, set()
    def historical_site_module(n):
        return n == 'TrialHistoricalSiteGrid180' or re.fullmatch(r'TrialSiteShard[0-9]{3}180', n) is not None
    def density_sample_module(n):
        return n == "TrialDensitySampleWords180" or re.fullmatch(r"TrialDensitySampleBlock[0-9]{2}180", n) is not None
    def density_moment_module(n):
        return n == "TrialDensityCombinedMoments180" or re.fullmatch(r"TrialDensityMomentI[0-9]{2}180", n) is not None
    def cap_square_module(n):
        return n in {"TrialCapSquareNumbers180", "TrialCapAlignedGrid180"} or re.fullmatch(r"TrialCapAlignedBlock0[0-7]180", n) is not None
    def cap_power_module(n):
        return re.fullmatch(r"TrialCapPower[0-9]{2}180", n) is not None
    def raw_angular_module(n):
        return re.fullmatch(r"TrialCapRawAtom(?:Data)?(0[2-9]|1[0-2])180", n)
    def cap_end_site(n):
        return re.fullmatch(r"TrialCapEndSite(?:Data)?(01|02|11|12|22)180", n)
    def cap_end_pair(n):
        return re.fullmatch(r"TrialCapEndPair([012]{4})180", n)
    def signed_pair_window(n):
        return re.fullmatch(r"TrialRawDotTwo(?:Score|Sample)0[0-9]180", n)
    def gram_product(n):
        return re.fullmatch(r"TrialCapGram(Base|Group|Distinct)V([0-9]{2}(?:X[0-9]{2})*)180", n)
    def weighted_signature(n):
        return re.fullmatch(r"TrialCapWeighted([0-4][0-9]|5[0-2])180", n)
    def cap36_score_module(n):
        return n == "TrialMassCap36Scores180" or re.fullmatch(
            r"TrialCap36(?:WordReader|WordEnd[012]{4}|WordAng[0-9]{2}|ScoreBase|Rows[0-8]|RowTable|Radial[0-9]{2}|RadialTable|Score[0-9]{4})180", n) is not None
    # Banks and scores of the eight other changing caps (cap_bank_names.Names), e.g. TrialCap07Weighted00180.
    def cap_bank_module(n):
        return re.fullmatch(r"TrialCap(07|08|15|23|26|30|33|34)(SquareNumbers|AlignedGrid|AlignedBlock0[0-7]|Unmarked"
                            r"|Power[0-9]{2}|RawAtom(?:Data)?(?:0[2-9]|1[0-2])|EndSite(?:Data)?(?:01|02|11|12|22)"
                            r"|EndPair[012]{4}|Gram(?:Base|Group|Distinct)V[0-9]{2}(?:X[0-9]{2})*"
                            r"|Weighted(?:[0-4][0-9]|5[0-2])|MassBank)180", n)
    def cap_score_module(n):
        return re.fullmatch(r"TrialCap(07|08|15|23|26|30|33|34)(?:WordEnd[012]{4}|WordAng[0-9]{2}|ScoreBase"
                            r"|Rows(?:Now|Next)[0-8]|RowTable|Radial[0-9]{3}|RadialTable|Score[0-9]{4}|MassScores)180", n)
    def visit(n):
        if n in sources:
            return
        if n not in available and historical_site_module(n):
            from build_historical_site_rows import generate
            available.update(generate(build/'generated'/'historical_site_rows'))
        if n not in available and density_sample_module(n):
            from check_packed_five_moments import generate_samples
            available.update(generate_samples(build/"generated"/"density_samples"))
        if n not in available and density_moment_module(n):
            from check_packed_five_moments import generate_moments
            available.update(generate_moments(build/"generated"/"density_moments"))
        if n not in available and cap_square_module(n):
            from build_cap_square import generate
            available.update(generate(build/'generated'/'cap_square'))
        if n not in available and cap_power_module(n):
            from build_cap_unmarked import generate
            available.update(generate(build / 'generated' / 'cap_powers'))
        if n not in available and n == 'TrialCapAtomR180':
            from build_cap_reciprocal import generate
            available.update(generate(build/'generated'/'cap_reciprocal'))
        if n not in available and (raw := raw_angular_module(n)):
            from build_cap_raw_atoms import generate
            available.update(generate(build/'generated'/'cap_raw_atoms', int(raw[1])))
        if n not in available and (pair := cap_end_site(n)):
            from build_cap_end_site import generate
            available.update(generate(build/'generated'/'cap_end_sites', pair[1]))
        if n not in available and (pair := cap_end_pair(n)):
            from build_cap_end_pairs import generate
            available.update(generate(build/'generated'/'cap_end_pairs', pair[1]))
        if n not in available and signed_pair_window(n):
            from build_signed_pair_windows import generate
            available.update(generate(build/'generated'/'cap_signed_pair'))
        if n not in available and (node := gram_product(n)):
            from build_cap_gram_nodes import generate
            powers = tuple(int(k) for k in node[2].split('X'))
            target = (node[1].lower(), powers)
            available.update(generate(build/'generated'/'cap_gram', [target]))
        if n not in available and (sig := weighted_signature(n)):
            from build_cap_weighted import generate
            available.update(generate(build/'generated'/'cap_gram', [int(sig[1])]))
        if n not in available and cap36_score_module(n):
            # The score bounds are computed from the factor words, so write every bank first.
            visit('TrialCheckedEnds36180')
            visit('TrialCapAngularBank36180')
            from build_cap36_scores import generate
            available.update(generate(build/'generated'/'cap36_scores', build/'generated',
                                      jobs=max(1, min(8, os.cpu_count() or 1))))
        if n not in available and (bank := cap_bank_module(n)):
            from cap_bank_names import Names
            cap, kind, root = int(bank[1]), bank[2], build/'generated'
            names = Names(cap)
            if kind in {'SquareNumbers', 'AlignedGrid', 'Unmarked'} or kind.startswith('AlignedBlock'):
                from build_cap_square import generate
                available.update(generate(root/names.directory('square'), cap))
            elif kind.startswith('Power'):
                from build_cap_unmarked import generate
                available.update(generate(root/names.directory('powers'), cap))
            elif part := re.fullmatch(r'RawAtom(?:Data)?([0-9]{2})', kind):
                from build_cap_raw_atoms import generate
                available.update(generate(root/names.directory('raw_atoms'), int(part[1]), cap))
            elif part := re.fullmatch(r'EndSite(?:Data)?([0-9]{2})', kind):
                from build_cap_end_site import generate
                available.update(generate(root/names.directory('end_sites'), part[1], cap))
            elif kind.startswith('EndPair'):
                from build_cap_end_pairs import generate
                available.update(generate(root/names.directory('end_pairs'), kind[7:], cap))
            elif part := re.fullmatch(r'Gram(Base|Group|Distinct)V([0-9X]+)', kind):
                from build_cap_gram_nodes import generate
                target = (part[1].lower(), tuple(int(k) for k in part[2].split('X')))
                available.update(generate(root/names.directory('gram'), [target], cap=cap))
            elif kind.startswith('Weighted'):
                from build_cap_weighted import generate
                available.update(generate(root/names.directory('gram'), [int(kind[8:])], cap=cap))
            else:
                from build_cap_bank import generate_bank
                available.update(generate_bank(root, cap))
        if n not in available and (score := cap_score_module(n)):
            # As for cap 36: the score bounds are computed from the factor words, so write the whole bank first.
            from cap_bank_names import Names
            cap = int(score[1])
            visit(Names(cap).module('MassBank'))
            from build_cap_scores import generate
            available.update(generate(build/'generated'/Names(cap).directory('scores'), build/'generated',
                                      jobs=max(1, min(8, os.cpu_count() or 1)), cap=cap))
        p = available.get(n) or legacy.get(n)
        if not p:
            raise ValueError(f'Missing local source for {n}')
        sources[n] = p
        deps[n] = []
        for im in imports(p):
            if (im in available or historical_site_module(im) or density_sample_module(im)
                    or density_moment_module(im) or cap_square_module(im) or cap_power_module(im)
                    or im == 'TrialCapAtomR180' or raw_angular_module(im) or gram_product(im)
                    or weighted_signature(im) or cap_end_site(im) or cap_end_pair(im)
                    or signed_pair_window(im) or cap36_score_module(im)
                    or cap_bank_module(im) or cap_score_module(im)
                    or (im in legacy and im not in upstream_modules)):
                deps[n].append(im)
                visit(im)
            elif im in upstream_modules or im.split('.')[0] in {'Mathlib','Batteries','Aesop','Qq'}:
                externals.add(im)
            elif im.split('.')[0] not in {'Lean','Std','Init'}:
                raise ValueError(f'Unresolved import {im} from {p}')
    for target in targets:
        visit(target)
    order = list(TopologicalSorter(deps).static_order())
    tool_digest = file_hash(Path(__file__))
    fingerprints = {}
    records = {}
    for n in order:
        p = sources[n]
        inputs = [p.parent/f for f in re.findall(r'include_str\s+"([^"]+)"',p.read_text())]
        if n in {'TrialPackedLedger180','TrialPriceReflectedRows180','TrialPriceFactorArchive180'}:
            inputs += [HERE/'read_frozen_ledger.py', HERE/'frozen_ledger_supplement.zip',
                       HERE.parent/'minorants'/'data'/'ml12_w25.json.gz']
        if n == 'TrialPriceReflectedRows180':
            inputs.append(HERE/'TrialPriceFactorRows180.py')
        if n == 'TrialPriceFactorArchive180':
            inputs.append(HERE/'TrialPriceFactorWords180.py')
        if n == 'TrialSourceScheduleArchive180':
            inputs += [HERE/'h1_multilevel_tail_tilt2.json', HERE/'frozen_source_long_plans.json']
        if n == 'TrialSourceRectData180':
            inputs.append(HERE/'frozen_source_rectangles.json')
        if n in {'TrialSourceAffineCompactData180','TrialSourceAffineSpanData180'}:
            inputs += [HERE/'read_source_affine_rows.py',
                       HERE.parent/'minorants'/'data'/'ml12_w25.json.gz']
        data = {f.resolve().relative_to(REPO).as_posix():file_hash(f) for f in inputs}
        if n == 'TrialCapSquareNumbers180':
            from build_cap_square import WORD_NAMES
            data.update({name+'.bin':file_hash(p.parent / (name+'.bin')) for name in WORD_NAMES})
        word_names = re.findall(r'(?:packedWord180|cap36Word180|capWord180)%\s+"([A-Za-z0-9_./-]+\.bin)"', p.read_text())
        data.update({name:file_hash(p.parent / name) for name in word_names})
        if n == 'TrialDensitySampleWords180':
            data.update({f.name:file_hash(f) for f in sorted(p.parent.glob('row[0-9][0-9].bin'))})
        tag = p.relative_to(build/'generated') if p.is_relative_to(build/'generated') else p.relative_to(REPO)
        records[n] = dict(source=str(tag),generated=p.is_relative_to(build/'generated'),sha256=file_hash(p),
                          data=data,local_imports=deps[n])
        inputs_for_hash = [PIN,TOOLCHAIN,tool_digest,records[n],[(d,fingerprints[d]) for d in deps[n]]]
        fingerprints[n] = sha256(json.dumps(inputs_for_hash,sort_keys=True).encode()).hexdigest()
    plan = dict(upstream=PIN,toolchain=TOOLCHAIN,targets=targets,upstream_targets=sorted(externals),
                modules=records,order=order)
    save(build/'source-plan.json',plan)
    return sources,deps,externals,order,fingerprints,upstream_modules


def lean_env(upstream, external, build, smoke):
    env = os.environ.copy()
    env.pop('LEAN_PATH',None)
    if not smoke and external:
        with (build/'logs'/'upstream.log').open('w') as log:
            subprocess.run(['lake','build',*('+'+n+':olean' for n in sorted(external))],cwd=upstream,
                           env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    # Lake resolves the exact dependency and toolchain paths from this checkout.
    keys = ['PATH','LEAN_PATH','LEAN_SYSROOT','LD_LIBRARY_PATH','DYLD_LIBRARY_PATH']
    probe = 'import os,json;print(json.dumps({k:os.environ[k] for k in '+repr(keys)+' if k in os.environ}))'
    env.update(json.loads(output(['lake','env',sys.executable,'-c',probe],cwd=upstream,env=env)))
    if 'version 4.34.0-rc2' not in output(['lean','--version'],cwd=upstream,env=env):
        raise ValueError('Lean binary does not match the pinned toolchain')
    for dep in json.loads((upstream/'lake-manifest.json').read_text())['packages']:
        checkout = upstream/'.lake'/'packages'/dep['name']
        git = ['git','-C',checkout]
        if output(git+['rev-parse','HEAD']) != dep['rev'] or output(git+['diff','--name-only','HEAD']):
            raise ValueError(f'Lake dependency {dep["name"]} differs from the locked revision')
    return env


def smoke_upstream(roots, pinned_modules, external, search):
    """Fill missing pinned upstream objects only for an explicitly trusted warm smoke."""
    source_paths = [Path(d) for d in search.split(os.pathsep)]
    todo, seen, borrowed = list(external), set(), {}
    while todo:
        n = todo.pop()
        if n in seen or n not in pinned_modules:
            continue
        seen.add(n)
        src = pinned_modules[n]
        todo.extend(imports(src))
        name = n.replace('.','/')+'.olean'
        if any((d/name).is_file() for d in source_paths):
            continue
        candidates = [p.resolve()/name for p in roots if (p/name).is_file()]
        if not candidates:
            raise ValueError(f'Missing upstream smoke dependency {n}. Build its pinned Lake target first.')
        obj = candidates[0]
        sibling = obj.with_suffix('.lean')
        if sibling.is_file() and sibling.read_bytes()!=src.read_bytes():
            raise ValueError(f'Warm upstream source differs for {n}')
        borrowed[n] = dict(path=str(obj),olean=file_hash(obj),pinned_source=file_hash(src))
    return borrowed


def link_object(candidate, artifact):
    tmp = artifact.with_suffix('.pending-link')
    tmp.unlink(missing_ok=True)
    tmp.symlink_to(candidate)
    tmp.replace(artifact)


def run(args):
    upstream, build = args.upstream.resolve(), args.build_dir.resolve()
    if build.is_relative_to(REPO) or build.is_relative_to(upstream):
        raise ValueError('Choose an external build directory to keep generated sources and caches out of both repositories')
    build.mkdir(parents=True,exist_ok=True)
    with (build/'.build-lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        (build/'logs').mkdir(exist_ok=True)
        targets = list(dict.fromkeys(args.target or TARGETS))
        smoke = bool(args.smoke_cache)
        mode = 'smoke' if smoke else 'build'
        report = build/f'{mode}-report.json'
        if not args.plan_only:
            save(report,dict(status='running',mode=mode,targets=targets))
        try:
            sources,deps,external,order,fingerprints,up_modules = graph(upstream,build,targets)
        except Exception as error:
            if not args.plan_only:
                save(report,dict(status='failed',mode=mode,error=str(error),targets=targets))
            raise
        print(f'{len(order)} local modules; {len(external)} upstream targets. Plan: {build/"source-plan.json"}',flush=True)
        if args.plan_only:
            return
        cache_dir = Path(tempfile.mkdtemp(prefix='smoke-',dir=build)) if smoke else build/'build'
        cache_dir.mkdir(exist_ok=True)
        try:
            env = lean_env(upstream,external,build,smoke)
            borrowed = smoke_upstream(args.smoke_cache,up_modules,external,env['LEAN_PATH']) if smoke else {}
            for n,record in borrowed.items():
                artifact = cache_dir/(n.replace('.','/')+'.olean')
                artifact.parent.mkdir(parents=True,exist_ok=True)
                link_object(Path(record['path']),artifact)
        except Exception as error:
            save(report,dict(status='failed',mode=mode,error=str(error),targets=targets))
            raise
        env['LEAN_PATH'] = str(cache_dir)+os.pathsep+env['LEAN_PATH']
        compiled, reused = [], []
        def work(n):
            artifact = cache_dir/(n+'.olean')
            stamp = cache_dir/(n+'.json')
            if not smoke and artifact.is_file() and stamp.is_file():
                old = json.loads(stamp.read_text())
                if old.get('source') == fingerprints[n] and old.get('olean') == file_hash(artifact):
                    return 'reused'
            if smoke and n not in targets:
                for root in args.smoke_cache:
                    candidate = root.resolve()/(n+'.olean')
                    text = candidate.with_suffix('.lean')
                    if candidate.is_file() and text.is_file() and text.read_bytes() == sources[n].read_bytes():
                        # Never seed a full build from a smoke-test result.
                        link_object(candidate,artifact)
                        return 'reused'
            log = build/'logs'/f'{mode}-{n}.log'
            tmp = cache_dir/(n+'.pending.olean')
            with log.open('w') as stream:
                # The original matrix literals can exceed a million characters.
                # The kernel needs a larger worker stack to compare their complete character lists.
                stack = ['-s','1800000'] if (n == 'PriceOriginalSlot45Literal180' or n.startswith('TrialPricePublicMatrix')) else []
                check = subprocess.run(['lean','-j1',*stack,'-DElab.async=false','-Dpp.fullNames=true','-R',sources[n].parent,
                                        '-o',tmp,sources[n]],cwd=upstream,env=env,stdout=stream,stderr=subprocess.STDOUT)
            lines = log.read_text()
            axioms = {a.strip() for group in re.findall(r'depends on axioms:\s*\[([^]]*)\]',lines)
                      for a in group.split(',') if a.strip()}
            unexpected = axioms-ALLOWED_AXIOMS
            if check.returncode or 'sorryAx' in lines or "declaration uses 'sorry'" in lines or unexpected:
                raise RuntimeError(f'{n} failed (Lean exit {check.returncode}, '
                                   f'unexpected axioms {sorted(unexpected)}); see {log}')
            if n == 'TrialRobustTransfer180' and "'PrimeGap180.RobustTransfer.gap' depends on axioms:" not in lines:
                raise RuntimeError(f'Missing terminal axiom report in {log}')
            tmp.replace(artifact)
            if not smoke:
                save(stamp, dict(source=fingerprints[n],olean=file_hash(artifact)))
            return 'compiled'
        # A dependency becomes available as soon as its object has been written.
        sorter = TopologicalSorter(deps)
        sorter.prepare()
        try:
            with ThreadPoolExecutor(max_workers=args.jobs) as pool:
                pending = {}
                while sorter.is_active():
                    for name in sorter.get_ready():
                        pending[pool.submit(work,name)] = name
                    done,_ = wait(pending,return_when=FIRST_COMPLETED)
                    for future in done:
                        name = pending.pop(future)
                        state = future.result()
                        (reused if state == 'reused' else compiled).append(name)
                        if state == 'compiled':
                            print(f'Compiled {name}',flush=True)
                        sorter.done(name)
        except Exception as error:
            save(report,dict(status='failed',mode=mode,error=str(error),targets=targets))
            raise
        save(report,dict(status='passed',mode=mode,targets=targets,compiled=compiled,reused=reused,
                         upstream_smoke_objects=borrowed,
                         source_plan_sha256=file_hash(build/'source-plan.json')))
        print(f'{mode} passed: {len(compiled)} compiled, {len(reused)} reused. {report}')


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--upstream',type=Path,required=True,help='checkout of romyar1/prime-gaps-lean at the documented pin')
    p.add_argument('--build-dir',type=Path,required=True)
    p.add_argument('--target',action='append',help='local module to compile; repeat to select several')
    p.add_argument('--jobs',type=int,default=1,help='concurrent local Lean processes')
    mode = p.add_mutually_exclusive_group()
    mode.add_argument('--plan-only',action='store_true',help='audit and generate sources without compiling')
    mode.add_argument('--smoke-cache',action='append',type=Path,default=[],help='reuse exact-source local .oleans for a warm endpoint smoke test only')
    a = p.parse_args()
    if a.jobs < 1:
        p.error('--jobs must be positive')
    run(a)
