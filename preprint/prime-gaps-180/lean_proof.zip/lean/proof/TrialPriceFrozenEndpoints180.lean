import TrialPriceSignedEndpoint180
import TrialPricePublicFactors180

noncomputable section
namespace PrimeGap180.PriceBindings

/-- All price endpoint bounds hold for the original frozen diameter-180 ledger. -/
theorem frozen_endpoints : FrozenLedger.Endpoints :=
  PriceGroupCensus.endpoints_of_public_factor_slots all_matrices

#print axioms frozen_endpoints
end PrimeGap180.PriceBindings
