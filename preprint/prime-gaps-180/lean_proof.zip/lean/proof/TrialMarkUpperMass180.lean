import TrialMarkedCover180

/-! A one-sided reciprocal-mass price suffices for the marked cover. Add the
shortfall at the unit mark. It preserves every divisibility witness and
increases the total ordinary weight by at most the fixed price. -/
noncomputable section
open scoped BigOperators Classical Topology
open Filter PrimeGap186
namespace PrimeGap180.Marked

def toppedWeight (S : Finset ℕ) (w : ℕ → ℝ) (C : ℝ) (n : ℕ) :=
  if n = 1 then max 0 (C-mass S w) else w n

private theorem top_sum (S : Finset ℕ) (w : ℕ → ℝ) (C : ℝ) (one : 1 ∉ S)
    (g : ℕ → ℝ) : (∑ n ∈ insert 1 S, toppedWeight S w C n * g n) =
      max 0 (C-mass S w)*g 1 + ∑ n ∈ S, w n*g n := by
  rw [Finset.sum_insert one]
  simp only [toppedWeight,ite_true,eq_self]
  congr 1
  exact Finset.sum_congr rfl (fun n hn => by simp [show n ≠ 1 from fun h => one (h ▸ hn)])

theorem topped_mass (S : Finset ℕ) (w : ℕ → ℝ) (C : ℝ) (one : 1 ∉ S) :
    mass (insert 1 S) (toppedWeight S w C) = max C (mass S w) := by
  have h := top_sum S w C one (fun n => (n:ℝ)⁻¹)
  simp only [← div_eq_mul_inv, Nat.cast_one, div_one] at h
  change mass (insert 1 S) (toppedWeight S w C) = max 0 (C-mass S w) + mass S w at h
  rw [h]
  rcases le_total C (mass S w) with le|le
  · rw [max_eq_right le,max_eq_left (sub_nonpos.mpr le),zero_add]
  · rw [max_eq_left le,max_eq_right (sub_nonneg.mpr le),sub_add_cancel]

theorem topped_cover (S : Finset ℕ) (w : ℕ → ℝ) (C : ℝ) (one : 1 ∉ S) (N : ℕ) :
    (∑ n ∈ S, if n ∣ N then w n else 0) ≤
      ∑ n ∈ insert 1 S, if n ∣ N then toppedWeight S w C n else 0 := by
  rw [Finset.sum_insert one]
  have eq : (∑ n ∈ S, if n ∣ N then toppedWeight S w C n else 0) =
      ∑ n ∈ S, if n ∣ N then w n else 0 :=
    Finset.sum_congr rfl fun n hn => by simp [toppedWeight,show n ≠ 1 from fun h => one (h ▸ hn)]
  rw [eq]
  simp only [one_dvd,ite_true,toppedWeight,eq_self]
  exact le_add_of_nonneg_left (le_max_left _ _)

theorem topped_mass_limit (S : ℝ → Finset ℕ) (w : ℝ → ℕ → ℝ) {C : ℝ}
    (one : ∀ᶠ x : ℝ in atTop, 1 ∉ S x)
    (upper : ∀ ε > 0, ∀ᶠ x : ℝ in atTop, mass (S x) (w x) ≤ C+ε) :
    Tendsto (fun x => mass (insert 1 (S x)) (toppedWeight (S x) (w x) C)) atTop (𝓝 C) := by
  apply Metric.tendsto_nhds.mpr
  intro ε he
  filter_upwards [one,upper (ε/2) (half_pos he)] with x absent price
  rw [topped_mass _ _ _ absent,Real.dist_eq,abs_of_nonneg (sub_nonneg.mpr (le_max_left _ _))]
  exact sub_lt_iff_lt_add.mpr (max_lt (by linarith) (by linarith))

theorem topped_eligible (H : Finset ℕ) {s d κ K C : ℝ} (hs : 0 ≤ s) (hd : 0 < d)
    (hC : 0 ≤ C) (S : ℝ → Finset ℕ) (w : ℝ → ℕ → ℝ)
    (one : ∀ᶠ x : ℝ in atTop, 1 ∉ S x)
    (ok : ∀ᶠ x : ℝ in atTop, let W := presievingModulus H x
      (∀ l ∈ S x, 0 < l ∧ W.Coprime l ∧ (carrier W x κ).Coprime l ∧ 0 ≤ w x l) ∧
      (∑ l ∈ S x, w x l) ≤ x^s ∧ mass (S x) (w x) ≤ K) :
    ∀ᶠ x : ℝ in atTop, let W := presievingModulus H x
      (∀ l ∈ insert 1 (S x), 0 < l ∧ W.Coprime l ∧ (carrier W x κ).Coprime l ∧
        0 ≤ toppedWeight (S x) (w x) C l) ∧
      (∑ l ∈ insert 1 (S x), toppedWeight (S x) (w x) C l) ≤ x^(s+d) ∧
      mass (insert 1 (S x)) (toppedWeight (S x) (w x) C) ≤ max C K := by
  filter_upwards [one,ok,eventually_gt_atTop (1:ℝ),(tendsto_rpow_atTop hd).eventually_ge_atTop (C+1)]
    with x absent orig hx big
  intro W
  have mn : 0 ≤ mass (S x) (w x) := Finset.sum_nonneg fun n hn => div_nonneg (orig.1 n hn).2.2.2 (Nat.cast_nonneg n)
  have add : max 0 (C-mass (S x) (w x)) ≤ C := max_le hC (sub_le_self _ mn)
  refine ⟨?_,?_,?_⟩
  · intro l h
    rcases Finset.mem_insert.mp h with rfl|mem
    · simp [toppedWeight]
    · simpa [toppedWeight,show l ≠ 1 from fun e => absent (e ▸ mem)] using orig.1 l mem
  · have eq := top_sum (S x) (w x) C absent (fun _ => 1)
    simp only [mul_one] at eq
    rw [eq,Real.rpow_add (zero_lt_one.trans hx)]
    have powge := Real.one_le_rpow hx.le hs
    calc
      _ ≤ C+x^s := add_le_add add orig.2.1
      _ ≤ x^s*(C+1) := by nlinarith only [mul_nonneg (sub_nonneg.mpr powge) hC]
      _ ≤ _ := mul_le_mul_of_nonneg_left big (Real.rpow_nonneg (zero_lt_one.trans hx).le s)
  · rw [topped_mass _ _ _ absent]
    exact max_le_max (le_refl C) orig.2.2

#print axioms topped_mass_limit
#print axioms topped_eligible
#print axioms topped_cover
end PrimeGap180.Marked


open MeasureTheory PrimeGap182Analytic
namespace PrimeGap180.Sector

/-- Pass a tabulated mass upper bound directly into the physical signed price.
The original bins here consist of primes or products of primes. -/
theorem marked_cover_upper_of_mass_price {m : ℕ} {J T : Type*} [Fintype J] [Fintype T]
    (H : Finset ℕ) (hH : H.card = 39) (i : Fin 39)
    (a : Fin (m+2) → ℝ) (ha : StrictMono a) (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (P : J → (Fin 38 → Band m) → Prop) (F : J → Profile 39 m)
    (sep : ∀ j k, j ≠ k → ∀ y, P j y → ¬ P k y)
    (bf : ∀ j, Bornology.IsBounded (Set.range (F j)))
    (mf : ∀ j, Measurable (restrictFace i (P j) (F j)))
    (cf : ∀ j, ∀ᵐ y ∂Measure.pi (fun _ => bandLaw a), ContinuousAt (restrictFace i (P j) (F j)) y)
    (r : J → ℝ) (ζ : T → J → ℝ) (κ s d K C : T → ℝ) (ξ : ℝ)
    (hr : ∀ j, 0 ≤ r j) (hz : ∀ t j, 0 < ζ t j ∧ ζ t j < ξ)
    (hc : ∀ t, cap ≤ κ t) (aux : ∀ t j, ζ t j/rho ≤ κ t)
    (hs : ∀ t, 0 ≤ s t) (hd : ∀ t, 0 < d t) (hC : ∀ t, 0 ≤ C t) (room : ∀ t j, s t+d t+2*(r j+ζ t j) < 1)
    (rad : ∀ j y, P j y → rho*∑ q, ∑ v, y q v ≤ r j)
    (S : T → ℝ → Finset ℕ) (w : T → ℝ → ℕ → ℝ) (b : ℝ → ℕ) (event : ℝ → ℕ → ℝ)
    (eligible : ∀ t, ∀ᶠ x : ℝ in atTop, let W := presievingModulus H x
      (∀ l ∈ S t x, 0 < l ∧ W.Coprime l ∧ (Marked.carrier W x (κ t)).Coprime l ∧ 0 ≤ w t x l) ∧
      (∑ l ∈ S t x, w t x l) ≤ x^(s t) ∧ Marked.mass (S t x) (w t x) ≤ K t)
    (one : ∀ t, ∀ᶠ x : ℝ in atTop, 1 ∉ S t x)
    (mass : ∀ t, ∀ δ > 0, ∀ᶠ x : ℝ in atTop, Marked.mass (S t x) (w t x) ≤ C t+δ)
    (cover : ∀ᶠ x : ℝ in atTop, ∀ n ∈ Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊,
      let N := n + H.orderEmbOfFin hH i
      event x N ≤ ∑ t, ∑ l ∈ S t x, if l ∣ N then w t x l else 0)
    (rough : ∀ᶠ x : ℝ in atTop, ∀ n ∈ Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊,
      let N := n + H.orderEmbOfFin hH i
      0 < event x N → ∀ p : ℕ, p.Prime → p ∣ N → x^ξ ≤ (p:ℝ))
    {ε : ℝ} (he : 0 < ε) :
    let h : Fin 39 → ℕ := H.orderEmbOfFin hH
    let Z := fun j => restrictFace i (P j) (F j)
    let V := fun j x n => sampledSelbergRoot (face H a i (Z j) x) (fun k => n+h (i.succAbove k))
    let E := fun j => ∫ t, (integralFace a i (Z j) t)^2 ∂Measure.pi (fun _ => bandLaw a)
    ∀ᶠ x : ℝ in atTop, (∑ n ∈ Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊, if Nat.ModEq (presievingModulus H x) n (b x)
      then event x (n+h i)*(∑ j, V j x n)^2 else 0)/markedScale H x ≤
      (∑ t, ∑ j, C t*(1/ζ t j)*E j)+ε := by
  apply marked_cover_upper H hH i a ha first last P F sep bf mf cf r ζ κ
    (fun t => s t+d t) (fun t => max (C t) (K t)) C ξ hr hz hc aux
    (fun t => add_nonneg (hs t) (hd t).le) (fun t => (hC t).trans (le_max_left _ _)) room rad
    (fun t x => insert 1 (S t x)) (fun t x => Marked.toppedWeight (S t x) (w t x) (C t)) b event
    (fun t => Marked.topped_eligible H (hs t) (hd t) (hC t) (S t) (w t) (one t) (eligible t))
    (fun t => Marked.topped_mass_limit (S t) (w t) (one t) (mass t)) _ rough he
  filter_upwards [cover,eventually_all.mpr one] with x paid absent
  intro n hn N
  exact (paid n hn).trans (Finset.sum_le_sum fun t _ => Marked.topped_cover (S t x) (w t x) (C t) (absent t) N)

#print axioms marked_cover_upper_of_mass_price
end PrimeGap180.Sector
