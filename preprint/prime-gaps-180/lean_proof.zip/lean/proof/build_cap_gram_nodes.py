"""Generate the shared packed multiplication DAG for the archived Gram of one cap (default 36)."""
import argparse
from dataclasses import dataclass
from pathlib import Path

from build_cap_unmarked import POWER_FACTORS, lean_names, module as power_module
from cap_bank_names import Names, cap_argument
from check_exact_endpoint_pair import Gram, SIGNATURES, group_assignments
from build_historical_site_rows import columns
from endpoint_pair_arithmetic import COUNT, encode


@dataclass
class Node:
    module: str
    low: str
    high: str
    bounds: str
    masks: str


def name(kind, values, cap=36):
    return Names(cap).module('Gram'+kind.title()+'V'+'X'.join(f'{v:02d}' for v in values))


def all_targets():
    keys=sorted({q for a in SIGNATURES for b in SIGNATURES for q in group_assignments(tuple(sorted(a+b)))})
    return [('distinct',q) for q in keys]


def generate(destination, targets=None, cache=None, cap=36, dry_run=False):
    names=Names(cap)
    legacy=names.legacy
    unmarked=names.ns('Unmarked')
    destination.mkdir(parents=True,exist_ok=True)
    parts={}
    references={}
    gram=None
    if cache is None and not dry_run:
        temp=destination/'packed-intermediates';temp.mkdir(exist_ok=True)
        gram=Gram(columns()[cap][:COUNT],temp)
    # Cap-specific symbols: the cap-36 bank uses the cap-36 rules of MassAngularBank/CapFastAssembly.
    if legacy:
        fast,atom,occupied,blocks,base='CapFastAssembly.','atom','occupied','blocks','base'
    else:
        fast,atom,occupied,blocks,base=('CapBank.',f'CapBank.atom {cap}',f'CapBank.occupied {cap}',
                                        f'CapBank.blocks {cap}',f'CapBank.base {cap}')
    rule=(lambda r:fast+r) if legacy else (lambda r:f'{fast}{r} {cap}')
    simp_blocks='blocks,occupied' if legacy else 'CapBank.blocks,CapBank.occupied'

    def words(kind,args):
        if dry_run:
            return None,None
        if cache is None:
            alias={'base':'count','group':'occupied','distinct':'all'}
            p=gram.term(alias[kind],args)
            return encode(p.low,80),encode(p.high,80)
        import numpy as np
        path=cache/(kind+'-'+'.'.join(map(str,args))+'.u40')
        raw=np.fromfile(path,dtype=np.uint8)
        if raw.size!=COUNT*80:raise ValueError(path)
        two=raw.reshape(2,COUNT,40);out=[]
        for a in two:
            arr=np.zeros((COUNT,80),dtype=np.uint8);arr[:,:40]=a;out.append(arr.tobytes())
        return out

    def fetch(kind,args):
        if (kind,args) in references:return references[kind,args]
        if kind=='atom':
            e,=args
            if not e:
                n=fetch('base',(1,))
                return Node(n.module,n.low,n.high,'(by simpa only [pow_one] using '+n.bounds+')',n.masks)
            head=names.ns(f'RawAtom{e}')+'.'
            return Node(names.module(f'RawAtom{e:02d}'),head+'lo',head+'hi',head+'actual',head+'masks')
        if kind=='base' and (args[0] in POWER_FACTORS or args[0]==1):
            d,=args
            l,h,pr,m=lean_names(d,cap)
            if '.' not in l:l=unmarked+'.'+l;h=unmarked+'.'+h
            return Node(power_module(d,cap) if d>2 else names.unmarked_module,l,h,
                        f'({base} {d} _ _ {unmarked}.{pr})',unmarked+'.'+m)
        if kind=='group' and len(args)==1:
            n=fetch('atom',args)
            return Node(n.module,n.low,n.high,f'({rule("singleRaw")} {args[0]} {n.low} {n.high} {n.bounds})',n.masks)
        if kind=='distinct' and not args:
            n=fetch('base',(37,))
            return Node(n.module,n.low,n.high,'(by simpa only ['+simp_blocks+',List.length_nil,Nat.sub_zero,List.map_nil,List.prod_nil,mul_one] using '+n.bounds+')',n.masks)
        name_here=name(kind,args,cap)
        s='['+','.join(map(str,args))+']'
        if kind=='base':
            d,=args;l=d//2;r=d-l
            a=fetch('base',(l,));b=fetch('base',(r,))
            target=f'{atom} 0^{d}'
            combine = f'{rule("baseProduct")} {l} {r}'
        elif kind=='group':
            a=fetch('group',args[:-1]);b=fetch('atom',args[-1:])
            t='['+','.join(map(str,args[:-1]))+']'
            target=f'{occupied} {s}'
            combine = f'{rule("markedProduct")} {t} {args[-1]}'
        else:
            a=fetch('base',(37-len(args),));b=fetch('group',args)
            target=f'{blocks} {s}'
            combine = f'{rule("distinctProduct")} {s}'
        ns=name_here.removeprefix('Trial').removesuffix('180')
        src=['import '+names.fast_module,*('import '+m for m in sorted({a.module,b.module})),
             '',f'namespace PrimeGap180.{ns}','open CapWordConvolution MassAngularBank',
             'set_option maxRecDepth 18000','set_option maxHeartbeats 0',
             'set_option exponentiation.threshold 100000000']
        for nm,data in zip(('lo','hi'),words(kind,args),strict=True):
            fn=name_here+'-'+nm+'.bin'
            if data is not None:(destination/fn).write_bytes(data)
            src.append(f'def {nm} := {names.word} "{fn}" {COUNT*80 if data is None else len(data)}')
        src.extend(['theorem masks : mask 640 296 130965 lo=true ∧ mask 640 296 130965 hi=true := by decide +kernel',
                    f'private theorem nums : wordLow 640 256 130965 {a.low} {b.low}=lo ∧',
                    f'    wordHigh 640 256 130965 {a.high} {b.high}=hi := by decide +kernel',
                    f'theorem actual : kept ({target}) lo hi :=',
                    f'  {combine} {a.low} {a.high} {b.low} {b.high} lo hi',
                    f'    {a.bounds} {b.bounds} {a.masks} {b.masks} nums.1 nums.2',
                    '#print axioms actual',f'end PrimeGap180.{ns}',''])
        src_path=destination/(name_here+'.lean');src_path.write_text('\n'.join(src));parts[name_here]=src_path
        ref=Node(name_here,ns+'.lo',ns+'.hi',ns+'.actual',ns+'.masks')
        references[kind,args]=ref
        return ref

    if targets is None:
        targets=all_targets()
    for kind,args in targets:fetch(kind,args)
    return parts


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    cap_argument(p)
    p.add_argument('--output-dir', type=Path, required=True)
    p.add_argument('--dry-run', action='store_true', help='write Lean text without words')
    a = p.parse_args()
    for n in generate(a.output_dir, cap=a.cap, dry_run=a.dry_run):
        print(n)
