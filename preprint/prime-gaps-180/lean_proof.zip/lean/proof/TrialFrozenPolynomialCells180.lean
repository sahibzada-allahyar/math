import TrialPolynomialCells180
import TrialDickmanChartData180
import TrialDebitCapMap180

/-! Outward rational enclosures for each actual physical CDF cell. Both
knots are integer mesh points, and the two polynomial witnesses cover
all 4,845,705 historical cutoff/index pairs. -/
noncomputable section
open Set PrimeGap186 PrimeGap180.CoarseLaw PrimeGap180.FrozenProfile
open PrimeGap180.CellQuadrature PrimeGap180.DickmanPolynomial
namespace PrimeGap180.FrozenPolynomialCells

def coordinate (k m c : ℕ) : ℚ := 2*(k:ℚ)/m-c
def center (k m c : ℕ) (q : List ℚ) : ℚ :=
  (m:ℚ)/2*(evalQ (primitive q) (coordinate (k+1) m c) -
            evalQ (primitive q) (coordinate k m c))

private theorem from_chart (k : ℕ) (hk : k < 130965) (f : Fine) (c : ℕ) (q : List ℚ) (e : ℚ)
    (derivQ : diff (primitive q) = q ++ [0])
    (bound : ∀ z ∈ Icc (-1:ℝ) 1, |density c z-evalR q z| ≤ (e:ℝ))
    (lo : -1 ≤ coordinate k (FrozenCaps.index f) c)
    (hi : coordinate (k+1) (FrozenCaps.index f) c ≤ 1) :
    |cdf k f / Native.step - (center k (FrozenCaps.index f) c q:ℝ)| ≤ (e:ℝ) := by
  have start : (-1:ℝ) ≤ (coordinate k (FrozenCaps.index f) c : ℝ) := by exact_mod_cast lo
  have stop : (coordinate (k+1) (FrozenCaps.index f) c : ℝ) ≤ 1 := by exact_mod_cast hi
  have lift (j : ℕ) :
      ((coordinate j (FrozenCaps.index f) c : ℚ):ℝ) =
      2*(j:ℝ)/(FrozenCaps.index f:ℝ)-c := by unfold coordinate; push_cast; rfl
  rw [lift] at start stop
  push_cast at stop
  have h := physical_cell k hk f (c:ℝ) q (e:ℝ) derivQ bound start stop
  have val (j : ℕ) : ((evalQ (primitive q) (coordinate j (FrozenCaps.index f) c):ℚ):ℝ) =
      evalR (primitive q) (2*(j:ℝ)/(FrozenCaps.index f:ℝ)-c) := by rw [←eval_rat,lift]
  unfold center
  push_cast
  rw [val,val]
  push_cast
  exact h

def box (k m : ℕ) : ℚ × ℚ :=
  if k < m then (1,1)
  else if k < 2*m then (center k m 3 p3-r3, center k m 3 p3+r3)
  else (center k m 5 p5-e5, center k m 5 p5+e5)

private theorem deriv3 : diff (primitive p3) = p3 ++ [0] := by decide +kernel
private theorem deriv5 : diff (primitive p5) = p5 ++ [0] := by decide +kernel

theorem physical_box (k : ℕ) (hk : k < 130965) (f : Fine) (through : k < 3 * FrozenCaps.index f) :
    ((box k (FrozenCaps.index f)).1:ℝ) ≤ cdf k f / Native.step ∧
      cdf k f / Native.step ≤ ((box k (FrozenCaps.index f)).2:ℝ) := by
  let m := FrozenCaps.index f
  have pos : (0:ℚ) < m := by change 0 < (FrozenCaps.index f:ℚ); exact_mod_cast FrozenCaps.positive f
  change ((box k m).1:ℝ) ≤ _ ∧ _ ≤ ((box k m).2:ℝ)
  by_cases short : k < m
  · rw [below_frozen_cutoff k hk f short, div_self (by norm_num [Native.step])]
    simp [box,short]
  have mid0 : m ≤ k := Nat.le_of_not_gt short
  by_cases mid : k < 2*m
  · have lo : -1 ≤ coordinate k m 3 := by
      unfold coordinate
      rw [le_sub_iff_add_le,le_div_iff₀ pos]
      have v : (m:ℚ) ≤ k := by exact_mod_cast mid0
      norm_num at v ⊢ <;> linarith only [v]
    have hi : coordinate (k+1) m 3 ≤ 1 := by
      unfold coordinate
      rw [sub_le_iff_le_add,div_le_iff₀ pos]
      have v : ((k+1:ℕ):ℚ) ≤ 2*(m:ℚ) := by exact_mod_cast Nat.succ_le_of_lt mid
      norm_num at v ⊢ <;> linarith only [v]
    have h := abs_le.mp (from_chart k hk f 3 p3 r3 deriv3 first_bound lo hi)
    simp only [box,if_neg short,if_pos mid,Rat.cast_sub,Rat.cast_add]
    constructor <;> linarith only [h.1,h.2]
  · have lo : -1 ≤ coordinate k m 5 := by
      unfold coordinate
      rw [le_sub_iff_add_le,le_div_iff₀ pos]
      have v : 2*(m:ℚ) ≤ k := by exact_mod_cast Nat.le_of_not_gt mid
      norm_num at v ⊢ <;> linarith only [v]
    have hi : coordinate (k+1) m 5 ≤ 1 := by
      unfold coordinate
      rw [sub_le_iff_le_add,div_le_iff₀ pos]
      have v : ((k+1:ℕ):ℚ) ≤ 3*(m:ℚ) := by exact_mod_cast Nat.succ_le_of_lt through
      norm_num at v ⊢ <;> linarith only [v]
    have h := abs_le.mp (from_chart k hk f 5 p5 e5 deriv5 second_bound lo hi)
    simp only [box,if_neg short,if_neg mid,Rat.cast_sub,Rat.cast_add]
    constructor <;> linarith only [h.1,h.2]

theorem historical_domain (c : DebitNativeClasses.Class) (k : ℕ) (hk : k < 130965) :
    k < 3*FrozenCaps.index (DebitNativeClasses.capAt c) := by
  have h := (show ∀ c : DebitNativeClasses.Class, 45067 ≤ FrozenCaps.index (DebitNativeClasses.capAt c) by decide +kernel) c
  omega

theorem historical (k : ℕ) (hk : k < 130965) (c : DebitNativeClasses.Class) :
    let f := DebitNativeClasses.capAt c
    ((box k (FrozenCaps.index f)).1:ℝ) ≤ cdf k f / Native.step ∧
      cdf k f / Native.step ≤ ((box k (FrozenCaps.index f)).2:ℝ) :=
  physical_box k hk _ (historical_domain c k hk)

#print axioms physical_box
#print axioms historical
end PrimeGap180.FrozenPolynomialCells
