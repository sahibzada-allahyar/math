import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G040
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 40

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G040

namespace PrimeGap180.PriceIsolatedGroup.G045
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 45

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G045

namespace PrimeGap180.PriceIsolatedGroup.G050
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 50

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G050

namespace PrimeGap180.PriceIsolatedGroup.G055
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 55

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G055
