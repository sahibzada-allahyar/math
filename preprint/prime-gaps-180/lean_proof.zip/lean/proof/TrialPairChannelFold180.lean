import TrialPackedRoleKernels180

/-! For the double endpoint erasure all labelled interior assignments share
one correlation. The two erased shape indices are retained in the ordered
sum; the surviving angular expansion has eleven signatures. -/
noncomputable section
open scoped BigOperators Classical
open PrimeGap180.DebitNativeClasses PrimeGap180.CoarseLaw PrimeGap180.FrozenProfile
open PrimeGap180.FrozenChannels PrimeGap180.PackedLaw PrimeGap180.PackedSingleFields
open PrimeGap180.PackedPairFields PrimeGap180.PackedRoleKernels PrimeGap180.SignedCapContractions
namespace PrimeGap180.PairChannelFold
set_option maxRecDepth 6500
set_option maxHeartbeats 1200000

def fixed (a b : Fin 3) (s : Fin 11) : Term := ⟨a,b,s,fun _ => 0⟩

private theorem last_ne (i : Fin 37) : i.castSucc.succ ≠ Fin.last 38 := by
  intro e
  have h := congrArg Fin.val e
  change i.val+1=38 at h
  omega

private theorem ends (z : Term) (j : ℕ) :
    siteChannel z 0 j = siteFactor (center j)*shapes (center j) z.1 ∧
    siteChannel z (Fin.last 38) j = siteFactor (center j)*shapes (center j) z.2.1 := by
  have last_num (i : Fin 37) : i.castSucc.succ ≠ (38 : Fin 39) := last_ne i
  simp [siteChannel,last_num]

def slot (g : Grid) (c : Hist) (a : Fin 3) (j : Tick) :=
    100*(Native.step*((g j c:ℝ)/(base:ℝ)))*siteFactor (center j.val)*shapes (center j.val) a

def delta (J : ℕ) (c : Hist) (a b : Fin 3) (s : Fin 11) :=
  coefficientChange J c (fixed a b s)

def erased (g : Grid) (J : ℕ) (c : Hist) (a b : Fin 3) (s : Fin 11) :=
  ∑ h : Tick,slot g c a h*∑ l : Tick,slot g c b l*delta (h.val+l.val+J) c a b s

theorem correlation (g : Grid) (J : ℕ) (c : Hist) (z : Term) :
    pairCoefficient g J c z=erased g J c z.1 z.2.1 z.2.2.1 := by
  unfold pairCoefficient erased
  apply Finset.sum_congr rfl
  intro h _
  rw [Finset.mul_sum,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro l _
  have dz : coefficientChange (h.val+l.val+J) c z=delta (h.val+l.val+J) c z.1 z.2.1 z.2.2.1 := rfl
  rw [factor,dz,(ends z _).1,(ends z _).2]
  unfold slot
  ring

def erasureBank (g : Grid) (J k : ℕ) (a b : Fin 3) (s : Fin 11) :=
  bank (fun c => erased g J c a b s) k

theorem bank_eq (g : Grid) (J k : ℕ) (z : Term) :
    pairField g J k z=erasureBank g J k z.1 z.2.1 z.2.2.1 := by
  unfold pairField erasureBank
  apply congrArg (fun d => bank d k)
  funext c
  exact correlation g J c z

def power (s : Fin 11) (x : Fin 37 → Atom) :=
  ((signatures s).map fun e => ∑ i : Fin 37,(center (x i).1.val)^e).prod

private theorem assigned (z : Term) (x : Fin 37 → Atom) :
    features x z=(∏ i,siteFactor (center (x i).1.val))*
      ∏ l : Fin (signatures z.2.2.1).length,
        (center (x (z.2.2.2 l)).1.val)^((signatures z.2.2.1).get l) := by
  simp only [features,siteChannel,Fin.succ_ne_zero,last_ne,if_false,mul_one,
    Fin.succ_inj,Fin.castSucc_inj,Finset.prod_mul_distrib]
  rw [Finset.prod_comm (s:=(Finset.univ : Finset (Fin 37)))
    (t:=(Finset.univ : Finset (Fin (signatures z.2.2.1).length)))]
  simp

private theorem assignments (s : Fin 11) (x : Fin 37 → Atom) :
    power s x = ∑ t : Assignment s,∏ l : Fin (signatures s).length,
       (center (x (t l)).1.val)^((signatures s).get l) := by
  unfold power
  rw [←List.ofFn_getElem_eq_map,List.prod_ofFn,Fintype.prod_sum]
  rfl

theorem amplitude (g : Grid) (x : Fin 37 → Atom) (k : ℕ) :
    bank (NativePairUpdates.addPair (ReferenceRoles.archive (law g)) x) k =
    ∑ a : Fin 3,∑ b : Fin 3,∑ s : Fin 11,
      erasureBank g (retained x) k a b s * (∏ i,siteFactor (center (x i).1.val)) * power s x := by
  rw [pair_bank]
  simp only [Fintype.sum_sigma]
  apply Finset.sum_congr rfl
  intro a _
  apply Finset.sum_congr rfl
  intro b _
  apply Finset.sum_congr rfl
  intro s _
  rw [assignments,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro t _
  rw [bank_eq,assigned]
  exact (mul_assoc _ _ _).symm

#print axioms correlation
#print axioms amplitude
end PrimeGap180.PairChannelFold
