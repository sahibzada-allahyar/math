import TrialNativeRoleTotals180

/-! The five finite polynomial estimates used by the relaxed native score. -/
noncomputable section
open PrimeGap180.PackedLaw
namespace PrimeGap180.RelaxedFive

def mBound : ℝ := 94.17315
def cBound : ℝ := 2.47735
def aBound : ℝ := 1.38520
def bBound : ℝ := 1.38520
def pBound : ℝ := 0.14425

structure Bounds (g : Grid) : Prop where
  mass : NativeRoleTotals.ordinary g ≤ mBound
  core : cBound ≤ NativeRoleTotals.single g 1
  first : aBound ≤ NativeRoleTotals.single g 0
  last : bBound ≤ NativeRoleTotals.single g (Fin.last 38)
  pair : NativeRoleTotals.pair g ≤ pBound

end PrimeGap180.RelaxedFive
