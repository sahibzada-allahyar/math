import TrialTripleHingePartition180

/-! The two closed prime bands that pay for a triple appearing at the next
cutoff. The factor two is included in the weights on actual prime marks. -/
noncomputable section
open scoped Classical BigOperators Topology
open Filter MeasureTheory PrimeGap186 PrimeGap182Analytic PrimeGap180.EventBins
namespace PrimeGap180.TripleAdjacent

abbrev lo (i : Fin 12) := (PriceEvents.lowTicks i : ℝ)/10^7
abbrev hi (i : Fin 12) := (PriceEvents.topTicks i : ℝ)/10^10
def L (i : Fin 11) (k : Bool) := if k then hi i.castSucc else lo i.succ
def U (i : Fin 11) (k : Bool) := if k then hi i.succ else lo i.castSucc

private theorem bins (i : Fin 11) (k : Bool) :
    0 < lo i.succ ∧ lo i.succ ≤ L i k ∧ L i k ≤ U i k ∧ U i k ≤ 1 := by
  fin_cases i <;> cases k <;> norm_num [L,U,hi,lo,PriceEvents.lowTicks,PriceEvents.topTicks]
  · change 0 < (2921877:ℕ) ∧ (2921877:ℝ)/10000000 ≤ 2927277/10000000
    norm_num
  · change 0 < (2921877:ℕ) ∧ (2921877:ℝ)/10000000 ≤ 4138052001/10000000000 ∧
      (4138052001:ℝ)/10000000000 ≤ 4140052001/10000000000 ∧
      (4140052001:ℝ)/10000000000 ≤ 1
    norm_num

theorem closed_mem {x l r : ℝ} (hx : 1 < x) {p : ℕ} :
    p ∈ closedPrimeMarks x l r ↔ p.Prime ∧ x^l ≤ (p:ℝ) ∧ (p:ℝ) ≤ x^r := by
  simp [closedPrimeMarks,Nat.mem_primesLE,Nat.le_floor_iff (Real.rpow_nonneg (zero_lt_one.trans hx).le r),
    and_comm,and_left_comm]

theorem adjacent_marks {x : ℝ} (hx : 1 < x) (i : Fin 11) (n : ℕ) :
    PriceEvents.mass x n (.three i.succ) ≤ ∑ k : Bool, ∑ p ∈ closedPrimeMarks x (L i k) (U i k),
      if p ∣ n then (2:ℝ) else 0 := by
  have nn (k : Bool) : 0 ≤ ∑ p ∈ closedPrimeMarks x (L i k) (U i k), if p ∣ n then (2:ℝ) else 0 :=
    Finset.sum_nonneg fun _ _ => ite_nonneg (by norm_num) le_rfl
  by_cases zero : PriceEvents.mass x n (.three i.succ) = 0
  · rw [zero]; exact Finset.sum_nonneg fun k _ => nn k
  have e := PriceEvents.three_mass_spec zero
  obtain ⟨p,mem,side⟩ := triple_increment_band e.1 (e.2 i.castSucc Fin.castSucc_lt_succ)
  have pp := Nat.prime_of_mem_primeFactors mem
  have dv := Nat.dvd_of_mem_primeFactors mem
  have witness : ∃ k : Bool, p ∈ closedPrimeMarks x (L i k) (U i k) := by
    rcases side with h|h
    · exact ⟨false, (closed_mem hx).mpr ⟨pp,h.1.le,h.2⟩⟩
    · exact ⟨true, (closed_mem hx).mpr ⟨pp,h.1,h.2.le⟩⟩
  obtain ⟨k,mem⟩ := witness
  rw [show PriceEvents.mass x n (.three i.succ) = 2 from ite_eq_left (ite_ne_right_iff.mp zero).1]
  apply le_trans _ (Finset.single_le_sum (fun k _ => nn k) (Finset.mem_univ k))
  simpa [dv] using Finset.single_le_sum (f := fun p : ℕ => if p ∣ n then (2:ℝ) else 0)
    (fun p _ => ite_nonneg (by norm_num) le_rfl) mem

theorem adjacent_mass (i : Fin 11) (k : Bool) :
    Tendsto (fun x => Marked.mass (closedPrimeMarks x (L i k) (U i k)) (fun _ => 2))
      atTop (𝓝 (2*Real.log (U i k/L i k))) := by
  have law := (closed_primeMarks_mass ((bins i k).1.trans_le (bins i k).2.1) (bins i k).2.2.1).const_mul 2
  apply law.congr'
  exact Eventually.of_forall fun x => by simp only [Marked.mass,Finset.mul_sum,← mul_div_assoc,mul_one]

theorem adjacent_eligible (H : Finset ℕ) (i : Fin 11) (k : Bool) {κ d : ℝ}
    (below : Marked.rho*κ < lo i.succ) (hd : 0 < d) :
    ∃ K : ℝ, 0 ≤ K ∧ ∀ᶠ x : ℝ in atTop, let W := presievingModulus H x
      (∀ p ∈ closedPrimeMarks x (L i k) (U i k),
        0 < p ∧ W.Coprime p ∧ (Marked.carrier W x κ).Coprime p ∧ (0:ℝ) ≤ 2) ∧
      (∑ _ ∈ closedPrimeMarks x (L i k) (U i k), (2:ℝ)) ≤ x^(U i k+d) ∧
      Marked.mass (closedPrimeMarks x (L i k) (U i k)) (fun _ => 2) ≤ K := by
  obtain ⟨pos,low,le,high⟩ := bins i k
  obtain ⟨K,nn,eligible⟩ := Marked.eligible_subsets H (s := U i k) pos ((low.trans le).trans high)
    below hd (by norm_num : (0:ℝ) ≤ 2)
  refine ⟨K,nn,?_⟩
  filter_upwards [eligible,eventually_gt_atTop (1:ℝ)] with x he hx
  apply he
  · intro p hp
    obtain ⟨pp,pl,pu⟩ := (closed_mem hx).mp hp
    have bound : (p:ℝ) ≤ x := by simpa using pu.trans (Real.rpow_le_rpow_of_exponent_le hx.le high)
    have mem : p ∈ Marked.primeBand x (lo i.succ) := Finset.mem_filter.mpr
      ⟨Nat.mem_primesLE.mpr ⟨(Nat.le_floor_iff (by linarith)).mpr bound,pp⟩,
       (Real.rpow_le_rpow_of_exponent_le hx.le low).trans pl⟩
    exact Finset.mem_union_left _ (Finset.mem_union_right _ mem)
  · intro p hp
    exact ⟨((closed_mem hx).mp hp).2.2,by norm_num,le_rfl⟩

open PrimeGap180.Sector

theorem adjacent_triple_partition_upper {m : ℕ} {J : Type*} [Fintype J]
    (H : Finset ℕ) (hH : H.card = 39) (i : Fin 39)
    (row : Fin 11)
    (a : Fin (m+2) → ℝ) (ha : StrictMono a) (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (P : J → (Fin 38 → Band m) → Prop) (F : J → Profile 39 m)
    (sep : ∀ j k, j ≠ k → ∀ y, P j y → ¬ P k y)
    (bf : ∀ j, Bornology.IsBounded (Set.range (F j)))
    (mf : ∀ j, Measurable (restrictFace i (P j) (F j)))
    (cf : ∀ j, ∀ᵐ y ∂Measure.pi (fun _ => bandLaw a), ContinuousAt (restrictFace i (P j) (F j)) y)
    (r : J → ℝ) (ζ : Bool → J → ℝ) (κ : Bool → ℝ) {d : ℝ}
    (hd : 0 < d) (hr : ∀ j, 0 ≤ r j) (hz : ∀ t j, 0 < ζ t j ∧ ζ t j < lo row.succ)
    (hc : ∀ t, cap ≤ κ t) (below : ∀ t, Marked.rho*κ t < lo row.succ)
    (aux : ∀ t j, ζ t j/rho ≤ κ t) (room : ∀ t j, U row t+d+2*(r j+ζ t j) < 1)
    (rad : ∀ j y, P j y → rho*∑ q, ∑ v, y q v ≤ r j)
    (b : ℝ → ℕ) {ε : ℝ} (he : 0 < ε) :
    let h : Fin 39 → ℕ := H.orderEmbOfFin hH
    let Z := fun j => restrictFace i (P j) (F j)
    let V := fun j x n => sampledSelbergRoot (face H a i (Z j) x) (fun k => n+h (i.succAbove k))
    let E := fun j => ∫ t, (integralFace a i (Z j) t)^2 ∂Measure.pi (fun _ => bandLaw a)
    ∀ᶠ x : ℝ in atTop, (∑ n ∈ Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊, if Nat.ModEq (presievingModulus H x) n (b x)
      then PriceEvents.mass x (n+h i) (.three row.succ)*(∑ j, V j x n)^2 else 0)/markedScale H x ≤
      (∑ t, ∑ j, (2*Real.log (U row t/L row t))*(1/ζ t j)*E j)+ε := by
  classical
  choose K nn elig using fun t => adjacent_eligible H row t (below t) hd
  apply marked_cover_upper H hH i a ha first last P F sep bf mf cf r ζ κ (fun t => U row t+d)
    K (fun t => 2*Real.log (U row t/L row t)) (lo row.succ) hr hz hc aux
    (fun t => add_nonneg (((bins row t).1.le.trans (bins row t).2.1).trans (bins row t).2.2.1) hd.le)
    nn room rad (fun t x => closedPrimeMarks x (L row t) (U row t)) (fun _ _ _ => 2) b
    (fun x n => PriceEvents.mass x n (.three row.succ)) elig (adjacent_mass row) _ _ he
  · filter_upwards [eventually_gt_atTop (1:ℝ)] with x hx
    exact fun n _ => adjacent_marks hx row _
  · filter_upwards with x
    intro n _ N positive p pp dvd
    obtain ⟨v,w,t,pv,pw,pt,vw,wt,prod,lower,_⟩ := (PriceEvents.three_mass_spec positive.ne').1
    rw [prod] at dvd
    simp only [pp.dvd_mul,Nat.prime_dvd_prime_iff_eq pp pv,Nat.prime_dvd_prime_iff_eq pp pw,
      Nat.prime_dvd_prime_iff_eq pp pt] at dvd
    exact lower.le.trans (Nat.cast_le.mpr (by omega : v ≤ p))

#print axioms adjacent_triple_partition_upper
end PrimeGap180.TripleAdjacent
