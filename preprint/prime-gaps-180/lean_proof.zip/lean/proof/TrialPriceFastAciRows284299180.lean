import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G284
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 284

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G284

namespace PrimeGap180.PriceIsolatedGroup.G289
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 289

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G289

namespace PrimeGap180.PriceIsolatedGroup.G294
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 294

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G294

namespace PrimeGap180.PriceIsolatedGroup.G299
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 299

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G299
