import TrialPriceScalar180
namespace PrimeGap180.PriceExactCensus
set_option maxHeartbeats 100000000
set_option maxRecDepth 65536
private theorem c256 : PriceScalar.checked (256 : Book.Label) = true := by decide +kernel
private theorem c257 : PriceScalar.checked (257 : Book.Label) = true := by decide +kernel
private theorem c258 : PriceScalar.checked (258 : Book.Label) = true := by decide +kernel
private theorem c259 : PriceScalar.checked (259 : Book.Label) = true := by decide +kernel
private theorem c260 : PriceScalar.checked (260 : Book.Label) = true := by decide +kernel
private theorem c261 : PriceScalar.checked (261 : Book.Label) = true := by decide +kernel
private theorem c262 : PriceScalar.checked (262 : Book.Label) = true := by decide +kernel
private theorem c263 : PriceScalar.checked (263 : Book.Label) = true := by decide +kernel
private theorem c264 : PriceScalar.checked (264 : Book.Label) = true := by decide +kernel
private theorem c265 : PriceScalar.checked (265 : Book.Label) = true := by decide +kernel
private theorem c266 : PriceScalar.checked (266 : Book.Label) = true := by decide +kernel
private theorem c267 : PriceScalar.checked (267 : Book.Label) = true := by decide +kernel
private theorem c268 : PriceScalar.checked (268 : Book.Label) = true := by decide +kernel
private theorem c269 : PriceScalar.checked (269 : Book.Label) = true := by decide +kernel
private theorem c270 : PriceScalar.checked (270 : Book.Label) = true := by decide +kernel
private theorem c271 : PriceScalar.checked (271 : Book.Label) = true := by decide +kernel
private theorem c272 : PriceScalar.checked (272 : Book.Label) = true := by decide +kernel
private theorem c273 : PriceScalar.checked (273 : Book.Label) = true := by decide +kernel
private theorem c274 : PriceScalar.checked (274 : Book.Label) = true := by decide +kernel
private theorem c275 : PriceScalar.checked (275 : Book.Label) = true := by decide +kernel
private theorem c276 : PriceScalar.checked (276 : Book.Label) = true := by decide +kernel
private theorem c277 : PriceScalar.checked (277 : Book.Label) = true := by decide +kernel
private theorem c278 : PriceScalar.checked (278 : Book.Label) = true := by decide +kernel
private theorem c279 : PriceScalar.checked (279 : Book.Label) = true := by decide +kernel
private theorem c280 : PriceScalar.checked (280 : Book.Label) = true := by decide +kernel
private theorem c281 : PriceScalar.checked (281 : Book.Label) = true := by decide +kernel
private theorem c282 : PriceScalar.checked (282 : Book.Label) = true := by decide +kernel
private theorem c283 : PriceScalar.checked (283 : Book.Label) = true := by decide +kernel
private theorem c284 : PriceScalar.checked (284 : Book.Label) = true := by decide +kernel
private theorem c285 : PriceScalar.checked (285 : Book.Label) = true := by decide +kernel
private theorem c286 : PriceScalar.checked (286 : Book.Label) = true := by decide +kernel
private theorem c287 : PriceScalar.checked (287 : Book.Label) = true := by decide +kernel
theorem block8 : ∀ i : Fin 32, PriceScalar.checked ⟨256+i.val,by omega⟩ = true :=
  Fin.cases c256 (Fin.cases c257 (Fin.cases c258 (Fin.cases c259 (Fin.cases c260 (Fin.cases c261 (Fin.cases c262 (Fin.cases c263 (Fin.cases c264 (Fin.cases c265 (Fin.cases c266 (Fin.cases c267 (Fin.cases c268 (Fin.cases c269 (Fin.cases c270 (Fin.cases c271 (Fin.cases c272 (Fin.cases c273 (Fin.cases c274 (Fin.cases c275 (Fin.cases c276 (Fin.cases c277 (Fin.cases c278 (Fin.cases c279 (Fin.cases c280 (Fin.cases c281 (Fin.cases c282 (Fin.cases c283 (Fin.cases c284 (Fin.cases c285 (Fin.cases c286 (Fin.cases c287 (fun i => Fin.elim0 i))))))))))))))))))))))))))))))))
#print axioms block8
end PrimeGap180.PriceExactCensus
