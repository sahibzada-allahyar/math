import TrialLowAngularDirectedGrid180
import TrialLaterLowAngularProduct180
import TrialAngularEnumeration180

/-! Group equivalent assignments of the angular factors to unused core coordinates. -/
noncomputable section
open scoped BigOperators Classical
namespace PrimeGap180.LowAngularCompressed
open AngularOccupied (bump)
variable {R : Type*} [CommSemiring R] {d : ℕ}

def addSlots (es : List ℕ) (w : Fin d→ℕ) (t : Fin es.length→Fin d) (i : Fin d) :=
  w i+∑ l : Fin es.length,if t l=i then es.get l else 0

def expand (L : (Fin d→ℕ)→R) : List ℕ → (Fin d→ℕ)→R
  | [],w=>L w
  | e::es,w=>∑ i : Fin d,expand L es (bump w i e)

private theorem slots_cons (es : List ℕ) (e : ℕ) (w : Fin d→ℕ) (i : Fin d) (t : Fin es.length→Fin d) :
    addSlots (e::es) w (Fin.cons i t) = addSlots es (bump w i e) t := by
  funext j
  change w j + (∑ l : Fin (es.length+1), if Fin.cons (α:=fun _=>Fin d) i t l=j then (e::es).get l else 0) = bump w i e j + _
  rw [Fin.sum_univ_succ]
  simp only [Fin.cons_zero,Fin.cons_succ,List.get_cons_zero,bump]
  by_cases eq : i=j <;> simp [eq,Ne.symm] <;> omega

theorem assigned (L : (Fin d→ℕ)→R) (es : List ℕ) (w : Fin d→ℕ) :
    expand L es w=∑ t : Fin es.length→Fin d, L (addSlots es w t) := by
  induction es generalizing w with
  | nil =>
    change L w=∑ t : Fin 0→Fin d,L (addSlots [] w t)
    simp only [Fintype.sum_unique]
    apply congrArg L
    funext j
    change w j=w j+∑ l : Fin 0, _
    simp
  | cons e es ih =>
    let F (t : Fin (es.length+1)→Fin d) := L (addSlots (e::es) w t)
    change (∑ i,expand L es (bump w i e))=∑ t,F t
    rw [←Equiv.sum_comp (Fin.consEquiv (fun _ : Fin (es.length+1)=>Fin d)) F,Fintype.sum_prod_type]
    apply Finset.sum_congr rfl
    intro i _
    rw [ih]
    exact Finset.sum_congr rfl (fun t _=> congrArg L (slots_cons es e w i t).symm)

theorem append (L : (Fin d→ℕ)→R) (as bs : List ℕ) (w : Fin d→ℕ) :
    expand L (as++bs) w=expand (expand L bs) as w := by
  induction as generalizing w with
  | nil=>rfl
  | cons e es ih=>simp [expand,ih]

def leaf (M : Fin d→ℕ→R) (w : Fin d→ℕ) := ∏ i,M i (w i)

private theorem perm (M : Fin d→ℕ→R) (p : Equiv.Perm (Fin d)) (hp : ∀ i,M (p i)=M i)
    (es : List ℕ) (w : Fin d→ℕ) :
    expand (leaf M) es (w ∘ p)=expand (leaf M) es w := by
  induction es generalizing w with
  | nil=>
    change (∏ i,M i (w (p i)))=∏ i,M i (w i)
    rw [←Equiv.prod_comp p (fun i=>M i (w i))]
    exact Finset.prod_congr rfl (fun i _=>by rw [hp])
  | cons e es ih=>
    unfold expand
    rw [←Equiv.sum_comp p (fun i=>expand (leaf M) es (bump w i e))]
    apply Finset.sum_congr rfl
    intro i _
    have eq : bump (w ∘ p) i e=bump w (p i) e ∘ p := by
      funext j
      simp [bump,Function.comp_apply]
    rw [eq,ih]

private theorem equal_site (M : Fin d→ℕ→R) (w : Fin d→ℕ) (i j : Fin d)
    (hm : M i=M j) (same : w i=w j) (e : ℕ) (es : List ℕ) :
    expand (leaf M) es (bump w i e)=expand (leaf M) es (bump w j e) := by
  have eq : bump w i e=bump w j e ∘ Equiv.swap i j := by
    funext x
    by_cases xi : x=i
    · subst x; simp [bump,same]
    · by_cases xj : x=j
      · subst x; simp [bump,xi,Ne.symm xi,same]
      · simp [bump,Equiv.swap_apply_of_ne_of_ne xi xj,xi,xj]
  rw [eq]
  apply perm
  intro x
  by_cases xi:x=i
  · subst x;simpa using hm.symm
  by_cases xj:x=j
  · subst x;simpa using hm
  rw [Equiv.swap_apply_of_ne_of_ne xi xj]

/-- Only the occupied sites and one representative of the fresh sites are visited at each step.
The moment function at an already distinguished ordinary core can differ from the other cores. -/
def fast (M : Fin d→ℕ→R) : List ℕ→(Fin d→ℕ)→ℕ→R
  | [],w,_=>leaf M w
  | e::es,w,k=>
    (∑ i : Fin d,if i.val<k then fast M es (bump w i e) k else 0)+
    if h:k<d then (d-k) • fast M es (bump w ⟨k,h⟩ e) (k+1) else 0

theorem compressed (M : Fin d→ℕ→R) (es : List ℕ) (w : Fin d→ℕ) (k : ℕ)
    (fresh : ∀ j : Fin d,k≤j.val→w j=0)
    (same : ∀ i j : Fin d,(k ≤ i.val) → (k ≤ j.val) → (M i = M j)) :
    expand (leaf M) es w=fast M es w k := by
  induction es generalizing w k with
  | nil=>rfl
  | cons e es ih=>
    rw [expand,fast]
    by_cases hk:k<d
    · let x : Fin d:=⟨k,hk⟩
      have sets : (Finset.univ : Finset (Fin d))=Finset.Iio x ∪ Finset.Ici x := by
        ext j; simp only [Finset.mem_univ,Finset.mem_union,Finset.mem_Iio,Finset.mem_Ici,true_iff];exact lt_or_ge _ _
      have dis : Disjoint (Finset.Iio x) (Finset.Ici x) := Finset.disjoint_left.mpr fun i lo hi=>
        (not_lt_of_ge (Finset.mem_Ici.mp hi)) (Finset.mem_Iio.mp lo)
      rw [dite_eq_left hk,←Finset.sum_filter]
      have ltset : (Finset.univ : Finset (Fin d)).filter (fun j=>j.val<k)=Finset.Iio x := by ext j; simp only [Finset.mem_filter,Finset.mem_univ,true_and,Finset.mem_Iio];rfl
      rw [ltset,sets,Finset.sum_union dis]
      apply congrArg₂ (·+·)
      · apply Finset.sum_congr rfl
        intro j hj
        apply ih _ _ _ same
        intro z hz
        have jl : j.val<k := (Finset.mem_Iio.mp hj : j<x)
        have neq : z≠j := by intro eq;subst z;omega
        simp [bump,neq,fresh z hz]
      · have freshX : ∀ z : Fin d,k+1≤z.val→bump w x e z=0 := by
          intro z hz
          have neq:z≠x := by intro eq;subst z;change k+1≤k at hz;omega
          simp [bump,neq,fresh z (by omega)]
        have sameX : ∀ i j : Fin d,(k+1 ≤ i.val) → (k+1 ≤ j.val) → (M i = M j) :=
          fun i j hi hj=>same i j (by omega) (by omega)
        rw [←ih _ _ freshX sameX]
        calc
          _ = ∑ _∈Finset.Ici x,expand (leaf M) es (bump w x e) := by
            apply Finset.sum_congr rfl
            intro j hj
            have jx : k≤j.val := (Finset.mem_Ici.mp hj : x≤j)
            exact equal_site M w j x (same j x jx le_rfl) ((fresh j jx).trans (fresh x le_rfl).symm) e es
          _ = _ := by simp [Fin.card_Ici,x]
    · rw [dite_eq_right hk,add_zero]
      apply Finset.sum_congr rfl
      intro i _
      have hi : i.val<k := by omega
      rw [ite_eq_left hi]
      apply ih
      · intro z hz;omega
      · intro u v hu;omega

#print axioms assigned
#print axioms compressed
end PrimeGap180.LowAngularCompressed


namespace PrimeGap180.LowAngularCompressed
open FrozenProfile
open FrozenChannels (Term Assignment)
open EnvelopeAngular (expAt)
open LowAngularProduct (exponent coefficient)

def code (U : Fin 13→ℝ) (k : ℕ) := if h:k<13 then U ⟨k,h⟩ else 0
def actual (U V : Fin 13→ℝ) (e i : Fin 39) := if i=e then code U else code V
def coef (a b : Fin 3) (s : Fin 11) : ℝ :=
  (LowAngularBernstein.caps a b s:ℝ)/(131072*Native.step)^(expAt a+expAt b)

private theorem inner_ne (i : Fin 37) : i.castSucc.succ≠Fin.last 38 := by
  intro eq
  have h:=congrArg Fin.val eq
  change i.val+1=38 at h
  omega

private theorem inner_ne_lit (i : Fin 37) : i.castSucc.succ≠(38:Fin 39) := inner_ne i

private theorem ends (a b : Fin 3) (s : Fin 11) (t : Assignment s) :
    exponent ⟨a,b,s,t⟩ 0=expAt a ∧ exponent ⟨a,b,s,t⟩ (Fin.last 38)=expAt b := by
  unfold exponent
  simp [inner_ne_lit,Fin.succ_ne_zero]

private theorem center (a b : Fin 3) (s : Fin 11) (t : Assignment s) (i : Fin 37) :
    exponent ⟨a,b,s,t⟩ i.castSucc.succ=∑ l,if t l=i then (signatures s).get l else 0 := by
  unfold exponent
  simp [inner_ne_lit,Fin.succ_ne_zero]

private theorem factors (M : Fin 39→ℕ→ℝ)
    (a b A B : Fin 3) (s u : Fin 11) (t : Assignment s) (v : Assignment u) :
    (∏ i,M i (exponent ⟨a,b,s,t⟩ i+exponent ⟨A,B,u,v⟩ i)) =
    M 0 (expAt a+expAt A)*M (Fin.last 38) (expAt b+expAt B)*
       leaf (fun i : Fin 37=>M i.castSucc.succ)
         (addSlots (signatures u) (addSlots (signatures s) (fun _=>0) t) v) := by
  rw [Fin.prod_univ_succ,Fin.prod_univ_castSucc]
  have end0 := (ends a b s t).1
  have end1 := (ends a b s t).2
  have end2 := (ends A B u v).1
  have end3 := (ends A B u v).2
  change M 0 _*((∏ i : Fin 37,M i.castSucc.succ _)*M (Fin.last 38) _)=_
  rw [show (Fin.last 37).succ=Fin.last 38 from rfl]
  simp only [end0,end1,end2,end3,center,leaf,addSlots,zero_add]
  ring

private theorem switch {R : Type*} [CommSemiring R] (F : Term→Term→R) :
    (∑ j : Term,∑ k : Term,F j k) =
    ∑ a : Fin 3,∑ b : Fin 3,∑ s : Fin 11,∑ A : Fin 3,∑ B : Fin 3,∑ S : Fin 11,
      ∑ t : Assignment s,∑ v : Assignment S,F ⟨a,b,s,t⟩ ⟨A,B,S,v⟩ := by
  simp only [Fintype.sum_sigma]
  refine Finset.sum_congr rfl fun a _=>Finset.sum_congr rfl fun b _=>Finset.sum_congr rfl fun s _=>?_
  rw [Finset.sum_comm (s:=(Finset.univ:Finset (Assignment s))) (t:=(Finset.univ:Finset (Fin 3)))]
  apply Finset.sum_congr rfl
  intro A _
  rw [Finset.sum_comm (s:=(Finset.univ:Finset (Assignment s))) (t:=(Finset.univ:Finset (Fin 3)))]
  apply Finset.sum_congr rfl
  intro B _
  rw [Finset.sum_comm (s:=(Finset.univ:Finset (Assignment s))) (t:=(Finset.univ:Finset (Fin 11)))]

def summary (X Y : ℕ→ℝ) (H : Fin 11→Fin 11→ℝ) :=
  ∑ a : Fin 3,∑ b : Fin 3,∑ s : Fin 11,∑ A : Fin 3,∑ B : Fin 3,∑ u : Fin 11,
    coef a b s*coef A B u*X (expAt a+expAt A)*Y (expAt b+expAt B)*H s u

def coreEntry (M : Fin 37→ℕ→ℝ) (s u : Fin 11) :=
  expand (leaf M) (signatures s ++ signatures u) (fun _=>0)

theorem groupedUpper (U V : Fin 13→ℝ) (e : Fin 39) :
    LowAngularProduct.upper U V e =
    summary (actual U V e 0) (actual U V e (Fin.last 38))
      (coreEntry (fun i : Fin 37=>actual U V e i.castSucc.succ)) := by
  let M:=actual U V e
  have h (j k : Term) (i : Fin 39) :
      (if i=e then U else V) ⟨exponent j i+exponent k i,LowAngularProduct.degree j k i⟩ =
      M i (exponent j i+exponent k i) := by
    by_cases z:i=e <;> simp [M,actual,code,z,LowAngularProduct.degree]
  unfold LowAngularProduct.upper
  simp_rw [h]
  rw [switch]
  unfold summary
  refine Finset.sum_congr rfl fun a _=>Finset.sum_congr rfl fun b _=>Finset.sum_congr rfl fun s _=>
    Finset.sum_congr rfl fun A _=>Finset.sum_congr rfl fun B _=>Finset.sum_congr rfl fun u _=>?_
  rw [coreEntry,append,assigned]
  simp_rw [assigned,Finset.mul_sum,factors]
  apply Finset.sum_congr rfl
  intro t _
  apply Finset.sum_congr rfl
  intro v _
  change (coef a b s*coef A B u)*(M 0 _*M (Fin.last 38) _*_) = _
  ring

#print axioms groupedUpper
end PrimeGap180.LowAngularCompressed

namespace PrimeGap180.LowAngularCompressed
open FrozenProfile (signatures)
variable {R : Type*} [CommSemiring R] {d : ℕ}
private theorem reindex (M : Fin d → ℕ → R) (p : Equiv.Perm (Fin d))
    (es : List ℕ) (w : Fin d → ℕ) :
    expand (leaf (M ∘ p)) es (w ∘ p) = expand (leaf M) es w := by
  induction es generalizing w with
  | nil =>
    exact Equiv.prod_comp p (fun i => M i (w i))
  | cons e es ih =>
    rw [expand,expand,←Equiv.sum_comp p (fun i=>expand (leaf M) es (AngularOccupied.bump w i e))]
    apply Finset.sum_congr rfl
    intro i _
    have eq : AngularOccupied.bump (w ∘ p) i e=AngularOccupied.bump w (p i) e ∘ p := by
      funext j
      simp [AngularOccupied.bump,Function.comp_apply]
    rw [eq,ih]

def special (U V : Fin 13→ℝ) (i x : Fin 37) := if x=i then code U else code V

def regular (V : Fin 13→ℝ) (s u : Fin 11) :=
  fast (fun _ : Fin 37=>code V) (signatures s ++ signatures u) (fun _=>0) 0

def mixed (U V : Fin 13→ℝ) (s u : Fin 11) :=
  fast (special U V 0) (signatures s ++ signatures u) (fun _=>0) 1

private theorem ordinary_core (V : Fin 13→ℝ) :
    coreEntry (fun _=>code V) = regular V := by
  funext s u
  apply compressed
  · simp
  · simp

private theorem mixed_core (U V : Fin 13→ℝ) (i : Fin 37) :
    coreEntry (special U V i) = mixed U V := by
  funext s u
  have hi : special U V i = special U V 0 ∘ Equiv.swap i 0 := by
    funext x
    by_cases xi:x=i
    · subst x; simp [special]
    · by_cases xz:x=0
      · subst x; simp [special,xi,Ne.symm xi]
      · simp [special,xi,xz,Equiv.swap_apply_of_ne_of_ne xi xz]
  unfold coreEntry mixed
  rw [hi]
  change expand (leaf (special U V 0 ∘ Equiv.swap i 0)) _ ((fun _=>0) ∘ Equiv.swap i 0) = _
  rw [reindex]
  apply compressed
  · simp
  · intro k l hk hl
    have kp:k≠0 := by intro z;subst k;omega
    have lp:l≠0 := by intro z;subst l;omega
    simp [special,kp,lp]

def full (U V : Fin 13→ℝ) :=
  summary (code U) (code V) (regular V) +
  summary (code V) (code U) (regular V) +
  37*summary (code V) (code V) (mixed U V)

theorem erasedSum (U V : Fin 13→ℝ) :
    (∑ i : Fin 39,LowAngularProduct.upper U V i) = full U V := by
  have left : LowAngularProduct.upper U V 0 = summary (code U) (code V) (regular V) := by
    rw [groupedUpper]
    simp [actual,ordinary_core]
  have right : LowAngularProduct.upper U V (Fin.last 38) = summary (code V) (code U) (regular V) := by
    rw [groupedUpper]
    simp [actual,inner_ne_lit,ordinary_core]
  have mid (i : Fin 37) : LowAngularProduct.upper U V i.castSucc.succ =
      summary (code V) (code V) (mixed U V) := by
    rw [groupedUpper]
    have h : (fun t:Fin 37=>actual U V i.castSucc.succ t.castSucc.succ)=special U V i := by
      funext t; simp [actual,special]
    rw [h,mixed_core]
    simp [actual,Ne.symm (Fin.succ_ne_zero i.castSucc),Ne.symm (inner_ne_lit i)]
  rw [Fin.sum_univ_succ,Fin.sum_univ_castSucc,left]
  simp only [mid,show (Fin.last 37).succ=Fin.last 38 from rfl,right,Finset.sum_const,
    Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]
  unfold full
  ring

#print axioms erasedSum
end PrimeGap180.LowAngularCompressed

end
noncomputable section
open Set MeasureTheory PrimeGap180.Sector PrimeGap180.FrozenProfile
open scoped BigOperators NNReal
namespace PrimeGap180.LowAngularOuter
open LowMassReceiver (lastRow lastEdge lastCharge)
open LowAngularProduct (upper contraction cutoff)
open LowWeightedQuadrature (shifted)
open GateDeletion (T Full μ)

def edgeNat : Fin 3→ℕ := ![60000,70000,80000]
def next : Fin 3→ℕ := ![70000,80000,90000]
def beta : Fin 3→ℕ := ![16,16,15]
def rate : Fin 3→ℕ := ![530,450,380]
def stepQ : ℚ := 1399373467/172031279104000
def excess (j : Fin 3) : ℚ := beta j*(131072*stepQ)+rate j*(2*next j/2624990:ℚ)
def expCode (x : ℚ) :=
  let k:=⌈1000*x⌉₊
  (27182819/10^7:ℚ)^(k/1000)*(1001001/10^6:ℚ)^(k%1000)
def factor (j : Fin 3) := (1+(907/5)*stepQ/2)^78*expCode (excess j)

set_option maxRecDepth 32768 in
theorem endpoints (j : Fin 3) :
    LaterLowTransform.edge (T.tailEdge (lastEdge j))=((edgeNat j:ℚ)/2624990:ℚ) ∧
    cutoff j=(2*next j:ℝ)/2624990 := by
  have eq : (RemovalEdgeBook.lowerNat (lastEdge j),FrozenData.parentUpperNat (lastEdge j))=(edgeNat j,next j) := by
    exact (LowMassReceiver.low_edges j).trans (by fin_cases j <;> rfl)
  have l : RemovalEdgeBook.lowerNat (lastEdge j)=edgeNat j := (Prod.mk.inj eq).1
  have h : FrozenData.parentUpperNat (lastEdge j)=next j := (Prod.mk.inj eq).2
  have raw:=RemovalEdgeBook.ticks_eq (lastEdge j)
  rw [l] at raw
  constructor
  · push_cast
    apply (eq_div_iff (by norm_num)).mpr
    rw [mul_comm];exact raw
  · rw [cutoff,FrozenData.parentUpper_nat,h]
    norm_num [Lookup.ticks]
    ring

private theorem exp_milli : Real.exp (1/1000:ℝ)≤1001001/10^6 := by
  have lo : (1-1/2000:ℝ)≤Real.exp (-(1/2000:ℝ)) := by
    linarith only [Real.add_one_le_exp (-(1/2000:ℝ))]
  have l:=pow_le_pow_left₀ (by norm_num : (0:ℝ)≤1-1/2000) lo 2
  rw [←Real.exp_nat_mul,show ((2:ℕ):ℝ)* -(1/2000)= -(1/1000) from by norm_num,Real.exp_neg] at l
  have unit : (1001001/10^6:ℝ)⁻¹ ≤ (1-1/2000:ℝ)^2 := by norm_num
  have low := unit.trans l
  exact (inv_le_inv₀ (by norm_num) (Real.exp_pos _)).mp low

theorem exponential (x : ℚ) : Real.exp (x:ℝ)≤(expCode x:ℝ) := by
  let k:=⌈1000*x⌉₊
  have ha : 1000*(x:ℝ)≤(k:ℝ) := by exact_mod_cast Nat.le_ceil (1000*x)
  have hdiv := Nat.mod_add_div k 1000
  have hd : ((k%1000:ℕ):ℝ)+1000*((k/1000:ℕ):ℝ)=(k:ℝ) := by exact_mod_cast hdiv
  have bound : (x:ℝ)≤((k/1000:ℕ):ℝ)*(1:ℝ)+((k%1000:ℕ):ℝ)*(1/1000:ℝ) := by linarith only [ha,hd]
  apply (Real.exp_le_exp.mpr bound).trans
  rw [Real.exp_add,Real.exp_nat_mul,Real.exp_nat_mul]
  unfold expCode
  push_cast
  exact mul_le_mul (pow_le_pow_left₀ (Real.exp_pos _).le (Real.exp_one_lt_d9.le.trans (by norm_num)) _)
    (pow_le_pow_left₀ (Real.exp_pos _).le exp_milli _) (by positivity) (by positivity)

theorem real_factor (j : Fin 3) :
    LaterLowFactor.bias^78*Real.exp ((beta j:ℝ)*LaterLowProduct.totalCap+(rate j:ℝ)*cutoff j) ≤ (factor j:ℝ) := by
  have hp : (0:ℝ)≤LaterLowFactor.bias^78 := Even.pow_nonneg (by decide : Even 78) _
  have dx : (excess j:ℝ)=(beta j:ℝ)*LaterLowProduct.totalCap+(rate j:ℝ)*cutoff j := by
    rw [(endpoints j).2]
    unfold excess LaterLowProduct.totalCap stepQ Native.step
    push_cast
    ring
  rw [←dx]
  apply (mul_le_mul_of_nonneg_left (exponential (excess j)) hp).trans_eq
  unfold factor LaterLowFactor.bias LaterLowFactor.w Native.step stepQ
  push_cast
  ring

#print axioms endpoints
#print axioms real_factor
end PrimeGap180.LowAngularOuter

namespace PrimeGap180.LowAngularInteger
open LowAngularCompressed
open FrozenProfile (signatures)
open EnvelopeAngular (expAt)
def amplitudeNum : ℕ := 1399373467
def amplitudeDen : ℕ := 1312494500
def unit : ℝ := (10^48)⁻¹
def radialUnit : ℝ := ((amplitudeNum:ℝ)^4)⁻¹
def w (a b : Fin 3) (s : Fin 11) :=
  let e := expAt a+expAt b
  LowAngularBernstein.caps a b s*amplitudeDen^e*amplitudeNum^(4-e)

private theorem radial (a b : Fin 3) (s : Fin 11) :
    coef a b s=(w a b s:ℝ)*radialUnit := by
  have small (i : Fin 3) : expAt i≤2 := by unfold expAt; split <;> decide
  have he : expAt a+expAt b≤4 := by have:=small a; have:=small b; omega
  have hrad : 131072*Native.step=(amplitudeNum:ℝ)/(amplitudeDen:ℝ) := by
    norm_num [Native.step,amplitudeNum,amplitudeDen]
  have p : (amplitudeNum:ℝ)^(expAt a+expAt b)*(amplitudeNum:ℝ)^(4-(expAt a+expAt b))=(amplitudeNum:ℝ)^4 := by
    rw [←pow_add,Nat.add_sub_of_le he]
  have nz:(amplitudeNum:ℝ)≠0 := by norm_num [amplitudeNum]
  have dz:(amplitudeDen:ℝ)≠0 := by norm_num [amplitudeDen]
  unfold coef w radialUnit
  rw [hrad,div_pow]
  push_cast
  field_simp [nz,dz]; rw [←p]; ring

def table (U : Fin 13→ℕ) (n : ℕ) := if h:n<13 then U ⟨n,h⟩ else 0
def decode (U : Fin 13→ℕ) (n : Fin 13) := (U n:ℝ)*unit

private theorem lifted (U : Fin 13→ℕ) (k : ℕ) : code (decode U) k=(table U k:ℝ)*unit := by
  unfold code table decode
  split <;> simp

theorem fast_scale {d : ℕ} (M : Fin d→ℕ→ℕ) (z : ℝ) (es : List ℕ) (g : Fin d→ℕ) (k : ℕ) :
    fast (fun i n=>(M i n:ℝ)*z) es g k=((fast M es g k:ℕ):ℝ)*z^d := by
  induction es generalizing g k with
  | nil =>
    simp only [fast,leaf,Finset.prod_mul_distrib,Finset.prod_const,Finset.card_univ,Fintype.card_fin,Nat.cast_prod]
  | cons e es ih =>
    rw [fast,fast]
    push_cast
    rw [add_mul,Finset.sum_mul]
    apply congrArg₂ (·+·)
    · refine Finset.sum_congr rfl fun i _=>?_
      by_cases hk:i.val<k <;> simp [hk,ih]
    · by_cases hk:k<d
      · simp [hk,ih,nsmul_eq_mul,mul_assoc]
      · simp [hk]

def regularN (V : Fin 13→ℕ) (s u : Fin 11) :=
  fast (fun _ : Fin 37=>table V) (signatures s ++ signatures u) (fun _=>0) 0

def mixedN (U V : Fin 13→ℕ) (s u : Fin 11) :=
  fast (fun x : Fin 37=>if x=0 then table U else table V) (signatures s ++ signatures u) (fun _=>0) 1

private theorem regular_lift (V : Fin 13→ℕ) (s u : Fin 11) :
    regular (decode V) s u=(regularN V s u:ℝ)*unit^37 := by
  unfold regular regularN
  have h : (fun _ : Fin 37=>code (decode V)) = fun (_ : Fin 37) n=>(table V n:ℝ)*unit := by
    funext i n;exact lifted V n
  rw [h,fast_scale]

private theorem mixed_lift (U V : Fin 13→ℕ) (s u : Fin 11) :
    mixed (decode U) (decode V) s u=(mixedN U V s u:ℝ)*unit^37 := by
  unfold mixed mixedN
  have h : special (decode U) (decode V) 0 = fun (i:Fin 37) n=>
      ((if i=0 then table U else table V) n:ℝ)*unit := by
    funext i n
    by_cases h:i=0 <;> simp [special,h,lifted]
  rw [h,fast_scale]

def summaryN (X Y : ℕ→ℕ) (H : Fin 11→Fin 11→ℕ) :=
  ∑ a : Fin 3,∑ b : Fin 3,∑ s : Fin 11,∑ A : Fin 3,∑ B : Fin 3,∑ u : Fin 11,
    w a b s*w A B u*X (expAt a+expAt A)*Y (expAt b+expAt B)*H s u

def scale := radialUnit^2*unit^39

private theorem summary_lift (X Y : ℕ→ℕ) (H : Fin 11→Fin 11→ℕ) :
    summary (fun k=>(X k:ℝ)*unit) (fun k=>(Y k:ℝ)*unit) (fun s u=>(H s u:ℝ)*unit^37) =
    (summaryN X Y H:ℝ)*scale := by
  unfold summary summaryN
  push_cast
  simp_rw [Finset.sum_mul]
  refine Finset.sum_congr rfl fun a _=>Finset.sum_congr rfl fun b _=>Finset.sum_congr rfl fun s _=>
    Finset.sum_congr rfl fun A _=>Finset.sum_congr rfl fun B _=>Finset.sum_congr rfl fun u _=>?_
  rw [radial,radial]
  unfold scale
  ring

def fullN (U V : Fin 13→ℕ) :=
  summaryN (table U) (table V) (regularN V) +
  summaryN (table V) (table U) (regularN V) +
  37*summaryN (table V) (table V) (mixedN U V)

theorem exactContraction (U V : Fin 13→ℕ) :
    (∑ i : Fin 39,LowAngularProduct.upper (decode U) (decode V) i)=(fullN U V:ℝ)*scale := by
  rw [erasedSum]
  unfold full fullN
  have l (A : Fin 13→ℕ) : code (decode A) = fun k=>(table A k:ℝ)*unit := funext (lifted A)
  have reg : regular (decode V) = fun s u=>(regularN V s u:ℝ)*unit^37 :=
    funext fun s=>funext (regular_lift V s)
  have mix : mixed (decode U) (decode V) = fun s u=>(mixedN U V s u:ℝ)*unit^37 :=
    funext fun s=>funext (mixed_lift U V s)
  rw [l,l,reg,mix,summary_lift,summary_lift,summary_lift]
  push_cast
  ring

#print axioms exactContraction
end PrimeGap180.LowAngularInteger

namespace PrimeGap180.LowAngularPayment
open GateDeletion (T μ)
open LowMassReceiver (lastEdge lastRow lastCharge)
open LowAngularOuter (beta rate edgeNat factor)
open LowAngularInteger (fullN)
open LowWeightedQuadrature (shifted)

def vector (j : Fin 3) (r : ℕ) (n : Fin 13) :=
  LowAngularDirected.read (LowAngularGrid.paid (edgeNat j) (beta j) r) n.val

def scaleQ : ℚ := ((LowAngularInteger.amplitudeNum:ℚ)^4)⁻¹^2*((10^48:ℚ)⁻¹)^39

def charge (j : Fin 3) : ℚ := factor j * ((fullN (vector j 0) (vector j (rate j)) : ℕ):ℚ) * scaleQ

private theorem beta_pos (j : Fin 3) : 0<beta j := by fin_cases j <;> decide

private theorem bound (j : Fin 3) (r : ℕ) (n : Fin 13) :
    shifted (T.tailEdge (lastEdge j)) n.val (beta j) r (Native.step/2) ≤ LowAngularInteger.decode (vector j r) n := by
  have h:=LowAngularGrid.physical (lastEdge j) (beta_pos j) (LowAngularOuter.endpoints j).1 r n
  simpa only [LowAngularInteger.decode,vector,LowAngularInteger.unit,LowAngularDirected.rawScale,Nat.cast_pow,Nat.cast_ofNat,div_eq_mul_inv] using h

theorem raw (j : Fin 3) :
    (∫ v in lastRow j,(Restoration.original v)^2 ∂μ) ≤ (charge j:ℝ) := by
  let u:=vector j 0
  let v:=vector j (rate j)
  let e:=T.tailEdge (lastEdge j)
  let g:=LaterLowFactor.bias^78*Real.exp ((beta j:ℝ)*LaterLowProduct.totalCap+(rate j:ℝ)*LowAngularProduct.cutoff j)
  have ge:0≤g := mul_nonneg (Even.pow_nonneg (by decide : Even 78) _) (Real.exp_pos _).le
  have p := LowAngularProduct.event j (beta j : ℝ≥0) (rate j : ℝ≥0) (by exact_mod_cast beta_pos j)
  have ev : (∫ x in lastRow j,(Restoration.original x)^2 ∂μ) ≤ g*∑ i:Fin 39, LowAngularProduct.contraction e (beta j) (rate j) i := by
    simpa only [NNReal.coe_natCast,g,e] using p
  have su := Finset.sum_le_sum (s:=(Finset.univ:Finset (Fin 39))) fun i _=>
    LowAngularProduct.contraction_upper e (beta j) (rate j) i (LowAngularInteger.decode u) (LowAngularInteger.decode v) (by
      intro n;simpa only [Nat.cast_zero] using bound j 0 n) (bound j (rate j))
  have sc : 0≤LowAngularInteger.scale := by unfold LowAngularInteger.scale LowAngularInteger.radialUnit LowAngularInteger.unit; positivity
  have eq : (scaleQ:ℝ)=LowAngularInteger.scale := by
    unfold scaleQ LowAngularInteger.scale LowAngularInteger.unit LowAngularInteger.radialUnit
    push_cast; rfl
  apply (ev.trans (mul_le_mul_of_nonneg_left su ge)).trans
  rw [LowAngularInteger.exactContraction]
  apply (mul_le_mul_of_nonneg_right (LowAngularOuter.real_factor j) (mul_nonneg (Nat.cast_nonneg _) sc)).trans_eq
  unfold charge
  push_cast
  rw [eq]
  ring

theorem original_low
    (floor : (94.17312:ℝ) ≤ 100^39*NumericalAccount.mass Restoration.original)
    (payment : ∀ j : Fin 3,charge j≤lastCharge j) :
    StructuralRun.layerMass 0 ≤ (RemovalReceipts.low:ℝ)*NumericalAccount.mass Restoration.original := by
  apply LowMassReceiver.low_mass floor
  intro j
  exact (raw j).trans (by exact_mod_cast payment j)

#print axioms raw
#print axioms original_low
end PrimeGap180.LowAngularPayment
