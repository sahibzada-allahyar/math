import TrialMassRadialValues180
import Mathlib.Algebra.Polynomial.Degree.Operations

/-! On a single cubic knot span all four active B-splines are ordinary
polynomials. Their coefficients can be reused over every native tick. -/
noncomputable section
open scoped BigOperators Polynomial
namespace PrimeGap180.MassSplineSpan
open Polynomial FrozenProfile FrozenData FullNativeTicks MassRadialValues

private def records : Array (Array Nat) := #[#[990178264387599,6496188829250660],
  #[990178264387599,6496188829250660],
  #[990178264387599,6496188829250660],
  #[990178264387599,6496188829250660],
  #[330059421462533,1299237765850132],
  #[2310415950237731,6496188829250660],
  #[2970534793162797,6496188829250660],
  #[3630653636087863,6496188829250660],
  #[4290772479012929,6496188829250660],
  #[990178264387599,1299237765850132],
  #[10891960908263589,12992377658501320],
  #[2310415950237731,2598475531700264],
  #[12212198594113721,12992377658501320],
  #[330059421462533,344528493755500],
  #[330059421462533,344528493755500],
  #[330059421462533,344528493755500],
  #[330059421462533,344528493755500],
  #[2520000,2624989],
  #[2540000,2624989],
  #[2566000,2624989],
  #[2600000,2624989],
  #[130624461,131249450],
  #[2625000,2624989],
  #[2642000,2624989],
  #[2670000,2624989],
  #[16509166398375785846190125654811703267,16161921199408696007503616565983946000],
  #[16509166398375785846190125654811703267,16161921199408696007503616565983946000],
  #[16509166398375785846190125654811703267,16161921199408696007503616565983946000],
  #[16509166398375785846190125654811703267,16161921199408696007503616565983946000],
  #[2700000,2624989],
  #[1399373467,1312494500],
  #[1399373467,1312494500],
  #[1399373467,1312494500],
  #[1399373467,1312494500]]

def knot (i : Nat) : ℚ :=
  let r := records[i]?.getD #[]
  ((r[0]?.getD 0 : Nat):ℚ)/((r[1]?.getD 0 : Nat):ℚ)

private def basis (x : ℚ) : Nat → Nat → ℚ
  | 0,i => if knot i ≤ x ∧ x < knot (i+1) then 1 else 0
  | d+1,i => (x-knot i)*basis x d i/(knot (i+d+1)-knot i) +
      (knot (i+d+2)-x)*basis x d (i+1)/(knot (i+d+2)-knot (i+1))

def sample (j : Nat) : ℚ := ((j:ℚ)+39/2)*(1399373467/172031279104000)

private theorem original (j : Nat) (k : Fin 30) : splineQ j k =
    if knot 3 ≤ sample j ∧ sample j < knot 33 then basis (sample j) 3 k.val else 0 := by rfl

def piece (s : Nat) : Nat → Nat → ℚ[X]
  | 0,i => if i=s then 1 else 0
  | d+1,i => (X-C (knot i))*piece s d i*C ((knot (i+d+1)-knot i)⁻¹) +
      (C (knot (i+d+2))-X)*piece s d (i+1)*C ((knot (i+d+2)-knot (i+1))⁻¹)

private theorem monotone_knots : Monotone (fun i : Fin 34 => knot i.val) :=
  Fin.monotone_iff_le_succ.mpr (by decide +kernel)

private theorem ordered {i j : Nat} (hij : i≤j) (hj : j<34) : knot i≤knot j :=
  @monotone_knots ⟨i,by omega⟩ ⟨j,hj⟩ hij

private theorem cell {i s : Nat} {x : ℚ} (hi : i<33) (hs : s<33)
    (center : knot s≤x ∧ x < knot (s+1)) :
    (knot i≤x ∧ x < knot (i+1)) ↔ i=s := by
  constructor
  · rintro ⟨a,b⟩
    rcases lt_trichotomy i s with h|h|h
    · have before : i+1 ≤ s := h
      have impossible := (ordered before (by omega)).trans center.1
      exact False.elim (not_lt_of_ge impossible b)
    · exact h
    · have after : s+1 ≤ i := h
      have impossible := (ordered after (by omega)).trans a
      exact False.elim (not_lt_of_ge impossible center.2)
  · rintro rfl
    exact center

private theorem point (s : Nat) (x : ℚ) (hs : s<33) (active : knot s≤x ∧ x < knot (s+1)) :
    ∀ d i, i+d<33 → basis x d i=(piece s d i).eval x := by
  intro d
  induction d with
  | zero =>
    intro i hi
    simp only [basis,piece,cell (show i<33 by omega) hs active]
    split <;> simp
  | succ d ih =>
    intro i hi
    simp only [basis,piece,eval_add,eval_mul,eval_sub,eval_X,eval_C,div_eq_mul_inv]
    rw [ih _ (by omega),ih _ (by omega)]

theorem spline_on_span (j : Nat) (k : Fin 30) (s : Nat) (left : 3 ≤ s) (right : s < 33)
    (active : knot s ≤ sample j ∧ sample j < knot (s+1)) :
    splineQ j k=(piece s 3 k.val).eval (sample j) := by
  have start : knot 3 ≤ knot s := ordered left (by omega)
  have stop : knot (s+1) ≤ knot 33 := ordered (by omega) (by decide)
  rw [original,ite_eq_left ⟨start.trans active.1,active.2.trans_le stop⟩]
  exact point s _ right active 3 k.val (by omega)

theorem before {j : Nat} (small : sample j < knot 3) (k : Fin 30) : splineQ j k=0 := by
  rw [original,ite_eq_right]
  exact fun h => (not_lt_of_ge h.1) small

theorem sample_mono : Monotone sample := by
  intro i j h
  unfold sample
  apply mul_le_mul_of_nonneg_right _ (by norm_num)
  have ij : (i:ℚ) ≤ (j:ℚ) := by exact_mod_cast h
  linarith

#print axioms spline_on_span
end PrimeGap180.MassSplineSpan
