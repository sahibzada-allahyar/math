import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G102
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 102

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G102

namespace PrimeGap180.PriceIsolatedGroup.G107
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 107

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G107

namespace PrimeGap180.PriceIsolatedGroup.G112
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 112

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G112

namespace PrimeGap180.PriceIsolatedGroup.G117
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 117

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G117
