import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G160
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 160

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G160

namespace PrimeGap180.PriceIsolatedGroup.G165
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 165

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G165

namespace PrimeGap180.PriceIsolatedGroup.G170
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 170

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G170

namespace PrimeGap180.PriceIsolatedGroup.G175
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 175

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G175
