import TrialPriceResourceRows180
namespace PrimeGap180.PriceResourceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 100000000
private theorem p7 : checkResource 7 = true := by decide +kernel
private theorem p8 : checkResource 8 = true := by decide +kernel
private theorem p9 : checkResource 9 = true := by decide +kernel
private theorem p10 : checkResource 10 = true := by decide +kernel
private theorem p11 : checkResource 11 = true := by decide +kernel
private theorem p12 : checkResource 12 = true := by decide +kernel
private theorem p13 : checkResource 13 = true := by decide +kernel
theorem block1 : ∀ j : Fin 7, checkResource (7+j.val) = true :=
  Fin.cases p7 (Fin.cases p8 (Fin.cases p9 (Fin.cases p10 (Fin.cases p11 (Fin.cases p12 (Fin.cases p13 (fun i => Fin.elim0 i)))))))
#print axioms block1
end PrimeGap180.PriceResourceRows
