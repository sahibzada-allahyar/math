import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G322
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 322

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G322

namespace PrimeGap180.PriceIsolatedGroup.G327
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 327

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G327

namespace PrimeGap180.PriceIsolatedGroup.G332
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 332

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G332

namespace PrimeGap180.PriceIsolatedGroup.G337
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 337

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G337
