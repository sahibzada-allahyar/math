import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G263
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 263

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G263

namespace PrimeGap180.PriceIsolatedGroup.G268
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 268

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G268

namespace PrimeGap180.PriceIsolatedGroup.G273
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 273

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G273

namespace PrimeGap180.PriceIsolatedGroup.G278
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 278

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G278
