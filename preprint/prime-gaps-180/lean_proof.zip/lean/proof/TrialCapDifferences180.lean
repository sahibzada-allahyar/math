import TrialCellQuadrature180

noncomputable section
open scoped BigOperators Classical ENNReal Topology
open MeasureTheory Filter PrimeGap186 PrimeGap180.CoarseLaw PrimeGap180.Sector
namespace PrimeGap180.CellQuadrature


/-- A lower maximum cap implies a higher one on every state of nonzero
physical weight. This also proves that nonnested Boolean patterns carry zero. -/
theorem nested (a b : FrozenProfile.Fine) (order : T.capEdge a ≤ T.capEdge b)
    (s : State) (nonzero : weight s ≠ 0) (small : s.2 a = true) : s.2 b = true := by
  have positive : ∀ᵐ z ∂μ, ∀ j, 0 ≤ z j := by
    apply Measure.ae_smul_measure
    rw [ae_all_iff]
    intro j
    apply (ae_map_iff (measurable_fragmentBandMasses _).aemeasurable
      (measurableSet_le measurable_const (measurable_pi_apply j))).mpr
    exact ae_of_all _ fun _ => NNReal.zero_le_coe
  let P := fun x : State => x.2 a = true → x.2 b = true
  have legal : ∀ᵐ x ∂law, P x := by
    apply (ae_map_iff state_meas.aemeasurable (Set.Finite.measurableSet (Set.toFinite _))).mpr
    filter_upwards [positive] with z hz
    change flag z a = true → flag z b = true
    simp only [flag,ite_eq_left_iff,Bool.false_eq_true,imp_false,not_not]
    have tails : NativeSiteLaw.tail (T.capEdge b) z ≤ NativeSiteLaw.tail (T.capEdge a) z := by
      apply Finset.sum_le_sum_of_subset_of_nonneg
      · intro j hj
        exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, order.trans (Finset.mem_filter.mp hj).2⟩
      · exact fun j _ _ => hz j
    have caps := T.ordered.monotone (Fin.castSucc_le_castSucc_iff.mpr order)
    intro low
    exact (tails.trans_lt low).trans_le (div_le_div_of_nonneg_right caps (by norm_num))
  by_contra no
  have subs : ({s} : Set State) ⊆ {x | ¬ P x} := by
    intro x hx h
    simp only [Set.mem_singleton_iff] at hx
    subst x
    exact no (h small)
  have zero := measure_mono_null subs (ae_iff.mp legal)
  exact nonzero (by simp [weight,measureReal_def,zero])

def bin (k : ℕ) (a b : FrozenProfile.Fine) : ℝ :=
  ∑ s : State, if s.1.val = k ∧ s.2 b = true ∧ s.2 a = false then weight s else 0

theorem bin_eq (k : ℕ) (a b : FrozenProfile.Fine) (order : T.capEdge a ≤ T.capEdge b) :
    bin k a b = cdf k b - cdf k a := by
  unfold bin cdf
  rw [←Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro s _
  by_cases zero : weight s = 0
  · simp [zero]
  · have legal := nested a b order s zero
    cases e : s.2 a <;> cases f : s.2 b <;> by_cases idx : s.1.val = k <;> simp_all

/-- Two directed cumulative enclosures yield one enclosure of the true physical
annulus, even when the mass is much smaller than either cumulative value. -/
theorem bounds_of_cdf (k : ℕ) (a b : FrozenProfile.Fine) (order : T.capEdge a ≤ T.capEdge b)
    {la ua lb ub : ℝ} (A : la ≤ cdf k a ∧ cdf k a ≤ ua) (B : lb ≤ cdf k b ∧ cdf k b ≤ ub) :
    lb - ua ≤ bin k a b ∧ bin k a b ≤ ub - la := by
  rw [bin_eq k a b order]
  exact ⟨sub_le_sub B.1 A.2,sub_le_sub B.2 A.1⟩

#print axioms bin_eq
end PrimeGap180.CellQuadrature
