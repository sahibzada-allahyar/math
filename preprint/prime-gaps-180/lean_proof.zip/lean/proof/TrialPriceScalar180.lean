import TrialPriceValues180
import TrialPriceComponents180

/-! Both scalar tests use the literal reference masses, prices, owner map,
floors and kernel ratios. All sums retain their exact rational denominators. -/
noncomputable section
open scoped BigOperators
open PrimeGap180.Book PrimeGap180.PackedLedger
namespace PrimeGap180.PriceScalar

private def ratio (x : ℕ × ℕ) : ℚ := (x.1:ℚ)/x.2
private def unit : ℚ := 10^14

theorem unit_cast : (unit:ℝ) = Price.priceUnit := by norm_num [unit,Price.priceUnit]

def ref (g : ℕ) := ratio raw.refs[g]!
def gain (g : ℕ) : ℚ := ((PriceValues.group g).gain:ℚ)/(10^18*unit)
def resourceCharge (g u : ℕ) : ℚ := (PriceValues.resource g u:ℚ)/unit^2
def eventCharge (g e : ℕ) : ℚ := (PriceValues.event g e:ℚ)/(24*(32*unit)^2)
private def floorTotal : ℤ := 328174011196611
def correction (g : ℕ) : ℚ := ((445*raw.floors[g]!+floorTotal+445:ℤ):ℚ)/unit^2

def resourceIndex : Resource → ℕ
  | .prime => 0 | .oldRough => 1 | .allRough => 2 | .primeThree i => 3+i.val
  | .fullFive i => 15+i.val | .triples i => 27+i.val | .extraFives i => 38+i.val

def eventIndex : Book.Event → ℕ
  | .prime => 0 | .oldFive => 1 | .three i => 2+i.val | .newFive i => 14+i.val

def resourceKernel (s : Label) (u : Resource) :=
  ratio (raw.resourceKernel[resourceIndex u]!)[raw.radiusIndex[s.val]!]!

def eventKernel (s : Label) (e : Book.Event) :=
  ratio (raw.eventKernel[eventIndex e]!)[raw.radiusIndex[s.val]!]!

def fixed (s : Label) (g : ℕ) : ℚ :=
  gain g-(∑ u : Resource, if u = .prime then 0 else resourceCharge g (resourceIndex u)*resourceKernel s u)-
    ∑ e : Book.Event, if e = .prime then 0 else eventCharge g (eventIndex e)*eventKernel s e

theorem ratio_cast (p : ℕ × ℕ) : (ratio p:ℝ) = (p.1:ℝ)/p.2 := by simp [ratio]

theorem ref_cast (g : Group) : (ref g.val:ℝ) = FrozenLedger.ledger.ref g := by
  rw [ref,ratio_cast]
  rfl

theorem resource_kernel_cast (s : SectorId) (u : Resource) :
    (resourceKernel s.val u:ℝ) = FrozenLedger.ledger.resourceKernel u s := by
  rw [resourceKernel,ratio_cast]
  cases u <;> rfl

theorem event_kernel_cast (s : SectorId) (e : Book.Event) :
    (eventKernel s.val e:ℝ) = FrozenLedger.ledger.eventKernel e s := by
  rw [eventKernel,ratio_cast]
  cases e <;> rfl

private theorem indexed_sum (xs : List ℤ) : (∑ i : Fin xs.length, xs[i.val]) = xs.sum := by
  induction xs with
  | nil => simp
  | cons a tail ih => simp [Fin.sum_univ_succ,ih]

private theorem array_sum (xs : Array ℤ) (n : ℕ) (size : xs.size = n) :
    xs.toList.sum = ∑ i : Fin n, xs[i.val]! := by
  subst n
  refine (indexed_sum xs.toList).symm.trans ?_
  apply Finset.sum_congr rfl
  intro i _
  rw [getElem!_pos xs i.val i.isLt] <;> rfl

set_option maxRecDepth 131072 in
private theorem floors_count : raw.floors.size = 445 := by decide +kernel

set_option maxRecDepth 131072 in
private theorem floors_add : floorTotal = raw.floors.toList.sum := by decide +kernel

private theorem floor_sum : floorTotal = ∑ g : Group, FrozenLedger.ledger.floors g :=
  floors_add.trans (array_sum raw.floors 445 floors_count)

theorem correction_cast (g : Group) : (correction g.val:ℝ) = Book.floorCharge FrozenLedger.ledger g := by
  have totals : (floorTotal:ℝ) = ∑ h : Group, (FrozenLedger.ledger.floors h:ℝ) := by exact_mod_cast floor_sum
  unfold correction Book.floorCharge Price.roundingRow Book.floorW
  push_cast
  rw [totals]
  simp only [Fintype.card_fin,Nat.cast_ofNat,unit_cast] <;> rfl

def inverse (g : ℕ) : ℚ := -(resourceCharge g 0+eventCharge g 0+correction g)

def checked (s : Label) : Bool :=
  if hs : s.val < 170 ∨ 173 < s.val then
    let g := (owner ⟨s,hs⟩).val
    let p := Detection.archivedPrice s
    decide ((p.1:ℚ)/unit*ref g ≤ fixed s g ∧ (p.2:ℚ)/unit*ref g ≤ inverse g)
  else true

theorem sound (s : SectorId) (pass : checked s.val = true) :
    ((Detection.archivedPrice s.val).1:ℚ)/unit*ref (owner s).val ≤ fixed s.val (owner s).val ∧
    ((Detection.archivedPrice s.val).2:ℚ)/unit*ref (owner s).val ≤ inverse (owner s).val := by
  have active : s.val.val < 170 ∨ 173 < s.val.val := s.property
  simpa only [checked,dite_eq_left active,decide_eq_true_eq] using pass

theorem income_test (s : SectorId) (pass : checked s.val = true) :
    p0 s.val * FrozenLedger.ledger.ref (owner s) ≤ (fixed s.val (owner s).val:ℝ) ∧
    p1 s.val * FrozenLedger.ledger.ref (owner s) ≤ (inverse (owner s).val:ℝ) := by
  obtain ⟨lo,hi⟩ := sound s pass
  have castLo : (((((Detection.archivedPrice s.val).1:ℚ)/unit)*ref (owner s).val:ℚ):ℝ) ≤
      ((fixed s.val (owner s).val:ℚ):ℝ) := by exact_mod_cast lo
  have castHi : (((((Detection.archivedPrice s.val).2:ℚ)/unit)*ref (owner s).val:ℚ):ℝ) ≤
      ((inverse (owner s).val:ℚ):ℝ) := by exact_mod_cast hi
  push_cast at castLo castHi
  simp only [ref_cast,unit_cast] at castLo castHi
  exact ⟨castLo,castHi⟩

end PrimeGap180.PriceScalar
