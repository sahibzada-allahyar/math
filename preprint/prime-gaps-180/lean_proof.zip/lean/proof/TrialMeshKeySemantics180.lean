import TrialFrozenData180
import TrialRunAlignment180

noncomputable section
open scoped Classical
open PrimeGap180 PrimeGap180.FrozenProfile PrimeGap180.Sector
open PrimeGap180.FrozenData.FiniteInput PrimeGap180.RunAlignment
namespace PrimeGap180.FrozenMesh

private def capBounds : Array ℕ := #[208489,416998,625487,833996,962305,963971,978554,980476,984341,984362,994291,994334,1005630,1010349,1042485,1204958,1221976,1225606,1242539,1242624,1245549,1245592,1250994,1259984,1261436,1262610,1265963,1276981,1282959,1283066,1287999,1293999,1304739,1306704,1308369,1328398,1349003,1358996,1364997,1379367,1399375,1419980,1459482,1667992]
private def capN (c : Fine) : ℕ := capBounds[c.val]!
private def capExact (c : Fine) : Prop :=
  let q := (2624990:ℚ)*FrozenData.meshQ (FrozenData.tables.capEdge c).castSucc
  0 < capN c ∧ ((capN c-1:ℕ):ℚ) < q ∧ q ≤ (capN c:ℚ)
private noncomputable instance (c) : Decidable (capExact c) := by unfold capExact; infer_instance

private def tagged (c : Fine) (r : Array ℕ) : Span where
  start := field r 4
  stop := field r 4+(field r 3-field r 2)
  cap := capN c
  radius := min 2798706 (field r 1)

private def spans := (List.finRange 44).flatMap (fun c => (owners c).toList.map (tagged c))
private def last (r : Array ℕ) := field r 0
private def fits (a : Span) (r : Array ℕ) :=
  decide (field r 1 ≤ a.cap ∧ field r 2 ≤ a.radius)

/-- Three finite judgments on the literal archive suffice for every receipt. -/
structure FiniteCertificate : Prop where
  ceilings : ∀ c : Fine, capExact c
  ownerOrder : ordered 0 spans = true
  gateAlignment : aligned last fits 8192 spans gates.toList = true

private theorem cap_eq (data : FiniteCertificate) (c : Fine) :
    ⌈Lookup.ticks * FrozenData.mesh (FrozenData.tables.capEdge c).castSucc⌉₊ = capN c := by
  obtain ⟨pos,low,hi⟩ := data.ceilings c
  apply (Nat.ceil_eq_iff pos.ne').mpr
  rw [FrozenData.mesh_eq_rat]
  change ((capN c - 1 : ℕ) : ℝ) < 2624990 * _ ∧ 2624990 * _ ≤ (capN c:ℝ)
  exact ⟨by exact_mod_cast low,by exact_mod_cast hi⟩

private theorem truncated (x y : ℕ) : ((x-y:ℕ):ℝ) ≤ max 0 ((x:ℝ)-(y:ℝ)) := by
  by_cases h : y ≤ x
  · rw [Nat.cast_sub h]
    exact le_max_right _ _
  · rw [Nat.sub_eq_zero_of_le (Nat.le_of_not_ge h),Nat.cast_zero]
    exact le_max_left _ _

private theorem gate_bound (z R l u c r : ℕ) (one : 1 ≤ c) (cz : z ≤ c) (cr : R ≤ r) :
    ((max (max 1 z) (max (l-u) (R-2*u)) : ℕ) : ℝ) ≤
    max (c:ℝ) (max ((r:ℝ)-2*(u:ℝ)) ((l:ℝ)-(u:ℝ))) := by
  let upper := max (c:ℝ) (max ((r:ℝ)-2*(u:ℝ)) ((l:ℝ)-(u:ℝ)))
  have cap : (c:ℝ) ≤ upper := le_max_left _ _
  have nn : (0:ℝ) ≤ upper := (Nat.cast_nonneg c).trans cap
  have cut : (l:ℝ)-u ≤ upper := (le_max_right _ _).trans (le_max_right _ _)
  have rad : (r:ℝ)-2*(u:ℝ) ≤ upper := (le_max_left _ _).trans (le_max_right _ _)
  have lim : ((l-u:ℕ):ℝ) ≤ upper := (truncated l u).trans (max_le nn cut)
  have rho : ((R-2*u:ℕ):ℝ) ≤ upper := by
    apply (truncated R (2*u)).trans
    apply max_le nn
    push_cast
    exact (sub_le_sub_right (Nat.cast_le.mpr cr) _).trans rad
  change _ ≤ upper
  push_cast
  exact max_le (max_le ((by exact_mod_cast one : (1:ℝ) ≤ c).trans cap) ((Nat.cast_le.mpr cz).trans cap))
    (max_le lim rho)

theorem enclosed_key (data : FiniteCertificate) (a : Receipt) (occ : FrozenData.tables.key a.fine (FrozenData.tables.group a.sector) a.bucket = some a.key) :
    (trialKey FrozenData.tables a (FrozenData.plateau a.key)).enclosed FrozenData.mesh
      (trialMesh FrozenData.tables FrozenData.parentUpper) := by
  obtain ⟨owner,inRows,lo,hi,rad⟩ := key_owner occ
  have inSpans : tagged a.fine owner ∈ spans := by
    apply List.mem_flatMap.mpr
    exact ⟨a.fine,by simp,List.mem_map.mpr ⟨owner,inRows,rfl⟩⟩
  have sel := find_owner data.ownerOrder inSpans lo hi
  obtain ⟨row,found,valid⟩ := aligned_at last fits data.gateAlignment sel
  have pass : field row 1 ≤ (tagged a.fine owner).cap ∧ field row 2 ≤ (tagged a.fine owner).radius :=
    of_decide_eq_true valid
  obtain ⟨plateau,formula⟩ := gate_row a.key row found
  constructor
  · exact Nat.cast_nonneg _
  constructor
  · exact Nat.le_ceil _
  · intro e
    change (FrozenData.tables.gate a.key e : ℝ) ≤
      max (⌈Lookup.ticks * FrozenData.mesh (FrozenData.tables.capEdge a.fine).castSucc⌉₊ : ℝ)
        (max ((FrozenData.tables.upper a.fine (FrozenData.tables.group a.sector) : ℝ) - 2*FrozenData.parentUpper e)
          (FrozenData.plateau a.key-FrozenData.parentUpper e))
    rw [formula e,cap_eq data,rad,plateau,FrozenData.parentUpper_nat]
    exact gate_bound _ _ _ _ _ _ (data.ceilings a.fine).1 pass.1 pass.2

#print axioms enclosed_key
end PrimeGap180.FrozenMesh
