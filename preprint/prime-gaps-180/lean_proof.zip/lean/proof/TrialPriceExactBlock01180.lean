import TrialPriceScalar180
namespace PrimeGap180.PriceExactCensus
set_option maxHeartbeats 100000000
set_option maxRecDepth 65536
private theorem c32 : PriceScalar.checked (32 : Book.Label) = true := by decide +kernel
private theorem c33 : PriceScalar.checked (33 : Book.Label) = true := by decide +kernel
private theorem c34 : PriceScalar.checked (34 : Book.Label) = true := by decide +kernel
private theorem c35 : PriceScalar.checked (35 : Book.Label) = true := by decide +kernel
private theorem c36 : PriceScalar.checked (36 : Book.Label) = true := by decide +kernel
private theorem c37 : PriceScalar.checked (37 : Book.Label) = true := by decide +kernel
private theorem c38 : PriceScalar.checked (38 : Book.Label) = true := by decide +kernel
private theorem c39 : PriceScalar.checked (39 : Book.Label) = true := by decide +kernel
private theorem c40 : PriceScalar.checked (40 : Book.Label) = true := by decide +kernel
private theorem c41 : PriceScalar.checked (41 : Book.Label) = true := by decide +kernel
private theorem c42 : PriceScalar.checked (42 : Book.Label) = true := by decide +kernel
private theorem c43 : PriceScalar.checked (43 : Book.Label) = true := by decide +kernel
private theorem c44 : PriceScalar.checked (44 : Book.Label) = true := by decide +kernel
private theorem c45 : PriceScalar.checked (45 : Book.Label) = true := by decide +kernel
private theorem c46 : PriceScalar.checked (46 : Book.Label) = true := by decide +kernel
private theorem c47 : PriceScalar.checked (47 : Book.Label) = true := by decide +kernel
private theorem c48 : PriceScalar.checked (48 : Book.Label) = true := by decide +kernel
private theorem c49 : PriceScalar.checked (49 : Book.Label) = true := by decide +kernel
private theorem c50 : PriceScalar.checked (50 : Book.Label) = true := by decide +kernel
private theorem c51 : PriceScalar.checked (51 : Book.Label) = true := by decide +kernel
private theorem c52 : PriceScalar.checked (52 : Book.Label) = true := by decide +kernel
private theorem c53 : PriceScalar.checked (53 : Book.Label) = true := by decide +kernel
private theorem c54 : PriceScalar.checked (54 : Book.Label) = true := by decide +kernel
private theorem c55 : PriceScalar.checked (55 : Book.Label) = true := by decide +kernel
private theorem c56 : PriceScalar.checked (56 : Book.Label) = true := by decide +kernel
private theorem c57 : PriceScalar.checked (57 : Book.Label) = true := by decide +kernel
private theorem c58 : PriceScalar.checked (58 : Book.Label) = true := by decide +kernel
private theorem c59 : PriceScalar.checked (59 : Book.Label) = true := by decide +kernel
private theorem c60 : PriceScalar.checked (60 : Book.Label) = true := by decide +kernel
private theorem c61 : PriceScalar.checked (61 : Book.Label) = true := by decide +kernel
private theorem c62 : PriceScalar.checked (62 : Book.Label) = true := by decide +kernel
private theorem c63 : PriceScalar.checked (63 : Book.Label) = true := by decide +kernel
theorem block1 : ∀ i : Fin 32, PriceScalar.checked ⟨32+i.val,by omega⟩ = true :=
  Fin.cases c32 (Fin.cases c33 (Fin.cases c34 (Fin.cases c35 (Fin.cases c36 (Fin.cases c37 (Fin.cases c38 (Fin.cases c39 (Fin.cases c40 (Fin.cases c41 (Fin.cases c42 (Fin.cases c43 (Fin.cases c44 (Fin.cases c45 (Fin.cases c46 (Fin.cases c47 (Fin.cases c48 (Fin.cases c49 (Fin.cases c50 (Fin.cases c51 (Fin.cases c52 (Fin.cases c53 (Fin.cases c54 (Fin.cases c55 (Fin.cases c56 (Fin.cases c57 (Fin.cases c58 (Fin.cases c59 (Fin.cases c60 (Fin.cases c61 (Fin.cases c62 (Fin.cases c63 (fun i => Fin.elim0 i))))))))))))))))))))))))))))))))
#print axioms block1
end PrimeGap180.PriceExactCensus
