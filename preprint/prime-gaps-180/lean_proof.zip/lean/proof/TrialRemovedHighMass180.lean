import TrialRemovedHighTags180

/-! A high-edge deletion is dominated by the square of the original trial
restricted to exactly two atoms of the complete 39-site physical Poisson law. -/
noncomputable section
open scoped Classical BigOperators ENNReal
open MeasureTheory PrimeGap186 PrimeGap180.Sector PrimeGap180.FrozenProfile
open PrimeGap180.GateDeletion PrimeGap180.RemovedHighTags
namespace PrimeGap180.RemovedHighMass

abbrev Config := Fin 39→FiniteMeasure ℝ
def bands (X : Config) : Full := fun i=>fragmentBandMasses FrozenData.mesh (X i)
def law := Measure.pi (fun _ : Fin 39=>NativeSiteLaw.phys cap)
def two : Set Config := {X | physicalSourceCountMeasure X (Set.Ioi cutoff)=2}

def charged : Set Config := two ∩ {X | 102994≤Native.cellSum (bands X)}

private theorem meas_bands : Measurable bands := measurable_pi_lambda _ fun i=>
  (measurable_fragmentBandMasses FrozenData.mesh).comp (measurable_pi_apply i)

private theorem meas_two : MeasurableSet two := measurableSet_eq_fun
  ((Measure.measurable_coe measurableSet_Ioi).comp (physicalSourceCountMeasure_regular 39).1) measurable_const

private theorem meas_charged : MeasurableSet charged := by
  have mi : Measurable (fun v : Full=>Native.cellSum v) := by unfold Native.cellSum Native.cell; fun_prop
  exact meas_two.inter (measurableSet_le measurable_const (mi.comp meas_bands))

open private band_map from TrialNativeSiteLaw180
open private layer_regular from TrialGateDeletion180

private theorem band_push : Measure.map bands law=μ := by
  let := fragmentLaw_isProbabilityMeasure cap
  letI : IsFiniteMeasure (NativeSiteLaw.phys cap) := (fragmentLaw cap).smul_finite (by simp)
  change (Measure.pi (fun _ : Fin 39=>NativeSiteLaw.phys cap)).map
    (fun X i=>fragmentBandMasses FrozenData.mesh (X i)) = Measure.pi (fun _ : Fin 39=>bandLaw FrozenData.mesh)
  rw [Measure.pi_map_pi (f:=fun _ : Fin 39=>fragmentBandMasses FrozenData.mesh)
    (fun _=>(measurable_fragmentBandMasses FrozenData.mesh).aemeasurable)]
  simp only [band_map]

private def base := Measure.pi (fun _ : Fin 39=>fragmentLaw cap)

private theorem scaled : law=(ENNReal.ofReal (Real.exp Real.eulerMascheroniConstant*cap))^39 • base := by
  let := fragmentLaw_isProbabilityMeasure cap
  letI : IsFiniteMeasure (NativeSiteLaw.phys cap) := (fragmentLaw cap).smul_finite (by simp)
  unfold law
  apply Measure.pi_eq
  intro s _
  rw [Measure.smul_apply,base,Measure.pi_pi]
  simp [NativeSiteLaw.phys,Measure.smul_apply,Finset.prod_mul_distrib]

private theorem counted (Y : Fin 39 → FiniteMeasure ℝ) (n : Fin 39→ℕ)
    (x : (i : Fin 39)→Fin (n i)→ℝ) (hY : ∀ i,(Y i).restrict (Set.Ioc 0 cutoff)=Y i)
    (hx : ∀ i a,cutoff<x i a ∧ x i a≤cap) :
    physicalSourceCountMeasure (fun i=>Y i + weightedEmpirical _ (x i)) (Set.Ioi cutoff) =
      ((∑ i,n i : ℕ):ℝ≥0∞) := by
  have pos : 0<cutoff := by norm_num [cutoff,Lookup.ticks]
  have h := (trial_finite_tail_mass_and_count 39 cutoff pos Y n x hY fun i a=>(hx i a).1).2
  rw [←Measure.restrict_eq_self _ (Set.Subset.rfl : Set.Ioi cutoff ⊆ Set.Ioi cutoff),h,Measure.finsetSum_apply]
  have atom (a : (i : Fin 39) × Fin (n i)) : Measure.dirac (x a.1 a.2) (Set.Ioi cutoff)=1 :=
    Measure.dirac_apply_of_mem (hx a.1 a.2).1
  simp only [atom,Finset.sum_const,Finset.card_univ,nsmul_eq_mul,mul_one,Fintype.card_sigma,
    Fintype.card_fin,Nat.cast_sum]

theorem high_ae : ∀ᵐ X ∂law, layer (.group 23) (bands X)=0 ∨ X∈charged := by
  rw [scaled]
  apply Measure.ae_smul_measure
  apply fragmentLaw_ae_finite_tail_elim cap cutoff (by norm_num [cap,physicalCap,rho])
    (by norm_num [cutoff,Lookup.ticks]) 39
  · exact (measurableSet_eq_fun ((layer_regular _).1.comp meas_bands) measurable_const).union meas_charged
  · intro Y n x hY hx
    by_cases on : owner (encode (state Y n x))=some (.group 23)
    · by_cases nz : original (state Y n x)=0
      · exact Or.inl (by change layer _ (state Y n x)=0; simp [layer,on,nz])
      · right
        refine ⟨?_,?_⟩
        · change physicalSourceCountMeasure _ (Set.Ioi cutoff)=2
          rw [counted Y n x hY hx,two_tags Y n x hY hx nz on]
          norm_num
        · obtain ⟨e,⟨i,r,sel,bad,_⟩,_,_⟩ := group_highest _ _ on
          exact (EarlyFailure.support (state Y n x) (fun _ _=>NNReal.zero_le_coe) nz i e r sel bad).1
    · exact Or.inl (by change layer _ (state Y n x)=0; exact ite_eq_right on)

theorem mass_high : StructuralRun.layerMass 23 ≤ ∫ X in charged, (Restoration.original (bands X))^2 ∂law := by
  letI := fragmentLaw_isProbabilityMeasure cap
  letI : IsFiniteMeasure (NativeSiteLaw.phys cap) := (fragmentLaw cap).smul_finite (by simp)
  letI : IsFiniteMeasure law := by unfold law; infer_instance
  have reg := coded_regular T (fun p=>(originalValue p.1)^2)
  have m : Measurable (fun X=>(Restoration.original (bands X))^2) := reg.1.comp meas_bands
  have bounded : Bornology.IsBounded (Set.range (fun X=>(Restoration.original (bands X))^2)) :=
    reg.2.1.subset (by rintro val ⟨X,rfl⟩; exact ⟨bands X,rfl⟩)
  have intSq := integrable_of_measurable_of_bounded_range law _ m bounded
  change (∫ v,(layer (.group 23) v)^2 ∂μ)≤_
  rw [←band_push,integral_map meas_bands.aemeasurable (((layer_regular _).1.pow_const 2).aestronglyMeasurable),
    ←integral_indicator meas_charged]
  apply integral_mono_of_nonneg (Filter.Eventually.of_forall fun _=>sq_nonneg _) (intSq.indicator meas_charged)
  filter_upwards [high_ae] with X hx
  rcases hx with off|on
  · rw [off,zero_pow (by decide)]
    by_cases mem : X∈charged
    · rw [Set.indicator_of_mem mem]; exact sq_nonneg _
    · rw [Set.indicator_of_notMem mem]
  · rw [Set.indicator_of_mem on]
    unfold layer
    split
    · exact le_rfl
    · rw [zero_pow (by decide)]; exact sq_nonneg _

#print axioms high_ae
#print axioms mass_high
end PrimeGap180.RemovedHighMass
