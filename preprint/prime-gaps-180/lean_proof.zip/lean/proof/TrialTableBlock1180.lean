import TrialTableRow05180
import TrialTableRow06180
import TrialTableRow07180
import TrialTableRow08180
import TrialTableRow09180
namespace PrimeGap180.TablePrices
theorem block1 (i : Fin 5) : certified (blockIndex 1 i) := by
  fin_cases i
  · exact row05
  · exact row06
  · exact row07
  · exact row08
  · exact row09
#print axioms block1
end PrimeGap180.TablePrices
