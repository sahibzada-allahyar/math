import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G080
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 80

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G080

namespace PrimeGap180.PriceIsolatedGroup.G085
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 85

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G085

namespace PrimeGap180.PriceIsolatedGroup.G090
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 90

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G090

namespace PrimeGap180.PriceIsolatedGroup.G095
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 95

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G095
