import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G365
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 365

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G365

namespace PrimeGap180.PriceIsolatedGroup.G370
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 370

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G370

namespace PrimeGap180.PriceIsolatedGroup.G375
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 375

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G375

namespace PrimeGap180.PriceIsolatedGroup.G380
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 380

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G380
