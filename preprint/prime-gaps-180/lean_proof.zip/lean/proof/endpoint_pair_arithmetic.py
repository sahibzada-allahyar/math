"""Directed, truncated polynomial products using carry-free GMP integers."""

import ctypes
import ctypes.util
from dataclasses import dataclass

FRACTION_BITS = 256
COUNT = 130965
DENOMINATOR = 1 << FRACTION_BITS


@dataclass
class Interval:
    low: list
    high: list


class MPZ(ctypes.Structure):
    _fields_ = [
        ("alloc", ctypes.c_int),
        ("size", ctypes.c_int),
        ("limbs", ctypes.POINTER(ctypes.c_ulong)),
    ]


def gmp_library():
    name = ctypes.util.find_library("gmp")
    if not name or ctypes.sizeof(ctypes.c_ulong) != 8:
        raise RuntimeError("This checker requires a 64-bit GMP installation.")
    lib = ctypes.CDLL(name)
    ptr = ctypes.POINTER(MPZ)
    signatures = {
        "init": [ptr],
        "clear": [ptr],
        "import": [ptr, ctypes.c_size_t, ctypes.c_int, ctypes.c_size_t,
                   ctypes.c_int, ctypes.c_size_t, ctypes.c_void_p],
        "export": [ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.c_int,
                   ctypes.c_size_t, ctypes.c_int, ctypes.c_size_t, ptr],
        "mul": [ptr, ptr, ptr],
        "fdiv_r_2exp": [ptr, ptr, ctypes.c_ulong],
    }
    ops = {}
    for name, signature in signatures.items():
        function = getattr(lib, "__gmpz_" + name)
        function.argtypes = signature
        function.restype = None
        ops[name] = function
    return ops


GMP = gmp_library()


def encode(values, width):
    return b"".join(value.to_bytes(width, "little") for value in values)


def decode(data, width):
    return [int.from_bytes(data[i:i + width], "little") for i in range(0, len(data), width)]


def rounded_product(left, right, upward):
    """Compute floor or ceiling of each coefficient divided by 2^256."""
    length = min(COUNT, len(left) + len(right) - 1)
    norm = sum(left) * sum(right)
    if norm == 0:
        return [0] * length
    width = 8 * ((norm.bit_length() + 63) // 64)
    if norm >= 1 << (8 * width):
        raise ArithmeticError("The input coefficient sums exceed the lane capacity.")
    a, b, result = MPZ(), MPZ(), MPZ()
    for z in (a, b, result):
        GMP["init"](ctypes.byref(z))
    try:
        packed = encode(left, width)
        GMP["import"](ctypes.byref(a), len(packed), -1, 1, -1, 0, packed)
        if left is right:
            GMP["mul"](ctypes.byref(result), ctypes.byref(a), ctypes.byref(a))
        else:
            packed = encode(right, width)
            GMP["import"](ctypes.byref(b), len(packed), -1, 1, -1, 0, packed)
            GMP["mul"](ctypes.byref(result), ctypes.byref(a), ctypes.byref(b))
        GMP["fdiv_r_2exp"](ctypes.byref(result), ctypes.byref(result), 8 * width * length)
        output = ctypes.create_string_buffer(width * length)
        used = ctypes.c_size_t()
        GMP["export"](output, ctypes.byref(used), -1, 1, -1, 0, ctypes.byref(result))
        if used.value > len(output):
            raise ArithmeticError("Packed product escaped the retained degrees.")
        increment = DENOMINATOR - 1 if upward else 0
        return [(x + increment) >> FRACTION_BITS for x in decode(output.raw, width)]
    finally:
        for z in (a, b, result):
            GMP["clear"](ctypes.byref(z))


def multiply(a, b):
    return Interval(rounded_product(a.low, b.low, False), rounded_product(a.high, b.high, True))


def correlate(radial, kernel):
    """Keep the signed radial scale and remove the positive kernel's 256 fractional bits."""
    def parts(values):
        return [max(x, 0) for x in reversed(values)], [max(-x, 0) for x in reversed(values)]

    positive, negative = parts(radial.low)
    lower = rounded_product(positive, kernel.low, False)
    correction = rounded_product(negative, kernel.high, True)
    low = [x - y for x, y in zip(reversed(lower), reversed(correction), strict=True)]
    positive, negative = parts(radial.high)
    upper = rounded_product(positive, kernel.high, True)
    correction = rounded_product(negative, kernel.low, False)
    high = [x - y for x, y in zip(reversed(upper), reversed(correction), strict=True)]
    return Interval(low, high)


def audit():
    scale = DENOMINATOR
    a = Interval([2 * scale + 1, 3 * scale + 2, scale],
                 [2 * scale + 2, 3 * scale + 3, scale + 1])
    b = Interval([5 * scale + 1, 3 * scale], [5 * scale + 2, 3 * scale + 1])
    result = multiply(a, b)
    for left, right, actual, increment in [
        (a.low, b.low, result.low, 0), (a.high, b.high, result.high, scale - 1)
    ]:
        for k, value in enumerate(actual):
            exact = sum(x * right[k - i] for i, x in enumerate(left) if 0 <= k - i < len(right))
            if value != (exact + increment) // scale:
                raise ArithmeticError("GMP packing disagrees with direct integer multiplication.")
