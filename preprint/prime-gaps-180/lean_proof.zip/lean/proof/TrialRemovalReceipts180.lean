import TrialStructuralRuns180

/-! The two exterior relative-mass endpoints and the 22 absolute scaled
middle-mass endpoints used in the restoration budget. -/
noncomputable section
open scoped Classical BigOperators
open MeasureTheory PrimeGap180.Sector
namespace PrimeGap180.RemovalReceipts

def low : ℚ := 3303228195853457002671/905631431450000000000000000
def high : ℚ := 1947250500129/452815715725000000
def middle : Fin 22 → ℚ := ![
  4349604360037/100000000000000000,
  696219572663/10000000000000000,
  50884791834039/500000000000000000,
  163448849131761/1000000000000000000,
  30560461315951/125000000000000000,
  264261063281913/1000000000000000000,
  374173727193533/1000000000000000000,
  395251168045263/1000000000000000000,
  312421158140457/1000000000000000000,
  227090049432491/500000000000000000,
  328882423670591/500000000000000000,
  653378923866723/1000000000000000000,
  764835800547357/1000000000000000000,
  1236280766420807/1000000000000000000,
  757348544819277/500000000000000000,
  2399167222635017/1000000000000000000,
  2854013579413019/1000000000000000000,
  13980607713781/12500000000000000,
  507042011041849/1000000000000000000,
  175147134666381/1000000000000000000,
  17714655652921/250000000000000000,
  3981355002443/500000000000000000]

def relative (g : Fin 24) : ℚ :=
  if g.val=0 then low else if h : g.val≤22 then middle ⟨g.val-1,by omega⟩ / 94.17312 else high

set_option maxRecDepth 8192 in
theorem total : (∑ g,relative g) = 1338209182539911284283583223/8328724362276623437500000000000 := by
  decide +kernel

/-- The outer estimates are relative to the original mass. The middle
worker uses absolute mass in 100^39 units, normalized by the certified floor. -/
theorem removed (floor : (94.17312:ℝ)≤100^39*NumericalAccount.mass Restoration.original)
    (lo : StructuralRun.layerMass 0 ≤ (low:ℝ)*NumericalAccount.mass Restoration.original)
    (mid : ∀ k : Fin 22, 100^39*StructuralRun.layerMass ⟨k.val+1,by omega⟩ ≤ (middle k:ℝ))
    (hi : StructuralRun.layerMass 23 ≤ (high:ℝ)*NumericalAccount.mass Restoration.original) :
    NumericalAccount.mass Restoration.deleted ≤ 0.000160674*NumericalAccount.mass Restoration.original := by
  have pos : (0:ℝ)≤NumericalAccount.mass Restoration.original := integral_nonneg fun _=>sq_nonneg _
  have each (g : Fin 24) : StructuralRun.layerMass g ≤ (relative g:ℝ)*NumericalAccount.mass Restoration.original := by
    by_cases z : g.val=0
    · have eq : g=0 := Fin.ext z
      subst g
      exact lo
    by_cases small : g.val≤22
    · let k : Fin 22 := ⟨g.val-1,by omega⟩
      have eq : (⟨k.val+1,by omega⟩ : Fin 24)=g := Fin.ext (by dsimp [k]; omega)
      have other := mid k
      rw [eq] at other
      have nn : (0:ℝ)≤ middle k := by
        have nnQ : ∀ j : Fin 22, 0≤ middle j := by decide +kernel
        exact_mod_cast nnQ k
      simp only [relative, z, small, dite_true, ite_false, Rat.cast_div, Rat.cast_ofScientific]
      change StructuralRun.layerMass g ≤ ((middle k:ℝ)/94.17312)*NumericalAccount.mass Restoration.original
      calc
        _ ≤ (middle k:ℝ)/100^39 := (le_div_iff₀ (by norm_num)).mpr (by simpa only [mul_comm] using other)
        _ ≤ _ := by
          apply (div_le_iff₀ (by norm_num : (0:ℝ)<100^39)).mpr
          calc
            (middle k:ℝ) = ((middle k:ℝ)/94.17312)*94.17312 := by ring
            _ ≤ ((middle k:ℝ)/94.17312)*(100^39*NumericalAccount.mass Restoration.original) :=
              mul_le_mul_of_nonneg_left floor (div_nonneg nn (by norm_num))
            _ = _ := by ring
    · have eq : g=23 := Fin.ext (by have:=g.isLt; omega)
      subst g
      exact hi
  have sum := Finset.sum_le_sum (s:=Finset.univ) (fun g _=>each g)
  rw [←Finset.sum_mul,←Rat.cast_sum,total] at sum
  rw [StructuralRun.deleted_mass]
  exact sum.trans (mul_le_mul_of_nonneg_right (by norm_num) pos)

#print axioms total
#print axioms removed
end PrimeGap180.RemovalReceipts
