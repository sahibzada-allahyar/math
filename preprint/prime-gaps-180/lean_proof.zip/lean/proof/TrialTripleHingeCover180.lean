import TrialTripleHingeMass180
import TrialMarkEligibility180

/-! Positive-support bins for the triple hinge, including intervals meeting
at a marked prime. Each bin carries the same pointwise prime weight. -/
noncomputable section
open scoped Classical BigOperators Topology
open Filter PrimeGap186
namespace PrimeGap180.EventBins

theorem hinge_nonneg {b : ℝ} (hb : 1+pad < 3*b) (t : ℝ) : 0 ≤ hinge b t :=
  div_nonneg (mul_nonneg (by norm_num) (le_max_left _ _)) (by linarith)

theorem mem_primeMarks {x l r : ℝ} (hx : 1 < x) {p : ℕ} :
    p ∈ primeMarks x l r ↔ p.Prime ∧ l < Real.logb x p ∧ Real.logb x p ≤ r := by
  constructor
  · intro h
    exact ⟨(Nat.mem_primesLE.mp (Finset.mem_filter.mp h).1).2,primeMarks_bounds hx h⟩
  · rintro ⟨hp,lo,hi⟩
    have pos : (0:ℝ) < p := Nat.cast_pos.mpr hp.pos
    exact Finset.mem_filter.mpr ⟨Nat.mem_primesLE.mpr ⟨(Nat.le_floor_iff (by positivity)).mpr
      ((Real.logb_le_iff_le_rpow hx pos).mp hi),hp⟩,(Real.lt_logb_iff_rpow_lt hx pos).mp lo⟩

theorem triple_hinge_bins {T : Type*} [Fintype T] (L U : T → ℝ) {x lo hi b : ℝ}
    (hx : 1 < x) (hb : 1+pad < 3*b)
    (covered : ∀ t, lo < t → t < b → ∃ j, L j < t ∧ t ≤ U j)
    {n : ℕ} (size : (n:ℝ) ≤ x^(1+pad)) (e : Literal.Three (x^lo) (x^hi) n) :
    2 ≤ ∑ j, ∑ p ∈ primeMarks x (L j) (U j),
      if p ∣ n then hinge b (Real.logb x p) else 0 := by
  classical
  let S := n.primeFactors.filter (fun p : ℕ => x^lo < (p:ℝ) ∧ (p:ℝ) < x^hi)
  let w := fun p : ℕ => hinge b (Real.logb x p)
  let B := fun j => primeMarks x (L j) (U j)
  have nn (p : ℕ) : 0 ≤ w p := hinge_nonneg hb _
  calc
    2 ≤ ∑ p ∈ S, w p := triple_hinge hx size hb e
    _ ≤ ∑ p ∈ S, ∑ j, if p ∈ B j then w p else 0 := by
      apply Finset.sum_le_sum
      intro p mem
      obtain ⟨prime,mlo,_⟩ := Finset.mem_filter.mp mem
      have pp := Nat.prime_of_mem_primeFactors prime
      by_cases active : Real.logb x p < b
      · obtain ⟨j, inside⟩ := covered _ ((Real.lt_logb_iff_rpow_lt hx (Nat.cast_pos.mpr pp.pos)).mpr mlo) active
        have h := (mem_primeMarks hx).mpr ⟨pp,inside⟩
        exact (show w p ≤ (if p ∈ B j then w p else 0) by rw [ite_eq_left h]).trans
          (Finset.single_le_sum (f := fun j => if p ∈ B j then w p else 0) (fun j _ => ite_nonneg (nn p) le_rfl) (Finset.mem_univ j))
      · have zero : w p = 0 := by simp [w,hinge,max_eq_left (sub_nonpos.mpr (le_of_not_gt active))]
        simp [zero]
    _ = ∑ j, ∑ p ∈ S, if p ∈ B j then w p else 0 := Finset.sum_comm
    _ ≤ _ := by
      apply Finset.sum_le_sum
      intro j _
      have sub : S.filter (fun p => p ∈ B j) ⊆ (B j).filter (fun p => p ∣ n) := by
        intro p hp
        obtain ⟨s,bb⟩ := Finset.mem_filter.mp hp
        exact Finset.mem_filter.mpr ⟨bb,Nat.dvd_of_mem_primeFactors (Finset.mem_filter.mp s).1⟩
      simpa only [Finset.sum_filter] using
        (Finset.sum_le_sum_of_subset_of_nonneg (f := w) sub (fun p _ _ => nn p))

theorem hinge_marks_eligible (H : Finset ℕ) {κ ξ l r d b : ℝ}
    (hξ : 0 < ξ) (ξl : ξ ≤ l) (lr : l ≤ r) (r1 : r ≤ 1)
    (cap : Marked.rho*κ < ξ) (hd : 0 < d) (hb : 1+pad < 3*b) :
    ∃ K : ℝ, 0 ≤ K ∧ ∀ᶠ x : ℝ in atTop, let W := presievingModulus H x
      (∀ p ∈ primeMarks x l r, 0 < p ∧ W.Coprime p ∧ (Marked.carrier W x κ).Coprime p ∧
        0 ≤ hinge b (Real.logb x p)) ∧
      (∑ p ∈ primeMarks x l r, hinge b (Real.logb x p)) ≤ x^(r+d) ∧
      Marked.mass (primeMarks x l r) (fun p => hinge b (Real.logb x p)) ≤ K := by
  have nonneg : 0 ≤ hinge b l := hinge_nonneg hb l
  obtain ⟨K,hK,eligible⟩ := Marked.eligible_subsets H (s := r) hξ ((ξl.trans lr).trans r1) cap hd nonneg
  refine ⟨K,hK,?_⟩
  filter_upwards [eligible,eventually_gt_atTop (1:ℝ)] with x he hx
  apply he
  · intro p hp
    obtain ⟨prime,low,hi⟩ := (mem_primeMarks hx).mp hp
    have pos : (0:ℝ) < p := Nat.cast_pos.mpr prime.pos
    have p1 : (p:ℝ) ≤ x := by simpa using (Real.logb_le_iff_le_rpow hx pos).mp (hi.trans r1)
    have mem : p ∈ Marked.primeBand x ξ := Finset.mem_filter.mpr
      ⟨Nat.mem_primesLE.mpr ⟨(Nat.le_floor_iff (by linarith)).mpr p1, prime⟩,
       (Real.le_logb_iff_rpow_le hx pos).mp (ξl.trans low.le)⟩
    exact Finset.mem_union_left _ (Finset.mem_union_right _ mem)
  · intro p hp
    obtain ⟨prime,low,high⟩ := (mem_primeMarks hx).mp hp
    refine ⟨(Real.logb_le_iff_le_rpow hx (Nat.cast_pos.mpr prime.pos)).mp high, hinge_nonneg hb _, ?_⟩
    unfold hinge
    exact div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left (max_le_max_left _ (sub_le_sub_left low.le _)) (by norm_num)) (by linarith)

#print axioms triple_hinge_bins
#print axioms hinge_marks_eligible
end PrimeGap180.EventBins
