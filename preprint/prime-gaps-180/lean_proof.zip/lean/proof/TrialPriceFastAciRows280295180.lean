import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G280
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 280

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G280

namespace PrimeGap180.PriceIsolatedGroup.G285
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 285

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G285

namespace PrimeGap180.PriceIsolatedGroup.G290
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 290

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G290

namespace PrimeGap180.PriceIsolatedGroup.G295
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 295

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G295
