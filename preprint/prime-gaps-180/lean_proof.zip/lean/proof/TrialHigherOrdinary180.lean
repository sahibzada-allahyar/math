import TrialLiteralBoxCuts180

/-! Ordinary Bombieri--Vinogradov distribution for the actual shifted higher
minorants. Both exceptional sets are counted once per integer and carry their
literal signed coefficients. -/
noncomputable section
open scoped BigOperators Classical Topology
open Filter PrimeGap186 PrimeGap180.Ordinary PrimeGap180.Signed
namespace PrimeGap180.Distribution

private def weightedSum (S : Finset ℕ) (f : ℕ → ℂ) := ∑ n ∈ S, Finsupp.single n (f n)

private theorem scale_discrepancy (S : Finset ℕ) (f : ℕ → ℂ) (k : ℂ) (q b : ℕ) :
    fullDiscrepancy (weightedSum S (fun n => k*f n)) q b =
      k * fullDiscrepancy (weightedSum S f) q b := by
  simp only [weightedSum,fullDiscrepancy_sample,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro n _
  split_ifs <;> ring

theorem higher_ordinary {θ a c : ℝ} (hθ0 : 0 < θ) (hθ : θ < 1/2)
    (ha : a ≤ 417/1000) (hc : 4/25 ≤ c) (h : ℕ) :
    RowBound (fun x => .higher (x^a) (x^c)) (ordinary θ) h := by
  classical
  apply row_shift (θ := θ) _ h (by linarith)
    (Eventually.of_forall fun x I => Finset.filter_subset _ _)
  intro A hA
  obtain ⟨P,hP,pbd⟩ := prime_ordinary hθ0 hθ 0 A hA
  obtain ⟨F,hF,fbd⟩ := five_ordinary_event θ hθ0 hθ A hA
  obtain ⟨T,hT,tbd⟩ := three_ordinary_event θ hθ0 hθ A hA
  refine ⟨P+24*F+2*T,by positivity,?_⟩
  filter_upwards [pbd,fbd,tbd] with x pbd fbd tbd
  intro I Q b hp hb sub
  have hQ := sub.trans (Finset.filter_subset _ _)
  have cop (q : ℕ) (hq : q ∈ Q) := hb.of_dvd_right (Finset.mem_filter.mp (sub hq)).2
  have Bp := pbd I Q b hp hb sub
  have Bf := fbd a ha Q hQ (fun _ => b) cop
  have Bt := tbd a c hc (by linarith) Q hQ (fun _ => b) cop
  let p : ℕ → ℂ := fun n => if n.Prime then 1 else 0
  let f : ℕ → ℂ := fun n => if Literal.Five (x^a) n then 1 else 0
  let t : ℕ → ℂ := fun n => if Literal.Three (x^c) (x^a) n then 1 else 0
  let disc := fun (w : ℕ → ℂ) q => fullDiscrepancy (weightedSum (window x) w) q b
  change ∑ q ∈ Q, ‖disc f q‖ ≤ _ at Bf
  change ∑ q ∈ Q, ‖disc t q‖ ≤ _ at Bt
  have ep : sample (window x) 0 (Literal.value .prime) = weightedSum (window x) p := by
    simp [sample,weightedSum,p,Literal.value,apply_ite Complex.ofReal]
  rw [ep] at Bp
  have e : sample (window x) 0 (Literal.value (.higher (x^a) (x^c))) =
      weightedSum (window x) (fun n => p n-24*f n-2*t n) := by
    simp only [sample,Nat.add_zero,Finset.image_id',weightedSum]
    apply Finset.sum_congr rfl
    intro n _
    congr 1
    simp only [Literal.value,p,f,t]
    split_ifs <;> norm_num
  rw [e]
  have err (q : ℕ) : ‖disc (fun n => p n-24*f n-2*t n) q‖ ≤
      ‖disc p q‖+24*‖disc f q‖+2*‖disc t q‖ := by
    have id : disc (fun n => p n-24*f n-2*t n) q =
        disc p q-24*disc f q-2*disc t q := by
      dsimp only [disc,weightedSum]
      rw [fullDiscrepancy_sample_sub,fullDiscrepancy_sample_sub]
      have hf := scale_discrepancy (window x) f 24 q b
      have ht := scale_discrepancy (window x) t 2 q b
      simp only [weightedSum] at hf ht
      rw [hf,ht]
    rw [id]
    have est := (norm_sub_le (disc p q-24*disc f q) (2*disc t q)).trans
      (add_le_add (norm_sub_le (disc p q) (24*disc f q)) le_rfl)
    simpa only [norm_mul,Complex.norm_ofNat] using est
  calc
    _ ≤ ∑ q ∈ Q, (‖disc p q‖+24*‖disc f q‖+2*‖disc t q‖) := Finset.sum_le_sum fun q _ => err q
    _ ≤ P*x/(Real.log x)^A+24*(F*x/(Real.log x)^A)+2*(T*x/(Real.log x)^A) := by
      simp only [Finset.sum_add_distrib,← Finset.mul_sum]
      exact add_le_add (add_le_add Bp (mul_le_mul_of_nonneg_left Bf (by norm_num)))
        (mul_le_mul_of_nonneg_left Bt (by norm_num))
    _ = _ := by ring

#print axioms higher_ordinary
end PrimeGap180.Distribution
