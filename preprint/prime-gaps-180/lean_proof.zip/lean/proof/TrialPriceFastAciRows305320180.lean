import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G305
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 305

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G305

namespace PrimeGap180.PriceIsolatedGroup.G310
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 310

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G310

namespace PrimeGap180.PriceIsolatedGroup.G315
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 315

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G315

namespace PrimeGap180.PriceIsolatedGroup.G320
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 320

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G320
