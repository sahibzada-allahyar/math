import TrialRetainedIdentity180

/-! Recover the signed central sequence on integers from its four ordered
prime-tuple sums, with each squarefree composite counted once. -/
noncomputable section
open scoped Classical BigOperators Topology
open Filter PrimeGap186 PrimeGap182Audit PrimeGap180.Distribution PrimeGap180.Ordinary
namespace PrimeGap180.Central

def centralRank (k : ℕ) (x a ζ : ℝ) : ℕ →₀ ℂ :=
  ∑ p ∈ Fintype.piFinset (fun _ : Fin k => primeBand x (4/25) (9/10)),
    Finsupp.single (∏ i, p i) (residualWeight (trueKeys x a ζ p) : ℂ)

def integerResidual (x a ζ : ℝ) (N : ℕ) : ℂ :=
  if Squarefree N ∧ ¬N.Prime then
    (residualWeight (trueKeys x a ζ (N.primeFactors.orderEmbOfFin rfl)) : ℂ) else 0

private theorem canonical_product {N : ℕ} (sq : Squarefree N) {k : ℕ}
    (card : N.primeFactors.card = k) : ∏ i, N.primeFactors.orderEmbOfFin card i = N := by
  let p := N.primeFactors.orderEmbOfFin card
  calc
    ∏ i, p i = ∏ q ∈ Finset.univ.image p, q :=
      (Finset.prod_image (f := id) p.injective.injOn).symm
    _ = N := by rw [Finset.image_orderEmbOfFin_univ,Nat.prod_primeFactors_of_squarefree sq]

/-- A nonzero tuple summand determines the prime-divisor count, the integer
window, and its uniquely ordered prime labels. -/
private theorem contributor {k N : ℕ} (hk : 2 ≤ k) {x a ζ : ℝ} (hx : 1 < x)
    (p : Fin k → ℕ) (prime : ∀ i, (p i).Prime) (prod : ∏ i, p i = N)
    (ne : residualWeight (trueKeys x a ζ p) ≠ 0) :
    Squarefree N ∧ ¬N.Prime ∧ N ∈ window x ∧ N.primeFactors.card = k ∧ StrictMono p := by
  obtain ⟨win,_,inc⟩ := closed_and_ordered hx (fun i => Nat.cast_pos.mpr (prime i).pos) ne
  have card : N.primeFactors.card = k := by
    simp [Retained.factors_of_product p prime prod,Finset.card_image_of_injective _ inc.injective]
  refine ⟨Retained.ordered_squarefree p inc prime prod,?_,prod ▸ win,card,inc⟩
  intro pn
  have c1 : N.primeFactors.card = 1 := by simp [pn.primeFactors]
  omega

/-- An integer with a nonzero central coefficient lies in the tuple carriers
used by the distribution estimates. The bounds are uniform in the cutoff. -/
private theorem central_carrier : ∀ᶠ x : ℝ in atTop, ∀ a ζ : ℝ, CutParameters a ζ →
    ∀ N : ℕ, integerResidual x a ζ N ≠ 0 → N ∈ window x ∧ 2 ≤ N.primeFactors.card ∧
      N.primeFactors.card ≤ 5 ∧ ∀ q ∈ N.primeFactors, q ∈ primeBand x (4/25) (9/10) := by
  have δ : (0:ℝ) < 1/1000 := by norm_num
  filter_upwards [eventually_gt_atTop (1:ℝ),
    (tendsto_rpow_atTop δ).eventually (eventually_gt_atTop (2:ℝ))] with x hx hxδ
  intro a ζ cuts N ne
  classical
  by_cases good : Squarefree N ∧ ¬N.Prime
  swap
  · exact (ne (by simp [integerResidual,good])).elim
  let p := N.primeFactors.orderEmbOfFin rfl
  have pr (i) : (p i).Prime := Nat.prime_of_mem_primeFactors (N.primeFactors.orderEmbOfFin_mem rfl i)
  have nonzero : residualWeight (trueKeys x a ζ p) ≠ 0 := fun h => ne (by simp [integerResidual,good,p] at h ⊢; exact_mod_cast h)
  obtain ⟨win,rough,_⟩ := closed_and_ordered hx (p := (p : Fin N.primeFactors.card → ℕ))
    (fun i => Nat.cast_pos.mpr (pr i).pos) nonzero
  have prod : ∏ i,p i = N := canonical_product good.1 rfl
  rw [prod] at win
  have xp := zero_lt_one.trans hx
  have low := Nat.ceil_le.mp (Finset.mem_Icc.mp win).1
  have high := (Nat.cast_le.mpr (Finset.mem_Icc.mp win).2).trans
    (Nat.floor_le (by linarith : 0 ≤ 2*x))
  have two : 2 ≤ N.primeFactors.card := by
    by_contra! h
    have cases : N.primeFactors.card = 0 ∨ N.primeFactors.card = 1 := by omega
    rcases cases with h|h
    · have eq := Nat.prod_primeFactors_of_squarefree good.1
      rw [Finset.card_eq_zero.mp h,Finset.prod_empty] at eq
      exact hx.not_ge (by simpa [← eq] using low)
    · obtain ⟨q,eq⟩ := Finset.card_eq_one.mp h
      have div := Nat.prod_primeFactors_of_squarefree good.1
      rw [eq,Finset.prod_singleton] at div
      exact good.2 (div ▸ Nat.prime_of_mem_primeFactors (eq ▸ Finset.mem_singleton_self q))
  have qrough (q : ℕ) (hq : q ∈ N.primeFactors) : x^(1-2*a) ≤ (q:ℝ) := by
    have hit : q ∈ Finset.univ.image p := by simpa [p] using hq
    obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp hit
    exact rough i
  have five : N.primeFactors.card ≤ 5 := by
    by_contra! many
    have hbase : 1 ≤ x^(1-2*a) := Real.one_le_rpow hx.le (by linarith only [cuts.high])
    have bp : (x^(1-2*a))^N.primeFactors.card ≤ (N:ℝ) := by
      have e := Finset.prod_le_prod (s := N.primeFactors) (f := fun _ => x^(1-2*a))
        (g := fun n : ℕ => (n:ℝ)) (fun _ _ => hbase.trans' zero_le_one) qrough
      have nprod : (∏ q ∈ N.primeFactors, (q:ℝ)) = N := by
        simpa only [Nat.cast_prod] using congrArg (fun n : ℕ => (n:ℝ))
          (Nat.prod_primeFactors_of_squarefree good.1)
      simpa [nprod] using e
    have b6 : (x^(1-2*a))^6 ≤ (N:ℝ) := (pow_le_pow_right₀ hbase (by omega : 6 ≤ N.primeFactors.card)).trans bp
    rw [← Real.rpow_mul_natCast xp.le] at b6
    have exponent : 1+(1:ℝ)/1000 ≤ (1-2*a)*6 := by linarith only [cuts.high]
    have upper := (Real.rpow_le_rpow_of_exponent_le hx.le exponent).trans b6
    rw [Real.rpow_add xp, Real.rpow_one] at upper
    nlinarith only [upper,high,mul_lt_mul_of_pos_left hxδ xp]
  refine ⟨win,two,five,?_⟩
  intro q hq
  have qr := qrough q hq
  have lower := (Real.rpow_le_rpow_of_exponent_le hx.le (by linarith only [cuts.high] : (4:ℝ)/25 ≤ 1-2*a)).trans qr
  have other : ∃ r ∈ N.primeFactors, r ≠ q := by
    by_contra! all
    have h : N.primeFactors.card ≤ 1 := Finset.card_le_one_iff.mpr
      (fun {_ _} h₁ h₂ => (all _ h₁).trans (all _ h₂).symm)
    omega
  obtain ⟨r,hr,diff⟩ := other
  have pp := Nat.mem_primeFactors.mp hq
  have rr := Nat.mem_primeFactors.mp hr
  have dvd := ((Nat.coprime_primes pp.1 rr.1).mpr diff.symm).mul_dvd_of_dvd_of_dvd pp.2.1 rr.2.1
  have qrle : (q:ℝ)*r ≤ 2*x := (by exact_mod_cast Nat.le_of_dvd (Nat.pos_of_ne_zero good.1.ne_zero) dvd : (q:ℝ)*r ≤ N).trans high
  apply (mem_primeBand xp).mpr
  refine ⟨pp.1,lower,?_⟩
  by_contra! big
  have rl := qrough r hr
  have gt := mul_lt_mul_of_pos_right big (Real.rpow_pos_of_pos xp (1-2*a))
  have b := gt.trans_le (mul_le_mul_of_nonneg_left rl (Nat.cast_nonneg q))
  rw [← Real.rpow_add xp] at b
  have exponent : 1+(1:ℝ)/1000 ≤ 9/10+(1-2*a) := by linarith only [cuts.high]
  have upper := (Real.rpow_le_rpow_of_exponent_le hx.le exponent).trans_lt (b.trans_le qrle)
  rw [Real.rpow_add xp,Real.rpow_one] at upper
  nlinarith only [upper,mul_lt_mul_of_pos_left hxδ xp]


private theorem central_rank_evaluation : ∀ᶠ x : ℝ in atTop, ∀ a ζ : ℝ, CutParameters a ζ →
    ∀ k : ℕ, 2 ≤ k → ∀ N : ℕ, centralRank k x a ζ N =
      if N.primeFactors.card = k then integerResidual x a ζ N else 0 := by
  classical
  filter_upwards [central_carrier,eventually_gt_atTop (1:ℝ)] with x carrier hx
  intro a ζ cuts k hk N
  let T := Fintype.piFinset (fun _ : Fin k => primeBand x (4/25) (9/10))
  let R := fun p : Fin k → ℕ => residualWeight (trueKeys x a ζ p)
  change (∑ p ∈ T, Finsupp.single (∏ i,p i) (R p:ℂ)) N = _
  simp only [Finsupp.finsetSum_apply,Finsupp.single_apply]
  have primes (t : Fin k → ℕ) (ht : t ∈ T) (i : Fin k) : (t i).Prime :=
    ((mem_primeBand (zero_lt_one.trans hx)).mp (Fintype.mem_piFinset.mp ht i)).1
  by_cases found : ∃ p ∈ T, (∏ i,p i) = N ∧ R p ≠ 0
  · obtain ⟨p,hp,prod,ne⟩ := found
    obtain ⟨sq,comp,_,card,inc⟩ := contributor hk hx p (primes p hp) prod ne
    rw [Finset.sum_eq_single p]
    · simp only [prod,ite_true,card]
      subst k
      let t := N.primeFactors.orderEmbOfFin rfl
      have eq : p = (t : Fin N.primeFactors.card → ℕ) := ordered_primes_unique (primes p hp)
        (fun i => Nat.prime_of_mem_primeFactors (N.primeFactors.orderEmbOfFin_mem rfl i))
        inc t.strictMono (prod.trans (canonical_product sq rfl).symm)
      simp [integerResidual,sq,comp,R,eq,t]
    · intro t ht diff
      by_cases same : (∏ i,t i) = N
      · have zero : R t = 0 := by
          by_contra nz
          have asc := (contributor hk hx t (primes t ht) same nz).2.2.2.2
          exact diff (ordered_primes_unique (primes t ht) (primes p hp) asc inc (same.trans prod.symm))
        simp [same,zero]
      · simp [same]
    · exact fun bad => (bad hp).elim
  · rw [Finset.sum_eq_zero]
    · by_cases card : N.primeFactors.card = k
      · rw [ite_eq_left card]
        by_contra bad
        have ne : integerResidual x a ζ N ≠ 0 := Ne.symm bad
        obtain ⟨_,_,_,band⟩ := carrier a ζ cuts N ne
        have good : Squarefree N ∧ ¬N.Prime := by
          by_contra ng
          exact ne (by simp [integerResidual,ng])
        subst k
        let t := N.primeFactors.orderEmbOfFin rfl
        have mem : (t : Fin N.primeFactors.card → ℕ) ∈ T := Fintype.mem_piFinset.mpr
          fun i => band _ (N.primeFactors.orderEmbOfFin_mem rfl i)
        exact found ⟨t,mem,canonical_product good.1 rfl,fun zero =>
          ne (by simpa only [integerResidual,ite_eq_left good] using
            (show ((R t:ℤ):ℂ) = 0 by rw [zero,Int.cast_zero]))⟩
      · simp [card]
    · intro t ht
      by_cases prod : (∏ i,t i) = N
      · have zero : R t = 0 := by by_contra ne; exact found ⟨t,ht,prod,ne⟩
        simp [prod,zero]
      · simp [prod]

/-- The four ordered tuple sums recover the literal central sequence, once
per integer, and vanish outside its dyadic support. -/
theorem central_four_ranks : ∀ᶠ x : ℝ in atTop, ∀ a ζ : ℝ, CutParameters a ζ →
    (∑ N ∈ window x, Finsupp.single N (integerResidual x a ζ N)) =
      centralRank 2 x a ζ + centralRank 3 x a ζ + centralRank 4 x a ζ + centralRank 5 x a ζ := by
  classical
  filter_upwards [central_rank_evaluation,central_carrier] with x eval carrier
  intro a ζ cuts
  ext N
  simp only [Finsupp.finsetSum_apply,Finsupp.single_apply,Finset.sum_ite_eq',Finsupp.add_apply,
    eval a ζ cuts 2 (by decide),eval a ζ cuts 3 (by decide),eval a ζ cuts 4 (by decide),
    eval a ζ cuts 5 (by decide)]
  by_cases ne : integerResidual x a ζ N = 0
  · simp [ne]
  · obtain ⟨win,two,five,_⟩ := carrier a ζ cuts N ne
    have cases : N.primeFactors.card = 2 ∨ N.primeFactors.card = 3 ∨
        N.primeFactors.card = 4 ∨ N.primeFactors.card = 5 := by omega
    rcases cases with h|h|h|h <;> simp [win,h]

#print axioms central_four_ranks

end PrimeGap180.Central
