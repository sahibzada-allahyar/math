import TrialRelaxedMargin180

/-! The relaxed-route deduction with larger restoration, deleted-mass and original-debit
allowances. With the uncut target 1.00117224 the terminal excess is still
0.00117224 - 0.001121271547 - 0.0000443013 > 0.0000066 times the original mass. -/
noncomputable section
open scoped BigOperators
open PrimeGap186 PrimeGap180.Sector PrimeGap180.FrozenData PrimeGap180.NumericalAccount
open PrimeGap180.AdverseScore
namespace PrimeGap180.SlackMargin

theorem direct (uncutDebit : PhysicalDebit.debit Restoration.original ≤ 0.000024*mass Restoration.original)
    (removedMass : mass Restoration.deleted ≤ 0.00017*mass Restoration.original) :
    directDebit ≤ 0.0000443013*mass Restoration.original := by
  have nn : 0 ≤ mass Restoration.original := MeasureTheory.integral_nonneg (fun _ => sq_nonneg _)
  linarith only [PhysicalDebit.split,uncutDebit,DebitRunData.deleted,removedMass,nn]

theorem margin (uncut : RelaxedMargin.target*mass Restoration.original ≤ numerator Restoration.original)
    (removed : restoredLoss ≤ 0.001121271547*mass Restoration.original)
    (debit : directDebit ≤ 0.0000443013*mass Restoration.original) : Terminal.Margin := by
  have pos := PositiveMass.positive
  have eq := Restoration.ordinary_split
  change mass Restoration.original = mass trial + mass Restoration.deleted at eq
  unfold restoredLoss at removed
  unfold RelaxedMargin.target at uncut
  have gain : 0.0000066*mass Restoration.original <
      numerator trial-mass trial-directDebit := by linarith only [pos,uncut,removed,debit,eq]
  have strict := (mul_pos (by norm_num : (0:ℝ)<0.0000066) pos).trans gain
  apply historical_margin
  unfold numerator at strict
  have hist : historical trial = rho*∑ i : Fin 39,historicalIncome i := by
    simp only [historical,historical_exact]
  rw [hist] at strict
  change mass trial + pairFor trial + directDebit < _
  linarith only [strict]

theorem gap (input : SourceSchedule.Inputs) (prices : FrozenLedger.Endpoints)
    (resource : ∀ u : Resources.Resource,u ≠ .prime → ∀ s,
      (Book.resourceRow u).price s ≤ FrozenLedger.ledger.resourceKernel u s)
    (event : ∀ e : PriceEvents.Event,e ≠ .prime → ∀ s,
      (Book.eventRow e).price s ≤ FrozenLedger.ledger.eventKernel e s)
    (densities : Terminal.DensityIntegrals)
    (uncut : RelaxedMargin.target*mass Restoration.original ≤ numerator Restoration.original)
    (removed : restoredLoss ≤ 0.001121271547*mass Restoration.original)
    (uncutDebit : PhysicalDebit.debit Restoration.original ≤ 0.000024*mass Restoration.original)
    (removedMass : mass Restoration.deleted ≤ 0.00017*mass Restoration.original) :
    primeGapLiminf ≤ (180 : EReal) :=
  Terminal.gap_of_frozen_margin input FrozenLedger.ledger (FrozenLedger.finiteChecks prices)
    ⟨FrozenFiveCovers.checked,resource,event⟩ FrozenLedger.slots densities
    FrozenMesh.checked SourceCoverageCertificate.checked ResolvedCertificate.checked
    (margin uncut removed (direct uncutDebit removedMass))

#print axioms direct
#print axioms margin
#print axioms gap
end PrimeGap180.SlackMargin
