import TrialMassCoefficientSum180
import TrialSignedMassDot180

/-! The ordinary-mass bank groups signed products sharing an identical
nonnegative angular coefficient. Rounding the group after its signed sum
gives the integer accumulation used by the directed native computation. -/
noncomputable section
open scoped BigOperators Classical
open PrimeGap180.PackedLaw PrimeGap180.PackedSingleFields PrimeGap180.FullNativeTicks
namespace PrimeGap180.GroupedMassDot
open SignedMassDot
set_option exponentiation.threshold 512
variable {G : Type*} [Fintype G] {P : G → Type*} [∀ i,Fintype (P i)]

private theorem reindex {K : Type*} [Fintype K] (order : (Σ a,P a) ≃ K × K) (f : K → K → ℝ) :
    (∑ a : K,∑ b : K,f a b) = ∑ a : G,∑ p : P a,f (order ⟨a,p⟩).1 (order ⟨a,p⟩).2 := by
  calc
    _ = ∑ x : K × K,f x.1 x.2 := (Fintype.sum_prod_type _).symm
    _ = ∑ p : Σ a,P a,f (order p).1 (order p).2 := (Equiv.sum_comp order (fun x => f x.1 x.2)).symm
    _ = _ := Fintype.sum_sigma _

def diff (c : Hist) (j : Tick) (s : Key) : ℝ := 2^64*(radialField j.val c.val s - radialField j.val (c.val+1) s)
def both (c : Hist) (j : Tick) (s : Key) : ℝ := 2^64*(radialField j.val c.val s + radialField j.val (c.val+1) s)

theorem scaled (g : Grid) (c : Hist) (order : (Σ a,P a) ≃ Key × Key) (kernel : G → Tick → ℝ)
    (same : ∀ a p (j : Tick),
      (EndpointShapeTensor.tensor g c (order ⟨a,p⟩).1 (order ⟨a,p⟩).2).coeff j.val = kernel a j) :
    (2^384:ℝ)*RoundedCaps.m g c =
      ∑ a : G,∑ j : Tick,(∑ p : P a,diff c j (order ⟨a,p⟩).1 * both c j (order ⟨a,p⟩).2) *
        (2^256*kernel a j) := by
  rw [MassCoefficientSum.cap,Finset.mul_sum,Finset.sum_comm (s:=Finset.univ (α:=G))]
  apply Finset.sum_congr rfl
  intro j _
  rw [reindex order,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro a _
  rw [Finset.sum_mul,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro p _
  rw [same]
  unfold diff both
  ring

theorem upper (g : Grid) (c : Hist) (order : (Σ a,P a) ≃ Key × Key) (kernel : G → Tick → ℝ)
    (same : ∀ a p (j : Tick),
      (EndpointShapeTensor.tensor g c (order ⟨a,p⟩).1 (order ⟨a,p⟩).2).coeff j.val = kernel a j)
    (a b : (z : G) → Tick → P z → ℤ) (p q : (z : G) → Tick → P z → ℕ)
    (lo hi : G → Tick → ℕ)
    (delta : ∀ z j t,(a z j t:ℝ) ≤ diff c j (order ⟨z,t⟩).1 ∧
      diff c j (order ⟨z,t⟩).1 ≤ (a z j t:ℝ)+p z j t)
    (total : ∀ z j t,(b z j t:ℝ) ≤ both c j (order ⟨z,t⟩).2 ∧
      both c j (order ⟨z,t⟩).2 ≤ (b z j t:ℝ)+q z j t)
    (low : ∀ z j,(lo z j:ℝ)≤2^256*kernel z j) (high : ∀ z j,2^256*kernel z j≤(hi z j:ℝ)) :
    (2^384:ℝ)*RoundedCaps.m g c ≤
      ((∑ z : G,∑ j : Tick,up (center (a z j) (b z j)+radius (a z j) (b z j) (p z j) (q z j))
        (lo z j) (hi z j):ℤ):ℝ) := by
  rw [scaled g c order kernel same,Int.cast_sum]
  apply Finset.sum_le_sum
  intro z _
  exact (SignedMassDot.contraction _ _ _ _ _ _ _ _ _ (delta z) (total z) (low z) (high z)).2

theorem bounds (g : Grid) (c : Hist) (order : (Σ a,P a) ≃ Key × Key) (kernel : G → Tick → ℝ)
    (same : ∀ a p (j : Tick),
      (EndpointShapeTensor.tensor g c (order ⟨a,p⟩).1 (order ⟨a,p⟩).2).coeff j.val = kernel a j)
    (a b : (z : G) → Tick → P z → ℤ) (p q : (z : G) → Tick → P z → ℕ)
    (lo hi : G → Tick → ℕ)
    (delta : ∀ z j t,(a z j t:ℝ) ≤ diff c j (order ⟨z,t⟩).1 ∧
      diff c j (order ⟨z,t⟩).1 ≤ (a z j t:ℝ)+p z j t)
    (total : ∀ z j t,(b z j t:ℝ) ≤ both c j (order ⟨z,t⟩).2 ∧
      both c j (order ⟨z,t⟩).2 ≤ (b z j t:ℝ)+q z j t)
    (low : ∀ z j,(lo z j:ℝ)≤2^256*kernel z j) (high : ∀ z j,2^256*kernel z j≤(hi z j:ℝ)) :
    ((∑ z : G,∑ j : Tick,down (center (a z j) (b z j)-radius (a z j) (b z j) (p z j) (q z j))
        (lo z j) (hi z j):ℤ):ℝ) ≤ (2^384:ℝ)*RoundedCaps.m g c ∧
    (2^384:ℝ)*RoundedCaps.m g c ≤
      ((∑ z : G,∑ j : Tick,up (center (a z j) (b z j)+radius (a z j) (b z j) (p z j) (q z j))
        (lo z j) (hi z j):ℤ):ℝ) := by
  rw [scaled g c order kernel same,Int.cast_sum,Int.cast_sum]
  have each (z : G) := SignedMassDot.contraction _ _ _ _ _ _ _ _ _ (delta z) (total z) (low z) (high z)
  exact ⟨Finset.sum_le_sum (fun z _ => (each z).1),Finset.sum_le_sum (fun z _ => (each z).2)⟩

#print axioms upper
#print axioms bounds
end PrimeGap180.GroupedMassDot
