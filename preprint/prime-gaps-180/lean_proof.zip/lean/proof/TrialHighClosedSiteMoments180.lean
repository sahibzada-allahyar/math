import TrialHighCertifiedMoments180
import TrialHighSiteMoments180

/-! The two certified tilts supply the moments for every ordinary, singly
marked, and doubly marked native site used in the high-edge Gram. -/
namespace PrimeGap180.HighClosedSiteMoments
open HighMomentReader HighSiteMoments HighTailTiles

theorem core (r : Rate) (tags : Marks) (p : Fin 13) :
    encloses (upperCore HighCertifiedMoments.bounds r tags p) (physicalCore r tags p) :=
  core_ok HighCertifiedMoments.sound r tags p

theorem endpoint (r : Rate) (tags : Marks) (a b : Fin 3) :
    encloses (upperEndpoint HighCertifiedMoments.bounds r tags a b) (physicalEnd r tags a b) :=
  endpoint_ok HighCertifiedMoments.sound r tags a b

#print axioms core
#print axioms endpoint
end PrimeGap180.HighClosedSiteMoments
