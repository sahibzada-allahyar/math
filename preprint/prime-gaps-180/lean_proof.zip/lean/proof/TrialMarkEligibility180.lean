import TrialMarkedSector180

/-! All mark families in the 180 prices consist of units, primes or
products of two primes. A rough ambient prime interval gives a uniform
reciprocal bound for arbitrary nonnegative, bounded weights on subsets. -/
noncomputable section
open scoped Classical BigOperators Topology
open Filter PrimeGap186
namespace PrimeGap180.Marked

def primeBand (x ξ : ℝ) := (Nat.primesLE ⌊x⌋₊).filter (fun p : ℕ => x^ξ ≤ (p:ℝ))

def markUniverse (B : Finset ℕ) := ({1} ∪ B) ∪ ((B ×ˢ B).image (fun v => v.1*v.2))

private theorem universe_mass (B : Finset ℕ) :
    (∑ m ∈ markUniverse B, (m:ℝ)⁻¹) ≤
      1+(∑ p ∈ B, (p:ℝ)⁻¹)+(∑ p ∈ B, (p:ℝ)⁻¹)^2 := by
  let w := fun m : ℕ => (m:ℝ)⁻¹
  let g := fun v : ℕ × ℕ => v.1*v.2
  have nn (m) : 0 ≤ w m := inv_nonneg.mpr (Nat.cast_nonneg _)
  have join (S T : Finset ℕ) : (∑ m ∈ S ∪ T, w m) ≤ (∑ m ∈ S, w m)+(∑ m ∈ T,w m) := by
    have add := Finset.sum_union_inter (s₁ := S) (s₂ := T) (f := w)
    linarith only [add,Finset.sum_nonneg (s := S ∩ T) (f := w) (fun m _ => nn m)]
  have image := Finset.sum_image_le_of_nonneg (s := B ×ˢ B) (g := g) (f := w) (fun m _ => nn m)
  have pair : (∑ v ∈ B ×ˢ B, w (g v)) = (∑ p ∈ B, w p)^2 := by
    simp only [Finset.sum_product,w,g,Nat.cast_mul,mul_inv,← Finset.mul_sum,← Finset.sum_mul,pow_two]
  calc
    _ ≤ ((∑ m ∈ {1} ∪ B, w m)+(∑ m ∈ (B ×ˢ B).image g,w m)) := join _ _
    _ ≤ ((∑ m ∈ {1}, w m)+(∑ m ∈ B,w m))+(∑ v ∈ B ×ˢ B, w (g v)) := add_le_add (join _ _) image
    _ = _ := by rw [pair]; simp [w]

theorem eligible_subsets (H : Finset ℕ) {κ ξ s d M : ℝ} (hξ : 0 < ξ) (hξ1 : ξ ≤ 1)
    (cap : rho*κ < ξ) (hd : 0 < d) (hM : 0 ≤ M) :
    ∃ K : ℝ, 0 ≤ K ∧ ∀ᶠ x : ℝ in atTop, let W := presievingModulus H x
      ∀ (S : Finset ℕ) (w : ℕ → ℝ), S ⊆ markUniverse (primeBand x ξ) →
      (∀ m ∈ S, (m:ℝ) ≤ x^s ∧ 0 ≤ w m ∧ w m ≤ M) →
      (∀ m ∈ S, 0 < m ∧ W.Coprime m ∧ (carrier W x κ).Coprime m ∧ 0 ≤ w m) ∧
        (∑ m ∈ S, w m) ≤ x^(s+d) ∧ mass S w ≤ K := by
  obtain ⟨U,hU,band⟩ := eventually_prime_reciprocal_band_bounded ξ 1 hξ hξ1
  refine ⟨M*(1+U+U^2),by positivity,?_⟩
  filter_upwards [band,eventually_gt_atTop (1:ℝ),eventually_large_prime_coprime_presieving H ξ hξ,
    (tendsto_rpow_atTop hd).eventually_ge_atTop M] with x hband hx pre big
  intro W S w sub terms
  let B := primeBand x ξ
  have prime (p : ℕ) (hp : p ∈ B) : 0 < p ∧ W.Coprime p ∧ (carrier W x κ).Coprime p := by
    obtain ⟨mem,hp'⟩ := Finset.mem_filter.mp hp
    have pr := Nat.prime_of_mem_primesLE mem
    have small : (x^rho)^κ < x^ξ := by
      rw [← Real.rpow_mul (zero_lt_one.trans hx).le]
      exact Real.rpow_lt_rpow_of_exponent_lt hx cap
    exact ⟨pr.pos,(pre p pr hp').symm,(fragmentPrimeProduct_coprime_of_large_prime W p (x^rho) κ
      (Real.rpow_nonneg (zero_lt_one.trans hx).le _) pr (small.trans_le hp')).symm⟩
  have ok (m : ℕ) (hm : m ∈ S) : 0 < m ∧ W.Coprime m ∧ (carrier W x κ).Coprime m := by
    rcases Finset.mem_union.mp (sub hm) with h|h
    · rcases Finset.mem_union.mp h with one|p
      · have eq := Finset.mem_singleton.mp one
        simp [eq]
      · exact prime m p
    · obtain ⟨⟨p,q⟩,mem,rfl⟩ := Finset.mem_image.mp h
      obtain ⟨p',q'⟩ := Finset.mem_product.mp mem
      exact ⟨Nat.mul_pos (prime _ p').1 (prime _ q').1,
        (prime _ p').2.1.mul_right (prime _ q').2.1,(prime _ p').2.2.mul_right (prime _ q').2.2⟩
  refine ⟨fun m h => ⟨(ok _ h).1,(ok _ h).2.1,(ok _ h).2.2,(terms _ h).2.1⟩,?_,?_⟩
  · have small : S ⊆ Finset.Icc 1 ⌊x^s⌋₊ := fun m h => Finset.mem_Icc.mpr
      ⟨(ok _ h).1,(Nat.le_floor_iff (Real.rpow_nonneg (zero_lt_one.trans hx).le _)).mpr (terms _ h).1⟩
    have card : (S.card:ℝ) ≤ x^s := by
      have le : S.card ≤ ⌊x^s⌋₊ := by simpa using Finset.card_le_card small
      exact (Nat.cast_le.mpr le).trans (Nat.floor_le (Real.rpow_nonneg (zero_lt_one.trans hx).le _))
    rw [Real.rpow_add (zero_lt_one.trans hx)]
    exact (Finset.sum_le_card_nsmul S w M (fun m h => (terms _ h).2.2)).trans
      (by simpa only [nsmul_eq_mul] using mul_le_mul card big hM (Real.rpow_nonneg (zero_lt_one.trans hx).le s))
  · let sum := ∑ p ∈ B, (p:ℝ)⁻¹
    have sb : sum ≤ U := by simpa only [Real.rpow_one,primeBand,B,sum] using hband
    have sn : 0 ≤ sum := Finset.sum_nonneg (fun p _ => inv_nonneg.mpr (Nat.cast_nonneg p))
    have extended := Finset.sum_le_sum_of_subset_of_nonneg (f := fun m : ℕ => (m:ℝ)⁻¹) sub
      (fun m _ _ => inv_nonneg.mpr (Nat.cast_nonneg m))
    have total := extended.trans (universe_mass B)
    calc
      _ ≤ ∑ m ∈ S, M*(m:ℝ)⁻¹ := Finset.sum_le_sum (fun m h => by
        rw [div_eq_mul_inv]; exact mul_le_mul_of_nonneg_right (terms _ h).2.2 (inv_nonneg.mpr (Nat.cast_nonneg _)))
      _ = M*(∑ m ∈ S,(m:ℝ)⁻¹) := by rw [Finset.mul_sum]
      _ ≤ _ := mul_le_mul_of_nonneg_left (total.trans (by
        change 1+sum+sum^2 ≤ 1+U+U^2
        gcongr)) hM

/-- One common carrier works for all cells with the same roughness. The retreat
also absorbs the loss in replacing bounded weights by a counting exponent. -/
theorem price_radius {s r ξ d : ℝ} (hd : 0 < d) (hrough : d < ξ)
    (hr : d < (1-s)/2-r) (hcap : Sector.physicalCap < ξ) :
    let ζ := min ξ ((1-s)/2-r)-d
    let κ := max Sector.physicalCap (ξ-d)/Sector.rho
    0 < ζ ∧ ζ < ξ ∧ Sector.cap ≤ κ ∧ ζ/Sector.rho ≤ κ ∧ Sector.rho*κ < ξ ∧
      s+d+2*(r+ζ) ≤ 1-d := by
  intro ζ κ
  have rhoPos : 0 < Sector.rho := by norm_num [Sector.rho]
  have rough : ζ ≤ ξ-d := sub_le_sub_right (min_le_left _ _) _
  have rad : ζ ≤ (1-s)/2-r-d := sub_le_sub_right (min_le_right _ _) _
  refine ⟨sub_pos.mpr (lt_min hrough hr),by linarith,?_,?_,?_,by linarith⟩
  · exact div_le_div_of_nonneg_right (le_max_left _ _) rhoPos.le
  · exact div_le_div_of_nonneg_right (rough.trans (le_max_right _ _)) rhoPos.le
  · dsimp [κ]
    rw [mul_comm,div_mul_cancel₀ _ rhoPos.ne']
    exact max_lt hcap (by linarith)

#print axioms price_radius
#print axioms eligible_subsets
end PrimeGap180.Marked
