import TrialDebitRunData180
import TrialDebitCapMap180
noncomputable section
open PrimeGap180.FrozenData PrimeGap180.FrozenProfile PrimeGap180.DebitRunData
open PrimeGap180.DebitNativeClasses
namespace PrimeGap180.MonotonePriceCaps
abbrev Row := Array Nat
abbrev Rows := List Row

def raw (l : Rows) (j : ℕ) := debitCode l (j+1)

def fixed (l : Rows) (a b : ℕ) := l.all fun r => decide (stop r ≤ a+1 ∨ b+1 < stop r)

private theorem code_cons (r : Row) (rs : Rows) (j : ℕ) :
    raw (r::rs) j = if j+1 < stop r then num r else raw rs j := by
  change num (((r::rs).find? (fun t => decide (j+1 < stop t))).getD #[]) =
    if j+1 < stop r then num r else num ((rs.find? (fun t => decide (j+1 < stop t))).getD #[])
  by_cases h : j+1 < stop r <;> simp [h]

theorem constant (l : Rows) {a b j : ℕ} (h : fixed l a b=true) (aj : a≤j) (jb : j≤b) :
    raw l j = raw l a := by
  induction l with
  | nil => rfl
  | cons r rs ih =>
    simp only [fixed,List.all_cons,Bool.and_eq_true,decide_eq_true_eq] at h
    rw [code_cons,code_cons]
    rcases h.1 with low|hi
    · rw [ite_eq_right (by omega),ite_eq_right (by omega)]
      exact ih h.2
    · rw [ite_eq_left (by omega),ite_eq_left (by omega)]

def codePair (j x y : ℕ) : Prop := x=y ∨
    (x=183 ∧ y=181 ∧ 108887≤j ∧ j≤110018) ∨
    (x=187 ∧ y=186 ∧ 110019≤j ∧ j≤112359) ∨
    (x=193 ∧ y=191 ∧ 112360≤j ∧ j≤112788) ∨
    (x=192 ∧ y=191 ∧ 112789≤j ∧ j≤114382) ∨
    (x=186 ∧ y=185 ∧ j=110818)
instance (j x y : ℕ) : Decidable (codePair j x y) := by unfold codePair; infer_instance

private theorem between (a b j x y : ℕ) (h : codePair a x y ∧ codePair b x y)
    (aj : a ≤ j) (jb : j ≤ b) : codePair j x y := by
  rcases h with ⟨left,right⟩
  rcases left with eq | ⟨rfl,rfl,_,_⟩ | ⟨rfl,rfl,_,_⟩ | ⟨rfl,rfl,_,_⟩ |
    ⟨rfl,rfl,_,_⟩ | ⟨rfl,rfl,_⟩
  · exact Or.inl eq
  all_goals norm_num [codePair] at right ⊢ <;> omega

def scan (l r : Rows) (a : ℕ) : List ℕ → Bool
  | [] => decide (130964<a)
  | b::bs => fixed l a b && fixed r a b && decide (codePair a (raw l a) (raw r a))
      && decide (codePair b (raw l a) (raw r a)) && scan l r (b+1) bs

theorem scan_sound (l r : Rows) (bs : List ℕ) (a j : ℕ) (ok : scan l r a bs=true)
    (aj : a≤j) (jn : j≤130964) : codePair j (raw l j) (raw r j) := by
  induction bs generalizing a with
  | nil => simp [scan] at ok; omega
  | cons b bs ih =>
    simp only [scan,Bool.and_eq_true,decide_eq_true_eq] at ok
    by_cases jb : j≤b
    · rw [constant l ok.1.1.1.1 aj jb,constant r ok.1.1.1.2 aj jb]
      exact between _ _ _ _ _ ⟨ok.1.1.2,ok.1.2⟩ aj jb
    · exact ih (b+1) ok.2 (by omega)

def rowsAt (c : Fin 37) := debitSectorRows (capAt c)
def ends0 : List ℕ := [93626, 98310, 100651, 102993, 105334, 107676, 108886, 110018, 112359, 112788, 114382, 114701, 114721, 115070, 115582, 115838, 116030, 116315, 116350, 116594, 116734, 116926, 116990, 117042, 117054, 117182, 117246, 117438, 117502, 117630, 117694, 117758, 117942, 117950, 118142, 118188, 118206, 118398, 118504, 118526, 118590, 118654, 118846, 118910, 119038, 119102, 119166, 119294, 119384, 119534, 119550, 119614, 119742, 119806, 119998, 120062, 120097, 120149, 120254, 120318, 120446, 120510, 120574, 120711, 120766, 120894, 120958, 121022, 121150, 121214, 121406, 121470, 121598, 121662, 121726, 121854, 121918, 121982, 122057, 122110, 122174, 122302, 122366, 122430, 122558, 122622, 122750, 122814, 122878, 123006, 123070, 123134, 123262, 123326, 123390, 123454, 123518, 123582, 123646, 123710, 123774, 123838, 123902, 123930, 123966, 124030, 124067, 124094, 124222, 124286, 124350, 124478, 124542, 124606, 124734, 124798, 124926, 124990, 125054, 125182, 125246, 125310, 125374, 125438, 125502, 125630, 125694, 125758, 125861, 125886, 125950, 126142, 126206, 126334, 126409, 126462, 126590, 126654, 126782, 126846, 126910, 127038, 127102, 127214, 127230, 127294, 127358, 127550, 127614, 127742, 127776, 127806, 127998, 128062, 128190, 128254, 128318, 128446, 128510, 128702, 128751, 128766, 128830, 128958, 129122, 129150, 129214, 129406, 129598, 129662, 129726, 129854, 129918, 130110, 130174, 130302, 130366, 130622, 130750, 130964]
set_option maxRecDepth 18000 in
set_option maxHeartbeats 0 in
private theorem check0 : scan (rowsAt 0) (rowsAt 1) 0 ends0 = true := by decide +kernel
theorem pair0 (j : ℕ) (h : j≤130964) : codePair j (raw (rowsAt 0) j) (raw (rowsAt 1) j) :=
  scan_sound _ _ ends0 0 j check0 (Nat.zero_le _) h
#print axioms pair0
def ends3 : List ℕ := [93626, 98310, 100651, 102993, 105334, 107676, 108884, 108886, 110018, 110817, 110818, 112359, 114701, 116286, 116350, 116594, 116734, 116926, 116990, 117042, 117054, 117182, 117246, 117438, 117502, 117630, 117694, 117758, 117942, 117950, 118142, 118188, 118206, 118398, 118504, 118526, 118590, 118654, 118846, 118910, 119038, 119102, 119166, 119294, 119384, 119534, 119550, 119614, 119742, 119806, 119998, 120062, 120097, 120149, 120254, 120318, 120446, 120510, 120574, 120711, 120766, 120894, 120958, 121022, 121150, 121214, 121406, 121470, 121598, 121662, 121726, 121854, 121918, 121982, 122057, 122110, 122174, 122302, 122366, 122430, 122558, 122622, 122750, 122814, 122878, 123006, 123070, 123134, 123262, 123326, 123390, 123454, 123518, 123582, 123646, 123710, 123774, 123838, 123902, 123930, 123966, 124030, 124067, 124094, 124222, 124286, 124350, 124478, 124542, 124606, 124734, 124798, 124926, 124990, 125054, 125182, 125246, 125310, 125374, 125438, 125502, 125630, 125694, 125758, 125861, 125886, 125950, 126142, 126206, 126334, 126409, 126462, 126590, 126654, 126782, 126846, 126910, 127038, 127102, 127214, 127230, 127294, 127358, 127550, 127614, 127742, 127776, 127806, 127998, 128062, 128190, 128254, 128318, 128446, 128510, 128702, 128751, 128766, 128830, 128958, 129122, 129150, 129214, 129406, 129598, 129662, 129726, 129854, 129918, 130110, 130174, 130302, 130366, 130622, 130750, 130964]
set_option maxRecDepth 18000 in
set_option maxHeartbeats 0 in
private theorem check3 : scan (rowsAt 3) (rowsAt 4) 0 ends3 = true := by decide +kernel
theorem pair3 (j : ℕ) (h : j≤130964) : codePair j (raw (rowsAt 3) j) (raw (rowsAt 4) j) :=
  scan_sound _ _ ends3 0 j check3 (Nat.zero_le _) h
#print axioms pair3
end PrimeGap180.MonotonePriceCaps
