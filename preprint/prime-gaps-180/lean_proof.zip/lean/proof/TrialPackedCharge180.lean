import TrialPackedSiteAudit180
import Mathlib.Tactic

/-! The integer division used in every radial row is an upper rounding of
the dimensionless squared bin error, including the structural zero branch. -/
namespace PrimeGap180.PackedCharge
open PackedSiteAudit
def U : ℕ := 2^111
def E : ℕ := 2^128

private theorem ceil_div (x d : ℤ) (hd : 0 < d) : x ≤ ((x+d-1)/d)*d := by
  have decomp := Int.emod_add_ediv_mul (x+d-1) d
  have rem := Int.emod_lt_of_pos (x+d-1) hd
  omega

theorem rates {n a b : ℤ} (ok : validBin n a b=true) :
    (9999999996734/10^13:ℚ)*((n:ℚ)/U) ≤ (a:ℚ)/U ∧
    (b:ℚ)/U ≤ (1000003698086/10^12:ℚ)*((n:ℚ)/U) := by
  obtain ⟨nn,lo,hi,_⟩ := of_decide_eq_true ok
  have l : (9999999996734:ℚ)*n≤10^13*a := by exact_mod_cast lo
  have h : (10:ℚ)^12*b≤1000003698086*n := by exact_mod_cast hi
  norm_num [U] at l h ⊢
  constructor <;> linarith only [l,h]

theorem energy {n a b : ℤ} (ok : validBin n a b=true) :
    max |(a:ℚ)/U-(n:ℚ)/U| |(b:ℚ)/U-(n:ℚ)/U| ^2 / ((n:ℚ)/U) ≤ (charge n a b:ℚ)/E := by
  obtain ⟨nn,_,_,zz⟩ := of_decide_eq_true ok
  by_cases nz : n=0
  · subst n; simp [charge_eq]
  have pos : 0<n := lt_of_le_of_ne nn (Ne.symm nz)
  have up : 0<(U:ℚ) := by norm_num [U]
  have ep : 0<(E:ℚ) := by norm_num [E]
  have np : 0<(n:ℚ) := by exact_mod_cast pos
  let err := max |a-n| |b-n|
  have eq : max |(a:ℚ)/U-(n:ℚ)/U| |(b:ℚ)/U-(n:ℚ)/U| = (err:ℚ)/U := by
    simp only [←sub_div,abs_div,abs_of_pos up,err,Int.cast_max,Int.cast_abs,Int.cast_sub]
    exact max_div_div_right up.le _ _
  have dp : 0<n*(U:ℤ) := mul_pos pos (by norm_num [U])
  have result : (E:ℤ)*err^2 ≤ charge n a b * (n*(U:ℤ)) := by
    simp only [charge_eq,if_neg (not_le.mpr pos)]
    exact ceil_div ((E:ℤ)*err^2) (n*(U:ℤ)) dp
  have cast : (E:ℚ)*(err:ℚ)^2 ≤ (charge n a b:ℚ)*(n*(U:ℚ)) := by exact_mod_cast result
  rw [eq]
  apply (le_div_iff₀ ep).mpr
  calc
    _ = ((E:ℚ)*(err:ℚ)^2)/(n*(U:ℚ)) := by field_simp [up.ne',np.ne'] <;> ring
    _ ≤ _ := (div_le_iff₀ (mul_pos np up)).mpr cast

#print axioms energy
end PrimeGap180.PackedCharge
