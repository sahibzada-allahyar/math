import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G220
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 220

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G220

namespace PrimeGap180.PriceIsolatedGroup.G226
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 226

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G226

namespace PrimeGap180.PriceIsolatedGroup.G231
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 231

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G231

namespace PrimeGap180.PriceIsolatedGroup.G236
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 236

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G236
