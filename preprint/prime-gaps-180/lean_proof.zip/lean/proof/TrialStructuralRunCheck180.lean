import TrialStructuralClassReplay180

/-! The frozen source has no positive-measure deletion without a failed
active edge. The kernel checks every complete constant sector run. -/
noncomputable section
open scoped Classical BigOperators
open MeasureTheory PrimeGap180.Sector PrimeGap180.FrozenProfile
open PrimeGap180.GateDeletion
namespace PrimeGap180.StructuralRun

theorem checked : allRuns=true := StructuralRunClassReplay.checked

#print axioms checked
end PrimeGap180.StructuralRun
