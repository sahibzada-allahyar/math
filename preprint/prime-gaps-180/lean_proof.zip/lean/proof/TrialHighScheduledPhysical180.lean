import TrialHighPhysicalNativeSum180
import TrialHighScheduledAllowance180
import TrialHighPanelIntegerValuation180

/-! Assign every physical sample to the archived harmonic-band and radial
panel schedule, then discharge the nine continuum band estimates from its
444 signed integer comparisons. -/
noncomputable section
open scoped BigOperators Classical
namespace PrimeGap180.HighScheduledPhysical
set_option maxRecDepth 8192
set_option maxHeartbeats 1600000
attribute [local irreducible] HighPanelSchedule.fee HighPanelSchedule.data
open HighPhysicalNativeSum HighPanelSchedule HighPanelCensus HighMarkedNativePanel
open HighGroupedPayment (symmetry sumWord scale)
open HighSignedControls (Words ControlWords)
open HighAngularProduct (Cube)
open HighMassBands (capClass bandMass)
open HighScheduledAllowance (bandUnits)

abbrev lowerBand (i : Row) := (fee i).panel.1
abbrev upperBand (i : Row) := (fee i).panel.2.1
abbrev block (i : Row) := (fee i).panel.2.2.1
abbrev span (i : Row) := (fee i).panel.2.2.2
abbrev leftEnd (i : Row) := lo (lowerBand i) (upperBand i) (block i) (span i)
abbrev rightEnd (i : Row) := hi (lowerBand i) (upperBand i) (block i) (span i)
abbrev lastIndex (i : Row) := endIndex (lowerBand i) (upperBand i) (block i) (span i)
def payment (i : Row) := ((fee i).units:ℝ)*446/10^94
private theorem payment_nn (i : Row) : 0 ≤ payment i := by unfold payment;positivity

private def feasible (p : Panel) (x : Cube) :=
  let r := radial x
  let l := lo p.1 p.2.1 p.2.2.1 p.2.2.2
  let h := hi p.1 p.2.1 p.2.2.1 p.2.2.2
  let n := p.2.2.2.val
  MassSplineSpan.knot n ≤ MassSplineSpan.sample r ∧ MassSplineSpan.sample r < MassSplineSpan.knot (n+1) ∧
  ∃ t : ℚ, 0 ≤ t ∧ t ≤ 1 ∧ MassSplineSpan.sample r=l+(h-l)*t ∧ r≤endIndex p.1 p.2.1 p.2.2.1 p.2.2.2

def selected (i : Row) := Finset.univ.filter (feasible (fee i).panel)
private def matching (u v : Fin 9) := Finset.univ.filter fun i : Row => lowerBand i=u ∧ upperBand i=v

private theorem in_selected {i : Row} {x : Cube} : x∈selected i ↔ feasible (fee i).panel x := by simp only [selected,Finset.mem_filter,Finset.mem_univ,true_and]
private theorem in_matching {u v : Fin 9} {i : Row} : i∈matching u v ↔ lowerBand i=u ∧ upperBand i=v := by simp only [matching,Finset.mem_filter,Finset.mem_univ,true_and]
private theorem in_support {u v : Fin 9} {x : Cube} : x∈support u v ↔ firstIndex u v ≤ radial x ∧ radial x ≤ HighPanelSupport.radius v := by
  simp only [support,inRange,Finset.mem_filter,Finset.mem_univ,true_and]

attribute [local irreducible] selected support matching HighPhysicalNativeSum.contribution

private theorem covered {u v : Fin 9} (uv : u≤v) {x : Cube} (hx : x∈support u v) :
    ∃ i∈matching u v,x∈selected i := by
  obtain ⟨lower,upper⟩ := (in_support (u:=u) (v:=v) (x:=x)).mp hx
  obtain ⟨j,n,live,ok,hi,t,h0,h1,hp,hr⟩ := HighPanelCensus.cover (j:=radial x) uv lower upper
  rw [←HighPanelSchedule.covers] at live
  obtain ⟨i,_,eq⟩ := Finset.mem_image.mp live
  refine ⟨i,(in_matching (u:=u) (v:=v) (i:=i)).mpr ?_,(in_selected (i:=i) (x:=x)).mpr ?_⟩
  · simp only [lowerBand,upperBand,eq,and_self]
  · rw [eq]
    exact ⟨ok,hi,t,h0,h1,hp,hr⟩

def RowPaid (i : Row) := (∑ x ∈ selected i, HighPhysicalNativeSum.sample (lowerBand i) (upperBand i) x) / (symmetry (lowerBand i) (upperBand i):ℝ) ≤ payment i

/-- To pay one scheduled row, supply its signed control words, their exact
scales and its integer inequality. The range and knot obligations are closed. -/
theorem from_integer (i : Row) (method : Method) (C : Words) (Z : ControlWords) {den e : ℕ}
    (dp : 0<den) (ep : 0<e)
    (control : ∀ p q, HighFrozenPanel.control (span i).val (capClass (upperBand i)) (leftEnd i) (rightEnd i) p q = (C p q:ℝ)/den)
    (center : ∀ p q, matrixOf method p q=(Z p q:ℝ)/e)
    (check : sumWord (HighPanelTiltBook.read (fee i).tilt).rate (lowerBand i) (upperBand i) (HighSignedControls.coeff C Z)*(2^320:ℤ)*10^94 ≤
      ((fee i).units:ℤ)*(den*den*e*scale*symmetry (lowerBand i) (upperBand i):ℕ)*(HighPanelTiltBook.read (fee i).tilt).bound*446) : RowPaid i := by
  have live : (fee i).panel ∈ panels := by rw [←HighPanelSchedule.covers];exact Finset.mem_image_of_mem _ (Finset.mem_univ _)
  have lowest : 3 ≤ (span i).val := (of_decide_eq_true (Finset.mem_filter.mp live).2 : lowerBand i ≤ upperBand i ∧ _).2.1
  have upper : (span i).val<33 := by have := (span i).isLt;omega
  let parameter (x : Cube) := if h : feasible (fee i).panel x then Classical.choose h.2.2 else (0:ℚ)
  have par {x : Cube} (hx : x∈selected i) :
      0 ≤ parameter x ∧ parameter x≤1 ∧ MassSplineSpan.sample (radial x)=leftEnd i+(rightEnd i-leftEnd i)*parameter x ∧ radial x≤lastIndex i := by
    simpa only [parameter,dite_eq_left ((in_selected (i:=i) (x:=x)).mp hx)] using Classical.choose_spec ((in_selected (i:=i) (x:=x)).mp hx).2.2
  apply HighPanelIntegerValuation.panel (fee i).tilt (lowerBand i) (upperBand i) (selected i) (capClass (upperBand i)) (span i).val
    (leftEnd i) (rightEnd i) parameter lowest upper _ _ _ _ method C Z dp ep control center check
  · exact fun x hx => ⟨((in_selected (i:=i) (x:=x)).mp hx).1,((in_selected (i:=i) (x:=x)).mp hx).2.1⟩
  · exact fun x hx => (par (x:=x) hx).2.2.1
  · exact fun x hx => ⟨(par (x:=x) hx).1,(par (x:=x) hx).2.1⟩
  · intro x hx
    rw [(HighPanelSchedule.verified i).1]
    exact (par (x:=x) hx).2.2.2

private theorem price_pair {u v : Fin 9} (uv : u≤v) (paid : ∀ i,RowPaid i) :
    contribution u v/(symmetry u v:ℝ) ≤ ∑ i ∈ matching u v,payment i := by
  let F (x : Cube) := HighPhysicalNativeSum.sample u v x/(symmetry u v:ℝ)
  have pos (x : Cube) : 0≤F x := div_nonneg (mul_nonneg (nonnegative _ _ _) (sq_nonneg _)) (Nat.cast_nonneg _)
  unfold contribution
  rw [Finset.sum_div]
  change (∑ x ∈ support u v,F x) ≤ _
  calc
    _ ≤ ∑ x ∈ support u v,∑ i ∈ matching u v,if feasible (fee i).panel x then F x else 0 := by
      apply Finset.sum_le_sum
      intro x hx
      obtain ⟨i,hi,mem⟩ := covered (u:=u) (v:=v) (x:=x) uv hx
      have h := Finset.single_le_sum (f:=fun j => if feasible (fee j).panel x then F x else 0)
        (s:=matching u v) (fun _ _ => by split <;> first | exact pos x | exact le_rfl) hi
      rwa [ite_eq_left ((in_selected (i:=i) (x:=x)).mp mem)] at h
    _ = ∑ i ∈ matching u v, ∑ x ∈ (support u v).filter (feasible (fee i).panel),F x := by
      rw [Finset.sum_comm];simp only [Finset.sum_filter]
    _ ≤ _ := by
      apply Finset.sum_le_sum
      intro i hi
      obtain ⟨hu,hv⟩ := (in_matching (u:=u) (v:=v) (i:=i)).mp hi
      have le : ∑ x ∈ (support u v).filter (feasible (fee i).panel),F x ≤ ∑ x ∈ selected i,F x :=
        Finset.sum_le_sum_of_subset_of_nonneg (fun x hx => (in_selected (i:=i) (x:=x)).mpr (Finset.mem_filter.mp hx).2) (fun x _ _ => pos x)
      apply le.trans
      unfold F
      rw [←Finset.sum_div,←hu,←hv]
      exact paid i

private theorem sum_by_band (v : Fin 9) : (∑ u : Fin 9, ∑ i ∈ matching u v, payment i) =
    (bandUnits v:ℝ)*446/10^94 := by
  unfold matching
  simp only [Finset.sum_filter,ite_and]
  rw [Finset.sum_comm]
  simp only [Finset.sum_ite_eq,Finset.mem_univ,ite_true]
  unfold bandUnits payment
  push_cast
  rw [Finset.sum_mul,Finset.sum_div]
  apply Finset.sum_congr rfl
  intro i _
  split <;> simp_all

/-- The exact 444 geometry rows discharge all nine original continuum bands
from their own individual signed integer payments. -/
theorem bands (paid : ∀ i,RowPaid i) (v : Fin 9) : bandMass v ≤ (bandUnits v:ℝ)*446/10^94 := by
  apply (HighPhysicalNativeSum.band v).trans
  have form : (∑ u ∈ Finset.Iio v,contribution u v) + contribution v v / 2 =
      ∑ u ∈ Finset.Iic v,contribution u v / (symmetry u v:ℝ) := by
    have part : Finset.Iic v = insert v (Finset.Iio v) := by ext u;simp
    rw [part,Finset.sum_insert (by simp),add_comm]
    exact congrArg₂ (·+·) (by simp [symmetry]) (Finset.sum_congr rfl fun u hu => by simp [symmetry,(Finset.mem_Iio.mp hu).ne])
  rw [form,←sum_by_band]
  apply (Finset.sum_le_sum (fun u hu => price_pair (Finset.mem_Iic.mp hu) paid)).trans
  apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
  exact fun u _ _ => Finset.sum_nonneg fun i _ => payment_nn i

theorem high (floor : (94.17312:ℝ) ≤ 100^39*RestorationBudget.originalMass) (paid : ∀ i,RowPaid i) :
    StructuralRun.layerMass 23 ≤ RestorationRows.ticks 4135470 * RestorationBudget.originalMass :=
  HighScheduledAllowance.high floor (bands paid)

#print axioms from_integer
#print axioms bands
#print axioms high
end PrimeGap180.HighScheduledPhysical
