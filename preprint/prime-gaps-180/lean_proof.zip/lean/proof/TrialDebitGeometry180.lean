import TrialPhysicalDebit180

/-! Direct comparison for the positive replacement debit on the actual single-site law. -/
noncomputable section
open scoped Classical BigOperators Topology
open MeasureTheory Filter PrimeGap186 PrimeGap180.Sector PrimeGap180.FrozenProfile
open PrimeGap180.FrozenData PrimeGap180.EndpointPhysical PrimeGap180.Detection
open PrimeGap180.AdverseScore PrimeGap180.CoarseLaw PrimeGap180.CoarseForms
namespace PrimeGap180.PhysicalDebit

/-- Data-only verification target. The integer layer selects each retained
sector, and the last admissible full index bounds the inserted cell count. -/
def Runs := Antitone T.maxIndex ∧ ∀ (c : Fine) (j : ℕ) (s : Fin 521),
  j ≤ T.maxIndex c → T.sector c (j+1) = some s →
  39*rho*rate s j*((((T.maxIndex c-j : ℕ):ℝ)+1)*Native.step) ≤ 0.01815

private theorem min_transfer {p q : Fine → Bool} (imp : ∀ c,p c = true → q c = true)
    {f : Fine} (hf : least p = some f) : ∃ c, least q=some c ∧ c ≤ f := by
  classical
  let S := Finset.univ.filter fun c => p c = true
  let R := Finset.univ.filter fun c => q c = true
  change (if h : S.Nonempty then some (S.min' h) else none) = some f at hf
  split at hf
  next he =>
    have eq := Option.some.inj hf
    have fin : f ∈ S := eq ▸ S.min'_mem he
    have inR : f ∈ R := Finset.mem_filter.mpr ⟨Finset.mem_univ _,imp _ (Finset.mem_filter.mp fin).2⟩
    have ok : R.Nonempty := ⟨f,inR⟩
    refine ⟨R.min' ok,?_,R.min'_le _ inR⟩
    change (if h : R.Nonempty then some (R.min' h) else none) = _
    rw [dite_eq_left ok]
  next => contradiction

private theorem raw_bound (D : Tables) (j : Fin 39 → ℕ) (f : Fine) (hit : raw D j f ≠ 0) :
    (∑ k,j k) ≤ D.maxIndex f := by
  by_contra! above
  have discard := (min_le_right 130964 (D.maxIndex f)).trans_lt above
  apply hit
  exact ite_eq_left discard

private theorem raw_cap (y : Fin 39 → State) (hit : rawState y ≠ 0) :
    ∃ f, maxClass y=some f ∧ NativeContractions.total y ≤ T.maxIndex f := by
  unfold rawState at hit
  split at hit
  next => exact (hit rfl).elim
  next f eq => exact ⟨f,eq,raw_bound T (idx y) f hit⟩

theorem raw_index_bound (y : Fin 39 → State) (hit : rawState y ≠ 0) :
    (∑ j,(y j).1.val) ≤ 130964 := by
  obtain ⟨f,_,cap⟩ := raw_cap y hit
  exact cap.trans (T.maxBound f)

private theorem extend (i : Fin 39) (x : Fin 38 → State) (z : State)
    (hit : rawState (i.insertNth (α := fun _ => State) z x) ≠ 0) :
    ∃ c f, maxClass x = some c ∧ c ≤ f ∧ z.1.val + NativeContractions.total x ≤ T.maxIndex f := by
  let y := i.insertNth (α := fun _ => State) z x
  have total : NativeContractions.total y = z.1.val+NativeContractions.total x := by
    change (∑ k, (y k).1.val) = _
    rw [Fin.sum_univ_succAbove (fun k => (y k).1.val) i]
    simp [y,NativeContractions.total,idx]
  obtain ⟨f,chosen,ft⟩ := raw_cap y hit
  have imp (k : Fine) : decide (∀ j,(y j).2 k=true) = true →
      decide (∀ j,(x j).2 k=true) = true := by
    intro accept
    apply decide_eq_true
    intro t
    simpa [y] using (of_decide_eq_true accept) (i.succAbove t)
  obtain ⟨c,hc,le⟩ := min_transfer imp chosen
  exact ⟨c,f,hc,le,total ▸ ft⟩

/-- A nonzero single insertion has a retained cap no more restrictive than
the full cap and lies below the latter's actual native ceiling. -/
theorem extend_public (i : Fin 39) (x : Fin 38 → State) (z : State)
    (hit : rawState (i.insertNth (α := fun _ => State) z x) ≠ 0) :
    ∃ c f, maxClass x = some c ∧ c ≤ f ∧ z.1.val + NativeContractions.total x ≤ T.maxIndex f :=
  extend i x z hit

theorem finite_of_runs (h : Runs) : FiniteCells := by
  classical
  intro i x
  by_cases occupied : ∃ w,rawState (i.insertNth (α := fun _ => State) w x) ≠ 0
  · obtain ⟨w,hw⟩ := occupied
    obtain ⟨c,f,hc,cf,room⟩ := extend i x w hw
    let j := NativeContractions.total x
    have cap := h.1 cf
    have base : j ≤ T.maxIndex c := by dsimp [j]; omega
    right
    refine ⟨T.maxIndex c-j,?_,?_⟩
    · intro z hit
      obtain ⟨c',f',hc',le',support⟩ := extend i x z hit
      rw [hc] at hc'
      obtain rfl := Option.some.inj hc'
      have L := h.1 le'
      dsimp [j]
      omega
    · have label : NativeContractions.label x = (T.sector c (j+1)).getD 170 := by
        have ng : ¬NativeContractions.total x > T.maxIndex c := not_lt.mpr base
        change NativeContractions.label x = (T.sector c (NativeContractions.total x+1)).getD 170
        cases sel : T.sector c (NativeContractions.total x+1) <;>
          simp [NativeContractions.label,NativeContractions.retained,hc,ng,sel]
      rw [label]
      cases sel : T.sector c (j+1) with
      | none =>
        have fixed : inactive 170 = true := by decide +kernel
        change 39*rho*rate (170:Fin 521) j*((((T.maxIndex c-j:ℕ):ℝ)+1)*Native.step) ≤ 0.01815
        rw [inactive_rate 170 fixed]
        simp only [mul_zero,zero_mul]; norm_num
      | some s => exact h.2 c j s base sel
  · push Not at occupied
    exact Or.inl occupied

#print axioms finite_of_runs

end PrimeGap180.PhysicalDebit
