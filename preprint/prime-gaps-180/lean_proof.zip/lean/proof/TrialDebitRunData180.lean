import TrialDebitRunCertificate180
import TrialDebitGeometry180

/-! Replay of the positive debit against the literal retained-sector runs. -/
noncomputable section
open PrimeGap180.FrozenProfile PrimeGap180.FrozenData PrimeGap180.CoarseLaw
open PrimeGap180.PhysicalDebit PrimeGap180.DebitRunCertificate
namespace PrimeGap180.DebitRunData

def stop (row : Array ℕ) := row[0]?.getD 0
def num (row : Array ℕ) := row[1]?.getD 0
def lab (row : Array ℕ) := Fin.ofNat 521 (num row - 1)

def runCheck (N l : ℕ) : List (Array ℕ) → Bool
  | [] => true
  | r :: rs =>
      let h := min N (stop r-2)
      let s := lab r
      endpointCheck s N l l && endpointCheck s N l h &&
        (decide (85897 < l) || inactive s) && runCheck N (stop r-1) rs

private theorem code_cons (r : Array ℕ) (rs : List (Array ℕ)) (n : ℕ) :
    debitCode (r::rs) n = if n < stop r then num r else debitCode rs n := by
  change num (((r::rs).find? (fun t => decide (n < stop t))).getD #[]) =
    if n < stop r then num r else num ((rs.find? (fun t => decide (n < stop t))).getD #[])
  by_cases ok : n < stop r <;> simp [ok]

private theorem sound (N : ℕ) (Ncap : N ≤ 130964) (rs : List (Array ℕ)) :
    ∀ (l j : ℕ) (s : Fin 521), l ≤ j → j ≤ N → debitCode rs (j+1) = s.val+1 →
      runCheck N l rs = true → (39*Sector.rho*rate s j*((((N-j:ℕ):ℝ)+1)*Native.step) ≤ 0.01815 ∧
      (j ≤ 85897 → rate s j=0)) := by
  induction rs with
  | nil =>
    intro l j s lj jN code ok
    change 0 = s.val+1 at code
    omega
  | cons r rs ih =>
    intro l j s lj jN code ok
    simp only [runCheck,Bool.and_eq_true,Bool.or_eq_true,decide_eq_true_eq] at ok
    rw [code_cons] at code
    by_cases here : j+1 < stop r
    · rw [ite_eq_left here] at code
      have label : lab r = s := by
        apply Fin.ext
        simp [lab,code,Fin.ofNat, Nat.mod_eq_of_lt s.isLt]
      have h : j ≤ min N (stop r-2) := le_min jN (by omega)
      rw [label] at ok
      exact ⟨run_sound s N l j _ lj h ((min_le_left _ _).trans Ncap) ok.1.1.1 ok.1.1.2,
        fun low => (ok.1.2.resolve_left (by omega)) |> fun on => inactive_rate s on j⟩
    · rw [ite_eq_right here] at code
      exact ih (stop r-1) j s (by omega) jN code ok.2

def checks := (List.finRange 44).all (fun c => runCheck (T.maxIndex c) 0 (debitSectorRows c))
def adjacent (k : Fin 43) : Bool := decide (T.maxIndex k.succ ≤ T.maxIndex k.castSucc)
def monotoneChecks := (List.finRange 43).all adjacent

set_option maxRecDepth 16000 in
set_option maxHeartbeats 0 in
theorem rows_checked : checks = true := by decide +kernel

set_option maxRecDepth 16000 in
set_option maxHeartbeats 0 in
theorem limits_checked : monotoneChecks = true := by decide +kernel

theorem bound (c : Fine) (j : ℕ) (s : Fin 521) (jN : j ≤ T.maxIndex c) (key : T.sector c (j+1) = some s) :
    39*Sector.rho*rate s j*((((T.maxIndex c-j:ℕ):ℝ)+1)*Native.step) ≤ 0.01815 ∧
      (j ≤ 85897 → rate s j = 0) := by
  exact sound _ (T.maxBound c) _ 0 j s (Nat.zero_le _) jN (debit_code_of_sector c _ s key)
    ((List.all_eq_true (l := List.finRange 44)
      (p := fun k => runCheck (T.maxIndex k) 0 (debitSectorRows k))).mp rows_checked c (List.mem_finRange c))

theorem bottom (x : Fin 38 → State) (h : NativeContractions.total x ≤ 85897) :
    rate (NativeContractions.label x) (NativeContractions.total x)=0 := by
  have off : inactive 170 = true := by decide +kernel
  have zero := inactive_rate 170 off (NativeContractions.total x)
  cases hc : CoarseForms.maxClass x with
  | none => simpa [NativeContractions.label,NativeContractions.retained,hc] using zero
  | some c =>
    by_cases large : NativeContractions.total x > T.maxIndex c
    · simpa [NativeContractions.label,NativeContractions.retained,hc,large] using zero
    · cases sel : T.sector c (NativeContractions.total x+1) with
      | none => simpa [NativeContractions.label,NativeContractions.retained,hc,large,sel] using zero
      | some s =>
        simpa [NativeContractions.label,NativeContractions.retained,hc,large,sel] using
          (bound c _ s (le_of_not_gt large) sel).2 h

theorem runs : Runs := by
  refine ⟨Fin.antitone_iff_succ_le.mpr (fun c => ?_),fun c j s h q => (bound c j s h q).1⟩
  have ok : adjacent c = true := (List.all_eq_true (l := List.finRange 43) (p := adjacent)).mp limits_checked c (List.mem_finRange c)
  exact of_decide_eq_true ok

theorem deleted : debit Restoration.deleted ≤ 0.01815*NumericalAccount.mass Restoration.deleted :=
  deleted_schur (row_of_cells (cells_of_finite (finite_of_runs runs)))

theorem restored
    (original : debit Restoration.original ≤ 0.000023397302*NumericalAccount.mass Restoration.original)
    (removed : NumericalAccount.mass Restoration.deleted ≤ 0.000160674*NumericalAccount.mass Restoration.original) :
    NumericalAccount.directDebit ≤ 0.000042838*NumericalAccount.mass Restoration.original :=
  receiver original (deleted) removed

#print axioms rows_checked
#print axioms limits_checked
#print axioms bottom
#print axioms deleted
#print axioms restored
end PrimeGap180.DebitRunData
