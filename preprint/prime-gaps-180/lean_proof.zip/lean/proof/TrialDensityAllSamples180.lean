import TrialDensitySampleBlock00180
import TrialDensitySampleBlock01180
import TrialDensitySampleBlock02180
import TrialDensitySampleBlock03180
import TrialDensitySampleBlock04180
import TrialDensitySampleBlock05180
import TrialDensitySampleBlock06180
import TrialDensitySampleBlock07180
import TrialDensitySampleBlock08180
import TrialDensitySampleBlock09180
import TrialDensitySampleBlock10180
namespace PrimeGap180.PackedFive
set_option maxRecDepth 10000
set_option maxHeartbeats 0
theorem all_samples : ∀ i : Fin 51, sample (i.val:Int) = unsignedEval (i.val:Int) words :=
  Fin.cases at00 (Fin.cases at01 (Fin.cases at02 (Fin.cases at03 (Fin.cases at04 (Fin.cases at05 (Fin.cases at06 (Fin.cases at07 (Fin.cases at08 (Fin.cases at09 (Fin.cases at10 (Fin.cases at11 (Fin.cases at12 (Fin.cases at13 (Fin.cases at14 (Fin.cases at15 (Fin.cases at16 (Fin.cases at17 (Fin.cases at18 (Fin.cases at19 (Fin.cases at20 (Fin.cases at21 (Fin.cases at22 (Fin.cases at23 (Fin.cases at24 (Fin.cases at25 (Fin.cases at26 (Fin.cases at27 (Fin.cases at28 (Fin.cases at29 (Fin.cases at30 (Fin.cases at31 (Fin.cases at32 (Fin.cases at33 (Fin.cases at34 (Fin.cases at35 (Fin.cases at36 (Fin.cases at37 (Fin.cases at38 (Fin.cases at39 (Fin.cases at40 (Fin.cases at41 (Fin.cases at42 (Fin.cases at43 (Fin.cases at44 (Fin.cases at45 (Fin.cases at46 (Fin.cases at47 (Fin.cases at48 (Fin.cases at49 (Fin.cases at50 ((fun i => Fin.elim0 i))))))))))))))))))))))))))))))))))))))))))))))))))))
#print axioms all_samples
end PrimeGap180.PackedFive
