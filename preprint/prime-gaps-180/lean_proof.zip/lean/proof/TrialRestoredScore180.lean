import TrialAdverseScore180

/-! The frozen native-cell receipt uses the original restored profile,
including both copies of the erased profile in each squared fibre. -/
noncomputable section
open scoped BigOperators Classical
open MeasureTheory PrimeGap186 PrimeGap180.Sector PrimeGap180.Detection
open PrimeGap180.FrozenData PrimeGap180.AdverseScore PrimeGap180.EndpointPhysical
namespace PrimeGap180.RestoredScore

def face (i : Fin 39) (s : Fin 521) :=
  integralFace mesh i (restrictFace i (fun t => label t = s) restored)

def income (i : Fin 39) := (∑ s : Fin 521,
    ((archivedPrice s).1*(∫ t, (face i s t)^2 ∂prodLaw 38) +
     (archivedPrice s).2*(∫ t, primePrice (Native.adverse (d := 38) (Native.cellSum t))*
       (face i s t)^2 ∂prodLaw 38)))/(10^14:ℝ)

def endpoint := ∫ r, (2*rho^2/(ledger-Native.adverse (d := 37) (Native.cellSum r))^2)*
  (∫ l, ∫ h, restored (EndpointPhysical.join r l h) ∂law ∂law)^2 ∂prodLaw 37

theorem income_eq (i : Fin 39) : AdverseScore.income i = income i := by
  rw [AdverseScore.income_exact]
  apply congrArg (fun v : ℝ => v/(10^14:ℝ))
  apply Finset.sum_congr rfl
  intro s _
  let V := integralFace mesh i (restrictFace i (fun r => label r=s) trial)
  have same : V =ᵐ[prodLaw 38] face i s := FrozenData.face_eq i _
  have square := integral_congr_ae (same.mono fun _ e => congrArg (·^2) e)
  have priced := integral_congr_ae (same.mono fun t e =>
    congrArg (fun z => primePrice (Native.adverse (d := 38) (Native.cellSum t))*z^2) e)
  change (archivedPrice s).1*(∫ t, (V t)^2 ∂prodLaw 38) +
    (archivedPrice s).2*(∫ t, primePrice (Native.adverse (d := 38) (Native.cellSum t))*(V t)^2 ∂prodLaw 38) = _
  rw [square,priced]

theorem endpoint_eq : AdverseScore.endpoint = endpoint := by
  rw [AdverseScore.endpoint_exact]
  apply integral_congr_ae
  filter_upwards [FrozenData.double_face_eq] with r h
  exact congrArg (fun z => (2*rho^2/(ledger-Native.adverse (d := 37) (Native.cellSum r))^2)*z^2) h

def Margin : Prop := (∫ v, (restored v)^2 ∂prodLaw 39) + endpoint < rho*∑ i : Fin 39, income i

theorem native_iff : ((∫ v, (trial v)^2 ∂prodLaw 39) + AdverseScore.endpoint <
    rho*∑ i : Fin 39, AdverseScore.income i) ↔ Margin := by
  unfold Margin
  simp only [FrozenData.ordinary_eq,endpoint_eq,income_eq]

#print axioms native_iff
end PrimeGap180.RestoredScore
