import TrialPriceTransposeGroupCommand180
import TrialPriceIsolatedChecks180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section
namespace PrimeGap180.PriceIsolatedGroup.G427
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 427

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G427
namespace PrimeGap180.PriceIsolatedGroup.G428
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 428

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G428
namespace PrimeGap180.PriceIsolatedGroup.G429
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 429

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G429
namespace PrimeGap180.PriceIsolatedGroup.G430
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 430

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G430
