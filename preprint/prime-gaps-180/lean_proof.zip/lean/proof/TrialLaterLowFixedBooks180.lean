import TrialLaterLowFixedWeights180

/-! The closed fixed-point books dominate the gamma quadrature for the
physical edge cutoff and every integer pair of positive scalar tilts. -/
noncomputable section
open Set MeasureTheory PrimeGap180.FrozenProfile
open scoped BigOperators NNReal
namespace PrimeGap180.LaterLowFixed
open LaterLowFiniteSite (book majorant node step)
open LaterLowFactor (a survival panel)
open LaterLowRational (rationalE1)

def W (u : ℕ) : ℝ := R u/(S:ℝ)
def G (e b r k : ℕ) := majorant ((e:ℝ)/2624990) (sQ b k:ℝ) r

private theorem Wadd (u v : ℕ) : W (u+v)=W u+W v := by unfold W; rw [Radd,add_div]
private theorem Wmul (u v : ℕ) : W (u*v)=R u*R v := by unfold W R asQ; push_cast; ring

private theorem site_sound {e b : ℕ} (he : 0<e) (hb : 0<b) (r k : ℕ) : G e b r k ≤ R (siteU e b r k) := by
  have sp : 0<(sQ b k:ℝ) := by unfold sQ; push_cast; positivity
  by_cases rz : r=0
  · subst r
    simp only [G,majorant,Nat.cast_zero,add_zero,sub_self,Real.exp_zero]
    unfold R
    exact_mod_cast site_erased e b k
  have re := LaterLowRational.retained (e:=(e:ℝ)/2624990) (s:=(sQ b k:ℝ)) (by positivity) sp (Nat.cast_nonneg r)
  have h := (Rat.cast_le (K:=ℝ)).mpr (site_retained (k:=k) he hb (Nat.pos_of_ne_zero rz))
  push_cast only [Rat.cast_div,Rat.cast_add,Rat.cast_mul,Rat.cast_natCast,Rat.cast_ofNat,castRat] at h
  apply re.trans
  convert h using 1 <;> first | rfl' | (rw [mul_div_assoc])

private theorem Gpos {b : ℕ} (hb : 0<b) (e r k : ℕ) : 0≤G e b r k := by
  unfold G majorant sQ
  push_cast
  positivity

private theorem acc {e b : ℕ} (he : 0<e) (hb : 0<b) (r n : ℕ) :
    Real.exp (-node n) ≤ R (accum e b r n).1 ∧
    (∑ k∈Finset.range n,panel step k*G e b r k) ≤ W (accum e b r n).2 := by
  induction n with
  | zero => norm_num [accum,node,R,W,asQ,S]
  | succ k ih =>
    let st:=accum e b r k
    refine ⟨next_node ih.1,?_⟩
    rw [Finset.sum_range_succ]
    change _ ≤ W (st.2+up (asQ st.1*panelQ k)*siteU e b r k)
    rw [Wadd,Wmul]
    exact add_le_add ih.2 (mul_le_mul (gamma_panel ih.1) (site_sound he hb r k) (Gpos hb e r k) (Rnn _))

theorem book_sound {e b : ℕ} (he : 0<e) (hb : 0<b) (r : ℕ) :
    book 1600 (G e b r) ≤ W (bookU e b r) := by
  let st:=accum e b r 1600
  obtain ⟨dec,sum⟩ := acc he hb r 1600
  have atom : a^2 ≤ R (up ((21/200:ℚ)^2)) := by
    convert Rup ((21/200:ℚ)^2) using 1 <;> norm_num [a]
  change _ ≤ W (up ((21/200:ℚ)^2)*siteU e b r 0+st.2+up (asQ st.1*densityQ 1600)*siteU e b r 1600)
  rw [Wadd,Wadd,Wmul,Wmul]
  exact add_le_add (add_le_add (mul_le_mul atom (site_sound he hb r 0) (Gpos hb e r 0) (Rnn _)) sum)
    (mul_le_mul (gamma_tail dec) (site_sound he hb r 1600) (Gpos hb e r 1600) (Rnn _))

theorem actual_book (j : Active) {e b : ℕ} (he : 0<e) (hb : 0<b)
    (edge : LaterLowTransform.edge (FrozenData.tables.tailEdge j)=(e:ℝ)/2624990) (r : ℕ) :
    book 1600 (fun k=>majorant (LaterLowTransform.edge (FrozenData.tables.tailEdge j))
      (((b:ℝ≥0)+LaterLowFiniteSite.shift k:ℝ≥0):ℝ) (r:ℝ)) ≤ W (bookU e b r) := by
  have eq (k : ℕ) : (((b:ℝ≥0)+LaterLowFiniteSite.shift k:ℝ≥0):ℝ)=(sQ b k:ℝ) := by
    rw [NNReal.coe_add]
    change (b:ℝ)+LaterLowFactor.w*node k=(sQ b k:ℝ)
    unfold sQ node step LaterLowFactor.w
    push_cast
    ring
  simp_rw [eq,edge]
  exact book_sound he hb r

#print axioms actual_book
end PrimeGap180.LaterLowFixed
