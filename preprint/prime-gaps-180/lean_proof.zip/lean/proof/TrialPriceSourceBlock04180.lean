import TrialPriceFrozenSourceRows180
namespace PrimeGap180.PriceFactorSourceProof
set_option maxRecDepth 131072
set_option maxHeartbeats 100000000
set_option profiler true in
private theorem m40 : PriceFactorData.sourceCheck 40 = true := by decide +kernel
set_option profiler true in
private theorem m41 : PriceFactorData.sourceCheck 41 = true := by decide +kernel
set_option profiler true in
private theorem m42 : PriceFactorData.sourceCheck 42 = true := by decide +kernel
set_option profiler true in
private theorem m43 : PriceFactorData.sourceCheck 43 = true := by decide +kernel
set_option profiler true in
private theorem m44 : PriceFactorData.sourceCheck 44 = true := by decide +kernel
set_option profiler true in
private theorem m45 : PriceFactorData.sourceCheck 45 = true := by decide +kernel
set_option profiler true in
private theorem m46 : PriceFactorData.sourceCheck 46 = true := by decide +kernel
set_option profiler true in
private theorem m47 : PriceFactorData.sourceCheck 47 = true := by decide +kernel
set_option profiler true in
private theorem m48 : PriceFactorData.sourceCheck 48 = true := by decide +kernel
set_option profiler true in
private theorem m49 : PriceFactorData.sourceCheck 49 = true := by decide +kernel
theorem batch4 : ∀ i : Fin 10, PriceFactorData.sourceCheck (40+i.val) = true :=
  Fin.cases m40 (Fin.cases m41 (Fin.cases m42 (Fin.cases m43 (Fin.cases m44 (Fin.cases m45 (Fin.cases m46 (Fin.cases m47 (Fin.cases m48 (Fin.cases m49 (fun i => Fin.elim0 i))))))))))
#print axioms batch4
end PrimeGap180.PriceFactorSourceProof
