import TrialMarkedLogUpper180
import TrialPriceEvents180
namespace PrimeGap180.MarkedLogs

def D : Nat := 10^10
def scale : Nat := 10^22

def upperTicks (i : Fin 11) (k : Fin 3) : Nat :=
  if k = 0 then ![11062185971047398041,18464213915969019563,37031021817303448037,37168661326023505250,37307327829567481563,37447032865348200420,18776233559799563410,18811554584446062781,18847008748303262882,19152106649439403717,14862281463190252994] i
  else if k = 1 then ![2900335781833635913,4832024430789701535,9657049959528119336,9647733094755528319,9638434189983315636,9629153193329590739,4811101805069371201,4808788248042731175,4806476915027864872,4804167802819414382,3841673171804831592] i
  else ![3367629004266064050733,3415681794223314938476,3511765809745608841926,3607824777800536640814,3703863138489664949191,3799885326207972990065,3847891739694001741616,3895895770874395928344,3943897972991015721994,3991898899159269593030,4030299093047318110894] i
def top (i : Fin 12) := PriceEvents.topTicks i
def low (i : Fin 12) := 1000 * PriceEvents.lowTicks i

def num (j : Fin 11) (k : Fin 3) :=
  if k=0 then low j.castSucc else if k=1 then top j.succ else top j.succ-(D-2*top j.succ)
def den (j : Fin 11) (k : Fin 3) :=
  if k=0 then low j.succ else if k=1 then top j.castSucc else D-2*top j.succ

def argument (j : Fin 11) (k : Fin 3) : ℚ := (num j k:ℚ)/(den j k:ℚ)
def ceiling (j : Fin 11) (k : Fin 3) : ℚ := (upperTicks j k:ℚ)/scale

set_option maxRecDepth 65536 in
set_option maxHeartbeats 0 in
private theorem checked : ∀ j : Fin 11, ∀ k : Fin 3, 1 ≤ argument j k ∧
    upper (argument j k) 16 ≤ ceiling j k := by decide +kernel

theorem log_ceiling (j : Fin 11) (k : Fin 3) :
    Real.log (argument j k:ℝ) ≤ (ceiling j k:ℝ) :=
  (log_upper _ (checked j k).1 16).trans (by exact_mod_cast (checked j k).2)

#print axioms log_ceiling
end PrimeGap180.MarkedLogs
