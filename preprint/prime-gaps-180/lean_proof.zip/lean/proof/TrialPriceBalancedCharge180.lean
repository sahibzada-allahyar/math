import TrialPriceActionDiagonal180

noncomputable section
namespace PrimeGap180.PriceActionDiagonal
open Book PriceRows

/-- Evaluate the absolute row sum in five balanced levels while retaining the
exact frozen-ledger theorem. -/
def balancedCheck (g : Group) (U : Array Int) (A : Book.Row → Int) (e : Book.Event) : Prop :=
  let x := signedCode g U A e
  let d := lane g x
  let i := 75 + PriceScalar.eventIndex e
  (PriceValues.event g.val (PriceScalar.eventIndex e) : ℤ) =
    lane g U[i]! + max 0 ((PriceBalancedDigits.plan 5 445).evaluate PriceRows.base center x - |d| - d)

instance (g : Group) (U : Array Int) (A : Book.Row → Int) (e : Book.Event) :
    Decidable (balancedCheck g U A e) := by unfold balancedCheck; infer_instance

theorem event_of_balanced_check {g : Group} {U : Array Int} {A : Book.Row → Int} {e : Book.Event}
    (values : moments g = U) (passed : balancedCheck g U A e) : eventPass g U A e := by
  apply event_of_check values
  simpa only [check, balancedCheck, PriceBalancedDigits.balanced_sum (by decide : 1 < PriceRows.base)] using passed

#print axioms event_of_balanced_check
end PrimeGap180.PriceActionDiagonal
