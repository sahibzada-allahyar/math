import TrialFrozenLedger180

/-! A second, less sensitive comparison for the native-to-physical Rayleigh
quotient. It leaves the same signed local deletion charges to be certified. -/
noncomputable section
open scoped Classical BigOperators InnerProductSpace
open MeasureTheory PrimeGap186 PrimeGap180.Sector PrimeGap180.Detection
open PrimeGap180.FrozenData PrimeGap180.AdverseScore PrimeGap180.NumericalAccount
namespace PrimeGap180.RobustTransfer

/-- If a positive root multiplier maps x to a y, with x and y normalized,
a pointwise range around m bounds their distance without a spectral argument. -/
theorem normalization {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (x y : E) (a m : ℝ) (hx : ‖x‖ = 1) (hy : ‖y‖ = 1) :
    a*m*‖y-x‖^2 = ‖a • y - m • x‖^2 - (a-m)^2 := by
  simp only [norm_sub_sq_real,norm_smul,Real.norm_eq_abs,sq_abs,hx,hy,mul_one,
    real_inner_smul_left,real_inner_smul_right]
  ring_nf

theorem quadratic_drift {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (x y : E) (A : E →L[ℝ] E) (hx : ‖x‖ = 1) (hy : ‖y‖ = 1) :
    |⟪y,A y⟫_ℝ - ⟪x,A x⟫_ℝ| ≤ 2*‖A‖*‖y-x‖ := by
  have expand : ⟪y,A y⟫_ℝ - ⟪x,A x⟫_ℝ = ⟪y-x,A y⟫_ℝ + ⟪x,A (y-x)⟫_ℝ := by
    rw [map_sub,inner_sub_left,inner_sub_right]
    ring
  have left := (abs_real_inner_le_norm (y-x) (A y)).trans
    (mul_le_mul_of_nonneg_left (A.le_opNorm y) (norm_nonneg _))
  have right := (abs_real_inner_le_norm x (A (y-x))).trans
    (mul_le_mul_of_nonneg_left (A.le_opNorm _) (norm_nonneg _))
  rw [hy,mul_one] at left
  rw [hx,one_mul] at right
  rw [expand]
  exact (abs_add_le _ _).trans (by linarith only [left,right])

/-- The low and middle group charges are shared with the sharper numerical
account. The uncut and positive debit bounds below are both weaker. -/
structure Bounds : Prop where
  positive : 0 < mass Restoration.original
  uncut : 1.00119224 * mass Restoration.original ≤ numerator Restoration.original
  removed : restoredLoss ≤ (0.000071406420 + 0.001035091858) * mass Restoration.original
  debit : directDebit ≤ 0.000042838 * mass Restoration.original

theorem excess (b : Bounds) :
    0.00004290 * mass Restoration.original < numerator trial - mass trial - directDebit := by
  have eq := Restoration.ordinary_split
  change mass Restoration.original = mass trial + mass Restoration.deleted at eq
  have r := b.removed
  unfold restoredLoss at r
  linarith only [b.positive,b.uncut,r,b.debit,eq]

theorem margin (b : Bounds) : Terminal.Margin := by
  apply historical_margin
  have gain : 0 < numerator trial - mass trial - directDebit :=
    (mul_pos (by norm_num : (0:ℝ) < 0.00004290) b.positive).trans (excess b)
  unfold numerator at gain
  have hist : historical trial = rho*∑ i : Fin 39, historicalIncome i := by
    simp only [historical,historical_exact]
  rw [hist] at gain
  change mass trial + pairFor trial + directDebit < _
  linarith only [gain]

theorem gap (input : SourceSchedule.Inputs) (prices : FrozenLedger.Endpoints)
    (kernels : Book.KernelChecks FrozenLedger.ledger) (densities : Terminal.DensityIntegrals)
    (mesh : FrozenPairGate.MeshChecks) (cover : Terminal.SourceCoverage FrozenLedger.ledger)
    (half : Terminal.ResolvedHalf) (b : Bounds) : primeGapLiminf ≤ (180 : EReal) :=
  Terminal.gap_of_frozen_margin input FrozenLedger.ledger (FrozenLedger.finiteChecks prices)
    kernels FrozenLedger.slots densities mesh cover half (margin b)

#print axioms normalization
#print axioms quadratic_drift
#print axioms excess
#print axioms gap
end PrimeGap180.RobustTransfer
