import TrialDensitySliceSemantics180
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Tactic.Ring
namespace PrimeGap180.PackedFive

theorem fac_eq (n : Nat) : fac n = n.factorial := by
  induction n with
  | zero => rfl
  | succ n ih => simp [fac,Nat.factorial_succ,ih]

theorem addTerms_sum (n : Nat) (f : Nat → Int) :
    addTerms n f = ∑ j ∈ Finset.range (n+1), f j := by
  have aux (l : List Nat) (z : Int) :
      l.foldr (fun j s => f j+s) z = (l.map f).sum + z := by
    induction l with
    | nil => simp
    | cons a l ih => simp [ih,add_assoc]
  have rangeSum (k : Nat) : ((List.range k).map f).sum = ∑ j ∈ Finset.range k, f j := by
    induction k with
    | zero => simp
    | succ k ih => simp [List.range_succ,Finset.sum_range_succ,ih]
  simp [addTerms,aux,rangeSum]

private theorem triangle_box (n k : Nat) (hk : k ≤ n) (f : Nat → Int) :
    (∑ l ∈ Finset.range (n-k+1), f l) =
    ∑ l ∈ Finset.range (n+1), if k+l ≤ n then f l else 0 := by
  rw [← Finset.sum_filter]
  have E : (Finset.range (n+1)).filter (fun l => k+l ≤ n) = Finset.range (n-k+1) := by
    ext l; simp; omega
  rw [E]

theorem triangle_swap (n : Nat) (f : Nat → Nat → Int) :
    (∑ k ∈ Finset.range (n+1), ∑ l ∈ Finset.range (n-k+1), f k l) =
     ∑ l ∈ Finset.range (n+1), ∑ k ∈ Finset.range (n-l+1), f k l := by
  have box (g : Nat → Nat → Int) :
      (∑ k ∈ Finset.range (n+1), ∑ l ∈ Finset.range (n-k+1), g k l) =
       ∑ k ∈ Finset.range (n+1), ∑ l ∈ Finset.range (n+1), if k+l≤n then g k l else 0 := by
    apply Finset.sum_congr rfl; intro k hk
    exact triangle_box n k (by simpa [Nat.lt_succ_iff] using hk) _
  rw [box f,box (fun l k => f k l),Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j hj
  apply Finset.sum_congr rfl
  intro k hk
  rw [Nat.add_comm k j]

#print axioms triangle_swap
end PrimeGap180.PackedFive
