import TrialMinorantMoment180

/-! Transfer the scheduled signed moment directly to the harmonic diagonal
for two independently chosen canonical sector arrays. -/
noncomputable section
open scoped Classical BigOperators
open Filter PrimeGap186 PrimeGap182.Selberg PrimeGap180.Signed
namespace PrimeGap180.Distribution

abbrev SectorArray := (Fin 38 → ℕ) →₀ ℝ

def descendants (z : SectorArray) : Finset (Fin 38 → ℕ) :=
  z.support.biUnion fun r => Fintype.piFinset fun j => (r j).divisors

def sectorAmplitude (z : SectorArray) (h : Fin 39 → ℕ) (i : Fin 39) (n : ℕ) : ℝ :=
  ∑ d ∈ descendants z, if ∀ j, d j ∣ n+h (i.succAbove j) then PrimeGap182.Selberg.selbergCoefficient z d else 0

def harmonicPair (z t : SectorArray) : ℝ :=
  z.sum fun r a => a * t r / ∏ j, ((r j).totient : ℝ)

private theorem descendant_support {q W : ℕ} (cop : Nat.Coprime q W)
    {z : SectorArray} (roots : ∀ r ∈ z.support,
      Squarefree (∏ j, r j) ∧ ∀ j, r j ∈ q.divisors)
    {d : Fin 38 → ℕ} (hd : d ∈ descendants z) :
    Squarefree (∏ j, d j) ∧ Nat.Coprime (∏ j, d j) W := by
  obtain ⟨r,hr,hdr⟩ := Finset.mem_biUnion.mp hd
  have divs := Fintype.mem_piFinset.mp hdr
  have sub := Finset.prod_dvd_prod_of_dvd (s := Finset.univ) d r
    (fun j _ => Nat.dvd_of_mem_divisors (divs j))
  obtain ⟨sq,coord⟩ := roots r hr
  have divq : (∏ j, r j) ∣ q := by
    apply sq.isRadical 38 q
    simpa only [Finset.prod_const,Finset.card_univ,Fintype.card_fin] using
      Finset.prod_dvd_prod_of_dvd (s := Finset.univ) r (fun _ => q)
        (fun j _ => Nat.dvd_of_mem_divisors (coord j))
  exact ⟨sq.squarefree_of_dvd sub,cop.coprime_dvd_left (sub.trans divq)⟩

/-- The first error is distributional. The second has the absolute mass
of the actual signed row and an arbitrarily small relative constant. -/
theorem scheduled_diagonal_moment {ι : Type*} [Fintype ι] [Nonempty ι] [DecidableEq ι]
    (ch : ℝ → Literal.Channel) (bands : ι → ProvedBand ch)
    (cuts : ∀ᶠ x : ℝ in atTop, Literal.admissible x (x^(0.1668:ℝ)) (ch x))
    (H : Finset ℕ) (hH : H.card = 39) (i : Fin 39)
    (κ M N A ε : ℝ) (hκ : 0 < κ) (hM : 0 ≤ M) (hN : 0 ≤ N)
    (hA : 0 < A) (hε : 0 < ε) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      let h := H.orderEmbOfFin hH
      let W := presievingModulus H x
      let R := x ^ (2624989/10000000 : ℝ)
      let B := fragmentNormalization W R
      let q := ∏ p ∈ fragmentPrimes W R κ, p
      ∀ (z t : SectorArray),
      (∀ r ∈ z.support, Squarefree (∏ j, r j) ∧ ∀ j, r j ∈ q.divisors) →
      (∀ r ∈ t.support, Squarefree (∏ j, r j) ∧ ∀ j, r j ∈ q.divisors) →
      (∀ r, |z r| ≤ M/B^38) → (∀ r, |t r| ≤ N/B^38) →
      ∀ (v : ℕ), Nat.Coprime (v+h i) W →
      ∀ U V : ℝ, 0 ≤ U → 0 ≤ V →
      (∀ d ∈ descendants z, |PrimeGap182.Selberg.selbergCoefficient z d| ≤ U) →
      (∀ e ∈ descendants t, |PrimeGap182.Selberg.selbergCoefficient t e| ≤ V) →
      ∀ I : Finset ℕ, (∀ p ∈ I, p.Prime) →
      (∀ d ∈ descendants z, ∀ e ∈ descendants t,
        (∀ j k : Fin 38, j ≠ k → Nat.Coprime (d j) (e k)) →
        let Q := W.lcm ((∏ j, d j).lcm (∏ j, e j))
        (∃ j, Q ∈ (bands j).toSieveBand.moduli x I) ∧
          ∀ p : ℕ, p.Prime → p ∣ Q → (p:ℝ) ≤ x^(0.1668:ℝ)) →
      let f := Literal.value (ch x)
      let mass := (∑ n ∈ window x, f (n+h i))/(W.totient : ℝ)
      |(∑ n ∈ window x, if Nat.ModEq W n v then
        f (n+h i)*sectorAmplitude z h i n*sectorAmplitude t h i n else 0) -
          mass*harmonicPair z t| ≤ U*V*(C*x/(Real.log x)^A) + |mass| *(ε/B^38) := by
  classical
  let h := H.orderEmbOfFin hH
  obtain ⟨C,hC,law⟩ := scheduled_minorant_moment ch bands cuts h h.injective i A hA
  refine ⟨C,hC,?_⟩
  filter_upwards [law,selberg38_prime_bilinear_comparison (𝓗 := H) (h𝓗_card := hH)
    i κ M N hκ hM hN ε hε] with x moment diagonal
  intro h' W R B q z t hz ht bz bt v hv U V hU hV bu bv I hp gate f mass
  have cop : Nat.Coprime q W := by
    apply Nat.Coprime.prod_left
    intro p mem
    exact (Nat.prime_of_mem_primesLE (Finset.mem_filter.mp mem).1).coprime_iff_not_dvd.mpr
      (Finset.mem_filter.mp mem).2
  have cover (j k : Fin 39) (neq : h j ≠ h k) (p : ℕ) (pr : p.Prime)
      (dv : p ∣ Nat.dist (h j) (h k)) : p ∣ W :=
    PrimeGap182.Selberg.difference_prime_dvd_presieving H x (H.orderEmbOfFin_mem hH j)
      (H.orderEmbOfFin_mem hH k) neq pr dv
  have weighted := moment (descendants z) (descendants t) _ _ W v (presieving_pos H x)
    (fun _ hd => descendant_support cop hz hd) (fun _ he => descendant_support cop ht he)
    cover hv U V hU hV bu bv I hp gate
  have diag := diagonal.2 z t hz ht bz bt
  have add_errors (a b c m E D : ℝ) (left : |a-m*b| ≤ E) (right : |b-c| ≤ D) :
      |a-m*c| ≤ E + |m| *D := by
    calc
      _ = |(a-m*b)+m*(b-c)| := by ring_nf
      _ ≤ |a-m*b| + |m*(b-c)| := abs_add_le _ _
      _ ≤ _ := by rw [abs_mul]; exact add_le_add left (mul_le_mul_of_nonneg_left right (abs_nonneg _))
  exact add_errors _ _ _ mass _ _ weighted diag

#print axioms scheduled_diagonal_moment

end PrimeGap180.Distribution
