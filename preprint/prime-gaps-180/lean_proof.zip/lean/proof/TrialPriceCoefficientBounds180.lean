import TrialLedgerIdentities180

/-! Uniform no-carry bound for the signed positional residual. It uses the
native 64-bit coefficient bound, the 445-column rank limit, and the actual
incidence counts and signed-row values of the physical book. -/
noncomputable section
open scoped BigOperators
open PrimeGap180.Book PrimeGap180.Price
namespace PrimeGap180.PriceCoefficientBounds

def wordBound : ℤ := 2^63
def gramBound : ℤ := 445*wordBound^2

private theorem sum_bound {ι : Type*} [Fintype ι] (f : ι → ℤ) (U : ℤ) (bound : ∀ i, |f i| ≤ U) :
    |∑ i, f i| ≤ (Fintype.card ι:ℤ)*U := by
  calc
    _ ≤ ∑ i, |f i| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _ : ι, U := Finset.sum_le_sum fun i _ => bound i
    _ = _ := by simp

theorem gram_bound {r : ℕ} (rank : r ≤ 445) (F : Group → Fin r → ℤ)
    (bound : ∀ i j, |F i j| ≤ wordBound) (g h : Group) : |intGram F g h| ≤ gramBound := by
  have term (j : Fin r) : |F g j*F h j| ≤ wordBound^2 := by
    rw [abs_mul,pow_two]
    exact mul_le_mul (bound g j) (bound h j) (abs_nonneg _) (by norm_num [wordBound])
  have vals := sum_bound _ _ term
  calc
    |intGram F g h| ≤ (r:ℤ)*wordBound^2 := by simpa only [intGram,Fintype.card_fin] using vals
    _ ≤ 445*wordBound^2 := mul_le_mul_of_nonneg_right (by exact_mod_cast rank) (sq_nonneg _)

private theorem row_size : Fintype.card Book.Row = 14 := by decide +kernel
private theorem resource_size : Fintype.card Resource = 49 := by decide +kernel

set_option maxRecDepth 131072 in
private theorem row_bounds : ∀ (k : Book.Row) (e : Book.Event), |LedgerData.rowValue k e| ≤ 1 := by decide +kernel

set_option maxRecDepth 131072 in
private theorem counts : ∀ (u : Resource) (e : Book.Event), |LedgerData.incidence u e| ≤ 24 := by decide +kernel

theorem residual (b : Ledger)
    (floorBound : ∀ g, |b.floors g| ≤ wordBound)
    (affineBound : ∀ k g h, |b.affine k g h| ≤ wordBound)
    (resourceBound : ∀ u g h, |intGram (b.factor u) g h| ≤ gramBound)
    (positiveBound : ∀ e g h, |intGram (b.positive e) g h| ≤ gramBound)
    (negativeBound : ∀ e g h, |intGram (b.negative e) g h| ≤ gramBound)
    (form : ∀ e g h, b.remainder e g h = LedgerData.residual b.floors b.affine b.rank b.factor e g h)
    (e : Book.Event) (g h : Group) :
    |intRemainder (b.remainder e) (b.positive e) (b.negative e) g h| < 2^170 := by
  have aff := sum_bound (fun k => LedgerData.rowValue k e * b.affine k g h) wordBound fun k => by
    rw [abs_mul]
    calc
      _ ≤ 1*wordBound := mul_le_mul (row_bounds k e) (affineBound k g h) (abs_nonneg _) (by norm_num)
      _ = _ := one_mul _
  have resources := sum_bound (fun u => LedgerData.incidence u e * intGram (b.factor u) g h) (24*gramBound) fun u => by
    rw [abs_mul]
    exact mul_le_mul (counts u e) (resourceBound u g h) (abs_nonneg _) (by norm_num)
  rw [row_size] at aff
  rw [resource_size] at resources
  have floorProd : |24*b.floors g*b.floors h| ≤ 24*wordBound^2 := by
    simp only [abs_mul,abs_of_nonneg (by norm_num : (0:ℤ) ≤ 24),pow_two,mul_assoc]
    apply mul_le_mul_of_nonneg_left _ (by norm_num)
    exact mul_le_mul (floorBound g) (floorBound h) (abs_nonneg _) (by norm_num [wordBound])
  have root : |(if e = .prime then 24*b.floors g*b.floors h else 0)| ≤ 24*wordBound^2 := by
    split
    · exact floorProd
    · norm_num [wordBound]
  have negG := negativeBound e g h
  have posG := positiveBound e g h
  rw [intRemainder,form,LedgerData.residual]
  rw [abs_lt]
  rw [abs_le] at aff resources root negG posG
  norm_num [wordBound,gramBound] at aff resources root negG posG ⊢
  constructor <;> omega

end PrimeGap180.PriceCoefficientBounds
