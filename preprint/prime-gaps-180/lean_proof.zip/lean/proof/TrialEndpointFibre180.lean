import OrdinarySelberg182
import SelbergPolarization182

/-! Harmonic averaging on the two endpoint coordinates. The auxiliary
uses the full legal Selberg support and the original signed coefficients. -/
noncomputable section
open scoped BigOperators Classical
open Filter PrimeGap186 PrimeGap182.Selberg PrimeGap182Analytic
namespace PrimeGap180.Endpoint

variable {I : Type*} [Fintype I] [DecidableEq I]
abbrev Root (I : Type*) := I → ℕ

def retained (i j : I) (r : Root I) : Root I :=
  fun k => if k = i ∨ k = j then 1 else r k

def harmonic (r : Root I) : ℝ := 1 / ∏ k, ((r k).totient : ℝ)

def members (T : Finset (Root I)) (i j : I) (s : Root I) :=
  T.filter fun r => retained i j r = s

def volume (T : Finset (Root I)) (i j : I) (s : Root I) : ℝ :=
  ∑ r ∈ members T i j s, harmonic r

def integral (T : Finset (Root I)) (i j : I) (y : Root I →₀ ℝ) (s : Root I) : ℝ :=
  ∑ r ∈ members T i j s, y r * harmonic r

def average (T : Finset (Root I)) (i j : I) (y : Root I →₀ ℝ) (s : Root I) : ℝ :=
  integral T i j y s / volume T i j s

def lift (T : Finset (Root I)) (i j : I) (y : Root I →₀ ℝ) : Root I →₀ ℝ :=
  Finsupp.onFinset T (fun r => if r ∈ T then average T i j y (retained i j r) else 0)
    (fun r hr => by by_contra outside; simp [outside] at hr)

private theorem lift_inside {T : Finset (Root I)} (i j : I) (y : Root I →₀ ℝ)
    {r : Root I} (hr : r ∈ T) : lift T i j y r = average T i j y (retained i j r) := by
  simp [lift,hr]

private theorem split_sum (T : Finset (Root I)) (i j : I) (F : Root I → ℝ) :
    ∑ s ∈ T.image (retained i j), ∑ r ∈ members T i j s, F r = ∑ r ∈ T, F r :=
  Finset.sum_fiberwise_of_maps_to (fun _ hr => Finset.mem_image_of_mem _ hr) _

private theorem volume_pos {T : Finset (Root I)} (i j : I)
    (pos : ∀ r ∈ T, 0 < harmonic r) {s : Root I} (hs : s ∈ T.image (retained i j)) :
    0 < volume T i j s := by
  obtain ⟨r,hr,rfl⟩ := Finset.mem_image.mp hs
  apply Finset.sum_pos (fun t ht => pos t (Finset.mem_filter.mp ht).1)
  exact ⟨r,Finset.mem_filter.mpr ⟨hr,rfl⟩⟩

theorem lift_bound {T : Finset (Root I)} (i j : I) (y : Root I →₀ ℝ)
    (pos : ∀ r ∈ T, 0 < harmonic r) {M : ℝ} (hm : 0 ≤ M) (bound : ∀ r ∈ T, |y r| ≤ M)
    (r : Root I) : |lift T i j y r| ≤ M := by
  by_cases inside : r ∈ T
  · let s := retained i j r
    have v := volume_pos i j pos (Finset.mem_image_of_mem _ inside)
    rw [lift_inside i j y inside,average,abs_div,abs_of_pos v]
    apply (div_le_iff₀ v).mpr
    rw [volume,Finset.mul_sum]
    apply (Finset.abs_sum_le_sum_abs ..).trans
    apply Finset.sum_le_sum
    intro t ht
    have ok := (Finset.mem_filter.mp ht).1
    rw [abs_mul,abs_of_pos (pos t ok)]
    exact mul_le_mul_of_nonneg_right (bound t ok) (pos t ok).le
  · simpa [lift,inside] using hm

/-- Integration against any function of the retained coordinates is exact. -/
theorem lift_preserves {T : Finset (Root I)} (i j : I) (y : Root I →₀ ℝ)
    (pos : ∀ r ∈ T, 0 < harmonic r) (g : Root I → ℝ) :
    (∑ r ∈ T, g (retained i j r) * (lift T i j y r * harmonic r)) =
      ∑ r ∈ T, g (retained i j r) * (y r * harmonic r) := by
  rw [← split_sum T i j,← split_sum T i j (fun r => g (retained i j r)*(y r*harmonic r))]
  apply Finset.sum_congr rfl
  intro s hs
  have v := volume_pos i j pos hs
  have repl (r : Root I) (hr : r ∈ members T i j s) :=
    (lift_inside i j y (Finset.mem_filter.mp hr).1).trans
      (congrArg (average T i j y) (Finset.mem_filter.mp hr).2)
  calc
    _ = ∑ r ∈ members T i j s, g s * (average T i j y s * harmonic r) := by
      apply Finset.sum_congr rfl
      intro r hr
      rw [repl r hr,(Finset.mem_filter.mp hr).2]
    _ = g s * integral T i j y s := by
      rw [← Finset.mul_sum,← Finset.mul_sum,← volume,average,div_mul_cancel₀ _ v.ne']
    _ = _ := by
      rw [integral,Finset.mul_sum]
      exact Finset.sum_congr rfl fun r hr => by rw [(Finset.mem_filter.mp hr).2]

/-- Exact ordinary diagonal of the lifted array, with all normalization
already present in the sampled coefficients. -/
theorem lift_energy {T : Finset (Root I)} (i j : I) (y : Root I →₀ ℝ)
    (pos : ∀ r ∈ T, 0 < harmonic r) :
    diagonalHarmonic (fun r : Root I => ∏ k, ((r k).totient : ℝ)) (lift T i j y) =
      ∑ s ∈ T.image (retained i j), (integral T i j y s)^2 / volume T i j s := by
  unfold diagonalHarmonic
  rw [Finsupp.sum_of_support_subset _ (show (lift T i j y).support ⊆ T from
    Finsupp.support_onFinset_subset) _ (by simp),← split_sum T i j]
  apply Finset.sum_congr rfl
  intro s hs
  have v := volume_pos i j pos hs
  calc
    _ = ∑ r ∈ members T i j s, (average T i j y s)^2 * harmonic r := by
      apply Finset.sum_congr rfl
      intro r hr
      rw [lift_inside i j y (Finset.mem_filter.mp hr).1,(Finset.mem_filter.mp hr).2]
      simp [harmonic,div_eq_mul_inv]
    _ = _ := by
      rw [← Finset.mul_sum,← volume,average]
      field_simp

omit [Fintype I] in
private theorem compatible_retained (i j : I) (d r : Root I) (di : d i = 1) (dj : d j = 1) :
    (∀ k, d k ∣ r k) ↔ ∀ k, d k ∣ retained i j r k := by
  apply forall_congr'
  intro k
  by_cases e : k=i ∨ k=j
  · rcases e with rfl | rfl <;> simp [retained,di,dj]
  · simp [retained,e]

theorem lift_coefficient {T : Finset (Root I)} (i j : I) (y : Root I →₀ ℝ)
    (hy : y.support ⊆ T) (pos : ∀ r ∈ T, 0 < harmonic r)
    (d : Root I) (di : d i=1) (dj : d j=1) :
    PrimeGap182.Selberg.selbergCoefficient (lift T i j y) d =
      PrimeGap182.Selberg.selbergCoefficient y d := by
  let g (s : Root I) : ℝ := if ∀ k, d k ∣ s k then 1 else 0
  have expand (w : Root I →₀ ℝ) (hw : w.support ⊆ T) :
      w.sum (fun r a => if ∀ k, d k ∣ r k then a/(∏ k, ((r k).totient : ℝ)) else 0) =
        ∑ r ∈ T, g (retained i j r)*(w r*harmonic r) := by
    rw [w.sum_of_support_subset hw _ (by simp)]
    apply Finset.sum_congr rfl
    intro r _
    dsimp only [g]
    by_cases c : ∀ k, d k ∣ r k
    · simp [c,(compatible_retained i j d r di dj).mp c,harmonic,div_eq_mul_inv]
    · simp [c,(compatible_retained i j d r di dj).not.mp c]
  unfold PrimeGap182.Selberg.selbergCoefficient
  congr 1
  exact (expand (lift T i j y) Finsupp.support_onFinset_subset).trans
    ((lift_preserves i j y pos g).trans (expand y hy).symm)

private def below (T : Finset (Root I)) :=
  T.biUnion fun r => Fintype.piFinset fun k => (r k).divisors

private theorem root_on {T : Finset (Root I)} (y : Root I →₀ ℝ) (hy : y.support ⊆ T)
    (v : I → ℕ) :
    sampledSelbergRoot y v = ∑ d ∈ below T,
      if ∀ k, d k ∣ v k then PrimeGap182.Selberg.selbergCoefficient y d else 0 := by
  unfold sampledSelbergRoot
  apply Finset.sum_subset
  · intro d hd
    simp only [below, Finset.mem_biUnion, Fintype.mem_piFinset] at hd ⊢
    obtain ⟨r,hr,mem⟩ := hd
    exact ⟨r,hy hr,mem⟩
  · intro d _ outside
    have zero : PrimeGap182.Selberg.selbergCoefficient y d = 0 := by
      by_contra nz
      exact outside (PrimeGap182.Selberg.selbergCoefficient_mem_divisorClosure y d nz)
    simp [zero]

/-- Both endpoint primes are too large to occur in any descendant.
Thus the two full Selberg amplitudes agree on that event. -/
theorem lift_on_primes {T : Finset (Root I)} (i j : I) (y : Root I →₀ ℝ)
    (hy : y.support ⊆ T) (pos : ∀ r ∈ T, 0 < harmonic r) (v : I → ℕ)
    (hi : (v i).Prime) (hj : (v j).Prime) (size : ∀ r ∈ T, r i < v i ∧ r j < v j) :
    sampledSelbergRoot (lift T i j y) v = sampledSelbergRoot y v := by
  rw [root_on _ (show (lift T i j y).support ⊆ T from Finsupp.support_onFinset_subset),
    root_on y hy]
  apply Finset.sum_congr rfl
  intro d hd
  split
  · rename_i divs
    obtain ⟨r,hr,hdr⟩ := Finset.mem_biUnion.mp hd
    have coord (k : I) : d k ≤ r k := Nat.le_of_dvd (Nat.pos_of_ne_zero (Nat.mem_divisors.mp (Fintype.mem_piFinset.mp hdr k)).2)
      (Nat.dvd_of_mem_divisors (Fintype.mem_piFinset.mp hdr k))
    exact lift_coefficient i j y hy pos d
      ((Nat.dvd_prime hi).mp (divs i) |>.resolve_right (ne_of_lt ((coord i).trans_lt (size r hr).1)))
      ((Nat.dvd_prime hj).mp (divs j) |>.resolve_right (ne_of_lt ((coord j).trans_lt (size r hr).2)))
  · rfl

/-- All legal full roots of product at most L. Each retained fibre contains
exactly the allowed endpoint pairs, including both unit coordinates. -/
def legalRoots (I : Type*) [Fintype I] [DecidableEq I] (W L : ℕ) : Finset (Root I) :=
  (Fintype.piFinset (fun _ : I => Finset.Icc 1 L)).filter (fun r =>
    Squarefree (∏ k, r k) ∧ Nat.Coprime (∏ k, r k) W ∧ (∏ k, r k) ≤ L)

theorem mem_legalRoots {W L : ℕ} (r : Root I) :
    r ∈ legalRoots I W L ↔ Squarefree (∏ k, r k) ∧
      Nat.Coprime (∏ k, r k) W ∧ (∏ k, r k) ≤ L := by
  constructor
  · exact fun h => (Finset.mem_filter.mp h).2
  · intro h
    apply Finset.mem_filter.mpr
    refine ⟨Fintype.mem_piFinset.mpr (fun k => Finset.mem_Icc.mpr ⟨?_,?_⟩),h⟩
    · exact Nat.one_le_iff_ne_zero.mpr ((Finset.prod_ne_zero_iff.mp h.1.ne_zero) k (Finset.mem_univ _))
    · exact (Nat.le_of_dvd (Nat.pos_of_ne_zero h.1.ne_zero)
        (Finset.dvd_prod_of_mem r (Finset.mem_univ k))).trans h.2.2

abbrev rho : ℝ := 2624989/10000000

/-- Uniform endpoint-pair upper bound at the physical cap x^s. The two
chosen finite indices can in particular be the first and last of the tuple. -/
theorem prime_pair_upper {H : Finset ℕ} (hH : H.card = 39)
    (i j : Fin 39) {s M ε : ℝ} (hs : 0 < s) (half : s < 1/2)
    (hm : 0 ≤ M) (hε : 0 < ε) :
    ∀ᶠ x : ℝ in atTop,
      let h := H.orderEmbOfFin hH
      let W := presievingModulus H x
      let B := fragmentNormalization W (x^rho)
      let T := legalRoots (Fin 39) W ⌊x^s⌋₊
      ∀ (y : Root (Fin 39) →₀ ℝ) (v : ℕ), y.support ⊆ T →
        (∀ r, |y r| ≤ M/B^39) →
        (∑ n ∈ Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊, if Nat.ModEq W n v ∧
          (n+h i).Prime ∧ (n+h j).Prime then
          (sampledSelbergRoot y (fun k => n+h k))^2 else 0) ≤
          x/(W:ℝ)*(∑ t ∈ T.image (retained i j), (integral T i j y t)^2 / volume T i j t) +
          ε*(x/(W:ℝ)/B^39) := by
  let S := s/rho
  have rp : 0 < rho := by norm_num [rho]
  have scale : rho*S = s := by dsimp [S]; field_simp
  have law := selberg39_uniform_real_diagonal_radius (𝓗 := H) (h𝓗_card := hH)
    S (div_pos hs rp) (by rw [← scale] at half; exact half) M hm ε hε
  filter_upwards [law,eventually_gt_atTop (1:ℝ)] with x ordinary hx
  intro h W B T y v hy bound
  have xc : 0 ≤ x := zero_le_one.trans hx.le
  have powx : (x^rho)^S = x^s := by rw [← Real.rpow_mul xc,scale]
  have cut : x^s < x := by
    simpa using Real.rpow_lt_rpow_of_exponent_lt hx (by linarith : s < 1)
  have nonnegL : 0 ≤ M/B^39 := (abs_nonneg _).trans (bound (fun _ => 1))
  have hp (r : Root (Fin 39)) (hr : r ∈ T) : 0 < harmonic r := by
    have mem := Fintype.mem_piFinset.mp (Finset.mem_filter.mp hr).1
    apply one_div_pos.mpr
    apply Finset.prod_pos
    intro k _
    exact_mod_cast Nat.totient_pos.mpr (Finset.mem_Icc.mp (mem k)).1
  have valid (r : Root (Fin 39)) (hr : r ∈ (lift T i j y).support) := (mem_legalRoots r).mp
    (show r ∈ T from Finsupp.support_onFinset_subset hr)
  have sq := ordinary (lift T i j y) v (fun r hr => ⟨(valid r hr).1,(valid r hr).2.1,by
    rw [powx]
    exact (Nat.cast_le.mpr (valid r hr).2.2).trans (Nat.floor_le (Real.rpow_nonneg xc _))⟩)
    (lift_bound i j y hp nonnegL (fun r _ => bound r))
  have energy := lift_energy i j y hp
  unfold diagonalHarmonic at energy
  rw [energy] at sq
  apply le_trans _ (((sub_le_iff_le_add).mp (le_of_abs_le sq)).trans_eq (add_comm _ _))
  apply Finset.sum_le_sum
  intro n hn
  by_cases event : Nat.ModEq W n v ∧ (n+h i).Prime ∧ (n+h j).Prime
  · have below_n (r : Root (Fin 39)) (hr : r ∈ T) (k : Fin 39) : r k < n+h k := by
      have le := (Finset.mem_Icc.mp (Fintype.mem_piFinset.mp (Finset.mem_filter.mp hr).1 k)).2
      have cmp : (r k:ℝ) < n := ((Nat.cast_le.mpr le).trans
        (Nat.floor_le (Real.rpow_nonneg xc _))).trans_lt
          (cut.trans_le (Nat.ceil_le.mp (Finset.mem_Icc.mp hn).1))
      exact (Nat.cast_lt.mp cmp).trans_le (Nat.le_add_right _ _)
    have eqn := lift_on_primes i j y hy hp (fun k => n+h k) event.2.1 event.2.2
      (fun r hr => ⟨below_n r hr i,below_n r hr j⟩)
    rw [ite_eq_left event,ite_eq_left event.1,← eqn,sampledSelbergRoot_fin]
  · rw [ite_eq_right event]
    split
    · exact sq_nonneg _
    · exact le_rfl

/-- Replacing legal fibre volumes by larger volumes in the denominator
costs at most the missing harmonic mass times the squared sup norm.
This estimate stays uniform even when a legal fibre is very small. -/
theorem enlarge_denominator {T U : Finset (Root I)} (sub : T ⊆ U) (i j : I)
    (y : Root I →₀ ℝ) (pos : ∀ r ∈ U, 0 < harmonic r)
    {M : ℝ} (hm : 0 ≤ M) (bound : ∀ r ∈ T, |y r| ≤ M) :
    let keys := T.image (retained i j)
    (∑ t ∈ keys, (integral T i j y t)^2 / volume T i j t) ≤
      (∑ t ∈ keys, (integral T i j y t)^2 / volume U i j t) +
      M^2 * ((∑ r ∈ U, harmonic r) - ∑ r ∈ T, harmonic r) := by
  intro keys
  have subkeys : keys ⊆ U.image (retained i j) := Finset.image_subset_image sub
  have vtotal (D : Finset (Root I)) :
      ∑ t ∈ D.image (retained i j), volume D i j t = ∑ r ∈ D, harmonic r :=
    split_sum D i j harmonic
  have sumU : (∑ t ∈ keys, volume U i j t) ≤ ∑ r ∈ U, harmonic r := by
    rw [← vtotal U]
    exact Finset.sum_le_sum_of_subset_of_nonneg subkeys
      (fun t ht _ => (volume_pos i j pos ht).le)
  have point (t : Root I) (ht : t ∈ keys) :
      (integral T i j y t)^2 / volume T i j t ≤
        (integral T i j y t)^2 / volume U i j t +
        M^2 * (volume U i j t - volume T i j t) := by
    have hT := volume_pos i j (fun r hr => pos r (sub hr)) ht
    have hU := volume_pos i j pos (subkeys ht)
    have inc : volume T i j t ≤ volume U i j t :=
      Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset_filter _ sub)
        (fun r hr _ => (pos r (Finset.mem_filter.mp hr).1).le)
    obtain ⟨r,hr,he⟩ := Finset.mem_image.mp ht
    have hb := lift_bound i j y (fun r hr => pos r (sub hr)) hm bound r
    rw [lift_inside i j y hr,he,average,abs_div,abs_of_pos hT] at hb
    have hsq := mul_self_le_mul_self (abs_nonneg _) ((div_le_iff₀ hT).mp hb)
    have major : (integral T i j y t)^2 ≤ M^2 * (volume T i j t * volume U i j t) := by
      calc
        _ ≤ (M * volume T i j t)^2 := by simpa only [← pow_two, sq_abs] using hsq
        _ = M^2 * (volume T i j t * volume T i j t) := by ring
        _ ≤ _ := mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left inc hT.le) (sq_nonneg _)
    apply sub_le_iff_le_add'.mp
    calc
      _ = ((integral T i j y t)^2 / (volume T i j t * volume U i j t)) *
          (volume U i j t - volume T i j t) := by field_simp
      _ ≤ _ := mul_le_mul_of_nonneg_right ((div_le_iff₀ (mul_pos hT hU)).mpr major) (sub_nonneg.mpr inc)
  calc
    _ ≤ _ := Finset.sum_le_sum point
    _ = (∑ t ∈ keys, (integral T i j y t)^2 / volume U i j t) +
        M^2 * ((∑ t ∈ keys, volume U i j t) - ∑ r ∈ T, harmonic r) := by
      rw [Finset.sum_add_distrib,← Finset.mul_sum,Finset.sum_sub_distrib,vtotal T]
    _ ≤ _ := by gcongr

#print axioms enlarge_denominator
#print axioms lift_energy
#print axioms lift_coefficient
#print axioms prime_pair_upper
end PrimeGap180.Endpoint
