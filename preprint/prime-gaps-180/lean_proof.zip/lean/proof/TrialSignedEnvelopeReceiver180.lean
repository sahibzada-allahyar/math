import TrialEnvelopeWeights180
import Mathlib.Analysis.MeanInequalities
import TrialEnvelopeKernelData180
import TrialLaterLowScalarPayments180

/-! A pointwise bound for the actual frozen signed spline on native indices at
least 102994. Its sole premise is the printed integer cost bound at each of the
27 panels, three coefficient suffixes, and two signs. -/

/-! Explicit weighted integer-power AM–GM for the two endpoints and the
37-site core of the frozen signed amplitude. -/
noncomputable section
open scoped BigOperators
namespace PrimeGap180.EnvelopeAngular
open FrozenProfile

-- Zero exponents contribute a factor one even when the corresponding mass vanishes.
theorem power_allocation (m : Fin 3 → ℕ) (a : Fin 3 → ℝ) (ha : ∀ i,0 ≤ a i) (R : ℝ)
    (budget : ∑ i,a i ≤ R) :
    (∏ i,a i^(m i))  ≤  R^(∑ i,m i) * (∏ i,(m i:ℝ)^m i) /
      ((∑ i,m i:ℕ):ℝ)^(∑ i,m i) := by
  let N:=∑ i,m i
  by_cases nz : N=0
  · have allZero (i : Fin 3) : m i=0 := Nat.eq_zero_of_le_zero (nz ▸
      (Finset.single_le_sum (f:=m) (fun _ _=>Nat.zero_le _) (Finset.mem_univ i)))
    simp [allZero]
  have npos : (0:ℝ)<N := by exact_mod_cast Nat.pos_of_ne_zero nz
  let b := fun i=>(m i:ℝ)
  let z := fun i=>a i/b i
  have bz (i : Fin 3) : 0 ≤ b i := Nat.cast_nonneg _
  have zz (i : Fin 3) : 0 ≤ z i := div_nonneg (ha i) (bz i)
  have sn : (∑ i,b i)=(N:ℝ) := by dsimp [b,N]; push_cast; rfl
  have portion (i : Fin 3) : b i*z i ≤ a i := by
    by_cases mi : m i=0
    · simp [b,z,mi,ha]
    · have nb : b i≠0 := by dsimp [b]; exact_mod_cast mi
      dsimp only [z]; rw [mul_div_cancel₀ _ nb]
  have base := Real.geom_mean_le_arith_mean Finset.univ b z (fun i _=>bz i) (sn ▸ npos) (fun i _=>zz i)
  rw [sn] at base
  have q := base.trans (div_le_div_of_nonneg_right ((Finset.sum_le_sum (s:=Finset.univ) fun i _=>portion i).trans budget) npos.le)
  have wgt : (∏ i,z i^(b i))=(∏ i,z i^(m i)) := by simp [b]
  rw [wgt] at q
  have nnprod : 0 ≤ ∏ i,z i^(m i) := Finset.prod_nonneg fun i _=>pow_nonneg (zz i) _
  have pwr := pow_le_pow_left₀ (Real.rpow_nonneg nnprod _) q N
  rw [←Real.rpow_natCast,←Real.rpow_mul nnprod,inv_mul_cancel₀ npos.ne',Real.rpow_one] at pwr
  have fact (i : Fin 3) : a i^(m i)=(z i)^(m i)*(b i)^(m i) := by
    by_cases mi : m i=0
    · simp [mi]
    · have nb : b i≠0 := by dsimp [b]; exact_mod_cast mi
      rw [←mul_pow,show z i*b i=a i from div_mul_cancel₀ _ nb]
  simp_rw [fact]
  rw [Finset.prod_mul_distrib]
  change _  ≤  R^N*(∏ i,(b i)^m i)/(N:ℝ)^N
  exact (mul_le_mul_of_nonneg_right pwr (Finset.prod_nonneg fun i _=>pow_nonneg (bz i) _)).trans_eq (by rw [div_pow]; ring)

private theorem site_shape (x : ℝ) (hp : 0 ≤ x) (a : Fin 3) :
    0 ≤ shapes x a ∧ shapes x a ≤ x^(expAt a)/(131072*Native.step)^(expAt a) := by
  fin_cases a
  · norm_num [shapes,expAt]
  · norm_num [shapes,expAt,div_pow] <;> positivity
  · simp [shapes,expAt]
    first | exact inv_le_one_of_one_le₀ (by linarith) | exact ⟨by positivity,inv_le_one_of_one_le₀ (by linarith)⟩

private theorem powers (u : Fin 37 → ℝ) (hu : ∀ i,0 ≤ u i) {e : ℕ} (he : 0<e) :
    ∑ i,u i^e  ≤  (∑ i,u i)^e := by
  obtain ⟨n,rfl⟩:=Nat.exists_eq_succ_of_ne_zero he.ne'
  have h (i : Fin 37) : u i  ≤  ∑ k,u k := Finset.single_le_sum (f:=u) (fun j _=>hu j) (Finset.mem_univ i)
  simp_rw [pow_succ]
  rw [Finset.mul_sum]
  exact Finset.sum_le_sum fun i _=>mul_le_mul_of_nonneg_right (pow_le_pow_left₀ (hu i) (h i) _) (hu i)

def angular (x y : ℝ) (u : Fin 37 → ℝ) (a b : Fin 3) (σ : Fin 11) :=
  shapes x a*shapes y b*((signatures σ).map fun e=>∑ i,u i^e).prod

theorem bound (x y : ℝ) (u : Fin 37 → ℝ) (hx : 0 ≤ x) (hy : 0 ≤ y) (hu : ∀ i,0 ≤ u i) (R : ℝ)
    (budget : x+y+(∑ i,u i) ≤ R) (a b : Fin 3) (σ : Fin 11) :
    0 ≤ angular x y u a b σ ∧ angular x y u a b σ ≤ weight R (131072*Native.step) a b σ := by
  let C:=∑ i,u i
  have hc : 0 ≤ C:=Finset.sum_nonneg fun i _=>hu i
  let P:=fun e=>(∑ i,u i^e)
  have pp (e : ℕ) : 0 ≤ P e:=Finset.sum_nonneg fun i _=>pow_nonneg (hu i) _
  have lst (L : List ℕ) (ok : ∀ e∈L,0<e) : 0 ≤ (L.map P).prod ∧ (L.map P).prod  ≤  C^L.sum := by
    induction L with
    | nil=>simp
    | cons k L ih=>
      obtain ⟨nn,le⟩:=ih (fun e he=>ok _ (List.mem_cons_of_mem _ he))
      simp only [List.map_cons,List.prod_cons,List.sum_cons,pow_add]
      exact ⟨mul_nonneg (pp k) nn,mul_le_mul (powers u hu (ok _ List.mem_cons_self)) le nn (pow_nonneg hc _)⟩
  have valid : ∀ s : Fin 11,∀ e∈signatures s,0<e := by decide +kernel
  obtain ⟨p0,pU⟩:=lst (signatures σ) (valid σ)
  obtain ⟨a0,aU⟩:=site_shape x hx a
  obtain ⟨b0,bU⟩:=site_shape y hy b
  have bp : 0<(131072:ℝ)*Native.step := by norm_num [Native.step]
  let A:=expAt a; let B:=expAt b; let d:=(signatures σ).sum
  let m : Fin 3 → ℕ:=![A,B,d]
  let v : Fin 3 → ℝ:=![x,y,C]
  have hm:=power_allocation m v (fun i=>by fin_cases i; exacts [hx,hy,hc]) R
    (by simpa [Fin.sum_univ_three,v,add_assoc] using budget)
  simp only [Fin.prod_univ_three,Fin.sum_univ_three,m,v,Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.cons_val_two] at hm
  change x^A*y^B*C^d ≤ R^(A+B+d)*((A:ℝ)^A*(B:ℝ)^B*(d:ℝ)^d)/((A+B+d:ℕ):ℝ)^(A+B+d) at hm
  refine ⟨mul_nonneg (mul_nonneg a0 b0) p0,?_⟩
  change shapes x a*shapes y b*((signatures σ).map P).prod  ≤  _
  have q:=mul_le_mul (mul_le_mul aU bU b0 (div_nonneg (pow_nonneg hx _) (pow_nonneg bp.le _))) pU p0
    (mul_nonneg (div_nonneg (pow_nonneg hx _) (pow_nonneg bp.le _)) (div_nonneg (pow_nonneg hy _) (pow_nonneg bp.le _)))
  apply q.trans
  calc
    _ = (x^A*y^B*C^d)/(131072*Native.step)^(A+B) := by rw [pow_add]; field_simp [bp.ne'] <;> ring
    _  ≤  _ := (div_le_div_of_nonneg_right hm (pow_nonneg bp.le _)).trans_eq (by
      rw [div_div]; rfl)

#print axioms power_allocation
#print axioms bound
end PrimeGap180.EnvelopeAngular
end


noncomputable section
open scoped BigOperators
namespace PrimeGap180.EnvelopeKernel
open EnvelopePolynomial FrozenProfile FrozenData

theorem suffix_range : ∀ c : Fine,suffix c<3 := by decide +kernel

theorem row_eq (c : Fine) (a b : Fin 3) (s : Fin 11) (k : Fin 30) :
    row (suffix c) a b s k.val = rowQ c ⟨3*a.val+b.val,by omega⟩ s k := rfl

private theorem off (p : Panel) (z : ℚ) (d i : ℕ) (h : p.span < i ∨ i+d < p.span) :
    eval z (basis p d i)=0 := by
  induction d generalizing i with
  | zero => simp [basis,eval,show i≠p.span by omega]
  | succ d ih =>
    simp only [basis,plus_eval,times_eval,affine_eval,ih i (by omega),ih (i+1) (by omega),mul_zero,add_zero]

theorem combine_eval (p : Panel) (f : ℕ → ℚ) (n : ℕ) (z : ℚ) :
    eval z (combine p f n)=∑ k∈Finset.range n,f k*eval z (basis p 3 k) := by
  induction n with
  | zero=>simp [combine,eval]
  | succ k ih=>
    rw [Finset.sum_range_succ]
    by_cases yes : k ≤ p.span ∧ p.span ≤ k+3
    · simp [combine,yes,plus_eval,times_eval,ih]
    · simp [combine,yes,off p z 3 k (by omega),ih]

theorem channel (p : Panel) (c : Fine) (a b : Fin 3) (s : Fin 11) (ng : Bool) (j : ℕ) (z : ℚ)
    (atTick : ∀ k : Fin 30,splineQ j k=eval z (basis p 3 k.val)) :
    eval z (poly p (suffix c) a b s ng) =
      sign ng*norm s * ∑ k : Fin 30,splineQ j k*rowQ c ⟨3*a.val+b.val,by omega⟩ s k := by
  rw [poly,times_eval,combine_eval,←Fin.sum_univ_eq_sum_range (fun k=>row (suffix c) a b s k*eval z (basis p 3 k)) 30]
  simp_rw [row_eq,←atTick]
  simp only [mul_comm]

/-- A local angular product between zero and its homogeneous allocation
bound may accompany each actual signed radial coefficient. -/
theorem signed_sum {p : Panel} {u : ℕ} {ng : Bool} {z : ℚ} (hz : 0 ≤ z) (ho : z ≤ 1)
    (F : Fin 3 → Fin 3 → Fin 11 → ℝ) (nonneg : ∀ a b s,0 ≤ F a b s)
    (weights : ∀ a b s,F a b s ≤ (EnvelopeAngular.weight (right p) radius a b s:ℚ)) :
    (∑ a,∑ b,∑ s,F a b s*(eval z (poly p u a b s ng):ℝ))  ≤  (cost p u ng:ℝ) := by
  unfold cost
  push_cast
  refine Finset.sum_le_sum fun a _=>Finset.sum_le_sum fun b _=>Finset.sum_le_sum fun s _=>?_
  let v:=poly p u a b s ng
  let A:=EnvelopeAngular.weight (right p) radius a b s
  have val : (eval z v:ℝ) ≤ ((max 0 (upper v):ℚ):ℝ) := by exact_mod_cast (eval_le v hz ho).trans (le_max_right _ _)
  have h := (mul_le_mul_of_nonneg_left val (nonneg a b s)).trans
    (mul_le_mul_of_nonneg_right (weights a b s) (by exact_mod_cast (le_max_left 0 (upper v))))
  exact h.trans (by exact_mod_cast Nat.le_ceil (A*max 0 (upper v)))

#print axioms channel
#print axioms signed_sum
end PrimeGap180.EnvelopeKernel
end


/-! Adaptive integer panels cover the entire high-index range including both
ends. Repeated knots and source-basis transitions are tested panel by panel. -/
namespace PrimeGap180.EnvelopePanels
open MassSplineSpan EnvelopePolynomial EnvelopeKernel

private def chain (stop : ℕ) : ℕ → List Panel → Bool
  | n,[]=>decide (n=stop+1)
  | n,p::ps=>decide (p.lo=n ∧ p.lo ≤ p.hi) && chain stop (p.hi+1) ps

private theorem covers {stop j : ℕ} (ps : List Panel) (lo : ℕ) (ok : chain stop lo ps=true)
    (inside : lo ≤ j ∧ j ≤ stop) : ∃ p∈ps,p.lo ≤ j ∧ j ≤ p.hi := by
  induction ps generalizing lo with
  | nil=> simp only [chain,decide_eq_true_eq] at ok; omega
  | cons p ps ih=>
    simp only [chain, Bool.and_eq_true_iff, decide_eq_true_eq] at ok
    obtain ⟨⟨beg,_⟩,rest⟩ := ok
    by_cases h : j ≤ p.hi
    · exact ⟨p,List.mem_cons_self,by omega,h⟩
    · obtain ⟨P,mem,rng⟩:=ih (p.hi+1) rest ⟨by omega,inside.2⟩
      exact ⟨P,List.mem_cons_of_mem p mem,rng⟩

theorem spans : ∀ i : Fin 27, let p:=atIndex i
    p.lo<p.hi ∧ 3 ≤ p.span ∧ p.span<33 ∧ knot p.span ≤ left p ∧ right p<knot (p.span+1) := by decide +kernel

theorem cover {j : ℕ} (low : 102994 ≤ j) (high : j ≤ 130964) : ∃ i,(atIndex i).lo ≤ j ∧ j ≤ (atIndex i).hi := by
  obtain ⟨p,hp,h⟩:=covers (List.ofFn atIndex) 102994 (by decide +kernel : chain 130964 102994 (List.ofFn atIndex)=true) ⟨low,high⟩
  obtain ⟨i,rfl⟩:=List.mem_ofFn.mp hp
  exact ⟨i,h⟩

#print axioms cover
#print axioms spans
end PrimeGap180.EnvelopePanels

/-! Apply signed cubic and angular bounds to the actual signed physical
spline restricted to the high native-index support. -/
noncomputable section
open MeasureTheory Set PrimeGap180.FrozenProfile PrimeGap180.Sector
open scoped BigOperators
namespace PrimeGap180.EnvelopePhysical
open EnvelopePolynomial EnvelopeKernel EnvelopePanels
open GateDeletion (T)
open LaterLowScalar (mid)
private def center (j : ℕ) := ((j:ℝ)+1/2)*Native.step
private theorem center_nn (n : ℕ) : 0 ≤ center n := by
  unfold center Native.step
  positivity

private theorem factor_nn (x : ℝ) (hx : 0 ≤ x) : 0 ≤ siteFactor x := by
  unfold siteFactor
  positivity

private def scalar (j : Fin 39 → ℕ) (c : Fine) := ∑ a : Fin 3,∑ b : Fin 3,∑ s : Fin 11,
  EnvelopeAngular.angular (center (j 0)) (center (j (Fin.last 38))) (fun k : Fin 37=>center (j k.castSucc.succ)) a b s *
  ((EnvelopeKernel.norm s:ℝ)* ∑ k : Fin 30,T.spline (∑ i,j i) k*T.row c ⟨3*a.val+b.val,by omega⟩ s k)

private theorem factors (j : Fin 39 → ℕ) (c : Fine) : amplitude T j c =
    (∏ i,siteFactor (center (j i)))*scalar j c := by
  unfold amplitude scalar
  apply congrArg (fun z : ℝ=>(∏ i,siteFactor (center (j i)))*z)
  refine Finset.sum_congr rfl fun a _=>Finset.sum_congr rfl fun b _=>Finset.sum_congr rfl fun s _=>?_
  simp only [EnvelopeAngular.angular,EnvelopeKernel.norm,Rat.cast_pow,Rat.cast_ofNat,center]
  ring

private theorem sum_center (j : Fin 39 → ℕ) : (∑ i,center (j i))=(MassSplineSpan.sample (∑ i,j i):ℝ) := by
  unfold center MassSplineSpan.sample Native.step
  push_cast
  rw [←Finset.sum_mul,Finset.sum_add_distrib]
  norm_num

private theorem weights_cast (R : ℚ) (a b : Fin 3) (s : Fin 11) :
    (EnvelopeAngular.weight R radius a b s:ℚ)=(EnvelopeAngular.weight (R:ℝ) (131072*Native.step) a b s) := by
  unfold EnvelopeAngular.weight
  dsimp only
  generalize (signatures s).sum = d
  push_cast
  norm_num [radius, Native.step]

private theorem cap (p : Panel) (j : Fin 39 → ℕ) (hR : ∑ i,j i ≤ p.hi)
    (a b : Fin 3) (s : Fin 11) :
    let F:=EnvelopeAngular.angular (center (j 0)) (center (j (Fin.last 38))) (fun k : Fin 37=>center (j k.castSucc.succ)) a b s
    0 ≤ F ∧ F ≤ (EnvelopeAngular.weight (right p) radius a b s:ℚ) := by
  have nn (i : Fin 39) : 0 ≤ center (j i) := by unfold center Native.step; positivity
  have all := (sum_center j).le.trans (show (MassSplineSpan.sample (∑ i,j i):ℝ) ≤ (right p:ℝ) from
    by exact_mod_cast MassSplineSpan.sample_mono hR)
  rw [Fin.sum_univ_succ,Fin.sum_univ_castSucc] at all
  change center (j 0) + ((∑ i : Fin 37, center (j i.castSucc.succ)) + center (j (Fin.last 38))) ≤ _ at all
  have hb := EnvelopeAngular.bound (center (j 0)) (center (j (Fin.last 38))) (fun k : Fin 37=>center (j k.castSucc.succ))
    (nn _) (nn _) (fun k=>nn _) (right p:ℝ) (by linarith only [all]) a b s
  rw [weights_cast]
  exact hb

private theorem signed (i : Fin 27) (j : Fin 39 → ℕ) (c : Fine) (ng : Bool)
    (inside : (atIndex i).lo  ≤  ∑ l,j l ∧ (∑ l,j l)  ≤  (atIndex i).hi)
    (checked : cost (atIndex i) (suffix c) ng ≤ 728975) :
    (EnvelopeKernel.sign ng:ℝ)*scalar j c  ≤  728975 := by
  let p:=atIndex i
  let J:=∑ l,j l
  obtain ⟨wide,lo,hi,act⟩:=spans i
  obtain ⟨z,nn,one,exactBasis⟩ := EnvelopePolynomial.physical p inside wide lo hi act
  let F:=EnvelopeAngular.angular (center (j 0)) (center (j (Fin.last 38))) (fun k : Fin 37=>center (j k.castSucc.succ))
  have hs:=signed_sum (p:=p) (u:=suffix c) (ng:=ng) nn one F
    (fun a b s=>(cap p j inside.2 a b s).1) (fun a b s=>(cap p j inside.2 a b s).2)
  calc
    _ = ∑ a,∑ b,∑ s,F a b s*(eval z (poly p (suffix c) a b s ng):ℝ) := by
      unfold scalar
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl fun a _ => ?_
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl fun b _ => ?_
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl fun s _ => ?_
      rw [channel p c a b s ng J z exactBasis]
      push_cast
      simp_rw [FrozenData.spline_eq_rat,FrozenData.row_eq_rat]
      dsimp only [F,J]
      simp only [show Fin.last 38 = (38 : Fin 39) by decide]
      ring
    _  ≤  _ := hs.trans (by exact_mod_cast checked)

private theorem ordinary (bounds : ∀ i : Fin 27,∀ u : Fin 3,∀ ng : Bool,cost (atIndex i) u.val ng ≤ 728975)
    (j : Fin 39 → ℕ) (c : Fine) (low : 102994 ≤ ∑ i,j i) (high : (∑ i,j i) ≤ 130964) :
    |amplitude T j c| ≤ 728975*∏ i,siteFactor (center (j i)) := by
  obtain ⟨i,inside⟩:=cover low high
  have sg (ng) := signed i j c ng inside (bounds i ⟨suffix c,suffix_range c⟩ ng)
  have plus:=sg false
  have minus:=sg true
  simp [EnvelopeKernel.sign] at plus minus
  have av : |scalar j c| ≤ 728975 := abs_le.mpr ⟨by linarith only [minus],plus⟩
  have rn (k : Fin 39) : 0 ≤ siteFactor (center (j k)) := factor_nn _ (center_nn _)
  rw [factors,abs_mul,abs_of_nonneg (Finset.prod_nonneg fun k _=>rn k),mul_comm]
  exact mul_le_mul_of_nonneg_right av (Finset.prod_nonneg fun k _=>rn k)

/-- The signed bound holds pointwise on the entire high native-index support. -/
theorem pointwise (bounds : ∀ i : Fin 27, ∀ u : Fin 3, ∀ ng : Bool, cost (atIndex i) u.val ng ≤ 728975)
    (v : Fin 39 → Band 216) (low : 102994 ≤ Native.cellSum v) :
    |Restoration.original v| ≤ 728975 * ∏ k, siteFactor (mid (v k)) := by
  have rn (k : Fin 39) : 0 ≤ siteFactor (mid (v k)) := factor_nn _ (center_nn (Native.cell (v k)))
  by_cases zero : Restoration.original v=0
  · rw [zero,abs_zero]
    exact mul_nonneg (by norm_num) (Finset.prod_nonneg fun i _=>rn i)
  have high:=Restoration.original_index v zero
  let j:=fun k=>Native.cell (v k)
  have idx : indices (bits T v)=j := by
    funext k
    rw [index_eq]
    exact min_eq_left ((Finset.single_le_sum (f := j) (fun _ _ => Nat.zero_le _) (Finset.mem_univ k)).trans (high.trans (by decide)))
  change |GateDeletion.originalValue (bits T v)|  ≤  _
  change GateDeletion.originalValue (bits T v)≠0 at zero
  unfold GateDeletion.originalValue at zero ⊢
  cases choose : least (fun c=>bits T v (.cap c)) with
  | none=>simp [choose] at zero
  | some c=>
    simp only [choose,idx] at zero ⊢
    unfold raw at zero ⊢
    split
    · rename_i bad
      exact False.elim (zero (ite_eq_left bad))
    · exact ordinary bounds j c low high

/-- Almost-everywhere interface consumed by all nine scalar payments. -/
theorem physical (bounds : ∀ i : Fin 27, ∀ u : Fin 3, ∀ ng : Bool, cost (atIndex i) u.val ng ≤ 728975) :
    LaterLowFixed.Envelope := Filter.Eventually.of_forall (pointwise bounds)

#print axioms pointwise
#print axioms physical
end PrimeGap180.EnvelopePhysical
end
