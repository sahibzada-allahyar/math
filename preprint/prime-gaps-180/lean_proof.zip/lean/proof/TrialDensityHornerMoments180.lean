import TrialDensityHorner180

namespace PrimeGap180.DensitySimplex.Horner
open MeasureTheory
open scoped BigOperators
abbrev Term (d : ℕ) := (Fin d → ℕ) × Int

def appendPowers {A : Type} {d : ℕ} (expand : A → List (Term d)) :
    ℕ → List A → List (Term (d+1))
  | _, [] => []
  | k, a::rest =>
    (expand a).map (fun e => (Fin.cons k e.1,e.2)) ++ appendPowers expand (k+1) rest

def terms : (d : ℕ) → Table d → List (Term d)
  | 0, a => [(Fin.elim0,(a:Int))]
  | d+1, l => appendPowers (terms d) 0 l

noncomputable def realTerm {d : ℕ} (x : Fin d → ℝ) (e : Term d) : ℝ :=
  (e.2:ℝ)*monomial e.1 x

noncomputable def total {d : ℕ} (x : Fin d → ℝ) (v : List (Term d)) : ℝ :=
  (v.map (realTerm x)).sum

private theorem extended {d : ℕ} (x : Fin (d+1) → ℝ) (k : ℕ) (l : List (Term d)) :
    total x (l.map (fun e => (Fin.cons k e.1,e.2))) = x 0 ^ k * total (Fin.tail x) l := by
  induction l with
  | nil => simp [total]
  | cons a l ih =>
    have lead : realTerm x (Fin.cons k a.1,a.2) = x 0^k*realTerm (Fin.tail x) a := by
      simp [realTerm,monomial, Fin.prod_univ_succ,Fin.tail]
      ring
    simp only [total,List.map_cons,List.sum_cons] at ih ⊢
    rw [ih,lead]
    ring

private theorem listed {d : ℕ} {A : Type} (exp : A → List (Term d)) (v : A → ℝ)
    (x : Fin (d+1) → ℝ) (h : ∀ a, total (Fin.tail x) (exp a)=v a) (k : ℕ) (l : List A) :
    total x (appendPowers exp k l) = x 0 ^ k * value v (x 0) l := by
  induction l generalizing k with
  | nil => simp [total,appendPowers,value]
  | cons a l ih =>
    have split {w t : List (Term (d+1))} : total x (w++t) = total x w + total x t := by
      simp [total]
    rw [appendPowers,split,extended,h,ih (k+1),pow_succ]
    simp only [value,List.foldr_cons]
    ring

theorem represented (d : ℕ) (a : Table d) (x : Fin d → ℝ) :
    total x (terms d a) = evaluate d a x := by
  induction d with
  | zero => simp [total,terms,realTerm,evaluate,monomial]
  | succ d ih =>
    have h := listed (terms d) (fun a => evaluate d a (Fin.tail x)) x (fun a => ih a _) 0 a
    simpa only [terms,evaluate,pow_zero,one_mul] using h

def qTerm {d : ℕ} (t : ℚ) (e : Term d) : ℚ :=
  (e.2:ℚ)*t^(d+∑ i,e.1 i)*(∏ i,((e.1 i).factorial:ℚ))/((d+∑ i,e.1 i).factorial:ℚ)

def integralQ (d : ℕ) (a : Table d) (t : ℚ) : ℚ :=
  ((terms d a).map (qTerm t)).sum

private theorem integrated {d : ℕ} (t : ℚ) (ht : 0 < t) (xs : List (Term d)) :
    IntegrableOn (fun x => total x xs) (region d (t:ℝ)) ∧
    (∫ x in region d (t:ℝ),total x xs) = (((xs.map (qTerm t)).sum : ℚ):ℝ) := by
  induction xs with
  | nil => simp [total]
  | cons a l ih =>
    have hi := (monomial_integrable a.1 (t:ℝ)).const_mul (a.2:ℝ)
    have eqn (x : Fin d → ℝ) : total x (a::l) = (a.2:ℝ)*monomial a.1 x + total x l := by
      simp [total,realTerm]
    simp_rw [eqn]
    refine ⟨hi.add ih.1,?_⟩
    rw [integral_add hi ih.1, integral_const_mul,← moment,moment_value a.1 _ (by exact_mod_cast ht),ih.2]
    simp [qTerm]
    ring

theorem integralQ_correct (d : ℕ) (a : Table d) (t : ℚ) (ht : 0 < t) :
    (∫ x in region d (t:ℝ),evaluate d a x) = (integralQ d a t:ℝ) := by
  simp_rw [← represented d a]
  exact (integrated t ht (terms d a)).2

#print axioms integralQ_correct
end PrimeGap180.DensitySimplex.Horner
