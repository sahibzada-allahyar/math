import TrialPackedSingleFields180
import TrialNativePairUpdates180

/-! A retained endpoint-pair row reads two independent packed one-site
correlations. The two ordered endpoint shape factors stay in their original positions. -/
noncomputable section
open scoped Classical BigOperators
open PrimeGap180.DebitNativeClasses PrimeGap180.PackedLaw PrimeGap180.FrozenChannels
open PrimeGap180.PackedSingleFields PrimeGap180.NativePairUpdates PrimeGap180.NativeShellErasures
namespace PrimeGap180.PackedPairFields
set_option maxRecDepth 5500
set_option maxHeartbeats 1700000

def features (t : Fin 37 → Atom) (z : Term) := ∏ i,siteChannel z i.castSucc.succ (t i).1.val

theorem total (t : Fin 37 → Atom) (a b : Atom) :
    retained (EndpointPhysical.join t a b) = a.1.val+b.1.val+retained t := by
  unfold retained EndpointPhysical.join
  rw [Fin.sum_univ_succ]
  simp only [Fin.cons_zero,Fin.cons_succ]
  rw [Fin.sum_univ_castSucc]
  simp only [Fin.snoc_castSucc,Fin.snoc_last]
  omega

private theorem joined (t : Fin 37 → Atom) (a b : Atom) (z : Term) :
    fullProduct (EndpointPhysical.join t a b) z =
      siteChannel z 0 a.1.val*siteChannel z (Fin.last 38) b.1.val*features t z := by
  unfold fullProduct EndpointPhysical.join features
  rw [Fin.prod_univ_succ]
  simp only [Fin.cons_zero,Fin.cons_succ]
  rw [Fin.prod_univ_castSucc]
  simp only [Fin.snoc_castSucc,Fin.snoc_last,show (Fin.last 37).succ=Fin.last 38 by rfl]
  ring

def factor (J : ℕ) (c : Hist) (z : Term) (a b : ℕ) :=
  100^2*coefficientChange (a+b+J) c z*siteChannel z 0 a*siteChannel z (Fin.last 38) b

def pairCoefficient (g : Grid) (J : ℕ) (c : Hist) (z : Term) :=
  ∑ a : Tick, Native.step*((g a c:ℝ)/(base:ℝ))*
    ∑ b : Tick,Native.step*((g b c:ℝ)/(base:ℝ))*factor J c z a.val b.val

private def clipped (g : Grid) (c : Hist) (a : Atom) := if accepts a.2 c then law g a else 0

private theorem project (g : Grid) (c : Hist) (f : ℕ → ℝ) :
    (∑ a : Atom,clipped g c a*f a.1.val) =
      ∑ j : Tick,Native.step*((g j c:ℝ)/(base:ℝ))*f j.val := by
  simpa only [clipped,ite_mul,zero_mul] using PackedMoments.site g c f

theorem double_project (g : Grid) (c : Hist) (f : ℕ → ℕ → ℝ) :
    (∑ a : Atom,∑ b : Atom,clipped g c a*(clipped g c b*f a.1.val b.1.val)) =
    ∑ a : Tick, Native.step*((g a c:ℝ)/(base:ℝ))*∑ b : Tick,Native.step*((g b c:ℝ)/(base:ℝ))*f a.val b.val := by
  simp_rw [←Finset.mul_sum,project]
  exact project g c (fun k => ∑ b : Tick,Native.step*((g b c:ℝ)/(base:ℝ))*f k b.val)

theorem packed_erasure (g : Grid) (t : Fin 37 → Atom) (c : Hist) :
    addPair (ReferenceRoles.archive (law g)) t c=∑ z : Term,pairCoefficient g (retained t) c z*features t z := by
  let I (a b : Atom) (z : Term) := clipped g c a*(clipped g c b*factor (retained t) c z a.1.val b.1.val)*features t z
  calc
    _ = ∑ a : Atom,∑ b : Atom,∑ z : Term,I a b z := by
      unfold addPair
      apply Finset.sum_congr rfl
      intro a _
      apply Finset.sum_congr rfl
      intro b _
      by_cases la : accepts a.2 c=true <;> by_cases lb : accepts b.2 c=true
      · simp only [la,lb,and_self,ite_true,delta_value,total,joined,Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro z _
        simp only [I,clipped,la,lb,ite_true,ReferenceRoles.archive,factor]
        ring
      all_goals simp [la,lb,I,clipped]
    _ = ∑ z : Term,∑ a : Atom,∑ b : Atom,I a b z := by
      calc
        _ = ∑ a : Atom,∑ z : Term,∑ b : Atom,I a b z := Finset.sum_congr rfl (fun _ _ => Finset.sum_comm)
        _ = _ := Finset.sum_comm
    _ = _ := by
      apply Finset.sum_congr rfl
      intro z _
      unfold I
      simp_rw [←Finset.sum_mul]
      exact congrArg (·*features t z) (double_project g c (factor (retained t) c z))

#print axioms packed_erasure
end PrimeGap180.PackedPairFields
