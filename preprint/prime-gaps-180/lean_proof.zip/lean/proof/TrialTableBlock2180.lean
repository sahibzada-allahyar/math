import TrialTableRow10180
import TrialTableRow11180
import TrialTableRow12180
import TrialTableRow13180
import TrialTableRow14180
namespace PrimeGap180.TablePrices
theorem block2 (i : Fin 5) : certified (blockIndex 2 i) := by
  fin_cases i
  · exact row10
  · exact row11
  · exact row12
  · exact row13
  · exact row14
#print axioms block2
end PrimeGap180.TablePrices
