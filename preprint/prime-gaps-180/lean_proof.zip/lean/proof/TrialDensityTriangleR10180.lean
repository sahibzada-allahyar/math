import TrialDensityTriangleInputs180
namespace PrimeGap180.DensitySimplex.Horner.TriangleChecks
private theorem lower_den10 (z : Fin 2 → ℝ) :
    ((L 10).map (factorValue z)).prod/((unit^3:Int):ℝ) = threeDen (lowerMap (r 10) (s 10) z) := by
  have hr : r 10 = 121947999/10000000000 := by decide +kernel
  have hs : s 10 = 592552001/5000000000 := by decide +kernel
  have forms : L 10 = factors 1429000000 243895998 0 2370208004 := rfl
  rw [hr,hs,forms]
  norm_num [factors,unit,factorValue,Fin.sum_univ_two,threeDen,lowerMap] <;> ring
private theorem upper_den10 (z : Fin 2 → ℝ) :
    ((U 10).map (factorValue z)).prod/((unit^3:Int):ℝ) = threeDen (upperMap (r 10) (s 10) z) := by
  have hr : r 10 = 121947999/10000000000 := by decide +kernel
  have hs : s 10 = 592552001/5000000000 := by decide +kernel
  have forms : U 10 = factors 243895998 0 2370208004 2492156003 := rfl
  rw [hr,hs,forms]
  norm_num [factors,unit,factorValue,Fin.sum_univ_two,threeDen,upperMap] <;> ring

set_option maxRecDepth 65536 in
set_option maxHeartbeats 0 in
theorem row10 : triangleQ (r 10) (s 10) = FrozenNumbers.triangles 10 := by
  rw [triangle_from_forms _ _ (L 10) (U 10) (unit^3) (unit^3) (by decide) (by decide)
    lower_den10 upper_den10]
  decide +kernel

#print axioms row10
end PrimeGap180.DensitySimplex.Horner.TriangleChecks
