import TrialSourcePlanBlocks180

namespace PrimeGap180.SourcePlanBlocks.Higher04

set_option maxRecDepth 131072
set_option maxHeartbeats 100000000

private theorem b0 : all (.higher 4) 0 = true := by decide +kernel
private theorem b1 : all (.higher 4) 1 = true := by decide +kernel
private theorem b2 : all (.higher 4) 2 = true := by decide +kernel
private theorem b3 : all (.higher 4) 3 = true := by decide +kernel
private theorem b4 : all (.higher 4) 4 = true := by decide +kernel
private theorem b5 : all (.higher 4) 5 = true := by decide +kernel
private theorem b6 : all (.higher 4) 6 = true := by decide +kernel
private theorem b7 : all (.higher 4) 7 = true := by decide +kernel
private theorem b8 : all (.higher 4) 8 = true := by decide +kernel
private theorem b9 : all (.higher 4) 9 = true := by decide +kernel
private theorem b10 : all (.higher 4) 10 = true := by decide +kernel
private theorem b11 : all (.higher 4) 11 = true := by decide +kernel
private theorem b12 : all (.higher 4) 12 = true := by decide +kernel
private theorem b13 : all (.higher 4) 13 = true := by decide +kernel
private theorem b14 : all (.higher 4) 14 = true := by decide +kernel
private theorem b15 : all (.higher 4) 15 = true := by decide +kernel
private theorem b16 : all (.higher 4) 16 = true := by decide +kernel
private theorem b17 : all (.higher 4) 17 = true := by decide +kernel
private theorem b18 : all (.higher 4) 18 = true := by decide +kernel
private theorem b19 : all (.higher 4) 19 = true := by decide +kernel
private theorem b20 : all (.higher 4) 20 = true := by decide +kernel
private theorem b21 : all (.higher 4) 21 = true := by decide +kernel
private theorem b22 : all (.higher 4) 22 = true := by decide +kernel
private theorem b23 : all (.higher 4) 23 = true := by decide +kernel
private theorem b24 : all (.higher 4) 24 = true := by decide +kernel
private theorem b25 : all (.higher 4) 25 = true := by decide +kernel
private theorem b26 : all (.higher 4) 26 = true := by decide +kernel
private theorem b27 : all (.higher 4) 27 = true := by decide +kernel
private theorem b28 : all (.higher 4) 28 = true := by decide +kernel
private theorem b29 : all (.higher 4) 29 = true := by decide +kernel
private theorem b30 : all (.higher 4) 30 = true := by decide +kernel
private theorem b31 : all (.higher 4) 31 = true := by decide +kernel
private theorem b32 : all (.higher 4) 32 = true := by decide +kernel
private theorem b33 : all (.higher 4) 33 = true := by decide +kernel
private theorem b34 : all (.higher 4) 34 = true := by decide +kernel
private theorem b35 : all (.higher 4) 35 = true := by decide +kernel
private theorem b36 : all (.higher 4) 36 = true := by decide +kernel
private theorem b37 : all (.higher 4) 37 = true := by decide +kernel

private theorem checked : ∀ j : Fin 38, all (.higher 4) j.val = true :=
  (Fin.cases b0
    (Fin.cases b1
    (Fin.cases b2
    (Fin.cases b3
    (Fin.cases b4
    (Fin.cases b5
    (Fin.cases b6
    (Fin.cases b7
    (Fin.cases b8
    (Fin.cases b9
    (Fin.cases b10
    (Fin.cases b11
    (Fin.cases b12
    (Fin.cases b13
    (Fin.cases b14
    (Fin.cases b15
    (Fin.cases b16
    (Fin.cases b17
    (Fin.cases b18
    (Fin.cases b19
    (Fin.cases b20
    (Fin.cases b21
    (Fin.cases b22
    (Fin.cases b23
    (Fin.cases b24
    (Fin.cases b25
    (Fin.cases b26
    (Fin.cases b27
    (Fin.cases b28
    (Fin.cases b29
    (Fin.cases b30
    (Fin.cases b31
    (Fin.cases b32
    (Fin.cases b33
    (Fin.cases b34
    (Fin.cases b35
    (Fin.cases b36
    (Fin.cases b37
    (fun z => Fin.elim0 z)))))))))))))))))))))))))))))))))))))))

theorem every : Every (.higher 4) := of_blocks (.higher 4) 38 (by decide +kernel) checked

#print axioms every
end PrimeGap180.SourcePlanBlocks.Higher04
