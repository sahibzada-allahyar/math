import TrialFirstEdgeReference180
import TrialFirstEdgeKernels180
import TrialFirstEdgeProduct180

noncomputable section

section
open scoped BigOperators
open Set
namespace PrimeGap180.FirstEdgeProduct

/-- The erased sum over all sites controls the erased sum on any embedded
set of regular sites, even when the actual erased label lies outside it. -/
theorem embeds {n N : ℕ} (l : Fin (n+1) ↪ Fin (N+1)) (i : Fin (N+1))
    (s : Fin (N+1)→ℝ) (nn : ∀ j,0≤s j) (w : Fin (n+1)→ℝ) (lo : ∀ j, w j≤s (l j))
    {B : ℝ} (small : ∑ j,s (i.succAbove j)<B) : w∈erased n B := by
  classical
  obtain ⟨k,off⟩ : ∃ k : Fin (n+1), ∀ j : Fin n, l (k.succAbove j)≠i := by
    by_cases hit : ∃ k,l k=i
    · obtain ⟨k,rfl⟩:=hit
      exact ⟨k, fun j h=>Fin.succAbove_ne _ j (l.injective h)⟩
    · exact ⟨0,fun j h=>hit ⟨_,h⟩⟩
  refine ⟨k,lt_of_le_of_lt ?_ small⟩
  let R:=(Finset.univ : Finset (Fin n)).image (fun j=>l (k.succAbove j))
  have subset : R⊆(Finset.univ.image i.succAbove) := by
    rw [Fin.image_succAbove_univ]
    rintro t ht
    obtain ⟨j,_,rfl⟩:=Finset.mem_image.mp ht
    simpa using off j
  calc
    _ ≤ ∑ j,s (l (k.succAbove j)) := Finset.sum_le_sum (fun _ _=>lo _)
    _ = ∑ t∈R,s t := by
      unfold R
      rw [Finset.sum_image];exact fun u _ v _ h=>Fin.succAbove_right_injective (l.injective h)
    _ ≤ ∑ t∈Finset.univ.image i.succAbove,s t :=
      Finset.sum_le_sum_of_subset_of_nonneg subset (fun t _ _=>nn t)
    _ = _ := Finset.sum_image (fun _ _ _ _ h=>Fin.succAbove_right_injective h)

/-- The single maximum split applies after the event has been dominated as
a measurable lower set. -/
theorem partition {n : ℕ} {t m B : ℝ} {w : Fin (n+1)→ℝ} (clipped : ∀ j,w j≤t)
    (h : w∈erased n B) :
    (∑ j,w j<B+t ∧ ¬∀ j,w j≤m) ∨ (∑ j,w j<B+m ∧ ∀ j,w j≤m) := by
  obtain ⟨i,hi⟩:=h
  rw [Fin.sum_univ_succAbove w i]
  by_cases low : ∀ j,w j≤m
  · exact Or.inr ⟨by linarith only [hi,low i],low⟩
  · exact Or.inl ⟨by linarith only [hi,clipped i],low⟩

#print axioms embeds
#print axioms partition
end PrimeGap180.FirstEdgeProduct

open MeasureTheory
namespace PrimeGap180.FirstEdgeProduct

/-- Project any finite independent probability product onto a chosen set of
coordinates. The set can be chosen from the fixed native product piece. -/
theorem projection {ι κ X : Type*} [Fintype ι] [Fintype κ] [MeasurableSpace X]
    (P : ι→Measure X) [∀ i,IsProbabilityMeasure (P i)] (l : κ↪ι) :
    MeasurePreserving (fun (x : ι→X) j=>x (l j)) (Measure.pi P) (Measure.pi (fun j=>P (l j))) := by
  classical
  let f:=fun (x : ι→X) j=>x (l j)
  have cf : Measurable f:=measurable_pi_lambda _ (fun j=>measurable_pi_apply _)
  refine ⟨cf, (Measure.pi_eq ?_).symm⟩
  intro s hs
  let g:=Function.extend l s (fun _=> @univ X)
  let R:=Finset.univ.image l
  have gl (j : κ) : g (l j)=s j:=l.injective.extend_apply _ _ _
  have eq : f ⁻¹' (Set.univ.pi s) = (R:Set ι).pi g := by
    ext x
    change (∀ j∈(Set.univ : Set κ),x (l j)∈s j) ↔ ∀ i∈(R : Set ι),x i∈g i
    constructor
    · intro h i hi
      obtain ⟨j,_,rfl⟩:=Finset.mem_image.mp hi
      rw [gl];exact h j trivial
    · intro h j _
      rw [←gl j]
      exact h (l j) (Finset.mem_image.mpr ⟨j,by simp,rfl⟩)
  rw [Measure.map_apply cf (MeasurableSet.univ_pi hs),eq,Measure.pi_pi_finset,Finset.prod_image]
  · simp only [gl]
  · exact fun _ _ _ _ h=>l.injective h

#print axioms projection
end PrimeGap180.FirstEdgeProduct

end

section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace PrimeGap180.FirstEdgeConvolution

def cut (n : ℕ) (B : ℝ) : Set (Fin n→ℝ) := {x | ∑ i,x i≤B}
def restricted (n : ℕ) (Q : Measure ℝ) (m B : ℝ) := Measure.pi (fun _ : Fin n=>Q.restrict (Iic m)) (cut n B)

private theorem mcut (n : ℕ) (B : ℝ) : MeasurableSet (cut n B) :=
  measurableSet_le (Finset.measurable_sum _ (fun i _=>measurable_pi_apply i)) measurable_const

theorem start (Q : Measure ℝ) [IsFiniteMeasure Q] (m B : ℝ) :
    restricted 0 Q m B = if 0≤B then 1 else 0 := by
  classical
  have h : cut 0 B = if 0≤B then univ else ∅ := by
    split <;> rename_i z <;> ext x <;> simp [cut,z]
  rw [restricted,h]
  split
  · simp [Measure.pi_univ]
  · simp

theorem step (n : ℕ) (Q : Measure ℝ) [IsFiniteMeasure Q] (m B : ℝ) :
    restricted (n+1) Q m B = ∫⁻ t, restricted n Q m (B-t) ∂Q.restrict (Iic m) := by
  let μ:=Q.restrict (Iic m)
  let E:=MeasurableEquiv.piFinSuccAbove (fun _ : Fin (n+1)=>ℝ) 0
  have mp:=measurePreserving_piFinSuccAbove (fun _ : Fin (n+1)=>μ) 0
  change Measure.pi (fun _ : Fin (n+1)=>μ) (cut (n+1) B)=_
  rw [←mp.symm.measure_preimage (mcut _ _).nullMeasurableSet,
    Measure.prod_apply (E.symm.measurable (mcut _ _))]
  apply lintegral_congr_ae
  filter_upwards with t
  congr 1
  ext y
  change (∑ j,(Fin.insertNth (α:=fun _=>ℝ) 0 t y) j)≤B ↔ (∑ j,y j)≤B-t
  rw [Fin.sum_univ_succ]
  simp [le_sub_iff_add_le',Fin.insertNth_zero']

theorem event (n : ℕ) (Q : Measure ℝ) [IsFiniteMeasure Q] (m B : ℝ) :
    restricted n Q m B = Measure.pi (fun _ : Fin n=>Q) {x : Fin n→ℝ | (∑ i,x i)≤B ∧ ∀ i,x i≤m} := by
  rw [restricted,←Measure.restrict_pi_pi,Measure.restrict_apply (mcut _ _)]
  congr 1
  ext x
  simp [cut,Pi.le_def]

#print axioms start
#print axioms step
#print axioms event
end PrimeGap180.FirstEdgeConvolution

end

section
open MeasureTheory Set
open scoped ENNReal
namespace PrimeGap180.FirstEdgeSiteCDF
open FirstEdgeKernels

private def u (z : ℝ):=max 0 (min 1 z)

private theorem slope_cdf (z : ℝ) : slopeLaw (Iic z)=ENNReal.ofReal ((u z)^2/2) := by
  rw [slopeLaw,withDensity_apply _ measurableSet_Iic,Measure.restrict_restrict measurableSet_Iic]
  have eq : Iic z ∩ Ioc (0:ℝ) 1=Ioc 0 (u z) := by
    ext x
    simp only [mem_inter_iff,mem_Iic,mem_Ioc,u,le_max_iff,le_min_iff]
    grind
  rw [eq]
  have nonneg : 0≤u z:=le_max_left _ _
  have ii : IntegrableOn (fun v : ℝ=>v) (Ioc 0 (u z)) :=
    (continuous_id.continuousOn.integrableOn_compact (μ:=volume) isCompact_Icc).mono_set Ioc_subset_Icc_self
  have nn : 0≤ᵐ[volume.restrict (Ioc (0:ℝ) (u z))] (fun v=>v) :=
    (ae_restrict_mem (μ:=volume) measurableSet_Ioc).mono (fun _ h=>h.1.le)
  rw [←ofReal_integral_eq_lintegral_ofReal ii nn,←intervalIntegral.integral_of_le nonneg,integral_id]
  simp

theorem cdf (m A z : ℝ) (hA : 0≤A) : siteLaw m A (Iic z)=ENNReal.ofReal
    ((u z)^2/2+max 0 (min m z-1)+(if m≤z then A else 0)) := by
  rw [siteLaw,Measure.add_apply,Measure.add_apply,slope_cdf,Measure.restrict_apply measurableSet_Iic,
    Measure.smul_apply,smul_eq_mul,Measure.dirac_apply' _ measurableSet_Iic]
  have eq : Iic z ∩ Ioc (1:ℝ) m=Ioc 1 (min m z) := by ext x;simp;tauto
  rw [eq,Real.volume_Ioc]
  have nn : 0≤(u z)^2/2:=by positivity
  by_cases on : m≤z
  · rw [indicator_of_mem (show m∈Iic z from on),Pi.one_apply,mul_one,ite_eq_left on]
    rw [ENNReal.ofReal_add (add_nonneg nn (le_max_left _ _)) hA,ENNReal.ofReal_add nn (le_max_left _ _)]
    simp
  · rw [indicator_of_notMem (show m∉Iic z from on),mul_zero,ite_eq_right on,add_zero,add_zero,
      ENNReal.ofReal_add nn (le_max_left _ _)]
    simp

private theorem full (h z : ℝ) (hz : h≤z) : FirstEdgeReference.law h 1 (Iic z)=ENNReal.ofReal h := by
  have eq : FirstEdgeReference.clip h ⁻¹' Iic z=univ:=
    eq_univ_of_forall fun x=>(min_le_left _ _).trans hz
  rw [←FirstEdgeReference.mass (h:=h) zero_lt_one,FirstEdgeReference.law,
    Measure.smul_apply,Measure.smul_apply,
    Measure.map_apply (by unfold FirstEdgeReference.clip;fun_prop) measurableSet_Iic,
    Measure.map_apply (by unfold FirstEdgeReference.clip;fun_prop) MeasurableSet.univ,preimage_univ,eq]

theorem compatible {h m : ℝ} (hm : 1≤m) (mh : m≤h) :
    (FirstEdgeReference.law h 1).restrict (Iic m)=siteLaw m (if m=h then 1/2 else 0) := by
  let A : ℝ:=if m=h then 1/2 else 0
  have pos : 0≤A:=by unfold A;split <;> norm_num
  haveI : IsFiniteMeasure (FirstEdgeReference.law h 1) :=
    ⟨by rw [FirstEdgeReference.mass zero_lt_one];exact ENNReal.ofReal_lt_top⟩
  change _=siteLaw m A
  apply Measure.ext_of_Iic
  intro z
  rw [Measure.restrict_apply measurableSet_Iic,Iic_inter_Iic,cdf m A z pos]
  by_cases neg : z<0
  · have hh : (0:ℝ)<h:=zero_lt_one.trans_le (hm.trans mh)
    have zero:=FirstEdgeReference.cdf (h:=h) zero_lt_one (z:=0) le_rfl hh
    have mono:=measure_mono (μ:=FirstEdgeReference.law h 1) (Iic_subset_Iic.mpr (min_le_left z m |>.trans neg.le))
    have small : min z m<h:=lt_of_le_of_lt (min_le_left _ _) (neg.trans hh)
    simp only [min_eq_right zero_le_one,sub_zero,zero_pow (by decide : 2≠0),zero_div,add_zero,ENNReal.ofReal_zero] at zero
    have z0 : ¬m≤z:=by linarith
    rw [le_zero_iff.mp (mono.trans_eq zero)]
    simp [u,min_eq_right (by linarith : z≤1),max_eq_left neg.le,min_eq_right (by linarith : z≤m),
      max_eq_left (by linarith : z-1≤0),z0]
  by_cases cut : z<m
  · rw [min_eq_left cut.le,FirstEdgeReference.cdf zero_lt_one (le_of_not_gt neg) (cut.trans_le mh)]
    rw [min_eq_right cut.le,ite_eq_right cut.not_ge]
    congr 1
    dsimp [u]
    rcases le_total z 1 with z1|z1
    · rw [min_eq_right z1,max_eq_right (le_of_not_gt neg),max_eq_left (by linarith)]
      ring
    · rw [min_eq_left z1,max_eq_right zero_le_one,max_eq_right (by linarith)]
      ring
  have zm:=le_of_not_gt cut
  rw [min_eq_right zm,min_eq_left zm,ite_eq_left zm]
  rw [show u z=1 by simp [u,min_eq_left (hm.trans zm)]]
  rw [max_eq_right (by linarith : 0≤m-1)]
  by_cases same : m=h
  · subst h
    rw [full _ _ le_rfl]
    simp [A];congr 1;ring
  · rw [FirstEdgeReference.cdf zero_lt_one (zero_le_one.trans hm) (lt_of_le_of_ne mh same),min_eq_left hm]
    simp [A,same];congr 1;ring

#print axioms compatible
end PrimeGap180.FirstEdgeSiteCDF

namespace PrimeGap180.FirstEdgeSiteCDF
open FirstEdgeProduct FirstEdgeConvolution

private theorem cap_support (h : ℝ) : ∀ᵐ t ∂FirstEdgeReference.law h 1,t≤h := by
  apply Measure.ae_smul_measure
  apply (ae_map_iff (show Measurable (FirstEdgeReference.clip h) by unfold FirstEdgeReference.clip;fun_prop).aemeasurable
    measurableSet_Iic).mpr
  exact ae_of_all _ fun p=>min_le_left _ _

theorem erased_upper (n : ℕ) (h m B : ℝ) :
    (Measure.pi (fun _ : Fin (n+1)=>FirstEdgeReference.law h 1)).real (erased n B) ≤
    (restricted (n+1) (FirstEdgeReference.law h 1) h (B+h)).toReal-
    (restricted (n+1) (FirstEdgeReference.law h 1) m (B+h)).toReal+
    (restricted (n+1) (FirstEdgeReference.law h 1) m (B+m)).toReal := by
  let Q:=FirstEdgeReference.law h 1
  let μ:=Measure.pi (fun _ : Fin (n+1)=>Q)
  let M:={x : Fin (n+1)→ℝ | ∀ j,x j≤m}
  let A:=cut (n+1) (B+h)
  let L:=cut (n+1) (B+m)
  have inst : IsFiniteMeasure Q:=⟨by rw [FirstEdgeReference.mass zero_lt_one];exact ENNReal.ofReal_lt_top⟩
  have bound : ∀ᵐ w ∂μ,∀ j,w j≤h := ae_all_iff.mpr fun j=>
    (Measure.quasiMeasurePreserving_eval (fun _ : Fin (n+1)=>Q) j).ae (cap_support h)
  have cover : erased n B ≤ᵐ[μ] (A \ M) ∪ (L ∩ M) := by
    filter_upwards [bound] with w hw
    intro hit
    rcases partition hw hit with first|second
    · exact Or.inl ⟨first.1.le,first.2⟩
    · exact Or.inr ⟨second.1.le,second.2⟩
  have part := (ENNReal.toReal_mono (measure_ne_top μ _) (measure_mono_ae cover)).trans
      (measureReal_union_le (μ:=μ) (A\M) (L∩M))
  have ms : MeasurableSet M:=by
    change MeasurableSet {x : Fin (n+1)→ℝ | ∀ j,x j≤m}
    simp only [Set.ofPred_forall]
    exact MeasurableSet.iInter fun j=>measurableSet_le (measurable_pi_apply _) measurable_const
  have sub:=measureReal_sdiff_add_inter (μ:=μ) (s:=A) ms
  have hi : restricted (n+1) Q h (B+h)=μ A := by
    rw [event]
    apply measure_congr
    filter_upwards [bound] with w hw
    exact propext ⟨And.left,fun g=>⟨g,hw⟩⟩
  change μ.real (erased n B)≤(restricted (n+1) Q h (B+h)).toReal-(restricted (n+1) Q m (B+h)).toReal+(restricted (n+1) Q m (B+m)).toReal
  rw [hi,event,event]
  change μ.real (erased n B)≤μ.real A-μ.real (A∩M)+μ.real (L∩M)
  change μ.real (erased n B)≤μ.real (A\M)+μ.real (L∩M) at part
  linarith only [part,sub]

#print axioms erased_upper
end PrimeGap180.FirstEdgeSiteCDF

end
