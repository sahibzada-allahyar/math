import TrialLocalCompletion180

/-! The prime-field Fourier criterion implies the squarefree cycle hypothesis
used by the actual sampled distribution theorem. -/
noncomputable section
open scoped BigOperators Classical
open PrimeGap182.TypeIII PrimeGap180.Averaged
namespace PrimeGap180.Prefix

def envelopeBase (C d : ℝ) := 52488 + C*d^4 + C*d + C*d*8^4

private theorem envelopeBase_bounds {C d : ℝ} (hc : 0 ≤ C) (hd : 0 ≤ d) :
    52488 ≤ envelopeBase C d ∧ C*d*8^4 ≤ envelopeBase C d ∧
    C*d^4 ≤ envelopeBase C d ∧ C*d ≤ envelopeBase C d := by
  have h₁ := mul_nonneg hc (pow_nonneg hd 4)
  have h₂ := mul_nonneg hc hd
  have h₃ := mul_nonneg h₂ (show (0:ℝ) ≤ 8^4 by norm_num)
  unfold envelopeBase
  exact ⟨by linarith, by linarith, by linarith, by linarith⟩

theorem raw_le_cycleScale {C d P T L M R : ℝ} (t : ℕ) (hc : 0 ≤ C) (hd : 0 ≤ d)
    (hp : 1 ≤ P) (ht : 1 ≤ T) (hl : 1 ≤ L) (hm : 0 ≤ M) (hr : 0 ≤ R) :
    4*(52488:ℝ)^t*(R^2*M^3*P^2) +
      (C^t*P^3*((2*d^t*M)^4 + 4*d^t*M^3*Real.sqrt P))*(T*L)^2 +
      2*P⁻¹^2*R*(C^t*P^3*d^t*(2*R*Real.sqrt P + P*L))*(2*8^t*M)^4 ≤
      envelopeBase C d ^ t * 64 * T^2 * L^2 * cycleScale M R P := by
  let U := envelopeBase C d
  let K := U^t*64*T^2*L^2
  let Y₁ := R^2*M^3*P^2
  let Y₂ := R^2*M^4*P*Real.sqrt P
  let Y₃ := R*M^4*P^2
  let Y₄ := M^4*P^3
  let Y₅ := M^3*P^(7/2 : ℝ)
  have hp0 := zero_lt_one.trans_le hp
  have ht0 := zero_le_one.trans ht
  have hl0 := zero_le_one.trans hl
  have hL : L ≤ T^2*L^2 := by
    have t1 : 1 ≤ T^2 := one_le_pow₀ ht
    nlinarith only [mul_nonneg (sub_nonneg.mpr t1) (sq_nonneg L), mul_nonneg (sub_nonneg.mpr hl) hl0]
  have h1 : 1 ≤ T^2*L^2 := hl.trans hL
  have bound (s a v : ℝ) (hs : 0 ≤ s) (h64 : s ≤ 64) (ha : 0 ≤ a) (hu : a ≤ U)
      (hv : 0 ≤ v) (hV : v ≤ T^2*L^2) : s*a^t*v ≤ K := by
    have hu0 := ha.trans hu
    dsimp [K]
    calc
      _ ≤ 64*U^t*(T^2*L^2) := by gcongr
      _ = _ := by ring
  obtain ⟨hbig, haxis, hfour, hextra⟩ := envelopeBase_bounds hc hd
  have h₁ := bound 4 52488 1 (by norm_num) (by norm_num) (by norm_num) hbig (by norm_num) h1
  have h₂ := bound 64 (C*d*8^4) 1 (by norm_num) (by norm_num) (by positivity) haxis (by norm_num) h1
  have h₃ := bound 32 (C*d*8^4) L (by norm_num) (by norm_num) (by positivity) haxis hl0 hL
  have h₄ := bound 16 (C*d^4) (T^2*L^2) (by norm_num) (by norm_num) (by positivity) hfour (by positivity) le_rfl
  have h₅ := bound 4 (C*d) (T^2*L^2) (by norm_num) (by norm_num) (by positivity) hextra (by positivity) le_rfl
  have powEq : P^(7/2 : ℝ) = P^3*Real.sqrt P := by
    rw [show (7/2 : ℝ) = 3 + 1/2 by norm_num, Real.rpow_add hp0, Real.sqrt_eq_rpow]
    norm_num
  calc
    _ = (4*52488^t*1)*Y₁ + (64*(C*d*8^4)^t*1)*Y₂ + (32*(C*d*8^4)^t*L)*Y₃ +
          (16*(C*d^4)^t*(T^2*L^2))*Y₄ + (4*(C*d)^t*(T^2*L^2))*Y₅ := by
      dsimp [Y₁,Y₂,Y₃,Y₄,Y₅]
      rw [powEq]
      simp only [mul_pow, ← pow_mul, Nat.mul_comm 4 t]
      field_simp; ring
    _ ≤ K*Y₁ + K*Y₂ + K*Y₃ + K*Y₄ + K*Y₅ := by
      exact add_le_add (add_le_add (add_le_add (add_le_add
        (mul_le_mul_of_nonneg_right h₁ (by dsimp [Y₁]; positivity))
        (mul_le_mul_of_nonneg_right h₂ (by dsimp [Y₂]; positivity)))
        (mul_le_mul_of_nonneg_right h₃ (by dsimp [Y₃]; positivity)))
        (mul_le_mul_of_nonneg_right h₄ (by dsimp [Y₄]; positivity)))
        (mul_le_mul_of_nonneg_right h₅ (by dsimp [Y₅]; positivity))
    _ = _ := by dsimp [K,U,Y₁,Y₂,Y₃,Y₄,Y₅,cycleScale]; ring

theorem primeBoundsToCycles {C : ℝ} (hC : 0 ≤ C) {D : ℕ} (hD : 1 ≤ D)
    (base : BaselineLocalInputs) (geo : PrimeFourierBounds C D) : IntervalCycleEstimate := by
  intro ε hε
  let d : ℝ := 2*(D:ℝ)
  have hd : 0 ≤ d := by dsimp [d]; positivity
  let U := envelopeBase C d
  have hU : 1 ≤ U := (by norm_num : (1:ℝ) ≤ 52488).trans (envelopeBase_bounds hC hd).1
  obtain ⟨K,hK,bound⟩ := exists_primeFactor_divisor_log_subpower hU hε
  refine ⟨K,hK,?_⟩
  intro ι _ _ q _ _ hc α ha A B Ah Ak M R _
  let P := ∏ i, q i
  have hp : (1:ℝ) ≤ P := by exact_mod_cast (NeZero.one_le : 1 ≤ P)
  have ht : (1:ℝ) ≤ P.divisors.card := by
    exact_mod_cast Finset.card_pos.mpr ⟨1,Nat.one_mem_divisors.mpr (NeZero.ne P)⟩
  have hl : 1 ≤ 1+Real.log (P:ℝ) := by linarith [Real.log_nonneg hp]
  have raw := local_cycle_raw q hc α ha C hC D hD base geo A B Ah Ak M R
  apply raw.trans
  simp only [Nat.cast_pow, Nat.cast_mul, Nat.cast_ofNat]
  have sm := raw_le_cycleScale (Fintype.card ι) hC hd hp ht hl (Nat.cast_nonneg M) (Nat.cast_nonneg R)
  apply sm.trans
  apply mul_le_mul_of_nonneg_right _ (by unfold cycleScale; positivity)
  apply (show U^Fintype.card ι * 64 * (P.divisors.card:ℝ)^2 * (1+Real.log P)^2 ≤
      U^P.primeFactors.card * 64 * (P.divisors.card:ℝ)^2 * (1+Real.log P)^2 by
    gcongr; exact card_prime_family_le_primeFactors q hc).trans
  exact bound P (NeZero.ne P)

#print axioms primeBoundsToCycles
#print axioms cyclesToMatrix
#print axioms sampledSlotsOfMatrix
end PrimeGap180.Prefix
