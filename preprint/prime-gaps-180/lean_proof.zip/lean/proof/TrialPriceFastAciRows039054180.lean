import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G039
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 39

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G039

namespace PrimeGap180.PriceIsolatedGroup.G044
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 44

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G044

namespace PrimeGap180.PriceIsolatedGroup.G049
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 49

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G049

namespace PrimeGap180.PriceIsolatedGroup.G054
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 54

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G054
