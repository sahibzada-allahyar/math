import TrialRemovedHighMass180
import TrialFrozenCapIndices180
import TrialRestorationMassBudget180

/-! Split the physical high-mass target over the nine actual maximum-mark
bands of the positive signed-Gram archive. -/
noncomputable section
open scoped Classical BigOperators ENNReal
open MeasureTheory PrimeGap186 PrimeGap180.Sector PrimeGap180.FrozenProfile
open PrimeGap180.GateDeletion PrimeGap180.RemovedHighTags PrimeGap180.RemovedHighMass
namespace PrimeGap180.HighMassBands
open private least_spec least_of_pass from TrialStructuralGate180
open private meas_bands from TrialRemovedHighMass180

def capClass : Fin 9 → Fine := ![11,12,20,29,32,36,39,40,43]
def nativeCap : Fin 9 → ℕ := ![46567,47096,58332,60089,61104,63177,64599,65536,78116]
def units : Fin 9 → ℕ := ![3295000884,846355270,4582189432,7572416,924221,20633,1995,171,1]
def top (k : Fin 9) := FrozenData.mesh (T.capEdge (capClass k)).castSucc
def choice (b : Bits 39) := least (fun k => b (.cap (capClass k)))

set_option maxRecDepth 65536 in
theorem capTable (k : Fin 9) : top k = (nativeCap k:ℝ)*Native.step := by
  have h : ∀ k : Fin 9, FrozenCaps.index (capClass k) = nativeCap k := by decide +kernel
  rw [top,FrozenCaps.aligned,h]

private theorem large (k : Fin 9) : cutoff ≤ top k := by
  have h : ∀ k : Fin 9, 46567 ≤ nativeCap k := by decide +kernel
  have n : (46567:ℝ) ≤ (nativeCap k:ℝ) := by exact_mod_cast h k
  have p : 0 ≤ Native.step := by norm_num [Native.step]
  rw [capTable]
  exact (show cutoff ≤ 46567*Native.step by norm_num [cutoff,Lookup.ticks,Native.step]).trans
    (mul_le_mul_of_nonneg_right n p)

theorem chosen_band (Y : Fin 39 → FiniteMeasure ℝ) (n : Fin 39 → ℕ)
    (x : (i : Fin 39) → Fin (n i) → ℝ) (hY : ∀ i, (Y i).restrict (Set.Ioc 0 cutoff) = Y i)
    (hx : ∀ i a, cutoff < x i a ∧ x i a ≤ cap) (k : Fin 9)
    (chosen : choice (bits T (state Y n x)) = some k) :
    (∀ i a, x i a ≤ top k) ∧ ∀ j : Fin 9, j < k → ∃ i a, top j < x i a := by
  obtain ⟨ok,small⟩ := least_spec chosen
  exact ⟨(tagged_cap Y n x hY hx _ (large k)).mp ok, fun j hj => by
    by_contra! allBelow
    have pass := (tagged_cap Y n x hY hx _ (large j)).mpr allBelow
    exact Bool.noConfusion (pass.symm.trans (small j hj))⟩

set_option maxRecDepth 65536 in
private theorem chooses (X : Config) (nz : Restoration.original (bands X) ≠ 0) :
    ∃ k, choice (bits T (bands X)) = some k := by
  obtain ⟨c,chosen,_⟩ := StructuralGate.geometric_of_nonzero nz
  have ok := (least_spec chosen).1
  have csmall : Lookup.suffix (bands X) (T.capEdge c) < FrozenData.mesh (T.capEdge c).castSucc/2 := by
    change (if Lookup.suffix (bands X) (T.capEdge c) < FrozenData.mesh (T.capEdge c).castSucc / 2 then true else false) = true at ok
    by_contra h
    rw [ite_eq_right h] at ok
    exact Bool.false_ne_true ok
  have above : ∀ c : Fine, T.capEdge c ≤ T.capEdge (capClass 8) := by
    set_option maxRecDepth 65536 in decide +kernel
  have suffix := Lookup.suffix_antitone (bands X) (fun _ _ => NNReal.zero_le_coe) (above c)
  have width := T.ordered.monotone (Fin.castSucc_le_castSucc_iff.mpr (above c))
  have last : bits T (bands X) (.cap (capClass 8)) = true := by
    apply ite_eq_left
    change Lookup.suffix (bands X) (T.capEdge (capClass 8)) < FrozenData.mesh _/2
    change FrozenData.mesh _ ≤ FrozenData.mesh _ at width
    linarith only [suffix,csmall,width]
  obtain ⟨k,hk,_⟩ := least_of_pass (p:=fun k => bits T (bands X) (.cap (capClass k))) (j:=8) last
  exact ⟨k,hk⟩

def piece (k : Fin 9) (X : Config) := if choice (bits T (bands X)) = some k then
  (Restoration.original (bands X))^2 else 0

def bandMass (k : Fin 9) := ∫ X in charged, piece k X ∂law

private theorem part (X : Config) : ∑ k, piece k X = (Restoration.original (bands X))^2 := by
  by_cases z : Restoration.original (bands X) = 0
  · simp [piece,z]
  · obtain ⟨k,hk⟩ := chooses X z
    rw [Finset.sum_eq_single k]
    · simp [piece,hk]
    · intro j _ hj
      simp [piece,hk,Ne.symm hj]
    · simp

local instance : IsProbabilityMeasure (fragmentLaw cap) := fragmentLaw_isProbabilityMeasure _
local instance : IsFiniteMeasure (NativeSiteLaw.phys cap) := (fragmentLaw cap).smul_finite (by simp)
local instance : IsFiniteMeasure law := by unfold law; infer_instance

private theorem integrable_piece (k : Fin 9) : Integrable (piece k) (law.restrict charged) := by
  let f := fun b : Code => if choice b.1 = some k then (originalValue b.1)^2 else 0
  have reg := coded_regular T f
  exact integrable_of_measurable_of_bounded_range _ _ (reg.1.comp meas_bands)
    (reg.2.1.subset (by rintro v ⟨X,rfl⟩; exact ⟨bands X,rfl⟩))

theorem split : StructuralRun.layerMass 23 ≤ ∑ k : Fin 9, bandMass k := by
  apply mass_high.trans_eq
  unfold bandMass
  rw [←integral_finsetSum _ (fun k _ => integrable_piece k)]
  exact integral_congr_ae (ae_of_all _ fun X => (part X).symm)

/-- The nine archive rows are in units of 10⁻¹⁵ times the earlier 44.6 mass
floor. Their physical integral bounds imply the high-mass target at 94.17312. -/
theorem payment (floor : (94.17312:ℝ) ≤ 100^39 * RestorationBudget.originalMass)
    (raw : ∀ k : Fin 9, (100:ℝ)^39 * bandMass k ≤ (44.6:ℝ)*units k / 10^15) :
    StructuralRun.layerMass 23 ≤ RestorationRows.ticks 4135470 * RestorationBudget.originalMass := by
  have h := Finset.sum_le_sum (s:=Finset.univ) (fun k _ => raw k)
  rw [←Finset.mul_sum,←Finset.sum_div,←Finset.mul_sum,←Nat.cast_sum] at h
  have s : (∑ k, units k) = 8732065023 := by decide +kernel
  rw [s] at h
  have lo := mul_le_mul_of_nonneg_left split (show (0:ℝ) ≤ 100^39 by positivity)
  unfold RestorationRows.ticks
  linarith only [floor,h,lo]

#print axioms capTable
#print axioms chosen_band
#print axioms split
#print axioms payment
end PrimeGap180.HighMassBands
