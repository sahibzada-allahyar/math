import TrialDensityMomentCode180
import TrialDensityPackedDigits180

namespace PrimeGap180.PackedFive
open DensitySimplex.PackedDigits

private theorem pow_dvd (b i j : Nat) (h : i ≤ j) : b^i ∣ b^j := by
  refine ⟨b^(j-i), ?_⟩
  rw [← Nat.pow_add]
  congr 1; omega

theorem slice_div (x a w : Nat) : slice x a w = x/radix^a % radix^w := by
  unfold slice radix
  simp only [Nat.one_shiftLeft,Nat.shiftRight_eq_div_pow]
  rw [Nat.and_two_pow_sub_one_eq_mod,Nat.pow_mul,Nat.pow_mul]

theorem slice_comp (x a w k t : Nat) (hk : k+t ≤ w) :
    slice (slice x a w) k t = slice x (a+k) t := by
  simp only [slice_div]
  have hp : radix^w = radix^k * radix^(w-k) := by
    rw [← Nat.pow_add]; congr 1; omega
  rw [hp,Nat.mod_mul_right_div_self,Nat.mod_mod_of_dvd _ (pow_dvd radix t (w-k) (by omega)),
    Nat.div_div_eq_div_mul,Nat.pow_add]

def bias (w : Nat) : Nat := (radix/2)*(((1 <<< (320*w))-1)/(radix-1))

private theorem cast_radix : (radix:Int) = b := by decide +kernel

set_option exponentiation.threshold 321 in
private theorem bias_cast (w : Nat) :
    (bias w : Int) = offset b ((radix/2:Nat):Int) w := by
  have hb : 1 < b := by decide +kernel
  have hr : 0 < radix := by decide +kernel
  have h1 : 0 < radix^w := Nat.pow_pos hr
  rw [offset_closed _ _ hb]
  simp only [bias,Nat.one_shiftLeft,Nat.pow_mul]
  change (↑((radix/2)*((radix^w-1)/(radix-1))) : Int) = _
  rw [Int.natCast_mul,← Int.ofNat_ediv_ofNat (a:=radix^w-1) (b:=radix-1),Int.natCast_sub (by omega : 1 ≤ radix^w),
      Int.natCast_sub (by omega : 1 ≤ radix),Int.natCast_pow,cast_radix]
  rfl

private theorem encode_nonneg (l : List Int) (h : ∀ e ∈ l, 0 ≤ e) : 0 ≤ encode b l := by
  have hb : 0 ≤ b := by decide +kernel
  induction l with
  | nil => simp [encode]
  | cons a l ih =>
    exact Int.add_nonneg (h a (by simp)) (Int.mul_nonneg hb (ih (fun e he => h e (by simp [he]))))

/-- A single 320-bit extraction after the executable bias recovers its signed digit. -/
theorem slice_signed (l : List Int) (bounded : ∀ e ∈ l, 0 ≤ e+(radix/2:Nat) ∧ e+(radix/2:Nat) < b)
    (j : Nat) (hj : j < l.length) :
    (slice (encode b l + (bias l.length : Int)).toNat j 1 : Int) - (radix/2:Nat) = l[j] := by
  have E := signed_digit b (radix/2:Nat) (by decide +kernel) l bounded j hj
  have N : 0 ≤ encode b l + (bias l.length : Int) := by
    rw [bias_cast,← biased]
    apply encode_nonneg
    intro e he
    obtain ⟨v,hv,rfl⟩ := List.mem_map.mp he
    exact (bounded v hv).1
  rw [slice_div,Nat.pow_one,Int.natCast_emod,← Int.ofNat_ediv_ofNat,Int.toNat_of_nonneg N,
    Int.natCast_pow,cast_radix,bias_cast]
  exact E

theorem simplex_digit (l : List Int) (n j s k : Nat) (len : l.length = 2601*n+1)
    (hs : j+s+k ≤ n) (bounded : ∀ e ∈ l, 0 ≤ e+(radix/2:Nat) ∧ e+(radix/2:Nat) < b) :
    let x := (encode b l + (bias (2601*n+1) : Int)).toNat
    (slice (slice (slice x (2601*j) (51*(n-j)+1)) (51*s) (n-j-s+1)) k 1 : Int) -
      (radix/2:Nat) = l[2601*j+51*s+k]'(by omega) := by
  dsimp only
  rw [slice_comp _ _ _ k 1 (by omega),slice_comp _ _ _ (51*s+k) 1 (by omega),←len]
  simpa [Nat.add_assoc] using slice_signed l bounded (2601*j+51*s+k) (by omega)

theorem addTerms_congr {f g : Nat → Int} {n : Nat} (h : ∀ j ≤ n, f j = g j) :
    addTerms n f = addTerms n g := by
  have congrL (l : List Nat) (hl : ∀ j ∈ l, j ≤ n) :
      l.foldr (fun i a => f i + a) 0 = l.foldr (fun i a => g i + a) 0 := by
    induction l with
    | nil => rfl
    | cons i l ih =>
      simp only [List.foldr_cons]
      rw [h i (hl _ (by simp)),ih (fun j hj => hl j (by simp [hj]))]
  exact congrL _ (fun j hj => by have := List.mem_range.mp hj; omega)

/-- The exact factorial contraction computed by one outer word. Indices follow
the physical variable order i,j,k,s even though the bit fields store j,s,k. -/
def sliceMoment (i : Nat) (coef : Nat → Nat → Nat → Int) : Int :=
  let n := 50-i
  (fac i:Int)*h^i*addTerms n fun j =>
    (addTerms (n-j) fun s => (addTerms (n-j-s) fun k =>
      coef j k s * (fac k:Int) * h^k) * (fac s:Int)*h^s) * (fac j:Int)*h^j

theorem moments_of_digits (l : List Int) (i : Nat) (len : l.length = 2601*(50-i)+1)
    (bounded : ∀ e ∈ l, 0 ≤ e+(radix/2:Nat) ∧ e+(radix/2:Nat) < b)
    (coef : Nat → Nat → Nat → Int)
    (hc : ∀ j s k, j+s+k ≤ 50-i → l[2601*j+51*s+k]?.getD 0 = coef j k s) :
    moments (encode b l) i = sliceMoment i coef := by
  dsimp only [moments,sliceMoment]
  congr 1
  apply addTerms_congr
  intro j hj
  unfold middle
  congr 2
  apply addTerms_congr
  intro s hs
  unfold inner
  congr 2
  apply addTerms_congr
  intro k hk
  congr 2
  have ijk : j+s+k ≤ 50-i := by omega
  have p := simplex_digit l (50-i) j s k len ijk bounded
  exact p.trans (by simpa [List.getElem?_eq_getElem (by omega : 2601*j+51*s+k<l.length)] using hc j s k ijk)

#print axioms moments_of_digits
#print axioms simplex_digit
end PrimeGap180.PackedFive
