import TrialDensityContraction180
import TrialDensityShape180
import TrialDensitySimplexOrder180

namespace PrimeGap180.DensitySimplex.Horner
open PackedDigits PrimeGap180.PackedFive

theorem tableAt_fits (d n : Nat) (l : Table (d+1)) (hl : fits (d+1) n l) (j : Nat) :
    fits d (n-j) (tableAt d l j) := by
  by_cases hj : j < l.length
  · simpa [tableAt,List.getElem?_eq_getElem hj] using hl.2 j hj
  · simpa [tableAt,List.getElem?_eq_none (by omega : l.length ≤ j)] using fits_zero d (n-j)

def coeff3 (a : Table 3) (j k s : Nat) : Int :=
  tableAt 0 (tableAt 1 (tableAt 2 a j) k) s

private theorem two_dimensions (n : Nat) (a : Table 2) (ha : fits 2 n a) :
    encode h (degrees 2 a) =
      ∑ s ∈ Finset.range (n+1),
        (∑ k ∈ Finset.range (n-s+1), (tableAt 0 (tableAt 1 a k) s : Int) *
          (k.factorial:Int)*h^k) * (s.factorial:Int)*h^s := by
  rw [expand_degrees h 1 (n+1) a ha.1]
  calc
    _ = ∑ k ∈ Finset.range (n+1), ∑ s ∈ Finset.range (n-k+1),
        (tableAt 0 (tableAt 1 a k) s:Int) * (k.factorial:Int)*h^k*(s.factorial:Int)*h^s := by
      apply Finset.sum_congr rfl
      intro k hk
      rw [expand_degrees h 0 (n-k+1) (tableAt 1 a k) (tableAt_fits 1 n a ha k).1,
        Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro s hs
      simp only [degrees,encode,mul_zero,add_zero]
      ring
    _ = _ := by
      rw [triangle_swap]
      apply Finset.sum_congr rfl
      intro s hs
      simp only [Finset.sum_mul]

/-- Recover the encoded simplex moments by summing the slices in their storage order. -/
theorem physical_contraction (a : Table 4) (ha : fits 4 50 a) :
    encode h (degrees 4 a) =
    ∑ i ∈ Finset.range 51, sliceMoment i (coeff3 (tableAt 3 a i)) := by
  rw [expand_degrees h 3 51 a ha.1]
  apply Finset.sum_congr rfl
  intro i hi
  let A := tableAt 3 a i
  have hA : fits 3 (50-i) A := tableAt_fits 3 50 a ha i
  change _ * encode h (degrees 3 A) = _
  rw [expand_degrees h 2 (50-i+1) A hA.1]
  simp only [sliceMoment,addTerms_sum,fac_eq]
  congr 1
  apply Finset.sum_congr rfl
  intro j hj
  rw [two_dimensions (50-i-j) (tableAt 2 A j) (tableAt_fits 2 (50-i) A hA j)]
  simp only [coeff3,A,mul_assoc,mul_comm]

#print axioms physical_contraction
end PrimeGap180.DensitySimplex.Horner
