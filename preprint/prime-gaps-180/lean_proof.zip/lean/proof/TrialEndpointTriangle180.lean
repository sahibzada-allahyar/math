import TrialMarkedPartition180

/-! Lower bounds for the actual pair volume. A single finite grid fits
inside the 0.49995 fibre and pays the 0.4999 price uniformly in its radius. -/
noncomputable section
open scoped Classical BigOperators Topology
open Filter PrimeGap186
namespace PrimeGap180.EndpointVolume

private abbrev h : ℝ := 1/100000
private abbrev fraction : ℝ := 1-h

def members (x t : ℝ) := Finset.Icc 1 ⌊x^t⌋₊

def weight (H : Finset ℕ) (x : ℝ) (a : ℕ) : ℝ :=
  (if Squarefree a ∧ a.Coprime (presievingModulus H x) then 1/(a.totient:ℝ) else 0)/Sector.norm H x

def triangle (H : Finset ℕ) (x z : ℝ) : ℝ :=
  ∑ ab ∈ ((members x z) ×ˢ (members x z)).filter (fun ab => ((ab.1:ℝ)*ab.2) ≤ x^z),
    weight H x ab.1 * weight H x ab.2

private theorem prefix_limit (H : Finset ℕ) {t : ℝ} (ht : 0 < t) :
    Tendsto (fun x => ∑ a ∈ members x t, weight H x a) atTop (𝓝 (t/Sector.rho)) := by
  have raw := (PrimeGap182.Selberg.sharp_harmonic_normalizer_tendsto H t ht).div_const Sector.rho
  apply raw.congr'
  filter_upwards [eventually_gt_atTop (1:ℝ)] with x hx
  have norm : Sector.norm H x = Sector.rho * fragmentNormalization (presievingModulus H x) x := by
    simp only [Sector.norm,Sector.scale,fragmentNormalization,Real.log_rpow (zero_lt_one.trans hx)]
    ring
  unfold members weight
  rw [← Finset.sum_div,norm]
  ring

private def strip (x : ℝ) (k : ℕ) :=
  members x (((k:ℝ)+2)*h) \ members x (((k:ℝ)+1)*h)

private theorem members_mono {x t u : ℝ} (hx : 1 ≤ x) (le : t ≤ u) :
    members x t ⊆ members x u := Finset.Icc_subset_Icc_right
      (Nat.floor_mono (Real.rpow_le_rpow_of_exponent_le hx le))

private theorem strip_limit (H : Finset ℕ) (k : ℕ) :
    Tendsto (fun x => ∑ a ∈ strip x k, weight H x a) atTop (𝓝 (h/Sector.rho)) := by
  have lim := (prefix_limit H (by positivity : 0 < ((k:ℝ)+2)*h)).sub
    (prefix_limit H (by positivity : 0 < ((k:ℝ)+1)*h))
  rw [show (((k:ℝ)+2)*h)/Sector.rho-(((k:ℝ)+1)*h)/Sector.rho = h/Sector.rho by ring] at lim
  apply lim.congr'
  filter_upwards [eventually_ge_atTop (1:ℝ)] with x hx
  have sub := members_mono hx (by dsimp [h]; linarith : ((k:ℝ)+1)*h ≤ ((k:ℝ)+2)*h)
  exact (Finset.sum_sdiff_eq_sub sub).symm

private theorem strips_disjoint {x : ℝ} (hx : 1 ≤ x) {k l : ℕ} (ne : k ≠ l) :
    Disjoint (strip x k) (strip x l) := by
  have ordered {a b : ℕ} (lt : a < b) : Disjoint (strip x a) (strip x b) := by
    apply Finset.disjoint_left.mpr
    intro n ha hb
    have ord : (a:ℝ)+2 ≤ (b:ℝ)+1 := by exact_mod_cast (show a+2 ≤ b+1 by omega)
    exact (Finset.mem_sdiff.mp hb).2 (members_mono hx
      (mul_le_mul_of_nonneg_right ord (by norm_num)) (Finset.mem_sdiff.mp ha).1)
  exact (lt_or_gt_of_ne ne).elim ordered fun h => (ordered h).symm

private def rectangle (x : ℝ) (n k : ℕ) :=
  strip x k ×ˢ members x (((n-k:ℕ):ℝ)*h)

private theorem grid_lower (H : Finset ℕ) {x z : ℝ} (hx : 1 < x) (n : ℕ)
    (fits : ((n:ℝ)+2)*h ≤ z)
    (bands : ∀ k < n, fraction*h/Sector.rho ≤ ∑ a ∈ strip x k, weight H x a)
    (prefixes : ∀ i, 0 < i → i ≤ n →
      fraction*((i:ℝ)*h)/Sector.rho ≤ ∑ a ∈ members x ((i:ℝ)*h), weight H x a) :
    (fraction*((n:ℝ)*h))^2/(2*Sector.rho^2) ≤ triangle H x z := by
  let w := weight H x
  have wp (a : ℕ) : 0 ≤ w a := by
    have bp : 0 < Sector.norm H x := PrimeGap182.Selberg.fragmentNormalization_pos H x (Sector.scale x)
      (Real.one_lt_rpow hx (by norm_num [Sector.rho]))
    dsimp [w,weight]
    split_ifs <;> positivity
  let cost := fun ab : ℕ × ℕ => w ab.1*w ab.2
  let T := ((members x z) ×ˢ (members x z)).filter (fun ab => (ab.1:ℝ)*ab.2 ≤ x^z)
  have sub : (Finset.range n).biUnion (rectangle x n) ⊆ T := by
    intro ab hab
    obtain ⟨k,hk,hmem⟩ := Finset.mem_biUnion.mp hab
    obtain ⟨p,q⟩ := Finset.mem_product.mp hmem
    have kn := Finset.mem_range.mp hk
    have dk : ((n-k:ℕ):ℝ) = (n:ℝ)-k := Nat.cast_sub kn.le
    have ku : (k:ℝ) ≤ n := by exact_mod_cast kn.le
    have kz : ((k:ℝ)+2)*h ≤ z := le_trans (by gcongr) fits
    have bz : ((n-k:ℕ):ℝ)*h ≤ z := le_trans (by rw [dk]; dsimp [h]; linarith) fits
    have p' := (Finset.mem_sdiff.mp p).1
    have amax := (Nat.cast_le.mpr (Finset.mem_Icc.mp p').2).trans
      (Nat.floor_le (Real.rpow_nonneg (zero_lt_one.trans hx).le _))
    have bmax := (Nat.cast_le.mpr (Finset.mem_Icc.mp q).2).trans
      (Nat.floor_le (Real.rpow_nonneg (zero_lt_one.trans hx).le _))
    apply Finset.mem_filter.mpr
    refine ⟨Finset.mem_product.mpr ⟨members_mono hx.le kz p',members_mono hx.le bz q⟩,?_⟩
    apply (mul_le_mul amax bmax (Nat.cast_nonneg _) (Real.rpow_nonneg (zero_lt_one.trans hx).le _)).trans
    rw [← Real.rpow_add (zero_lt_one.trans hx),dk]
    exact Real.rpow_le_rpow_of_exponent_le hx.le (by linarith only [fits])
  have dis : ∀ k ∈ Finset.range n, ∀ j ∈ Finset.range n, k ≠ j →
      Disjoint (rectangle x n k) (rectangle x n j) := by
    intro k _ j _ ne
    exact Finset.disjoint_left.mpr fun _ p q => (Finset.disjoint_left.mp (strips_disjoint hx.le ne))
      (Finset.mem_product.mp p).1 (Finset.mem_product.mp q).1
  have rcost (k) : (∑ ab ∈ rectangle x n k, cost ab) =
      (∑ a ∈ strip x k, w a) * (∑ b ∈ members x (((n-k:ℕ):ℝ)*h), w b) := by
    simp only [rectangle,cost,Finset.sum_product,Finset.sum_mul,Finset.mul_sum]
    exact Finset.sum_comm
  have row (k : ℕ) (hk : k ∈ Finset.range n) :
      ((n:ℝ)-k)*(fraction*h/Sector.rho)^2 ≤ ∑ ab ∈ rectangle x n k, cost ab := by
    have kn := Finset.mem_range.mp hk
    rw [rcost]
    have z := mul_le_mul (bands _ kn) (prefixes (n-k) (by omega) (by omega))
      (by positivity) (Finset.sum_nonneg (fun a _ => wp a))
    rw [Nat.cast_sub kn.le] at z ⊢
    apply le_trans _ z
    exact le_of_eq (by ring)
  have count (m : ℕ) : ∑ k ∈ Finset.range m, ((m:ℝ)-k) = (m:ℝ)*((m:ℝ)+1)/2 := by
    induction m with
    | zero => simp
    | succ m ih =>
      rw [Finset.sum_range_succ,Nat.cast_succ]
      simp_rw [show ∀ k : ℕ, (m:ℝ)+1-k = ((m:ℝ)-k)+1 by intro k; ring,
        Finset.sum_add_distrib,ih,Finset.sum_const,Finset.card_range,nsmul_eq_mul]
      ring
  have z := Finset.sum_le_sum row
  rw [← Finset.sum_mul,count,← Finset.sum_biUnion dis] at z
  have bigger := z.trans (Finset.sum_le_sum_of_subset_of_nonneg sub (fun ab _ _ => mul_nonneg (wp _) (wp _)))
  change _ ≤ ∑ ab ∈ T, cost ab
  apply le_trans _ bigger
  norm_num [fraction,h,Sector.rho]
  nlinarith only [Nat.cast_nonneg (α := ℝ) n]

/-- On every sufficiently large dyadic scale, simultaneously for every
retained radius on the trial, the independent two-endpoint fibre has
enough harmonic mass to pay the certificate's inverse-square price. -/
theorem physical_triangle_lower (H : Finset ℕ) :
    ∀ᶠ x : ℝ in atTop, ∀ q ∈ Set.Icc (0:ℝ) 0.2801,
      (0.4999-q)^2/(2*Sector.rho^2) ≤ triangle H x (0.49995-q) := by
  have limit1 (k : Fin 50001) := (strip_limit H k).eventually_const_le
    (by norm_num [fraction,h,Sector.rho] : fraction*h/Sector.rho < h/Sector.rho)
  have limit2 (i : Fin 50001) : ∀ᶠ x : ℝ in atTop, 0 < i.val →
      fraction*((i:ℝ)*h)/Sector.rho ≤ ∑ a ∈ members x ((i:ℝ)*h), weight H x a := by
    by_cases hi : 0 < i.val
    · have pos : 0 < (i:ℝ) := Nat.cast_pos.mpr hi
      have hp : 0 < (i:ℝ)*h := mul_pos pos (by norm_num)
      have frac : fraction*((i:ℝ)*h)/Sector.rho < ((i:ℝ)*h)/Sector.rho :=
        (div_lt_div_iff_of_pos_right (by norm_num [Sector.rho])).mpr (mul_lt_of_lt_one_left hp (by norm_num [fraction,h]))
      have ev := (prefix_limit H hp).eventually_const_le frac
      filter_upwards [ev] with x hx using fun _ => hx
    · exact .of_forall fun _ pos => (hi pos).elim
  filter_upwards [eventually_gt_atTop (1:ℝ),eventually_all.mpr limit1,eventually_all.mpr limit2] with x hx one two
  intro q hq
  let N := ⌊(0.49995-q)/h⌋₊
  have lo := Nat.floor_le (show 0 ≤ (0.49995-q)/h by have := hq.2; dsimp [h]; linarith)
  have hi := Nat.lt_floor_add_one ((0.49995-q)/h)
  change (N:ℝ) ≤ _ at lo
  change _ < (N:ℝ)+1 at hi
  have big : 2 ≤ N := by
    have z : (2:ℝ) ≤ N := by have := hq.2; dsimp [h] at hi; linarith
    exact_mod_cast z
  have bound : N < 50001 := by
    have z : (N:ℝ) < 50001 := by have := hq.1; dsimp [h] at lo; linarith
    exact_mod_cast z
  have eq := Nat.cast_sub (R := ℝ) big
  have fits : (((N-2:ℕ):ℝ)+2)*h ≤ 0.49995-q := by rw [eq]; dsimp [h] at lo ⊢; linarith
  have lower := grid_lower H hx (N-2) fits
    (fun k hk => one ⟨k,by omega⟩) (fun i ip it => two ⟨i,by omega⟩ ip)
  apply le_trans _ lower
  apply div_le_div_of_nonneg_right _ (by positivity)
  apply pow_le_pow_left₀ (by have := hq.2; linarith) _ 2
  rw [eq]
  dsimp [h,fraction] at hi ⊢
  linarith only [hi,hq.1]

#print axioms physical_triangle_lower
end PrimeGap180.EndpointVolume
