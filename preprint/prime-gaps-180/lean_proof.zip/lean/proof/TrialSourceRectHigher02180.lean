import TrialSourceRectChecks180
namespace PrimeGap180.SourceRectChecks.Higher02

set_option maxRecDepth 131072
set_option maxHeartbeats 100000000

theorem verified : row (.higher 2) = true := by decide +kernel

#print axioms verified
end PrimeGap180.SourceRectChecks.Higher02
