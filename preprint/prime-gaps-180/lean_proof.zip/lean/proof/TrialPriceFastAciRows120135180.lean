import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G120
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 120

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G120

namespace PrimeGap180.PriceIsolatedGroup.G125
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 125

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G125

namespace PrimeGap180.PriceIsolatedGroup.G130
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 130

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G130

namespace PrimeGap180.PriceIsolatedGroup.G135
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 135

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G135
