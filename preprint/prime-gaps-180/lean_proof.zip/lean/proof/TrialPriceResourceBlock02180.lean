import TrialPriceResourceRows180
namespace PrimeGap180.PriceResourceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 100000000
private theorem p14 : checkResource 14 = true := by decide +kernel
private theorem p15 : checkResource 15 = true := by decide +kernel
private theorem p16 : checkResource 16 = true := by decide +kernel
private theorem p17 : checkResource 17 = true := by decide +kernel
private theorem p18 : checkResource 18 = true := by decide +kernel
private theorem p19 : checkResource 19 = true := by decide +kernel
private theorem p20 : checkResource 20 = true := by decide +kernel
theorem block2 : ∀ j : Fin 7, checkResource (14+j.val) = true :=
  Fin.cases p14 (Fin.cases p15 (Fin.cases p16 (Fin.cases p17 (Fin.cases p18 (Fin.cases p19 (Fin.cases p20 (fun i => Fin.elim0 i)))))))
#print axioms block2
end PrimeGap180.PriceResourceRows
