import TrialFixedTagIntegral180

/-! Replace the remaining small-fragment mass by its Dickman law under a
fixed tag count. A pointwise majorant can retain every large-mark coordinate. -/
noncomputable section
open scoped Classical ENNReal BigOperators
open MeasureTheory PrimeGap186 PrimeGap180.JanossyLaw
namespace PrimeGap180.FixedTagRadial
open FixedTagIntegral
open private marks from TrialJanossyRadial180

private def mass (Y : FiniteMeasure ℝ) : ℝ := Y.mass
private theorem mass_meas : Measurable mass :=
  ((Measure.measurable_coe MeasurableSet.univ).comp measurable_subtype_coe).ennreal_toReal

private theorem small_density {e : ℝ} (he : 0 < e) :
    (PoissonSplit.phys e).map mass ≤ volume.restrict (Set.Ici (0:ℝ)) := by
  rw [PoissonSplit.phys,Measure.map_smul _ mass_meas.aemeasurable]
  change ENNReal.ofReal (Real.exp Real.eulerMascheroniConstant * e) •
    (fragmentLaw e).map (fun Y : FiniteMeasure ℝ => (Y.mass:ℝ)) ≤ _
  rw [normalized_fragmentLaw_mass_eq_dickman _ he]
  have upper : ∀ᵐ t ∂volume.restrict (Set.Ici (0:ℝ)), ENNReal.ofReal (dickmanRho (t/e)) ≤ 1 :=
    ae_of_all _ fun t => by simpa using ENNReal.ofReal_le_ofReal (dickmanRho_analytic.2.2.2.2.2.1 (t/e)).2
  simpa using withDensity_mono upper

private theorem mass_insert (Y : FiniteMeasure ℝ) (k : ℕ) (u : Fin k → ℝ)
    (hu : ∀ i, 0 ≤ u i) : mass (Y + weightedEmpirical k u) = mass Y + total u := by
  change ((Y + weightedEmpirical k u : FiniteMeasure ℝ) : Measure ℝ).real Set.univ = _
  rw [Measure.real,FiniteMeasure.toMeasure_add,Measure.add_apply,coe_weightedEmpirical,Measure.finsetSum_apply]
  simp only [Measure.smul_apply,Measure.dirac_apply_of_mem (Set.mem_univ _),smul_eq_mul,mul_one]
  rw [ENNReal.toReal_add (measure_ne_top _ _) (ENNReal.sum_ne_top.mpr (fun _ _ => ENNReal.ofReal_ne_top)),
    ENNReal.toReal_sum (fun _ _ => ENNReal.ofReal_ne_top)]
  simp only [ENNReal.toReal_ofReal (hu _)]
  rfl

/-- For a fixed count, a positive majorant may retain both the residual radial
coordinate and the individual positions of all large marks, including their bins. -/
theorem majorant {e b : ℝ} (he : 0 < e) (hb : e ≤ b) (k : ℕ)
    (F : FiniteMeasure ℝ → ℝ≥0∞) (hF : Measurable F)
    (G : ℝ → (Fin k → ℝ) → ℝ≥0∞) (hG : Measurable (Function.uncurry G))
    (bound : ∀ (Y : FiniteMeasure ℝ), Y.restrict (Set.Ioc 0 e) = Y →
      ∀ (u : Fin k → ℝ), (∀ i, u i ∈ Set.Ioc e b) →
        F (Y + weightedEmpirical k u) ≤ G (Y.mass:ℝ) u) :
    (∫⁻ X in {X | markCount e X = k}, F X ∂PoissonSplit.phys b) ≤
      ∫⁻ u, (k.factorial:ℝ≥0∞)⁻¹ *
        (∫⁻ t in Set.Ici (0:ℝ), G t u ∂volume) ∂prodLaw e b k := by
  let : IsFiniteMeasure (PoissonSplit.intensity e b) := (PoissonSplit.jumps he hb).property
  let : IsFiniteMeasure (prodLaw e b k) := by unfold prodLaw; infer_instance
  let ν := volume.restrict (Set.Ici (0:ℝ))
  let H (t : ℝ) (u : Fin k → ℝ) := (k.factorial:ℝ≥0∞)⁻¹ * G t u
  have mh : Measurable (Function.uncurry H) := measurable_const.mul hG
  have inner : Measurable (fun t => ∫⁻ u, H t u ∂prodLaw e b k) := mh.lintegral_prod_right
  have small : ∀ᵐ Y ∂PoissonSplit.phys e, Y.restrict (Set.Ioc 0 e) = Y :=
    Measure.ae_smul_measure (ae_restrict_Ioc_fragmentLaw e)
      (ENNReal.ofReal (Real.exp Real.eulerMascheroniConstant * e))
  rw [fixed he hb k F hF]
  calc
    _ ≤ ∫⁻ Y, ∫⁻ u, H (mass Y) u ∂prodLaw e b k ∂PoissonSplit.phys e := by
      apply lintegral_mono_ae
      filter_upwards [small] with Y hY
      rw [show (∫⁻ u, H (mass Y) u ∂prodLaw e b k) =
        (k.factorial:ℝ≥0∞)⁻¹ * ∫⁻ u, G (mass Y) u ∂prodLaw e b k from
        lintegral_const_mul _ ((hG.comp (measurable_const.prodMk measurable_id)))]
      apply mul_le_mul_of_nonneg_left _ zero_le
      apply lintegral_mono_ae
      filter_upwards [marks he hb k] with u hu
      exact bound Y hY u hu
    _ = ∫⁻ t, ∫⁻ u, H t u ∂prodLaw e b k ∂(PoissonSplit.phys e).map mass :=
      (lintegral_map inner mass_meas).symm
    _ ≤ ∫⁻ t, ∫⁻ u, H t u ∂prodLaw e b k ∂ν := lintegral_mono' (small_density he) (fun _ => le_rfl)
    _ = ∫⁻ u, ∫⁻ t, H t u ∂ν ∂prodLaw e b k := lintegral_lintegral_swap mh.aemeasurable
    _ = _ := by
      apply lintegral_congr
      intro u
      exact lintegral_const_mul _ (hG.comp (measurable_id.prodMk measurable_const))

/-- Exactly k tags on a site in a radial cell: at fixed marked positions the
remaining mass has permissible length max(0, H - sum u - max(0, L - sum u)). -/
theorem cell {e b : ℝ} (he : 0 < e) (hb : e ≤ b) (k : ℕ) (L H : ℝ) :
    (PoissonSplit.phys b) ({X | markCount e X = k} ∩ {X : FiniteMeasure ℝ | (X.mass:ℝ) ∈ Set.Ico L H}) ≤
      ∫⁻ u, (k.factorial:ℝ≥0∞)⁻¹ *
        ENNReal.ofReal (H - total u - max 0 (L - total u)) ∂prodLaw e b k := by
  let A := {X : FiniteMeasure ℝ | (X.mass:ℝ) ∈ Set.Ico L H}
  have mA : MeasurableSet A := mass_meas measurableSet_Ico
  let F := A.indicator (fun _ => (1:ℝ≥0∞))
  let G := fun (t : ℝ) (u : Fin k → ℝ) => (Set.Ico L H).indicator (fun _ => (1:ℝ≥0∞)) (t + total u)
  have mt : Measurable (@total k) := by unfold total; fun_prop
  have mG : Measurable (Function.uncurry G) :=
    (measurable_const.indicator measurableSet_Ico).comp (measurable_fst.add (mt.comp measurable_snd))
  have h := majorant he hb k F (measurable_const.indicator mA) G mG (by
    intro Y _ u hu
    have m := mass_insert Y k u (fun i => (he.trans (hu i).1).le)
    change A.indicator (fun _ => 1) _ ≤ _
    simp only [A,Set.indicator_apply,Set.mem_ofPred_eq,G]
    change (if mass (Y + weightedEmpirical k u) ∈ Set.Ico L H then 1 else 0) ≤ _
    rw [m]
    exact le_rfl)
  have left : (∫⁻ X in {X | markCount e X = k}, F X ∂PoissonSplit.phys b) =
    (PoissonSplit.phys b) ({X | markCount e X = k} ∩ A) := by
    rw [show F = A.indicator (fun _ => (1:ℝ≥0∞)) from rfl,lintegral_indicator mA,lintegral_const,
      Measure.restrict_apply_univ,one_mul,Measure.restrict_apply mA,Set.inter_comm]
  rw [←left]
  apply h.trans_eq
  apply lintegral_congr
  intro u
  congr 1
  have cut : ∀ t, G t u = (Set.Ico (L-total u) (H-total u)).indicator (fun _ => (1:ℝ≥0∞)) t := by
    intro t
    simp [G,Set.indicator_apply,Set.mem_Ico,lt_sub_iff_add_lt]
  simp_rw [cut]
  rw [lintegral_indicator measurableSet_Ico,lintegral_const,Measure.restrict_apply_univ,one_mul,
    Measure.restrict_apply measurableSet_Ico]
  have sets : Set.Ico (L-total u) (H-total u) ∩ Set.Ici 0 = Set.Ico (max 0 (L-total u)) (H-total u) := by
    ext t
    simp only [Set.mem_inter_iff,Set.mem_Ico,Set.mem_Ici,max_le_iff]
    tauto
  rw [sets,Real.volume_Ico]

#print axioms majorant
#print axioms cell
end PrimeGap180.FixedTagRadial
