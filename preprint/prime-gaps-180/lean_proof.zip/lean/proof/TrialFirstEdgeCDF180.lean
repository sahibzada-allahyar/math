import TrialFirstEdgeDust180
import TrialFirstEdgeRegular180
import TrialRemovalEdgeBook180

/-! The integrated uniform lower comparison on the literal band arrays used
in the frozen trial. It holds on every measurable subset of each regular
native total cell for both exceptional low edges. -/
noncomputable section
open scoped Classical ENNReal BigOperators
open MeasureTheory PrimeGap186 PrimeGap180.FrozenProfile PrimeGap180.Sector PrimeGap180.FrozenData
open PrimeGap180.DebitNativeClasses
namespace PrimeGap180.FirstEdgeCDF

private def edge (j : Fin 217) := FrozenData.mesh j.castSucc
private def Q (j : Fin 217) (s : ℝ) (G : ℝ→ℝ≥0∞) (z : Band 216) :=
  if NativeSiteLaw.radial z - NativeSiteLaw.tail j z ≤ s then G (NativeSiteLaw.radial z) else 0

open private radial_meas tail_meas from TrialNativeSiteLaw180

private theorem qm (j : Fin 217) (s : ℝ) (G : ℝ→ℝ≥0∞) (mG : Measurable G) : Measurable (Q j s G) :=
  Measurable.ite (measurableSet_le (radial_meas.sub (tail_meas j)) measurable_const) (mG.comp radial_meas) measurable_const

private theorem stats (X : FiniteMeasure ℝ) (covers : X.restrict (Set.Ioc 0 cap)=X) (j : Fin 217) :
    NativeSiteLaw.radial (fragmentBandMasses mesh X)=(X.mass:ℝ) ∧
      NativeSiteLaw.radial (fragmentBandMasses mesh X)-NativeSiteLaw.tail j (fragmentBandMasses mesh X)=
        FirstEdgeDust.dust (edge j) X := by
  have mono : Monotone mesh:=tables.ordered.monotone
  have first : mesh 0=0:=tables.first
  have last : mesh (Fin.last 217)=cap:=tables.last
  have lo : 0≤edge j:=first ▸ mono (Fin.zero_le j.castSucc)
  have hi : edge j≤cap:=last ▸ mono (Fin.le_last j.castSucc)
  have rad : NativeSiteLaw.radial (fragmentBandMasses mesh X)=(X.mass:ℝ) := by
    rw [NativeSiteLaw.radial,sum_fragmentBandMasses mesh mono,first,last,covers]
  refine ⟨rad,?_⟩
  rw [NativeSiteLaw.radial,sum_fragmentBandMasses mesh mono,first,last,
    NativeSiteLaw.tail,trial_band_tail_eq mesh mono,last,FiniteMeasure.restrict_mass]
  change (X:Measure ℝ).real (Set.Ioc 0 cap) - (X:Measure ℝ).real (Set.Ioc (edge j) cap) =
    (X:Measure ℝ).real (Set.Ioc 0 (edge j))
  rw [←Set.Ioc_union_Ioc_eq_Ioc lo hi,
    measureReal_union (Set.Ioc_disjoint_Ioc_of_le le_rfl) measurableSet_Ioc,add_sub_cancel_right]

theorem caps (j c : Fin 217) (he : 0<edge j) (hc : edge j≤edge c) {s : ℝ} (hs : 0≤ s) (hse : s<edge j)
    (G : ℝ→ℝ≥0∞) (mG : Measurable G) (supp : ∀ t,t<edge j → G t=0) :
    (∫⁻ z,Q j s G z ∂(bandLaw mesh).restrict (NativeSiteLaw.capped c)) ≤
      ENNReal.ofReal (s/edge j)*∫⁻ t,G t := by
  have ca : edge c≤cap:=tables.last ▸ tables.ordered.monotone (Fin.le_last c.castSucc)
  rw [NativeSiteLaw.capped_bandLaw c (he.trans_le hc),lintegral_map (qm j s G mG) (measurable_fragmentBandMasses mesh)]
  apply le_trans _ (FirstEdgeDust.physical he hc hs hse G mG supp)
  apply le_of_eq
  apply lintegral_congr_ae
  have cover : ∀ᵐ X ∂NativeSiteLaw.phys (edge c), X.restrict (Set.Ioc 0 (edge c))=X :=
    Measure.ae_smul_measure (ae_restrict_Ioc_fragmentLaw _) (ENNReal.ofReal (Real.exp Real.eulerMascheroniConstant*edge c))
  filter_upwards [cover] with X hX
  obtain ⟨rad,ds⟩ := stats X (trial_restrict_eq_self_of_subset X _ _ hX (Set.Ioc_subset_Ioc le_rfl ca)) j
  unfold Q FirstEdgeDust.weight
  rw [ds,rad]

open private min_cap from TrialFirstEdgeRegular180

private theorem fits (a : Active) (ha : a.val≤1) (c : DebitNativeClasses.Class) :
    edge (tables.tailEdge a) ≤ edge (tables.capEdge (capAt c)) := by
  have pos : 0<Lookup.ticks:=by norm_num [Lookup.ticks]
  have n := (show ∀ a : Active,a.val≤1 → RemovalEdgeBook.lowerNat a≤100 by decide +kernel) a ha
  have line := RemovalEdgeBook.ticks_eq a
  have one : edge (tables.tailEdge a) ≤ 100/Lookup.ticks := by
    apply (le_div_iff₀ pos).mpr
    change mesh (tables.tailEdge a).castSucc*Lookup.ticks≤100
    rw [mul_comm,line]
    exact_mod_cast n
  apply one.trans
  unfold edge
  rw [FrozenCaps.aligned]
  calc
    100/Lookup.ticks ≤ 45067*Native.step := by norm_num [Native.step,Lookup.ticks]
    _ ≤ _ := mul_le_mul_of_nonneg_right (by exact_mod_cast min_cap c) (by norm_num [Native.step])

/-- On every measurable subset S of regular native totals above the chosen
edge, the genuine conditional dust CDF is bounded by that of U[0,e].
The denominator is the actual physical mass on precisely the same S. -/
theorem regular (a : Active) (ha : a.val≤1) (k : ℕ) (hk : k<45067) (c : DebitNativeClasses.Class)
    (S : Set ℝ) (mS : MeasurableSet S) (inside : S⊆Set.Ico ((k:ℝ)*Native.step) (((k:ℝ)+1)*Native.step))
    (above : S⊆Set.Ici (edge (tables.tailEdge a))) (s : ℝ) (hs : 0≤ s) (hse : s<edge (tables.tailEdge a)) :
    ((bandLaw mesh).restrict (NativeSiteLaw.capped (tables.capEdge (capAt c))))
      {z | NativeSiteLaw.radial z∈S ∧ NativeSiteLaw.radial z-NativeSiteLaw.tail (tables.tailEdge a) z≤ s} ≤
      ENNReal.ofReal (s/edge (tables.tailEdge a))*
      ((bandLaw mesh).restrict (NativeSiteLaw.capped (tables.capEdge (capAt c)))) {z | NativeSiteLaw.radial z∈S} := by
  let j := tables.tailEdge a
  let C := tables.capEdge (capAt c)
  let M := (bandLaw mesh).restrict (NativeSiteLaw.capped C)
  let G := S.indicator (fun _=> (1:ℝ≥0∞))
  have mg : Measurable G:=measurable_const.indicator mS
  have supp (t) (h : t<edge j) : G t=0:=Set.indicator_of_notMem (fun ht=>(above ht).not_gt h) _
  have ok := caps j C (tables.tailPos a) (fits a ha c) hs hse G mg supp
  have denom : M {z | NativeSiteLaw.radial z∈S}=volume S := by
    have u:=FirstEdgeRegular.uniform k hk c S mS inside
    rwa [Measure.map_apply radial_meas mS] at u
  have test : (∫⁻ t,G t)=volume S := by rw [lintegral_indicator mS]; simp
  let A := {z | NativeSiteLaw.radial z∈S ∧ NativeSiteLaw.radial z-NativeSiteLaw.tail j z≤ s}
  have mA : MeasurableSet A := (radial_meas mS).inter (measurableSet_le (radial_meas.sub (tail_meas j)) measurable_const)
  have cost : (∫⁻ z,Q j s G z ∂M)=M A := by
    have eq : Q j s G=A.indicator (fun _=>1) := by
      funext z
      by_cases v : NativeSiteLaw.radial z∈S <;> by_cases d : NativeSiteLaw.radial z-NativeSiteLaw.tail j z≤ s <;>
        simp [Q,A,G,v,d,Set.indicator_apply] <;> linarith only [d]
    rw [eq,lintegral_indicator mA]
    simp
  change M A≤_*M {z | NativeSiteLaw.radial z∈S}
  rw [denom,←test,←cost]
  exact ok

/-- At any smaller total all occupied fragments lie below the tested edge.
Consequently the upper-cell slack plus the dust equals the cell endpoint. -/
theorem below (j c : Fin 217) (he : 0<edge j) (hc : 0<edge c) :
    ∀ᵐ z ∂(bandLaw mesh).restrict (NativeSiteLaw.capped c), NativeSiteLaw.radial z≤edge j →
      NativeSiteLaw.tail j z=0 ∧ ∀ u : ℝ,(u-NativeSiteLaw.radial z) +
        (NativeSiteLaw.radial z-NativeSiteLaw.tail j z)=u := by
  have gap : ∀ᵐ z ∂(bandLaw mesh).restrict (NativeSiteLaw.capped c),
      NativeSiteLaw.tail j z=0 ∨ edge j<NativeSiteLaw.tail j z :=
    ae_restrict_le (NativeSiteLaw.threshold_gap j he)
  have nn : ∀ᵐ z ∂(bandLaw mesh).restrict (NativeSiteLaw.capped c), NativeSiteLaw.tail j z≤NativeSiteLaw.radial z := by
    rw [NativeSiteLaw.capped_bandLaw _ hc]
    apply (ae_map_iff (measurable_fragmentBandMasses mesh).aemeasurable
      (measurableSet_le (tail_meas j) radial_meas)).mpr
    filter_upwards with X
    exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _) (fun _ _ _=>NNReal.zero_le_coe)
  filter_upwards [gap,nn] with z hz hm smaller
  have zero:=hz.resolve_right (not_lt_of_ge (hm.trans smaller))
  refine ⟨zero,fun u=>?_⟩
  rw [zero,sub_zero,sub_add_cancel]

#print axioms below
#print axioms regular
end PrimeGap180.FirstEdgeCDF
