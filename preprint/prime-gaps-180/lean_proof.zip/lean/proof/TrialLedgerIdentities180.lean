import TrialApplyBook180

/-! Build the residual matrices in the integer units of the physical atoms.
Only the symmetric affine matrices and the 49 resource factors are needed. -/
noncomputable section
open scoped Classical BigOperators
open PrimeGap180.Book PrimeGap180.Price
namespace PrimeGap180.LedgerData

private def point (e t : Book.Event) : ℤ := if e=t then 1 else 0
private def total (e : Book.Event) (f : Fin 12 → Book.Event) (i : Fin 12) : ℤ :=
  ∑ j ∈ Finset.Iic i, point e (f j)

def incidence (u : Resource) (e : Book.Event) : ℤ :=
  match u with
  | .prime => 24*point e .prime
  | .oldRough => 24*point e .prime + point e .oldFive
  | .allRough => 24*point e .prime + 12*total e .three 11 + point e .oldFive + total e .newFive 11
  | .primeThree i => 24*point e .prime + 12*total e .three i
  | .fullFive i => 24*(point e .oldFive + total e .newFive i)
  | .triples i => 24*total e .three i.succ
  | .extraFives i => 24*total e .newFive i.succ

def rowValue (k : Row) (e : Book.Event) : ℤ :=
  match k with
  | .prime => point e .prime
  | .sharp => point e .prime - point e .oldFive
  | .higher i => point e .prime - point e .oldFive - total e .three i - total e .newFive i

private theorem point_cast (e t : Book.Event) : (point e t:ℝ) = if e=t then 1 else 0 := by
  by_cases h : e=t <;> simp [point,h]

theorem incidence_exact (u : Resource) (e : Book.Event) :
    (incidence u e:ℝ)/24 = Resources.coefficient u e := by
  by_cases p : e=.prime <;> cases u <;>
    simp only [incidence,total,Int.cast_mul,Int.cast_add,Int.cast_sum,point_cast,
      Resources.coefficient,Resources.evaluate,p,ite_true,ite_false] <;> norm_num <;> ring

theorem row_exact (k : Row) (e : Book.Event) : (rowValue k e:ℝ) = PhysicalPrices.coefficient k e := by
  have h (t : Book.Event) : (point e t:ℝ) = if t=e then 1 else 0 := by
    by_cases same : e=t
    · simp [point,same]
    · simp [point,same,Ne.symm same]
  cases k <;> simp only [rowValue,total,Int.cast_sub,Int.cast_sum,h,PhysicalPrices.coefficient] <;> rfl

variable (F : Group → ℤ) (A : Row → Group → Group → ℤ) (r : Resource → ℕ)
  (U : ∀ u, Group → Fin (r u) → ℤ)

def residual (e : Book.Event) (g h : Group) : ℤ :=
  (if e=.prime then 24*F g*F h else 0) -
  (24*10^14)*∑ k : Row, rowValue k e*A k g h +
  ∑ u : Resource, incidence u e * intGram (U u) g h

theorem residual_symmetric (ha : ∀ k g h, A k g h = A k h g) (e : Book.Event) (g h : Group) :
    residual F A r U e g h = residual F A r U e h g := by
  have eq (u : Resource) : intGram (U u) g h = intGram (U u) h g :=
    Finset.sum_congr rfl fun k _ => mul_comm _ _
  have ag (k : Row) := ha k g h
  by_cases hit : e = .prime <;> simp only [residual,eq,ag,hit,ite_true,ite_false] <;> ring

theorem residual_exact (e : Book.Event) (g h : Group) :
    (residual F A r U e g h:ℝ)/(24*priceUnit^2) =
    PhysicalPrices.objective (fun k => (F k:ℝ)/priceUnit) e g h -
    (∑ k, PhysicalPrices.coefficient k e * ((A k g h:ℝ)/priceUnit)) +
    ∑ u, (incidence u e:ℝ)/24*((intGram (U u) g h:ℝ)/priceUnit^2) := by
  have a : (∑ k, PhysicalPrices.coefficient k e * ((A k g h:ℝ)/priceUnit)) =
      (∑ k, PhysicalPrices.coefficient k e * (A k g h:ℝ))/priceUnit := by
    rw [Finset.sum_div]; exact Finset.sum_congr rfl fun _ _ => by ring
  have c : (∑ u, (incidence u e:ℝ)/24*((intGram (U u) g h:ℝ)/priceUnit^2)) =
      (∑ u, (incidence u e:ℝ)*(intGram (U u) g h:ℝ))/(24*priceUnit^2) := by
    rw [Finset.sum_div]; exact Finset.sum_congr rfl fun _ _ => by ring
  rw [a,c]
  simp only [residual,Int.cast_add,Int.cast_sub,Int.cast_sum,Int.cast_mul,Int.cast_pow,
    Int.cast_ofNat,row_exact,PhysicalPrices.objective]
  by_cases he : e=.prime <;> simp only [he,ite_true,ite_false,Int.cast_zero,Int.cast_mul,Int.cast_ofNat]
  all_goals norm_num [priceUnit] <;> ring

end PrimeGap180.LedgerData
