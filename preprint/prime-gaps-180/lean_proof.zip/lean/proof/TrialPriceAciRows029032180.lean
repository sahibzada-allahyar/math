import TrialPriceIsolatedChecks180
import TrialPriceGroupElab180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G029
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifySignedPriceGroup 29

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G029

namespace PrimeGap180.PriceIsolatedGroup.G030
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifySignedPriceGroup 30

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G030

namespace PrimeGap180.PriceIsolatedGroup.G031
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifySignedPriceGroup 31

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G031

namespace PrimeGap180.PriceIsolatedGroup.G032
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifySignedPriceGroup 32

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G032
