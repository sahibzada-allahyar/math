import TrialHighAngularProduct180

/-! The ten endpoint and interior owner cases of the original angular Gram.
The relabellings fix both actual endpoints and preserve every angular power sum. -/
noncomputable section
open scoped Classical BigOperators
namespace PrimeGap180.HighOwnerRoles
open HighAngularProduct FullNativeTicks FrozenChannels

abbrev Site := Fin 39
abbrev Role := Fin 10
abbrev Owners := Site × Site
def role (q : Owners) : Role :=
  if q.1=0 then (if q.2=0 then 7 else if q.2=38 then 0 else 2)
  else if q.1=38 then (if q.2=0 then 1 else if q.2=38 then 8 else 4)
  else if q.2=0 then 3 else if q.2=38 then 5 else if q.1=q.2 then 9 else 6

def representative : Role → Owners := ![(0,38),(38,0),(0,1),(1,0),(38,1),(1,38),(1,2),(0,0),(38,38),(1,1)]
def multiplicity : Role → ℕ := ![1,1,37,37,37,37,1332,1,1,37]
def move (q : Owners) : Equiv.Perm Site :=
  let v := representative (role q)
  let s := Equiv.swap q.1 v.1
  s.trans (Equiv.swap (s q.2) v.2)

set_option maxRecDepth 20000 in
set_option maxHeartbeats 0 in
private theorem census : (∀ q : Owners, move q q.1 = (representative (role q)).1 ∧
    move q q.2 = (representative (role q)).2 ∧ move q 0 = 0 ∧ move q 38 = 38) ∧
    ∀ s : Role, (Finset.univ.filter fun q : Owners => role q = s).card = multiplicity s := by decide +kernel

private theorem inner (π : Equiv.Perm Site) (e0 : π 0=0) (e1 : π (Fin.last 38)=Fin.last 38)
    (f : Site → ℝ) : (∑ i : Fin 37,f (π i.castSucc.succ)) = ∑ i : Fin 37,f i.castSucc.succ := by
  have ends (g : Site → ℝ) : (∑ i,g i) = g 0 + (∑ i : Fin 37,g i.castSucc.succ) + g (Fin.last 38) := by
    rw [Fin.sum_univ_succ,Fin.sum_univ_castSucc]
    rw [add_assoc]
    rfl
  have sum := Equiv.sum_comp π f
  rw [ends (fun i => f (π i)),ends f,e0,e1] at sum
  linarith only [sum]

private theorem angular_perm (π : Equiv.Perm Site) (e0 : π 0=0) (e1 : π (Fin.last 38)=Fin.last 38)
    (u : Key) (j : Site → ℕ) : angular u (j ∘ π) = angular u j := by
  unfold angular
  simp only [Function.comp_apply,e0,e1]
  have h (k : ℕ) := inner π e0 e1 (fun i => center (j i)^k)
  simp_rw [h]

private def permute (π : Equiv.Perm Site) : Cube ≃ Cube where
  toFun t := t ∘ π
  invFun t := t ∘ π.symm
  left_inv t := by funext i; simp
  right_inv t := by funext i; simp

private theorem reindex (π : Equiv.Perm Site) (e0 : π 0=0) (e1 : π (Fin.last 38)=Fin.last 38)
    (W : Site → Index → ℝ) (u v : Key) : cube (W ∘ π) u v = cube W u v := by
  unfold cube
  rw [←Equiv.sum_comp (permute π)]
  apply Finset.sum_congr rfl
  intro x _
  change (∏ i,W (π i) (x (π i)))*angular u ((fun i => (x i).val) ∘ π)*
    angular v ((fun i => (x i).val) ∘ π) = _
  rw [angular_perm π e0 e1,angular_perm π e0 e1,Equiv.prod_comp π (fun i => W i (x i))]

/-- D, A, B and C are respectively the ordinary, first-mark, second-mark
and two-mark site laws. C retains both mark bands on a common owner. -/
def site (D A B C : Index → ℝ) (q : Owners) (i : Site) :=
  if i=q.1 then (if i=q.2 then C else A) else if i=q.2 then B else D

private theorem swap_law (D A B C : Index → ℝ) (q : Owners) :
    site D A B C q = site D A B C (representative (role q)) ∘ move q := by
  funext i
  have h := census.1 q
  simp only [Function.comp_apply,site,←h.1,←h.2.1,Equiv.apply_eq_iff_eq]

theorem representative_cube (D A B C : Index → ℝ) (q : Owners) (u v : Key) :
    cube (site D A B C q) u v = cube (site D A B C (representative (role q))) u v := by
  have h := census.1 q
  rw [swap_law]
  exact reindex _ h.2.2.1 h.2.2.2 _ u v

theorem total (D A B C : Index → ℝ) (u v : Key) :
    (∑ q : Owners, cube (site D A B C q) u v) =
      ∑ t : Role,(multiplicity t:ℝ)*cube (site D A B C (representative t)) u v := by
  let F := fun t => cube (site D A B C (representative t)) u v
  calc
    _ = ∑ q : Owners,F (role q) := Finset.sum_congr rfl fun q _ => representative_cube D A B C q u v
    _ = ∑ t : Role, ∑ q ∈ Finset.univ.filter (fun q : Owners => role q=t),F t := by
      simp only [Finset.sum_filter]
      rw [Finset.sum_comm]
      simp
    _ = _ := by simp only [Finset.sum_const,census.2,nsmul_eq_mul,F]

#print axioms representative_cube
#print axioms total
end PrimeGap180.HighOwnerRoles
