import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G304
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 304

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G304

namespace PrimeGap180.PriceIsolatedGroup.G309
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 309

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G309

namespace PrimeGap180.PriceIsolatedGroup.G314
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 314

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G314

namespace PrimeGap180.PriceIsolatedGroup.G319
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 319

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G319
