"""Generate exact packed one-site-square witnesses for one historical cap (default 36).

For cap 36 the output is the compiled bank's `TrialCapSquareNumbers180`,
`TrialCapAlignedBlock*180` and `TrialCapAlignedGrid180`. For another changing
cap `c` the same modules are named `TrialCap{cc}…180`, read their words with
`capWord180%`, and an extra module `TrialCap{cc}Unmarked180` instantiates
`CapBank.source/one/two/ordinaryEnd/ordinaryPair` (the cap-36 versions are the
hand-written `TrialCapActualSquare180`, `TrialCapUnmarked180` and
`TrialEndPairRules180`).
"""
import argparse
from pathlib import Path
import re

from build_historical_site_rows import columns
from cap_bank_names import Names, cap_argument
from check_exact_endpoint_pair import site
from endpoint_pair_arithmetic import COUNT, encode, multiply

HERE = Path(__file__).resolve().parent
NUMBERS = "TrialCapSquareNumbers180"
ALIGNMENT = "TrialCapAlignedGrid180"
WORD_NAMES = ("column", "site-low", "site-high", "square-low", "square-high")
READER = re.compile(r"open Lean Elab Term CapWordConvolution\n.*?return mkNatLit \(readNat bytes 0 bytes\.size\)\n",
                    re.S)


def input_tree():
    lines = []
    for k in range(2, 128):
        side = "left" if k % 2 == 0 else "right"
        lines.append(f"private def node{k} := {side} node{k//2}")
    lines.extend(f"private theorem yes{k} : fits 11 node{k}=true := by decide +kernel"
                 for k in range(64, 128))
    for k in range(63, 0, -1):
        fuel = 17-(k.bit_length()-1)
        lines.append(f"private theorem yes{k} : fits {fuel} node{k}=true := assemble node{k}"
                     f" (by decide) yes{k*2} yes{k*2+1}")
    return "\n".join(lines)


def numbers_text(names):
    text = (HERE / (NUMBERS + ".lean.in")).read_text()
    if not names.legacy:
        # The reader lives in TrialCapWordReader180, so the banks of several caps can be imported together.
        text, count = READER.subn("open CapWordConvolution\n", text)
        if count != 1:
            raise ValueError("Unexpected reader block in the square-number template")
        text = text.replace("import TrialCapWordConvolution180\n",
                            "import TrialCapWordConvolution180\nimport TrialCapWordReader180\n", 1)
        text = names.retarget(text)
    return text.replace("__INPUT_TREE__", input_tree())


def unmarked_text(names):
    """`CapSquare.original`, `CapUnmarked.one/two/maskOne/maskTwo` and the two `EndPairRules` facts."""
    c, sq, um, er = names.cap, names.ns("Square"), names.ns("Unmarked"), names.ns("EndPairRules")
    return "\n".join([
        "import TrialCapBankRules180", f"import {names.module('AlignedGrid')}", "",
        f"/-! Physical meaning of the cap-{c} column, its one-site words and their square. -/",
        f"namespace PrimeGap180.{sq}",
        f"theorem original : CapBank.Source {c} column := CapBank.source {c} column {names.ns('AlignedGrid')}.exact_column",
        "#print axioms original", f"end PrimeGap180.{sq}", "",
        f"namespace PrimeGap180.{um}", "open CapWordConvolution", "set_option maxRecDepth 32000",
        f"theorem one : CapBank.keptPow {c} 1 {sq}.lo {sq}.hi := CapBank.one {c} {sq}.original {sq}.inputs",
        f"theorem two : CapBank.keptPow {c} 2 {sq}.resultLo {sq}.resultHi :=",
        f"  CapBank.two {c} {sq}.original {sq}.inputs {sq}.masks {sq}.square",
        "set_option maxHeartbeats 0 in", "set_option exponentiation.threshold 100000000 in",
        f"theorem maskOne : mask 640 296 130965 {sq}.lo=true ∧ mask 640 296 130965 {sq}.hi=true := by decide +kernel",
        "set_option maxHeartbeats 0 in", "set_option exponentiation.threshold 100000000 in",
        f"theorem maskTwo : mask 640 296 130965 {sq}.resultLo=true ∧ mask 640 296 130965 {sq}.resultHi=true := "
        "by decide +kernel",
        "#print axioms two", f"end PrimeGap180.{um}", "",
        f"namespace PrimeGap180.{er}", "open MassRawProduct",
        f"theorem ordinary : Bounds (CapBank.endPairPoly {c} 0 0) {sq}.lo {sq}.hi := CapBank.ordinaryEnd {c} {um}.one",
        f"theorem ordinary_pair : Bounds (CapBank.endPairPoly {c} 0 0*CapBank.endPairPoly {c} 0 0) "
        f"{sq}.resultLo {sq}.resultHi :=",
        f"  CapBank.ordinaryPair {c} {um}.two",
        "#print axioms ordinary_pair", f"end PrimeGap180.{er}", ""])


def block_text(names, group, column_bytes):
    ids = range(group*84, (group+1)*84)
    part = "Part" if names.legacy else f"CapBank.Part {names.cap}"
    lines = ["import TrialAlignedColumnParts180" if names.legacy else "import TrialCapBankRules180",
             *(f"import TrialSiteShard{i:03d}180" for i in ids), "",
             f"namespace PrimeGap180.{names.ns('AlignedGrid')}", "open AlignedColumnAudit PackedSiteAudit",
             "set_option maxHeartbeats 0", "set_option maxRecDepth 12000"]
    for i in ids:
        start = 45067+128*i
        word = (int.from_bytes(column_bytes[8*start:8*(start+128)], "little")
                if column_bytes is not None else 0)
        lines.append(f"def part{i:03d} : {part} := ⟨shard{i:03d},{hex(word)},by decide +kernel⟩")
    lines.extend([f"#print axioms part{ids[-1]:03d}", f"end PrimeGap180.{names.ns('AlignedGrid')}"])
    return "\n".join(lines)+"\n"


def alignment_text(names, block_names):
    template = (HERE / (ALIGNMENT + ".lean.in")).read_text()
    if not names.legacy:
        c = names.cap
        for old, new in [
            ("def parts : Array Part := #[", f"def parts : Array (CapBank.Part {c}) := #["),
            ("theorem thisGrid : parts.map Part.chunk=gridChunks", "theorem thisGrid : parts.map CapBank.Part.chunk=gridChunks"),
            ("all fun k => wordAt parts", "all fun k => CapBank.wordAt parts"),
            ("numerator57 (gridRow j) 36 := by", f"numerator57 (gridRow j) {c} := by"),
            ("  apply alignment gridChunks _ gridSchema early _ j hj",
             f"  apply CapBank.alignment {c} (by decide) gridChunks _ gridSchema early _ j hj"),
            ("  apply block_of_wordAt\n", "  apply CapBank.block_of_wordAt\n"),
        ]:
            if template.count(old) != 1:
                raise ValueError(f"Missing unique alignment text {old!r}")
            template = template.replace(old, new)
        template = names.retarget(template)
    for key, replacement in [
        ("__BLOCK_IMPORTS__", "\n".join("import "+name for name in block_names)),
        ("__PARTS__", ",\n".join(f"  part{i:03d}" for i in range(672))),
        ("__INTERVAL_PROOFS__", "\n".join(
            f"private theorem interval{i} : interval {i}=true := by decide +kernel" for i in range(42))),
        ("__INTERVAL_CASES__", "\n".join(f"  · exact interval{i}" for i in range(42))),
    ]:
        if template.count(key) != 1:
            raise ValueError(f"Missing unique placeholder {key} in {ALIGNMENT}")
        template = template.replace(key, replacement)
    return template


def generate(destination, cap=36, dry_run=False):
    """Write the square words and modules; `dry_run` writes the Lean text only."""
    names = Names(cap)
    destination.mkdir(parents=True, exist_ok=True)
    column_bytes = None
    if not dry_run:
        column = columns()[cap][:COUNT]
        one_site = site(column)
        square = multiply(one_site, one_site)
        column_bytes = encode(column, 8)
        words = (column_bytes, encode(one_site.low, 80), encode(one_site.high, 80),
                 encode(square.low, 80), encode(square.high, 80))
        for label, value in zip(WORD_NAMES, words, strict=True):
            (destination / (label + ".bin")).write_bytes(value)
    numbers_name = names.module("SquareNumbers")
    numbers = destination / (numbers_name + ".lean")
    numbers.write_text(numbers_text(names))
    sources = {numbers_name: numbers}
    blocks = []
    for group in range(8):
        name = names.module(f"AlignedBlock{group:02d}")
        file = destination / (name+".lean")
        file.write_text(block_text(names, group, column_bytes))
        sources[name] = file
        blocks.append(name)
    alignment_name = names.module("AlignedGrid")
    assembly = destination / (alignment_name+".lean")
    assembly.write_text(alignment_text(names, blocks))
    sources[alignment_name] = assembly
    if not names.legacy:
        name = names.unmarked_module
        path = destination / (name+".lean")
        path.write_text(unmarked_text(names))
        sources[name] = path
    return sources


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    cap_argument(p)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--dry-run", action="store_true", help="write Lean text without words")
    a = p.parse_args()
    for n in generate(a.output_dir, a.cap, a.dry_run):
        print(n)
