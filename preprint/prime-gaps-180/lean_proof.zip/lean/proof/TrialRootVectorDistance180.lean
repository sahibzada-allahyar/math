import TrialUncutDrift180
import Mathlib.Analysis.InnerProductSpace.PiL2

/-! Turning pointwise product-law likelihood bounds into the actual unit-vector distance. -/
noncomputable section
open scoped Classical BigOperators
namespace PrimeGap180.RootVectorDistance

def lo : ℝ := 0.9999999996734
def hi : ℝ := 1.000003698086
private def mid := (lo+hi)/2
private def rad := (hi-lo)/2
private theorem ln : 0 ≤ lo := by norm_num [lo]
private theorem rn : 0 ≤ rad := by norm_num [rad,hi,lo]

variable {X : Type*} [Fintype X]
abbrev E (Y : Type*) [Fintype Y] := EuclideanSpace ℝ Y

theorem unit_distance (v z : E X) (vpos : 0 < ‖v‖) (zpos : 0 < ‖z‖)
    (scale : ∀ i,∃ r : ℝ,lo ≤ r ∧ r ≤ hi ∧ z i = r*v i) :
    ‖‖z‖⁻¹ • z - ‖v‖⁻¹ • v‖ ≤ UncutDrift.δ := by
  have low : lo*‖v‖ ≤ ‖z‖ := by
    apply (sq_le_sq₀ (mul_nonneg ln vpos.le) zpos.le).mp
    rw [mul_pow,EuclideanSpace.real_norm_sq_eq,EuclideanSpace.real_norm_sq_eq,Finset.mul_sum]
    apply Finset.sum_le_sum
    intro i _
    obtain ⟨r,lb,_,e⟩ := scale i
    rw [e,mul_pow]
    exact mul_le_mul_of_nonneg_right (pow_le_pow_left₀ ln lb 2) (sq_nonneg _)
  have close : ‖z-mid • v‖ ≤ rad*‖v‖ := by
    apply (sq_le_sq₀ (norm_nonneg _) (mul_nonneg rn vpos.le)).mp
    rw [mul_pow,EuclideanSpace.real_norm_sq_eq,EuclideanSpace.real_norm_sq_eq,Finset.mul_sum]
    apply Finset.sum_le_sum
    intro i _
    obtain ⟨r,lb,ub,eq⟩ := scale i
    change (z i-mid*v i)^2 ≤ rad^2*(v i)^2
    rw [eq,←sub_mul,mul_pow]
    have ab : |r-mid| ≤ rad := abs_le.mpr (by unfold mid rad; constructor <;> linarith)
    have ps := pow_le_pow_left₀ (abs_nonneg _) ab 2
    rw [sq_abs] at ps
    exact mul_le_mul_of_nonneg_right ps (sq_nonneg _)
  have unit (w : E X) (hw : 0 < ‖w‖) : ‖‖w‖⁻¹ • w‖ = 1 := by
    rw [norm_smul,Real.norm_eq_abs,abs_inv,abs_of_nonneg hw.le,inv_mul_cancel₀ hw.ne']
  let A := ‖z‖/‖v‖
  apply UncutDrift.normalized_distance _ _ A (unit v vpos) (unit z zpos)
    ((le_div_iff₀ vpos).mpr low)
  change ‖A • (‖z‖⁻¹ • z) - mid • (‖v‖⁻¹ • v)‖ ≤ rad
  have eq : A • (‖z‖⁻¹ • z)-mid • (‖v‖⁻¹ • v) = ‖v‖⁻¹ • (z-mid • v) := by
    simp only [smul_smul,smul_sub]
    rw [show A*‖z‖⁻¹ = ‖v‖⁻¹ from by dsimp [A]; field_simp, mul_comm mid]
  rw [eq,norm_smul,Real.norm_eq_abs,abs_inv,abs_of_nonneg vpos.le]
  calc
    _ ≤ ‖v‖⁻¹*(rad*‖v‖) := mul_le_mul_of_nonneg_left close (inv_nonneg.mpr vpos.le)
    _ = rad := by field_simp

#print axioms unit_distance
end PrimeGap180.RootVectorDistance
