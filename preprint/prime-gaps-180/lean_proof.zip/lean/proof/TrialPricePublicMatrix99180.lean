import TrialPriceSlotReflect180

namespace PrimeGap180.PriceBindings.M99
open PrimeGap180.PriceProjection PrimeGap180.PriceWordText
set_option maxRecDepth 24000000
set_option maxHeartbeats 400000000

declareSlotParts 99

theorem selected_public : PackedLedger.raw.matrices[113]! = (rank,whole) := by rfl
theorem selected_rows : PriceFactorSource.factorShapes[99]! = (rank,numerals.toArray) := by rfl
theorem group_count : numerals.length=445 := by decide +kernel

proveWholeText 99
proveSlotRows 99 0 445
collectSlotRows 99

theorem bound : PackedLedger.raw.matrices[113]! = PriceFactorSource.physical (PriceFactorSource.factorShapes[99]!) :=
  slot group_count selected_rows (selected_public.trans (congrArg (fun s : String => (rank,s)) whole_text)) all_rows

#print axioms bound
end PrimeGap180.PriceBindings.M99
