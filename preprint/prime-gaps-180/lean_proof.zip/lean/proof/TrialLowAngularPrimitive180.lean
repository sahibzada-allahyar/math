import Init

/-! Integer arithmetic on the endpoint and occupied-core moments of the 39-site angular square. -/
namespace PrimeGap180.LowAngularPrimitive
def get (v : Array Nat) (i : Nat) := (v[i]?).getD 0
def sumN (f : Nat→Nat) : Nat→Nat
  | 0=>0
  | n+1=>sumN f n+f n
def prodN (f : Nat→Nat) : Nat→Nat
  | 0=>1
  | n+1=>prodN f n*f n

def update (v : Nat→Nat) (j e i : Nat) := v i+(if i=j then e else 0)
def occupied (U V : Array Nat) (marked : Bool) : List Nat→(Nat→Nat)→Nat→Nat
  | [],v,k=>prodN (fun i=>get (if marked && i==0 then U else V) (v i)) k*(get V 0)^(7-k)
  | e::es,v,k=>sumN (fun i=>occupied U V marked es (update v i e) k) k+
    (37-k)*occupied U V marked es (update v k e) (k+1)

def signatures : Array (List Nat) := #[[],[2],[3],[4],[2,2],[5],[2,3],[6],[2,4],[3,3],[2,2,2]]
def signature (i j : Nat) := (signatures[i]?).getD [] ++ (signatures[j]?).getD []

def endSum (W X Y : Array Nat) (s u : Nat) :=
  let w00:=get W (4*s+0)
  let w01:=get W (4*s+1)
  let w10:=get W (4*s+2)
  let w11:=get W (4*s+3)
  let t00:=get W (4*u+0)
  let t01:=get W (4*u+1)
  let t10:=get W (4*u+2)
  let t11:=get W (4*u+3)
  w00*t00*get X 0*get Y 0 +
  w00*t01*get X 0*get Y 2 +
  w00*t10*get X 2*get Y 0 +
  w00*t11*get X 2*get Y 2 +
  w01*t00*get X 0*get Y 2 +
  w01*t01*get X 0*get Y 4 +
  w01*t10*get X 2*get Y 2 +
  w01*t11*get X 2*get Y 4 +
  w10*t00*get X 2*get Y 0 +
  w10*t01*get X 2*get Y 2 +
  w10*t10*get X 4*get Y 0 +
  w10*t11*get X 4*get Y 2 +
  w11*t00*get X 2*get Y 2 +
  w11*t01*get X 2*get Y 4 +
  w11*t10*get X 4*get Y 2 +
  w11*t11*get X 4*get Y 4

def contribution (W U V : Array Nat) (s u : Nat) :=
  let es:=signature s u
  let hom:=occupied U V false es (fun _=>0) 0
  let interior:=occupied U V true es (fun _=>0) 1
  (endSum W U V s u+endSum W V U s u)*hom+37*endSum W V V s u*interior

def full (W U V : Array Nat) :=
  let reduced:=sumN (fun s=>sumN (fun u=>contribution W U V s u) 11) 11
  (get V 0)^30*reduced

end PrimeGap180.LowAngularPrimitive
