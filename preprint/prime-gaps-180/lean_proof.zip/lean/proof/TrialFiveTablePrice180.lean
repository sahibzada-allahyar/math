import TrialFiveTableCover180
import TrialMarkUpperMass180
import TrialSharpSequence180

/-! The 72-bin five-prime table as an upper bound for a signed physical
square. The per-bin auxiliary radius is the one in the price checker. -/
noncomputable section
open scoped Classical BigOperators Topology
open Filter MeasureTheory PrimeGap186 PrimeGap182Analytic
open PrimeGap180.EventBins PrimeGap180.Literal
namespace PrimeGap180.ClippedPair

theorem table_upper {m : ℕ} {J : Type*} [Fintype J] (H : Finset ℕ) (hH : H.card = 39)
    (k : Fin 39) (smallShift : H.orderEmbOfFin hH k ≤ 182)
    (a old : ℝ) (lo : 0 < lower a) (lo1 : lower a ≤ 1) (ha0 : 0 ≤ a) (ha1 : a ≤ 1)
    (hw : pad < width a) (incremental : Bool) (cut : incremental = true → 2*lower a+104*width a ≤ old)
    (c : Bin → ℝ) (nn : ∀ t, 0 ≤ c t) (table : TableCover incremental c)
    (bands : Fin (m+2) → ℝ) (inc : StrictMono bands) (first : bands 0 = 0)
    (last : bands (Fin.last (m+1)) = Sector.cap)
    (P : J → (Fin 38 → Sector.Band m) → Prop) (F : J → Sector.Profile 39 m)
    (sep : ∀ j z, j ≠ z → ∀ y, P j y → ¬ P z y) (bf : ∀ j, Bornology.IsBounded (Set.range (F j)))
    (mf : ∀ j, Measurable (Sector.restrictFace k (P j) (F j)))
    (cf : ∀ j, ∀ᵐ y ∂Measure.pi (fun _ => Sector.bandLaw bands), ContinuousAt (Sector.restrictFace k (P j) (F j)) y)
    (r : J → ℝ) (hr : ∀ j, 0 ≤ r j) (rad : ∀ j y, P j y → Sector.rho*∑ t, ∑ u, y t u ≤ r j)
    {d : ℝ} (hd : 0 < d) (roughGap : d < lower a) (capGap : Sector.physicalCap < lower a)
    (room : ∀ t j, d < (1-markExponent a t)/2-r j) (b : ℝ → ℕ) {ε : ℝ} (he : 0 < ε) :
    let h : Fin 39 → ℕ := H.orderEmbOfFin hH
    let Z := fun j => Sector.restrictFace k (P j) (F j)
    let V := fun j x n => sampledSelbergRoot (Sector.face H bands k (Z j) x) (fun q => n+h (k.succAbove q))
    let E := fun j => ∫ t, (Sector.integralFace bands k (Z j) t)^2 ∂Measure.pi (fun _ => Sector.bandLaw bands)
    let ζ := fun t j => min (lower a) ((1-markExponent a t)/2-r j)-d
    ∀ᶠ x : ℝ in atTop, (∑ n ∈ Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊, if Nat.ModEq (presievingModulus H x) n (b x)
      then (if Five (x^a) (n+h k) ∧ (incremental = true → ¬ Five (x^old) (n+h k)) then 24 else 0)*
        (∑ j, V j x n)^2 else 0)/Sector.markedScale H x ≤
      (∑ t : Bin, ∑ j, (c t*price a t.1 t.2)*(1/ζ t j)*E j)+ε := by
  classical
  intro h Z V E ζ
  let ξ := lower a
  let κ := max Sector.physicalCap (ξ-d)/Sector.rho
  have hp : 0 < width a := (show 0 < pad by norm_num).trans hw
  have source (t : Bin) (j : J) := Marked.price_radius hd roughGap (room t j) capGap
  have carrier : Sector.cap ≤ κ := div_le_div_of_nonneg_right (le_max_left _ _) (by norm_num [Sector.rho])
  have below : Sector.rho*κ < ξ := by
    dsimp [κ]
    rw [mul_comm,div_mul_cancel₀ _ (show Sector.rho ≠ 0 by norm_num [Sector.rho])]
    exact max_lt capGap (by linarith)
  choose K hK eligible using fun t : Bin => bin_eligible H ha1 lo lo1 hp below (half_pos hd) c nn t
  have edgePos (j : Fin 72) : 0 ≤ edge a j := add_nonneg lo.le (mul_nonneg (Nat.cast_nonneg _) hp.le)
  let ev := fun (x : ℝ) n => if Five (x^a) n ∧ (incremental = true → ¬ Five (x^old) n) then (24:ℝ) else 0
  apply Sector.marked_cover_upper_of_mass_price H hH k bands inc first last P F sep bf mf cf r ζ
    (fun _ => κ) (fun t => markExponent a t+d/2) (fun _ => d/2) K (fun t => c t*price a t.1 t.2) ξ hr
    (fun t j => ⟨(source t j).1,(source t j).2.1⟩) (fun _ => carrier) (fun t j => (source t j).2.2.2.1)
    (fun t => add_nonneg (le_min ha0 (add_nonneg (add_nonneg (edgePos _) (edgePos _)) (by positivity))) (half_pos hd).le)
    (fun _ => half_pos hd) (fun t => mul_nonneg (nn _) (price_nonneg lo hp t.1 t.2))
    (fun t j => by linarith only [(source t j).2.2.2.2.2,hd]) rad
    (fun t x => marks x a t.1 t.2) (fun t _ _ => c t) b ev eligible
    (fun t => .of_forall fun x => one_not_mem x a t) (fun t δ pos => weighted_bin_mass lo hp c nn t pos) _ _ he
  · filter_upwards [shifted_window_size,eventually_gt_atTop (1:ℝ)] with x size hx
    intro n hn N
    have win := Finset.mem_Icc.mp hn
    have bounds := size n (h k) ((Nat.le_ceil x).trans (Nat.cast_le.mpr win.1))
      ((Nat.cast_le.mpr win.2).trans (Nat.floor_le (by linarith))) smallShift
    by_cases event : Five (x^a) N ∧ (incremental=true → ¬ Five (x^old) N)
    · simpa only [ev,ite_eq_left event] using table_cover_on_five hx bounds.1 bounds.2 hw incremental cut event.1 event.2 c nn table
    · simp only [ev,ite_eq_right event]
      exact Finset.sum_nonneg (fun t _ => Finset.sum_nonneg (fun l _ => ite_nonneg (nn t) le_rfl))
  · filter_upwards [eventually_gt_atTop (1:ℝ)] with x hx
    intro n hn N hit p pr dvd
    have event : Five (x^a) N := by
      by_contra no
      simp [ev,no] at hit
    have left := Finset.mem_Icc.mp hn
    have nlo : x ≤ (N:ℝ) := ((Nat.le_ceil x).trans (Nat.cast_le.mpr left.1)).trans
      (Nat.cast_le.mpr (Nat.le_add_right ..))
    exact (sharpExceptional_prime_factor_lower x a hx N nlo ((five_iff_sharp x a N).mp event) p pr dvd).le

#print axioms table_upper
end PrimeGap180.ClippedPair
