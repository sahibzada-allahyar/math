import TrialSignedEnvelopeReceiver180
import TrialSignedEnvelopeDirected180

/-! The signed spline envelope and its nine exact physical low-edge payments. -/
noncomputable section
open MeasureTheory
namespace PrimeGap180.EnvelopeClosed
open LaterLowFixed LaterLowProduct
theorem envelope : LaterLowFixed.Envelope :=
  EnvelopePhysical.physical EnvelopeDirectedChecks.all

theorem nine : (∫ v in ⋃ i, event i, (Restoration.original v)^2 ∂μ) ≤
    (110400638236 / 10^18 : ℝ) * (94.17312 / (100:ℝ)^39) := by
  simpa only [total_eq, Rat.cast_div, Rat.cast_ofNat, Rat.cast_pow] using union_payment envelope

#print axioms envelope
#print axioms nine
end PrimeGap180.EnvelopeClosed
