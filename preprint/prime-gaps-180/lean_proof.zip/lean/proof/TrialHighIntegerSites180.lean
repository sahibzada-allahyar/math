import TrialHighClosedSiteMoments180

/-! Apply a common integer scale to the site enclosure. Lower endpoints may
be clamped at zero when the site moment has a nonnegative physical density. -/
namespace PrimeGap180.HighIntegerSites
open HighMomentReader

def scale : ℚ := 2^224
def lower (b : Interval) : ℤ := max 0 ⌊scale * b.lo⌋
def upper (b : Interval) : ℤ := ⌈scale * b.hi⌉

theorem round (b : Interval) (x : ℝ) (hx : encloses b x) (pos : 0 ≤ x) :
    0 ≤ lower b ∧ (lower b:ℝ) ≤ (2:ℝ)^224*x ∧ (2:ℝ)^224*x ≤ (upper b:ℝ) := by
  have h : (0:ℝ) ≤ (2:ℝ)^224 := by positivity
  have scl : (scale:ℝ)=2^224 := by norm_num [scale]
  have left : ((⌊scale*b.lo⌋:ℤ):ℝ) ≤ (2:ℝ)^224*(b.lo:ℝ) := by
    rw [←scl,←Rat.cast_mul]
    exact_mod_cast Int.floor_le (scale*b.lo)
  have right : (2:ℝ)^224*(b.hi:ℝ) ≤ ((⌈scale*b.hi⌉:ℤ):ℝ) := by
    rw [←scl,←Rat.cast_mul]
    exact_mod_cast Int.le_ceil (scale*b.hi)
  refine ⟨le_max_left _ _,?_,(mul_le_mul_of_nonneg_left hx.2 h).trans right⟩
  rw [lower,Int.cast_max,Int.cast_zero,max_le_iff]
  exact ⟨mul_nonneg h pos,left.trans (mul_le_mul_of_nonneg_left hx.1 h)⟩

#print axioms round
end PrimeGap180.HighIntegerSites
