import TrialPriceReflectedRows180
import TrialPackedLedger180
import Lean

namespace PrimeGap180.PriceProjection
open Lean Elab Command

private def body (n : Name) : CommandElabM Expr := do
  let some (.defnInfo ci) := (← getEnv).find? n | throwError "missing definition {n}"
  return ci.value

private def selected (xs : Expr) (i : Nat) : CommandElabM Expr := do
  unless xs.isAppOfArity ``List.toArray 2 do throwError "expected a literal array, found {xs.getAppFn.constName?}"
  let mut a := xs.appArg!
  for _ in [:i] do
    unless a.isAppOfArity ``List.cons 3 do throwError "literal array index outside its range"
    a := a.appArg!
  unless a.isAppOfArity ``List.cons 3 do throwError "literal array index outside its range"
  return a.appFn!.appArg!

private def literalNat (e : Expr) : CommandElabM Nat := do
  let some v ← liftTermElabM (Meta.getNatValue? e) | throwError "expected a natural literal"
  return v

/-- Read the already elaborated literal payloads of the two ledger representations.
These values only generate candidates. The declarations consuming them have ordinary kernel proofs. -/
def getParts (m : Nat) : CommandElabM (Nat × String × Array Nat) := do
  let raw ← body ``PackedLedger.raw
  unless raw.isAppOfArity ``PackedLedger.Raw.mk 6 do throwError "unexpected public ledger constructor"
  let item ← selected raw.getAppArgs[0]! (14+m)
  let shape ← selected (← body ``PriceFactorSource.factorShapes) m
  unless item.isAppOfArity ``Prod.mk 4 && shape.isAppOfArity ``Prod.mk 4 do throwError "unexpected factor pair"
  let rank ← literalNat item.getAppArgs[2]!
  unless (← literalNat shape.getAppArgs[2]!) == rank do throwError "rank mismatch"
  let .lit (.strVal s) := item.appArg! | throwError "expected a primitive text literal"
  let arr := shape.appArg!
  unless arr.isAppOfArity ``List.toArray 2 do throwError "expected physical row array"
  let mut xs := arr.appArg!
  let mut ns := #[]
  while xs.isAppOfArity ``List.cons 3 do
    ns := ns.push (← literalNat xs.appFn!.appArg!)
    xs := xs.appArg!
  unless ns.size == 445 && s.utf8ByteSize == 16*445*rank do throwError "unexpected physical dimensions"
  return (rank,s,ns)

elab "describeSlot" m:num : command => do
  let (rank,s,nums) ← getParts m.getNat
  logInfo m!"selected {rank} columns, {s.utf8ByteSize} hexadecimal characters, {nums.size} physical rows"

describeSlot 45
end PrimeGap180.PriceProjection
