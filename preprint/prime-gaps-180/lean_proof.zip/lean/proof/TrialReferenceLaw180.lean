import TrialFrozenCapIndices180
import TrialDebitCapMap180
import Mathlib.Algebra.BigOperators.Fin

/-! Exact rational model of the 37 binary64 trapezoidal CDFs. The interval
and nesting guards define a probability submeasure for arbitrary evaluations.
The bit replay checks every guard against every archived cell. -/
open scoped BigOperators
namespace PrimeGap180.ReferenceLaw
open PrimeGap180.DebitNativeClasses

def tiesEven (n d : ℕ) : ℕ :=
  let q := n/d
  let r := n%d
  if 2*r<d then q else if d<2*r then q+1 else q+q%2

/-- Round a finite magnitude from the frozen recurrence to its binary64 quantum, using even ties. -/
def magnitude (n d : ℕ) : ℚ :=
  let guess : ℤ := (n.log2:ℤ) - (d.log2:ℤ)
  let magnitudeLarge := if 0 ≤ guess then d*2^guess.toNat ≤ n else d ≤ n*2^(-guess).toNat
  let e := if magnitudeLarge then guess else guess-1
  let s := max (-1074:ℤ) (e-52)
  if s ≤ 0 then
    let unit := 2^(-s).toNat
    (tiesEven (n*unit) d : ℚ)/unit
  else
    let unit := 2^s.toNat
    (tiesEven n (d*unit):ℚ)*unit

def binary64 (q : ℚ) : ℚ :=
  if q=0 then 0 else if 0<q then magnitude q.num.natAbs q.den else -(magnitude q.num.natAbs q.den)

/-- Array entry j is the dyadic nodal value at j; nodes k n ends at index n. -/
def nodes (k n : ℕ) : Array ℚ := Id.run do
  let mut a : Array ℚ := #[1]
  for j in [:n] do
    let atIndex (k : ℕ) := a[k]?.getD 1
    let next := if j<k then 1 else
      let left := binary64 (atIndex (j-k)/j)
      let right := binary64 (atIndex (j+1-k)/(j+1))
      let change := binary64 ((binary64 (left+right))/2)
      binary64 (atIndex j-change)
    a := a.push next
  return a

def cap (c : DebitNativeClasses.Class) := FrozenCaps.index (capAt c)
def sample (a : Array ℚ) (j : ℕ) : ℚ :=
  max 0 (binary64 ((binary64 (a[j]?.getD 1+a[j+1]?.getD 1))/2))

def rawCDF (c : DebitNativeClasses.Class) (j : ℕ) := if j < cap c then 1 else sample (nodes (cap c) 131034) j

attribute [local irreducible] magnitude binary64 nodes sample rawCDF

theorem first_le : ∀ c : DebitNativeClasses.Class,45067 ≤ cap c := by decide +kernel

/-- The 37 successively nested maximum-cap observations form a single site law. -/
def cdf (j : ℕ) : ℕ → ℚ
  | 0 => 0
  | k+1 => max (cdf j k) (min 1 (rawCDF (Fin.ofNat 37 k) j))

def binQ (j : ℕ) (c : DebitNativeClasses.Class) := FrozenCaps.width*(cdf j (c.val+1)-cdf j c.val)

noncomputable def law (b : Atom) : ℝ :=
  match b.2 with
  | none => 0
  | some c => if b.1.val≤130964 then (binQ b.1.val c:ℝ) else 0

def probability (b : Atom) : ℚ :=
  match b.2 with
  | none => 0
  | some c => if b.1.val≤130964 then cdf b.1.val (c.val+1)-cdf b.1.val c.val else 0

theorem law_scaled (b : Atom) : law b=Native.step*(probability b:ℝ) := by
  obtain ⟨t,o⟩ := b
  cases o with
  | none => simp [law,probability]
  | some c =>
    by_cases ok : t.val≤130964
    · norm_num [law,probability,ok,binQ,FrozenCaps.width,Native.step]
    · simp [law,probability,ok]

theorem cdf_le_one (j k : ℕ) : cdf j k ≤ 1 := by
  induction k with
  | zero => norm_num [cdf]
  | succ n ih => exact max_le ih (min_le_left _ _)

theorem small_cdf {j : ℕ} (h : j < 45067) (k : ℕ) : cdf j (k+1)=1 := by
  have capped := h.trans_le (first_le (Fin.ofNat 37 k))
  simp only [cdf,rawCDF,ite_eq_left capped,min_self,max_eq_right (cdf_le_one j k)]

theorem small_first {j : ℕ} (h : j < 45067) : binQ j 0=FrozenCaps.width := by
  change FrozenCaps.width*(cdf j (0+1)-cdf j 0)=FrozenCaps.width
  rw [small_cdf h]; simp [cdf]

theorem small_next {j : ℕ} (h : j < 45067) (c : Fin 36) : binQ j c.succ=0 := by
  change FrozenCaps.width*(cdf j (c.val+1+1)-cdf j (c.val+1))=0
  rw [small_cdf h,small_cdf h]; ring

theorem bin_nonneg (j : ℕ) (c : DebitNativeClasses.Class) : 0 ≤ binQ j c :=
  mul_nonneg (by norm_num [FrozenCaps.width]) (sub_nonneg.mpr (le_max_left _ _))

theorem law_nonneg (b : Atom) : 0 ≤ law b := by
  obtain ⟨t,o⟩ := b
  cases o with
  | none => simp [law]
  | some c =>
    by_cases inside : t.val≤130964
    · simp only [law,ite_eq_left inside]; exact_mod_cast bin_nonneg t.val c
    · simp [law,inside]

private theorem telescopes (j n : ℕ) :
    (∑ i ∈ Finset.range n, (cdf j (i+1)-cdf j i)) = cdf j n := by
  induction n with
  | zero => simp [cdf]
  | succ n ih => rw [Finset.sum_range_succ,ih]; ring

theorem totalQ (j : ℕ) : (∑ c : DebitNativeClasses.Class,binQ j c) ≤ FrozenCaps.width := by
  unfold binQ
  rw [←Finset.mul_sum,Fin.sum_univ_eq_sum_range (fun i => cdf j (i+1)-cdf j i),telescopes]
  exact (mul_le_mul_of_nonneg_left (cdf_le_one j 37) (by norm_num [FrozenCaps.width])).trans_eq (mul_one _)

theorem surviving (j : Fin 130966) (inside : j.val≤130964) :
    (∑ c : DebitNativeClasses.Class,law (j,some c)) ≤ Native.step := by
  simp only [law,ite_eq_left inside]
  have cast : ((∑ c : DebitNativeClasses.Class,binQ j.val c : ℚ):ℝ) ≤ (FrozenCaps.width:ℝ) := by exact_mod_cast totalQ j.val
  push_cast at cast
  simpa only [FrozenCaps.width,Native.step,Rat.cast_div,Rat.cast_natCast,Rat.cast_ofNat] using cast

#print axioms surviving
end PrimeGap180.ReferenceLaw
