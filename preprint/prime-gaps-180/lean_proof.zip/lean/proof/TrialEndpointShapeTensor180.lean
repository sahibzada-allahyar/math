import Mathlib.Tactic.IrreducibleDef
import TrialPairMomentPolynomial180
import TrialFullNativeTicks180
import TrialEndpointPhysical180

/-! The 39-coordinate angular kernel is the 37-site polynomial times
the two ordered endpoint-shape polynomials. -/
noncomputable section
open scoped Classical BigOperators Polynomial
open Polynomial PrimeGap180.PackedLaw PrimeGap180.PackedSingleFields PrimeGap180.FrozenChannels
open PrimeGap180.NativePairTicks PrimeGap180.FrozenProfile
namespace PrimeGap180.EndpointShapeTensor
set_option maxRecDepth 32000
set_option maxHeartbeats 1300000

/-- Keep specialization of the 39-fold finite sum from enumerating the sample
space during conversion checking. The generated equation is valid for every
finite type. -/
irreducible_def sumValue {A R : Type*} [Fintype A] [AddCommMonoid R] (f : A → R) : R := ∑ a,f a

irreducible_def productValue {R : Type*} [CommSemiring R] (a b c : R) : R := a*b*c

def endSite (g : Grid) (c : Hist) (a b : Fin 3) (j : Tick) :=
  PairMomentPolynomial.site g c j*shapes (center j.val) a*shapes (center j.val) b

def endPoly (g : Grid) (c : Hist) (a b : Fin 3) : ℝ[X] :=
  sumValue (fun j : Tick => monomial j.val (endSite g c a b j))

def tensor (g : Grid) (c : Hist) (u v : FullNativeTicks.Key) :=
  productValue (endPoly g c u.1 v.1) (endPoly g c u.2.1 v.2.1) (PairMomentPolynomial.gram g c u.2.2 v.2.2)

def fullTerm (g : Grid) (c : Hist) (u v : FullNativeTicks.Key) (t : Fin 39 → Tick) : ℝ[X] :=
  monomial (∑ i,(t i).val) ((∏ i,PairMomentPolynomial.site g c (t i))*FullNativeTicks.angular u
    (fun i => (t i).val)*FullNativeTicks.angular v (fun i => (t i).val))

private def coreTerm (g : Grid) (c : Hist) (s u : Fin 11) (t : Fin 37 → Tick) : ℝ[X] :=
  monomial (∑ i,(t i).val) ((∏ i,PairMomentPolynomial.site g c (t i))*
    powers s (fun i => (t i).val)*powers u (fun i => (t i).val))

def orig (g : Grid) (c : Hist) (u v : FullNativeTicks.Key) : ℝ[X] :=
  sumValue (fullTerm g c u v)

private theorem splitEnds {A B : Type*} [Fintype A] [AddCommMonoid B] (Q : (Fin 39 → A) → B) :
    (∑ x,Q x)=∑ a : A,∑ b : A,∑ t : Fin 37 → A,Q (EndpointPhysical.join t a b) := by
  rw [←Equiv.sum_comp (Fin.consEquiv (fun _ : Fin 39 => A)) Q,Fintype.sum_prod_type]
  apply Finset.sum_congr rfl
  intro a _
  change (∑ x : Fin 38 → A,Q (Fin.cons (α:=fun _ => A) a x))=_
  rw [←Equiv.sum_comp (Fin.snocEquiv (fun _ : Fin 38 => A)) (fun x => Q (Fin.cons (α:=fun _ => A) a x)),Fintype.sum_prod_type]
  rfl

private theorem core_eq (g : Grid) (c : Hist) (s u : Fin 11) :
    PairMomentPolynomial.gram g c s u =
      ∑ t : Fin 37 → Tick,monomial (∑ i,(t i).val)
        ((∏ i,PairMomentPolynomial.site g c (t i))*powers s (fun i => (t i).val)*powers u (fun i => (t i).val)) := by
  ext J
  rw [PairMomentPolynomial.coefficient]
  simp only [finsetSum_coeff,coeff_monomial]

private theorem point (g : Grid) (c : Hist) (u v : FullNativeTicks.Key) (a b : Tick) (t : Fin 37 → Tick) :
    fullTerm g c u v (EndpointPhysical.join t a b) =
    monomial a.val (endSite g c u.1 v.1 a)*monomial b.val (endSite g c u.2.1 v.2.1 b)*coreTerm g c u.2.2 v.2.2 t := by
  unfold fullTerm coreTerm
  have sum (f : Tick → ℕ) : (∑ i,f (EndpointPhysical.join t a b i))=
      f a+f b+∑ i,f (t i) := by
    unfold EndpointPhysical.join
    rw [Fin.sum_univ_succ,Fin.sum_univ_castSucc]
    simp only [Fin.cons_zero,Fin.cons_succ,Fin.snoc_last,Fin.snoc_castSucc]
    omega
  have prod (f : Tick → ℝ) : (∏ i,f (EndpointPhysical.join t a b i))=
      f a*f b*∏ i,f (t i) := by
    unfold EndpointPhysical.join
    rw [Fin.prod_univ_succ,Fin.prod_univ_castSucc]
    simp only [Fin.cons_zero,Fin.cons_succ,Fin.snoc_last,Fin.snoc_castSucc]
    ring
  rw [sum (fun j => j.val),prod,monomial_mul_monomial,monomial_mul_monomial]
  apply congrArg (monomial _)
  have e : Fin.last 38=(Fin.last 37).succ := rfl
  simp only [FullNativeTicks.angular,EndpointPhysical.join,e,Fin.cons_zero,Fin.cons_succ,
    Fin.snoc_last,Fin.snoc_castSucc,powers,endSite]
  ring

private theorem triple {A B C R : Type*} [Fintype A] [Fintype B] [Fintype C]
    [CommSemiring R] (f : A → R) (h : B → R) (q : C → R) :
    (∑ a,∑ b,∑ t,f a*h b*q t)=(∑ a,f a)*(∑ b,h b)*(∑ t,q t) := by
  simp only [←Finset.mul_sum,←Finset.sum_mul]


private theorem separated {A R : Type*} [Fintype A] [CommSemiring R]
    (F : (Fin 39 → A) → R) (f h : A → R) (q : (Fin 37 → A) → R)
    (pointwise : ∀ a b t, F (EndpointPhysical.join t a b)=f a*h b*q t) :
    (∑ t,F t)=(∑ a,f a)*(∑ b,h b)*(∑ t,q t) := by
  rw [splitEnds F]
  simp only [pointwise]
  exact triple f h q

private theorem compact {A R : Type*} [Fintype A] [CommSemiring R]
    (F : (Fin 39 → A) → R) (f h : A → R) (q : (Fin 37 → A) → R)
    (pointwise : ∀ a b t, F (EndpointPhysical.join t a b)=f a*h b*q t) :
    sumValue F = productValue (sumValue f) (sumValue h) (sumValue q) := by
  simp only [sumValue_def,productValue_def]
  exact separated F f h q pointwise

private theorem middle (g : Grid) (c : Hist) (s u : Fin 11) :
    sumValue (coreTerm g c s u) = PairMomentPolynomial.gram g c s u := by
  rw [sumValue_def]
  exact (core_eq g c s u).symm

theorem factor (g : Grid) (c : Hist) (u v : FullNativeTicks.Key) : orig g c u v=tensor g c u v := by
  let f (j : Tick) := monomial j.val (endSite g c u.1 v.1 j)
  let h (j : Tick) := monomial j.val (endSite g c u.2.1 v.2.1 j)
  have H := compact (fullTerm g c u v) f h (coreTerm g c u.2.2 v.2.2) (point g c u v)
  exact H.trans (congrArg (productValue (sumValue f) (sumValue h)) (middle g c u.2.2 v.2.2))

#print axioms factor
end PrimeGap180.EndpointShapeTensor
