import TrialPriceRows180
namespace PrimeGap180.PriceRowPilot
set_option maxHeartbeats 100000000
set_option maxRecDepth 131072
set_option profiler true in
theorem group0 : PriceRows.check (0 : Book.Group) = true := by decide +kernel
#print axioms group0
end PrimeGap180.PriceRowPilot
