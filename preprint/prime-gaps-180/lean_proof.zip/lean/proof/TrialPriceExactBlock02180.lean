import TrialPriceScalar180
namespace PrimeGap180.PriceExactCensus
set_option maxHeartbeats 100000000
set_option maxRecDepth 65536
private theorem c64 : PriceScalar.checked (64 : Book.Label) = true := by decide +kernel
private theorem c65 : PriceScalar.checked (65 : Book.Label) = true := by decide +kernel
private theorem c66 : PriceScalar.checked (66 : Book.Label) = true := by decide +kernel
private theorem c67 : PriceScalar.checked (67 : Book.Label) = true := by decide +kernel
private theorem c68 : PriceScalar.checked (68 : Book.Label) = true := by decide +kernel
private theorem c69 : PriceScalar.checked (69 : Book.Label) = true := by decide +kernel
private theorem c70 : PriceScalar.checked (70 : Book.Label) = true := by decide +kernel
private theorem c71 : PriceScalar.checked (71 : Book.Label) = true := by decide +kernel
private theorem c72 : PriceScalar.checked (72 : Book.Label) = true := by decide +kernel
private theorem c73 : PriceScalar.checked (73 : Book.Label) = true := by decide +kernel
private theorem c74 : PriceScalar.checked (74 : Book.Label) = true := by decide +kernel
private theorem c75 : PriceScalar.checked (75 : Book.Label) = true := by decide +kernel
private theorem c76 : PriceScalar.checked (76 : Book.Label) = true := by decide +kernel
private theorem c77 : PriceScalar.checked (77 : Book.Label) = true := by decide +kernel
private theorem c78 : PriceScalar.checked (78 : Book.Label) = true := by decide +kernel
private theorem c79 : PriceScalar.checked (79 : Book.Label) = true := by decide +kernel
private theorem c80 : PriceScalar.checked (80 : Book.Label) = true := by decide +kernel
private theorem c81 : PriceScalar.checked (81 : Book.Label) = true := by decide +kernel
private theorem c82 : PriceScalar.checked (82 : Book.Label) = true := by decide +kernel
private theorem c83 : PriceScalar.checked (83 : Book.Label) = true := by decide +kernel
private theorem c84 : PriceScalar.checked (84 : Book.Label) = true := by decide +kernel
private theorem c85 : PriceScalar.checked (85 : Book.Label) = true := by decide +kernel
private theorem c86 : PriceScalar.checked (86 : Book.Label) = true := by decide +kernel
private theorem c87 : PriceScalar.checked (87 : Book.Label) = true := by decide +kernel
private theorem c88 : PriceScalar.checked (88 : Book.Label) = true := by decide +kernel
private theorem c89 : PriceScalar.checked (89 : Book.Label) = true := by decide +kernel
private theorem c90 : PriceScalar.checked (90 : Book.Label) = true := by decide +kernel
private theorem c91 : PriceScalar.checked (91 : Book.Label) = true := by decide +kernel
private theorem c92 : PriceScalar.checked (92 : Book.Label) = true := by decide +kernel
private theorem c93 : PriceScalar.checked (93 : Book.Label) = true := by decide +kernel
private theorem c94 : PriceScalar.checked (94 : Book.Label) = true := by decide +kernel
private theorem c95 : PriceScalar.checked (95 : Book.Label) = true := by decide +kernel
theorem block2 : ∀ i : Fin 32, PriceScalar.checked ⟨64+i.val,by omega⟩ = true :=
  Fin.cases c64 (Fin.cases c65 (Fin.cases c66 (Fin.cases c67 (Fin.cases c68 (Fin.cases c69 (Fin.cases c70 (Fin.cases c71 (Fin.cases c72 (Fin.cases c73 (Fin.cases c74 (Fin.cases c75 (Fin.cases c76 (Fin.cases c77 (Fin.cases c78 (Fin.cases c79 (Fin.cases c80 (Fin.cases c81 (Fin.cases c82 (Fin.cases c83 (Fin.cases c84 (Fin.cases c85 (Fin.cases c86 (Fin.cases c87 (Fin.cases c88 (Fin.cases c89 (Fin.cases c90 (Fin.cases c91 (Fin.cases c92 (Fin.cases c93 (Fin.cases c94 (Fin.cases c95 (fun i => Fin.elim0 i))))))))))))))))))))))))))))))))
#print axioms block2
end PrimeGap180.PriceExactCensus
