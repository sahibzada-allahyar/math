import TrialRadialSplit180
import TrialDualCharges180

/-! Put a physical signed sector estimate in the reference gauge used by
the integer dual. The map from sectors to groups can have arbitrary fibres. -/
noncomputable section
open scoped Classical BigOperators Topology
open MeasureTheory Filter PrimeGap186 PrimeGap182Analytic
namespace PrimeGap180.Sector

def gaugeGroup {S G : Type*} [Fintype S] (owner : S → G) (ref : G → ℝ) (v : S → ℝ) (g : G) :=
  (∑ s with owner s = g, v s) / Real.sqrt (ref g)

def gaugeCost {S G : Type*} [Fintype S] (owner : S → G) (ref : G → ℝ) (v : S → ℝ) (g : G) :=
  (∑ s with owner s = g, v s) / ref g

private theorem grouped_sum {S G : Type*} [Fintype S] [Fintype G] (owner : S → G) (w : G → ℝ) (v : S → ℝ) :
    (∑ g, w g*(∑ s with owner s = g, v s)) = ∑ s, w (owner s)*v s := by
  simp only [Finset.mul_sum]
  calc
    _ = ∑ g : G, ∑ s with owner s = g, w (owner s)*v s := by
      apply Finset.sum_congr rfl
      intro g _
      apply Finset.sum_congr rfl
      intro s hs
      rw [(Finset.mem_filter.mp hs).2]
    _ = _ := Finset.sum_fiberwise_of_maps_to (fun _ _ => Finset.mem_univ _) _

theorem gauge_root_sum {S G : Type*} [Fintype S] [Fintype G] (owner : S → G) (ref c : G → ℝ) (v : S → ℝ) :
    (∑ g, c g * gaugeGroup owner ref v g) = ∑ s, (c (owner s)/Real.sqrt (ref (owner s)))*v s := by
  simpa only [gaugeGroup,div_eq_mul_inv,mul_right_comm,mul_assoc,mul_left_comm,mul_comm] using
    grouped_sum owner (fun g => c g / Real.sqrt (ref g)) v

theorem gauge_energy_sum {S G : Type*} [Fintype S] [Fintype G] (owner : S → G)
    (ref c : G → ℝ) (pos : ∀ g, 0 < ref g) (v : S → ℝ) :
    (∑ g, gaugeCost owner ref v g * (c g)^2) = ∑ s, (c (owner s)/Real.sqrt (ref (owner s)))^2*v s := by
  simp only [div_pow,fun g => Real.sq_sqrt (pos g).le]
  trans ∑ g, ((c g)^2 / ref g) * (∑ s with owner s = g, v s)
  · apply Finset.sum_congr rfl
    intro g _
    dsimp only [gaugeCost]
    ring
  · exact grouped_sum owner (fun g => (c g)^2 / ref g) v

private theorem scalar_root {ι : Type*} [Fintype ι] (c : ℝ) (y : (ι → ℕ) →₀ ℝ) (v : ι → ℕ) :
    sampledSelbergRoot (c • y) v = c * sampledSelbergRoot y v := by
  classical
  have lin := PrimeGap182.Selberg.selberg_divisor_root_finset_combination ({()} : Finset Unit)
    (fun _ => c) (fun _ => y) v
  simpa only [sampledSelbergRoot,Finset.sum_singleton] using lin

theorem signed_sector_root {m : ℕ} (H : Finset ℕ) (a : Fin (m+2) → ℝ) (k : Fin 39)
    (F : Profile 39 m) (c x : ℝ) (v : Fin 38 → ℕ) :
    sampledSelbergRoot (face H a k (fun y => c * F y) x) v =
      c * sampledSelbergRoot (face H a k F x) v := by
  rw [←scalar_root]
  congr 1
  apply Finsupp.ext
  intro r
  exact face_weight_retained H a k (fun _ => c) F x r

theorem signed_sector_energy {m : ℕ} (a : Fin (m+2) → ℝ) (k : Fin 39)
    (F : Profile 39 m) (K : (Fin 38 → Band m) → ℝ) (c : ℝ) :
    (∫ y, K y * (integralFace a k (fun t => c * F t) y)^2 ∂Measure.pi fun _ => bandLaw a) =
      c^2 * ∫ y, K y * (integralFace a k F y)^2 ∂Measure.pi fun _ => bandLaw a := by
  simp only [integralFace,integral_const_mul,mul_pow]
  rw [←integral_const_mul]
  apply integral_congr_ae
  exact Eventually.of_forall fun _ => by ring

/-- Multiplication by a signed group coefficient introduces no new
regularity assumption at a sector boundary. -/
theorem signed_sector_regular {m : ℕ} (a : Fin (m+2) → ℝ) (k : Fin 39)
    (P : (Fin 38 → Band m) → Prop) (F : Profile 39 m) (c : ℝ)
    (bf : Bornology.IsBounded (Set.range F)) (mf : Measurable (restrictFace k P F))
    (cf : ∀ᵐ y ∂Measure.pi (fun _ => bandLaw a), ContinuousAt (restrictFace k P F) y) :
    let G := fun y => c * F y
    Bornology.IsBounded (Set.range G) ∧ Measurable (restrictFace k P G) ∧
      ∀ᵐ y ∂Measure.pi (fun _ => bandLaw a), ContinuousAt (restrictFace k P G) y := by
  intro G
  have eq : restrictFace k P G = fun y => c * restrictFace k P F y := by
    funext y
    by_cases hit : P (k.removeNth y) <;> simp [restrictFace,G,hit]
  rw [eq]
  refine ⟨?_,measurable_const.mul mf,?_⟩
  · obtain ⟨B,_,bound⟩ := bf.exists_pos_norm_le
    refine isBounded_iff_forall_norm_le.mpr ⟨‖c‖*B,?_⟩
    rintro _ ⟨y,rfl⟩
    exact (norm_mul_le c (F y)).trans (mul_le_mul_of_nonneg_left (bound _ ⟨y,rfl⟩) (norm_nonneg _))
  · filter_upwards [cf] with y hy
    exact continuousAt_const.mul hy

/-- The marked theorem on the scaled full profiles is exactly the grouped
square bound required by the integer dual, including progression and scale. -/
theorem gauge_physical_upper {m : ℕ} {S G : Type*} [Fintype S] [Fintype G]
    (H : Finset ℕ) (a : Fin (m+2) → ℝ) (k : Fin 39) (h : Fin 39 → ℕ)
    (F : S → Profile 39 m) (K : S → (Fin 38 → Band m) → ℝ) (owner : S → G) (ref c : G → ℝ)
    (pos : ∀ g, 0 < ref g) (event : ℝ → ℕ → ℝ) (interval : ℝ → Finset ℕ) (b : ℝ → ℕ)
    (L : Filter ℝ) (cofinal : L ≤ atTop) :
    let d := fun s => c (owner s) / Real.sqrt (ref (owner s))
    let V := fun x n s => sampledSelbergRoot (face H a k (F s) x) (fun t => n+h (k.succAbove t))
    let E := fun s => ∫ y, K s y * (integralFace a k (F s) y)^2 ∂Measure.pi (fun _ => bandLaw a)
    let pay := fun x n => if Nat.ModEq (presievingModulus H x) n (b x) then (markedScale H x)⁻¹ else 0
    (∀ ε > 0, ∀ᶠ x : ℝ in atTop,
      (∑ n ∈ interval x, if Nat.ModEq (presievingModulus H x) n (b x) then
        event x n*(∑ s, sampledSelbergRoot (face H a k (fun y => d s * F s y) x)
          (fun t => n+h (k.succAbove t)))^2 else 0)/markedScale H x ≤
        (∑ s, ∫ y, K s y * (integralFace a k (fun t => d s * F s t) y)^2 ∂Measure.pi (fun _ => bandLaw a))+ε) →
    Price.Upper L (fun x => Price.squareCount (interval x) (fun n => event x n * pay x n)
      (fun n => gaugeGroup owner ref (V x n)) c) (∑ g, gaugeCost owner ref E g * (c g)^2) := by
  intro d V E pay law ε he
  filter_upwards [cofinal (law ε he)] with x upper
  rw [gauge_energy_sum owner ref c pos]
  simp only [signed_sector_root,signed_sector_energy] at upper
  convert upper using 1
  unfold Price.squareCount
  rw [Finset.sum_div]
  apply Finset.sum_congr rfl
  intro n _
  rw [gauge_root_sum]
  by_cases hn : Nat.ModEq (presievingModulus H x) n (b x)
  · simp [pay,hn,V,d,div_eq_mul_inv]; ring
  · simp [pay,hn]

/-- The prime measure and the shared prime-strip resource both have the
variable-price bound on the original signed group coordinates. -/
theorem gauge_prime_upper {m : ℕ} {S G : Type*} [Fintype S] [Fintype G]
    (H : Finset ℕ) (hH : H.card=39) (k : Fin 39) (a : Fin (m+2) → ℝ) (ha : StrictMono a)
    (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (P : S → (Fin 38 → Band m) → Prop) (F : Profile 39 m)
    (sep : ∀ s t, s ≠ t → ∀ y, P s y → ¬ P t y)
    (bf : Bornology.IsBounded (Set.range F))
    (rad : ∀ s y, P s y → 0 ≤ retainedRadius y ∧ retainedRadius y ≤ 0.2801)
    (mf : ∀ s, Measurable (restrictFace k (P s) F))
    (cf : ∀ s, ∀ᵐ y ∂Measure.pi (fun _ => bandLaw a), ContinuousAt (restrictFace k (P s) F) y)
    (owner : S → G) (ref c : G → ℝ) (pos : ∀ g, 0 < ref g)
    (b : ℝ → ℕ) (L : Filter ℝ) (cofinal : L ≤ atTop) :
    let h : Fin 39 → ℕ := H.orderEmbOfFin hH
    let Z := fun s => restrictFace k (P s) F
    let V := fun x n s => sampledSelbergRoot (face H a k (Z s) x) (fun t => n+h (k.succAbove t))
    let E := fun s => ∫ y, primePrice (retainedRadius y) * (integralFace a k (Z s) y)^2 ∂Measure.pi (fun _ => bandLaw a)
    let pay := fun x n => if Nat.ModEq (presievingModulus H x) n (b x) then (markedScale H x)⁻¹ else 0
    Price.Upper L (fun x => Price.squareCount (Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊)
      (fun n => (if (n+h k).Prime then (1:ℝ) else 0) * pay x n) (fun n => gaugeGroup owner ref (V x n)) c)
      (∑ g, gaugeCost owner ref E g * (c g)^2) := by
  intro h Z V E pay
  apply gauge_physical_upper H a k h Z (fun _ y => primePrice (retainedRadius y)) owner ref c pos
    (fun _ n => if (n+h k).Prime then 1 else 0) (fun x => Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊) b L cofinal
  intro ε he
  let d := fun s => c (owner s)/Real.sqrt (ref (owner s))
  have reg := fun s => signed_sector_regular a k (P s) F (d s) bf (mf s) (cf s)
  have eq (s) : restrictFace k (P s) (fun t => d s * F t) = fun t => d s * Z s t := by
    funext t
    by_cases hs : P s (k.removeNth t) <;> simp [Z,restrictFace,hs]
  have law := prime_sector_price_of_regular H hH k a ha first last P (fun s t => d s * F t) sep
    (fun s => (reg s).1) rad (fun s => (reg s).2.1) (fun s => (reg s).2.2) b he
  filter_upwards [law] with x paid
  simp only [eq] at paid
  convert paid using 1
  congr 1
  apply Finset.sum_congr rfl
  intro n _
  by_cases hn : Nat.ModEq (presievingModulus H x) n (b x) <;> by_cases hp : (n+h k).Prime <;>
    simp [hn,hp,h,d] at *

#print axioms gauge_prime_upper
#print axioms gauge_physical_upper
#print axioms signed_sector_regular
#print axioms signed_sector_root
#print axioms signed_sector_energy
end PrimeGap180.Sector
