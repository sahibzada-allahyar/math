import TrialDensityTriangleInputs180
namespace PrimeGap180.DensitySimplex.Horner.TriangleChecks
private theorem lower_den0 (z : Fin 2 → ℝ) :
    ((L 0).map (factorValue z)).prod/((unit^3:Int):ℝ) = threeDen (lowerMap (r 0) (s 0) z) := by
  have hr : r 0 = 2113999/10000000000 := by decide +kernel
  have hs : s 0 = 602110501/5000000000 := by decide +kernel
  have forms : L 0 = factors 1208449000 4227998 0 2408442004 := rfl
  rw [hr,hs,forms]
  norm_num [factors,unit,factorValue,Fin.sum_univ_two,threeDen,lowerMap] <;> ring
private theorem upper_den0 (z : Fin 2 → ℝ) :
    ((U 0).map (factorValue z)).prod/((unit^3:Int):ℝ) = threeDen (upperMap (r 0) (s 0) z) := by
  have hr : r 0 = 2113999/10000000000 := by decide +kernel
  have hs : s 0 = 602110501/5000000000 := by decide +kernel
  have forms : U 0 = factors 4227998 0 2408442004 2410556003 := rfl
  rw [hr,hs,forms]
  norm_num [factors,unit,factorValue,Fin.sum_univ_two,threeDen,upperMap] <;> ring

set_option maxRecDepth 65536 in
set_option maxHeartbeats 0 in
theorem row00 : triangleQ (r 0) (s 0) = FrozenNumbers.triangles 0 := by
  rw [triangle_from_forms _ _ (L 0) (U 0) (unit^3) (unit^3) (by decide) (by decide)
    lower_den0 upper_den0]
  decide +kernel

#print axioms row00
end PrimeGap180.DensitySimplex.Horner.TriangleChecks
