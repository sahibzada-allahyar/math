import TrialSourceAffineSpan00180
import TrialSourceAffineSpan01180
import TrialSourceAffineSpan02180
import TrialSourceAffineSpan03180
import TrialSourceAffineSpan04180
import TrialSourceAffineSpan05180
import TrialSourceAffineSpan06180
import TrialSourceAffineSpan07180
import TrialSourceAffineSpan08180
import TrialSourceAffineSpan09180
import TrialSourceAffineSpan10180
import TrialSourceAffineSpan11180
import TrialSourceAffineSpan12180
import TrialSourceAffineSpan13180
namespace PrimeGap180.SourceAffine.Spans
private theorem slots : ∀ i : Fin 14, spanRow i.val = true :=
  (Fin.cases row00 (Fin.cases row01 (Fin.cases row02 (Fin.cases row03 (Fin.cases row04 (Fin.cases row05 (Fin.cases row06 (Fin.cases row07 (Fin.cases row08 (Fin.cases row09 (Fin.cases row10 (Fin.cases row11 (Fin.cases row12 (Fin.cases row13 (fun z => Fin.elim0 z)))))))))))))))

theorem forbidden_zero {k g h : Nat} (bound : max g h < 445) (no : Compact.forbidden k g h) :
    Compact.matrix k g h = 0 := by
  by_cases small : k < 14
  · exact off (slots ⟨k,small⟩) bound no
  · exact zero_of_bit (Compact.disjoint_row (Compact.beyond _ (Nat.le_of_not_gt small)) (min g h)) bound no

#print axioms forbidden_zero
end PrimeGap180.SourceAffine.Spans
