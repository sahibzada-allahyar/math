import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G202
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 202

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G202

namespace PrimeGap180.PriceIsolatedGroup.G207
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 207

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G207

namespace PrimeGap180.PriceIsolatedGroup.G212
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 212

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G212

namespace PrimeGap180.PriceIsolatedGroup.G217
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 217

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G217
