import TrialPairMomentPolynomial180
import TrialAngularEnumeration180
import TrialRoundedCaps180

/-! A simultaneous-endpoint Gram is an eleven-by-eleven contraction of
the actual signed erasure fields against exact native polynomial coefficients.
The factored form of the cap increment is the one evaluated by the replay. -/
noncomputable section
open scoped Classical BigOperators Polynomial
open PrimeGap180.PackedLaw PrimeGap180.PackedSingleFields PrimeGap180.FrozenProfile
open PrimeGap180.FrozenChannels PrimeGap180.NativePairTicks PrimeGap180.PackedRoleKernels
namespace PrimeGap180.PairCoefficientSum
set_option maxHeartbeats 1200000
set_option maxRecDepth 4500

private theorem rotate {A B C : Type*} [Fintype A] [Fintype B] [Fintype C] (f : A → B → C → ℝ) :
    (∑ a,∑ b,∑ c,f a b c)=∑ b,∑ c,∑ a,f a b c := by
  rw [Finset.sum_comm (s:=(Finset.univ : Finset A)) (t:=(Finset.univ : Finset B))]
  exact Finset.sum_congr rfl (fun _ _ => Finset.sum_comm)

theorem square {A B : Type*} [Fintype A] [Fintype B]
    (w : A → ℝ) (F : B → ℝ) (U : A → B → ℝ) :
    (∑ a,w a*(∑ b,F b*U a b)^2)=
      ∑ b,∑ c,F b*F c*(∑ a,w a*U a b*U a c) := by
  calc
    _ = ∑ a,∑ b,∑ c,w a*((F b*U a b)*(F c*U a c)) := by
      simp only [pow_two,Finset.sum_mul,Finset.mul_sum]
      exact Finset.sum_congr rfl (fun a _ => Finset.sum_comm)
    _ = _ := by
      rw [rotate]
      simp only [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro b _
      apply Finset.sum_congr rfl
      intro c _
      apply Finset.sum_congr rfl
      intro a _
      ring

private def gate (g : Grid) (c : Hist) (J : ℕ) (t : Fin 37 → Tick) : ℝ :=
  if (∑ i,(t i).val)=J then ∏ i,PairMomentPolynomial.site g c (t i) else 0

private theorem prod_site (g : Grid) (c : Hist) (t : Fin 37 → Tick) :
    (∏ i,PairMomentPolynomial.site g c (t i))=
      100^37*(∏ i,w g c (t i))*(∏ i,siteFactor (center (t i).val))^2 := by
  simp only [PairMomentPolynomial.site,Finset.prod_mul_distrib,Finset.prod_const,
    Finset.card_univ,Fintype.card_fin,Finset.prod_pow]

private theorem picked (g : Grid) (c : Hist) (J : ℕ) (s u : Fin 11) :
    (∑ t : Fin 37 → Tick,gate g c J t*powers s (fun i => (t i).val)*powers u (fun i => (t i).val))=
      (PairMomentPolynomial.gram g c s u).coeff J := by
  rw [PairMomentPolynomial.coefficient]
  apply Finset.sum_congr rfl
  intro t _
  unfold gate
  split <;> simp

theorem gram (g : Grid) (c : Hist) (J k : ℕ) :
    100^37*pairGram g c J k=
      ∑ s,∑ u,field g J k s*field g J k u*(PairMomentPolynomial.gram g c s u).coeff J := by
  rw [NativePairTicks.gram]
  calc
    _ = ∑ t : Fin 37 → Tick,gate g c J t*
        (∑ s,field g J k s*powers s (fun i => (t i).val))^2 := by
      unfold kernel
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro t _
      unfold gate NativePairTicks.value
      by_cases yes : (∑ i,(t i).val)=J
      · rw [if_pos yes,if_pos yes,prod_site]
        ring
      · simp [yes]
    _ = _ := by rw [square]; simp only [picked]

theorem difference {I : Type*} [Fintype I] (f h : I → ℝ) (p : I → I → ℝ)
    (symm : ∀ i j,p i j=p j i) :
    (∑ i,∑ j,f i*f j*p i j)-(∑ i,∑ j,h i*h j*p i j)=
      ∑ i,∑ j,(f i-h i)*(f j+h j)*p i j := by
  have exchange : (∑ i,∑ j,f i*h j*p i j)=∑ i,∑ j,h i*f j*p i j := by
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro i _
    apply Finset.sum_congr rfl
    intro j _
    rw [symm j i]
    ring
  have expand (i j : I) : (f i-h i)*(f j+h j)*p i j =
      f i*f j*p i j-h i*h j*p i j+(f i*h j*p i j-h i*f j*p i j) := by ring
  simp only [expand,Finset.sum_add_distrib,Finset.sum_sub_distrib,exchange,sub_self,add_zero]

private theorem symmetric (g : Grid) (c : Hist) (J : ℕ) (s t : Fin 11) :
    (PairMomentPolynomial.gram g c s t).coeff J=(PairMomentPolynomial.gram g c t s).coeff J := by
  simp only [PairMomentPolynomial.coefficient]
  apply Finset.sum_congr rfl
  intro x _
  split <;> ring

theorem cap (g : Grid) (c : Hist) : RoundedCaps.p g c =
    ∑ j : Tick,NativeRoleTotals.q j.val * ∑ s : Fin 11,∑ t : Fin 11,
      (field g j.val c.val s-field g j.val (c.val+1) s)*
      (field g j.val c.val t+field g j.val (c.val+1) t)*(PairMomentPolynomial.gram g c s t).coeff j.val := by
  unfold RoundedCaps.p
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro j _
  calc
    _ = NativeRoleTotals.q j.val*(100^37*pairGram g c j.val c.val - 100^37*pairGram g c j.val (c.val+1)) := by ring
    _ = _ := by rw [gram,gram,difference _ _ _ (symmetric g c j.val)]

#print axioms gram
#print axioms cap
end PrimeGap180.PairCoefficientSum
