import TrialNativePairUpdates180

/-! Exact pointwise integration-by-parts formula for the historical
cap-by-cap signed Gram contractions, including every change of price.
The retained maximum selects the active suffix of the cap table. -/
noncomputable section
open scoped Classical BigOperators
open PrimeGap180.DebitNativeClasses PrimeGap180.NativeShellErasures PrimeGap180.NativePairUpdates
open PrimeGap180.CoarseLaw PrimeGap180.ReferenceRoles
namespace PrimeGap180.SignedCapContractions
set_option maxRecDepth 5000
set_option maxHeartbeats 1800000

def bank (D : Cap → ℝ) (n : ℕ) := ∑ k : Cap,if n≤k.val then D k else 0

private theorem noBank (D : Cap → ℝ) : bank D 37=0 := by
  unfold bank
  exact Finset.sum_eq_zero (fun k _ => if_neg (not_le.mpr k.isLt))

private theorem addBank (D : Cap → ℝ) (c : Cap) : bank D c.val=D c+bank D (c.val+1) := by
  have splitTerm (k : Cap) : (if c.val≤k.val then D k else 0) =
      (if k=c then D k else 0)+(if c.val+1≤k.val then D k else 0) := by
    by_cases eq : k=c
    · subst k; simp
    · have ne : k.val ≠ c.val := fun h => eq (Fin.ext h)
      by_cases le : c.val ≤ k.val
      · have lt : c.val+1≤k.val := by omega
        simp [le,lt,eq]
      · have lt : ¬c.val+1≤k.val := by omega
        simp [le,lt,eq]
  unfold bank
  simp_rw [splitTerm]
  rw [Finset.sum_add_distrib]
  simp

def update (p : ℕ → ℝ) (D : Cap → ℝ) (c : Cap) :=
  p c.val*D c*(2*bank D (c.val+1)+D c) + (p c.val-p (c.val+1))*(bank D (c.val+1))^2

theorem jump (p : ℕ → ℝ) (D : Cap → ℝ) (c : Cap) :
    update p D c = p c.val*(bank D c.val)^2-p (c.val+1)*(bank D (c.val+1))^2 := by
  rw [addBank]
  unfold update
  ring

theorem tail (f : ℕ → ℝ) (m n : ℕ) :
    (∑ k ∈ Finset.range n,if m≤k then f k-f (k+1) else 0) = if m<n then f m-f n else 0 := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [Finset.sum_range_succ,ih]
    by_cases before : m<n
    · simp only [before,before.le,Nat.lt_succ_of_lt before,ite_true]; ring
    · by_cases eq : m=n
      · subst n; simp
      · have after : n < m := by omega
        simp [before,not_le.mpr after,show ¬m<n+1 by omega]

private theorem suffix (m : Cap) (p : ℕ → ℝ) (D : Cap → ℝ) :
    (∑ c : Cap,if m≤c then update p D c else 0) = p m.val*(bank D m.val)^2 := by
  let f (k : ℕ) := p k*(bank D k)^2
  have eq (c : Cap) : (if m≤c then update p D c else 0) =
      if m.val≤c.val then f c.val-f (c.val+1) else 0 := by rw [jump]; rfl
  simp_rw [eq]
  rw [Fin.sum_univ_eq_sum_range (fun k => if m.val≤k then f k-f (k+1) else 0),tail,if_pos m.isLt]
  simp [f,noBank]

def keyPrice (J k : ℕ) :=
  if h : k<37 then
    let c := capAt ⟨k,h⟩
    NativeContractions.price ((if J>T.maxIndex c then none else T.sector c (J+1)).getD 170) J
  else 0

theorem priced (count : Cap → Prop) [DecidablePred count] (selected : Option Cap)
    (cover : ∀ c,count c ↔ ∃ m,selected=some m ∧ m≤c)
    (price : ℝ) (p : ℕ → ℝ) (D : Cap → ℝ)
    (pick : ∀ m,selected=some m → p m.val=price) :
    price*(∑ c : Cap,if count c then D c else 0)^2 =
      ∑ c : Cap,if count c then update p D c else 0 := by
  cases selected with
  | none =>
    have empty (c : Cap) : ¬count c := by rw [cover]; simp
    simp [empty]
  | some m =>
    have hit (c : Cap) : count c ↔ m≤c := by rw [cover]; simp
    simp only [hit]
    rw [suffix,pick m rfl]
    rfl

theorem single_face (w : Atom → ℝ) (i : Fin 39) (t : Fin 38 → Atom) :
    NativeContractions.price (sectorAtom t) (retained t)*(singleN w i t)^2 =
    ∑ c : Cap,if below t c then update (keyPrice (retained t)) (eraseDelta w i t) c else 0 := by
  rw [single_updates]
  apply priced (below t) (maximum t) (below_iff t)
  intro m selected
  simp [keyPrice,sectorAtom,selected,m.isLt]

theorem pair_face (w : Atom → ℝ) (t : Fin 37 → Atom) (p : ℝ) :
    p*(insertPair w t)^2 =
      ∑ c : Cap,if below t c then update (fun _ => p) (addPair w t) c else 0 := by
  rw [pair_updates]
  exact priced (below t) (maximum t) (below_iff t) p (fun _ => p) _ (fun _ _ => rfl)

#print axioms single_face
#print axioms pair_face
end PrimeGap180.SignedCapContractions
