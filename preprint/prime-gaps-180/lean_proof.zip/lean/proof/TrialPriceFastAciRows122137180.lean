import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G122
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 122

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G122

namespace PrimeGap180.PriceIsolatedGroup.G127
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 127

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G127

namespace PrimeGap180.PriceIsolatedGroup.G132
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 132

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G132

namespace PrimeGap180.PriceIsolatedGroup.G137
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 137

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G137
