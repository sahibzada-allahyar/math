import TrialTableRow00180
import TrialTableRow01180
import TrialTableRow02180
import TrialTableRow03180
import TrialTableRow04180
namespace PrimeGap180.TablePrices
theorem block0 (i : Fin 5) : certified (blockIndex 0 i) := by
  fin_cases i
  · exact row00
  · exact row01
  · exact row02
  · exact row03
  · exact row04
#print axioms block0
end PrimeGap180.TablePrices
