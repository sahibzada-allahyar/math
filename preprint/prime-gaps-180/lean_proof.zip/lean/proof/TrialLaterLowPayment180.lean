import TrialLaterLowFiniteSite180
import TrialLaterLowExponentialIntegral180

/-! The finite scalar one-site upper evaluation for every frozen gate,
expressed in the two exponential integrals of the deposited calculator. -/
noncomputable section
open Set MeasureTheory PrimeGap180.Sector PrimeGap180.FrozenProfile
open scoped NNReal BigOperators
namespace PrimeGap180.LaterLowFiniteSite
open LaterLowFactor (a c w g panel survival density)
open LaterLowProduct (weight ν)
open LaterLowTransform (site E1 edge)
open private density_pos mass from TrialLaterLowQuadrature180

private theorem nonneg (k : ℕ) : 0≤panel step k := by
  unfold panel
  rw [←mass]
  apply intervalIntegral.integral_nonneg (by dsimp [step]; linarith)
  intro x hx
  exact density_pos ((mul_nonneg (Nat.cast_nonneg k) (by norm_num [step])).trans hx.1)

private theorem mono (n : ℕ) {f g : ℕ→ℝ} (p : ∀ k,f k≤g k) : book n f≤book n g := by
  have h : 0 ≤ survival (node n) := by unfold survival node step a c; positivity
  apply add_le_add (add_le_add (mul_le_mul_of_nonneg_left (p _) (sq_nonneg _)) _) (mul_le_mul_of_nonneg_left (p _) h)
  exact Finset.sum_le_sum fun k _=>mul_le_mul_of_nonneg_left (p k) (nonneg k)

def majorant (e s r : ℝ) := Real.exp (E1 (s*e)-E1 ((s+r)*e))/(s+r)

/-- The deposited 1,600-panel scalar book bounds the genuine one-site
integral, including its native root weight, for erased and retained sites. -/
theorem payment (j : Active) (b r : ℝ≥0) (hb : 0<b) :
    (∫ z,weight (fun t=>g t^2) (FrozenData.tables.tailEdge j) b r z ∂ν) ≤
    book 1600 (fun k=>majorant (edge (FrozenData.tables.tailEdge j)) ((b+shift k:ℝ≥0):ℝ) r) := by
  apply (finite _ _ _ _).trans
  exact mono _ fun k=>LaterLowTransform.bound_E1 j (b+shift k) r (add_pos_of_pos_of_nonneg hb (show 0 ≤ shift k from (shift k).2))

/-- The full scalar physical row is reduced to the signed amplitude envelope
on its event and the outward evaluation of two explicit finite books. -/
theorem full (j : Active) (b r : ℝ≥0) (hb : 0<b) (E : Set (Fin 39→Band 216)) (mE : MeasurableSet E)
    (cut amp : ℝ) (ha : 0≤amp) (cover : E ⊆ JointEdgeConditional.erasedSet (FrozenData.tables.tailEdge j) 1 cut)
    (envelope : ∀ᵐ v ∂LaterLowProduct.μ, v∈E → |Restoration.original v| ≤
        amp*∏ k,siteFactor (LaterLowScalar.mid (v k))) :
    (∫ v in E,(Restoration.original v)^2 ∂LaterLowProduct.μ) ≤
      39*(amp^2*LaterLowFactor.bias^78)*Real.exp ((b:ℝ)*LaterLowProduct.totalCap+(r:ℝ)*cut) *
      book 1600 (fun k=>majorant (edge (FrozenData.tables.tailEdge j)) ((b+shift k:ℝ≥0):ℝ) 0) *
      (book 1600 (fun k=>majorant (edge (FrozenData.tables.tailEdge j)) ((b+shift k:ℝ≥0):ℝ) r))^38 := by
  have scalar := LaterLowScalar.bound E mE _ b r cut amp ha cover envelope
  have nonnegative (u : ℝ) : 0≤ ∫ z,weight (fun t=>g t^2) (FrozenData.tables.tailEdge j) b u z ∂ν :=
    integral_nonneg fun z=>mul_nonneg (sq_nonneg _) (Real.exp_pos _).le
  have zeroPay := payment j b 0 hb
  have retained := payment j b r hb
  have nzero := (nonnegative 0).trans zeroPay
  exact scalar.trans (mul_le_mul (mul_le_mul_of_nonneg_left zeroPay (by positivity))
    (pow_le_pow_left₀ (nonnegative r) retained 38) (by positivity) (by positivity))

#print axioms payment
#print axioms full
end PrimeGap180.LaterLowFiniteSite
