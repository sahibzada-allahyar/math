import TrialPriceFrozenSourceRows180
namespace PrimeGap180.PriceFactorSourceProof
set_option maxRecDepth 131072
set_option maxHeartbeats 100000000
set_option profiler true in
private theorem m70 : PriceFactorData.sourceCheck 70 = true := by decide +kernel
set_option profiler true in
private theorem m71 : PriceFactorData.sourceCheck 71 = true := by decide +kernel
set_option profiler true in
private theorem m72 : PriceFactorData.sourceCheck 72 = true := by decide +kernel
set_option profiler true in
private theorem m73 : PriceFactorData.sourceCheck 73 = true := by decide +kernel
set_option profiler true in
private theorem m74 : PriceFactorData.sourceCheck 74 = true := by decide +kernel
set_option profiler true in
private theorem m75 : PriceFactorData.sourceCheck 75 = true := by decide +kernel
set_option profiler true in
private theorem m76 : PriceFactorData.sourceCheck 76 = true := by decide +kernel
set_option profiler true in
private theorem m77 : PriceFactorData.sourceCheck 77 = true := by decide +kernel
set_option profiler true in
private theorem m78 : PriceFactorData.sourceCheck 78 = true := by decide +kernel
set_option profiler true in
private theorem m79 : PriceFactorData.sourceCheck 79 = true := by decide +kernel
theorem batch7 : ∀ i : Fin 10, PriceFactorData.sourceCheck (70+i.val) = true :=
  Fin.cases m70 (Fin.cases m71 (Fin.cases m72 (Fin.cases m73 (Fin.cases m74 (Fin.cases m75 (Fin.cases m76 (Fin.cases m77 (Fin.cases m78 (Fin.cases m79 (fun i => Fin.elim0 i))))))))))
#print axioms batch7
end PrimeGap180.PriceFactorSourceProof
