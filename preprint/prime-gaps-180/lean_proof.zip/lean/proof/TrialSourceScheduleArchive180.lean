import TrialSourceLongSchedule180
import Lean.Elab.Command
import Lean.Data.Json

/-! Read the literal numerical corner coordinates and the short schedule for
each corner. Every band is reconstructed from an actual original source grant.
A missing grant or failed analytic guard invalidates the whole schedule. -/
noncomputable section
open PrimeGap180.Book PrimeGap180.FrozenGuards PrimeGap180.SourceCornerArithmetic
open PrimeGap180.LongSchedule
namespace PrimeGap180.SourcePlans

structure CornerData where
  z : ℕ
  w : ℕ
  S : ℕ
  T : ℕ
  level : ℕ
  deriving Inhabited, Lean.ToExpr
structure StepCode where
  upper : ℕ
  source : ℕ
  dense : ℕ
  branch : ℕ
  deriving Inhabited, Lean.ToExpr
structure Entry where
  corner : CornerData
  steps : List StepCode
  deriving Inhabited, Lean.ToExpr
private structure GeoRow where
  channel : String
  corners : Array (Array ℕ)
  deriving Lean.FromJson
private structure Geometry where
  channels : Array GeoRow
  deriving Lean.FromJson
private structure PlanRow where
  channel : String
  plans : Array (Array (Array ℕ))
  deriving Lean.FromJson
private structure PlanFile where
  version : ℕ
  channels : Array PlanRow
  deriving Lean.FromJson

private def read (geo plans : String) : Except String (List (List (List Entry))) := do
  let src : Geometry ← Lean.fromJson? (← Lean.Json.parse geo)
  let data : PlanFile ← Lean.fromJson? (← Lean.Json.parse plans)
  unless src.channels.size == 14 && data.version == 1 && data.channels.size == 14 do throw "expected fourteen source rows"
  let mut archive := #[]
  for k in [:14] do
    let g ← src.channels[k]?.elim (throw "missing geometry") pure
    let r ← data.channels[k]?.elim (throw "missing schedules") pure
    let name := if k == 0 then "P" else if k == 1 then "P-B" else "S"++toString (k-2)
    unless g.channel == name && r.channel == name && g.corners.size == r.plans.size do throw "wrong channel or corner count"
    let mut entries := #[]
    for i in [:g.corners.size] do
      let point ← g.corners[i]?.elim (throw "missing point") pure
      let codes ← r.plans[i]?.elim (throw "missing steps") pure
      unless point.size == 5 && 0 < codes.size do throw "invalid point or empty schedule"
      let c : CornerData := ⟨point[0]!,point[1]!,point[2]!,point[3]!,point[4]!⟩
      let steps ← codes.mapM fun a => do
        unless a.size == 4 do throw "invalid source step"
        return (⟨a[0]!,a[1]!,a[2]!,a[3]!⟩ : StepCode)
      entries := entries.push (⟨c,steps.toList⟩ : Entry)
    archive := archive.push ((Array.range ((entries.size+7)/8)).map fun b => (entries.extract (8*b) (8*b+8)).toList).toList
  return archive.toList

open Lean Elab Term in
elab "longSourceCodes%" : term => do
  let path := (System.FilePath.mk (← getFileName)).parent.getD "."
  let geo ← IO.FS.readFile (path / "h1_multilevel_tail_tilt2.json")
  let plan ← IO.FS.readFile (path / "frozen_source_long_plans.json")
  return toExpr (← IO.ofExcept (read geo plan))

set_option maxRecDepth 65536 in
private def data : List (List (List Entry)) := longSourceCodes%

def blocks (k : Row) := data[FrozenGuards.code k]?.getD []
def entries (k : Row) := (blocks k).flatten

def CornerData.q (c : CornerData) : QCorner := ⟨tick c.z,tick c.w,tick c.S,tick c.T,tick c.level⟩

def source (k : Row) (i : ℕ) : Option Ticks := do
  let block ← (sourceBlocks k)[i/32]?
  block[i%32]?

private theorem source_member {k : Row} {i : ℕ} {t : Ticks} (h : source k i = some t) : t ∈ sourceTicks k := by
  unfold source at h
  cases b : (sourceBlocks k)[i/32]? with
  | none => simp [b] at h
  | some block =>
    have inBlock : block[i%32]? = some t := by simpa [b] using h
    have member : t ∈ (sourceBlocks k).flatten := List.mem_flatten.mpr ⟨block,List.mem_of_getElem? b,List.mem_of_getElem? inBlock⟩
    simpa [sourceTicks] using member

def materialize (k : Row) (a : StepCode) : Option Step := do
  let t ← source k a.source
  if verified k t = true then some ⟨a.upper,t,a.dense,a.branch⟩ else none

private theorem materialize_link {k : Row} {a : StepCode} {s : Step} (h : materialize k a = some s) :
    ∃ i : SourceIndex k, indexedGrant k i = grant k s.origin := by
  cases fromTable : source k a.source with
  | none => simp [materialize,fromTable] at h
  | some t =>
    by_cases ok : verified k t = true
    · have eq : (⟨a.upper,t,a.dense,a.branch⟩ : Step) = s := by simpa [materialize,fromTable,ok] using h
      subst s
      obtain ⟨i,_,hit⟩ := indexed_of_ticks (source_member fromTable) ok
      exact ⟨i,hit⟩
    · simp [materialize,fromTable,ok] at h

def realize (k : Row) (rows : List StepCode) := rows.filterMap (materialize k)

def replay (k : Row) (e : Entry) :=
  let s := realize k e.steps
  (s.length == e.steps.length) && !s.isEmpty && scan e.corner.q 5000000 s

def booked {k : Row} {e : Entry} (good : replay k e = true) : Booked k e.corner.q.real := by
  let rows := realize k e.steps
  have ok : (rows.length == e.steps.length) = true ∧ (!rows.isEmpty) = true ∧
      scan e.corner.q 5000000 rows = true := by simpa only [replay,rows,Bool.and_eq_true,and_assoc] using good
  apply of_list k e.corner.q rows (by simpa using ok.2.1) ok.2.2
  intro s member
  obtain ⟨a,_,found⟩ := List.mem_filterMap.mp member
  exact materialize_link found

#print axioms booked
end PrimeGap180.SourcePlans
