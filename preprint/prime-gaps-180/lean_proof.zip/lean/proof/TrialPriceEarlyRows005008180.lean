import TrialPriceWitnessGroupCommand180
import TrialPriceIsolatedChecks180
import TrialPriceWitnessCharge180
import TrialPriceAffinePhysical180

noncomputable section
namespace PrimeGap180.PriceAssemblyGroup.G005
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyWitnessPriceGroup 5

#print axioms events
end PrimeGap180.PriceAssemblyGroup.G005
namespace PrimeGap180.PriceAssemblyGroup.G006
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyWitnessPriceGroup 6

#print axioms events
end PrimeGap180.PriceAssemblyGroup.G006
namespace PrimeGap180.PriceAssemblyGroup.G007
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyWitnessPriceGroup 7

#print axioms events
end PrimeGap180.PriceAssemblyGroup.G007
namespace PrimeGap180.PriceAssemblyGroup.G008
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyWitnessPriceGroup 8

#print axioms events
end PrimeGap180.PriceAssemblyGroup.G008
