import TrialEarlyFailure180
import TrialFrozenKeyMesh180
import TrialPhysicalProjection180
import TrialRemovalEdgeBook180
import Batteries.Tactic.OpenPrivate

/-! The actual retained failure is inside the Chernoff slack/dust event
used for every one of the fourteen low edges. -/
noncomputable section
open scoped Classical BigOperators
open MeasureTheory
open PrimeGap180.Sector PrimeGap180.FrozenProfile PrimeGap180.FrozenData
open PrimeGap180.GateDeletion PrimeGap180.RunAlignment PrimeGap180.FrozenData.FiniteInput
namespace PrimeGap180.RemovedLowProjection

open private spans tagged cap_eq from TrialMeshKeySemantics180
open private certificate from TrialFrozenKeyMesh180
open private info_bounds from TrialFrozenData180

private def radial (s : Span) (a : Array ℕ) := decide (s.radius ≤ field a 2 ∧ s.cap ≤ field a 1)
private def last (a : Array ℕ) := field a 0

set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
private theorem radius_checked : aligned last radial 8192 spans gates.toList = true := by decide +kernel

/-- At all 25,600 possible keys the gate retains its physical owner radius.
The other direction is proved by the source-schedule mesh certificate. -/
theorem threshold_bounds (r : Receipt)
    (occ : T.key r.fine (T.group r.sector) r.bucket=some r.key) (e : Active) :
    T.upper r.fine (T.group r.sector) ≤ T.gate r.key e + 2*parentUpperNat e ∧
    ⌈Lookup.ticks * FrozenData.mesh (T.capEdge r.fine).castSucc⌉₊ ≤ T.gate r.key e := by
  obtain ⟨a,ina,lo,hi,rad⟩ := key_owner occ
  have mem : tagged r.fine a ∈ spans := List.mem_flatMap.mpr
    ⟨r.fine,by simp,List.mem_map.mpr ⟨a,ina,rfl⟩⟩
  have sel := find_owner certificate.ownerOrder mem lo hi
  obtain ⟨b,got,valid⟩ := aligned_at last radial radius_checked sel
  have both : (tagged r.fine a).radius ≤ field b 2 ∧ (tagged r.fine a).cap ≤ field b 1 := of_decide_eq_true valid
  have rr : min 2798706 (field a 1) ≤ field b 2 := both.1
  have lower : field b 2-2*parentUpperNat e ≤ T.gate r.key e := by
    rw [(gate_row r.key b got).2 e]
    exact (le_max_right _ _).trans (le_max_right _ _)
  refine ⟨rad.le.trans (rr.trans (show field b 2 ≤ T.gate r.key e + 2*parentUpperNat e by omega)),?_⟩
  rw [cap_eq certificate,(gate_row r.key b got).2 e]
  exact both.2.trans ((le_max_right _ _).trans (le_max_left _ _))

/-- In gate ticks, this is upper native-cell slack plus the dust below e,
evaluated at each retained site. The largest erased index and both endpoints
are treated exactly as every other omission. -/
def slackDust (y : Fin 38 → Band 216) (i : Fin 38) (e : Active) : ℝ :=
  let total := ∑ k,y i k
  let tail := ∑ k ∈ Finset.univ.filter (fun k=>T.tailEdge e≤k),y i k
  Lookup.ticks * ((((Native.cell (y i):ℝ)+1)*Native.step - total) + (total-tail))

theorem failed_slack (y : Fin 38 → Band 216) (r : Receipt) (e : Active)
    (chosen : select T (bits T y)=some r) (bad : bits T y (.high r.key e)=true) :
    ∑ i,slackDust y i e < 2*parentUpper e := by
  obtain ⟨bound,sector⟩ := EarlyFailure.index_data y r chosen
  have radius := StructuralRun.cell_upper r.fine _ r.sector bound sector
  have gate : (T.upper r.fine (T.group r.sector):ℝ) ≤ (T.gate r.key e:ℝ)+2*parentUpper e := by
    rw [parentUpper_nat]
    exact_mod_cast (threshold_bounds r (receipt_data T _ r chosen).2.2 e).1
  have tail : (T.gate r.key e:ℝ) < Lookup.ticks * Lookup.suffix y (T.tailEdge e) := by
    change (if -Lookup.ticks * Lookup.suffix y (T.tailEdge e) < -(T.gate r.key e:ℝ) then true else false)=true at bad
    by_contra! h
    rw [ite_eq_right (by rw [neg_mul,neg_lt_neg_iff]; exact h.not_gt)] at bad
    exact Bool.noConfusion bad
  have id : (∑ i,slackDust y i e) = StructuralGate.upperTick (Native.cellSum y) -
      Lookup.ticks * Lookup.suffix y (T.tailEdge e) := by
    unfold slackDust StructuralGate.upperTick Native.cellSum Lookup.suffix
    simp_rw [sub_add_sub_cancel, mul_sub, Finset.sum_sub_distrib, ←Finset.mul_sum, ←Finset.sum_mul]
    simp only [Finset.sum_add_distrib,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,mul_one,Nat.cast_sum]
    norm_num
  rw [id]
  linarith only [radius,gate,tail]


def lowEvent (v : Full) : Prop :=
  ∃ (i : Fin 39) (e : Active), e.val<14 ∧ 102994≤Native.cellSum v ∧ Native.cell (v i)≤27970 ∧
    ∑ j,slackDust (i.removeNth v) j e < 2*parentUpper e

theorem covers_low (v : Full) (nn : ∀ i k,0≤v i k) (nz : original v≠0) (hit : owner (encode v)=some (.group 0)) : lowEvent v := by
  obtain ⟨e,⟨i,r,chosen,bad,_⟩,group,_⟩ := group_highest _ _ hit
  have support := EarlyFailure.support v nn nz i e r chosen bad
  exact ⟨i,e,(RemovalEdgeBook.low e).mp group,support.1,support.2,failed_slack _ r e chosen bad⟩

private theorem measurable_low : MeasurableSet {v | lowEvent v} := by
  change MeasurableSet {v | ∃ (i : Fin 39) (e : Active), _}
  simp only [Set.setOf_exists]
  apply MeasurableSet.iUnion
  intro i
  apply MeasurableSet.iUnion
  intro e
  by_cases on : e.val<14
  · simp only [on,true_and]
    change MeasurableSet ({v : Full | 102994≤Native.cellSum v} ∩
      ({v : Full | Native.cell (v i)≤27970} ∩ {v : Full | ∑ j,slackDust (i.removeNth v) j e < 2*parentUpper e}))
    have ms : Measurable (fun v : Full=>Native.cellSum v) := by unfold Native.cellSum Native.cell; fun_prop
    have mc : Measurable (fun v : Full=>Native.cell (v i)) := by unfold Native.cell; fun_prop
    apply MeasurableSet.inter (measurableSet_le measurable_const ms)
    apply MeasurableSet.inter (measurableSet_le mc measurable_const)
    apply measurableSet_lt _ measurable_const
    unfold slackDust Native.cell
    change Measurable fun v : Full => ∑ j : Fin 38, Lookup.ticks *
      (((((⌊(∑ k,v (i.succAbove j) k)/Native.step⌋₊:ℕ):ℝ)+1)*Native.step -
          ∑ k,v (i.succAbove j) k) +
        ((∑ k,v (i.succAbove j) k)-∑ k ∈ Finset.univ.filter (fun k=>T.tailEdge e≤k),v (i.succAbove j) k))
    fun_prop
  · simp [on]

theorem mass_low : StructuralRun.layerMass 0 ≤ ∫ v in {v | lowEvent v}, (Restoration.original v)^2 ∂μ := by
  let := bandLaw_finite FrozenData.mesh
  have regular := coded_regular T (fun p=>(originalValue p.1)^2)
  have intSq : Integrable (fun v=> (Restoration.original v)^2) μ :=
    PrimeGap186.integrable_of_measurable_of_bounded_range _ _ regular.1 regular.2.1
  rw [←integral_indicator measurable_low]
  apply integral_mono_of_nonneg (Filter.Eventually.of_forall fun v=>sq_nonneg _) (intSq.indicator measurable_low)
  filter_upwards [StructuralGate.physical_ae (d:=39)] with v phys
  by_cases nonzero : original v=0
  · have eq : Restoration.original v=0 := nonzero
    simp [layer,nonzero,Set.indicator_apply,eq]
  by_cases on : owner (encode v)=some (.group 0)
  · have hit := covers_low v phys.1 nonzero on
    simp only [Set.indicator_of_mem (by exact hit : v∈{w | lowEvent w}),layer,ite_eq_left on]
    rfl
  · rw [show layer (.group 0) v=0 from ite_eq_right on]
    by_cases hit : v∈{w | lowEvent w}
    · rw [Set.indicator_of_mem hit,zero_pow (by decide)]; exact sq_nonneg _
    · simp [Set.indicator_of_notMem hit]

#print axioms mass_low

#print axioms threshold_bounds
#print axioms failed_slack
end PrimeGap180.RemovedLowProjection
