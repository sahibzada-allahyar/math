import TrialRetainedTriple180
import TrialSiftedIndices180
import TrialOrderedFactors180
import TrialSiftedRoughSupport180
import TrialNoncentralPhysical180

/-! Literal multiplicity of the retained convolution on squarefree
integers. The small interval is closed and the two large intervals open. -/
noncomputable section
open scoped BigOperators Classical
open PrimeGap186 PrimeGap182Audit PrimeGap180.Distribution
namespace PrimeGap180.Retained

theorem factors_of_product {k N : ℕ} (p : Fin k → ℕ) (prime : ∀ i, (p i).Prime)
    (prod : ∏ i, p i = N) : N.primeFactors = Finset.univ.image p := by
  have nz : N ≠ 0 := prod ▸ Finset.prod_ne_zero_iff.mpr (fun i _ => (prime i).ne_zero)
  ext q
  by_cases pq : q.Prime
  · have mem : q ∈ N.primeFactors ↔ q ∣ N :=
      ⟨fun h => (Nat.mem_primeFactors.mp h).2.1,fun h => Nat.mem_primeFactors.mpr ⟨pq,h,nz⟩⟩
    simp only [mem,Finset.mem_image,Finset.mem_univ,true_and]
    rw [← prod,pq.prime.dvd_finsetProd_iff]
    simp only [Finset.mem_univ,true_and]
    exact exists_congr fun i => (Nat.prime_dvd_prime_iff_eq pq (prime i)).trans eq_comm
  · simp only [Nat.mem_primeFactors,pq,false_and,Finset.mem_image,Finset.mem_univ,true_and,false_iff]
    rintro ⟨i,rfl⟩
    exact pq (prime i)

private theorem sq_injective {k N : ℕ} (sq : Squarefree N) (p : Fin k → ℕ)
    (prime : ∀ i, (p i).Prime) (prod : ∏ i, p i = N) : Function.Injective p := by
  apply List.nodup_ofFn.mp
  have perm := Nat.primeFactorsList_unique ((Fin.prod_ofFn p).trans prod)
    (fun n hn => by obtain ⟨i,rfl⟩ := List.mem_ofFn.mp hn; exact prime i)
  exact perm.nodup_iff.mpr ((Nat.squarefree_iff_nodup_primeFactorsList sq.ne_zero).mp sq)

private theorem ordered_factors {k N : ℕ} (sq : Squarefree N) (card : N.primeFactors.card = k) :
    ∃ p : Fin k → ℕ, StrictMono p ∧ (∀ i, (p i).Prime) ∧ ∏ i, p i = N := by
  let p := N.primeFactors.orderEmbOfFin card
  refine ⟨p,p.strictMono,fun i => Nat.prime_of_mem_primeFactors (Finset.orderEmbOfFin_mem _ _ i),?_⟩
  calc
    ∏ i, p i = ∏ q ∈ Finset.univ.image p, q :=
      (Finset.prod_image (f := id) p.injective.injOn).symm
    _ = N := by rw [Finset.image_orderEmbOfFin_univ,Nat.prod_primeFactors_of_squarefree sq]

/-- Recognition of the literal strict three-prime event directly on the
prime-divisor set of a squarefree integer. -/
theorem three_iff_factors {N : ℕ} (sq : Squarefree N) (L U : ℝ) :
    Literal.Three L U N ↔ N.primeFactors.card = 3 ∧
      ∀ q ∈ N.primeFactors, L < (q:ℝ) ∧ (q:ℝ) < U := by
  constructor
  · rintro ⟨r,s,t,hr,hs,ht,hrs,hst,prod,lo,hi⟩
    let p : Fin 3 → ℕ := ![r,s,t]
    have pr (i : Fin 3) : (p i).Prime := by fin_cases i <;> assumption
    have inc : StrictMono p := Fin.strictMono_iff_lt_succ.mpr
      (by intro i; fin_cases i <;> assumption)
    have fac := factors_of_product p pr (show ∏ i,p i = N by
      simpa [p,Fin.prod_univ_succ,mul_assoc] using prod.symm)
    rw [fac,Finset.card_image_of_injective _ inc.injective]
    refine ⟨by simp,?_⟩
    intro q h
    obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp h
    have low : p 0 ≤ p i := inc.monotone (Fin.zero_le _)
    have high : p i ≤ p 2 := inc.monotone (Fin.le_last _)
    exact ⟨lo.trans_le (Nat.cast_le.mpr low), (Nat.cast_le.mpr high).trans_lt hi⟩
  · rintro ⟨card,all⟩
    obtain ⟨p,inc,pr,prod⟩ := ordered_factors sq card
    rw [factors_of_product p pr prod] at all
    have band (i : Fin 3) := all _ (Finset.mem_image_of_mem p (Finset.mem_univ i))
    exact ⟨p 0,p 1,p 2,pr _,pr _,pr _,inc (by decide),inc (by decide),
      by simpa [Fin.prod_univ_succ,mul_assoc] using prod.symm,(band 0).1,(band 2).2⟩

private def choices (x ζ c a : ℝ) (N : ℕ) : Finset (Fin 3 → ℕ) :=
  (Fintype.piFinset fun i => primesIn (tripleLower x ζ c i) (tripleUpper x c a i)).filter
    (fun p : Fin 3 → ℕ => ∏ i, p i = N)

private theorem mem_choices {x ζ c a : ℝ} (hx : 0 < x) {N : ℕ} (p : Fin 3 → ℕ) :
    p ∈ choices x ζ c a N ↔ (∀ i, (p i).Prime) ∧ (∏ i, p i) = N ∧
      (x^ζ ≤ (p 0:ℝ) ∧ (p 0:ℝ) ≤ x^c) ∧
      (x^c < (p 1:ℝ) ∧ (p 1:ℝ) < x^a) ∧ (x^c < (p 2:ℝ) ∧ (p 2:ℝ) < x^a) := by
  simp only [choices,Finset.mem_filter,Fintype.mem_piFinset,triple_prime_ranges hx,Fin.forall_fin_succ]
  simp
  tauto

private theorem retained_card {N : ℕ} {x : ℝ} (win : N ∈ window x) (ζ c a : ℝ) :
    retainedTriple x ζ c a N = ((choices x ζ c a N).card : ℂ) := by
  classical
  simp [retainedTriple,win,choices,Finsupp.finsetSum_apply,
    Finsupp.single_apply,Finset.sum_boole]


private theorem two_choices {N : ℕ} (sq : Squarefree N) {x ζ c a : ℝ} (hx : 0 < x)
    (hit : (choices x ζ c a N).Nonempty) : (choices x ζ c a N).card = 2 := by
  classical
  obtain ⟨p,hp⟩ := hit
  obtain ⟨pr,prod,sm,big1,big2⟩ := (mem_choices hx p).mp hp
  let r : Fin 3 → ℕ := ![p 0,p 2,p 1]
  have rp : ∀ i, (r i).Prime := by intro i; fin_cases i <;> apply pr
  have rpProd : ∏ i, r i = N := by
    rw [← prod]
    simp only [Fin.prod_univ_succ,Fin.prod_univ_zero,mul_one]
    change p 0 * (p 2 * p 1) = p 0 * (p 1 * p 2)
    rw [mul_comm (p 2) (p 1)]
  have hr := (mem_choices hx r).mpr ⟨rp,rpProd,sm,big2,big1⟩
  have pinj := sq_injective sq p pr prod
  have ne : p ≠ r := fun e => (by decide : (1:Fin 3) ≠ 2) (pinj (congrFun e 1))
  suffices eq : choices x ζ c a N = {p,r} by simp [eq,ne]
  ext t
  constructor
  · intro ht
    obtain ⟨pt,tprod,st,bt1,bt2⟩ := (mem_choices hx t).mp ht
    have tinj := sq_injective sq t pt tprod
    have neq : t 1 ≠ t 2 := fun e => (by decide : (1:Fin 3) ≠ 2) (tinj e)
    have cover (i : Fin 3) : t i = p 0 ∨ t i = p 1 ∨ t i = p 2 := by
      have h := Finset.mem_image_of_mem t (Finset.mem_univ i)
      rw [← factors_of_product t pt tprod,factors_of_product p pr prod] at h
      simpa [Fin.exists_fin_succ,eq_comm] using h
    have zero : t 0 = p 0 := by
      rcases cover 0 with h|h|h
      · exact h
      · exact False.elim (big1.1.not_ge (h ▸ st.2))
      · exact False.elim (big2.1.not_ge (h ▸ st.2))
    have first : t 1 = p 1 ∨ t 1 = p 2 := (cover 1).resolve_left
      (fun e => bt1.1.not_ge (e.symm ▸ sm.2))
    have second : t 2 = p 1 ∨ t 2 = p 2 := (cover 2).resolve_left
      (fun e => bt2.1.not_ge (e.symm ▸ sm.2))
    simp only [Finset.mem_insert,Finset.mem_singleton]
    rcases first with h|h
    · left
      have h2 := second.resolve_left (fun v => neq (h.trans v.symm))
      funext i; fin_cases i <;> assumption
    · right
      have h2 := second.resolve_right (fun v => neq (h.trans v.symm))
      funext i; fin_cases i <;> assumption
  · intro h
    rcases Finset.mem_insert.mp h with rfl | h
    · exact hp
    · exact Finset.mem_singleton.mp h ▸ hr

/-- Three distinct prime divisors, all in the half-open interval [Z,U).
On a squarefree integer these are exactly its three prime factors. -/
def broadTriple (N : ℕ) (Z U : ℝ) : Prop := N.primeFactors.card = 3 ∧
  ∀ q ∈ N.primeFactors, Z ≤ (q:ℝ) ∧ (q:ℝ) < U

private theorem choices_iff {N : ℕ} (sq : Squarefree N) {x ζ c a : ℝ}
    (hx : 1 < x) (zc : ζ ≤ c) (ca : c < a) (room : 2*c+a ≤ 1) (low : x ≤ (N:ℝ)) :
    (choices x ζ c a N).Nonempty ↔ broadTriple N (x^ζ) (x^a) ∧ ¬Literal.Three (x^c) (x^a) N := by
  classical
  have xp := zero_lt_one.trans hx
  have z_le_c := Real.rpow_le_rpow_of_exponent_le hx.le zc
  have c_lt_a := Real.rpow_lt_rpow_of_exponent_lt hx ca
  rw [three_iff_factors sq]
  constructor
  · rintro ⟨p,hp⟩
    obtain ⟨pr,prod,sm,b1,b2⟩ := (mem_choices xp p).mp hp
    have fac := factors_of_product p pr prod
    have inj := sq_injective sq p pr prod
    have card : N.primeFactors.card = 3 := by simp [fac,Finset.card_image_of_injective _ inj]
    refine ⟨⟨card,?_⟩,?_⟩
    · rw [fac]
      intro q h
      obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp h
      fin_cases i
      · exact ⟨sm.1,sm.2.trans_lt c_lt_a⟩
      · exact ⟨z_le_c.trans b1.1.le,b1.2⟩
      · exact ⟨z_le_c.trans b2.1.le,b2.2⟩
    · rintro ⟨_,strict⟩
      rw [fac] at strict
      exact sm.2.not_gt (strict _ (Finset.mem_image_of_mem p (Finset.mem_univ 0))).1
  · rintro ⟨⟨card,all⟩,no⟩
    obtain ⟨p,inc,pr,prod⟩ := ordered_factors sq card
    rw [factors_of_product p pr prod] at all
    have band (i : Fin 3) := all _ (Finset.mem_image_of_mem p (Finset.mem_univ i))
    have first : (p 0:ℝ) ≤ x^c := by
      by_contra! bigger
      apply no
      refine ⟨card,?_⟩
      rw [factors_of_product p pr prod]
      intro q h
      obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp h
      exact ⟨bigger.trans_le (Nat.cast_le.mpr (inc.monotone (Fin.zero_le i))), (band i).2⟩
    have second : x^c < (p 1:ℝ) := by
      by_contra! le
      have bound : (p 0:ℝ)*(p 1:ℝ)*(p 2:ℝ) < x^c*x^c*x^a := by
        apply lt_of_le_of_lt (mul_le_mul_of_nonneg_right (mul_le_mul first le
          (Nat.cast_nonneg _) (Real.rpow_pos_of_pos xp _).le) (Nat.cast_nonneg _))
        exact mul_lt_mul_of_pos_left (band 2).2 (mul_pos (Real.rpow_pos_of_pos xp _)
          (Real.rpow_pos_of_pos xp _))
      rw [← Real.rpow_add xp,← Real.rpow_add xp] at bound
      have upper := Real.rpow_le_rpow_of_exponent_le hx.le (show c+c+a ≤ 1 by linarith)
      rw [Real.rpow_one] at upper
      have eq : (p 0:ℝ)*(p 1:ℝ)*(p 2:ℝ) = N := by
        exact_mod_cast (show p 0 * p 1 * p 2 = N by simpa [Fin.prod_univ_succ,mul_assoc] using prod)
      exact low.not_gt (eq ▸ bound.trans_le upper)
    exact ⟨p,(mem_choices xp p).mpr ⟨pr,prod,⟨(band 0).1,first⟩,
      ⟨second,(band 1).2⟩,⟨second.trans (Nat.cast_lt.mpr (inc (by decide : (1:Fin 3) < 2))),(band 2).2⟩⟩⟩

/-- Exact coefficient of the actual finite convolution on each squarefree
integer of the trial window. Equality at the lower broad cutoff is allowed,
and equality at the intermediate cutoff belongs to the small factor. -/
theorem retained_triple_on_squarefree {N : ℕ} (sq : Squarefree N) {x ζ c a : ℝ}
    (hx : 1 < x) (zc : ζ ≤ c) (ca : c < a) (room : 2*c+a ≤ 1) (win : N ∈ window x) :
    retainedTriple x ζ c a N =
      (if broadTriple N (x^ζ) (x^a) then (2:ℂ) else 0) - (if Literal.Three (x^c) (x^a) N then 2 else 0) := by
  classical
  rw [retained_card win]
  have equiv := choices_iff sq hx zc ca room (Nat.ceil_le.mp (Finset.mem_Icc.mp win).1)
  have sub (h : Literal.Three (x^c) (x^a) N) : broadTriple N (x^ζ) (x^a) := by
    obtain ⟨card,all⟩ := (three_iff_factors sq _ _).mp h
    exact ⟨card,fun q hq => ⟨(Real.rpow_le_rpow_of_exponent_le hx.le zc).trans
      (all q hq).1.le,(all q hq).2⟩⟩
  change _ = (if broadTriple N (x^ζ) (x^a) then (2:ℂ) else 0) - (if Literal.Three (x^c) (x^a) N then 2 else 0)
  by_cases hit : broadTriple N (x^ζ) (x^a) ∧ ¬Literal.Three (x^c) (x^a) N
  · simp [two_choices sq (zero_lt_one.trans hx) (equiv.mpr hit), hit.1,hit.2]
  · have empty := Finset.not_nonempty_iff_eq_empty.mp (mt equiv.mp hit)
    by_cases h : Literal.Three (x^c) (x^a) N
    · simp [empty,h,sub h]
    · simp [empty,h,show ¬broadTriple N (x^ζ) (x^a) from fun b => hit ⟨b,h⟩]

#print axioms retained_triple_on_squarefree


/-- The largest pair of an increasing five-prime factorization controls
all pairs, with the same strict product cutoff. -/
theorem five_iff_factors {N : ℕ} (sq : Squarefree N) (U : ℝ) :
    Literal.Five U N ↔ N.primeFactors.card = 5 ∧
      ∀ q ∈ N.primeFactors, ∀ r ∈ N.primeFactors, q < r → (q:ℝ)*r < U := by
  constructor
  · rintro ⟨v,w,y,z,t,hv,hw,hy,hz,ht,vw,wy,yz,zt,prod,last⟩
    let p : Fin 5 → ℕ := ![v,w,y,z,t]
    have pr (i : Fin 5) : (p i).Prime := by fin_cases i <;> assumption
    have inc : StrictMono p := Fin.strictMono_iff_lt_succ.mpr
      (by intro i; fin_cases i <;> assumption)
    rw [factors_of_product p pr (show ∏ i, p i = N by
      simpa [p,Fin.prod_univ_succ,mul_assoc] using prod.symm),Finset.card_image_of_injective _ inc.injective]
    refine ⟨by simp,?_⟩
    intro q hq r hr qr
    obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp hq
    obtain ⟨l,_,rfl⟩ := Finset.mem_image.mp hr
    have il := inc.lt_iff_lt.mp qr
    have ile : i ≤ (3:Fin 5) := by omega
    have lle : l ≤ (4:Fin 5) := Fin.le_last l
    exact (mul_le_mul (Nat.cast_le.mpr (inc.monotone ile)) (Nat.cast_le.mpr (inc.monotone lle))
      (Nat.cast_nonneg _) (Nat.cast_nonneg _)).trans_lt last
  · rintro ⟨card,all⟩
    obtain ⟨p,inc,pr,prod⟩ := ordered_factors sq card
    rw [factors_of_product p pr prod] at all
    have mem (i : Fin 5) := Finset.mem_image_of_mem p (Finset.mem_univ i)
    exact ⟨p 0,p 1,p 2,p 3,p 4,pr _,pr _,pr _,pr _,pr _,inc (by decide),inc (by decide),
      inc (by decide),inc (by decide),by simpa [Fin.prod_univ_succ,mul_assoc] using prod.symm,
      all _ (mem 3) _ (mem 4) (inc (by decide))⟩

/-- Exact arithmetic assembly for every squarefree rough composite in the
dyadic window. The term R is the same weight used in the central distribution
theorem. The remaining seven terms are the actual six families and retained
integer convolution, evaluated on N. -/
theorem higher_on_squarefree_composite {N k : ℕ} {a s c x : ℝ}
    (hx : 1 < x) (zc : 1-s-a ≤ c) (ca : c < a) (room : 2*c+a ≤ 1)
    (sq : Squarefree N) (comp : ¬N.Prime) (win : N ∈ window x)
    (rough : ∀ q ∈ N.primeFactors, x^(1-2*a) ≤ (q:ℝ)) (p : Fin k → ℕ)
    (inc : StrictMono p) (prime : ∀ i, (p i).Prime) (prod : ∏ i, p i = N) :
    let T := fun j : Fin 6 => (Sifted.theta ⟨a,1-a,s,1-2*a⟩ x j (fun _ => 1) N : ℂ)
    (Literal.value (.higher (x^a) (x^c)) N : ℂ) =
      T 0-T 1+T 2+T 3-T 4-T 5 + (Central.residualWeight (Central.trueKeys x a (1-s-a) p) : ℂ)
        + retainedTriple x (1-s-a) c a N := by
  classical
  intro T
  let u := fun i => Real.logb x (p i:ℝ)
  have pos (i) : 0 < (p i:ℝ) := by exact_mod_cast (prime i).pos
  have fac := factors_of_product p prime prod
  have card : N.primeFactors.card = k := by simp [fac,Finset.card_image_of_injective _ inc.injective]
  have pair (i l) : u i + u l < a ↔ (p i:ℝ)*p l < x^a := by
    rw [← Real.logb_mul (pos i).ne' (pos l).ne']
    exact Real.logb_lt_iff_lt_rpow hx (mul_pos (pos i) (pos l))
  have five : (k=5 ∧ ∀ i l, i < l → u i+u l<a) ↔ Literal.Five (x^a) N := by
    rw [five_iff_factors sq,card,fac]
    simp [pair,inc.lt_iff_lt]
  have three : (k=3 ∧ ∀ i, 1-s-a ≤ u i ∧ u i < a) ↔ broadTriple N (x^(1-s-a)) (x^a) := by
    simp [broadTriple,fac,Finset.card_image_of_injective _ inc.injective,u,Real.le_logb_iff_rpow_le hx,Real.logb_lt_iff_lt_rpow hx,pos]
  have rem := Sifted.residual_on_factorization a s x hx (zc.trans ca.le) p inc prime sq prod win rough
  change (Central.residualWeight (Central.trueKeys x a (1-s-a) p) : ℝ) =
    -(if k=5 ∧ ∀ i l, i<l → u i+u l<a then 24 else 0) -
    (if k=3 ∧ ∀ i, 1-s-a ≤ u i ∧ u i<a then 2 else 0) - _ at rem
  simp only [five,three] at rem
  have ret := retained_triple_on_squarefree sq hx zc ca room win
  change _ = (if broadTriple N (x^(1-s-a)) (x^a) then (2:ℂ) else 0) - (if Literal.Three (x^c) (x^a) N then 2 else 0) at ret
  have rc := congrArg (fun v : ℝ => (v:ℂ)) rem
  push_cast at rc
  rw [ret]
  simp only [Literal.value,comp,ite_false,zero_sub]
  dsimp only [T]
  split_ifs at * <;> push_cast at * <;> linear_combination -rc

#print axioms higher_on_squarefree_composite


/-- On a prime in the dyadic window only the empty sieve label contributes.
This is the reason the central remainder is applied only to composites. -/
private theorem higher_on_prime {N : ℕ} {a s c x : ℝ} (hx : 1 < x)
    (zc : 1-s-a ≤ c) (ca : c < a) (ha : a < 1) (room : 2*c+a ≤ 1) (pr : N.Prime)
    (win : N ∈ window x) (rough : ∀ q ∈ N.primeFactors, x^(1-2*a) ≤ (q:ℝ)) :
    let T := fun j : Fin 6 => (Sifted.theta ⟨a,1-a,s,1-2*a⟩ x j (fun _ => 1) N : ℂ)
    (Literal.value (.higher (x^a) (x^c)) N : ℂ) =
      T 0-T 1+T 2+T 3-T 4-T 5 + retainedTriple x (1-s-a) c a N := by
  classical
  intro T
  let p : Fin 1 → ℕ := fun _ => N
  have inc : StrictMono p := by intro i l il; have eq := Subsingleton.elim i l; exact (il.ne eq).elim
  have only (q : ℕ) (hq : q.Prime) : q ∣ N ↔ ∃ i, p i = q := by
    rw [Nat.prime_dvd_prime_iff_eq hq pr]
    simp [p,eq_comm]
  have all (j) := Sifted.theta_index_counts ⟨a,1-a,s,1-2*a⟩ x hx p inc (fun _ => pr)
    pr.squarefree only rough (zc.trans ca.le) j
  have loglo : 1 ≤ Real.logb x (N:ℝ) := (Real.le_logb_iff_rpow_le hx (Nat.cast_pos.mpr pr.pos)).mpr
    (by simpa using Nat.ceil_le.mp (Finset.mem_Icc.mp win).1)
  have notSmall : ¬ Real.logb x (N:ℝ) < a := (ha.le.trans loglo).not_gt
  have card : N.primeFactors.card = 1 := by simp [pr.primeFactors]
  have five : ¬Literal.Five (x^a) N := by rw [five_iff_factors pr.squarefree,card]; simp
  have three : ¬Literal.Three (x^c) (x^a) N := by rw [three_iff_factors pr.squarefree,card]; simp
  rw [retained_triple_on_squarefree pr.squarefree hx zc ca room win]
  simp [Literal.value,pr,five,three,broadTriple,T,all,Sifted.indexCounts,p,notSmall]

/-- Exact decomposition of the higher-row minorant on every squarefree
rough integer in the dyadic window, including primes. Its central argument
is the canonical increasing enumeration of the prime divisors. -/
theorem higher_on_squarefree {N : ℕ} {a s c x : ℝ} (hx : 1 < x)
    (zc : 1-s-a ≤ c) (ca : c < a) (ha : a < 1) (room : 2*c+a ≤ 1)
    (sq : Squarefree N) (win : N ∈ window x)
    (rough : ∀ q ∈ N.primeFactors, x^(1-2*a) ≤ (q:ℝ)) :
    let p := N.primeFactors.orderEmbOfFin rfl
    let T := fun j : Fin 6 => (Sifted.theta ⟨a,1-a,s,1-2*a⟩ x j (fun _ => 1) N : ℂ)
    (Literal.value (.higher (x^a) (x^c)) N : ℂ) =
      T 0-T 1+T 2+T 3-T 4-T 5 + (if N.Prime then 0 else
        (Central.residualWeight (Central.trueKeys x a (1-s-a) p) : ℂ))
        + retainedTriple x (1-s-a) c a N := by
  classical
  intro p T
  by_cases prime : N.Prime
  · simpa only [prime,ite_true,add_zero] using
      (higher_on_prime hx zc ca ha room prime win rough)
  rw [ite_eq_right prime]
  have prod : ∏ i, p i = N := by
    calc
      ∏ i, p i = ∏ q ∈ Finset.univ.image p, q :=
        (Finset.prod_image (f := id) p.injective.injOn).symm
      _ = N := by rw [Finset.image_orderEmbOfFin_univ,Nat.prod_primeFactors_of_squarefree sq]
  exact higher_on_squarefree_composite hx zc ca room sq prime win rough p p.strictMono
    (fun i => Nat.prime_of_mem_primeFactors (Finset.orderEmbOfFin_mem _ _ i)) prod

#print axioms higher_on_squarefree


/-- The unsifted three-prime product has the same divisor bound on repeated
factors. Every prime divisor of a contributing integer lies above x^ζ. -/
theorem retained_size_and_support {N : ℕ} (nz : N ≠ 0) {x ζ c a : ℝ} (hx : 1 < x) (zc : ζ ≤ c) :
    ‖retainedTriple x ζ c a N‖ ≤ (N.divisors.card:ℝ)^3 ∧
    (retainedTriple x ζ c a N ≠ 0 → ∀ q ∈ N.primeFactors, x^ζ ≤ (q:ℝ)) := by
  classical
  by_cases win : N ∈ window x
  · rw [retained_card win]
    have xp := zero_lt_one.trans hx
    have lo := Real.rpow_le_rpow_of_exponent_le hx.le zc
    let B := Fintype.piFinset (fun _ : Fin 3 => N.divisors)
    have sub : choices x ζ c a N ⊆ B := by
      intro t ht
      obtain ⟨_,prod,_⟩ := (mem_choices xp t).mp ht
      exact Fintype.mem_piFinset.mpr fun i => Nat.mem_divisors.mpr
        ⟨prod ▸ Finset.dvd_prod_of_mem t (Finset.mem_univ i),nz⟩
    have bound := Finset.card_le_card sub
    have size : B.card = N.divisors.card^3 := by simp [B,Fintype.card_piFinset]
    refine ⟨?_,?_⟩
    · simpa using (Nat.cast_le.mpr (bound.trans_eq size) :
        ((choices x ζ c a N).card:ℝ) ≤ (N.divisors.card^3:ℕ))
    · intro ne q hq
      have hit : (choices x ζ c a N).Nonempty := Finset.card_pos.mp (Nat.pos_of_ne_zero
        fun e => ne (by rw [e,Nat.cast_zero]))
      obtain ⟨p,hp⟩ := hit
      obtain ⟨pr,prod,sm,b1,b2⟩ := (mem_choices xp p).mp hp
      rw [factors_of_product p pr prod] at hq
      obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp hq
      fin_cases i
      · exact sm.1
      · exact lo.trans b1.1.le
      · exact lo.trans b2.1.le
  · simp [retainedTriple,win]

theorem retained_repeated_distribution (J j : ℕ) {a ζ c A θ δ : ℝ} (hA : 0 < A)
    (level : θ ≤ 54/100) (cut : a ≤ 5/12) (rz : 1-2*a ≤ ζ) (zc : ζ ≤ c) :
    ∃ K : ℝ, 0 < K ∧ ∀ᶠ x : ℝ in Filter.atTop, ∀ (I S : Finset ℕ) (b : ℕ),
      (∀ p ∈ I, p.Prime) → b.Coprime (∏ p ∈ I, p) → S ⊆ dense j θ δ x I →
      ∑ q ∈ S, (q.divisors.card:ℝ)^J * ‖fullDiscrepancy (∑ n ∈ window x, Finsupp.single n
        (if Squarefree n then 0 else retainedTriple x ζ c a n)) q b‖ ≤ K*x/(Real.log x)^A := by
  classical
  obtain ⟨K,hK,raw⟩ := Collisions.dense_rough_collisions 3 J j A θ δ a hA level cut
  refine ⟨K,hK,?_⟩
  filter_upwards [raw,Filter.eventually_gt_atTop (1:ℝ)] with x raw hx
  intro I S b primes cop sub
  let e (n : ℕ) := if n ∈ window x ∧ ¬Squarefree n then retainedTriple x ζ c a n else 0
  have info (n : ℕ) (hn : n ∈ Finset.Icc 1 ⌊2*x⌋₊) :=
    retained_size_and_support (a := a) (Nat.ne_of_gt (Finset.mem_Icc.mp hn).1) hx zc
  have size (n : ℕ) (hn : n ∈ Finset.Icc 1 ⌊2*x⌋₊) : ‖e n‖ ≤ (n.divisors.card:ℝ)^3 := by
    simp only [e]; split
    · exact (info n hn).1
    · simp
  have support (n : ℕ) (hn : n ∈ Finset.Icc 1 ⌊2*x⌋₊) (ne : e n ≠ 0) :
      ¬Squarefree n ∧ ∀ q : ℕ, q.Prime → q ∣ n → x^(1-2*a) ≤ (q:ℝ) := by
    by_cases hit : n ∈ window x ∧ ¬Squarefree n
    · refine ⟨hit.2,fun q pq dq => (Real.rpow_le_rpow_of_exponent_le hx.le rz).trans
        ((info n hn).2 (by simpa [e,hit] using ne) q
          (Nat.mem_primeFactors.mpr ⟨pq,dq,Nat.ne_of_gt (Finset.mem_Icc.mp hn).1⟩))⟩
    · exact (ne (by simp [e,hit])).elim
  have eq : (∑ n ∈ Finset.Icc 1 ⌊2*x⌋₊, Finsupp.single n (e n)) =
      ∑ n ∈ window x, Finsupp.single n (if Squarefree n then 0 else retainedTriple x ζ c a n) := by
    ext n
    have cover (h : n ∈ window x) : n ∈ Finset.Icc 1 ⌊2*x⌋₊ :=
      Finset.mem_Icc.mpr ⟨(Nat.ceil_pos.mpr (zero_lt_one.trans hx)).trans_le (Finset.mem_Icc.mp h).1,
        (Finset.mem_Icc.mp h).2⟩
    by_cases hw : n ∈ window x
    · simp [Finsupp.finsetSum_apply,Finsupp.single_apply,Finset.sum_ite_eq',e,hw,cover hw,ite_not]
    · simp [Finsupp.finsetSum_apply,Finsupp.single_apply,Finset.sum_ite_eq',e,hw]
  simpa only [eq] using raw I S b e primes cop sub size support

#print axioms retained_repeated_distribution


theorem ordered_squarefree {k N : ℕ} (p : Fin k → ℕ) (inc : StrictMono p)
    (prime : ∀ i, (p i).Prime) (prod : ∏ i, p i = N) : Squarefree N := by
  have nz : N ≠ 0 := prod ▸ Finset.prod_ne_zero_iff.mpr (fun i _ => (prime i).ne_zero)
  apply (Nat.squarefree_iff_nodup_primeFactorsList nz).mpr
  have perm := Nat.primeFactorsList_unique ((Fin.prod_ofFn p).trans prod)
    (fun q hq => by obtain ⟨i,rfl⟩ := List.mem_ofFn.mp hq; exact prime i)
  exact perm.nodup_iff.mp (List.nodup_ofFn.mpr inc.injective)

private theorem zero_on_repeats {N : ℕ} (ns : ¬Squarefree N) (U L : ℝ) :
    Literal.value (.higher U L) N = 0 := by
  have five : ¬Literal.Five U N := by
    rintro ⟨r,s,t,v,w,pr,ps,pt,pv,pw,rs,st,tv,vw,prod,_⟩
    let p : Fin 5 → ℕ := ![r,s,t,v,w]
    refine ns (ordered_squarefree p ?_ ?_ ?_)
    · apply Fin.strictMono_iff_lt_succ.mpr
      intro i; fin_cases i <;> assumption
    · intro i; fin_cases i <;> assumption
    · simpa [p,Fin.prod_univ_succ,mul_assoc] using prod.symm
  have three : ¬Literal.Three L U N := by
    rintro ⟨r,s,t,pr,ps,pt,rs,st,prod,_,_⟩
    let p : Fin 3 → ℕ := ![r,s,t]
    refine ns (ordered_squarefree p ?_ ?_ ?_)
    · apply Fin.strictMono_iff_lt_succ.mpr
      intro i; fin_cases i <;> assumption
    · intro i; fin_cases i <;> assumption
    · simpa [p,Fin.prod_univ_succ,mul_assoc] using prod.symm
  simp [Literal.value,five,three,show ¬N.Prime from fun h => ns h.squarefree]

/-- Full pointwise identity for every integer in the dyadic window.
Only a squarefree composite contributes to the central term. The other
seven sequences can all be restricted to squarefree integers. -/
theorem higher_window_identity {N : ℕ} {a s c x : ℝ} (hx : 1 < x) (ha : 0 < a) (au : a < 1)
    (rz : 1-2*a ≤ 1-s-a) (zc : 1-s-a ≤ c) (ca : c < a)
    (room : 2*c+a ≤ 1) (win : N ∈ window x) :
    let p := N.primeFactors.orderEmbOfFin rfl
    let T := fun j : Fin 6 => (Sifted.theta ⟨a,1-a,s,1-2*a⟩ x j (fun _ => 1) N : ℂ)
    (Literal.value (.higher (x^a) (x^c)) N : ℂ) =
      if Squarefree N then T 0-T 1+T 2+T 3-T 4-T 5 + (if N.Prime then 0 else
        (Central.residualWeight (Central.trueKeys x a (1-s-a) p) : ℂ))
        + retainedTriple x (1-s-a) c a N else 0 := by
  classical
  intro p T
  by_cases sq : Squarefree N
  · rw [ite_eq_left sq]
    by_cases rough : ∀ q ∈ N.primeFactors, x^(1-2*a) ≤ (q:ℝ)
    · exact higher_on_squarefree hx zc ca au room sq win rough
    push Not at rough
    obtain ⟨q,hq,small⟩ := rough
    have ⟨pq,dq,nz⟩ := Nat.mem_primeFactors.mp hq
    have low := Nat.ceil_le.mp (Finset.mem_Icc.mp win).1
    have xp := zero_lt_one.trans hx
    have R := Real.rpow_le_rpow_of_exponent_le hx.le rz
    have C := Real.rpow_le_rpow_of_exponent_le hx.le zc
    have notprime : ¬N.Prime := by
      intro h
      have eq := (Nat.prime_dvd_prime_iff_eq pq h).mp dq
      have below := Real.rpow_lt_rpow_of_exponent_lt hx (show 1-2*a < 1 by linarith)
      rw [Real.rpow_one] at below
      exact low.not_gt (eq ▸ small.trans below)
    have notfive : ¬Literal.Five (x^a) N := by
      intro h
      have cap : (q:ℝ)*(x^a)^2 < x := by
        calc
          _ < x^(1-2*a)*(x^a)^2 := mul_lt_mul_of_pos_right small (sq_pos_of_pos (Real.rpow_pos_of_pos xp _))
          _ = x := by rw [pow_two,← Real.rpow_add xp,← Real.rpow_add xp, show 1-2*a+(a+a)=1 by ring,Real.rpow_one]
      exact (lt_irrefl (q:ℝ)) (Literal.five_rough (Nat.cast_nonneg q) cap low h pq dq)
    have notthree : ¬Literal.Three (x^c) (x^a) N := by
      intro h
      exact (small.trans_le (R.trans C)).not_ge ((three_iff_factors sq _ _).mp h |>.2 q hq).1.le
    have theta0 (j) : T j = 0 := by
      dsimp [T]
      exact_mod_cast Sifted.theta_zero_of_small_prime ⟨a,1-a,s,1-2*a⟩ x hx j _ N q pq dq small
    have retained0 : retainedTriple x (1-s-a) c a N = 0 := by
      by_contra ne
      exact (small.trans_le R).not_ge ((retained_size_and_support nz hx zc).2 ne q hq)
    have central0 : Central.residualWeight (Central.trueKeys x a (1-s-a) p) = 0 := by
      by_contra ne
      have good := (Central.closed_and_ordered hx (p := (p : Fin N.primeFactors.card → ℕ))
        (fun i => Nat.cast_pos.mpr (Nat.prime_of_mem_primeFactors
          (N.primeFactors.orderEmbOfFin_mem rfl i)).pos) ne).2.1
      have mem : q ∈ Finset.univ.image p := by simpa [p] using hq
      obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp mem
      exact small.not_ge (good i)
    simp [Literal.value,notprime,notfive,notthree,theta0,retained0,central0]
  · simp [sq,zero_on_repeats sq]

#print axioms higher_window_identity

end PrimeGap180.Retained
