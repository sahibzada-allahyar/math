import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G060
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 60

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G060

namespace PrimeGap180.PriceIsolatedGroup.G065
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 65

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G065

namespace PrimeGap180.PriceIsolatedGroup.G070
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 70

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G070

namespace PrimeGap180.PriceIsolatedGroup.G075
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 75

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G075
