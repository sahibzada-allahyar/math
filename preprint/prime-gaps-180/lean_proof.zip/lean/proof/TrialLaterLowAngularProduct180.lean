import TrialLaterLowAngularEnvelope180
import TrialLaterLowAngularOneSite180
import TrialFrozenChannels180
import TrialLowMassReceiver180

/-! Fubini expansion of the actual physical angular square for every possible erased site. -/
noncomputable section
open MeasureTheory Set Filter PrimeGap180.Sector PrimeGap180.FrozenProfile
open scoped Classical BigOperators NNReal
namespace PrimeGap180.LowAngularProduct
open FrozenChannels (Term Assignment)
open LowAngularBernstein (caps)
open LowAngularPhysical (bound endpoint core)
open EnvelopeAngular (expAt)
open GateDeletion (T Full)
open LaterLowProduct (ν μ weight totalCap)
open NativeSiteLaw (radial tail)
open LowWeightedQuadrature (shifted)
open private powers from TrialFrozenChannels180
open private rate tilted from TrialLaterLowProduct180
open private row_scale from TrialJointEdgeLowRows180
open private bands_nonneg one_nonneg from TrialFrozenData180

local instance : IsFiniteMeasure ν := bandLaw_finite _

def exponent (z : Term) (i : Fin 39) :=
  (if i=0 then expAt z.1 else 0)+(if i=Fin.last 38 then expAt z.2.1 else 0)+
    ∑ l : Fin (signatures z.2.2.1).length, if (z.2.2.2 l).castSucc.succ=i then (signatures z.2.2.1).get l else 0

def coefficient (z : Term) : ℝ :=
  (caps z.1 z.2.1 z.2.2.1:ℝ)/(131072*Native.step)^(expAt z.1+expAt z.2.1)

private theorem site_prod (v : Fin 39→ℝ) (a b : Fin 3) (s : Fin 11) (t : Assignment s) :
    (∏ i, v i^(exponent ⟨a,b,s,t⟩ i)) =
      v 0^expAt a * v (Fin.last 38)^expAt b * ∏ l, v (t l).castSucc.succ^(signatures s).get l := by
  have single (z : ℝ) (P : Prop) [Decidable P] (n : ℕ) :
      z^(if P then n else 0) = if P then z^n else 1 := by split <;> simp_all
  simp only [exponent,pow_add,←Finset.prod_pow_eq_pow_sum,single,Finset.prod_mul_distrib]
  rw [Finset.prod_comm (s:=(Finset.univ : Finset (Fin 39)))
    (t:=(Finset.univ : Finset (Fin (signatures s).length)))]
  simp

theorem expansion (v : Fin 39→ℝ) :
    bound v = ∑ z : Term,coefficient z*∏ i,v i^(exponent z i) := by
  simp only [Fintype.sum_sigma]
  unfold bound
  refine Finset.sum_congr rfl fun a _=>Finset.sum_congr rfl fun b _=>Finset.sum_congr rfl fun s _=>?_
  unfold core endpoint
  rw [powers,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro t _
  rw [site_prod]
  unfold coefficient
  rw [pow_add]
  ring

private def power (v : Full) (i : Fin 39) := radial (v i)+Native.step/2
private def site (e : Fin 217) (b r : ℝ) (k : ℕ) (x : Band 216) :=
  (weight (fun t => LaterLowFactor.g t^2) e b r x)*(radial x+Native.step/2)^k

private theorem regular_site (e : Fin 217) (n : ℕ) {b r : ℝ} (hb : 0<b) (hr : 0≤r) :
    Integrable (site e b r n) ν := by
  have h:=LowWeightedQuadrature.shift_regular e n hb hr (Native.step/2)
  unfold site weight
  convert h using 2
  ring

private theorem site_eq (e : Fin 217) (n : ℕ) (b r : ℝ) :
    (∫ x,site e b r n x ∂ν) = shifted e n b r (Native.step/2) := by
  unfold shifted
  apply integral_congr_ae
  apply Eventually.of_forall
  intro x
  unfold site weight
  ring

def integrand (e : Fin 217) (b r : ℝ) (erased : Fin 39) (v : Full) :=
  (bound (power v))^2*∏ i,weight (fun t=>LaterLowFactor.g t^2) e b (rate erased i r) (v i)

private def term (e : Fin 217) (b r : ℝ) (erased : Fin 39) (j k : Term) (v : Full) :=
  (coefficient j*coefficient k)*∏ i,site e b (rate erased i r) (exponent j i+exponent k i) (v i)

private theorem integrand_eq (e : Fin 217) (b r : ℝ) (erased : Fin 39) (v : Full) :
    integrand e b r erased v=∑ j : Term,∑ k : Term,term e b r erased j k v := by
  unfold integrand
  rw [expansion,pow_two,Finset.sum_mul,Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro j _
  rw [Finset.mul_sum,Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro k _
  simp only [term,site,power,pow_add,Finset.prod_mul_distrib]
  ring

private theorem regular_term (e : Fin 217) {b r : ℝ} (hb : 0<b) (hr : 0≤r)
    (erased : Fin 39) (j k : Term) : Integrable (term e b r erased j k) μ := by
  apply Integrable.const_mul
  apply Integrable.fintype_prod_dep
  intro i
  apply regular_site _ _ hb
  unfold rate
  split <;> positivity

theorem regular (e : Fin 217) {b r : ℝ} (hb : 0<b) (hr : 0≤r) (erased : Fin 39) :
    Integrable (integrand e b r erased) μ := by
  have eq : integrand e b r erased=fun v=>∑ j : Term,∑ k : Term,term e b r erased j k v :=
    funext (integrand_eq _ _ _ _)
  rw [eq]
  exact integrable_finsetSum _ fun j _=>integrable_finsetSum _ fun k _=>regular_term _ hb hr erased j k

def contraction (e : Fin 217) (b r : ℝ) (erased : Fin 39) :=
  ∑ j : Term,∑ k : Term,(coefficient j*coefficient k)*
    ∏ i,shifted e (exponent j i+exponent k i) b (rate erased i r) (Native.step/2)

theorem fubini (e : Fin 217) {b r : ℝ} (hb : 0<b) (hr : 0≤r) (erased : Fin 39) :
    (∫ v,integrand e b r erased v ∂μ)=contraction e b r erased := by
  simp_rw [integrand_eq]
  rw [integral_finsetSum _ (fun j _=>integrable_finsetSum _ fun k _=>regular_term e hb hr erased j k)]
  unfold contraction
  apply Finset.sum_congr rfl
  intro j _
  rw [integral_finsetSum _ fun k _=>regular_term e hb hr erased j k]
  apply Finset.sum_congr rfl
  intro k _
  unfold term
  rw [integral_const_mul,integral_fintype_prod_eq_prod]
  simp_rw [site_eq]


private theorem fnn (e : Fin 217) (b r : ℝ) (i : Fin 39) (v : Full) :
    0 ≤ integrand e b r i v :=
  mul_nonneg (sq_nonneg _) (Finset.prod_nonneg fun _ _=>mul_nonneg (sq_nonneg _) (Real.exp_pos _).le)

def cutoff (j : Fin 3) := ((1:ℝ)/Lookup.ticks)*(2*FrozenData.parentUpper (LowMassReceiver.lastEdge j))

/-- This is a bound on the actual physical event. All 39 coordinates are integrated through
their tilted one-site moments, with the erased coordinate receiving zero dust rate. -/
theorem event (j : Fin 3) (b r : ℝ≥0) (hb : 0<b) :
    (∫ v in LowMassReceiver.lastRow j,(Restoration.original v)^2 ∂μ) ≤
      LaterLowFactor.bias^78*Real.exp ((b:ℝ)*totalCap+(r:ℝ)*cutoff j)*
      ∑ i : Fin 39,contraction (T.tailEdge (LowMassReceiver.lastEdge j)) b r i := by
  let e:=T.tailEdge (LowMassReceiver.lastEdge j)
  let L:=LaterLowFactor.bias^78*Real.exp ((b:ℝ)*totalCap+(r:ℝ)*cutoff j)
  have ln : 0≤L := mul_nonneg (Even.pow_nonneg (by decide : Even 78) _) (Real.exp_pos _).le
  have pos : 0<(b:ℝ) := hb
  have reg (i : Fin 39) := regular e pos (show 0≤(r:ℝ) from r.2) i
  have pay : (∫ v in LowMassReceiver.lastRow j,(Restoration.original v)^2 ∂μ) ≤
      ∫ v,L*(∑ i : Fin 39,integrand e b r i v) ∂μ := by
    rw [←integral_indicator (LowMassReceiver.last_meas j)]
    apply integral_mono_of_nonneg (Eventually.of_forall fun _=>Set.indicator_nonneg (fun _ _=>sq_nonneg _) _)
      ((integrable_finsetSum _ fun i _=>reg i).const_mul L)
    filter_upwards [bands_nonneg 39] with v nn
    have posSum := Finset.sum_nonneg (s:=Finset.univ) (fun (k : Fin 39) _=>fnn e b r k v)
    by_cases yes : v∈LowMassReceiver.lastRow j
    · rw [Set.indicator_of_mem yes]
      by_cases nz : Restoration.original v=0
      · rw [nz,zero_pow (by decide)]
        exact mul_nonneg ln posSum
      obtain ⟨w,total,_,sl⟩:=yes
      have raw : v∈JointEdgeLowRows.row (LowMassReceiver.lastEdge j) := ⟨w,sl⟩
      rw [row_scale _ (by norm_num : (0:ℝ)<1)] at raw
      obtain ⟨i,fail⟩:=raw
      have ker:=tilted (fun t=>sq_nonneg (LaterLowFactor.g t)) b r (cutoff j) nz i fail
      have amp:=LowAngularPhysical.physical v total (fun k=>Finset.sum_nonneg fun l _=>nn k l)
      let B:=(bound (power v))^2
      let U:=LaterLowFactor.bias^78
      let expo:=Real.exp ((b:ℝ)*totalCap+(r:ℝ)*cutoff j)
      have aa : (Restoration.original v)^2 ≤ U*(∏ k,LaterLowFactor.g (radial (v k))^2)*B := by
        have aa:=pow_le_pow_left₀ (abs_nonneg _) amp 2
        have eq : power v = fun k=>radial (v k)+Native.step/2 := funext fun _=>rfl
        simpa only [sq_abs,mul_pow,←Finset.prod_pow,←pow_mul,U,B,eq,Nat.reduceMul] using aa
      have u0 : 0≤U := Even.pow_nonneg (by decide : Even 78) _
      apply aa.trans
      apply ((mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left ker u0) (sq_nonneg _))).trans
      apply le_trans _ (mul_le_mul_of_nonneg_left (Finset.single_le_sum (f:=fun k=>integrand e b r k v)
        (fun k _=>fnn e b r k v) (Finset.mem_univ i)) ln)
      apply le_of_eq
      dsimp only [integrand,L,U,B,e]
      ring
    · rw [Set.indicator_of_notMem yes]
      exact mul_nonneg ln posSum
  apply pay.trans_eq
  rw [integral_const_mul,integral_finsetSum _ fun i _=>reg i]
  simp only [fubini (b:=(b:ℝ)) (r:=(r:ℝ)) _ pos r.2]
  rfl


private theorem six (z : Term) (i : Fin 39) : exponent z i≤6 := by
  have ends : ∀ a : Fin 3,expAt a≤2 := by decide +kernel
  have sums : ∀ s : Fin 11, (∑ l : Fin (signatures s).length,(signatures s).get l)≤6 := by decide +kernel
  rcases z with ⟨a,b,s,t⟩
  have away (l : Fin (signatures s).length) : (t l).castSucc.succ ≠ (0 : Fin 39) ∧
      (t l).castSucc.succ ≠ Fin.last 38 := by
    constructor
    · exact Fin.succ_ne_zero _
    · intro eq
      have h:=congrArg Fin.val eq
      change (t l).val+1=38 at h
      omega
  by_cases z : i=0
  · subst i
    have eq : (0:Fin 39)≠Fin.last 38 := by decide
    simp only [exponent,ite_true,ite_eq_right eq,ite_eq_right (away _).1,Finset.sum_const_zero,add_zero]
    exact (ends a).trans (by decide)
  by_cases o : i=Fin.last 38
  · subst i
    simp only [exponent,ite_eq_right z,ite_true,ite_eq_right (away _).2,Finset.sum_const_zero,zero_add,add_zero]
    exact (ends b).trans (by decide)
  simp only [exponent,ite_eq_right z,ite_eq_right o,zero_add]
  apply le_trans _ (sums s)
  apply Finset.sum_le_sum
  intro l _
  split <;> omega

theorem degree (z y : Term) (i : Fin 39) : exponent z i+exponent y i<13 := by
  have := six z i
  have := six y i
  omega

/-- Closed analytic inequalities now leave a finite degree-twelve moment table for either site role. -/
def upper (U V : Fin 13→ℝ) (erased : Fin 39) :=
  ∑ j : Term,∑ k : Term,(coefficient j*coefficient k)*
    ∏ i,(if i=erased then U else V) ⟨exponent j i+exponent k i,degree j k i⟩

private theorem coef_nonneg (j : Term) : 0≤coefficient j := by
  unfold coefficient
  apply div_nonneg (Nat.cast_nonneg _) (pow_nonneg (by norm_num [Native.step]) _)

private theorem positive (e : Fin 217) (n : ℕ) (b r : ℝ) : 0 ≤ shifted e n b r (Native.step/2) := by
  apply integral_nonneg_of_ae
  filter_upwards [one_nonneg] with x nn
  exact mul_nonneg (sq_nonneg _) (mul_nonneg (pow_nonneg (add_nonneg (Finset.sum_nonneg fun k _=>nn k)
    (by norm_num [Native.step])) _) (Real.exp_pos _).le)

theorem contraction_upper (e : Fin 217) (b r : ℝ) (erased : Fin 39) (U V : Fin 13→ℝ)
    (hu : ∀ k : Fin 13,shifted e k.val b 0 (Native.step/2)≤U k)
    (hv : ∀ k : Fin 13,shifted e k.val b r (Native.step/2)≤V k) :
    contraction e b r erased≤upper U V erased := by
  unfold contraction upper
  apply Finset.sum_le_sum
  intro j _
  apply Finset.sum_le_sum
  intro k _
  apply mul_le_mul_of_nonneg_left _ (mul_nonneg (coef_nonneg j) (coef_nonneg k))
  apply Finset.prod_le_prod (fun i _=>positive e _ _ _) (fun i _=>?_)
  let n : Fin 13 := ⟨exponent j i+exponent k i,degree j k i⟩
  by_cases eq : i=erased
  · simpa only [rate,ite_eq_left eq] using hu n
  · simpa only [rate,ite_eq_right eq] using hv n

#print axioms degree
#print axioms contraction_upper

#print axioms event

#print axioms fubini
end PrimeGap180.LowAngularProduct
