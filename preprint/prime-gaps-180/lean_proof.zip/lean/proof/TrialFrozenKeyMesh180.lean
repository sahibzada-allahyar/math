import TrialFrozenPairGate180
import TrialFrozenMesh180
import TrialMeshKeySemantics180

namespace PrimeGap180.FrozenMesh

set_option maxRecDepth 100000
set_option maxHeartbeats 100000000

private theorem certificate : FiniteCertificate := by
  constructor <;> decide +kernel

/-- The literal physical mesh and all 25,600 active integer gate keys. -/
theorem checked : FrozenPairGate.MeshChecks := ⟨bins,enclosed_key certificate⟩

#print axioms checked
end PrimeGap180.FrozenMesh
