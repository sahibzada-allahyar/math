import TrialRestorationCharge180
import TrialRemovedLowProjection180
import TrialRemovedHighMass180

/-! The actual low and high signed image energies in the restoration ledger are
dominated by the projected low event and the two-fragment high event used for quadrature. -/
noncomputable section
open scoped BigOperators Classical ENNReal
open MeasureTheory PrimeGap186 PrimeGap180.Sector PrimeGap180.GateDeletion
open PrimeGap180.PhysicalDebit (Regular)
open PrimeGap180.RestorationCharge PrimeGap180.RemovedHighMass
namespace PrimeGap180.RestorationOuterEnergy

open private measurable_low from TrialRemovedLowProjection180
open private meas_bands band_push meas_charged from TrialRemovedHighMass180
open private image_reg from TrialRestorationCharge180
open private intg comp from TrialRestorationField180

open private raw_reg from TrialPhysicalDebit180

def lowRegion : Set Full := {w | RemovedLowProjection.lowEvent w} ∩ {w | Restoration.original w ≠ 0}
def highRegion : Set Config := charged ∩ {X | Restoration.original (bands X) ≠ 0}

theorem lowRegion_meas : MeasurableSet lowRegion :=
  measurable_low.inter (measurableSet_eq_fun raw_reg.1 measurable_const).compl

theorem highRegion_meas : MeasurableSet highRegion :=
  meas_charged.inter (measurableSet_eq_fun (raw_reg.1.comp meas_bands) measurable_const).compl

private theorem raw_of_layer (g : Fin 24) (v : Full) (nz : layer (.group g) v ≠ 0) :
    Restoration.original v ≠ 0 := by
  intro h
  apply nz
  unfold layer
  split
  · exact h
  · rfl

theorem low (V : Full → ℝ) (reg : Regular V) : restrictedSq 0 V ≤
    ∫ v in lowRegion, (V v)^2 ∂μ := by
  let := bandLaw_finite FrozenData.mesh
  have sq := SignedErasure.continuous_reg reg (fun z => z^2) (by fun_prop)
  rw [restrictedSq,←integral_indicator lowRegion_meas]
  apply integral_mono_ae (intg _ (image_reg _ _ reg)) ((intg _ sq).indicator lowRegion_meas)
  filter_upwards [StructuralGate.physical_ae (d:=39)] with v hv
  by_cases z : layer (.group 0) v = 0
  · rw [ite_eq_left z]
    exact Set.indicator_nonneg (fun w _ => sq_nonneg (V w)) v
  · have on : owner (encode v) = some (.group 0) := by
      by_contra h
      exact z (ite_eq_right h)
    have nz : original v ≠ 0 := by simpa only [layer,ite_eq_left on] using z
    have hit := RemovedLowProjection.covers_low v hv.1 nz on
    rw [ite_eq_right z,Set.indicator_of_mem (show v ∈ lowRegion from ⟨hit,raw_of_layer 0 v z⟩)]

theorem high (V : Full → ℝ) (reg : Regular V) : restrictedSq 23 V ≤
    ∫ X in highRegion, (V (bands X))^2 ∂law := by
  let := fragmentLaw_isProbabilityMeasure cap
  let : IsFiniteMeasure (NativeSiteLaw.phys cap) := (fragmentLaw cap).smul_finite (by simp)
  let : IsFiniteMeasure law := by unfold law; infer_instance
  have sq := SignedErasure.continuous_reg reg (fun z => z^2) (by fun_prop)
  have full := image_reg 23 V reg
  change (∫ v : Full, (if layer (.group 23) v = 0 then 0 else (V v)^2) ∂μ) ≤ _
  rw [←band_push,integral_map meas_bands.aemeasurable full.1.aestronglyMeasurable,
    ←integral_indicator highRegion_meas]
  apply integral_mono_ae (intg law (comp full meas_bands)) ((intg law (comp sq meas_bands)).indicator highRegion_meas)
  filter_upwards [high_ae] with X h
  change (if layer (.group 23) (bands X) = 0 then 0 else (V (bands X))^2) ≤ _
  by_cases z : layer (.group 23) (bands X) = 0
  · rw [ite_eq_left z]
    exact Set.indicator_nonneg (fun q _ => sq_nonneg (V (bands q))) X
  · rw [ite_eq_right z,Set.indicator_of_mem (show X ∈ highRegion from ⟨h.resolve_left z,raw_of_layer 23 _ z⟩)]
    exact le_rfl

theorem low_field : imageSq 0 ≤
    ∫ v in lowRegion, (RestorationField.field v)^2 ∂μ :=
  low _ RestorationField.field_reg

theorem high_field : imageSq 23 ≤
    ∫ X in highRegion, (RestorationField.field (bands X))^2 ∂law :=
  high _ RestorationField.field_reg

#print axioms low_field
#print axioms high_field
end PrimeGap180.RestorationOuterEnergy
