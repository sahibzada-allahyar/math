import TrialPrimeDistribution180
import Mathlib.Data.List.Sort

/-! Push an ordered product of distinct primes forward without a factorial
or a collision error. The two literal events retain strict physical cutoffs. -/
noncomputable section
open scoped BigOperators Classical
open PrimeGap180.Literal PrimeGap180.Distribution
namespace PrimeGap180.Ordinary

theorem ordered_primes_unique {k : ℕ} {p q : Fin k → ℕ}
    (hp : ∀ i, (p i).Prime) (hq : ∀ i, (q i).Prime)
    (sp : StrictMono p) (sq : StrictMono q) (eq : ∏ i, p i = ∏ i, q i) : p = q := by
  have primes (t : Fin k → ℕ) (ht : ∀ i, (t i).Prime) : ∀ n ∈ List.ofFn t, n.Prime := by
    intro n hn
    obtain ⟨i, rfl⟩ := List.mem_ofFn.mp hn
    exact ht i
  have left := Nat.primeFactorsList_unique ((Fin.prod_ofFn p).trans eq) (primes p hp)
  have right := Nat.primeFactorsList_unique (Fin.prod_ofFn q) (primes q hq)
  exact List.ofFn_injective (List.Perm.eq_of_sortedLE sp.monotone.sortedLE_ofFn
    sq.monotone.sortedLE_ofFn (left.trans right.symm))

def primeBand (x lo hi : ℝ) := (Finset.Icc ⌈x^lo⌉₊ ⌊x^hi⌋₊).filter Nat.Prime

theorem mem_primeBand {x lo hi : ℝ} {n : ℕ} (hx : 0 < x) :
    n ∈ primeBand x lo hi ↔ n.Prime ∧ x^lo ≤ (n:ℝ) ∧ (n:ℝ) ≤ x^hi := by
  simp only [primeBand,Finset.mem_filter,Finset.mem_Icc,Nat.ceil_le,
    Nat.le_floor_iff (Real.rpow_nonneg hx.le _)]
  tauto

theorem ordered_pushforward {k : ℕ} (P N : Finset ℕ) (hp : ∀ n ∈ P, n.Prime)
    (C : (Fin k → ℕ) → Prop) (event : ℕ → Prop)
    (hmono : ∀ t, C t → StrictMono t)
    (hspec : ∀ n ∈ N, event n ↔ ∃ t ∈ Fintype.piFinset (fun _ : Fin k => P),
      C t ∧ (∏ i, t i) = n) :
    (∑ n ∈ N, Finsupp.single n (if event n then (1:ℂ) else 0)) =
      ∑ t ∈ Fintype.piFinset (fun _ : Fin k => P), Finsupp.single (∏ i, t i)
        (if (∏ i, t i) ∈ N ∧ C t then (1:ℂ) else 0) := by
  classical
  ext n
  simp only [Finsupp.finsetSum_apply,Finsupp.single_apply,Finset.sum_ite_eq']
  by_cases hn : n ∈ N
  · rw [ite_eq_left hn]
    by_cases he : event n
    · rw [ite_eq_left he]
      obtain ⟨p,hpT,hCp,eqp⟩ := (hspec n hn).mp he
      symm
      rw [Finset.sum_eq_single p]
      · simp [eqp,hn,hCp]
      · intro q hqT hne
        by_cases eq : (∏ i, q i) = n
        · have nq : ¬C q := fun hCq => hne (ordered_primes_unique
            (fun i => hp _ (Fintype.mem_piFinset.mp hqT i))
            (fun i => hp _ (Fintype.mem_piFinset.mp hpT i))
            (hmono q hCq) (hmono p hCp) (eq.trans eqp.symm))
          simp [eq,nq]
        · simp [eq]
      · exact fun h => (h hpT).elim
    · rw [ite_eq_right he]
      symm
      apply Finset.sum_eq_zero
      intro q hq
      by_cases eq : (∏ i, q i) = n
      · have nq : ¬C q := fun h => he ((hspec n hn).mpr ⟨q,hq,h,eq⟩)
        simp [eq,nq]
      · simp [eq]
  · rw [ite_eq_right hn]
    symm
    apply Finset.sum_eq_zero
    intro q _
    by_cases eq : (∏ i, q i) = n <;> simp [eq,hn]


def orderedFive (cut : ℝ) (t : Fin 5 → ℕ) := StrictMono t ∧ (t 3 : ℝ)*t 4 < cut

def orderedThree (lo hi : ℝ) (t : Fin 3 → ℕ) :=
  StrictMono t ∧ lo < (t 0 : ℝ) ∧ (t 2 : ℝ) < hi

theorem five_pushforward (x a : ℝ) (hx : 1 < x) (ha : a ≤ 417/1000) :
    (∑ n ∈ window x, Finsupp.single n (if Five (x^a) n then (1:ℂ) else 0)) =
      ∑ t ∈ Fintype.piFinset (fun _ : Fin 5 => primeBand x (4/25) (9/10)),
        Finsupp.single (∏ i, t i)
          (if (∏ i, t i) ∈ window x ∧ orderedFive (x^a) t then (1:ℂ) else 0) := by
  apply ordered_pushforward _ _ (fun _ hn => ((mem_primeBand (by linarith)).mp hn).1)
    _ _ (fun _ h => h.1)
  intro n hn
  have x0 : 0 < x := by linarith
  have rho : x^(4/25:ℝ)*(x^a)^2 < x := by
    rw [sq,← Real.rpow_add x0,← Real.rpow_add x0]
    exact (Real.rpow_lt_rpow_of_exponent_lt hx (by linarith : (4:ℝ)/25+(a+a)<1)).trans_eq
      (Real.rpow_one x)
  constructor
  · intro event
    obtain ⟨p,q,r,s,t,hp,hq,hr,hs,ht,hpq,hqr,hrs,hst,pr,cut⟩ := id event
    let f : Fin 5 → ℕ := ![p,q,r,s,t]
    have inc : StrictMono f := by
      apply Fin.strictMono_iff_lt_succ.mpr
      intro i; fin_cases i <;> first | exact hpq | exact hqr | exact hrs | exact hst
    have primes (i : Fin 5) : (f i).Prime := by
      fin_cases i <;> first | exact hp | exact hq | exact hr | exact hs | exact ht
    have prod : (∏ i, f i) = n := by simpa [f,Fin.prod_univ_succ,mul_assoc] using pr.symm
    refine ⟨f,Fintype.mem_piFinset.mpr ?_,⟨inc,cut⟩,prod⟩
    intro i
    apply (mem_primeBand x0).mpr
    have dvd : f i ∣ n := prod ▸ Finset.dvd_prod_of_mem _ (Finset.mem_univ i)
    have lower := five_rough (Real.rpow_nonneg x0.le _) rho
      (Nat.ceil_le.mp (Finset.mem_Icc.mp hn).1) event (primes i) dvd
    have last : (t:ℝ) ≤ (s:ℝ)*t := by
      simpa only [one_mul] using mul_le_mul_of_nonneg_right
        (by exact_mod_cast hs.one_lt.le : (1:ℝ) ≤ s) (Nat.cast_nonneg t)
    exact ⟨primes i,lower.le,((by exact_mod_cast inc.monotone (Fin.le_last i) : (f i:ℝ) ≤ t).trans
      (last.trans cut.le)).trans (Real.rpow_le_rpow_of_exponent_le hx.le (by linarith))⟩
  · rintro ⟨t,ht,⟨inc,cut⟩,prod⟩
    have pr (i : Fin 5) := ((mem_primeBand x0).mp (Fintype.mem_piFinset.mp ht i)).1
    exact ⟨t 0,t 1,t 2,t 3,t 4,pr _,pr _,pr _,pr _,pr _,
      inc (by decide),inc (by decide),inc (by decide),inc (by decide),
      by simpa [Fin.prod_univ_succ,mul_assoc] using prod.symm,cut⟩

theorem three_pushforward (x a c : ℝ) (hx : 1 < x) (hc : 4/25 ≤ c) (ha : a ≤ 9/10) :
    (∑ n ∈ window x, Finsupp.single n (if Three (x^c) (x^a) n then (1:ℂ) else 0)) =
      ∑ t ∈ Fintype.piFinset (fun _ : Fin 3 => primeBand x (4/25) (9/10)),
        Finsupp.single (∏ i, t i)
          (if (∏ i, t i) ∈ window x ∧ orderedThree (x^c) (x^a) t then (1:ℂ) else 0) := by
  have x0 : 0 < x := by linarith
  apply ordered_pushforward _ _ (fun _ hn => ((mem_primeBand x0).mp hn).1) _ _ (fun _ h => h.1)
  intro n _
  constructor
  · rintro ⟨p,q,r,hp,hq,hr,hpq,hqr,prod,lo,hi⟩
    let f : Fin 3 → ℕ := ![p,q,r]
    have inc : StrictMono f := by
      apply Fin.strictMono_iff_lt_succ.mpr
      intro i; fin_cases i <;> first | exact hpq | exact hqr
    refine ⟨f,Fintype.mem_piFinset.mpr ?_,⟨inc,lo,hi⟩,?_⟩
    · intro i
      apply (mem_primeBand x0).mpr
      have pr : (f i).Prime := by fin_cases i <;> first | exact hp | exact hq | exact hr
      refine ⟨pr,(Real.rpow_le_rpow_of_exponent_le hx.le hc).trans (lo.le.trans ?_),
        (le_trans ?_ hi.le).trans (Real.rpow_le_rpow_of_exponent_le hx.le ha)⟩
      · exact_mod_cast inc.monotone (Fin.zero_le i)
      · exact_mod_cast inc.monotone (Fin.le_last i)
    · simpa [f,Fin.prod_univ_succ,mul_assoc] using prod.symm
  · rintro ⟨t,ht,⟨inc,lo,hi⟩,prod⟩
    have pr (i : Fin 3) := ((mem_primeBand x0).mp (Fintype.mem_piFinset.mp ht i)).1
    exact ⟨t 0,t 1,t 2,pr _,pr _,pr _,inc (by decide),inc (by decide),
      by simpa [Fin.prod_univ_succ,mul_assoc] using prod.symm,lo,hi⟩

#print axioms five_pushforward
#print axioms three_pushforward
end PrimeGap180.Ordinary
