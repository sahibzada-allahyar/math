import TrialDebitGeometry180
import TrialSiteLawComparison180

/-! Comparison of the positive debit before deletion using finite single-site
weights. On a contributing insertion only the lower, common part of the site
law is needed; two retained sites can have changed weights. -/
noncomputable section
open scoped Classical BigOperators
open MeasureTheory PrimeGap186 PrimeGap180.Sector PrimeGap180.FrozenProfile
open PrimeGap180.CoarseLaw PrimeGap180.CoarseForms PrimeGap180.PhysicalDebit
namespace PrimeGap180.DebitWeights

def singleW (w : State → ℝ) (i : Fin 39) (x : Fin 38 → State) :=
  ∑ z : State,w z*rawState (i.insertNth (α := fun _ => State) z x)
def priceAt (x : Fin 38 → State) := rate (NativeContractions.label x) (NativeContractions.total x)
def debitW (w : State → ℝ) := rho*∑ i : Fin 39, ∑ x, priceAt x*(singleW w i x)^2*∏ j,w (x j)
def massW (w : State → ℝ) := ∑ x : Fin 39 → State,(rawState x)^2*∏ j,w (x j)

theorem true_debit : debit Restoration.original = debitW weight := by
  classical
  rw [original_finite]
  apply congrArg (rho*·)
  apply Finset.sum_congr rfl
  intro i _
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro x _
  simp [terms,priceAt,singleW,single,ite_pow,mul_ite,ite_mul,Finset.sum_ite_eq]

theorem true_mass : NumericalAccount.mass Restoration.original = massW weight := CoarseForms.ordinary

/-- The finite retained price run census suffices to make the inserted
one-site averages exactly equal even if the signed spline has cancellations. -/
def bottomPrices := ∀ x : Fin 38 → State, NativeContractions.total x ≤ 85897 → priceAt x=0

private theorem captured (i : Fin 39) (x : Fin 38 → State) (z : State) (nz : rawState (i.insertNth (α := fun _ => State) z x) ≠ 0) :
    z.1.val + NativeContractions.total x ≤ 130964 := by
  have h := raw_index_bound _ nz
  rw [Fin.sum_univ_succAbove _ i] at h
  simpa [NativeContractions.total,idx] using h

structure LawComparison (w : State → ℝ) : Prop where
  nonnegative : ∀ z, 0 ≤ w z
  small : ∀ z, z.1.val < 45067 → w z=weight z
  lower : ∀ z,(if 45067 ≤ z.1.val then (1-0.00002:ℝ) else 1)*w z ≤ weight z
  upper : ∀ z,weight z ≤ (if 45067 ≤ z.1.val then (1.00002:ℝ) else 1)*w z

theorem inserted_equal {w : State → ℝ} (law : LawComparison w) (bottom : bottomPrices)
    (i : Fin 39) (x : Fin 38 → State) (p : priceAt x ≠ 0) :
    singleW w i x = singleW weight i x := by
  have large : 85897 < NativeContractions.total x := by
    by_contra! low; exact p (bottom x low)
  apply Finset.sum_congr rfl
  intro z _
  by_cases nz : rawState (i.insertNth (α := fun _ => State) z x)=0
  · simp [nz]
  · have cap := captured i x z nz
    rw [law.small z (by omega)]

theorem retained_upper {w : State → ℝ} (law : LawComparison w) (x : Fin 38 → State)
    (room : NativeContractions.total x ≤ 130964) :
    (∏ j,weight (x j)) ≤ (1.00002:ℝ)^2*∏ j,w (x j) := by
  let high := Finset.univ.filter fun j => 45067 ≤ (x j).1.val
  let k : ℝ := 1.00002
  have coeff : (∏ j, if 45067 ≤ (x j).1.val then k else 1) = k^high.card := by
    simpa [high] using Finset.prod_ite_mem_eq high (fun _ => k)
  have card : high.card ≤ 2 := SiteLawComparison.at_most_two (fun j => (x j).1.val) room
  calc
    _ ≤ ∏ j, ((if 45067 ≤ (x j).1.val then k else 1)*w (x j)) :=
      Finset.prod_le_prod (fun j _ => ENNReal.toReal_nonneg) (fun j _ => law.upper (x j))
    _ = k^high.card * ∏ j,w (x j) := by rw [Finset.prod_mul_distrib,coeff]
    _ ≤ _ := mul_le_mul_of_nonneg_right (pow_le_pow_right₀ (by norm_num [k]) card)
      (Finset.prod_nonneg (fun j _ => law.nonnegative (x j)))

theorem uncut {w : State → ℝ} (law : LawComparison w) (bottom : bottomPrices)
    (native : debitW w ≤ 0.000023397128*massW w) :
    debit Restoration.original ≤ 0.000023399*NumericalAccount.mass Restoration.original := by
  have termBound (i : Fin 39) (x : Fin 38 → State) :
      priceAt x*(singleW weight i x)^2*(∏ j,weight (x j)) ≤
        (1.00002:ℝ)^2*(priceAt x*(singleW w i x)^2*(∏ j,w (x j))) := by
    by_cases p : priceAt x=0
    · simp [p]
    rw [←inserted_equal law bottom i x p]
    by_cases off : singleW w i x=0
    · simp [off]
    have hit : ∃ z, rawState (i.insertNth (α := fun _ => State) z x) ≠ 0 := by
      by_contra! empty; apply off; simp [singleW,empty]
    obtain ⟨z,nz⟩ := hit
    have room := captured i x z nz
    have nn : 0 ≤ priceAt x := le_max_left _ _
    have hp := mul_le_mul_of_nonneg_left (retained_upper law x (by omega)) (mul_nonneg nn (sq_nonneg (singleW w i x)))
    linarith only [hp]
  have vals := mul_le_mul_of_nonneg_left (Finset.sum_le_sum (s := Finset.univ)
    (fun (i : Fin 39) _ => Finset.sum_le_sum (s := Finset.univ) (fun x _ => termBound i x))) (by norm_num [rho] : 0 ≤ rho)
  simp only [←Finset.mul_sum] at vals
  have forms : debitW weight ≤ 1.00002^2*debitW w := by unfold debitW; linarith only [vals]
  have mass := SiteLawComparison.weighted_norm (fun z : State => z.1.val) w weight rawState
    (by norm_num : (0:ℝ) ≤ 1-0.00002) (by norm_num) law.nonnegative law.lower raw_index_bound
  rw [true_debit,true_mass]
  change (1-0.00002)^2 * massW w ≤ massW weight at mass
  have h0 : 0 ≤ massW w := Finset.sum_nonneg fun x _ => mul_nonneg (sq_nonneg _) (Finset.prod_nonneg fun j _ => law.nonnegative _)
  linarith only [forms,native,mass,h0]

/-- The same transfer with the native allowance raised for the slack route. -/
theorem uncut24 {w : State → ℝ} (law : LawComparison w) (bottom : bottomPrices)
    (native : debitW w ≤ 0.000023998*massW w) :
    debit Restoration.original ≤ 0.000024*NumericalAccount.mass Restoration.original := by
  have termBound (i : Fin 39) (x : Fin 38 → State) :
      priceAt x*(singleW weight i x)^2*(∏ j,weight (x j)) ≤
        (1.00002:ℝ)^2*(priceAt x*(singleW w i x)^2*(∏ j,w (x j))) := by
    by_cases p : priceAt x=0
    · simp [p]
    rw [←inserted_equal law bottom i x p]
    by_cases off : singleW w i x=0
    · simp [off]
    have hit : ∃ z, rawState (i.insertNth (α := fun _ => State) z x) ≠ 0 := by
      by_contra! empty; apply off; simp [singleW,empty]
    obtain ⟨z,nz⟩ := hit
    have room := captured i x z nz
    have nn : 0 ≤ priceAt x := le_max_left _ _
    have hp := mul_le_mul_of_nonneg_left (retained_upper law x (by omega)) (mul_nonneg nn (sq_nonneg (singleW w i x)))
    linarith only [hp]
  have vals := mul_le_mul_of_nonneg_left (Finset.sum_le_sum (s := Finset.univ)
    (fun (i : Fin 39) _ => Finset.sum_le_sum (s := Finset.univ) (fun x _ => termBound i x))) (by norm_num [rho] : 0 ≤ rho)
  simp only [←Finset.mul_sum] at vals
  have forms : debitW weight ≤ 1.00002^2*debitW w := by unfold debitW; linarith only [vals]
  have mass := SiteLawComparison.weighted_norm (fun z : State => z.1.val) w weight rawState
    (by norm_num : (0:ℝ) ≤ 1-0.00002) (by norm_num) law.nonnegative law.lower raw_index_bound
  rw [true_debit,true_mass]
  change (1-0.00002)^2 * massW w ≤ massW weight at mass
  have h0 : 0 ≤ massW w := Finset.sum_nonneg fun x _ => mul_nonneg (sq_nonneg _) (Finset.prod_nonneg fun j _ => law.nonnegative _)
  linarith only [forms,native,mass,h0]

#print axioms uncut24
#print axioms uncut
end PrimeGap180.DebitWeights
