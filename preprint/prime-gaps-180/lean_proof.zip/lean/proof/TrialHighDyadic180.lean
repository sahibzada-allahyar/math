import Mathlib.Algebra.Order.Floor.Div
import Mathlib.Data.Rat.Cast.Order
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Tactic.FieldSimp

/-! Integer enclosures used by the high-edge one-site moment sweep. -/
namespace PrimeGap180.HighDyadic

structure I where
  lo : ℕ
  hi : ℕ
  deriving DecidableEq, Repr

def unit : ℕ := 2^768
def inside (b : I) (x : ℚ) := (b.lo:ℚ) ≤ (unit:ℚ)*x ∧ (unit:ℚ)*x ≤ (b.hi:ℚ)
def zero : I := ⟨0,0⟩
def one : I := ⟨unit,unit⟩
def plus (b c : I) : I := ⟨b.lo+c.lo,b.hi+c.hi⟩
def divide (u d : ℕ) := (u+d-1)/d
def scaled (b : I) (n d : ℕ) : I := ⟨b.lo*n/d,divide (b.hi*n) d⟩
def times (b c : I) : I := ⟨b.lo*c.lo/unit,divide (b.hi*c.hi) unit⟩

private theorem dpos : (0:ℚ) < (unit:ℚ) := by norm_num [unit]
private theorem fl (u d : ℕ) : ((u/d:ℕ):ℚ)*d ≤ (u:ℚ) := by exact_mod_cast Nat.div_mul_le_self u d
private theorem ce (u d : ℕ) (hd : 0 < d) : (u:ℚ) ≤ (divide u d : ℚ)*d := by
  have h := le_smul_ceilDiv (b:=u) hd
  rw [Nat.ceilDiv_eq_add_pred_div,nsmul_eq_mul,mul_comm] at h
  exact_mod_cast h

theorem zero_ok : inside zero 0 := by simp [inside,zero]
theorem one_ok : inside one 1 := by simp [inside,one]
theorem plus_ok {a b : I} {x y : ℚ} (hx : inside a x) (hy : inside b y) :
    inside (plus a b) (x+y) := by
  simpa only [inside,plus,Nat.cast_add,mul_add] using
    And.intro (add_le_add hx.1 hy.1) (add_le_add hx.2 hy.2)

theorem scaled_ok {b : I} {x : ℚ} (hx : inside b x) (n d : ℕ) (hd : 0 < d) :
    inside (scaled b n d) (x*n/d) := by
  have hq : 0 < (d:ℚ) := by exact_mod_cast hd
  have nn : 0 ≤ (n:ℚ) := by positivity
  have lo := fl (b.lo*n) d
  have hi := ce (b.hi*n) d hd
  push_cast at lo hi
  unfold inside scaled
  rw [show (unit:ℚ)*(x*n/d)=((unit:ℚ)*x)*n/d by ring]
  exact ⟨(le_div_iff₀ hq).mpr (lo.trans (mul_le_mul_of_nonneg_right hx.1 nn)),
    (div_le_iff₀ hq).mpr ((mul_le_mul_of_nonneg_right hx.2 nn).trans hi)⟩

theorem times_ok {a b : I} {x y : ℚ} (hx : inside a x) (hy : inside b y) :
    inside (times a b) (x*y) := by
  have nnx : 0 ≤ (unit:ℚ)*x := (Nat.cast_nonneg _).trans hx.1
  have lo := fl (a.lo*b.lo) unit
  have hi := ce (a.hi*b.hi) unit (by norm_num [unit])
  push_cast at lo hi
  have p := (mul_le_mul hx.1 hy.1 (Nat.cast_nonneg _) nnx)
  have q := mul_le_mul hx.2 hy.2 ((Nat.cast_nonneg _).trans hy.1) (Nat.cast_nonneg _)
  unfold inside times
  rw [show (unit:ℚ)*(x*y)=((unit:ℚ)*x)*((unit:ℚ)*y)/unit by field_simp [dpos.ne']]
  exact ⟨(le_div_iff₀ dpos).mpr (lo.trans p), (div_le_iff₀ dpos).mpr (q.trans hi)⟩

/-- Binary exponentiation with rounding at every product. The bit list is
least significant first and can be checked by the kernel as a small numeral. -/
def power (base : I) : List Bool → I
  | [] => one
  | b :: bs => let t := power base bs; let s := times t t; if b then times s base else s

def exponent : List Bool → ℕ
  | [] => 0
  | b :: bs => 2 * exponent bs + if b then 1 else 0

theorem power_ok {base : I} {r : ℚ} (hr : inside base r) (bits : List Bool) :
    inside (power base bits) (r^(exponent bits)) := by
  induction bits with
  | nil => simpa [power,exponent] using one_ok
  | cons b bs ih =>
    have sq := times_ok ih ih
    cases b
    · simpa only [power,exponent,Bool.false_eq_true,ite_false,add_zero,two_mul,pow_add] using sq
    · simpa only [power,exponent,ite_true,two_mul,pow_add,pow_one] using (times_ok sq hr)

#print axioms scaled_ok
#print axioms times_ok
#print axioms power_ok
end PrimeGap180.HighDyadic
