import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G343
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 343

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G343

namespace PrimeGap180.PriceIsolatedGroup.G348
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 348

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G348

namespace PrimeGap180.PriceIsolatedGroup.G353
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 353

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G353

namespace PrimeGap180.PriceIsolatedGroup.G358
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 358

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G358
