import TrialDensityRationalRows180

/-! Executable dense coefficient arithmetic for products of affine forms. The
outer list stores ascending degrees of the first variable. -/
namespace PrimeGap180.DensitySimplex.Horner

abbrev Table : ℕ → Type
  | 0 => Int
  | d+1 => List (Table d)

def zero : (d : ℕ) → Table d
  | 0 => (0 : Int)
  | _+1 => []

noncomputable def value {A : Type} (v : A → ℝ) (x : ℝ) (l : List A) : ℝ :=
  l.foldr (fun a s => v a+x*s) 0

noncomputable def evaluate : (d : ℕ) → Table d → (Fin d → ℝ) → ℝ
  | 0, a, _ => ((a : Int) : ℝ)
  | d+1, l, x => value (fun a => evaluate d a (Fin.tail x)) (x 0) l

def together {A : Type} (f : A → A → A) : List A → List A → List A
  | [], b => b
  | a::as, [] => a::as
  | a::as, b::bs => f a b :: together f as bs

def add : (d : ℕ) → Table d → Table d → Table d
  | 0,a,b => (a:Int)+(b:Int)
  | d+1,a,b => together (add d) a b

def scale : (d : ℕ) → Int → Table d → Table d
  | 0,k,a => k*(a:Int)
  | d+1,k,l => l.map (scale d k)

def affineMul : (d : ℕ) → Int → (Fin d → Int) → Table d → Table d
  | 0,b,_,a => b*(a:Int)
  | d+1,b,c,l =>
    together (add d) (l.map (affineMul d b (Fin.tail c)))
      (zero d :: l.map (scale d (c 0)))

private theorem val_together {A : Type} (v : A → ℝ) (f : A → A → A)
    (h : ∀ a b, v (f a b)=v a+v b) (x : ℝ) (l k : List A) :
    value v x (together f l k) = value v x l+value v x k := by
  induction l generalizing k with
  | nil => simp [value,together]
  | cons a l ih =>
    cases k with
    | nil => simp [value,together]
    | cons b k =>
      simp only [together,value,List.foldr_cons] at ih ⊢
      rw [h,ih]
      ring

private theorem val_map {A : Type} (v : A → ℝ) (f : A → A) (k : ℝ)
    (h : ∀ a, v (f a)=k*v a) (x : ℝ) (l : List A) :
    value v x (l.map f) = k*value v x l := by
  induction l with
  | nil => simp [value]
  | cons a l ih =>
    simp only [value,List.map_cons,List.foldr_cons] at ih ⊢
    rw [h,ih]
    ring

theorem eval_zero (d : ℕ) (x : Fin d → ℝ) : evaluate d (zero d) x = 0 := by
  cases d <;> simp [zero,evaluate,value]

theorem eval_add (d : ℕ) (a b : Table d) (x : Fin d → ℝ) :
    evaluate d (add d a b) x = evaluate d a x+evaluate d b x := by
  induction d with
  | zero => simp [add,evaluate]
  | succ d ih => exact val_together _ (add d) (fun u w => ih u w _) _ a b

theorem eval_scale (d : ℕ) (k : Int) (a : Table d) (x : Fin d → ℝ) :
    evaluate d (scale d k a) x = (k:ℝ)*evaluate d a x := by
  induction d with
  | zero => simp [scale,evaluate]
  | succ d ih => exact val_map _ (scale d k) _ (fun u => ih u _) _ a

theorem eval_affineMul (d : ℕ) (b : Int) (c : Fin d → Int) (a : Table d) (x : Fin d → ℝ) :
    evaluate d (affineMul d b c a) x = ((b:ℝ)+∑ i,(c i:ℝ)*x i)*evaluate d a x := by
  induction d with
  | zero => simp [evaluate,affineMul]
  | succ d ih =>
    simp only [evaluate,affineMul]
    let v := fun a : Table d => evaluate d a (Fin.tail x)
    have m := val_map v (affineMul d b (Fin.tail c)) _ (fun u => ih (Fin.tail c) u (Fin.tail x)) (x 0) a
    have n := val_map v (scale d (c 0)) (c 0:ℝ) (fun u => eval_scale d (c 0) u (Fin.tail x)) (x 0) a
    rw [val_together _ _ (fun u w => eval_add d u w _),m]
    change _ + (evaluate d (zero d) _ + x 0*value _ _ (List.map _ a)) = _
    rw [eval_zero,zero_add,n,Fin.sum_univ_succ]
    dsimp only [Fin.tail,v]
    ring

#print axioms eval_affineMul
end PrimeGap180.DensitySimplex.Horner
