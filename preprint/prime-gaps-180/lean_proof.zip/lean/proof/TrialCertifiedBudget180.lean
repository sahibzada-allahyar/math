import TrialSlackBudget180
import TrialRestorationOuterEnergy180

/-! The four restoration inputs of `SlackBudget.Bounds` that the archived workers do not
bound directly, restated as what their certificates prove, and the Lean bridges back to
`SlackBudget.Bounds`.

The workers bound archived tabulated fields: the singles `V`, the pair `P` and the outer
images `G`. Lean's fields are the actual `RestorationBudget.singles`,
`RestorationBudget.negativePair` and `RestorationField.field`. Each input below is
therefore an existential decomposition: an approximating field, an L² distance from the
actual Lean field, and the worker bound on the approximating field at the frozen receipt
constants (`RestorationRows.rows` and the receipt images 1,196,124 and 179,904,296 ticks).
The bridges prove the slack constants of `SlackRows` and `SlackBudget` from them.

Statements that are established by written arguments or finite tables, rather than by the
computed bounds, are named fields of the certificates:

* `MiddlePair.bank`: the one-site bank dominates `bandLaw` (as product laws);
* `MiddlePair.superset`: the gate-table projection is a superset of the Lean group support;
* `MiddleJoint.schur`: the worker's pointwise Schur price dominates `RestorationCharge.multiplier`;
* `LowImage.region`, `HighImage.region`: Lean's `lowRegion`/`highRegion` lie in the worker events;
* the `transfer` fields: the field-norm comparisons and the endpoint-swap estimate of the
  paper's appendix on error analyses. They are stated against Lean's own fields, whose definitions use
  `facePrice`, `pairPrice` and `rho`, so the identity of the archived prices with these is a
  premise of the transfer fields and is not assumed anywhere else.

The bank, the gate tables, the Schur price and the worker events are archived objects that Lean
does not define, so they appear as the existential witnesses `ν`, `E` and `S`. Taking the
witnesses to be the actual fields, the Lean law and the Lean supports shows that each
decomposition is implied by the corresponding receipt-level statement about the actual field. -/
noncomputable section
open scoped Classical BigOperators
open MeasureTheory PrimeGap186 PrimeGap180.Sector PrimeGap180.CoarseLaw PrimeGap180.SignedErasure
open PrimeGap180.RestorationCharge PrimeGap180.RestorationBudget
open PrimeGap180.PhysicalDebit (Regular)
namespace PrimeGap180.CertifiedBudget

local instance : IsFiniteMeasure μ := bandLaw_finite _
open private intg comp from TrialRestorationField180
open private image_reg from TrialRestorationCharge180
open private layer_regular from TrialGateDeletion180
open private singles_reg pair_reg' from TrialRestorationBudget180
open private meas_bands from TrialRemovedHighMass180

/-! ## Certified inputs -/

/-- The middle pair images. `P` is the archived tabulated pair field, `ν i` the product of the
one-site bank used by the worker of group `i`, and `E i` the gate-table superset of the group. -/
structure MiddlePair (P : Full → ℝ) (ν : Fin 22 → Measure Full) (E : Fin 22 → Set Full) : Prop where
  regular : Regular P
  finite (i : Fin 22) : IsFiniteMeasure (ν i)
  /-- The one-site bank dominates `bandLaw`, so its product dominates the Lean law. -/
  bank (i : Fin 22) : prod 39 ≤ ν i
  measurable (i : Fin 22) : MeasurableSet (E i)
  /-- The gate-table projection is a superset of the support of the deleted group. -/
  superset (i : Fin 22) : {x | GateDeletion.layer (.group (middle i)) x ≠ 0} ⊆ E i
  /-- The pair-field transfer, ε_p = 6.91e-8 ≤ 2.5e-7. -/
  transfer : ∫ x, (negativePair x - P x)^2 ∂prod 39 ≤ (0.00000025:ℝ)^2 * originalMass
  /-- The 286 pair workers, aggregated per group, at the frozen receipt rows. -/
  worker (i : Fin 22) : ∫ x in E i, (P x)^2 ∂ν i ≤
    RestorationRows.ticks (RestorationRows.rows i).pairImage * originalMass

/-- The middle joint charges. `V` is the archived tabulated singles field with endpoint `b`
replaced by the swapped endpoint `a`, and `S i` the worker's pointwise Schur price on group `i`.
The worker bound is on the Lean law and the Lean group support. Its certificate reaches it
through the mass book (with no headroom over the Jackson mass), the one-site bank and the
gate-table superset; these do not separate as a measure domination because the cross term
is signed. -/
structure MiddleJoint (V : Full → ℝ) (S : Fin 22 → Full → ℝ) : Prop where
  regular : Regular V
  schurRegular (i : Fin 22) : Regular (S i)
  /-- The singles transfer, ε_s + ε_swap = 1.788e-7 ≤ 2.5e-7. -/
  transfer : ∫ x, (singles x - V x)^2 ∂prod 39 ≤ (0.00000025:ℝ)^2 * originalMass
  /-- The worker's Schur price dominates Lean's negative fibre multiplier on the group. -/
  schur (i : Fin 22) (x : Full) : GateDeletion.layer (.group (middle i)) x ≠ 0 → multiplier x ≤ S i x
  /-- `joint_singles_and_schur_upper` at the frozen receipt rows. -/
  worker (i : Fin 22) : 2*(∫ x, GateDeletion.layer (.group (middle i)) x * V x ∂prod 39) +
      (∫ x, S i x * (GateDeletion.layer (.group (middle i)) x)^2 ∂prod 39) -
      0.6865*StructuralRun.layerMass (middle i) ≤
    RestorationRows.ticks (RestorationRows.rows i).joint * originalMass

/-- The low image. `G` is the actual field on the first two low edges and the tabulated image
`A_tab F` on the other twelve; `E` is the union of the worker events. -/
structure LowImage (G : Full → ℝ) (E : Set Full) : Prop where
  regular : Regular G
  measurable : MeasurableSet E
  /-- Lean's projected low region lies in the worker events. -/
  region : RestorationOuterEnergy.lowRegion ⊆ E
  /-- FIELD + SWAP. -/
  transfer : ∫ x in E, (RestorationField.field x - G x)^2 ∂prod 39 ≤
    (0.00000024726961 + 0.0000000005881:ℝ)^2 * originalMass
  /-- Spectral ceiling on the first two edges plus the 108 single and 108 pair workers. -/
  worker : ∫ x in E, (G x)^2 ∂prod 39 ≤ RestorationRows.ticks 1196124 * originalMass

/-- The high image. `G` is the tabulated image `A_tab F` and `E` the worker's two-tag event,
both on the 39-site fragment configurations. -/
structure HighImage (G : Full → ℝ) (E : Set RemovedHighMass.Config) : Prop where
  regular : Regular G
  measurable : MeasurableSet E
  /-- Lean's charged high region lies in the worker event. -/
  region : RestorationOuterEnergy.highRegion ⊆ E
  /-- FIELD; no SWAP because both endpoints are evaluated. -/
  transfer : ∫ X in E, (RestorationField.field (RemovedHighMass.bands X) - G (RemovedHighMass.bands X))^2
      ∂(RemovedHighMass.law) ≤ (0.00000024726961:ℝ)^2 * originalMass
  /-- The 28 role rows of `high_tag_ledger.json`. -/
  worker : ∫ X in E, (G (RemovedHighMass.bands X))^2 ∂(RemovedHighMass.law) ≤
    RestorationRows.ticks 179904296 * originalMass

/-! ## Generic steps -/

theorem sq_split {a b l : ℝ} (hl : 0 < l) : a^2 ≤ (1+l)*b^2 + (1+1/l)*(a-b)^2 := by
  have h : (1+l)*b^2 + (1+1/l)*(a-b)^2 - a^2 = (l*b-(a-b))^2/l := by
    field_simp
    ring
  have p : 0 ≤ (l*b-(a-b))^2/l := div_nonneg (sq_nonneg _) hl.le
  linarith only [h,p]

theorem sub_reg {X : Type*} [MeasurableSpace X] {f g : X → ℝ} (hf : Regular f) (hg : Regular g) :
    Regular (fun x => f x - g x) := by
  obtain ⟨C,_,cf⟩ := hf.2.exists_pos_norm_le
  obtain ⟨D,_,cg⟩ := hg.2.exists_pos_norm_le
  refine ⟨hf.1.sub hg.1,isBounded_iff_forall_norm_le.mpr ⟨C+D,?_⟩⟩
  rintro _ ⟨x,rfl⟩
  exact (norm_sub_le _ _).trans (add_le_add (cf _ ⟨x,rfl⟩) (cg _ ⟨x,rfl⟩))

/-- The pointwise (1+λ) inequality, integrated. -/
theorem split {X : Type*} [MeasurableSpace X] (ρ : Measure X) [IsFiniteMeasure ρ] {f g : X → ℝ}
    (hf : Regular f) (hg : Regular g) {l : ℝ} (hl : 0 < l) :
    ∫ x, (f x)^2 ∂ρ ≤ (1+l)*(∫ x, (g x)^2 ∂ρ) + (1+1/l)*(∫ x, (f x - g x)^2 ∂ρ) := by
  have sf := continuous_reg hf (fun z => z^2) (by fun_prop)
  have sg := continuous_reg hg (fun z => z^2) (by fun_prop)
  have sd := continuous_reg (sub_reg hf hg) (fun z => z^2) (by fun_prop)
  have i₂ := (intg ρ sg).const_mul (1+l)
  have i₃ := (intg ρ sd).const_mul (1+1/l)
  rw [←integral_const_mul,←integral_const_mul,←integral_add i₂ i₃]
  apply integral_mono (intg ρ sf) (i₂.add i₃)
  intro x
  exact sq_split hl

/-- A squared integral grows with the measure. -/
theorem sq_mono {X : Type*} [MeasurableSpace X] {ρ ν : Measure X} [IsFiniteMeasure ν] (h : ρ ≤ ν)
    {f : X → ℝ} (hf : Regular f) : ∫ x, (f x)^2 ∂ρ ≤ ∫ x, (f x)^2 ∂ν :=
  integral_mono_measure h (ae_of_all _ fun x => sq_nonneg (f x))
    (intg ν (continuous_reg hf (fun z => z^2) (by fun_prop)))

/-- `restrictedSq` is at most the integral over any measurable superset of the group support. -/
theorem restricted_le (g : Fin 24) {W : Full → ℝ} (reg : Regular W) {E : Set Full} (hE : MeasurableSet E)
    (sub : {x | GateDeletion.layer (.group g) x ≠ 0} ⊆ E) :
    restrictedSq g W ≤ ∫ x in E, (W x)^2 ∂prod 39 := by
  have sq := continuous_reg reg (fun z => z^2) (by fun_prop)
  rw [restrictedSq,←integral_indicator hE]
  apply integral_mono (intg _ (image_reg g W reg)) ((intg _ sq).indicator hE)
  intro x
  by_cases z : GateDeletion.layer (.group g) x = 0
  · change (if GateDeletion.layer (.group g) x = 0 then 0 else (W x)^2) ≤ E.indicator (fun x => (W x)^2) x
    rw [ite_eq_left z]
    exact Set.indicator_nonneg (fun w _ => sq_nonneg (W w)) x
  · change (if GateDeletion.layer (.group g) x = 0 then 0 else (W x)^2) ≤ E.indicator (fun x => (W x)^2) x
    rw [ite_eq_right z,Set.indicator_of_mem (sub (show x ∈ {x | GateDeletion.layer (.group g) x ≠ 0} from z))]

/-- `restrictedSq` is at most the full squared integral. -/
theorem restricted_le_full (g : Fin 24) {W : Full → ℝ} (reg : Regular W) :
    restrictedSq g W ≤ ∫ x, (W x)^2 ∂prod 39 := by
  have h := restricted_le g reg MeasurableSet.univ (Set.subset_univ _)
  rwa [Measure.restrict_univ] at h

/-! ## Middle groups -/

/-- `SlackBudget.middle_mass` from the floor and `middleRaw` alone. -/
theorem middle_mass (floor : (94.17312 : ℝ) ≤ 100^39 * originalMass)
    (raw : ∀ i : Fin 22, (100:ℝ)^39 * StructuralRun.layerMass (middle i) ≤ (SlackRows.absolute i : ℝ))
    (i : Fin 22) :
    StructuralRun.layerMass (middle i) ≤ RestorationRows.ticks (SlackRows.rows i).mass * originalMass := by
  have cap : (SlackRows.absolute i : ℝ) ≤ RestorationRows.ticks (SlackRows.rows i).mass * 94.17312 := by
    unfold RestorationRows.ticks
    have h := (Rat.cast_le (K := ℝ)).mpr (SlackRows.absolute_price i)
    push_cast at h
    rw [show (94.17312 : ℝ) = 9417312/100000 by norm_num]
    exact h
  have nn : 0 ≤ RestorationRows.ticks (SlackRows.rows i).mass := by unfold RestorationRows.ticks; positivity
  have h := (raw i).trans (cap.trans (mul_le_mul_of_nonneg_left floor nn))
  apply le_of_mul_le_mul_left (a := (100:ℝ)^39) _ (by positivity)
  linarith only [h]

theorem joint_rows : ∀ i : Fin 22, 20000*(RestorationRows.rows i).joint + (SlackRows.rows i).mass + 25000000 ≤
    20000*(SlackRows.rows i).joint := by
  decide +kernel

theorem pair_rows : ∀ i : Fin 22, 59856*(RestorationRows.rows i).pairImage + 12900 ≤
    46400*(SlackRows.rows i).pairImage := by
  decide +kernel

theorem joint_key (i : Fin 22) :
    RestorationRows.ticks (RestorationRows.rows i).joint + (1/20000)*RestorationRows.ticks (SlackRows.rows i).mass +
      20000*(0.00000025:ℝ)^2 ≤ RestorationRows.ticks (SlackRows.rows i).joint := by
  have h : (20000:ℝ)*(RestorationRows.rows i).joint + (SlackRows.rows i).mass + 25000000 ≤
      20000*(SlackRows.rows i).joint := by exact_mod_cast joint_rows i
  unfold RestorationRows.ticks
  norm_num
  linarith only [h]

theorem pair_key (i : Fin 22) :
    (1+29/100)*RestorationRows.ticks (RestorationRows.rows i).pairImage + (1+1/(29/100))*(0.00000025:ℝ)^2 ≤
      RestorationRows.ticks (SlackRows.rows i).pairImage := by
  have h : (59856:ℝ)*(RestorationRows.rows i).pairImage + 12900 ≤ 46400*(SlackRows.rows i).pairImage := by
    exact_mod_cast pair_rows i
  unfold RestorationRows.ticks
  norm_num
  linarith only [h]

private theorem nonnegative : 0 ≤ originalMass := integral_nonneg fun _ => sq_nonneg _

/-- The pair bridge: superset, bank, the (1+λ) step with λ = 0.29, and the transfer. -/
theorem pair_bound {P : Full → ℝ} {ν : Fin 22 → Measure Full} {E : Fin 22 → Set Full}
    (c : MiddlePair P ν E) (i : Fin 22) :
    restrictedSq (middle i) negativePair ≤
      (1+29/100)*(RestorationRows.ticks (RestorationRows.rows i).pairImage * originalMass) +
      (1+1/(29/100))*((0.00000025:ℝ)^2 * originalMass) := by
  have := c.finite i
  have s := restricted_le (middle i) pair_reg' (c.measurable i) (c.superset i)
  have sp := split ((prod 39).restrict (E i)) pair_reg' c.regular (l := 29/100) (by norm_num)
  have bank : ∫ x in E i, (P x)^2 ∂prod 39 ≤ ∫ x in E i, (P x)^2 ∂ν i :=
    sq_mono (Measure.restrict_mono subset_rfl (c.bank i)) c.regular
  have whole : ∫ x in E i, (negativePair x - P x)^2 ∂prod 39 ≤ ∫ x, (negativePair x - P x)^2 ∂prod 39 :=
    sq_mono Measure.restrict_le_self (sub_reg pair_reg' c.regular)
  calc
    _ ≤ _ := s
    _ ≤ _ := sp
    _ ≤ _ := add_le_add (mul_le_mul_of_nonneg_left (bank.trans (c.worker i)) (by norm_num))
      (mul_le_mul_of_nonneg_left (whole.trans c.transfer) (by norm_num))

theorem middlePair {P : Full → ℝ} {ν : Fin 22 → Measure Full} {E : Fin 22 → Set Full}
    (c : MiddlePair P ν E) (i : Fin 22) :
    restrictedSq (middle i) negativePair ≤ RestorationRows.ticks (SlackRows.rows i).pairImage * originalMass :=
  calc
    _ ≤ _ := pair_bound c i
    _ = ((1+29/100)*RestorationRows.ticks (RestorationRows.rows i).pairImage +
          (1+1/(29/100))*(0.00000025:ℝ)^2) * originalMass := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_right (pair_key i) nonnegative

/-- The joint bridge: Schur domination, then the Young step with t = 1/20000 on the
singles difference, and the transfer. -/
theorem joint_bound {V : Full → ℝ} {S : Fin 22 → Full → ℝ} (c : MiddleJoint V S) (i : Fin 22) {D : ℝ}
    (hD : StructuralRun.layerMass (middle i) ≤ D * originalMass) :
    joint (middle i) ≤ RestorationRows.ticks (RestorationRows.rows i).joint * originalMass +
      (1/20000)*(D * originalMass) + 20000*((0.00000025:ℝ)^2 * originalMass) := by
  have fr : Regular (GateDeletion.layer (.group (middle i))) := layer_regular _
  have sq := continuous_reg fr (fun z => z^2) (by fun_prop)
  have weight : weightGroup (middle i) ≤
      ∫ x, S i x * (GateDeletion.layer (.group (middle i)) x)^2 ∂prod 39 := by
    unfold weightGroup
    apply integral_mono (intg _ (prod_reg multiplier_reg sq)) (intg _ (prod_reg (c.schurRegular i) sq))
    intro x
    change multiplier x * (GateDeletion.layer (.group (middle i)) x)^2 ≤
      S i x * (GateDeletion.layer (.group (middle i)) x)^2
    by_cases z : GateDeletion.layer (.group (middle i)) x = 0
    · rw [z]; norm_num
    · exact mul_le_mul_of_nonneg_right (c.schur i x z) (sq_nonneg _)
  have W := sub_reg singles_reg c.regular
  have cross : (∫ x, GateDeletion.layer (.group (middle i)) x * singles x ∂prod 39) =
      (∫ x, GateDeletion.layer (.group (middle i)) x * V x ∂prod 39) +
      ∫ x, GateDeletion.layer (.group (middle i)) x * (singles x - V x) ∂prod 39 := by
    rw [←integral_add (intg _ (prod_reg fr c.regular)) (intg _ (prod_reg fr W))]
    apply integral_congr_ae
    apply ae_of_all
    intro x
    try dsimp only
    ring
  have y := young (middle i) (fun x => singles x - V x) W (1/20000) (by norm_num)
  have r := restricted_le_full (middle i) W
  have t := c.transfer
  have w := c.worker i
  have hM := nonnegative
  norm_num only at y
  unfold joint
  rw [cross]
  linarith only [y,r,t,w,weight,hD,hM]

theorem middleJoint {V : Full → ℝ} {S : Fin 22 → Full → ℝ} (c : MiddleJoint V S)
    (floor : (94.17312 : ℝ) ≤ 100^39 * originalMass)
    (raw : ∀ i : Fin 22, (100:ℝ)^39 * StructuralRun.layerMass (middle i) ≤ (SlackRows.absolute i : ℝ))
    (i : Fin 22) :
    joint (middle i) ≤ RestorationRows.ticks (SlackRows.rows i).joint * originalMass :=
  calc
    _ ≤ _ := joint_bound c i (middle_mass floor raw i)
    _ = (RestorationRows.ticks (RestorationRows.rows i).joint +
          (1/20000)*RestorationRows.ticks (SlackRows.rows i).mass + 20000*(0.00000025:ℝ)^2) * originalMass := by
      ring
    _ ≤ _ := mul_le_mul_of_nonneg_right (joint_key i) nonnegative

/-! ## Outer images -/

theorem low_key : (1+1/10)*RestorationRows.ticks 1196124 +
    (1+1/(1/10))*(0.00000024726961 + 0.0000000005881:ℝ)^2 ≤ RestorationRows.ticks 1375543 := by
  unfold RestorationRows.ticks
  norm_num

theorem high_key : (1+1/10)*RestorationRows.ticks 179904296 + (1+1/(1/10))*(0.00000024726961:ℝ)^2 ≤
    RestorationRows.ticks 206889941 := by
  unfold RestorationRows.ticks
  norm_num

/-- The low bridge: `RestorationOuterEnergy.low_field`, the region containment, and the
(1+λ) step with λ = 1/10. -/
theorem lowImage {G : Full → ℝ} {E : Set Full} (c : LowImage G E) :
    imageSq 0 ≤ RestorationRows.ticks 1375543 * originalMass := by
  have r : imageSq 0 ≤ ∫ x in RestorationOuterEnergy.lowRegion, (RestorationField.field x)^2 ∂prod 39 :=
    RestorationOuterEnergy.low_field
  have m := sq_mono (Measure.restrict_mono c.region (le_refl (prod 39))) RestorationField.field_reg
  have sp := split ((prod 39).restrict E) RestorationField.field_reg c.regular (l := 1/10) (by norm_num)
  calc
    _ ≤ _ := r.trans (m.trans sp)
    _ ≤ (1+1/10)*(RestorationRows.ticks 1196124 * originalMass) +
          (1+1/(1/10))*((0.00000024726961 + 0.0000000005881:ℝ)^2 * originalMass) :=
      add_le_add (mul_le_mul_of_nonneg_left c.worker (by norm_num))
        (mul_le_mul_of_nonneg_left c.transfer (by norm_num))
    _ = ((1+1/10)*RestorationRows.ticks 1196124 +
          (1+1/(1/10))*(0.00000024726961 + 0.0000000005881:ℝ)^2) * originalMass := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_right low_key nonnegative

section high

/-- The high bridge: `RestorationOuterEnergy.high_field`, the region containment, and the
(1+λ) step with λ = 1/10. -/
theorem highImage {G : Full → ℝ} {E : Set RemovedHighMass.Config} (c : HighImage G E) :
    imageSq 23 ≤ RestorationRows.ticks 206889941 * originalMass := by
  let := fragmentLaw_isProbabilityMeasure cap
  let : IsFiniteMeasure (NativeSiteLaw.phys cap) := (fragmentLaw cap).smul_finite (by simp)
  let : IsFiniteMeasure RemovedHighMass.law := by unfold RemovedHighMass.law; infer_instance
  have fb : Regular (fun X : RemovedHighMass.Config => RestorationField.field (RemovedHighMass.bands X)) :=
    comp RestorationField.field_reg meas_bands
  have gb : Regular (fun X : RemovedHighMass.Config => G (RemovedHighMass.bands X)) := comp c.regular meas_bands
  have r := RestorationOuterEnergy.high_field
  have m := sq_mono (Measure.restrict_mono c.region (le_refl RemovedHighMass.law)) fb
  have sp := split (RemovedHighMass.law.restrict E) fb gb (l := 1/10) (by norm_num)
  calc
    _ ≤ _ := r.trans (m.trans sp)
    _ ≤ (1+1/10)*(RestorationRows.ticks 179904296 * originalMass) +
          (1+1/(1/10))*((0.00000024726961:ℝ)^2 * originalMass) :=
      add_le_add (mul_le_mul_of_nonneg_left c.worker (by norm_num))
        (mul_le_mul_of_nonneg_left c.transfer (by norm_num))
    _ = ((1+1/10)*RestorationRows.ticks 179904296 + (1+1/(1/10))*(0.00000024726961:ℝ)^2) * originalMass := by
      ring
    _ ≤ _ := mul_le_mul_of_nonneg_right high_key nonnegative

end high

/-! ## Assembly -/

/-- The certified inputs, with the floor, the two outer masses and `middleRaw`, give the
slack restoration bounds. -/
theorem bounds (floor : (94.17312 : ℝ) ≤ 100^39 * originalMass)
    (lowMass : StructuralRun.layerMass 0 ≤ (RemovalReceipts.low : ℝ) * originalMass)
    (highMass : StructuralRun.layerMass 23 ≤ RestorationRows.ticks 4135470 * originalMass)
    (raw : ∀ i : Fin 22, (100:ℝ)^39 * StructuralRun.layerMass (middle i) ≤ (SlackRows.absolute i : ℝ))
    (low : ∃ (G : Full → ℝ) (E : Set Full), LowImage G E)
    (high : ∃ (G : Full → ℝ) (E : Set RemovedHighMass.Config), HighImage G E)
    (pair : ∃ (P : Full → ℝ) (ν : Fin 22 → Measure Full) (E : Fin 22 → Set Full), MiddlePair P ν E)
    (jointC : ∃ (V : Full → ℝ) (S : Fin 22 → Full → ℝ), MiddleJoint V S) : SlackBudget.Bounds := by
  obtain ⟨_,_,cl⟩ := low
  obtain ⟨_,_,ch⟩ := high
  obtain ⟨_,_,_,cp⟩ := pair
  obtain ⟨_,_,cj⟩ := jointC
  exact ⟨floor,lowMass,highMass,lowImage cl,highImage ch,raw,middlePair cp,middleJoint cj floor raw⟩

#print axioms middlePair
#print axioms middleJoint
#print axioms lowImage
#print axioms highImage
#print axioms bounds
end PrimeGap180.CertifiedBudget
