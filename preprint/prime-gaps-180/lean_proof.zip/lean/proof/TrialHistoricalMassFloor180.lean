import TrialHistoricalDebit180

noncomputable section
open scoped BigOperators
open PrimeGap180.DebitNativeClasses PrimeGap180.DebitWeights PrimeGap180.PackedLaw
open PrimeGap180.PackedSiteAudit PrimeGap180.LiftedBins PrimeGap180.RootVectorDistance
namespace PrimeGap180.HistoricalDebit
set_option maxRecDepth 6000
set_option maxHeartbeats 1600000

private theorem physical_mass : NumericalAccount.mass Restoration.original = massN physical := by
  have bins : BinComparison atom index physical := by
    refine ⟨fun _ => rfl,nn,fun _ _ => rfl,?_,?_⟩
    · intro b
      split
      · exact (mul_le_mul_of_nonneg_right (by norm_num : (1-0.00002:ℝ) ≤ 1) (nn b)).trans_eq (one_mul _)
      · exact (one_mul _).le
    · intro b
      split
      · exact (one_mul _).symm.le.trans (mul_le_mul_of_nonneg_right (by norm_num : (1:ℝ) ≤ 1.00002) (nn b))
      · exact (one_mul _).symm.le
  have same : liftNative atom physical = CoarseLaw.weight := by
    funext z
    by_cases h : physicalBin atom (atom z)=0 <;> simp [liftNative,stretch,physical,h]
  rw [true_mass,←same,DebitNativeClasses.mass_eq physical bins]

theorem mass_lower (g : Grid) (L U : Atom → ℚ) (B : PackedMetrics.Boxes g L U) :
    lo^39 * massN (law g) ≤ NumericalAccount.mass Restoration.original := by
  rw [physical_mass]
  unfold massN
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro t _
  by_cases off : rawAtom t=0
  · simp [off]
  have live_site (i : Fin 39) := live_of_raw t off i
  have h := Finset.prod_le_prod (s := (Finset.univ : Finset (Fin 39)))
    (fun i _ => mul_nonneg (by norm_num [lo] : 0 ≤ lo) ((PackedMetrics.live_bins g L U B).nonnegative _ (live_site i)))
    (fun i _ => (PackedMetrics.ratio g L U B (t i) (live_site i)).1)
  simp only [Finset.prod_mul_distrib,Finset.prod_const,Finset.card_univ,Fintype.card_fin] at h
  calc
    _ = (rawAtom t)^2*(lo^39*∏ i, law g (t i)) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_left h (sq_nonneg _)

/-- The native mass lower bound used for the original debit also supplies the
physical mass floor required by the deletion estimates. -/
theorem physical_floor (mass : DebitRoleBounds.massFloor ≤ NativeRoleTotals.ordinary grid) :
    94.17312 ≤ (100:ℝ)^39 * NumericalAccount.mass Restoration.original := by
  have h := mass_lower grid _ _ (ShardScore.shard_boxes gridChunks gridSchema)
  rw [←NativeRoleTotals.mass_eq,ReferenceRoles.mass_scale] at mass
  have cut : (94.17312:ℝ) ≤ lo^39*DebitRoleBounds.massFloor := by
    norm_num [lo,DebitRoleBounds.massFloor]
  calc
    _ ≤ lo^39*DebitRoleBounds.massFloor := cut
    _ ≤ lo^39*(100^39*massN (law grid)) := mul_le_mul_of_nonneg_left mass (by norm_num [lo])
    _ = (100:ℝ)^39*(lo^39*massN (law grid)) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_left h (by norm_num)

#print axioms physical_floor
end PrimeGap180.HistoricalDebit
