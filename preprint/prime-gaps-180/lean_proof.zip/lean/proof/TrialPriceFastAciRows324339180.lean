import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G324
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 324

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G324

namespace PrimeGap180.PriceIsolatedGroup.G329
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 329

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G329

namespace PrimeGap180.PriceIsolatedGroup.G334
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 334

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G334

namespace PrimeGap180.PriceIsolatedGroup.G339
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 339

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G339
