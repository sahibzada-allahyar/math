import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G404
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 404

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G404

namespace PrimeGap180.PriceIsolatedGroup.G409
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 409

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G409
