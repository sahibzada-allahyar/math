import TrialDensityMomentFormula180
import TrialDensitySimplexIntegrals180
import Mathlib.Algebra.Ring.GeomSum

noncomputable section
open MeasureTheory Set
open scoped BigOperators ENNReal
namespace PrimeGap180.DensitySimplex

/-- The physical five-exponent domain is precisely the domain of the moment formula. -/
theorem cone5_region (a : ℝ) : cone5 a = region 4 (5*a-2) := by
  ext z
  simp [cone5, region, Fin.forall_fin_succ, Fin.sum_univ_four, and_assoc]

/-- Evaluate a finite polynomial from its coefficients on a simplex of any dimension. -/
theorem polynomial_integral {d : ℕ} {ι : Type*} (s : Finset ι) (c : ι → ℝ)
    (p : ι → Fin d → ℕ) (t : ℝ) (ht : 0 < t) :
    (∫ x in region d t, ∑ j ∈ s, c j * monomial (p j) x) =
      ∑ j ∈ s, c j * (t^(d+∑ i, p j i) * (∏ i, ((p j i).factorial : ℝ))
        / ((d+∑ i, p j i).factorial:ℝ)) := by
  rw [integral_finsetSum s (fun j _ => (monomial_integrable (p j) t).const_mul (c j))]
  apply Finset.sum_congr rfl
  intro j _
  rw [integral_const_mul, ← moment, moment_value (p j) t ht]

/-- Uniform geometric-series error for the reciprocal of the normalized denominator. -/
theorem reciprocal_error (P q : ℝ) (n : ℕ) (hq : q < 1) (hP : |1-P| ≤ q) :
    |P⁻¹ - ∑ j ∈ Finset.range n, (1-P)^j| ≤ q^n / (1-q) := by
  have hlow : 1-q ≤ P := by linarith [(abs_le.mp hP).2]
  have hpos : 0 < P := by linarith
  have g := geom_sum_mul_neg (1-P) n
  rw [show 1-(1-P) = P by ring] at g
  have identity : P⁻¹ - ∑ j ∈ Finset.range n, (1-P)^j = (1-P)^n / P := by
    apply (eq_div_iff hpos.ne').mpr
    rw [sub_mul, inv_mul_cancel₀ hpos.ne', g]
    ring
  rw [identity, abs_div, abs_pow, abs_of_pos hpos]
  exact (div_le_div_of_nonneg_right (pow_le_pow_left₀ (abs_nonneg _) hP n) hpos.le).trans
    (div_le_div_of_nonneg_left (pow_nonneg ((abs_nonneg _).trans hP) n) (by linarith) hlow)

#print axioms cone5_region
#print axioms polynomial_integral
#print axioms reciprocal_error
end PrimeGap180.DensitySimplex
