import TrialContinuumGap180
import TrialEndpointReindex180
import Lean.Elab.Term
import Lean.Data.Json

/-! The terminal criterion with the actual signed integer prices and both
ordinary-unit charges computed on the same restored trial. -/
noncomputable section
open scoped BigOperators Classical Topology
open Filter MeasureTheory PrimeGap186 PrimeGap182Analytic PrimeGap180.Distribution
open PrimeGap180.Sector PrimeGap180.Price PrimeGap180.EndpointPhysical
namespace PrimeGap180.Detection

/-- Elaborate the archived integer pairs as a literal. The parser checks
the denominator, number of labels, sign and unused third coordinate. -/
private def decodeRows (raw : String) : Except String (Array (Int × Int)) := do
  let doc ← Lean.Json.parse raw
  let unit ← (← doc.getObjVal? "scale").getNat?
  if unit != 10^14 then throw "unexpected sector-price scale"
  let rows ← (← doc.getObjVal? "sector_prices").getArr?
  if rows.size != 521 then throw "expected 521 sector prices"
  rows.mapM fun row => do
    let #[a,b,c] := ← row.getArr? | throw "expected a price triple"
    let intercept ← a.getInt?
    let slope ← b.getInt?
    if slope > 0 || (← c.getInt?) != 0 then throw "invalid sector-price encoding"
    return (intercept,slope)

open Lean Elab Term in
elab "archiveRows% " t:term : term => do
  let e ← elabTermEnsuringType t (mkConst ``String)
  let .lit (.strVal raw) := e.consumeMData | throwError "expected a literal archive"
  let table ← IO.ofExcept (decodeRows raw)
  return toExpr table

private def archivedRows : Array (Int × Int) :=
  archiveRows% (include_str "../data/repriced_covers.json")

set_option maxRecDepth 4096 in
private theorem archived_count : archivedRows.size = 521 := by rfl

set_option maxRecDepth 4096 in
def archivedPrice (s : Fin 521) : Int × Int :=
  archivedRows[s.val]'(by rw [archived_count]; exact s.isLt)

def shiftIncome {m : ℕ} (a : Fin (m+2) → ℝ) (F : Profile 39 m)
    (i : Fin 39) (label : (Fin 38 → Band m) → Fin 521) : ℝ :=
  (∑ s : Fin 521,
    let V := integralFace a i (restrictFace i (fun t => label t = s) F)
    let E := ∫ t, (V t)^2 ∂Measure.pi (fun _ => bandLaw a)
    let U := ∫ t, primePrice (retainedRadius t)*(V t)^2 ∂Measure.pi (fun _ => bandLaw a)
    (archivedPrice s).1*E + (archivedPrice s).2*U) / (10^14:ℝ)

def endpointCost {m : ℕ} (a : Fin (m+2) → ℝ) (F : Profile 39 m) : ℝ :=
  ∫ r, pairPrice r*(∫ l, ∫ h, F (join r l h) ∂bandLaw a ∂bandLaw a)^2
    ∂Measure.pi (fun _ : Fin 37 => bandLaw a)

/-- The only numerical premise is the strict margin for this one profile.
The only prime-count premise is its archived single-shift lower bound.
The endpoint and ordinary estimates both follow within the theorem. -/
theorem gap_of_archived_prices {m : ℕ} (a : Fin (m+2) → ℝ) (inc : StrictMono a)
    (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (F : Profile 39 m) (mf : Measurable F) (bf : Bornology.IsBounded (Set.range F))
    (cf : ∀ᵐ t ∂Measure.pi (fun _ => bandLaw a), ContinuousAt F t)
    (room : ∀ t, F t ≠ 0 → rho*(∑ i, ∑ j, t i j) ≤ radiusCap)
    (label : Fin 39 → (Fin 38 → Band m) → Fin 521)
    (margin : (∫ t, (F t)^2 ∂Measure.pi (fun _ => bandLaw a)) + endpointCost a F <
      rho * ∑ i : Fin 39, shiftIncome a F i (label i))
    (priced : ∀ i : Fin 39, Lower (fun x => ∑ n ∈ window x,
      (primeHit n (shifts i) * (if Nat.ModEq (presievingModulus tuple182 x) n (PhysicalPrices.progression x)
       then (markedScale tuple182 x)⁻¹ else 0)) *
       (sampledSelbergRoot (sample tuple182 a F x) (fun j => n+shifts j))^2)
      (shiftIncome a F i (label i)) primeScales) :
    PrimeGap186.primeGapLiminf ≤ (180 : EReal) := by
  apply gap_of_continuum_moments a inc first last F mf bf cf room _ _ margin priced
  intro ε he
  have raw := EndpointReindex.endpoint_same_profile tuple182 tuple182_card a inc first last F mf bf cf room ε he
  filter_upwards [primeScales_cofinal raw] with x est
  exact est (PhysicalPrices.progression x)

#print axioms gap_of_archived_prices
end PrimeGap180.Detection
