import TrialEnvelopePolynomial180
import TrialEnvelopeWeights180

/-! Range arithmetic directly on the frozen signed suffix coefficients and
the local cubic spline. Positive and negative slopes are bounded separately. -/
noncomputable section
open scoped BigOperators
namespace PrimeGap180.EnvelopeKernel
open EnvelopePolynomial FrozenProfile FrozenData
open private get archive Archive.suffix coefficient from TrialFrozenData180

def suffix (c : Fine) := get (Archive.suffix archive) c.val
def row (u : ℕ) (a b : Fin 3) (s : Fin 11) (k : ℕ) : ℚ :=
  ∑ l : Fin 3,if u ≤ l.val then coefficient (3*a.val+b.val) l.val s.val k else 0

/-- Only four cubic basis functions can be active on the panel. -/
def combine (p : Panel) (f : ℕ → ℚ) : ℕ → Coeffs
  | 0=>[]
  | k+1=>if k ≤ p.span ∧ p.span ≤ k+3 then
      plus (combine p f k) (times (f k) (basis p 3 k))
    else combine p f k

def sign (negative : Bool) : ℚ := if negative then -1 else 1
def norm (s : Fin 11) : ℚ := 39^((signatures s).sum-(signatures s).length)
def poly (p : Panel) (u : ℕ) (a b : Fin 3) (s : Fin 11) (negative : Bool) :=
  times (sign negative*norm s) (combine p (row u a b s) 30)

def radius : ℚ := 1399373467/1312494500

def cost (p : Panel) (u : ℕ) (ng : Bool) : ℕ :=
  ∑ a : Fin 3, ∑ b : Fin 3, ∑ s : Fin 11,
    ⌈EnvelopeAngular.weight (right p) radius a b s * max 0 (upper (poly p u a b s ng))⌉₊

end PrimeGap180.EnvelopeKernel
end

namespace PrimeGap180.EnvelopePanels
open EnvelopePolynomial

def atIndex : Fin 27 → Panel := ![
  ⟨102994,103040,9⟩,
  ⟨103041,103431,10⟩,
  ⟨103432,103821,10⟩,
  ⟨103822,104602,10⟩,
  ⟨104603,105383,10⟩,
  ⟨105384,106163,10⟩,
  ⟨106164,106944,10⟩,
  ⟨106945,107725,10⟩,
  ⟨107726,108506,10⟩,
  ⟨108507,109286,10⟩,
  ⟨109287,110848,11⟩,
  ⟨110849,112409,11⟩,
  ⟨112410,113971,11⟩,
  ⟨113972,115532,11⟩,
  ⟨115533,117752,12⟩,
  ⟨117753,117998,16⟩,
  ⟨117999,118934,17⟩,
  ⟨118935,120152,18⟩,
  ⟨120153,121744,19⟩,
  ⟨121745,122329,20⟩,
  ⟨122330,122915,21⟩,
  ⟨122916,123711,22⟩,
  ⟨123712,125022,23⟩,
  ⟨125023,125556,24⟩,
  ⟨125557,126427,28⟩,
  ⟨126428,128696,29⟩,
  ⟨128697,130964,29⟩]

end PrimeGap180.EnvelopePanels
