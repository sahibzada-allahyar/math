import TrialSourcePlanPrime180
import TrialSourcePlanSharp180
import TrialSourcePlanHigher00180
import TrialSourcePlanHigher01180
import TrialSourcePlanHigher02180
import TrialSourcePlanHigher03180
import TrialSourcePlanHigher04180
import TrialSourcePlanHigher05180
import TrialSourcePlanHigher06180
import TrialSourcePlanHigher07180
import TrialSourcePlanHigher08180
import TrialSourcePlanHigher09180
import TrialSourcePlanHigher10180
import TrialSourcePlanHigher11180

namespace PrimeGap180.SourcePlanBlocks

theorem checked (k : Book.Row) : Every k := by
  cases k with
  | prime => exact Prime.every
  | sharp => exact Sharp.every
  | higher i =>
    fin_cases i
    · exact Higher00.every
    · exact Higher01.every
    · exact Higher02.every
    · exact Higher03.every
    · exact Higher04.every
    · exact Higher05.every
    · exact Higher06.every
    · exact Higher07.every
    · exact Higher08.every
    · exact Higher09.every
    · exact Higher10.every
    · exact Higher11.every

#print axioms checked
end PrimeGap180.SourcePlanBlocks
