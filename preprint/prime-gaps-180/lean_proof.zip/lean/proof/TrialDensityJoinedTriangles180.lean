import TrialDensityTriangleR00180
import TrialDensityTriangleR01180
import TrialDensityTriangleR02180
import TrialDensityTriangleR03180
import TrialDensityTriangleR04180
import TrialDensityTriangleR05180
import TrialDensityTriangleR06180
import TrialDensityTriangleR07180
import TrialDensityTriangleR08180
import TrialDensityTriangleR09180
import TrialDensityTriangleR10180
import TrialDensityTriangleR11180
namespace PrimeGap180.DensitySimplex.Horner.TriangleChecks
theorem values (i : Fin 12) : triangleQ (r i) (s i) = FrozenNumbers.triangles i := by
  fin_cases i
  · exact row00
  · exact row01
  · exact row02
  · exact row03
  · exact row04
  · exact row05
  · exact row06
  · exact row07
  · exact row08
  · exact row09
  · exact row10
  · exact row11
#print axioms values
end PrimeGap180.DensitySimplex.Horner.TriangleChecks
