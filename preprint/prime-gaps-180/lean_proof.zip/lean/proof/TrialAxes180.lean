import TrialOffAxis180
import TrialScalarExceptions180

/-! Uniform transfer from the actual local scalar estimates on a fixed
rectangle to each global axis, summed over retained rectangles. -/
noncomputable section
open scoped BigOperators Classical
open PrimeGap182.TypeIII
namespace PrimeGap180.Prefix

def axisFirst {K : Type*} [Zero K] (vertical : Bool) (v : K) := if vertical then 0 else v
def axisSecond {K : Type*} [Zero K] (vertical : Bool) (v : K) := if vertical then v else 0

def localAxisBound (p : ℕ) [Fact p.Prime] (D : ℕ) (C : ℝ) (α : ZMod p)
    (vertical : Bool) : Prop :=
  ∀ m m' n n' : ZMod p, m ≠ 0 → m' ≠ 0 → n ≠ 0 → n' ≠ 0 →
    ∃ E : Finset (ZMod p), E.card ≤ D ∧ ∀ v,
      ‖fourier₂ p (fourCycle p α m m' n n') (axisFirst vertical v) (axisSecond vertical v)‖ ≤
        C*(p:ℝ)^3*(if ratioCollision m m' n n' then (p:ℝ) else
          if v ∈ E then Real.sqrt p else 1)

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

theorem axis_per_rectangle (q : ι → ℕ) [∀ i, Fact (q i).Prime] [NeZero (∏ i, q i)]
    (hc : Pairwise (fun i j => (q i).Coprime (q j))) (α : ∀ i, ZMod (q i))
    (D : ℕ) (hD : 1 ≤ D) (C : ℝ) (hC : 0 ≤ C) (vertical : Bool)
    (localB : ∀ i, localAxisBound (q i) D C (α i) vertical) (A B V : ℤ) (R : ℕ) (a : List ℕ) :
    let P := ∏ i, q i
    (∑ v : ZMod P, ‖fourier₂ P (tupleCycle q α A B a) (axisFirst vertical v) (axisSecond vertical v)‖ *
        ‖intervalFourier P V R v‖) ≤
      (C^Fintype.card ι * (P:ℝ)^3 * ((2*D:ℕ):ℝ)^Fintype.card ι *
        (2*R*Real.sqrt P + P*(1+Real.log P))) * factor q (collisionPrimes q A B a) := by
  classical
  intro P
  have hp : (1:ℝ) ≤ P := by exact_mod_cast (NeZero.one_le : 1 ≤ P)
  have hlog := Real.log_nonneg hp
  let K := C^Fintype.card ι * (P:ℝ)^3
  let T := ((2*D:ℕ):ℝ)^Fintype.card ι * (2*R*Real.sqrt P + P*(1+Real.log P))
  have hT : 0 ≤ T := by dsimp [T]; positivity
  have rightpos : 0 ≤ (C^Fintype.card ι * (P:ℝ)^3 * ((2*D:ℕ):ℝ)^Fintype.card ι *
        (2*R*Real.sqrt P + P*(1+Real.log P))) * factor q (collisionPrimes q A B a) := by positivity
  unfold tupleCycle
  split
  next w z y x =>
    let m := A+(x:ℤ)
    let m' := A+(y:ℤ)
    let n := B+(z:ℤ)
    let n' := B+(w:ℤ)
    let bad := collisionPrimes q A B [w,z,y,x]
    let d := factor q bad
    have eq := funext (fun a => funext (integerFourCycle_eq q α m m' n n' a))
    by_cases hu : unitIntegerIndex q m ∧ unitIntegerIndex q m' ∧ unitIntegerIndex q n ∧ unitIntegerIndex q n'
    · choose E hE hbound using fun i => localB i _ _ _ _
        (hu.1 i) (hu.2.1 i) (hu.2.2.1 i) (hu.2.2.2 i)
      let unit := crtFrequencyUnit q hc
      let u (i : ι) := ((unit i) : ZMod (q i))
      let inj (i : ι) : Function.Injective (fun t : ZMod (q i) => u i*t) :=
        mul_right_injective₀ (unit i).ne_zero
      let F (i : ι) := (E i).preimage (fun t => u i*t) (inj i).injOn
      have hF (i : ι) : (F i).card ≤ D := by
        dsimp [F]; rw [Finset.card_preimage]; exact (Finset.card_filter_le _ _).trans (hE i)
      have isbad (i : ι) : i ∈ bad ↔ ratioCollision (m : ZMod (q i)) m' n n' := by
        apply (collisionPrimes_mem q A B w z y x i).trans
        have h₁ := hu.1 i
        have h₂ := hu.2.1 i
        have h₃ := hu.2.2.1 i
        have h₄ := hu.2.2.2 i
        simp only [m, m', n, n', Int.cast_add, Int.cast_natCast] at *
        simp [h₁,h₂,h₃,h₄]
      have prodW (S : Finset ι) : (∏ i, if i ∈ S then (q i : ℝ) else 1) = (factor q S : ℝ) := by
        rw [← Finset.prod_filter]; simp [factor]
      have prodS (S : Finset ι) : (∏ i, if i ∈ S then Real.sqrt (q i) else 1) = Real.sqrt (factor q S) := by
        rw [← Finset.prod_filter]; simp [factor, Real.sqrt_prod _ (fun i _ => Nat.cast_nonneg (q i))]
      have one (v : ZMod P) :
          ‖fourier₂ P (integerFourCycle q α m m' n n') (axisFirst vertical v) (axisSecond vertical v)‖ ≤
            K*(d:ℝ)*Real.sqrt (factor q (scalarMask q F v.val)) := by
        simp only [ite_eq_left hu] at eq
        rw [eq, squarefreeFourCycle_eq_crtProduct, norm_fourier₂_crtProduct q hc]
        calc
          _ ≤ ∏ i, C*(q i:ℝ)^3*(if i ∈ bad then (q i:ℝ) else 1)*
                (if i ∈ scalarMask q F v.val then Real.sqrt (q i) else 1) := by
            apply Finset.prod_le_prod (fun _ _ => norm_nonneg _)
            intro i _
            have loc := hbound i (u i * (v.val : ZMod (q i)))
            have eq1 : (u i)*((axisFirst vertical v).val : ZMod (q i)) =
                axisFirst vertical (u i * (v.val : ZMod (q i))) := by cases vertical <;> simp [axisFirst]
            have eq2 : (u i)*((axisSecond vertical v).val : ZMod (q i)) =
                axisSecond vertical (u i * (v.val : ZMod (q i))) := by cases vertical <;> simp [axisSecond]
            rw [eq1, eq2]
            apply loc.trans
            have heq : i ∈ scalarMask q F v.val ↔ u i * (v.val : ZMod (q i)) ∈ E i := by simp [scalarMask,F]
            have h1 : (1:ℝ) ≤ q i := by exact_mod_cast (Fact.out : (q i).Prime).one_le
            by_cases b : i ∈ bad <;> by_cases e : i ∈ scalarMask q F v.val
            all_goals simp only [← (isbad i), ← heq, b, e, ite_true, ite_false, mul_one]
            all_goals first | exact le_rfl | exact le_mul_of_one_le_right (by positivity) (by simpa using Real.sqrt_le_sqrt h1)
          _ = _ := by
            simp only [Finset.prod_mul_distrib, Finset.prod_const, Finset.card_univ, Finset.prod_pow,
              ← Nat.cast_prod, prodW, prodS]
            rfl
      calc
        _ ≤ ∑ v : ZMod P, K*(d:ℝ)*Real.sqrt (factor q (scalarMask q F v.val)) * ‖intervalFourier P V R v‖ :=
          Finset.sum_le_sum fun v _ => mul_le_mul_of_nonneg_right (one v) (norm_nonneg _)
        _ = K*(d:ℝ) * ∑ v : ZMod P, Real.sqrt (factor q (scalarMask q F v.val))*‖intervalFourier P V R v‖ := by
          simp only [Finset.mul_sum, mul_assoc]
        _ ≤ K*(d:ℝ)*T := mul_le_mul_of_nonneg_left (scalar_mask_mass q hc F D hD hF V R)
          (by dsimp [K]; positivity)
        _ = _ := by dsimp only [K,d,bad,T]; ring
    · simp only [ite_eq_right hu] at eq
      rw [eq]
      simpa [fourier₂] using rightpos
  next => simpa [fourier₂] using rightpos

#print axioms axis_per_rectangle
end PrimeGap180.Prefix
