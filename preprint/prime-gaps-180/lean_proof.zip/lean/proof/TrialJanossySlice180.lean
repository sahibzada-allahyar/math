import TrialPoissonSplit180
import Batteries.Tactic.OpenPrivate
import Mathlib.Analysis.SpecialFunctions.Exponential

/-! The unnormalized positive-count Janossy radial density has a simple
majorant. Cancel one of the reciprocal mark weights using the total, then
drop the sum restriction on the remaining marks; their mass is log(r/e)^n. -/
noncomputable section
open scoped Classical BigOperators ENNReal
open MeasureTheory
namespace PrimeGap180.JanossySlice

/-- Multiplication by the total cancels one of the unordered reciprocal mark factors. -/
theorem cancel_coordinate {n : ℕ} (x : Fin n → ℝ) (pos : ∀ i,0<x i) :
    (∑ i,x i)*(∏ j,(x j)⁻¹) = ∑ i,∏ j ∈ Finset.univ.erase i,(x j)⁻¹ := by
  rw [Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro i _
  rw [←Finset.mul_prod_erase Finset.univ (fun j=>(x j)⁻¹) (Finset.mem_univ i),←mul_assoc]
  simp [(pos i).ne']

/-- The physical compensated last mark is exactly Lebesgue on its mark interval. -/
theorem compensated {e b : ℝ} (he : 0<e) :
    (PoissonSplit.intensity e b).withDensity ENNReal.ofReal = volume.restrict (Set.Ioc e b) := by
  unfold PoissonSplit.intensity
  rw [←withDensity_mul _ (by fun_prop) (by fun_prop)]
  trans (volume.restrict (Set.Ioc e b)).withDensity 1
  · apply withDensity_congr_ae
    filter_upwards [ae_restrict_mem (μ:=volume) (measurableSet_Ioc (a:=e) (b:=b))] with x hx
    have pos := he.trans hx.1
    change ENNReal.ofReal (1/x)*ENNReal.ofReal x=1
    rw [←ENNReal.ofReal_mul (one_div_pos.mpr pos).le]
    simp [pos.ne']
  · exact withDensity_one

/-- Once the other marks total t, the last mark has unit Jacobian in the
total r. Both strict lower and inclusive upper endpoints are retained. -/
theorem translated {e b : ℝ} (he : 0<e) (t : ℝ) :
    (((PoissonSplit.intensity e b).withDensity ENNReal.ofReal).map (fun u=>u+t)) =
      volume.restrict (Set.Ioc (e+t) (b+t)) := by
  have pre : (fun u=>u+t) ⁻¹' Set.Ioc (e+t) (b+t)=Set.Ioc e b := by
    ext x
    simp
  rw [compensated he,←pre,←Measure.restrict_map (by fun_prop) measurableSet_Ioc,
    map_add_right_eq_self]

/-- Ordered free marks after integrating out a distinguished mark at fixed total.
The lost mark equals r - sum x. Working with intensity restricted to (e,r]
is exact on this section, since all marks are positive. -/
def slice (n : ℕ) (e b r : ℝ) :=
  {x : Fin n → ℝ | (∀ i,x i ∈ Set.Ioc e b) ∧ r - ∑ i,x i ∈ Set.Ioc e b}

theorem box {n : ℕ} {e b r : ℝ} (he : 0<e) {x : Fin n → ℝ} (hx : x ∈ slice n e b r)
    (i : Fin n) : x i∈Set.Ioc e r := by
  change (∀ i,x i∈Set.Ioc e b) ∧ r - ∑ i,x i∈Set.Ioc e b at hx
  refine ⟨(hx.1 i).1,?_⟩
  have one := Finset.single_le_sum (fun j _=>(he.trans (hx.1 j).1).le) (Finset.mem_univ i)
  linarith only [one,hx.2.1,he]

def part (n : ℕ) (e b r : ℝ) : ℝ :=
  (Measure.pi (fun _ : Fin n => PoissonSplit.intensity e r)).real (slice n e b r) / n.factorial / r

open private logmass from TrialPoissonSplit180

theorem part_le (n : ℕ) {e b r : ℝ} (he : 0<e) (hr : e≤r) :
    part n e b r ≤ Real.log (r/e)^n / n.factorial / r := by
  have hlog := Real.log_nonneg ((one_le_div he).mpr hr)
  letI : IsFiniteMeasure (PoissonSplit.intensity e r) := (PoissonSplit.jumps he hr).property
  have mass : PoissonSplit.intensity e r Set.univ=ENNReal.ofReal (Real.log (r/e)) := by
    rw [PoissonSplit.intensity,withDensity_apply _ MeasurableSet.univ,Measure.restrict_univ,logmass he hr]
  have univ : (Measure.pi (fun _ : Fin n=>PoissonSplit.intensity e r)).real Set.univ=Real.log (r/e)^n := by
    simp [Measure.real,Measure.pi_univ,mass,ENNReal.toReal_ofReal hlog]
  unfold part
  rw [←univ]
  exact div_le_div_of_nonneg_right (div_le_div_of_nonneg_right
    (measureReal_mono (μ:=Measure.pi (fun _ : Fin n=>PoissonSplit.intensity e r)) (Set.subset_univ _))
     (Nat.cast_nonneg _)) (he.trans_le hr).le

theorem sum_le {e b r : ℝ} (he : 0<e) (hr : e≤r) : ∑' n,part n e b r ≤ 1/e := by
  have hlog := Real.log_nonneg ((one_le_div he).mpr hr)
  have rr := he.trans_le hr
  have hp (n : ℕ) : 0 ≤ part n e b r := by
    unfold part
    positivity
  have summ := (Real.summable_pow_div_factorial (Real.log (r/e))).div_const r
  have bounded := (Summable.of_nonneg_of_le hp (fun n=>part_le n he hr) summ)
  calc
    _ ≤ ∑' n : ℕ,Real.log (r/e)^n/n.factorial/r := bounded.tsum_le_tsum (fun n=>part_le n he hr) summ
    _ = Real.exp (Real.log (r/e))/r := by
      rw [tsum_div_const,Real.exp_eq_exp_ℝ,NormedSpace.exp_eq_tsum_div]
    _ = 1/e := by rw [Real.exp_log (div_pos rr he)]; field_simp

#print axioms translated
#print axioms cancel_coordinate
#print axioms sum_le
end PrimeGap180.JanossySlice
