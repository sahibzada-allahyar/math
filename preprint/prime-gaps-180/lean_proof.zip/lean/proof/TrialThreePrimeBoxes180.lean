import PrimeGaps186

/-! Three-prime boxes at the ordinary distribution level. Adapted from
OpenAI PrimeGaps186's five-prime box proof (Apache License 2.0, retained in
tmp/prime-gap-upstream/LICENSE-OpenAI). Two interval-prime factors form the
divisor-bounded coefficient, and the third supplies Siegel–Walfisz. -/
noncomputable section
open scoped BigOperators Topology Classical
open Filter PrimeGap186
namespace PrimeGap180.Ordinary

theorem finite_three_prime_full_box_convolution (P : Fin 3 → Finset ℕ) :
    (∑ p ∈ Fintype.piFinset P, Finsupp.single (∏ i, p i) (1 : ℂ)) =
      finiteConvolution
        (∑ p ∈ Fintype.piFinset (fun i : Fin 2 => P i.castSucc),
          Finsupp.single (∏ i, p i) (1 : ℂ))
        (∑ n ∈ P 2, Finsupp.single n (1 : ℂ)) := by
  classical
  have hpi : Fintype.piFinset P =
      (P 2 ×ˢ Fintype.piFinset (fun i : Fin 2 => P i.castSucc)).map
        (Fin.snocEquiv (fun _ : Fin 3 => ℕ)).toEmbedding := by
    have hi : Fin.init P = (fun i : Fin 2 => P i.castSucc) := rfl
    have hl : Fin.last 2 = (2 : Fin 3) := rfl
    simpa only [Finset.filter_true, hi, hl] using
      Finset.filter_piFinset_eq_map_snocEquiv P (fun _ : Fin 2 → ℕ => True)
  rw [hpi, Finset.sum_map, Finset.sum_product, Finset.sum_comm]
  simp only [Equiv.toEmbedding_apply, Fin.snocEquiv_apply, Fin.prod_snoc]
  simp only [finiteConvolution, MonoidAlgebra.ofCoeff_sum,
    MonoidAlgebra.ofCoeff_single, Finset.sum_mul, Finset.mul_sum,
    MonoidAlgebra.single_mul_single, one_mul, MonoidAlgebra.coeff_sum,
    MonoidAlgebra.coeff_single]
  exact Finset.sum_comm

theorem three_prime_closed_box_bv_uniform_log_saving :
    ∀ A : ℝ, 0 < A →
      ∃ B K X : ℝ, 0 < B ∧ 0 < K ∧ Real.exp 100 ≤ X ∧
        ∀ x : ℝ, X ≤ x → ∀ L U : Fin 3 → ℝ,
          (∀ i, x ^ (1 / 10 : ℝ) ≤ L i ∧ L i ≤ U i ∧ U i ≤ 2 * L i) →
          x / 32 ≤ (∏ i, L i) → (∏ i, L i) ≤ 2 * x →
          ∀ h : ℕ, 0 < h →
          let P (i : Fin 3) := (Finset.Icc ⌈L i⌉₊ ⌊U i⌋₊).filter Nat.Prime
          (∑ q ∈ Finset.Ioc 0 ⌊Real.sqrt x / (Real.log x) ^ B⌋₊,
            ⨆ a : (ZMod q)ˣ,
              ‖fullDiscrepancy
                ((∑ p ∈ Fintype.piFinset P,
                  Finsupp.single (∏ i, p i) (1 : ℂ)).filter
                    (fun n : ℕ => Nat.Coprime n h)) q (a : ZMod q).val‖) ≤
            K * (h.divisors.card : ℝ) * x / (Real.log x) ^ A := by
  let G (x : ℝ) (z : (Fin 3 → ℝ) × (Fin 3 → ℝ)) : Prop :=
    (∀ i, x ^ (1 / 10 : ℝ) ≤ z.1 i ∧ z.1 i ≤ z.2 i ∧ z.2 i ≤ 2 * z.1 i) ∧
      x / 32 ≤ (∏ i, z.1 i) ∧ (∏ i, z.1 i) ≤ 2 * x
  let P (z : (Fin 3 → ℝ) × (Fin 3 → ℝ)) (i : Fin 3) :=
    (Finset.Icc ⌈z.1 i⌉₊ ⌊z.2 i⌋₊).filter Nat.Prime
  let M (x : ℝ) (z : (Fin 3 → ℝ) × (Fin 3 → ℝ)) : ℝ :=
    if G x z then ∏ i : Fin 2, z.1 i.castSucc else Real.sqrt x
  let N (x : ℝ) (z : (Fin 3 → ℝ) × (Fin 3 → ℝ)) : ℝ :=
    if G x z then z.1 2 else Real.sqrt x
  let α (x : ℝ) (z : (Fin 3 → ℝ) × (Fin 3 → ℝ)) : ℕ →₀ ℂ :=
    if G x z then ∑ p ∈ Fintype.piFinset (fun i : Fin 2 => P z i.castSucc),
      Finsupp.single (∏ i, p i) 1 else 0
  let β (x : ℝ) (z : (Fin 3 → ℝ) × (Fin 3 → ℝ)) : ℕ →₀ ℂ :=
    if G x z then ∑ n ∈ P z 2, Finsupp.single n 1 else 0
  have hxbase (x : ℝ) (hx : Real.exp 100 ≤ x) :
      32 ≤ x ∧ 1 ≤ Real.log x ∧ 1 ≤ x ^ (1 / 10 : ℝ) := by
    have hx0 : 0 < x := (Real.exp_pos 100).trans_le hx
    have he : (32 : ℝ) ≤ Real.exp 100 := by
      have := Real.add_one_le_exp (100 : ℝ)
      linarith
    have hx32 := he.trans hx
    refine ⟨hx32, ?_, Real.one_le_rpow (by linarith) (by norm_num)⟩
    have := (Real.le_log_iff_exp_le hx0).mpr hx
    linarith
  have hgeom (x : ℝ) (hx : Real.exp 100 ≤ x)
      (z : (Fin 3 → ℝ) × (Fin 3 → ℝ)) (hg : G x z) :
      (∀ i, 1 ≤ z.1 i) ∧
      (M x z * N x z = ∏ i, z.1 i) ∧
      x ^ (1 / 10 : ℝ) ≤ M x z ∧ x ^ (1 / 10 : ℝ) ≤ N x z ∧
      N x z ≤ x ^ (2 : ℝ) := by
    have hb := hxbase x hx
    have hL (i : Fin 3) : 1 ≤ z.1 i := hb.2.2.trans (hg.1 i).1
    have hM : x ^ (1 / 10 : ℝ) ≤ ∏ i : Fin 2, z.1 i.castSucc := by
      apply (hg.1 (0 : Fin 3)).1.trans
      have hs := Finset.prod_le_prod_of_subset_of_one_le
        (Finset.singleton_subset_iff.mpr (Finset.mem_univ (0 : Fin 2)))
        (fun i _ => (zero_le_one.trans (hL i.castSucc)))
        (fun i _ _ => hL i.castSucc)
      simpa only [Finset.prod_singleton,
        show (0 : Fin 2).castSucc = (0 : Fin 3) from rfl] using hs
    have hprod : (∏ i : Fin 2, z.1 i.castSucc) * z.1 2 = ∏ i, z.1 i := by
      simpa only [show Fin.last 2 = (2 : Fin 3) from rfl] using
        (Fin.prod_univ_castSucc (n := 2) z.1).symm
    have hNone : z.1 2 ≤ ∏ i, z.1 i := by
      have hs := Finset.prod_le_prod_of_subset_of_one_le
        (Finset.singleton_subset_iff.mpr (Finset.mem_univ (2 : Fin 3)))
        (fun i _ => zero_le_one.trans (hL i)) (fun i _ _ => hL i)
      simpa only [Finset.prod_singleton] using hs
    refine ⟨hL, ?_, ?_, ?_, ?_⟩
    · simpa only [M, N, ite_eq_left hg] using hprod
    · simpa only [M, ite_eq_left hg] using hM
    · simpa only [N, ite_eq_left hg] using (hg.1 2).1
    · simp only [N, ite_eq_left hg, Real.rpow_two]
      nlinarith [hNone.trans hg.2.2]
  have hscale : ∀ x : ℝ, Real.exp 100 ≤ x → ∀ z,
      x / 32 ≤ M x z * N x z ∧ M x z * N x z ≤ 32 * x ∧
      x ^ (1 / 10 : ℝ) ≤ M x z ∧ x ^ (1 / 10 : ℝ) ≤ N x z := by
    intro x hx z
    have hb := hxbase x hx
    by_cases hg : G x z
    · obtain ⟨hL, hprod, hM, hN, hNU⟩ := hgeom x hx z hg
      refine ⟨?_, ?_, hM, hN⟩
      · rw [hprod]; exact hg.2.1
      · rw [hprod]; nlinarith [hg.2.2]
    · have hs : x ^ (1 / 10 : ℝ) ≤ Real.sqrt x := by
        rw [Real.sqrt_eq_rpow]
        exact Real.rpow_le_rpow_of_exponent_le (by linarith) (by norm_num)
      simp only [M, N, ite_eq_right hg, Real.mul_self_sqrt (by linarith : 0 ≤ x)]
      exact ⟨by linarith, by linarith, hs, hs⟩
  have hP (z : (Fin 3 → ℝ) × (Fin 3 → ℝ)) (i : Fin 3) (p : ℕ)
      (hp : p ∈ P z i) : 0 < p := (Finset.mem_filter.mp hp).2.pos
  have hbeta (z : (Fin 3 → ℝ) × (Fin 3 → ℝ)) :
      (∑ n ∈ P z 2, Finsupp.single n (1 : ℂ)) =
      ∑ n ∈ Finset.Icc ⌈z.1 2⌉₊ ⌊z.2 2⌋₊,
        Finsupp.single n (if Nat.Prime n then (1 : ℂ) else 0) := by
    rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro n hn
    split_ifs <;> simp
  have hsupport : ∀ x : ℝ, Real.exp 100 ≤ x → ∀ z,
      (∀ n ∈ (α x z).support, 1 * M x z ≤ (n : ℝ) ∧ (n : ℝ) ≤ 32 * M x z) ∧
      (∀ n ∈ (β x z).support, 1 * N x z ≤ (n : ℝ) ∧ (n : ℝ) ≤ 32 * N x z) := by
    intro x hx z
    by_cases hg : G x z
    · have hL := (hgeom x hx z hg).1
      have hcoord (i : Fin 3) (p : ℕ) (hp : p ∈ P z i) :
          z.1 i ≤ (p : ℝ) ∧ (p : ℝ) ≤ 2 * z.1 i := by
        have hm := Finset.mem_filter.mp hp
        refine ⟨(Nat.le_ceil _).trans (Nat.cast_le.mpr (Finset.mem_Icc.mp hm.1).1), ?_⟩
        exact ((Nat.le_floor_iff' hm.2.ne_zero).mp (Finset.mem_Icc.mp hm.1).2).trans
          (hg.1 i).2.2
      constructor
      · intro n hn
        have hn' : n ∈ (∑ p ∈ Fintype.piFinset (fun i : Fin 2 => P z i.castSucc),
            Finsupp.single (∏ i, p i) (1 : ℂ)).support := by
          simpa only [α, ite_eq_left hg] using hn
        obtain ⟨p, hp, rfl⟩ :=
          (finite_positive_tuple_coefficient_support_and_bound
            (fun i : Fin 2 => P z i.castSucc) (fun i => hP z i.castSucc)).1 n hn'
        have hpcoord (i : Fin 2) := hcoord i.castSucc (p i) (Fintype.mem_piFinset.mp hp i)
        simp only [M, ite_eq_left hg, one_mul, Nat.cast_prod]
        constructor
        · exact Finset.prod_le_prod (fun i _ => (by linarith [hL i.castSucc]))
            (fun i _ => (hpcoord i).1)
        · have hu : (∏ i : Fin 2, (p i : ℝ)) ≤
              ∏ i : Fin 2, 2 * z.1 i.castSucc :=
            Finset.prod_le_prod (fun i _ => Nat.cast_nonneg _) (fun i _ => (hpcoord i).2)
          have hprod0 : 0 ≤ ∏ i : Fin 2, z.1 i.castSucc :=
            Finset.prod_nonneg fun i _ => (by linarith [hL i.castSucc])
          simpa only [Finset.prod_mul_distrib, Finset.prod_const, Finset.card_univ,
            Fintype.card_fin, show (2 : ℝ) ^ 2 = 4 by norm_num] using
            hu.trans (by
              rw [Finset.prod_mul_distrib]
              simp only [Finset.prod_const, Finset.card_univ, Fintype.card_fin]
              nlinarith)
      · intro n hn
        have hn' : n ∈ (∑ p ∈ P z 2, Finsupp.single p (1 : ℂ)).support := by
          simpa only [β, ite_eq_left hg] using hn
        obtain ⟨p, hp, hsingle⟩ := Finsupp.mem_support_finsetSum n hn'
        have heq := (Finsupp.mem_support_single n p (1 : ℂ)).mp hsingle
        rcases heq with ⟨rfl, h1⟩
        have hc := hcoord 2 n hp
        simp only [N, ite_eq_left hg, one_mul]
        exact ⟨hc.1, by linarith [hc.2, hL 2]⟩
    · simp only [α, β, ite_eq_right hg, Finsupp.support_zero, Finset.notMem_empty,
        false_implies, implies_true, and_self]
  have hcoeff : ∀ x : ℝ, Real.exp 100 ≤ x → ∀ z, ∀ n : ℕ,
      ‖α x z n‖ ≤ 1 * (n.divisors.card : ℝ) ^ 2 * (Real.log x) ^ 2 ∧
      ‖β x z n‖ ≤ 1 * (n.divisors.card : ℝ) ^ 2 * (Real.log x) ^ 2 := by
    intro x hx z n
    have hlog := (hxbase x hx).2.1
    have hlogpow : 1 ≤ (Real.log x) ^ 2 := one_le_pow₀ hlog
    have hα := (finite_positive_tuple_coefficient_support_and_bound
      (fun i : Fin 2 => P z i.castSucc) (fun i => hP z i.castSucc)).2 n
    by_cases hg : G x z
    · simp only [α, β, ite_eq_left hg, one_mul]
      constructor
      · exact hα.trans (le_mul_of_one_le_right (pow_nonneg (Nat.cast_nonneg _) _) hlogpow)
      · have hvalue : (∑ p ∈ P z 2, Finsupp.single p (1 : ℂ)) n =
            if n ∈ P z 2 then 1 else 0 := by
          simp only [Finsupp.finsetSum_apply, Finsupp.single_apply, Finset.sum_ite_eq']
        rw [hvalue]
        by_cases hn : n ∈ P z 2
        · rw [ite_eq_left hn, norm_one]
          have hτ : (1 : ℝ) ≤ n.divisors.card := by
            exact_mod_cast Finset.card_pos.mpr (Nat.nonempty_divisors.mpr (hP z 2 n hn).ne')
          exact (one_le_pow₀ hτ).trans
            (le_mul_of_one_le_right (pow_nonneg (Nat.cast_nonneg _) _) hlogpow)
        · rw [ite_eq_right hn, norm_zero]
          positivity
    · simp only [α, β, ite_eq_right hg, Finsupp.zero_apply, norm_zero, one_mul]
      exact ⟨by positivity, by positivity⟩
  have hSW : ∀ A : ℝ, 0 < A →
      ∃ K X : ℝ, 0 < K ∧ Real.exp 100 ≤ X ∧
        ∀ x : ℝ, X ≤ x → ∀ z,
        ∀ q r a : ℕ, 0 < q → 0 < r → Nat.Coprime a q →
          ‖fullDiscrepancy
            ((β x z).filter (fun n : ℕ => Nat.Coprime n r)) q a‖ ≤
            K * ((q * r).divisors.card : ℝ) ^ 1 * N x z / (Real.log x) ^ A := by
    intro A hA
    obtain ⟨K, X, hK, hX, hs⟩ := prime_closed_interval_all_moduli_siegelWalfisz A hA
    refine ⟨K, X, hK, hX, ?_⟩
    intro x hx z q r a hq hr ha
    have hx100 := hX.trans hx
    by_cases hg : G x z
    · have hg' := hgeom x hx100 z hg
      have hh := hs x hx (z.1 2) (z.1 2) (z.2 2)
        (hg.1 2).1 (by simpa only [N, ite_eq_left hg] using hg'.2.2.2.2)
        le_rfl (hg.1 2).2.2 q r a hq hr ha
      simpa only [β, N, ite_eq_left hg, hbeta, pow_one] using hh
    · simp only [β, N, ite_eq_right hg, Finsupp.filter_zero,
        fullDiscrepancy,
        progressionMass, reducedMass,
        Finsupp.support_zero,
        Finset.sum_empty, zero_div, sub_self, norm_zero]
      have hlog : 0 ≤ Real.log x := zero_le_one.trans (hxbase x hx100).2.1
      positivity
  have hbase : Real.exp 1 ≤ Real.exp 100 := Real.exp_le_exp.mpr (by norm_num)
  have hBV := balanced_bv_masked_uniform_log_saving
    M N α β 1 32 1 (1 / 10) (Real.exp 100) 2 1
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) hbase
    hscale hsupport hcoeff hSW
  intro A hA
  obtain ⟨B, K, X, hB, hK, hX, hbound⟩ := hBV A hA
  refine ⟨B, K, X, hB, hK, hX, ?_⟩
  intro x hx L U hLU hlow hhigh h hh P'
  have hg : G x (L, U) := ⟨hLU, hlow, hhigh⟩
  have hconv := finite_three_prime_full_box_convolution (P (L, U))
  have hfinal := hbound x hx (L, U) h hh
  simpa only [α, β, ite_eq_left hg, ← hconv, pow_one, P, P'] using hfinal

theorem three_prime_closed_box_bv_power_cutoff
    (θ : ℝ) (hθ : θ < 1 / 2) :
    ∀ A : ℝ, 0 < A → ∃ K X : ℝ, 0 < K ∧ Real.exp 100 ≤ X ∧
      ∀ x : ℝ, X ≤ x → ∀ L U : Fin 3 → ℝ,
      (∀ i, x ^ (1 / 10 : ℝ) ≤ L i ∧ L i ≤ U i ∧ U i ≤ 2 * L i) →
      x / 32 ≤ (∏ i, L i) → (∏ i, L i) ≤ 2 * x →
      ∀ Q : Finset ℕ, Q ⊆ Finset.Icc 1 ⌊x ^ θ⌋₊ →
      ∀ a : ℕ → ℕ, (∀ q ∈ Q, Nat.Coprime (a q) q) →
      let P (i : Fin 3) := (Finset.Icc ⌈L i⌉₊ ⌊U i⌋₊).filter Nat.Prime
      (∑ q ∈ Q, ‖fullDiscrepancy
        (∑ p ∈ Fintype.piFinset P, Finsupp.single (∏ i, p i) (1 : ℂ)) q (a q)‖) ≤
        K * x / (Real.log x) ^ A := by
  intro A hA
  obtain ⟨B, K, Xb, hB, hK, hXb, hb⟩ := three_prime_closed_box_bv_uniform_log_saving A hA
  have hsmall := (isLittleO_log_rpow_rpow_atTop B (sub_pos.mpr hθ)).eventuallyLE
  obtain ⟨Xs, hXs⟩ := Filter.eventually_atTop.mp hsmall
  refine ⟨K, max Xb Xs, hK, hXb.trans (le_max_left _ _), ?_⟩
  intro x hx L U hLU hlo hhi Q hQ a ha P
  have hxb : Xb ≤ x := (le_max_left _ _).trans hx
  have hxs : Xs ≤ x := (le_max_right _ _).trans hx
  have hx100 : Real.exp 100 ≤ x := hXb.trans hxb
  have hx0 : 0 < x := (Real.exp_pos 100).trans_le hx100
  have hlog : 0 < Real.log x := by
    have := (Real.le_log_iff_exp_le hx0).mpr hx100
    linarith
  have hLB : 0 < (Real.log x) ^ B := Real.rpow_pos_of_pos hlog B
  have hpow : (Real.log x) ^ B ≤ x ^ ((1 / 2 : ℝ) - θ) := by
    simpa only [Real.norm_of_nonneg hLB.le,
      Real.norm_of_nonneg (Real.rpow_nonneg hx0.le _)] using hXs x hxs
  have hcut : x ^ θ ≤ Real.sqrt x / (Real.log x) ^ B := by
    apply (le_div_iff₀ hLB).mpr
    calc
      _ ≤ x ^ θ * x ^ ((1 / 2 : ℝ) - θ) :=
        mul_le_mul_of_nonneg_left hpow (Real.rpow_nonneg hx0.le θ)
      _ = Real.sqrt x := by
        rw [← Real.rpow_add hx0, add_sub_cancel, Real.sqrt_eq_rpow]
  let F : ℕ →₀ ℂ := ∑ p ∈ Fintype.piFinset P,
    Finsupp.single (∏ i, p i) 1
  let V := Finset.Ioc 0 ⌊Real.sqrt x / (Real.log x) ^ B⌋₊
  let Z (q : ℕ) : ℝ := ⨆ b : (ZMod q)ˣ,
    ‖fullDiscrepancy F q (b : ZMod q).val‖
  have hQV : Q ⊆ V := by
    intro q hq
    have hmem := Finset.mem_Icc.mp (hQ hq)
    exact Finset.mem_Ioc.mpr ⟨hmem.1, hmem.2.trans (Nat.floor_mono hcut)⟩
  have hZnonneg (q : ℕ) (hq : q ∈ V) : 0 ≤ Z q := by
    let _ : NeZero q := ⟨(Finset.mem_Ioc.mp hq).1.ne'⟩
    have hh : ‖fullDiscrepancy F q ((1 : (ZMod q)ˣ) : ZMod q).val‖ ≤ Z q :=
      le_ciSup (f := fun b : (ZMod q)ˣ => ‖fullDiscrepancy F q (b : ZMod q).val‖)
        (Set.finite_range _).bddAbove 1
    exact (norm_nonneg _).trans hh
  have hnorm (q : ℕ) (hq : q ∈ Q) : ‖fullDiscrepancy F q (a q)‖ ≤ Z q := by
    let _ : NeZero q := ⟨Nat.ne_of_gt (show 0 < q from (Finset.mem_Icc.mp (hQ hq)).1)⟩
    have heq : fullDiscrepancy F q
        ((ZMod.unitOfCoprime (a q) (ha q hq) : (ZMod q)ˣ) : ZMod q).val =
          fullDiscrepancy F q (a q) := by
      simp only [fullDiscrepancy, progressionMass, ZMod.coe_unitOfCoprime,
        ZMod.val_natCast, Nat.mod_mod]
    exact heq.symm ▸ le_ciSup
      (f := fun b : (ZMod q)ˣ => ‖fullDiscrepancy F q (b : ZMod q).val‖)
      (Set.finite_range _).bddAbove
      (ZMod.unitOfCoprime (a q) (ha q hq))
  have hbound := hb x hxb L U hLU hlo hhi 1 (by decide)
  have hfilter : F.filter (fun n : ℕ => Nat.Coprime n 1) = F := by
    exact (Finsupp.filter_eq_self_iff _ _).mpr (by intro n hn; simp)
  have hbound' : (∑ q ∈ V, Z q) ≤ K * x / (Real.log x) ^ A := by
    simpa only [F, P, V, Z, hfilter, Nat.divisors_one, Finset.card_singleton,
      Nat.cast_one, mul_one] using hbound
  calc
    _ ≤ ∑ q ∈ Q, Z q := Finset.sum_le_sum hnorm
    _ ≤ ∑ q ∈ V, Z q :=
      Finset.sum_le_sum_of_subset_of_nonneg hQV (fun q hq _ => hZnonneg q hq)
    _ ≤ _ := hbound'

#print axioms three_prime_closed_box_bv_power_cutoff
end PrimeGap180.Ordinary
