import TrialHighAngularGram180
import TrialMassCubicFields180

/-! The four signed interpolation controls for every physical cubic spline
channel on every clipped knot span, including a span of zero width. -/
noncomputable section
open scoped BigOperators Polynomial
open Polynomial
namespace PrimeGap180.HighSplineControls
open MassCubicFields MassSplineSpan FrozenProfile FullNativeTicks MassRadialValues

def four (a b c d : ℚ) : Fin 4 → ℚ :=
  let u := 27*b-8*a-d
  let v := 27*c-a-8*d
  ![a,(2*u-v)/18,(2*v-u)/18,d]

def bezier (z : Fin 4 → ℚ) (t : ℚ) :=
  (1-t)^3 * z 0 + 3*t*(1-t)^2 * z 1 + 3*t^2*(1-t)*z 2 + t^3*z 3

private theorem cubic_eval (P : ℚ[X]) (h : P.natDegree ≤ 3) (x : ℚ) :
    P.eval x = P.coeff 0 + P.coeff 1*x + P.coeff 2*x^2 + P.coeff 3*x^3 := by
  rw [eval_eq_sum_range' (show P.natDegree < 4 by omega)]
  simp [Finset.sum_range_succ]

def fromPolynomial (P : ℚ[X]) (a b : ℚ) :=
  four (P.eval a) (P.eval (a+(b-a)/3)) (P.eval (a+2*(b-a)/3)) (P.eval b)

theorem interpolate (P : ℚ[X]) (h : P.natDegree ≤ 3) (a b t : ℚ) :
    P.eval (a+(b-a)*t) = bezier (fromPolynomial P a b) t := by
  simp [fromPolynomial,cubic_eval P h,bezier,four]
  <;> ring

def index (x : ℚ) := x/(1399373467/172031279104000)-39/2
def row (s : ℕ) (c : Fine) (u : FullNativeTicks.Key) (a b : ℚ) (i : Fin 4) :=
  fromPolynomial (cubic s 0 c u) (index a) (index b) i / 2^64

/-- The real radial coefficient at the actual native index is the Bernstein
mixture of this span's four rational controls. Each of the 99 channels retains
its sign, including the factor 39 to the correct angular power. -/
theorem physical (s j : ℕ) (c : Fine) (u : FullNativeTicks.Key) (a b t : ℚ)
    (start : 3 ≤ s) (stop : s < 33)
    (active : knot s ≤ sample j ∧ sample j < knot (s+1))
    (place : sample j = a + (b-a)*t) :
    (coefficientQ j c u : ℝ) = HighPanelGram.mix (HighAngularGram.controls (t:ℝ))
      (fun i => (row s c u a b i : ℝ)) := by
  have loc : (j:ℚ) = index a + (index b - index a)*t := by
    calc
      _ = index (sample j) := by unfold index sample; ring
      _ = _ := by rw [place]; unfold index; ring
  have h := cubic_value s 0 j c u start stop (by simpa using active)
  simp only [Nat.zero_add] at h
  rw [loc,interpolate _ (cubic_degree s 0 c u)] at h
  have eq : coefficientQ j c u = bezier (row s c u a b) t := by
    calc
      _ = bezier (fromPolynomial (cubic s 0 c u) (index a) (index b)) t / 2^64 := by rw [h]; ring
      _ = _ := by unfold bezier row; ring
  rw [eq]
  simp [HighPanelGram.mix,HighAngularGram.controls,Fin.sum_univ_succ,bezier]
  <;> ring

#print axioms interpolate
#print axioms physical
end PrimeGap180.HighSplineControls
