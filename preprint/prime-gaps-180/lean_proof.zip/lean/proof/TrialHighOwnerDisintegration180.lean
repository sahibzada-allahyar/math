import TrialHighGridPayment180
import TrialHighActualMarkBands180
import TrialHighSiteCellMeasures180
import TrialHighOwnerOrder180

/-! Janossy disintegration of the actual 39-site owner law, with both labelled
marks retained under the physical cap test. -/
noncomputable section
open scoped BigOperators Classical ENNReal
open Filter MeasureTheory PrimeGap186 PrimeGap180.Sector
namespace PrimeGap180.HighOwnerDisintegration
open HighOwnerProduct RemovedHighTags JanossyLaw FixedTagIntegral
open private measurable_insert from TrialHighMarkedMeasures180
open private phys_finite from TrialHighSiteCellMeasures180
open private measurable_cell from TrialHighSiteCellMeasures180
open private mb mk ms from TrialHighGridPayment180
open private marks from TrialJanossyRadial180

abbrev Site := Fin 39
abbrev Sample (n : ℕ) := FiniteMeasure ℝ × (Fin n → ℝ)
def assemble (n : ℕ) (q : Sample n) := q.1 + weightedEmpirical n q.2
private theorem massemble (n : ℕ) : Measurable (assemble n) := measurable_insert n

def base (n : ℕ) : Measure (Sample n) := (PoissonSplit.phys cutoff).prod (prodLaw cutoff cap n)
private theorem positive : 0 < cutoff := by norm_num [cutoff,Lookup.ticks]
private theorem within : cutoff ≤ cap := by norm_num [cutoff,Lookup.ticks,cap,physicalCap,rho]
local instance (n : ℕ) : IsFiniteMeasure (base n) := by
  let : IsFiniteMeasure (PoissonSplit.phys cutoff) := phys_finite cutoff
  let : IsFiniteMeasure (PoissonSplit.intensity cutoff cap) := (PoissonSplit.jumps positive within).property
  unfold base prodLaw
  infer_instance

def samples (p : Pair) := Measure.pi fun i => base (countAt p i)
def introduce (p : Pair) (q : (i : Site) → Sample (countAt p i)) : RemovedHighMass.Config :=
  fun i => assemble _ (q i)
private theorem mintro (p : Pair) : Measurable (introduce p) :=
  measurable_pi_lambda _ fun i => (massemble _).comp (measurable_pi_apply i)

def weight (p : Pair) : ℝ≥0∞ := ∏ i, ((countAt p i).factorial:ℝ≥0∞)⁻¹

theorem factorial (p : Pair) : weight p = (if p.1=p.2 then (2:ℝ≥0∞)⁻¹ else 1) := by
  rcases p with ⟨a,b⟩
  by_cases eq : a=b
  · subst b
    simp only [weight,ite_true]
    rw [Finset.prod_eq_single a]
    · norm_num [countAt]
    · intro j _ hj
      simp [countAt,hj]
    · simp
  · simp only [weight,eq,ite_false]
    apply Finset.prod_eq_one
    intro i _
    by_cases ia : i=a
    · subst i
      simp [countAt,eq]
    · by_cases ib : i=b <;> simp [countAt,ia,ib,Ne.symm eq]

/-- The actual restricted owner law is the image of the independent smaller
fragment laws and the two labelled Poisson coordinates, with its factorial. -/
theorem law (p : Pair) : restrictedLaw p = weight p • (samples p).map (introduce p) := by
  let μ (i : Site) := (base (countAt p i)).map (assemble (countAt p i))
  have map : (samples p).map (introduce p) = Measure.pi μ :=
    Measure.pi_map_pi fun i => (massemble (countAt p i)).aemeasurable
  rw [map]
  let κ (i : Site) := (NativeSiteLaw.phys cap).restrict (siteSet p i)
  let : IsFiniteMeasure (NativeSiteLaw.phys cap) := phys_finite cap
  have each (i : Site) : κ i = ((countAt p i).factorial:ℝ≥0∞)⁻¹ • μ i :=
    HighMarkedMeasures.restricted positive within _
  apply Measure.pi_eq
  intro s hs
  rw [Measure.smul_apply,smul_eq_mul,Measure.pi_pi,weight,←Finset.prod_mul_distrib]
  apply Finset.prod_congr rfl
  intro i _
  exact congrArg (fun m : Measure (FiniteMeasure ℝ) => m (s i)) (each i).symm

theorem integral (p : Pair) (F : RemovedHighMass.Config → ℝ≥0∞) (hF : Measurable F) :
    (∫⁻ X,F X ∂restrictedLaw p) = weight p * ∫⁻ q,F (introduce p q) ∂samples p := by
  rw [law,lintegral_smul_measure,lintegral_map hF (mintro p),smul_eq_mul]

#print axioms factorial
#print axioms law
#print axioms integral

abbrev Slot (p : Pair) := (i : Site) × Fin (countAt p i)
def firstSlot (p : Pair) : Slot p := ⟨p.1,⟨0,by simp [countAt]⟩⟩
def secondSlot (p : Pair) : Slot p :=
  ⟨p.2,⟨if p.2=p.1 then 1 else 0,by by_cases h : p.2=p.1 <;> simp [countAt,h]⟩⟩

theorem slots (p : Pair) (s : Slot p) : s=firstSlot p ∨ s=secondSlot p := by
  rcases p with ⟨a,b⟩
  rcases s with ⟨i,j⟩
  have hj := j.isLt
  by_cases ia : i=a
  · subst i
    by_cases ab : a=b
    · subst b
      change j.val < (if a=a then 1 else 0) + (if a=a then 1 else 0) at hj
      simp only [ite_true] at hj
      rcases (show j.val=0 ∨ j.val=1 by omega) with z|o
      · left; congr 1; apply Fin.ext; exact z
      · right; congr 1; apply Fin.ext; simpa [secondSlot] using o
    · left
      change j.val < (if a=a then 1 else 0) + (if a=b then 1 else 0) at hj
      simp [ab] at hj
      congr 1; apply Fin.ext; exact Nat.eq_zero_of_le_zero (by omega)
  · have ib : i=b := by
      by_contra h
      simp [countAt,ia,h] at hj
    subst i
    right
    simp [countAt,ia] at hj
    congr 1; apply Fin.ext; simpa [secondSlot,ia] using (show j.val=0 by omega)

theorem distinct (p : Pair) : firstSlot p ≠ secondSlot p := by
  rintro h
  have ab : p.1=p.2 := congrArg Sigma.fst h
  have bad := congrArg (fun s : Slot p => s.2.val) h
  simp [firstSlot,secondSlot,ab.symm] at bad

def reading (p : Pair) (q : (i : Site) → Sample (countAt p i)) (s : Slot p) := (q s.1).2 s.2

def label (p : Pair) (m : Fin 9 × Fin 9) (s : Slot p) := if s=firstSlot p then m.1 else m.2

def legal (k : Fin 9) := Finset.univ.filter (fun m : Fin 9 × Fin 9 => max m.1 m.2 = k)

def slice (p : Pair) (m : Fin 9 × Fin 9) := Set.univ.pi fun i : Site =>
  (Set.univ : Set (FiniteMeasure ℝ)) ×ˢ Set.univ.pi fun t : Fin (countAt p i) =>
    HighActualMarkBands.interval (label p m ⟨i,t⟩)

private theorem regular (p : Pair) : ∀ᵐ q ∂samples p,
    (∀ i, (q i).1.restrict (Set.Ioc 0 cutoff) = (q i).1) ∧
    ∀ i a, cutoff < (q i).2 a ∧ (q i).2 a ≤ cap := by
  let : IsFiniteMeasure (PoissonSplit.phys cutoff) := phys_finite cutoff
  let : IsFiniteMeasure (PoissonSplit.intensity cutoff cap) := (PoissonSplit.jumps positive within).property
  let each (n : ℕ) : IsFiniteMeasure (prodLaw cutoff cap n) := by unfold prodLaw; infer_instance
  have small : ∀ᵐ Y ∂PoissonSplit.phys cutoff,Y.restrict (Set.Ioc 0 cutoff)=Y :=
    Measure.ae_smul_measure (ae_restrict_Ioc_fragmentLaw _) _
  have full (i : Site) : ∀ᵐ q ∂base (countAt p i),
      q.1.restrict (Set.Ioc 0 cutoff)=q.1 ∧ ∀ a, cutoff < q.2 a ∧ q.2 a ≤ cap :=
    (Measure.quasiMeasurePreserving_fst.ae small).and
    (Measure.quasiMeasurePreserving_snd.ae (marks positive within (countAt p i)))
  have all := ae_all_iff.mpr fun i => (Measure.quasiMeasurePreserving_eval (fun i => base (countAt p i)) i).ae (full i)
  filter_upwards [all] with q h
  exact ⟨fun i => (h i).1,fun i => (h i).2⟩

/-- The actual selected cap puts the two labelled physical marks in a legal
pair of half-open intervals, including coincident owners. -/
theorem selected (p : Pair) (k : Fin 9) : ∀ᵐ q ∂samples p,
    introduce p q ∈ HighGridPayment.selected k → ∃ m ∈ legal k,q ∈ slice p m := by
  filter_upwards [regular p] with q h hsel
  have c := HighMassBands.chosen_band (fun i => (q i).1) (countAt p) (fun i => (q i).2) h.1 h.2 k hsel.2
  let x := reading p q (firstSlot p)
  let y := reading p q (secondSlot p)
  have prev (a : Fin 9) (ha : a<k) : HighMassBands.top a < x ∨ HighMassBands.top a < y := by
    obtain ⟨i,t,gt⟩ := c.2 a ha
    have g : HighMassBands.top a < reading p q ⟨i,t⟩ := gt
    rcases slots p ⟨i,t⟩ with eq|eq
    · left; rwa [eq] at g
    · right; rwa [eq] at g
  obtain ⟨i,j,hi,hj,hmax⟩ := HighActualMarkBands.paired
    (x:=x) (y:=y) (h.2 _ _).1 (h.2 _ _).1 (c.1 _ _) (c.1 _ _) prev
  refine ⟨(i,j),Finset.mem_filter.mpr ⟨Finset.mem_univ _,hmax⟩,?_⟩
  intro a _
  refine ⟨Set.mem_univ _,?_⟩
  intro t _
  change reading p q ⟨a,t⟩ ∈ HighActualMarkBands.interval (label p (i,j) ⟨a,t⟩)
  rcases slots p ⟨a,t⟩ with eq|eq
  · simpa [eq,label,x] using hi
  · simpa [eq,label,(distinct p).symm,y] using hj

#print axioms slots
#print axioms selected


private theorem bounds (a : Fin 9) : cutoff ≤ HighPanelSupport.bottom a ∧ HighPanelSupport.bottom a ≤ HighMassBands.top a ∧ HighMassBands.top a ≤ cap := by
  rw [HighPanelSupport.bottom]
  split
  · simp only [HighMassBands.capTable]
    fin_cases a <;> norm_num [HighMassBands.nativeCap,cutoff,Lookup.ticks,cap,physicalCap,rho,Native.step]
  · rename_i ne
    simp only [HighMassBands.capTable]
    fin_cases a <;> norm_num [HighMassBands.nativeCap,cutoff,Lookup.ticks,cap,physicalCap,rho,Native.step] at *

private theorem restricted_intensity (a : Fin 9) :
    (PoissonSplit.intensity cutoff cap).restrict (HighActualMarkBands.interval a) =
      PoissonSplit.intensity (HighPanelSupport.bottom a) (HighMassBands.top a) := by
  unfold PoissonSplit.intensity HighActualMarkBands.interval
  rw [restrict_withDensity measurableSet_Ioc,Measure.restrict_restrict measurableSet_Ioc]
  rw [Set.inter_eq_left.mpr (Set.Ioc_subset_Ioc (bounds a).1 (bounds a).2.2)]

def markedLaw {n : ℕ} (band : Fin n → Fin 9) :=
  Measure.pi fun t => PoissonSplit.intensity (HighPanelSupport.bottom (band t)) (HighMassBands.top (band t))
local instance bandFinite (a : Fin 9) : IsFiniteMeasure (PoissonSplit.intensity (HighPanelSupport.bottom a) (HighMassBands.top a)) :=
  (PoissonSplit.jumps (positive.trans_le (bounds a).1) (bounds a).2.1).property
local instance {n : ℕ} (band : Fin n → Fin 9) : IsFiniteMeasure (markedLaw band) := by unfold markedLaw;infer_instance

def inserted {n : ℕ} (band : Fin n → Fin 9) := HighMarkedMeasures.insert cutoff (markedLaw band)

/-- Evaluation on a native rectangle factors over the actual smaller physical
fragment laws with each labelled coordinate restricted to its harmonic band. -/
theorem rectangle (p : Pair) (m : Fin 9 × Fin 9) (j : HighGridPayment.Grid) :
    samples p ((introduce p ⁻¹' HighGridPayment.box j) ∩ slice p m) =
      ∏ i,inserted (fun t => label p m ⟨i,t⟩) {Y | HighGridPayment.site Y=(j i).val} := by
  let : IsFiniteMeasure (PoissonSplit.phys cutoff) := phys_finite cutoff
  let : IsFiniteMeasure (PoissonSplit.intensity cutoff cap) := (PoissonSplit.jumps positive within).property
  let each (n : ℕ) : IsFiniteMeasure (prodLaw cutoff cap n) := by unfold prodLaw; infer_instance
  let B (i : Site) : Set (FiniteMeasure ℝ) := {Y | HighGridPayment.site Y=(j i).val}
  have mB (i) : MeasurableSet (B i) := measurableSet_eq_fun ms measurable_const
  have hpre : introduce p ⁻¹' HighGridPayment.box j = Set.univ.pi (fun i => assemble (countAt p i) ⁻¹' B i) := by ext q;simp [introduce,HighGridPayment.box,B,Set.mem_preimage]
  rw [← Measure.restrict_apply ((mb j).preimage (mintro p)),samples,slice,Measure.restrict_pi_pi,hpre,Measure.pi_pi]
  apply Finset.prod_congr rfl
  intro i _
  let band (t : Fin (countAt p i)) := label p m ⟨i,t⟩
  change ((base (countAt p i)).restrict (Set.univ ×ˢ Set.univ.pi (fun t => HighActualMarkBands.interval (band t))))
    (assemble (countAt p i) ⁻¹' B i) = inserted band (B i)
  rw [base,← Measure.prod_restrict,Measure.restrict_univ,prodLaw,Measure.restrict_pi_pi]
  simp_rw [restricted_intensity]
  exact (Measure.map_apply (massemble _) (mB i)).symm

/-- Physical cap-band disintegration at each unordered owner and each actual
native rectangle. Ordered band pairs retain both orientations, and the
common-owner multiplicity is exactly 1/2. -/
theorem bound (p : Pair) (k : Fin 9) (j : HighGridPayment.Grid) :
    restrictedLaw p (HighGridPayment.box j ∩ HighGridPayment.selected k) ≤ weight p *
      ∑ m ∈ legal k, ∏ i,inserted (fun t => label p m ⟨i,t⟩) {Y | HighGridPayment.site Y=(j i).val} := by
  rw [law,Measure.smul_apply,smul_eq_mul,Measure.map_apply (mintro p) ((mb j).inter (mk k))]
  apply mul_le_mul_right
  let E := fun m => (introduce p ⁻¹' HighGridPayment.box j) ∩ slice p m
  calc
    _ ≤ samples p (⋃ m ∈ legal k,E m) := by
      apply measure_mono_ae
      filter_upwards [selected p k] with q h hq
      obtain ⟨m,hm,mem⟩ := h hq.2
      exact Set.mem_iUnion.mpr ⟨m,Set.mem_iUnion.mpr ⟨hm,hq.1,mem⟩⟩
    _ ≤ ∑ m ∈ legal k,samples p (E m) := measure_biUnion_finset_le _ _
    _ = _ := Finset.sum_congr rfl fun m _ => rectangle p m j

#print axioms rectangle
#print axioms bound


def one (a : Fin 9) := HighSiteCellMeasures.one cutoff (HighPanelSupport.bottom a) (HighMassBands.top a)
def two (a b : Fin 9) := HighSiteCellMeasures.two cutoff (HighPanelSupport.bottom a) (HighMassBands.top a)
  (HighPanelSupport.bottom b) (HighMassBands.top b)

private theorem empty {n : ℕ} (B : Fin n → Fin 9) (h : n=0) : inserted B=PoissonSplit.phys cutoff := by
  subst n
  have e : markedLaw B = prodLaw cutoff cap 0 := by
    apply congrArg Measure.pi
    funext i
    exact Fin.elim0 i
  rw [inserted,e]
  have hi := HighMarkedMeasures.restricted positive within 0
  simpa only [Nat.cast_zero,Nat.factorial_zero,Nat.cast_one,inv_one,one_smul,
    HighMarkedMeasures.unmarked positive within] using hi.symm

private theorem single {n : ℕ} (B : Fin n → Fin 9) (h : n=1) : inserted B=one (B ⟨0,by omega⟩) := by
  subst n
  unfold inserted one HighSiteCellMeasures.one
  apply congrArg (HighMarkedMeasures.insert cutoff)
  exact (measurePreserving_piUnique (fun i : Fin 1 => PoissonSplit.intensity
    (HighPanelSupport.bottom (B i)) (HighMassBands.top (B i))) |>.symm _).map_eq.symm

private theorem double {n : ℕ} (B : Fin n → Fin 9) (h : n=2) :
    inserted B=two (B ⟨0,by omega⟩) (B ⟨1,by omega⟩) := by
  subst n
  unfold inserted two HighSiteCellMeasures.two
  apply congrArg (HighMarkedMeasures.insert cutoff)
  exact (measurePreserving_piFinTwo (fun i : Fin 2 => PoissonSplit.intensity
    (HighPanelSupport.bottom (B i)) (HighMassBands.top (B i))) |>.symm _).map_eq.symm

/-- Physical one-site factors in the order used by the marked-owner Gram. -/
def factor (p : Pair) (m : Fin 9 × Fin 9) (i : Site) : Measure (FiniteMeasure ℝ) :=
  if i=p.1 then (if i=p.2 then two m.1 m.2 else one m.1)
  else if i=p.2 then one m.2 else PoissonSplit.phys cutoff

theorem at_site (p : Pair) (m : Fin 9 × Fin 9) (i : Site) :
    inserted (fun t => label p m ⟨i,t⟩) = factor p m i := by
  let B (t : Fin (countAt p i)) := label p m ⟨i,t⟩
  change inserted B = _
  by_cases h1 : i=p.1
  · by_cases h2 : i=p.2
    · have n : countAt p i=2 := by simp [countAt,h1,h1.symm.trans h2]
      rw [double B n,factor,ite_eq_left h1,ite_eq_left h2]
      have x : (⟨i,⟨0,by omega⟩⟩ : Slot p)=firstSlot p := by cases h1; rfl
      have y : (⟨i,⟨1,by omega⟩⟩ : Slot p)≠firstSlot p := fun h => by
        have e := congrArg (fun s : Slot p => s.2.val) h;contradiction
      simp only [B,label,x,y,ite_true,ite_false]
    · have n : countAt p i=1 := by simp [countAt,h1,show p.1≠p.2 from fun e => h2 (h1.trans e)]
      rw [single B n,factor,ite_eq_left h1,ite_eq_right h2]
      have x : (⟨i,⟨0,by omega⟩⟩ : Slot p)=firstSlot p := by cases h1; rfl
      simp only [B,label,x,ite_true]
  · by_cases h2 : i=p.2
    · have n : countAt p i=1 := by simp [countAt,h2,show p.2≠p.1 from fun e => h1 (h2.trans e)]
      rw [single B n,factor,ite_eq_right h1,ite_eq_left h2]
      have x : (⟨i,⟨0,by omega⟩⟩ : Slot p)≠firstSlot p := fun h => h1 (congrArg Sigma.fst h)
      simp only [B,label,x,ite_false]
    · have n : countAt p i=0 := by simp [countAt,h1,h2]
      rw [empty B n,factor,ite_eq_right h1,ite_eq_right h2]

/-- Every factor now uses precisely the unmarked, one-band or two-band
site measure employed by the numerical rectangle calculation. -/
theorem physical (p : Pair) (k : Fin 9) (j : HighGridPayment.Grid) :
    restrictedLaw p (HighGridPayment.box j ∩ HighGridPayment.selected k) ≤
      (if p.1=p.2 then (2:ℝ≥0∞)⁻¹ else 1) * ∑ m ∈ legal k,
        ∏ i,factor p m i {Y | HighGridPayment.site Y=(j i).val} := by
  simpa only [factorial,at_site] using bound p k j

#print axioms at_site
#print axioms physical


private abbrev intensity (a : Fin 9) := PoissonSplit.intensity (HighPanelSupport.bottom a) (HighMassBands.top a)
private def vector (q : ℝ × ℝ) := (![q.1,q.2] : Fin 2 → ℝ)
private theorem mvector : Measurable vector := measurable_pi_lambda _ fun i => by
  fin_cases i
  · exact measurable_fst
  · exact measurable_snd
private def bundle (q : FiniteMeasure ℝ × (ℝ × ℝ)) := assemble 2 (q.1,vector q.2)
private theorem bundle_m : Measurable bundle := (massemble 2).comp (measurable_id.prodMap mvector)

private theorem prod_map {α β : Type*} [MeasurableSpace α] [MeasurableSpace β]
    (μ : Measure α) [SFinite μ] (f : α → β) (mf : Measurable f) :
    (PoissonSplit.phys cutoff).prod (μ.map f) = ((PoissonSplit.phys cutoff).prod μ).map (Prod.map id f) := by
  let : IsFiniteMeasure (PoissonSplit.phys cutoff) := phys_finite cutoff
  simpa only [Measure.map_id] using Measure.map_prod_map (PoissonSplit.phys cutoff) μ measurable_id mf

private theorem two_map (a b : Fin 9) : two a b =
    ((PoissonSplit.phys cutoff).prod ((intensity a).prod (intensity b))).map bundle := by
  change ((PoissonSplit.phys cutoff).prod (((intensity a).prod (intensity b)).map vector)).map (assemble 2) = _
  rw [prod_map _ vector mvector,Measure.map_map (massemble 2) (measurable_id.prodMap mvector)]
  rfl

theorem two_swap (a b : Fin 9) : two b a=two a b := by
  rw [two_map,two_map,← Measure.prod_swap (μ:=intensity a) (ν:=intensity b),
    prod_map _ Prod.swap measurable_swap,Measure.map_map bundle_m (measurable_id.prodMap measurable_swap)]
  congr 1
  funext z
  change z.1+weightedEmpirical 2 ![z.2.2,z.2.1]=z.1+weightedEmpirical 2 ![z.2.1,z.2.2]
  congr 1
  apply FiniteMeasure.toMeasure_injective
  simp [coe_weightedEmpirical,Fin.sum_univ_two,add_comm]

private theorem factor_swap (p : Pair) (m : Fin 9 × Fin 9) (i : Site) :
    factor p.swap m.swap i=factor p m i := by
  by_cases h1 : i=p.1 <;> by_cases h2 : i=p.2 <;>
    simp only [factor,Prod.fst_swap,Prod.snd_swap,h1,h2,ite_true,ite_false,two_swap m.1 m.2]

def mass (p : Pair) (a b : Fin 9) (j : HighGridPayment.Grid) :=
  ∏ i,factor p (a,b) i {Y | HighGridPayment.site Y=(j i).val}

theorem mass_swap (p : Pair) (a b : Fin 9) (j : HighGridPayment.Grid) :
    mass p.swap b a j=mass p a b j := by
  unfold mass
  simp only [show (b,a)=(a,b).swap from rfl,factor_swap]

private theorem orientations {A : Type*} [AddCommMonoid A] (k : Fin 9) (F : Fin 9 × Fin 9 → A) :
    ∑ m ∈ legal k,F m = (∑ a ∈ Finset.Iio k,(F (a,k)+F (k,a))) + F (k,k) := by
  let l : Fin 9 ↪ Fin 9 × Fin 9 := ⟨fun a => (a,k),fun _ _ h => congrArg Prod.fst h⟩
  let r : Fin 9 ↪ Fin 9 × Fin 9 := ⟨fun a => (k,a),fun _ _ h => congrArg Prod.snd h⟩
  have part : legal k = (((Finset.Iio k).map l) ∪ (Finset.Iio k).map r) ∪ {(k,k)} := by
    dsimp only [l,r]
    fin_cases k <;> decide +kernel
  have diff : Disjoint ((Finset.Iio k).map l) ((Finset.Iio k).map r) := by
    apply Finset.disjoint_left.mpr
    rintro _ ha hb
    obtain ⟨a,ha,h⟩ := Finset.mem_map.mp ha
    obtain ⟨b,hb,g⟩ := Finset.mem_map.mp hb
    exact (Finset.mem_Iio.mp ha).ne (congrArg Prod.fst (h.trans g.symm))
  have no : (k,k) ∉ (Finset.Iio k).map l ∪ (Finset.Iio k).map r := by
    intro h
    rcases Finset.mem_union.mp h with h|h
    · obtain ⟨a,ha,eq⟩ := Finset.mem_map.mp h
      exact (Finset.mem_Iio.mp ha).ne (congrArg Prod.fst eq)
    · obtain ⟨a,ha,eq⟩ := Finset.mem_map.mp h
      exact (Finset.mem_Iio.mp ha).ne (congrArg Prod.snd eq)
  rw [part,Finset.sum_union (Finset.disjoint_singleton_right.mpr no),Finset.sum_union diff,
    Finset.sum_singleton,Finset.sum_map,Finset.sum_map,Finset.sum_add_distrib]
  rfl

private def parity (p : Pair) : ℝ≥0∞ := if p.1=p.2 then (2:ℝ≥0∞)⁻¹ else 1
private theorem halve (z : ℝ≥0∞) : (2:ℝ≥0∞)⁻¹*(z+z) = z := by
  rw [mul_add,mul_comm (2:ℝ≥0∞)⁻¹ z,←div_eq_mul_inv,ENNReal.add_halves]

private theorem orient_sum (f : Pair → ℝ≥0∞) :
    (∑ p ∈ pairs,parity p * (f p + f p.swap)) = ∑ p : Pair,f p := by
  rw [HighOwnerOrder.labelled]
  apply Finset.sum_congr rfl
  intro p hp
  have le := (Finset.mem_filter.mp hp).2
  rcases lt_or_eq_of_le le with lt|eq
  · simp [parity,lt,lt.ne]
  · have s : p.swap=p := Prod.ext eq.symm eq
    simp only [parity,eq,s,ite_true,lt_irrefl,ite_false,add_zero,halve]

/-- Summing over the physical unordered owners gives one ordered-owner sum
for each unequal harmonic pair and exactly half this sum on the equal band. -/
theorem ordered (k : Fin 9) (j : HighGridPayment.Grid) :
    (∑ p ∈ pairs, restrictedLaw p (HighGridPayment.box j ∩ HighGridPayment.selected k)) ≤
      (∑ a ∈ Finset.Iio k,∑ p : Pair,mass p a k j) + (2:ℝ≥0∞)⁻¹ * ∑ p : Pair,mass p k k j := by
  let M (a b : Fin 9) (p : Pair) := mass p a b j
  have flip (a b : Fin 9) (p : Pair) : M b a p = M a b p.swap := (mass_swap p b a j).symm
  have d (p : Pair) : M k k p+M k k p.swap = M k k p+M k k p := by rw [←flip]
  calc
    _ ≤ ∑ p ∈ pairs,parity p * (∑ m ∈ legal k,M m.1 m.2 p) := Finset.sum_le_sum fun p _ => physical p k j
    _ = (∑ a ∈ Finset.Iio k,∑ p ∈ pairs,parity p * (M a k p + M a k p.swap)) +
          ∑ p ∈ pairs,parity p*M k k p := by
      simp_rw [orientations, mul_add,Finset.mul_sum]
      rw [Finset.sum_add_distrib,Finset.sum_comm]
      apply congrArg (fun z => z + _)
      apply Finset.sum_congr rfl
      intro a _
      apply Finset.sum_congr rfl
      intro p _
      rw [←mul_add,flip a k p]
    _ = _ := by
      simp_rw [orient_sum]
      congr 1
      rw [←orient_sum (M k k),Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro p _
      rw [d,mul_left_comm,halve]

#print axioms two_swap
#print axioms mass_swap
#print axioms ordered


private theorem covers {n : ℕ} {q : Sample n}
    (hy : q.1.restrict (Set.Ioc 0 cutoff)=q.1) (hx : ∀ i, q.2 i ∈ Set.Ioc 0 cap) :
    (assemble n q).restrict (Set.Ioc 0 cap)=assemble n q := by
  have y := trial_restrict_eq_self_of_subset q.1 _ _ hy (Set.Ioc_subset_Ioc le_rfl within)
  apply FiniteMeasure.toMeasure_injective
  change ((q.1:Measure ℝ)+(weightedEmpirical n q.2:Measure ℝ)).restrict (Set.Ioc 0 cap)=
    (q.1:Measure ℝ)+(weightedEmpirical n q.2:Measure ℝ)
  have baseeq : (q.1:Measure ℝ).restrict (Set.Ioc 0 cap) = q.1 := congrArg FiniteMeasure.toMeasure y
  rw [Measure.restrict_add,baseeq,coe_weightedEmpirical,←Measure.restrictₗ_apply,map_sum]
  apply congrArg (fun z => (q.1:Measure ℝ)+z)
  apply Finset.sum_congr rfl
  intro i _
  simp only [Measure.restrictₗ_apply,Measure.restrict_smul,restrict_dirac,ite_eq_left (hx i)]

def radial (j : HighGridPayment.NativeIndex) :=
  HighMixedCell.cellSet ((j.val:ℝ)*Native.step) (((j.val:ℝ)+1)*Native.step)

private theorem native_of_support (Y : FiniteMeasure ℝ) (support : Y.restrict (Set.Ioc 0 cap)=Y)
    (j : HighGridPayment.NativeIndex) : HighGridPayment.site Y=j.val ↔ Y∈radial j := by
  have rad : (∑ i, fragmentBandMasses FrozenData.mesh Y i)=(Y.mass:ℝ) := by
    rw [sum_fragmentBandMasses FrozenData.mesh FrozenData.tables.ordered.monotone Y,
      show FrozenData.mesh 0=0 from FrozenData.tables.first,
      show FrozenData.mesh (Fin.last 217)=cap from FrozenData.tables.last,support]
  have stepPos : 0 < Native.step := by norm_num [Native.step]
  change ⌊(∑ i, fragmentBandMasses FrozenData.mesh Y i)/Native.step⌋₊=j.val ↔ _
  rw [rad,Nat.floor_eq_iff (div_nonneg Y.mass.coe_nonneg stepPos.le)]
  exact and_congr (le_div_iff₀ stepPos) (div_lt_iff₀ stepPos)

private theorem coord {n : ℕ} (B : Fin n → Fin 9) : ∀ᵐ x ∂markedLaw B,∀ i, x i ∈ Set.Ioc 0 cap := by
  apply ae_all_iff.mpr
  intro i
  apply (Measure.quasiMeasurePreserving_eval (fun t => intensity (B t)) i).ae
  have h : ∀ᵐ x ∂intensity (B i), x ∈ HighActualMarkBands.interval (B i) :=
    (withDensity_absolutelyContinuous _ _).ae_le (ae_restrict_mem (μ:=volume) measurableSet_Ioc)
  filter_upwards [h] with x hx
  exact ⟨positive.trans_le (bounds (B i)).1 |>.trans hx.1,hx.2.trans (bounds (B i)).2.2⟩

private theorem inserted_radial {n : ℕ} (B : Fin n → Fin 9) (j : HighGridPayment.NativeIndex) :
    inserted B {Y | HighGridPayment.site Y=j.val} = inserted B (radial j) := by
  let : IsFiniteMeasure (PoissonSplit.phys cutoff) := phys_finite cutoff
  have A : MeasurableSet {Y | HighGridPayment.site Y=j.val} := measurableSet_eq_fun ms measurable_const
  have R : MeasurableSet (radial j) := measurable_cell _ _
  change ((PoissonSplit.phys cutoff).prod (markedLaw B)).map (assemble n) _ =
    ((PoissonSplit.phys cutoff).prod (markedLaw B)).map (assemble n) _
  rw [Measure.map_apply (massemble _) A,Measure.map_apply (massemble _) R]
  apply measure_congr
  have small : ∀ᵐ Y ∂PoissonSplit.phys cutoff, Y.restrict (Set.Ioc 0 cutoff)=Y :=
    Measure.ae_smul_measure (ae_restrict_Ioc_fragmentLaw _) _
  filter_upwards [Measure.quasiMeasurePreserving_fst.ae small,Measure.quasiMeasurePreserving_snd.ae (coord B)] with q hy hx
  exact propext (native_of_support (assemble n q) (covers hy hx) j)

/-- On every actual marked site law the native lookup rectangle is precisely
the same half-open radial cell as in the certified one-site estimate. -/
theorem site_radial (p : Pair) (m : Fin 9 × Fin 9) (i : Site) (j : HighGridPayment.NativeIndex) :
    factor p m i {Y | HighGridPayment.site Y=j.val} = factor p m i (radial j) := by
  rw [←at_site]
  exact inserted_radial _ _

def radialMass (p : Pair) (a b : Fin 9) (j : HighGridPayment.Grid) := ∏ i, factor p (a,b) i (radial (j i))
private theorem mass_radial (p : Pair) (a b : Fin 9) (j : HighGridPayment.Grid) :
    mass p a b j = radialMass p a b j := by
  unfold mass radialMass
  apply Finset.prod_congr rfl
  intro i _
  exact site_radial _ _ _ _

theorem ordered_radial (k : Fin 9) (j : HighGridPayment.Grid) :
    (∑ p ∈ pairs, restrictedLaw p (HighGridPayment.box j ∩ HighGridPayment.selected k)) ≤
      (∑ a ∈ Finset.Iio k,∑ p : Pair,radialMass p a k j) + (2:ℝ≥0∞)⁻¹ * ∑ p : Pair,radialMass p k k j := by
  simpa only [mass_radial] using ordered k j

/-- The original continuum band mass is charged directly to signed-spline
rectangle values and positive radial products, with the physical symmetry factor. -/
theorem band_mass (k : Fin 9) :
    ENNReal.ofReal (HighMassBands.bandMass k) ≤ ∑ j : HighGridPayment.Grid,HighGridPayment.value k j *
      ((∑ a ∈ Finset.Iio k,∑ p : Pair,radialMass p a k j) + (2:ℝ≥0∞)⁻¹ * ∑ p : Pair,radialMass p k k j) := by
  apply (HighGridPayment.band k).trans
  rw [Finset.sum_comm]
  apply Finset.sum_le_sum
  intro j _
  rw [←Finset.mul_sum]
  exact mul_le_mul_right (ordered_radial k j) _

#print axioms site_radial
#print axioms ordered_radial
#print axioms band_mass


private theorem index_pair (p : Pair) (m : Fin 9 × Fin 9) (j : HighGridPayment.Grid)
    (q : (i : Site) → Sample (countAt p i))
    (hy : ∀ i, (q i).1.restrict (Set.Ioc 0 cutoff)=(q i).1)
    (hx : ∀ i t, cutoff < (q i).2 t ∧ (q i).2 t ≤ cap)
    (rect : introduce p q ∈ HighGridPayment.box j) (band : q ∈ slice p m) :
    HighPanelSupport.lowerIndex m.1 + HighPanelSupport.lowerIndex m.2 ≤ ∑ i,(j i).val := by
  let f (t : Slot p) := ⌊reading p q t / Native.step⌋₊
  have lo (t : Slot p) : HighPanelSupport.bottom (label p m t) ≤ reading p q t :=
    ((band t.1 (Set.mem_univ _)).2 t.2 (Set.mem_univ _)).1.le
  have lb (t : Slot p) : HighPanelSupport.lowerIndex (label p m t) ≤ f t :=
    (HighPanelSupport.floor_bottom _).symm.trans_le (Nat.floor_mono (div_le_div_of_nonneg_right (lo t) (by norm_num [Native.step])))
  have one : HighPanelSupport.lowerIndex m.1 ≤ f (firstSlot p) := by simpa [label] using lb (firstSlot p)
  have two : HighPanelSupport.lowerIndex m.2 ≤ f (secondSlot p) := by simpa [label,Ne.symm (distinct p)] using lb (secondSlot p)
  have pair : f (firstSlot p)+f (secondSlot p) ≤ ∑ t : Slot p,f t := by
    rw [←Finset.sum_pair (distinct p)]
    exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) (fun _ _ _ => Nat.zero_le _)
  have all := tag_indices (fun i => (q i).1) (countAt p) (fun i => (q i).2) hy hx
  have eq : Native.cellSum (state (fun i => (q i).1) (countAt p) (fun i => (q i).2)) = ∑ i,(j i).val :=
    Finset.sum_congr rfl fun i _ => rect i (Set.mem_univ _)
  rw [Fintype.sum_sigma] at pair
  exact ((Nat.add_le_add one two).trans pair).trans (all.trans_eq eq)

/-- A nonempty marked product pays each mark's lower native index, including
when the marks lie at one site. This certifies removal of the empty panels. -/
theorem below (p : Pair) (a b : Fin 9) (j : HighGridPayment.Grid)
    (h : (∑ i,(j i).val) < HighPanelSupport.lowerIndex a+HighPanelSupport.lowerIndex b) : radialMass p a b j = 0 := by
  have eq := rectangle p (a,b) j
  simp_rw [at_site] at eq
  change _ = mass p a b j at eq
  rw [←mass_radial,←eq,measure_eq_zero_iff_ae_notMem]
  filter_upwards [regular p] with q good mem
  exact h.not_ge (index_pair p (a,b) j q good.1 good.2 mem.1 mem.2)

#print axioms below

end PrimeGap180.HighOwnerDisintegration
