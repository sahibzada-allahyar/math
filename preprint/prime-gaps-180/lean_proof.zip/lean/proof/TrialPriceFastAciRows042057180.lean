import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G042
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 42

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G042

namespace PrimeGap180.PriceIsolatedGroup.G047
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 47

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G047

namespace PrimeGap180.PriceIsolatedGroup.G052
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 52

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G052

namespace PrimeGap180.PriceIsolatedGroup.G057
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 57

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G057
