import TrialTableMassTicks180
namespace PrimeGap180.TablePrices

def costTicks (n : Fin 25) (c : Fin 49) (k : Fin 143) : ℤ :=
  ⌈(((massTicks[n.val]!)[k.val]! : Nat):ℚ) / radius (cut (rowOf n)) (capOf c) k.val⌉

def total (n : Fin 25) (c : Fin 49) : ℤ :=
  ∑ k : Fin 143, costTicks n c k

def conditions (n : Fin 25) (c : Fin 49) : Prop :=
    (∀ k : Fin 143, 0 < radius (cut (rowOf n)) (capOf c) k.val) ∧
    (total n c:ℚ)/scale ≤ ratioQ (rowOf n) c
noncomputable instance (n : Fin 25) (c : Fin 49) : Decidable (conditions n c) := by
  unfold conditions
  infer_instance

theorem paid (n : Fin 25) (c : Fin 49) (m : degreeBounds n) (h : conditions n c) :
    table (rowOf n) (capOf c) ≤ ratioQ (rowOf n) c := by
  rw [grouped]
  apply le_trans _ h.2
  unfold total
  push_cast
  rw [Finset.sum_div]
  apply Finset.sum_le_sum
  intro k _
  have z := h.1 k
  apply le_trans (div_le_div_of_nonneg_right (m k) z.le)
  unfold upperMass
  have pos : (0:ℚ) < scale := by norm_num [scale]
  rw [div_right_comm]
  exact div_le_div_of_nonneg_right (Int.le_ceil _) pos.le
end PrimeGap180.TablePrices

namespace PrimeGap180.TablePrices
def certified (n : Fin 25) : Prop := degreeBounds n ∧ ∀ c, conditions n c
noncomputable instance (n : Fin 25) : Decidable (certified n) := by unfold certified; infer_instance
def blockIndex (b i : Fin 5) : Fin 25 := ⟨5*b.val+i.val,by omega⟩
end PrimeGap180.TablePrices
