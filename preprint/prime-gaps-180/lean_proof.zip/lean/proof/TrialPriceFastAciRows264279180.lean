import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G264
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 264

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G264

namespace PrimeGap180.PriceIsolatedGroup.G269
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 269

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G269

namespace PrimeGap180.PriceIsolatedGroup.G274
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 274

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G274

namespace PrimeGap180.PriceIsolatedGroup.G279
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 279

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G279
