import TrialDensityTriangleInputs180
namespace PrimeGap180.DensitySimplex.Horner.TriangleChecks
private theorem lower_den8 (z : Fin 2 → ℝ) :
    ((L 8).map (factorValue z)).prod/((unit^3:Int):ℝ) = threeDen (lowerMap (r 8) (s 8) z) := by
  have hr : r 8 = 104193999/10000000000 := by decide +kernel
  have hs : s 8 = 593990501/5000000000 := by decide +kernel
  have forms : L 8 = factors 1396369000 208387998 0 2375962004 := rfl
  rw [hr,hs,forms]
  norm_num [factors,unit,factorValue,Fin.sum_univ_two,threeDen,lowerMap] <;> ring
private theorem upper_den8 (z : Fin 2 → ℝ) :
    ((U 8).map (factorValue z)).prod/((unit^3:Int):ℝ) = threeDen (upperMap (r 8) (s 8) z) := by
  have hr : r 8 = 104193999/10000000000 := by decide +kernel
  have hs : s 8 = 593990501/5000000000 := by decide +kernel
  have forms : U 8 = factors 208387998 0 2375962004 2480156003 := rfl
  rw [hr,hs,forms]
  norm_num [factors,unit,factorValue,Fin.sum_univ_two,threeDen,upperMap] <;> ring

set_option maxRecDepth 65536 in
set_option maxHeartbeats 0 in
theorem row08 : triangleQ (r 8) (s 8) = FrozenNumbers.triangles 8 := by
  rw [triangle_from_forms _ _ (L 8) (U 8) (unit^3) (unit^3) (by decide) (by decide)
    lower_den8 upper_den8]
  decide +kernel

#print axioms row08
end PrimeGap180.DensitySimplex.Horner.TriangleChecks
