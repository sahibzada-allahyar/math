import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G240
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 240

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G240

namespace PrimeGap180.PriceIsolatedGroup.G245
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 245

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G245

namespace PrimeGap180.PriceIsolatedGroup.G250
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 250

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G250

namespace PrimeGap180.PriceIsolatedGroup.G255
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 255

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G255
