import TrialDensityTriangleMaps180
import TrialDensityThreeTail180

noncomputable section
open MeasureTheory Set
namespace PrimeGap180.DensitySimplex

def cornerX (a c : ℝ) := (2*(1-3*c)-(3*a-1))/3
def cornerY (a c : ℝ) := (2*(3*a-1)-(1-3*c))/3

/-- The two polynomial integrals, with exactly the two column determinants of
the triangle parameterizations used in the rational certificate. -/
def triangleApprox (r s : ℝ) :=
  18*(((r+s/2)*s)*(∫ u in region 2 1,threePolynomial (lowerMap r s u)) +
      (r*(s+r/2))*(∫ u in region 2 1,threePolynomial (upperMap r s u)))

theorem threeApprox_triangles (a c : ℝ) (hr : 0 < cornerX a c) (hs : 0 < cornerY a c) :
    threeApprox a c = triangleApprox (cornerX a c) (cornerY a c) := by
  let r := cornerX a c
  let s := cornerY a c
  have A : 1-3*c=2*r+s := by unfold r s cornerX cornerY; ring
  have B : 3*a-1=r+2*s := by unfold r s cornerX cornerY; ring
  have boxL (u v : ℝ) (hu : 0 < u) (hv : 0 < v) :
      lowerPiece u v ⊆ Icc (0 : Fin 2 → ℝ) (fun _ => 2*u+v) := by
    intro z h
    have hx : 0 < z 0 := by
      by_contra! no
      nlinarith [mul_nonpos_of_nonneg_of_nonpos hv.le no,mul_pos hu h.1,h.2.1]
    have hy := h.1
    have top := h.2.2
    constructor <;> intro i <;> fin_cases i
    · exact hx.le
    · exact hy.le
    · change z 0 ≤ 2*u+v
      linarith
    · change z 1 ≤ 2*u+v
      linarith
  have L : IntegrableOn threePolynomial (lowerPiece r s) := (three_polynomial_continuous.continuousOn.integrableOn_compact
    (isCompact_Icc (α := Fin 2 → ℝ) (a:=0) (b:=fun _ => 2*r+s))).mono_set (boxL r s hr hs)
  have upperBox : upperPiece r s ⊆ Icc (0 : Fin 2 → ℝ) (fun _ => 2*s+r) := by
    intro z h
    have inside := boxL s r hs hr (show flip2 z ∈ lowerPiece s r from h)
    constructor <;> intro i <;> fin_cases i
    · exact inside.1 1
    · exact inside.1 0
    · exact inside.2 1
    · exact inside.2 0
  have U : IntegrableOn threePolynomial (upperPiece r s) := (three_polynomial_continuous.continuousOn.integrableOn_compact
    (isCompact_Icc (α := Fin 2 → ℝ) (a:=0) (b:=fun _ => 2*s+r))).mono_set upperBox
  have ms : MeasurableSet (upperPiece r s) := by
    unfold upperPiece lowerPiece
    apply MeasurableSet.preimage _ (show Measurable flip2 by unfold flip2; fun_prop)
    measurability
  unfold threeApprox triangleApprox
  rw [setIntegral_congr_set (polygon_pieces hr hs A B), setIntegral_union (pieces_disjoint _ _) ms L U,
    lower_integral hr hs _ three_polynomial_continuous.measurable,
    upper_integral hr hs _ three_polynomial_continuous.measurable]

private theorem higher_geometry (i : Fin 12) :
    let a := (Sifted.frozenCutoffs i).a
    let c := Frozen.parentCut i
    0 < cornerX a c ∧ 0 < cornerY a c ∧ 1-3*c ≤ 3/20 := by
  fin_cases i <;> norm_num [Sifted.frozenCutoffs,Frozen.parentCut,PriceEvents.lowTicks,cornerX,cornerY]

theorem higher_three_error (i : Fin 12) :
    let a := (Sifted.frozenCutoffs i).a
    let c := Frozen.parentCut i
    |2*Terminal.threeIntegral a c-triangleApprox (cornerX a c) (cornerY a c)| ≤ 2/10^14 := by
  dsimp only
  obtain ⟨hx,hy,hmax⟩ := higher_geometry i
  rw [← threeApprox_triangles _ _ hx hy]
  exact three_loss_error hmax

#print axioms threeApprox_triangles
#print axioms higher_three_error
end PrimeGap180.DensitySimplex
