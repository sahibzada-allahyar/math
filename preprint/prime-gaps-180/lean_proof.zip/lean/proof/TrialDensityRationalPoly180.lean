import TrialDensityFiveTail180
import Mathlib.Algebra.MvPolynomial.Eval

noncomputable section
open MeasureTheory
open scoped BigOperators
namespace PrimeGap180.DensitySimplex
open MvPolynomial

abbrev QPoly (d : ℕ) := MvPolynomial (Fin d) ℚ
def realEval {d : ℕ} (x : Fin d → ℝ) : QPoly d →+* ℝ := eval₂Hom (Rat.castHom ℝ) x

/-- Rational evaluation of a polynomial integral on the simplex of radius t. -/
def momentQ {d : ℕ} (t : ℚ) (p : QPoly d) : ℚ :=
  ∑ e ∈ p.support, p.coeff e *
    (t^(d+∑ i,e i) * (∏ i,((e i).factorial:ℚ)) / ((d+∑ i,e i).factorial:ℚ))

theorem momentQ_correct {d : ℕ} (t : ℚ) (ht : 0 < t) (p : QPoly d) :
    (∫ x in region d (t:ℝ), realEval x p) = (momentQ t p : ℝ) := by
  have value (x : Fin d → ℝ) : realEval x p =
      ∑ e ∈ p.support, ((p.coeff e : ℚ) : ℝ)*DensitySimplex.monomial (fun i => e i) x :=
    MvPolynomial.eval₂_eq' (Rat.castHom ℝ) x p
  simp_rw [value]
  rw [polynomial_integral _ _ _ _ (by exact_mod_cast ht)]
  simp [momentQ]

def geometricQ {d : ℕ} (p : QPoly d) : QPoly d :=
  ∑ j ∈ Finset.range 11, (1-p)^j

@[simp] theorem eval_X {d : ℕ} (z : Fin d → ℝ) (i : Fin d) : realEval z (X i) = z i :=
  MvPolynomial.eval₂_X _ _ _
@[simp] theorem eval_C {d : ℕ} (z : Fin d → ℝ) (q : ℚ) : realEval z (C q) = (q : ℝ) :=
  MvPolynomial.eval₂_C _ _ _

private def fiveQDen : QPoly 4 :=
  let v := X (0 : Fin 4)
  let w := X (1 : Fin 4)
  let x := X (2 : Fin 4)
  let y := X (3 : Fin 4)
  (1-2*v-C (3/4)*w-C (1/3)*x-C (1/3)*y) *
  (1+C (1/2)*v-C (3/4)*w-C (1/3)*x-C (1/3)*y) *
  (1+C (1/2)*v+C (1/2)*w-C (1/3)*x-C (1/3)*y) *
  (1+C (1/2)*v+C (1/2)*w+C (1/2)*x-C (1/3)*y) *
  (1+C (1/2)*v+C (1/2)*w+C (1/2)*x+C (4/3)*y)

set_option maxRecDepth 24000 in
theorem fiveQDen_eval (z : Fin 4 → ℝ) : realEval z fiveQDen = fiveDen z := by
  simp only [fiveQDen,map_sub,map_add,map_mul,map_one,map_ofNat,eval_X,eval_C]
  unfold fiveDen fiveNumerator
  push_cast
  ring

def fiveQ (a : ℚ) := (3125/30:ℚ)*momentQ (5*a-2) (geometricQ fiveQDen)

theorem fiveQ_correct (a : ℚ) (ha : 0 < 5*a-2) : fiveApprox (a:ℝ) = (fiveQ a : ℝ) := by
  have E := momentQ_correct (5*a-2) ha (geometricQ fiveQDen)
  simp [geometricQ,fiveQDen_eval] at E
  simp [fiveApprox,fiveQ,E,geometricQ]

#print axioms momentQ_correct
#print axioms fiveQ_correct
end PrimeGap180.DensitySimplex
