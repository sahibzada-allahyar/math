import TrialPriceTransposeStep180

namespace PrimeGap180.PriceTranspose

def highPart (k x : Nat) := (x/scale k)*scale k
def lowPart (k x : Nat) := x%scale k
def toggle (k x : Nat) := (x/scale k)%2
def mixed (k x y : Nat) := highPart k x+lowPart k y

set_option maxRecDepth 4096 in
/-- A one-dimensional identity on nine binary positions and 512 indices. -/
private theorem pieces : ∀ (k : Fin 9) (x : Fin 512),
    (toggle k.val x.val=0 ∨ toggle k.val x.val=1) ∧
    highPart k.val x.val = highPart (k.val+1) x.val + toggle k.val x.val*scale k.val ∧
    lowPart (k.val+1) x.val = toggle k.val x.val*scale k.val + lowPart k.val x.val ∧
    highPart (k.val+1) x.val = (2*scale k.val)*(x.val/(2*scale k.val)) ∧
    lowPart k.val x.val < scale k.val ∧ highPart (k.val+1) x.val+2*scale k.val≤512 := by
  decide +kernel

private theorem mixed_lt (k : Fin 9) (x y : Fin 512) : mixed k.val x.val y.val < 512 := by
  obtain ⟨flag,h,_,_,_,cap⟩ := pieces k x
  have low := (pieces k y).2.2.2.2.1
  unfold mixed;rw [h]
  rcases flag with f|f <;> rw [f] <;> simp only [Nat.zero_mul,Nat.one_mul] <;> omega

private theorem mixed_high (k : Fin 9) (x y : Fin 512) :
    high (scale k.val) (mixed k.val x.val y.val) = decide (toggle k.val x.val=1) := by
  obtain ⟨flag,h,_,hdiv,_,_⟩ := pieces k x
  have lo := (pieces k y).2.2.2.2.1
  have rem : (mixed k.val x.val y.val)%(2*scale k.val) =
      toggle k.val x.val * scale k.val + lowPart k.val y.val := by
    rw [mixed,h,hdiv,Nat.add_assoc,Nat.add_comm ((2*scale k.val)*_),Nat.add_mul_mod_self_left]
    apply Nat.mod_eq_of_lt
    rcases flag with f|f <;> rw [f] <;> simp only [Nat.zero_mul,Nat.one_mul] <;> omega
  rw [high,rem]
  rcases flag with f|f <;> simp [f] <;> omega

def routed (k z i : Nat) : Bool → Bool → Bool
  | true,false => z.testBit (distance k+i)
  | false,true => decide (distance k ≤ i) && z.testBit (i-distance k)
  | _,_ => z.testBit i

private theorem atStep (k : Fin 9) (z r c b : Nat) (rr : r<512) (cc : c<512) (bb : b<64) :
    (step k.val z).testBit (addr r c b) =
    routed k.val z (addr r c b) (high (scale k.val) c) (high (scale k.val) r) := by
  obtain ⟨L,U⟩ := masks k r c b rr cc bb
  have inside : addr r c b<width := by dsimp [addr,width];omega
  cases hcol : high (scale k.val) c <;> cases hrow : high (scale k.val) r <;>
    simp only [step,keep,Nat.testBit_or,Nat.testBit_and,Nat.testBit_xor,Nat.testBit_two_pow_sub_one,
      Nat.testBit_shiftLeft,Nat.testBit_shiftRight,decide_eq_true inside,L,U,hcol,hrow,routed] <;> simp

private theorem leftBit (z i j d : Nat) (bound : d≤i) (same : i-d=j) :
    (decide (d≤i) && z.testBit (i-d)) = z.testBit j := by simp [bound,same]

private theorem step_mixed (k : Fin 9) (z : Nat) (r c : Fin 512) (b : Fin 64) :
    (step k.val z).testBit (addr (mixed k.val r.val c.val) (mixed k.val c.val r.val) b.val) =
    z.testBit (addr (mixed (k.val+1) r.val c.val) (mixed (k.val+1) c.val r.val) b.val) := by
  obtain ⟨rf,rh,rl,_,_,_⟩ := pieces k r
  obtain ⟨cf,ch,cl,_,_,_⟩ := pieces k c
  rw [atStep k _ _ _ _ (mixed_lt k r c) (mixed_lt k c r) b.isLt,
      mixed_high k c r,mixed_high k r c]
  unfold mixed;rw [rh,ch,rl,cl]
  rcases rf with r0|r1 <;> rcases cf with c0|c1 <;>
    simp only [*,Nat.zero_mul,Nat.one_mul,decide_true,show decide ((0:Nat)=1)=false by decide,Nat.zero_add,Nat.add_zero,routed,addr,distance] <;>
    (first | exact congrArg z.testBit (by omega) | exact leftBit z _ _ _ (by omega) (by omega))

/-- Nine bit-position swaps transpose a 512 by 512 matrix of 64-bit words. -/
def run : Nat → Nat → Nat
  | 0,z => z
  | k+1,z => run k (step k z)

private theorem run_bits (k z : Nat) (bound : k≤9) (r c : Fin 512) (b : Fin 64) :
    (run k z).testBit (addr r.val c.val b.val) =
    z.testBit (addr (mixed k r.val c.val) (mixed k c.val r.val) b.val) := by
  induction k generalizing z with
  | zero => simp [run,mixed,highPart,lowPart,scale,Nat.mod_one]
  | succ k ih =>
    rw [run,ih _ (by omega)]
    exact step_mixed ⟨k,by omega⟩ z r c b

theorem transpose (z : Nat) (r c : Fin 512) (b : Fin 64) :
    (run 9 z).testBit (addr r.val c.val b.val) = z.testBit (addr c.val r.val b.val) := by
  rw [run_bits _ _ (by decide)]
  simp [mixed,highPart,lowPart,scale,Nat.div_eq_of_lt r.isLt,Nat.div_eq_of_lt c.isLt,
    Nat.mod_eq_of_lt r.isLt,Nat.mod_eq_of_lt c.isLt]

#print axioms transpose
end PrimeGap180.PriceTranspose
