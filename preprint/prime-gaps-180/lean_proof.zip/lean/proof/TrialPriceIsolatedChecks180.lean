import TrialPriceEventRowCache180
import Mathlib.Tactic.FinCases

noncomputable section
namespace PrimeGap180.PriceIsolatedChecks
open Book PriceRows

/-- Certify each Gram action separately, keeping independent kernel reductions
small enough to share a worker machine with other parts of the proof. -/
theorem moments_of_entries (g : Group) (values : Array Int) (size : values.size = 101)
    (entries : ∀ i : Fin 101, PriceFactorData.rowAction i.val g.val = values[i.val]!) :
    moments g = values := by
  apply Array.ext
  · simpa only [moments,Array.size_map,Array.size_range] using size.symm
  · intro i hi hj
    have bound : i < 101 := by simpa only [moments,Array.size_map,Array.size_range] using hi
    have atI := (moment g bound).trans (entries ⟨i,bound⟩)
    change (moments g)[i]! = values[i]! at atI
    rw [getElem!_pos (moments g) i hi,getElem!_pos values i hj] at atI
    exact atI

#print axioms moments_of_entries
end PrimeGap180.PriceIsolatedChecks
