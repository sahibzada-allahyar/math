import TrialPriceGainRows180
open scoped BigOperators
namespace PrimeGap180.PriceGainRows
open Book
set_option maxRecDepth 131072
set_option maxHeartbeats 100000000
private theorem g320 : (PriceValues.group 320).gain = ∑ k : Book.Row, row k (320:Group) := by decide +kernel
private theorem g321 : (PriceValues.group 321).gain = ∑ k : Book.Row, row k (321:Group) := by decide +kernel
private theorem g322 : (PriceValues.group 322).gain = ∑ k : Book.Row, row k (322:Group) := by decide +kernel
private theorem g323 : (PriceValues.group 323).gain = ∑ k : Book.Row, row k (323:Group) := by decide +kernel
private theorem g324 : (PriceValues.group 324).gain = ∑ k : Book.Row, row k (324:Group) := by decide +kernel
private theorem g325 : (PriceValues.group 325).gain = ∑ k : Book.Row, row k (325:Group) := by decide +kernel
private theorem g326 : (PriceValues.group 326).gain = ∑ k : Book.Row, row k (326:Group) := by decide +kernel
private theorem g327 : (PriceValues.group 327).gain = ∑ k : Book.Row, row k (327:Group) := by decide +kernel
private theorem g328 : (PriceValues.group 328).gain = ∑ k : Book.Row, row k (328:Group) := by decide +kernel
private theorem g329 : (PriceValues.group 329).gain = ∑ k : Book.Row, row k (329:Group) := by decide +kernel
private theorem g330 : (PriceValues.group 330).gain = ∑ k : Book.Row, row k (330:Group) := by decide +kernel
private theorem g331 : (PriceValues.group 331).gain = ∑ k : Book.Row, row k (331:Group) := by decide +kernel
private theorem g332 : (PriceValues.group 332).gain = ∑ k : Book.Row, row k (332:Group) := by decide +kernel
private theorem g333 : (PriceValues.group 333).gain = ∑ k : Book.Row, row k (333:Group) := by decide +kernel
private theorem g334 : (PriceValues.group 334).gain = ∑ k : Book.Row, row k (334:Group) := by decide +kernel
private theorem g335 : (PriceValues.group 335).gain = ∑ k : Book.Row, row k (335:Group) := by decide +kernel
private theorem g336 : (PriceValues.group 336).gain = ∑ k : Book.Row, row k (336:Group) := by decide +kernel
private theorem g337 : (PriceValues.group 337).gain = ∑ k : Book.Row, row k (337:Group) := by decide +kernel
private theorem g338 : (PriceValues.group 338).gain = ∑ k : Book.Row, row k (338:Group) := by decide +kernel
private theorem g339 : (PriceValues.group 339).gain = ∑ k : Book.Row, row k (339:Group) := by decide +kernel
private theorem g340 : (PriceValues.group 340).gain = ∑ k : Book.Row, row k (340:Group) := by decide +kernel
private theorem g341 : (PriceValues.group 341).gain = ∑ k : Book.Row, row k (341:Group) := by decide +kernel
private theorem g342 : (PriceValues.group 342).gain = ∑ k : Book.Row, row k (342:Group) := by decide +kernel
private theorem g343 : (PriceValues.group 343).gain = ∑ k : Book.Row, row k (343:Group) := by decide +kernel
private theorem g344 : (PriceValues.group 344).gain = ∑ k : Book.Row, row k (344:Group) := by decide +kernel
private theorem g345 : (PriceValues.group 345).gain = ∑ k : Book.Row, row k (345:Group) := by decide +kernel
private theorem g346 : (PriceValues.group 346).gain = ∑ k : Book.Row, row k (346:Group) := by decide +kernel
private theorem g347 : (PriceValues.group 347).gain = ∑ k : Book.Row, row k (347:Group) := by decide +kernel
private theorem g348 : (PriceValues.group 348).gain = ∑ k : Book.Row, row k (348:Group) := by decide +kernel
private theorem g349 : (PriceValues.group 349).gain = ∑ k : Book.Row, row k (349:Group) := by decide +kernel
private theorem g350 : (PriceValues.group 350).gain = ∑ k : Book.Row, row k (350:Group) := by decide +kernel
private theorem g351 : (PriceValues.group 351).gain = ∑ k : Book.Row, row k (351:Group) := by decide +kernel
private theorem g352 : (PriceValues.group 352).gain = ∑ k : Book.Row, row k (352:Group) := by decide +kernel
private theorem g353 : (PriceValues.group 353).gain = ∑ k : Book.Row, row k (353:Group) := by decide +kernel
private theorem g354 : (PriceValues.group 354).gain = ∑ k : Book.Row, row k (354:Group) := by decide +kernel
private theorem g355 : (PriceValues.group 355).gain = ∑ k : Book.Row, row k (355:Group) := by decide +kernel
private theorem g356 : (PriceValues.group 356).gain = ∑ k : Book.Row, row k (356:Group) := by decide +kernel
private theorem g357 : (PriceValues.group 357).gain = ∑ k : Book.Row, row k (357:Group) := by decide +kernel
private theorem g358 : (PriceValues.group 358).gain = ∑ k : Book.Row, row k (358:Group) := by decide +kernel
private theorem g359 : (PriceValues.group 359).gain = ∑ k : Book.Row, row k (359:Group) := by decide +kernel
private theorem g360 : (PriceValues.group 360).gain = ∑ k : Book.Row, row k (360:Group) := by decide +kernel
private theorem g361 : (PriceValues.group 361).gain = ∑ k : Book.Row, row k (361:Group) := by decide +kernel
private theorem g362 : (PriceValues.group 362).gain = ∑ k : Book.Row, row k (362:Group) := by decide +kernel
private theorem g363 : (PriceValues.group 363).gain = ∑ k : Book.Row, row k (363:Group) := by decide +kernel
private theorem g364 : (PriceValues.group 364).gain = ∑ k : Book.Row, row k (364:Group) := by decide +kernel
private theorem g365 : (PriceValues.group 365).gain = ∑ k : Book.Row, row k (365:Group) := by decide +kernel
private theorem g366 : (PriceValues.group 366).gain = ∑ k : Book.Row, row k (366:Group) := by decide +kernel
private theorem g367 : (PriceValues.group 367).gain = ∑ k : Book.Row, row k (367:Group) := by decide +kernel
private theorem g368 : (PriceValues.group 368).gain = ∑ k : Book.Row, row k (368:Group) := by decide +kernel
private theorem g369 : (PriceValues.group 369).gain = ∑ k : Book.Row, row k (369:Group) := by decide +kernel
private theorem g370 : (PriceValues.group 370).gain = ∑ k : Book.Row, row k (370:Group) := by decide +kernel
private theorem g371 : (PriceValues.group 371).gain = ∑ k : Book.Row, row k (371:Group) := by decide +kernel
private theorem g372 : (PriceValues.group 372).gain = ∑ k : Book.Row, row k (372:Group) := by decide +kernel
private theorem g373 : (PriceValues.group 373).gain = ∑ k : Book.Row, row k (373:Group) := by decide +kernel
private theorem g374 : (PriceValues.group 374).gain = ∑ k : Book.Row, row k (374:Group) := by decide +kernel
private theorem g375 : (PriceValues.group 375).gain = ∑ k : Book.Row, row k (375:Group) := by decide +kernel
private theorem g376 : (PriceValues.group 376).gain = ∑ k : Book.Row, row k (376:Group) := by decide +kernel
private theorem g377 : (PriceValues.group 377).gain = ∑ k : Book.Row, row k (377:Group) := by decide +kernel
private theorem g378 : (PriceValues.group 378).gain = ∑ k : Book.Row, row k (378:Group) := by decide +kernel
private theorem g379 : (PriceValues.group 379).gain = ∑ k : Book.Row, row k (379:Group) := by decide +kernel
private theorem g380 : (PriceValues.group 380).gain = ∑ k : Book.Row, row k (380:Group) := by decide +kernel
private theorem g381 : (PriceValues.group 381).gain = ∑ k : Book.Row, row k (381:Group) := by decide +kernel
private theorem g382 : (PriceValues.group 382).gain = ∑ k : Book.Row, row k (382:Group) := by decide +kernel
private theorem g383 : (PriceValues.group 383).gain = ∑ k : Book.Row, row k (383:Group) := by decide +kernel
theorem batch5 : ∀ i : Fin 64, (PriceValues.group (320+i.val)).gain = ∑ k : Book.Row, row k ⟨320+i.val,by omega⟩ :=
  Fin.cases g320 (Fin.cases g321 (Fin.cases g322 (Fin.cases g323 (Fin.cases g324 (Fin.cases g325 (Fin.cases g326 (Fin.cases g327 (Fin.cases g328 (Fin.cases g329 (Fin.cases g330 (Fin.cases g331 (Fin.cases g332 (Fin.cases g333 (Fin.cases g334 (Fin.cases g335 (Fin.cases g336 (Fin.cases g337 (Fin.cases g338 (Fin.cases g339 (Fin.cases g340 (Fin.cases g341 (Fin.cases g342 (Fin.cases g343 (Fin.cases g344 (Fin.cases g345 (Fin.cases g346 (Fin.cases g347 (Fin.cases g348 (Fin.cases g349 (Fin.cases g350 (Fin.cases g351 (Fin.cases g352 (Fin.cases g353 (Fin.cases g354 (Fin.cases g355 (Fin.cases g356 (Fin.cases g357 (Fin.cases g358 (Fin.cases g359 (Fin.cases g360 (Fin.cases g361 (Fin.cases g362 (Fin.cases g363 (Fin.cases g364 (Fin.cases g365 (Fin.cases g366 (Fin.cases g367 (Fin.cases g368 (Fin.cases g369 (Fin.cases g370 (Fin.cases g371 (Fin.cases g372 (Fin.cases g373 (Fin.cases g374 (Fin.cases g375 (Fin.cases g376 (Fin.cases g377 (Fin.cases g378 (Fin.cases g379 (Fin.cases g380 (Fin.cases g381 (Fin.cases g382 (Fin.cases g383 (fun i => Fin.elim0 i))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
#print axioms batch5
end PrimeGap180.PriceGainRows
