import TrialFixedTagIntegral180

/-! Adjacent marked bands split before any signed polynomial is expanded. On
a site with two marks the cross-band term has coefficient one. -/
noncomputable section
open scoped Classical ENNReal BigOperators
open MeasureTheory PrimeGap186 PrimeGap180.JanossyLaw
namespace PrimeGap180.TagBandSplit
open FixedTagIntegral

theorem intensity {e b d : ℝ} (eb : e ≤ b) (bd : b ≤ d) :
    PoissonSplit.intensity e d = PoissonSplit.intensity e b + PoissonSplit.intensity b d := by
  unfold PoissonSplit.intensity
  rw [←Set.Ioc_union_Ioc_eq_Ioc eb bd,
    Measure.restrict_union (Set.Ioc_disjoint_Ioc_of_le le_rfl) measurableSet_Ioc,withDensity_add_measure]

abbrev scan1 (F : FiniteMeasure ℝ → ℝ≥0∞) (Y : FiniteMeasure ℝ) (ν : Measure ℝ) :=
  ∫⁻ v, F (Y + weightedEmpirical 1 (fun _ => v)) ∂ν

abbrev test2 (F : FiniteMeasure ℝ → ℝ≥0∞) (Y : FiniteMeasure ℝ) (q : ℝ × ℝ) :=
  F (Y + weightedEmpirical 2 (MeasurableEquiv.finTwoArrow.symm q))

abbrev scan2 (F : FiniteMeasure ℝ → ℝ≥0∞) (Y : FiniteMeasure ℝ) (ν μ : Measure ℝ) :=
  ∫⁻ q, test2 F Y q ∂ν.prod μ

private theorem swap (F : FiniteMeasure ℝ → ℝ≥0∞) (Y : FiniteMeasure ℝ)
    (q : ℝ × ℝ) : test2 F Y q.swap = test2 F Y q := by
  apply congrArg F
  apply congrArg (fun X : FiniteMeasure ℝ => Y + X)
  apply FiniteMeasure.toMeasure_injective
  rw [coe_weightedEmpirical,coe_weightedEmpirical,Fin.sum_univ_two,Fin.sum_univ_two]
  exact add_comm _ _

private theorem symmetric (F : FiniteMeasure ℝ → ℝ≥0∞) (Y : FiniteMeasure ℝ)
    (ν μ : Measure ℝ) [SFinite ν] [SFinite μ] : scan2 F Y ν μ = scan2 F Y μ ν := by
  unfold scan2
  calc
    _ = ∫⁻ z : ℝ × ℝ, test2 F Y z.swap ∂ν.prod μ := lintegral_congr fun z => (swap F Y z).symm
    _ = _ := lintegral_prod_swap (ν:=ν) (μ:=μ) (test2 F Y)

theorem one {e b d : ℝ} (he : 0<e) (eb : e≤b) (bd : b≤d)
    (F : FiniteMeasure ℝ → ℝ≥0∞) (mF : Measurable F) :
    (∫⁻ X in {X | markCount e X = 1}, F X ∂PoissonSplit.phys d) =
      ∫⁻ Y, scan1 F Y (PoissonSplit.intensity e b) + scan1 F Y (PoissonSplit.intensity b d)
        ∂PoissonSplit.phys e := by
  have whole := fixed he (eb.trans bd) 1 F mF
  simp only [Nat.cast_one] at whole
  rw [whole]
  apply lintegral_congr
  intro Y
  simp only [Nat.factorial_one,Nat.cast_one,inv_one,one_mul]
  have one (ν : Measure ℝ) :
      (∫⁻ u : Fin 1 → ℝ, F (Y + weightedEmpirical 1 u) ∂Measure.pi (fun _ => ν)) = scan1 F Y ν := by
    let f := fun v : ℝ => F (Y + weightedEmpirical 1 (fun _ => v))
    have h := (measurePreserving_funUnique ν (Fin 1)).lintegral_comp_emb
      (MeasurableEquiv.funUnique (Fin 1) ℝ).measurableEmbedding f
    apply Eq.trans _ h
    apply lintegral_congr
    intro u
    apply congrArg F
    apply congrArg (fun X : FiniteMeasure ℝ => Y + X)
    apply congrArg (weightedEmpirical 1)
    funext i
    exact congrArg u (Subsingleton.elim _ _)
  change (∫⁻ _, _ ∂Measure.pi (fun _ : Fin 1 => PoissonSplit.intensity e d)) = _
  rw [one,intensity eb bd]
  exact lintegral_add_measure _ _ _

theorem two {e b d : ℝ} (he : 0<e) (eb : e≤b) (bd : b≤d)
    (F : FiniteMeasure ℝ → ℝ≥0∞) (mF : Measurable F) :
    (∫⁻ X in {X | markCount e X = 2}, F X ∂PoissonSplit.phys d) =
      let lo := PoissonSplit.intensity e b
      let hi := PoissonSplit.intensity b d
      ∫⁻ Y, (2:ℝ≥0∞)⁻¹ * scan2 F Y lo lo + scan2 F Y lo hi +
        (2:ℝ≥0∞)⁻¹ * scan2 F Y hi hi ∂PoissonSplit.phys e := by
  let lo := PoissonSplit.intensity e b
  let hi := PoissonSplit.intensity b d
  let ν := PoissonSplit.intensity e d
  let : IsFiniteMeasure lo := (PoissonSplit.jumps he eb).property
  let : IsFiniteMeasure hi := (PoissonSplit.jumps (he.trans_le eb) bd).property
  let : IsFiniteMeasure ν := (PoissonSplit.jumps he (eb.trans bd)).property
  have whole := fixed he (eb.trans bd) 2 F mF
  simp only [Nat.cast_ofNat] at whole
  rw [whole]
  apply lintegral_congr
  intro Y
  have fact : (2:ℕ).factorial = 2 := by decide
  rw [fact,Nat.cast_ofNat]
  have h := (measurePreserving_finTwoArrow ν).lintegral_comp_emb
    MeasurableEquiv.finTwoArrow.measurableEmbedding (test2 F Y)
  have chart : (∫⁻ u, F (Y + weightedEmpirical 2 u) ∂prodLaw e d 2) = scan2 F Y ν ν := by
    unfold prodLaw scan2
    change (∫⁻ u : Fin 2 → ℝ, F (Y + weightedEmpirical 2 u) ∂Measure.pi (fun _ => ν)) = _
    simpa only [test2,MeasurableEquiv.symm_apply_apply] using h
  rw [chart]
  have sum : ν = lo + hi := intensity eb bd
  have four : scan2 F Y ν ν =
      (scan2 F Y lo lo + scan2 F Y lo hi) + (scan2 F Y hi lo + scan2 F Y hi hi) := by
    unfold scan2
    rw [sum,Measure.add_prod,Measure.prod_add,Measure.prod_add]
    simp only [lintegral_add_measure]
  rw [four,symmetric F Y hi lo]
  let half := (2:ℝ≥0∞)⁻¹
  have one : half + half = 1 := by dsimp [half]; rw [←two_mul]; exact ENNReal.mul_inv_cancel (by norm_num) (by simp)
  let mixed := scan2 F Y lo hi
  calc
    _ = half * scan2 F Y lo lo + (half+half)*mixed + half*scan2 F Y hi hi := by ring
    _ = _ := by rw [one,one_mul]

#print axioms one
#print axioms two
end PrimeGap180.TagBandSplit
