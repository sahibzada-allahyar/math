import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G383
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 383

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G383

namespace PrimeGap180.PriceIsolatedGroup.G388
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 388

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G388

namespace PrimeGap180.PriceIsolatedGroup.G393
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 393

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G393

namespace PrimeGap180.PriceIsolatedGroup.G398
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 398

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G398
