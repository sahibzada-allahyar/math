import TrialMarkedCover180
import TrialTripleHingeCover180

/-! The signed upper bound with the literal full three-prime hinge on all
retained cells. The positive mark bins may vary in width. -/
noncomputable section
open scoped Classical BigOperators Topology
open Filter MeasureTheory PrimeGap186 PrimeGap182Analytic PrimeGap180.EventBins
namespace PrimeGap180.Sector

theorem triple_hinge_partition_upper {m : ℕ} {J T : Type*} [Fintype J] [Fintype T]
    (H : Finset ℕ) (hH : H.card = 39) (i : Fin 39)
    (hh : H.orderEmbOfFin hH i ≤ 182)
    (a : Fin (m+2) → ℝ) (ha : StrictMono a) (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (P : J → (Fin 38 → Band m) → Prop) (F : J → Profile 39 m)
    (sep : ∀ j k, j ≠ k → ∀ y, P j y → ¬ P k y)
    (bf : ∀ j, Bornology.IsBounded (Set.range (F j)))
    (mf : ∀ j, Measurable (restrictFace i (P j) (F j)))
    (cf : ∀ j, ∀ᵐ y ∂Measure.pi (fun _ => bandLaw a), ContinuousAt (restrictFace i (P j) (F j)) y)
    (r : J → ℝ) (ζ : T → J → ℝ) (κ L U : T → ℝ) {lo hi peak d : ℝ}
    (hlo : 0 < lo) (hd : 0 < d) (hp : 1+pad < 3*peak)
    (bins : ∀ t, lo ≤ L t ∧ L t ≤ U t ∧ U t ≤ peak ∧ U t ≤ 1)
    (covered : ∀ s, lo < s → s < peak → ∃ t, L t < s ∧ s ≤ U t)
    (hr : ∀ j, 0 ≤ r j) (hz : ∀ t j, 0 < ζ t j ∧ ζ t j < lo)
    (hc : ∀ t, cap ≤ κ t) (below : ∀ t, Marked.rho*κ t < lo)
    (aux : ∀ t j, ζ t j/rho ≤ κ t) (room : ∀ t j, U t+d+2*(r j+ζ t j) < 1)
    (rad : ∀ j y, P j y → rho*∑ q, ∑ v, y q v ≤ r j)
    (b : ℝ → ℕ) {ε : ℝ} (he : 0 < ε) :
    let h : Fin 39 → ℕ := H.orderEmbOfFin hH
    let Z := fun j => restrictFace i (P j) (F j)
    let V := fun j x n => sampledSelbergRoot (face H a i (Z j) x) (fun k => n+h (i.succAbove k))
    let E := fun j => ∫ t, (integralFace a i (Z j) t)^2 ∂Measure.pi (fun _ => bandLaw a)
    ∀ᶠ x : ℝ in atTop, (∑ n ∈ Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊, if Nat.ModEq (presievingModulus H x) n (b x)
      then (if Literal.Three (x^lo) (x^hi) (n+h i) then (2:ℝ) else 0)*(∑ j, V j x n)^2 else 0)/markedScale H x ≤
      (∑ t, ∑ j, (2/(3*peak-1-pad)*(peak*Real.log (U t/L t)-(U t-L t)))*(1/ζ t j)*E j)+ε := by
  classical
  choose K nn elig using fun t => hinge_marks_eligible H hlo (bins t).1 (bins t).2.1
    (bins t).2.2.2 (below t) hd hp
  let event := fun (x : ℝ) (n : ℕ) => if Literal.Three (x^lo) (x^hi) n then (2:ℝ) else 0
  apply marked_cover_upper H hH i a ha first last P F sep bf mf cf r ζ κ (fun t => U t+d)
    K (fun t => 2/(3*peak-1-pad)*(peak*Real.log (U t/L t)-(U t-L t))) lo hr hz hc aux
    (fun t => add_nonneg ((hlo.le.trans (bins t).1).trans (bins t).2.1) hd.le) nn room rad
    (fun t x => primeMarks x (L t) (U t)) (fun _ x l => hinge peak (Real.logb x l)) b event elig
    (fun t => hinge_primeMarks_mass (hlo.trans_le (bins t).1) (bins t).2.1 (bins t).2.2.1 hp) _ _ he
  · filter_upwards [shifted_window_size,eventually_gt_atTop (1:ℝ)] with x sizes hx
    intro n hn N
    obtain ⟨loN,hiN⟩ := Finset.mem_Icc.mp hn
    have size := (sizes n (H.orderEmbOfFin hH i) (Nat.ceil_le.mp loN)
      ((Nat.le_floor_iff (by positivity)).mp hiN) hh).2
    by_cases hit : Literal.Three (x^lo) (x^hi) N
    · simpa [event,hit] using triple_hinge_bins L U hx hp covered size hit
    · simp only [event,ite_eq_right hit]
      exact Finset.sum_nonneg (fun t _ => Finset.sum_nonneg (fun p _ => ite_nonneg (hinge_nonneg hp _) le_rfl))
  · filter_upwards with x
    intro n hn N positive p pp dvd
    by_cases hit : Literal.Three (x^lo) (x^hi) N
    · obtain ⟨v,w,t,pv,pw,pt,vw,wt,prod,lower,_⟩ := hit
      rw [prod] at dvd
      simp only [pp.dvd_mul,Nat.prime_dvd_prime_iff_eq pp pv,Nat.prime_dvd_prime_iff_eq pp pw,
        Nat.prime_dvd_prime_iff_eq pp pt] at dvd
      exact lower.le.trans (Nat.cast_le.mpr (by omega : v ≤ p))
    · simp [event,hit] at positive

#print axioms triple_hinge_partition_upper
end PrimeGap180.Sector
