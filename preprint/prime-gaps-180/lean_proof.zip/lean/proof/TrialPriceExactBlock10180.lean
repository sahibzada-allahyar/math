import TrialPriceScalar180
namespace PrimeGap180.PriceExactCensus
set_option maxHeartbeats 100000000
set_option maxRecDepth 65536
private theorem c320 : PriceScalar.checked (320 : Book.Label) = true := by decide +kernel
private theorem c321 : PriceScalar.checked (321 : Book.Label) = true := by decide +kernel
private theorem c322 : PriceScalar.checked (322 : Book.Label) = true := by decide +kernel
private theorem c323 : PriceScalar.checked (323 : Book.Label) = true := by decide +kernel
private theorem c324 : PriceScalar.checked (324 : Book.Label) = true := by decide +kernel
private theorem c325 : PriceScalar.checked (325 : Book.Label) = true := by decide +kernel
private theorem c326 : PriceScalar.checked (326 : Book.Label) = true := by decide +kernel
private theorem c327 : PriceScalar.checked (327 : Book.Label) = true := by decide +kernel
private theorem c328 : PriceScalar.checked (328 : Book.Label) = true := by decide +kernel
private theorem c329 : PriceScalar.checked (329 : Book.Label) = true := by decide +kernel
private theorem c330 : PriceScalar.checked (330 : Book.Label) = true := by decide +kernel
private theorem c331 : PriceScalar.checked (331 : Book.Label) = true := by decide +kernel
private theorem c332 : PriceScalar.checked (332 : Book.Label) = true := by decide +kernel
private theorem c333 : PriceScalar.checked (333 : Book.Label) = true := by decide +kernel
private theorem c334 : PriceScalar.checked (334 : Book.Label) = true := by decide +kernel
private theorem c335 : PriceScalar.checked (335 : Book.Label) = true := by decide +kernel
private theorem c336 : PriceScalar.checked (336 : Book.Label) = true := by decide +kernel
private theorem c337 : PriceScalar.checked (337 : Book.Label) = true := by decide +kernel
private theorem c338 : PriceScalar.checked (338 : Book.Label) = true := by decide +kernel
private theorem c339 : PriceScalar.checked (339 : Book.Label) = true := by decide +kernel
private theorem c340 : PriceScalar.checked (340 : Book.Label) = true := by decide +kernel
private theorem c341 : PriceScalar.checked (341 : Book.Label) = true := by decide +kernel
private theorem c342 : PriceScalar.checked (342 : Book.Label) = true := by decide +kernel
private theorem c343 : PriceScalar.checked (343 : Book.Label) = true := by decide +kernel
private theorem c344 : PriceScalar.checked (344 : Book.Label) = true := by decide +kernel
private theorem c345 : PriceScalar.checked (345 : Book.Label) = true := by decide +kernel
private theorem c346 : PriceScalar.checked (346 : Book.Label) = true := by decide +kernel
private theorem c347 : PriceScalar.checked (347 : Book.Label) = true := by decide +kernel
private theorem c348 : PriceScalar.checked (348 : Book.Label) = true := by decide +kernel
private theorem c349 : PriceScalar.checked (349 : Book.Label) = true := by decide +kernel
private theorem c350 : PriceScalar.checked (350 : Book.Label) = true := by decide +kernel
private theorem c351 : PriceScalar.checked (351 : Book.Label) = true := by decide +kernel
theorem block10 : ∀ i : Fin 32, PriceScalar.checked ⟨320+i.val,by omega⟩ = true :=
  Fin.cases c320 (Fin.cases c321 (Fin.cases c322 (Fin.cases c323 (Fin.cases c324 (Fin.cases c325 (Fin.cases c326 (Fin.cases c327 (Fin.cases c328 (Fin.cases c329 (Fin.cases c330 (Fin.cases c331 (Fin.cases c332 (Fin.cases c333 (Fin.cases c334 (Fin.cases c335 (Fin.cases c336 (Fin.cases c337 (Fin.cases c338 (Fin.cases c339 (Fin.cases c340 (Fin.cases c341 (Fin.cases c342 (Fin.cases c343 (Fin.cases c344 (Fin.cases c345 (Fin.cases c346 (Fin.cases c347 (Fin.cases c348 (Fin.cases c349 (Fin.cases c350 (Fin.cases c351 (fun i => Fin.elim0 i))))))))))))))))))))))))))))))))
#print axioms block10
end PrimeGap180.PriceExactCensus
