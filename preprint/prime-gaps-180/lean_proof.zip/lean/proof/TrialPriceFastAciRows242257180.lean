import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G242
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 242

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G242

namespace PrimeGap180.PriceIsolatedGroup.G247
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 247

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G247

namespace PrimeGap180.PriceIsolatedGroup.G252
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 252

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G252

namespace PrimeGap180.PriceIsolatedGroup.G257
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 257

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G257
