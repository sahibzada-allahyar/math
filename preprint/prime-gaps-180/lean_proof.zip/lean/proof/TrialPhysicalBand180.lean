import TrialPrimeScaleBoundaries180
import TrialMinorantMoment180

/-! The source modulus families for descendants of two actual trial roots.
The same prime carrier accounts for the presieve and the fragment primes. -/
noncomputable section
open scoped BigOperators Classical
open Filter PrimeGap186
open PrimeGap180.Distribution
namespace PrimeGap180.Sector

abbrev workingExponent : ℝ := 2624989/2624990

def schedulePrimes (H : Finset ℕ) (x : ℝ) :=
  ((presievingModulus H x).lcm (carrier H x)).primeFactors

theorem schedulePrimes_prime (H : Finset ℕ) (x : ℝ) (p : ℕ) (hp : p ∈ schedulePrimes H x) :
    p.Prime := Nat.prime_of_mem_primeFactors hp

private theorem carrier_coprime (H : Finset ℕ) (x : ℝ) : (carrier H x).Coprime (presievingModulus H x) := by
  apply Nat.Coprime.symm
  apply Nat.Coprime.prod_right
  intro p hp
  exact ((Nat.prime_of_mem_primesLE (Finset.mem_filter.mp hp).1).coprime_iff_not_dvd.mpr
    (Finset.mem_filter.mp hp).2).symm

private theorem divisor_in_schedule {x : ℝ} {H : Finset ℕ} {d e : ℕ}
    (hd : d ∣ carrier H x) (he : e ∣ carrier H x) :
    (presievingModulus H x).lcm (d.lcm e) ∣ ∏ p ∈ schedulePrimes H x, p := by
  have sqW : Squarefree (presievingModulus H x) :=
    squarefree_prime_prod _ (fun _ hp => presieve_factor_prime H x hp)
  have sqC : Squarefree (carrier H x) :=
    squarefree_prime_prod _ (fun _ hp => Nat.prime_of_mem_primesLE (Finset.mem_filter.mp hp).1)
  rw [schedulePrimes,Nat.prod_primeFactors_of_squarefree (squarefree_lcm_nat sqW sqC)]
  exact Nat.lcm_dvd (Nat.dvd_lcm_left ..) ((Nat.lcm_dvd hd he).trans (Nat.dvd_lcm_right ..))

/-- A single eventual bound works on every positive integer width, which
is at least one tick, and every modulus band starting at the half-level. -/
theorem presieve_schedule_slack (H : Finset ℕ) :
    ∀ᶠ x : ℝ in atTop, (presievingModulus H x : ℝ) ≤ x^(1/100000000:ℝ) := by
  filter_upwards [Gate.presieve_below_all_powers H {1/100000000} (by simp)] with x hx
  exact hx _ (Finset.mem_singleton_self _)

theorem ordinary_schedule {x : ℝ} (hx : 1 < x) (H : Finset ℕ) {d e : ℕ}
    (hd : d ∣ carrier H x) (he : e ∣ carrier H x)
    (small : (presievingModulus H x : ℝ) ≤ x^(1/100000000:ℝ))
    (half : (d.lcm e : ℝ) ≤ (x^workingExponent)^(1/2:ℝ)) :
    (presievingModulus H x).lcm (d.lcm e) ∈ ordinary 0.4999999 x (schedulePrimes H x) := by
  have sq := squarefree_prime_prod (primes H x) (fun _ hp => Nat.prime_of_mem_primesLE (Finset.mem_filter.mp hp).1)
  have nz := Nat.pos_of_ne_zero (sq.squarefree_of_dvd (Nat.lcm_dvd hd he)).ne_zero
  have sz := Gate.size_after_presieve hx (presieving_pos H x) nz half
    (small.trans (Real.rpow_le_rpow_of_exponent_le hx.le (by norm_num [workingExponent] :
        (1/100000000:ℝ) ≤ 0.4999999-workingExponent*(1/2))))
  exact Finset.mem_filter.mpr ⟨Finset.mem_Icc.mpr
    ⟨Nat.lcm_pos (presieving_pos H x) nz,Nat.le_floor sz⟩,divisor_in_schedule hd he⟩

/-- The positive integer width and the source order of a passing corner
now put the presieved modulus into the actual dense theorem's Finset.
The upper band endpoint is tested on the product before the presieve. -/
theorem dense_schedule {m : ℕ} {L : ℕ} (hL : L.Prime) (H : Finset ℕ)
    {s t : Fin 39 → ℕ} (hs : s ∈ roots 39 H (L:ℝ)) (ht : t ∈ roots 39 H (L:ℝ)) (i : Fin 39)
    (a : Fin (m+2) → ℝ) (ha : Monotone a) (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (rat : ∀ j : Fin (m+1), ∃ u v : ℕ, 0 < v ∧ a j.castSucc = (u:ℝ)/v)
    {δ z w S T level B U θ δsrc : ℝ} {k j d e : ℕ} (oneTick : 1/10000000 ≤ δ)
    (width : δ ≤ δsrc) (order : j ≤ k) (upper : 1/2 ≤ U) (src : U ≤ θ)
    (small : (presievingModulus H L : ℝ) ≤ (L:ℝ)^(1/100000000:ℝ))
    (cs : rootCorner a L workingExponent δ z S level s i) (ct : rootCorner a L workingExponent δ w T level t i)
    (corner : Gate.finiteCorner (Gate.segments z S level) (Gate.segments w T level) δ B S T k)
    (hd : d ∣ ∏ j, s (i.succAbove j)) (he : e ∣ ∏ j, t (i.succAbove j))
    (lower : ((L:ℝ)^workingExponent)^B < (d.lcm e : ℝ))
    (ceiling : (d.lcm e : ℝ) ≤ ((L:ℝ)^workingExponent)^U) :
    (presievingModulus H L).lcm (d.lcm e) ∈ dense j θ δsrc L (schedulePrimes H L) := by
  have hx : 1 < (L:ℝ) := by exact_mod_cast hL.one_lt
  have δ0 : 0 ≤ δ := le_trans (by norm_num) oneTick
  have dC := hd.trans (Nat.dvd_of_mem_divisors (retained_root_data hs i).2)
  have eC := he.trans (Nat.dvd_of_mem_divisors (retained_root_data ht i).2)
  have cp := carrier_coprime H L
  have capWidth : (presievingModulus H L : ℝ) ≤ ((L:ℝ)^workingExponent)^δ := by
    rw [← Real.rpow_mul (zero_lt_one.trans hx).le]
    apply small.trans (Real.rpow_le_rpow_of_exponent_le hx.le _)
    dsimp only [workingExponent]
    linarith only [oneTick]
  have wtn := presieved_divisors_from_corner hL H hs ht i a ha first last rat
    (by norm_num [workingExponent] : 0 < workingExponent) δ0 cs ct corner hd he lower
    (presieving_pos H L) capWidth (cp.of_dvd_left dC) (cp.of_dvd_left eC)
  have sq := (squarefree_prime_prod (primes H L)
    (fun _ hp => Nat.prime_of_mem_primesLE (Finset.mem_filter.mp hp).1)).squarefree_of_dvd (Nat.lcm_dvd dC eC)
  have nz := Nat.pos_of_ne_zero sq.ne_zero
  have sz := Gate.size_after_presieve hx (presieving_pos H L) nz ceiling
    (small.trans (Real.rpow_le_rpow_of_exponent_le hx.le (show 1/100000000 ≤ θ-workingExponent*U by
      dsimp only [workingExponent]; linarith only [upper,src])))
  exact dense_mem (Nat.lcm_pos (presieving_pos H L) nz) sz (divisor_in_schedule dC eC)
    ((Gate.source_scale hx (by norm_num [workingExponent] : workingExponent ≤ 1) δ0).trans
      (Real.rpow_le_rpow_of_exponent_le hx.le width)) (denseDivisibility_mono_order wtn order)

#print axioms ordinary_schedule
#print axioms dense_schedule
end PrimeGap180.Sector
