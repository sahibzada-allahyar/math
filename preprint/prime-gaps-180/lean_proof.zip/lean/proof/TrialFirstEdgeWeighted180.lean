import TrialFirstEdgeCoarseFibers180

/-! Finite physical conditioning for the uncut square. The largest undivided
fiber can be many fine-cap states, since the raw spline sees only 37 prices. -/
noncomputable section
open MeasureTheory Set
open scoped Classical BigOperators
namespace PrimeGap180.FirstEdgeWeighted

private theorem sum_push {X A : Type*} [MeasurableSpace X] [Fintype A] [MeasurableSpace A]
    [MeasurableSingletonClass A] (μ : Measure X) [IsFiniteMeasure μ] (f : X→A) (mf : Measurable f)
    (u : A→ℝ) :
    (∫ x,u (f x) ∂μ)=∑ a,u a*μ.real (f ⁻¹' {a}) := by
  have m : Measurable u:=measurable_of_finite _
  have int := PrimeGap186.integrable_of_measurable_of_bounded_range (μ.map f) _ m (finite_range u).isBounded
  rw [←integral_map mf.aemeasurable (m.aestronglyMeasurable (μ:=μ.map f)),integral_fintype int]
  apply Finset.sum_congr rfl
  intro a _
  rw [smul_eq_mul,mul_comm,Measure.real,Measure.map_apply mf (measurableSet_singleton _)]
  rfl

theorem weighted {X A : Type*} [MeasurableSpace X] [Fintype A] [MeasurableSpace A]
    [MeasurableSingletonClass A] (μ : Measure X) [IsFiniteMeasure μ] (f : X→A) (mf : Measurable f)
    (u : A→ℝ) (S : Set X) (eps : ℝ)
    (piece : ∀ a,u a≠0 →
      (μ.restrict S).real (f ⁻¹' {a}) ≤ eps*μ.real (f ⁻¹' {a})) :
    (∫ x in S,(u (f x))^2 ∂μ) ≤ eps*(∫ x,(u (f x))^2 ∂μ) := by
  rw [sum_push (μ.restrict S) f mf (fun a=>(u a)^2),sum_push μ f mf (fun a=>(u a)^2),
    Finset.mul_sum]
  apply Finset.sum_le_sum
  intro a _
  by_cases nz : u a=0
  · simp [nz]
  · calc
      _ ≤ (u a)^2 * (eps*μ.real (f ⁻¹' {a})) := mul_le_mul_of_nonneg_left (piece a nz) (sq_nonneg _)
      _ = _ := by ring

open PrimeGap180.CoarseLaw PrimeGap180.DebitNativeClasses PrimeGap180.FirstEdgeCoarseFibers
local instance : IsFiniteMeasure μ := PrimeGap180.Sector.bandLaw_finite _

def observation (v : Fin 39→B) := fun j=>seen (v j)

/-- Only nonvanishing true price-profile fibers contribute. -/
theorem original (S : Set (Fin 39→B)) (eps : ℝ)
    (piece : ∀ a,rawAtom a≠0 → ((prod 39).restrict S).real (observation ⁻¹' {a}) ≤
        eps*(prod 39).real (observation ⁻¹' {a})) :
    (∫ v in S,(Restoration.original v)^2 ∂prod 39) ≤
      eps*(∫ v,(Restoration.original v)^2 ∂prod 39) := by
  have m : Measurable observation:=measurable_pi_lambda _ fun j=>seenM.comp (measurable_pi_apply j)
  have eq : (fun v=>(Restoration.original v)^2) =ᵐ[prod 39] (fun v=>(rawAtom (observation v))^2) :=
    raw_observable.mono fun v h=>congrArg (·^2) h
  rw [integral_congr_ae (ae_restrict_of_ae eq),integral_congr_ae eq]
  exact weighted (prod 39) observation m rawAtom S eps piece

#print axioms original
end PrimeGap180.FirstEdgeWeighted
