import TrialHighPanelCover180
import TrialHighPanelSupport180

/-! Enumerate exactly the supported high-edge panels in their native
radial coordinates, before assigning their individual signed payments. -/
noncomputable section
open scoped BigOperators
namespace PrimeGap180.HighPanelCensus
open HighPanelCover HighPanelSupport MassSplineSpan

abbrev Band := Fin 9
abbrev Block := Fin 7
abbrev Span := Fin 30
abbrev Panel := Band × Band × Block × Span

def first (a b : Band) := max 102994 (lowerIndex a + lowerIndex b)
def start (a b : Band) (d : Block) := first a b + d.val*4096
def last (a b : Band) (d : Block) := min (start a b d+4095) (radius b)
def lo (a b : Band) (d : Block) (s : Span) : ℚ := max (sample (start a b d)) (knot s.val)
def hi (a b : Band) (d : Block) (s : Span) : ℚ := min (sample (last a b d)) (knot (s.val+1))
def endIndex (a b : Band) (d : Block) (s : Span) := ⌈HighSplineControls.index (hi a b d s)⌉₊

def live (p : Panel) : Bool :=
  let (a,b,d,s) := p
  decide (a ≤ b ∧ 3 ≤ s.val ∧ start a b d ≤ radius b ∧
    lo a b d s ≤ hi a b d s ∧ lo a b d s < knot (s.val+1))

def panels : Finset Panel := Finset.univ.filter (fun p => live p)

set_option maxRecDepth 50000 in
set_option maxHeartbeats 0 in
theorem count : panels.card = 444 := by decide +kernel

theorem cover {a b : Band} (order : a ≤ b) {j : ℕ} (hj : first a b ≤ j) (hr : j ≤ radius b) :
    ∃ d : Block, ∃ s : Span, (a,b,d,s) ∈ panels ∧
      knot s.val ≤ sample j ∧ sample j < knot (s.val+1) ∧
      ∃ t : ℚ, 0 ≤ t ∧ t ≤ 1 ∧ sample j = lo a b d s+(hi a b d s-lo a b d s)*t ∧
        j ≤ endIndex a b d s := by
  have low : 102994 ≤ first a b := le_max_left _ _
  have high : radius b ≤ 130964 := by fin_cases b <;> decide
  obtain ⟨s,t,s0,s1,ltK,rtK,lr,lK,t0,t1,eq,stop⟩ := covers _ _ j low high hj hr
  have block : (j-first a b)/4096 < 7 := by omega
  let d : Block := ⟨(j-first a b)/4096,block⟩
  let n : Span := ⟨s,s1⟩
  have e : start a b d = leftIndex (first a b) j := rfl
  have a0 : start a b d ≤ radius b := by
    rw [e]
    unfold leftIndex
    omega
  have left : lo a b d n = HighPanelCover.left (first a b) j s := rfl
  have right : hi a b d n = HighPanelCover.right (first a b) (radius b) j s := rfl
  refine ⟨d,n,?_,ltK,rtK,t,t0,t1,?_,?_⟩
  · apply Finset.mem_filter.mpr
    refine ⟨Finset.mem_univ _,?_⟩
    change decide (a ≤ b ∧ 3 ≤ s ∧ start a b d ≤ radius b ∧
      lo a b d n ≤ hi a b d n ∧ lo a b d n < knot (s+1)) = true
    rw [left,right]
    exact decide_eq_true ⟨order,s0,a0,lr,lK⟩
  · rwa [left,right]
  · exact stop

#print axioms count
#print axioms cover
end PrimeGap180.HighPanelCensus
