import TrialPriceReflectedRows180
import Mathlib.Data.List.Basic

namespace PrimeGap180.PriceWordText
open PriceHexRender PriceRowBinding

def charAt (n : Nat) : Char := Char.ofNat (if n < 10 then n+48 else n+87)

theorem glyph_char : ∀ d : Fin 16, String.ofList [charAt d.val] = glyph d := by decide +kernel

theorem chars_render (ds : List (Fin 16)) : String.ofList (ds.map fun d => charAt d.val) = render ds := by
  induction ds with
  | nil => rfl
  | cons d ds ih =>
    change String.ofList ([charAt d.val] ++ ds.map fun e => charAt e.val) = _
    rw [String.ofList_append,glyph_char]
    exact congrArg (glyph d ++ ·) ih

theorem range_mul (a b : Nat) :
    List.range (a*b) = (List.range a).flatMap fun i => (List.range b).map (fun j => i*b+j) := by
  induction a with
  | zero => simp
  | succ a ih => rw [Nat.succ_mul,List.range_add,ih,List.range_succ,List.flatMap_append]; simp

def wordChars (w : Nat) := (List.range 16).map (fun i => charAt (atNibble (w % 2^64) i).val)

def characters (words : List Nat) := words.flatMap wordChars

def pack : List Nat → Nat
  | [] => 0
  | w::ws => w % 2^64 + 2^64*pack ws

theorem raw_zero (w : Nat) : rawLane w 0 = w % 2^64 := by
  change w >>> (64*0) &&& ((2:Nat)^64-1) = _
  exact Nat.and_two_pow_sub_one_eq_mod w 64
theorem raw_succ (w j : Nat) : rawLane w (j+1) = rawLane (w >>> 64) j := by
  unfold rawLane; rw [show 64*(j+1)=64+64*j by omega,Nat.shiftRight_add]
theorem pack_head (w : Nat) (ws : List Nat) : rawLane (pack (w::ws)) 0 = w % 2^64 := by
  rw [raw_zero,pack,Nat.add_mul_mod_self_left,Nat.mod_mod]
theorem pack_tail (w : Nat) (ws : List Nat) : pack (w::ws) >>> 64 = pack ws := by
  rw [Nat.shiftRight_eq_div_pow,pack,Nat.add_mul_div_left _ _ (by decide),Nat.div_eq_of_lt (Nat.mod_lt _ (by decide)),Nat.zero_add]

theorem lane (ws : List Nat) (j : Nat) : rawLane (pack ws) j = (ws[j]?.getD 0) % 2^64 := by
  induction ws generalizing j with
  | nil => simp [pack,rawLane]
  | cons w ws ih =>
    cases j with
    | zero => simpa using pack_head w ws
    | succ j => simpa only [List.getElem?_cons_succ,raw_succ,pack_tail] using ih j

theorem arithmetic_row (ws : List Nat) : characters ws =
    (List.range (ws.length*16)).map (fun i => charAt (atNibble (rawLane (pack ws) (i/16)) (i%16)).val) := by
  rw [range_mul,List.map_flatMap]
  unfold characters
  have enum : ws = (List.range ws.length).map (fun j => ws[j]?.getD 0) := by
    apply List.ext_getElem
    · simp
    · intro i hi hi'
      simp [List.getElem?_eq_getElem hi]
  conv_lhs => rw [enum]
  rw [List.flatMap_map]
  apply List.flatMap_congr
  intro j hj
  unfold wordChars
  rw [List.map_map]
  apply List.map_congr_left
  intro k hk
  have kb := List.mem_range.mp hk
  simp [show (j*16+k)/16=j by omega,show (j*16+k)%16=k by omega,lane]

def text (count : Nat) (r : Nat → List Nat) :=
  String.ofList ((List.range count).flatMap (fun g => characters (r g)))

theorem as_matrix (count rank : Nat) (r : Nat → List Nat) (lengths : ∀ g<count, (r g).length=rank) :
    text count r = (sourceMatrix count rank (fun g => pack (r g))).2 := by
  unfold text sourceMatrix matrix
  apply Eq.trans _ (chars_render _)
  apply congrArg String.ofList
  unfold digits
  rw [List.map_map,show 16*(count*rank)=count*(rank*16) by ac_rfl,range_mul count (rank*16),List.map_flatMap]
  apply List.flatMap_congr
  intro g hg
  rw [arithmetic_row, lengths g (List.mem_range.mp hg),List.map_map]
  apply List.map_congr_left
  intro i hi
  have bound := List.mem_range.mp hi
  have jlt : i/16 < rank := by omega
  have rpos : 0 < rank := by omega
  have d16 : (g*(rank*16)+i)/16 = g*rank+i/16 := by rw [←Nat.mul_assoc]; omega
  have m16 : (g*(rank*16)+i)%16 = i%16 := by rw [←Nat.mul_assoc]; omega
  have rd : (g*rank+i/16)/rank = g := by
    rw [Nat.add_comm,Nat.add_mul_div_right _ _ rpos,Nat.div_eq_of_lt jlt,Nat.zero_add]
  have rm : (g*rank+i/16)%rank = i/16 := by
    rw [Nat.add_comm,Nat.add_mul_mod_self_right,Nat.mod_eq_of_lt jlt]
  simp only [Function.comp_apply,d16,m16,rd,rm]

#print axioms as_matrix
end PrimeGap180.PriceWordText
