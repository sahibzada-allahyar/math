import TrialNoncentralPatterns180

/-! A noncentral ordered tuple has two, four, two or one possible complete
signatures, respectively, for two through five factors. Closed thresholds
are retained in the complements of the strict tests. -/
noncomputable section
open scoped BigOperators Classical
namespace PrimeGap180.Central

set_option maxHeartbeats 1500000 in
private theorem arity2 {a ζ : ℝ} (u : Fin 2 → ℝ) (cuts : CutParameters a ζ)
    (inc : StrictMono u) (_rough : 1-2*a ≤ u 0)
    (low : 1 ≤ ∑ i, u i) (high : ∑ i, u i ≤ 1+collar/4)
    (single : ∀ i, separated a (u i))
    (pair : ∀ i j, i < j → separated a (u i+u j)) :
    signatureWeight (initialFlags u a) (initialFlags u ζ) (pairFlags u a) = 0 := by
  obtain ⟨al,au,zl,zu,za⟩ := cuts
  simp [Fin.sum_univ_succ] at low high
  have o0 := inc (show (0:Fin 2) < 1 by decide)
  have hs0 := single 0
  have hs1 := single 1
  have hp01 := pair 0 1 (by decide)
  simp only [separated] at hs0 hs1 hp01
  have shapes :
      (u 0 < a ∧ ¬(u 1 < a) ∧ ¬(u 0 + u 1 < a) ∧ ¬(u 1 < ζ)) := by
    grind
  have v (t : ℝ) : initialFlags u t = ![decide (u 0 < t), decide (u 1 < t)] := by
    funext i
    fin_cases i <;> rfl
  have m : pairFlags u a =
      ![![false, decide (u 0 + u 1 < a)], ![false, false]] := by
    funext i j
    fin_cases i <;> fin_cases j <;> simp [pairFlags]
  rw [v,v,m]
  rcases shapes with ⟨bs0,bs1,bp01,bz1⟩
  · simp only [bs0, bs1, bp01, bz1, decide_true, decide_false]
    cases decide (u 0 < ζ) <;> decide

set_option maxHeartbeats 1500000 in
private theorem arity3 {a ζ : ℝ} (u : Fin 3 → ℝ) (cuts : CutParameters a ζ)
    (inc : StrictMono u) (rough : 1-2*a ≤ u 0)
    (low : 1 ≤ ∑ i, u i) (high : ∑ i, u i ≤ 1+collar/4)
    (single : ∀ i, separated a (u i))
    (pair : ∀ i j, i < j → separated a (u i+u j)) :
    signatureWeight (initialFlags u a) (initialFlags u ζ) (pairFlags u a) = 0 := by
  obtain ⟨al,au,zl,zu,za⟩ := cuts
  simp [Fin.sum_univ_succ] at low high
  have o0 := inc (show (0:Fin 3) < 1 by decide)
  have o1 := inc (show (1:Fin 3) < 2 by decide)
  have hs0 := single 0
  have hs1 := single 1
  have hs2 := single 2
  have hp01 := pair 0 1 (by decide)
  have hp02 := pair 0 2 (by decide)
  have hp12 := pair 1 2 (by decide)
  simp only [separated] at hs0 hs1 hs2 hp01 hp02 hp12
  have shapes :
      (u 0 < a ∧ u 1 < a ∧ u 2 < a ∧ ¬(u 0 + u 1 < a) ∧ ¬(u 0 + u 2 < a) ∧ ¬(u 1 + u 2 < a) ∧ ¬(u 1 <
       ζ) ∧ ¬(u 2 < ζ)) ∨
      (u 0 < a ∧ u 1 < a ∧ ¬(u 2 < a) ∧ u 0 + u 1 < a ∧ ¬(u 0 + u 2 < a) ∧ ¬(u 1 + u 2 < a) ∧ u 0 < ζ
       ∧ ¬(u 2 < ζ)) := by
    grind (splits := 40)
  have v (t : ℝ) : initialFlags u t = ![decide (u 0 < t), decide (u 1 < t), decide (u 2 < t)] := by
    funext i
    fin_cases i <;> rfl
  have m : pairFlags u a =
      ![![false, decide (u 0 + u 1 < a), decide (u 0 + u 2 < a)],
        ![false, false, decide (u 1 + u 2 < a)],
        ![false, false, false]] := by
    funext i j
    fin_cases i <;> fin_cases j <;> simp [pairFlags]
  rw [v,v,m]
  rcases shapes with ⟨bs0,bs1,bs2,bp01,bp02,bp12,bz1,bz2⟩ | ⟨bs0,bs1,bs2,bp01,bp02,bp12,bz0,bz2⟩
  · simp only [bs0, bs1, bs2, bp01, bp02, bp12, bz1, bz2, decide_true, decide_false]
    cases decide (u 0 < ζ) <;> decide
  · simp only [bs0, bs1, bs2, bp01, bp02, bp12, bz0, bz2, decide_true, decide_false]
    cases decide (u 1 < ζ) <;> decide

set_option maxHeartbeats 1500000 in
private theorem arity4 {a ζ : ℝ} (u : Fin 4 → ℝ) (cuts : CutParameters a ζ)
    (inc : StrictMono u) (rough : 1-2*a ≤ u 0)
    (low : 1 ≤ ∑ i, u i) (high : ∑ i, u i ≤ 1+collar/4)
    (single : ∀ i, separated a (u i))
    (pair : ∀ i j, i < j → separated a (u i+u j)) :
    signatureWeight (initialFlags u a) (initialFlags u ζ) (pairFlags u a) = 0 := by
  obtain ⟨al,au,zl,zu,za⟩ := cuts
  simp [Fin.sum_univ_succ] at low high
  have o0 := inc (show (0:Fin 4) < 1 by decide)
  have o1 := inc (show (1:Fin 4) < 2 by decide)
  have o2 := inc (show (2:Fin 4) < 3 by decide)
  have hs0 := single 0
  have hs1 := single 1
  have hs2 := single 2
  have hs3 := single 3
  have hp01 := pair 0 1 (by decide)
  have hp02 := pair 0 2 (by decide)
  have hp03 := pair 0 3 (by decide)
  have hp12 := pair 1 2 (by decide)
  have hp13 := pair 1 3 (by decide)
  have hp23 := pair 2 3 (by decide)
  simp only [separated] at hs0 hs1 hs2 hs3 hp01 hp02 hp03 hp12 hp13 hp23
  have shapes :
      (u 0 < a ∧ u 1 < a ∧ u 2 < a ∧ u 3 < a ∧ u 0 + u 1 < a ∧ u 0 + u 2 < a ∧ ¬(u 0 + u 3 < a) ∧ u 1
       + u 2 < a ∧ ¬(u 1 + u 3 < a) ∧ ¬(u 2 + u 3 < a) ∧ u 0 < ζ ∧ u 1 < ζ ∧ ¬(u 3 < ζ)) := by
    grind (splits := 40)
  have v (t : ℝ) : initialFlags u t = ![decide (u 0 < t), decide (u 1 < t), decide (u 2 < t), decide (u 3 < t)] := by
    funext i
    fin_cases i <;> rfl
  have m : pairFlags u a =
      ![![false, decide (u 0 + u 1 < a), decide (u 0 + u 2 < a), decide (u 0 + u 3 < a)],
        ![false, false, decide (u 1 + u 2 < a), decide (u 1 + u 3 < a)],
        ![false, false, false, decide (u 2 + u 3 < a)],
        ![false, false, false, false]] := by
    funext i j
    fin_cases i <;> fin_cases j <;> simp [pairFlags]
  rw [v,v,m]
  rcases shapes with ⟨bs0,bs1,bs2,bs3,bp01,bp02,bp03,bp12,bp13,bp23,bz0,bz1,bz3⟩
  · simp only [bs0, bs1, bs2, bs3, bp01, bp02, bp03, bp12, bp13, bp23, bz0, bz1, bz3, decide_true, decide_false]
    cases decide (u 2 < ζ) <;> decide

set_option maxHeartbeats 1500000 in
private theorem arity5 {a ζ : ℝ} (u : Fin 5 → ℝ) (cuts : CutParameters a ζ)
    (inc : StrictMono u) (rough : 1-2*a ≤ u 0)
    (low : 1 ≤ ∑ i, u i) (high : ∑ i, u i ≤ 1+collar/4)
    (single : ∀ i, separated a (u i))
    (pair : ∀ i j, i < j → separated a (u i+u j)) :
    signatureWeight (initialFlags u a) (initialFlags u ζ) (pairFlags u a) = 0 := by
  obtain ⟨al,au,zl,zu,za⟩ := cuts
  simp [Fin.sum_univ_succ] at low high
  have o0 := inc (show (0:Fin 5) < 1 by decide)
  have o1 := inc (show (1:Fin 5) < 2 by decide)
  have o2 := inc (show (2:Fin 5) < 3 by decide)
  have o3 := inc (show (3:Fin 5) < 4 by decide)
  have hs0 := single 0
  have hs1 := single 1
  have hs2 := single 2
  have hs3 := single 3
  have hs4 := single 4
  have hp01 := pair 0 1 (by decide)
  have hp02 := pair 0 2 (by decide)
  have hp03 := pair 0 3 (by decide)
  have hp04 := pair 0 4 (by decide)
  have hp12 := pair 1 2 (by decide)
  have hp13 := pair 1 3 (by decide)
  have hp14 := pair 1 4 (by decide)
  have hp23 := pair 2 3 (by decide)
  have hp24 := pair 2 4 (by decide)
  have hp34 := pair 3 4 (by decide)
  simp only [separated] at hs0 hs1 hs2 hs3 hs4 hp01 hp02 hp03 hp04 hp12 hp13 hp14 hp23 hp24 hp34
  have shapes :
      (u 0 < a ∧ u 1 < a ∧ u 2 < a ∧ u 3 < a ∧ u 4 < a ∧ u 0 + u 1 < a ∧ u 0 + u 2 < a ∧ u 0 + u 3 < a
       ∧ u 0 + u 4 < a ∧ u 1 + u 2 < a ∧ u 1 + u 3 < a ∧ u 1 + u 4 < a ∧ u 2 + u 3 < a ∧ u 2 + u 4 < a
       ∧ u 3 + u 4 < a ∧ u 0 < ζ ∧ u 1 < ζ ∧ u 2 < ζ ∧ u 3 < ζ ∧ u 4 < ζ) := by
    grind (splits := 40)
  have v (t : ℝ) : initialFlags u t = ![decide (u 0 < t), decide (u 1 < t), decide (u 2 < t), decide (u 3 < t), decide (u 4 < t)] := by
    funext i
    fin_cases i <;> rfl
  have m : pairFlags u a =
      ![![false, decide (u 0 + u 1 < a), decide (u 0 + u 2 < a), decide (u 0 + u 3 < a), decide (u 0 + u 4 < a)],
        ![false, false, decide (u 1 + u 2 < a), decide (u 1 + u 3 < a), decide (u 1 + u 4 < a)],
        ![false, false, false, decide (u 2 + u 3 < a), decide (u 2 + u 4 < a)],
        ![false, false, false, false, decide (u 3 + u 4 < a)],
        ![false, false, false, false, false]] := by
    funext i j
    fin_cases i <;> fin_cases j <;> simp [pairFlags]
  rw [v,v,m]
  rcases shapes with ⟨bs0,bs1,bs2,bs3,bs4,bp01,bp02,bp03,bp04,bp12,bp13,bp14,bp23,bp24,bp34,bz0,bz1,bz2,bz3,bz4⟩
  · simp only [bs0, bs1, bs2, bs3, bs4, bp01, bp02, bp03, bp04, bp12, bp13, bp14, bp23, bp24, bp34, bz0, bz1, bz2, bz3, bz4, decide_true]
    decide


theorem noncentral_weight_zero {n : ℕ} (hn : 2 ≤ n) (hn' : n ≤ 5) {a ζ : ℝ}
    (u : Fin n → ℝ) (cuts : CutParameters a ζ) (inc : StrictMono u)
    (rough : ∀ i, 1-2*a ≤ u i) (low : 1 ≤ ∑ i, u i) (high : ∑ i, u i ≤ 1+collar/4)
    (single : ∀ i, separated a (u i)) (pair : ∀ i j, i < j → separated a (u i+u j)) :
    signatureWeight (initialFlags u a) (initialFlags u ζ) (pairFlags u a) = 0 := by
  interval_cases n
  · exact arity2 u cuts inc (rough 0) low high single pair
  · exact arity3 u cuts inc (rough 0) low high single pair
  · exact arity4 u cuts inc (rough 0) low high single pair
  · exact arity5 u cuts inc (rough 0) low high single pair

#print axioms noncentral_weight_zero
end PrimeGap180.Central
