import TrialDiagonalMoment180
import MixedAuxiliaryArithmetic182

/-! The actual canonical array and its erased sectors at the diameter-180
prime cap. Both the band statistics and the prime carrier use this cap. -/
noncomputable section
open scoped Classical BigOperators ENNReal Topology
open MeasureTheory Filter PrimeGap186 PrimeGap182.Selberg PrimeGap180.Distribution
namespace PrimeGap180.Sector

abbrev rho : ℝ := 2624989/10000000
abbrev physicalCap : ℝ := 1668/10000
abbrev cap : ℝ := physicalCap/rho
private theorem cap_pos : 0 < cap := by norm_num [cap,physicalCap,rho]

def scale (x : ℝ) := x^rho
def norm (H : Finset ℕ) (x : ℝ) := fragmentNormalization (presievingModulus H x) (scale x)
def primes (H : Finset ℕ) (x : ℝ) := fragmentPrimes (presievingModulus H x) (scale x) cap
def carrier (H : Finset ℕ) (x : ℝ) := ∏ p ∈ primes H x, p
def roots (d : ℕ) (H : Finset ℕ) (x : ℝ) :=
  (Fintype.piFinset fun _ : Fin d => (carrier H x).divisors).filter fun r => Squarefree (∏ j, r j)

abbrev Band (m : ℕ) := Fin (m+1) → ℝ
abbrev Profile (d m : ℕ) := (Fin d → Band m) → ℝ

def stats {m : ℕ} (a : Fin (m+2) → ℝ) (x : ℝ) (s : ℕ) :=
  fragmentBandMasses a (primeLogConfiguration (scale x) s)

def sample {m d : ℕ} (H : Finset ℕ) (a : Fin (m+2) → ℝ) (F : Profile d m) (x : ℝ) :
    (Fin d → ℕ) →₀ ℝ := ∑ r ∈ roots d H x,
      Finsupp.single r (F (fun j => stats a x (r j)) / norm H x ^ d)

def face {m : ℕ} (H : Finset ℕ) (a : Fin (m+2) → ℝ) (i : Fin 39) (F : Profile 39 m)
    (x : ℝ) : SectorArray :=
  (sample H a F x).sum fun r yr => Finsupp.single (fun j => r (i.succAbove j)) (yr/(r i).totient)

def restrictFace {m : ℕ} (i : Fin 39) (P : (Fin 38 → Band m) → Prop)
    (F : Profile 39 m) : Profile 39 m := fun t => if P (i.removeNth t) then F t else 0

theorem scale_cap {x : ℝ} (hx : 0 ≤ x) : (scale x)^cap = x^physicalCap := by
  rw [scale,← Real.rpow_mul hx]
  norm_num [rho,cap,physicalCap]

private theorem face_value {m : ℕ} (H : Finset ℕ) (a : Fin (m+2) → ℝ) (i : Fin 39)
    (F : Profile 39 m) (x : ℝ) (r : Fin 38 → ℕ) :
    face H a i F x r = ∑ s ∈ (carrier H x).divisors,
      if Squarefree (s * ∏ j, r j) ∧ (∀ j, r j ∈ (carrier H x).divisors) then
        F (fun j => stats a x ((i.insertNth (α := fun _ => ℕ) s r) j)) / norm H x ^ 39 / (s.totient : ℝ) else 0 :=
  by
    simpa only [face,sample,roots,PrimeGap182Analytic.finPiFinset_eq_classical] using
      canonical_erased_profile_sum i (carrier H x).divisors
        (fun t => F (fun j => stats a x (t j)) / norm H x ^ 39) r

/-- A signed column of the price matrix is constant on each retained
sector. Forming its full profile and then erasing the detected coordinate
gives the same signed combination of the retained array, entry by entry. -/
theorem face_weight_retained {m : ℕ} (H : Finset ℕ) (a : Fin (m+2) → ℝ) (i : Fin 39)
    (w : (Fin 38 → Band m) → ℝ) (F : Profile 39 m) (x : ℝ) (r : Fin 38 → ℕ) :
    face H a i (fun t => w (i.removeNth t)*F t) x r =
      w (fun j => stats a x (r j))*face H a i F x r := by
  simp only [face_value,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro s _
  have erase : i.removeNth (fun j => stats a x ((i.insertNth (α := fun _ => ℕ) s r) j)) =
      (fun j => stats a x (r j)) := by
    funext j
    change stats a x ((i.insertNth (α := fun _ => ℕ) s r) (i.succAbove j)) = _
    rw [Fin.insertNth_apply_succAbove]
  rw [erase]
  split_ifs <;> ring

/-- One may attach the retained sector predicate to the original sampled
profile before erasure. The two procedures agree at every retained root. -/
theorem face_restrict {m : ℕ} (H : Finset ℕ) (a : Fin (m+2) → ℝ) (i : Fin 39)
    (P : (Fin 38 → Band m) → Prop) (F : Profile 39 m) (x : ℝ) (r : Fin 38 → ℕ) :
    face H a i (restrictFace i P F) x r =
      if P (fun j => stats a x (r j)) then face H a i F x r else 0 := by
  have erase (s : ℕ) : i.removeNth (fun j => stats a x ((i.insertNth (α := fun _ => ℕ) s r) j)) =
      (fun j => stats a x (r j)) := by
    funext j
    change stats a x ((i.insertNth (α := fun _ => ℕ) s r) (i.succAbove j)) = _
    rw [Fin.insertNth_apply_succAbove]
  simp only [face_value,restrictFace,erase]
  by_cases h : P (fun j => stats a x (r j)) <;> simp [h]

theorem sample_witness {m d : ℕ} {H : Finset ℕ} {a : Fin (m+2) → ℝ} {F : Profile d m}
    {x : ℝ} {s : Fin d → ℕ} (hs : s ∈ (sample H a F x).support) :
    s ∈ roots d H x ∧ F (fun j => stats a x (s j)) ≠ 0 := by
  have h := Finsupp.mem_support_iff.mp hs
  simp only [sample,Finsupp.finsetSum_apply,Finsupp.single_apply] at h
  simp only [Finset.sum_ite_eq'] at h
  exact ⟨(ite_ne_right_iff.mp h).1,(div_ne_zero_iff.mp (ite_ne_right_iff.mp h).2).1⟩

/-- Every surviving descendant belongs to a genuine full root of the
profile on the tested sector. Cancellations can only shrink the support. -/
theorem descendant_witness {m : ℕ} {H : Finset ℕ} {a : Fin (m+2) → ℝ} {i : Fin 39}
    {P : (Fin 38 → Band m) → Prop} {F : Profile 39 m} {x : ℝ} {d : Fin 38 → ℕ}
    (hd : d ∈ descendants (face H a i (restrictFace i P F) x)) :
    ∃ s ∈ roots 39 H x, F (fun j => stats a x (s j)) ≠ 0 ∧
      P (fun j => stats a x (s (i.succAbove j))) ∧ ∀ j, d j ∣ s (i.succAbove j) := by
  obtain ⟨r,hr,dr⟩ := Finset.mem_biUnion.mp hd
  obtain ⟨s,hs,hsr⟩ := Finset.mem_biUnion.mp (Finsupp.support_sum hr)
  have eqn := Finset.mem_singleton.mp (Finsupp.support_single_subset hsr)
  obtain ⟨root,nz⟩ := sample_witness hs
  obtain ⟨on,nonzero⟩ := ite_ne_right_iff.mp nz
  refine ⟨s,root,nonzero,on,?_⟩
  intro j
  have divs := Nat.dvd_of_mem_divisors (Fintype.mem_piFinset.mp dr j)
  simpa only [eqn] using divs

def bandLaw {m : ℕ} (a : Fin (m+2) → ℝ) :=
  ENNReal.ofReal (Real.exp Real.eulerMascheroniConstant * cap) •
    Measure.map (fragmentBandMasses a) (fragmentLaw cap)

def integralFace {m : ℕ} (a : Fin (m+2) → ℝ) (i : Fin 39) (F : Profile 39 m)
    (r : Fin 38 → Band m) := ∫ t, F (i.insertNth t r) ∂bandLaw a

/-- Mixed harmonic limit at the trial cap, including signed inputs and
fixed sector boundaries of measure zero. -/
theorem face_limit {m : ℕ} (H : Finset ℕ) (a : Fin (m+2) → ℝ)
    (ha : StrictMono a) (ha0 : a 0 = 0) (ha1 : a (Fin.last (m+1)) = cap)
    (i : Fin 39) (F G : Profile 39 m) (mf : Measurable F) (mg : Measurable G)
    (bf : Bornology.IsBounded (Set.range F)) (bg : Bornology.IsBounded (Set.range G))
    (cf : ∀ᵐ t ∂Measure.pi (fun _ => bandLaw a), ContinuousAt F t)
    (cg : ∀ᵐ t ∂Measure.pi (fun _ => bandLaw a), ContinuousAt G t) :
    Tendsto (fun x => norm H x^38 * harmonicPair (face H a i F x) (face H a i G x)) atTop
      (𝓝 (∫ r, integralFace a i F r * integralFace a i G r ∂Measure.pi (fun _ => bandLaw a))) := by
  let zero : Profile 38 m := fun _ => 0
  have bz : Bornology.IsBounded (Set.range zero) := by simp [zero]
  have h := canonical_and_erased_polarized_harmonic_tendsto (𝓗 := H) i cap cap_pos a ha ha0 ha1
    zero zero F G measurable_const measurable_const mf mg bz bz bf bg
    (Filter.Eventually.of_forall fun _ => continuousAt_const)
    (Filter.Eventually.of_forall fun _ => continuousAt_const) cf cg
  simpa only [face,sample,roots,carrier,primes,norm,stats,scale,rho,harmonicPair,integralFace,bandLaw,
    PrimeGap182Analytic.finPiFinset_eq_classical,zero,zero_div,Finsupp.single_zero,Finset.sum_const_zero,zero_add] using h

/-- Uniform logarithmic coefficient bound for the same erased array. -/
theorem coefficient_bound {m : ℕ} (H : Finset ℕ) (hH : H.card = 39) (a : Fin (m+2) → ℝ)
    (i : Fin 39) (F : Profile 39 m) (bf : Bornology.IsBounded (Set.range F)) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop, 1 < x ∧ ∀ d,
      |PrimeGap182.Selberg.selbergCoefficient (face H a i F x) d| ≤ C * Real.log x := by
  have bz : Bornology.IsBounded (Set.range (fun _ : Fin 38 → Band m => (0:ℝ))) := by simp
  have h := (canonical_and_erased_finite_coefficient_log_root_subpower (𝓗 := H) (h𝓗_card := hH)
    (J := Unit) i cap cap_pos a (fun _ => 1) (fun _ _ => 0) (fun _ => F)
    (fun _ => bz) (fun _ => bf)).1
  simpa only [face,sample,roots,carrier,primes,norm,stats,scale,rho,
    PrimeGap182Analytic.finPiFinset_eq_classical,Finset.univ_unique,Finset.sum_singleton,zero_div,Finsupp.single_zero,
    Finset.sum_const_zero,zero_add,one_smul] using h


/-- The pointwise bounds and squarefree support required by the physical
diagonal theorem hold for the arrays actually sampled at the trial cap. -/
theorem face_bounds {m : ℕ} (H : Finset ℕ) (hH : H.card = 39) (a : Fin (m+2) → ℝ)
    (i : Fin 39) (F : Profile 39 m) (bf : Bornology.IsBounded (Set.range F)) :
    ∃ M : ℝ, 0 < M ∧ ∀ᶠ x : ℝ in atTop,
      (∀ r ∈ (face H a i F x).support, Squarefree (∏ j, r j) ∧
        ∀ j, r j ∈ (carrier H x).divisors) ∧
      (∀ r, |face H a i F x r| ≤ M / norm H x ^ 38) := by
  obtain ⟨C,hC,bound⟩ := bf.exists_pos_norm_le
  have factor : 0 < Real.exp Real.eulerMascheroniConstant * cap + 1 :=
    add_pos (mul_pos (Real.exp_pos _) cap_pos) zero_lt_one
  refine ⟨_,mul_pos hC factor,?_⟩
  filter_upwards [selberg39_canonical_erased_face (𝓗 := H) (h𝓗_card := hH)
    i cap C cap_pos hC.le] with x law
  let F' : (Fin 39 → FiniteMeasure ℝ) → ℝ := fun t => F (fun j => fragmentBandMasses a (t j))
  have result := law.2.2 F' (fun t => bound _ ⟨_,rfl⟩)
  have hroot := result.2.2.2.2.1
  have hsize := result.2.2.2.2.2
  simp only [face,sample,roots,carrier,primes,norm,stats,scale,rho,
    PrimeGap182Analytic.finPiFinset_eq_classical,F'] at hroot hsize ⊢
  exact ⟨fun r hr => ⟨(hroot r hr).1,(hroot r hr).2.1⟩, fun r => (hsize r).2⟩

/-- The physical cutoff includes every prime of the full progression
modulus, even a prime coming only from the presieve. -/
theorem progression_prime_cap (H : Finset ℕ) :
    ∀ᶠ x : ℝ in atTop, ∀ u v : ℕ, u ∣ carrier H x → v ∣ carrier H x →
      ∀ p : ℕ, p.Prime → p ∣ (presievingModulus H x).lcm (u.lcm v) →
        (p : ℝ) ≤ x^physicalCap := by
  filter_upwards [eventually_gt_atTop (0:ℝ),
    eventually_presieving_factor_lt_rpow H physicalCap (by norm_num [physicalCap])]
    with x hx small
  intro u v hu hv p hp hd
  have hprod := Nat.lcm_dvd (Nat.dvd_mul_right (presievingModulus H x) (carrier H x))
    ((Nat.lcm_dvd hu hv).trans (Nat.dvd_mul_left (carrier H x) (presievingModulus H x)))
  rcases hp.dvd_mul.mp (hd.trans hprod) with hW | hc
  · exact (small _ (Nat.mem_primeFactors.mpr ⟨hp,hW,(presieving_pos H x).ne'⟩)).le
  obtain ⟨l,hl,pl⟩ := (hp.prime.dvd_finsetProd_iff id).mp hc
  have eq : p = l := (Nat.prime_dvd_prime_iff_eq hp (Nat.prime_of_mem_primesLE
    (Finset.mem_filter.mp hl).1)).mp pl
  subst l
  rw [← scale_cap hx.le]
  exact (Nat.cast_le.mpr (Nat.le_of_mem_primesLE (Finset.mem_filter.mp hl).1)).trans
    (Nat.floor_le (Real.rpow_nonneg (Real.rpow_nonneg hx.le _) _))

#print axioms face_bounds
#print axioms progression_prime_cap
#print axioms face_weight_retained
#print axioms face_restrict
#print axioms descendant_witness
#print axioms face_limit
#print axioms coefficient_bound
end PrimeGap180.Sector
