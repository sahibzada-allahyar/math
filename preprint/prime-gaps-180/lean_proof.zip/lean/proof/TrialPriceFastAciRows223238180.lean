import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G223
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 223

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G223

namespace PrimeGap180.PriceIsolatedGroup.G228
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 228

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G228

namespace PrimeGap180.PriceIsolatedGroup.G233
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 233

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G233

namespace PrimeGap180.PriceIsolatedGroup.G238
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 238

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G238
