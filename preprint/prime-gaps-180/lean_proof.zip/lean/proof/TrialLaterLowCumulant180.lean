import TrialLaterLowMomentDerivative180

/-! The physical finite-band logarithmic cumulants and Bell recurrence required by the angular square. -/
noncomputable section
open MeasureTheory Filter Set PrimeGap180.FrozenProfile PrimeGap180.Sector
open scoped Topology
namespace PrimeGap180.LowMomentCumulant
open LowMomentDerivative (M radialMoment)
private def band (l u b r : ℝ) := ∫ t in Ioc l u, LaterLowTransform.kernel (b+r) t
def bandMoment (l u : ℝ) (n : ℕ) (b r : ℝ) :=
  ∫ t in Ioc l u, t^n*Real.exp (-((b+r)*t))
def cumulant (a : Active) (n : ℕ) (s r : ℝ) :=
  let e := LaterLowTransform.edge (FrozenData.tables.tailEdge a)
  bandMoment 0 e n s r + bandMoment e cap n s 0

private theorem band_derivative {l u s r : ℝ} (hl : 0 ≤ l) (hs : 0<s) (hr : 0 ≤ r) :
    HasDerivAt (fun b=>band l u b r) (-(bandMoment l u 0 s r)) s := by
  let ν := volume.restrict (Ioc l u)
  let : IsFiniteMeasure ν := ⟨by rw [Measure.restrict_apply_univ]; simp⟩
  have pos : ∀ᵐ t ∂ν, 0<t :=
    (ae_restrict_mem (μ:=volume) measurableSet_Ioc).mono fun t h=>lt_of_le_of_lt hl h.1
  have meas (b : ℝ) : Measurable (LaterLowTransform.kernel (b+r)) := by unfold LaterLowTransform.kernel; fun_prop
  have int : Integrable (LaterLowTransform.kernel (s+r)) ν := by
    apply (integrable_const (μ:=ν) (s+r)).mono' (meas s).aestronglyMeasurable
    filter_upwards [pos] with t ht
    have nn : 0 ≤ (s+r)*t := mul_nonneg (add_nonneg hs.le hr) ht.le
    have lo := Real.add_one_le_exp (-((s+r)*t))
    have hi := Real.exp_le_one_iff.mpr (neg_nonpos.mpr nn)
    unfold LaterLowTransform.kernel
    rw [neg_mul,Real.norm_eq_abs,abs_le]
    exact ⟨(le_div_iff₀ ht).mpr (by linarith only [lo]),(div_le_iff₀ ht).mpr (by linarith only [hi,nn])⟩
  have der (b t : ℝ) (ht : 0<t) :
      HasDerivAt (fun v => LaterLowTransform.kernel (v+r) t) (-Real.exp (-((b+r)*t))) b := by
    have d : HasDerivAt (fun v:ℝ => -((v+r)*t)) (-t) b := by
      convert ((((hasDerivAt_id b).add_const r).mul_const t).neg) using 1 <;> first | rfl' | simp
    convert (d.exp.sub_const 1).div_const t using 1 <;> first | rfl' | (unfold LaterLowTransform.kernel; simp only [neg_mul]) | (field_simp [ht.ne'] <;> ring)
  have d := hasDerivAt_integral_of_dominated_loc_of_deriv_le (μ:=ν)
    (F:=fun b => LaterLowTransform.kernel (b+r)) (F':=fun b t => -Real.exp (-((b+r)*t)))
    (bound:=fun _ => (1:ℝ)) (Ioi_mem_nhds hs)
    (Eventually.of_forall fun b=>(meas b).aestronglyMeasurable) int
    (by fun_prop) (pos.mono fun t ht b hb=>by
      rw [norm_neg,Real.norm_eq_abs,abs_of_nonneg (Real.exp_pos _).le]
      exact Real.exp_le_one_iff.mpr (neg_nonpos.mpr (mul_nonneg (add_nonneg (le_of_lt hb) hr) ht.le)))
    (integrable_const _) (pos.mono fun t ht b _=>der b t ht)
  simpa only [band,bandMoment,pow_zero,one_mul,integral_neg,ν] using d.2

private theorem band_moment_derivative {l u s r : ℝ} (hl : 0 ≤ l) (n : ℕ) (hs : 0<s) (hr : 0 ≤ r) :
    HasDerivAt (fun b => bandMoment l u n b r) (-(bandMoment l u (n+1) s r)) s := by
  let ν := volume.restrict (Ioc l u)
  let : IsFiniteMeasure ν := ⟨by rw [Measure.restrict_apply_univ]; simp⟩
  have nn : ∀ᵐ t ∂ν, 0 ≤ t ∧ 0 ≤ t := (ae_restrict_mem (μ:=volume) measurableSet_Ioc).mono fun t h=>
    ⟨hl.trans h.1.le,hl.trans h.1.le⟩
  have d := LowMomentDerivative.transform_deriv ν id id measurable_id measurable_id nn n hs hr
  have eq (k : ℕ) (b : ℝ) : M ν id id k b r = bandMoment l u k b r := by
    unfold M bandMoment
    apply integral_congr_ae
    apply Eventually.of_forall
    intro t
    change t^k*Real.exp (-(b*t+r*t)) = t^k*Real.exp (-((b+r)*t))
    rw [add_mul]
  simpa only [eq] using d

theorem cumulant_derivative (a : Active) (n : ℕ) {s r : ℝ} (hs : 0<s) (hr : 0 ≤ r) :
    HasDerivAt (fun b=>cumulant a n b r) (-(cumulant a (n+1) s r)) s := by
  have h0 := band_moment_derivative (l:=0) (u:=LaterLowTransform.edge (FrozenData.tables.tailEdge a)) le_rfl n hs hr
  have h1 := band_moment_derivative (l:=LaterLowTransform.edge (FrozenData.tables.tailEdge a))
    (u:=cap) (FrozenData.tables.tailPos a).le n hs (le_rfl : (0:ℝ) ≤ 0)
  convert h0.add h1 using 1 <;> first | rfl' | (unfold cumulant; ring)

private theorem mass_eq (a : Active) {s r : ℝ} (hs : 0<s) (hr : 0 ≤ r) :
    radialMoment (FrozenData.tables.tailEdge a) 0 s r =
    let e := LaterLowTransform.edge (FrozenData.tables.tailEdge a)
    LaterLowTransform.factor*Real.exp (band 0 e s r + band e cap s 0) := by
  have h := LaterLowTransform.every a ⟨s,hs.le⟩ ⟨r,hr⟩
  let e := LaterLowTransform.edge (FrozenData.tables.tailEdge a)
  have hp : 0 ≤ e := (FrozenData.tables.tailPos a).le
  have hc : e ≤ cap := FrozenData.tables.last ▸ FrozenData.tables.ordered.monotone (Fin.le_last _)
  change (∫ x, Real.exp (-(s*NativeSiteLaw.radial x+
    r*(NativeSiteLaw.radial x-NativeSiteLaw.tail (FrozenData.tables.tailEdge a) x))) ∂bandLaw FrozenData.mesh) =
    LaterLowTransform.factor * Real.exp ((∫ t in (0:ℝ)..e,LaterLowTransform.kernel (s+r) t)+
      ∫ t in e..cap,LaterLowTransform.kernel s t) at h
  rw [intervalIntegral.integral_of_le hp,intervalIntegral.integral_of_le hc] at h
  change (∫ x, (NativeSiteLaw.radial x)^0*Real.exp (-(s*NativeSiteLaw.radial x+
    r*(NativeSiteLaw.radial x-NativeSiteLaw.tail (FrozenData.tables.tailEdge a) x))) ∂bandLaw FrozenData.mesh) = _
  simpa only [pow_zero,one_mul,band,add_zero,e] using h

theorem first (a : Active) {s r : ℝ} (hs : 0<s) (hr : 0 ≤ r) :
    radialMoment (FrozenData.tables.tailEdge a) 1 s r =
    cumulant a 0 s r*radialMoment (FrozenData.tables.tailEdge a) 0 s r := by
  let e := LaterLowTransform.edge (FrozenData.tables.tailEdge a)
  have h0 := band_derivative (l:=0) (u:=e) le_rfl hs hr
  have h1 := band_derivative (l:=e) (u:=cap) (FrozenData.tables.tailPos a).le hs (le_rfl : (0:ℝ) ≤ 0)
  have d := ((h0.add h1).exp.const_mul LaterLowTransform.factor)
  have hd : HasDerivAt (fun b=>radialMoment (FrozenData.tables.tailEdge a) 0 b r)
      (-(cumulant a 0 s r*radialMoment (FrozenData.tables.tailEdge a) 0 s r)) s := by
    apply HasDerivAt.congr_of_eventuallyEq (f:=fun b=>LaterLowTransform.factor*Real.exp (band 0 e b r+band e cap b 0))
    · convert d using 1 <;> first | rfl' | (rw [mass_eq a hs hr]; unfold cumulant; dsimp only [e,Pi.add_apply]; ring)
    · filter_upwards [Ioi_mem_nhds hs] with b hb
      exact mass_eq a hb hr
  exact neg_inj.mp ((LowMomentDerivative.physical_derivative (FrozenData.tables.tailEdge a) 0 hs hr).unique hd)

#print axioms cumulant_derivative
#print axioms first
end PrimeGap180.LowMomentCumulant

namespace PrimeGap180.LowMomentCumulant
open LowMomentDerivative (radialMoment)
open Filter
open scoped Topology BigOperators

-- Pascal's rule in the only orders used by the physical square.
private theorem pascal (n : ℕ) (hn : n<12) (C F : ℕ → ℝ) :
    (∑ k ∈ Finset.range (n+1), (n.choose k:ℝ) *
      (C (k+1)*F (n-k) + C k*F (n-k+1))) =
    ∑ k ∈ Finset.range (n+2), ((n+1).choose k:ℝ) * (C k*F (n+1-k)) := by
  interval_cases n <;> norm_num [Finset.sum_range_succ,Nat.choose] <;> ring

private theorem of_derivatives (F C : ℕ → ℝ → ℝ)
    (fd : ∀ n s, 0<s → HasDerivAt (F n) (-(F (n+1) s)) s)
    (cd : ∀ n s, 0<s → HasDerivAt (C n) (-(C (n+1) s)) s)
    (base : ∀ s, 0<s → F 1 s=C 0 s*F 0 s) :
    ∀ n, n<12 → ∀ s, 0<s → F (n+1) s =
      ∑ k ∈ Finset.range (n+1), (n.choose k:ℝ)*(C k s*F (n-k) s) := by
  intro n
  induction n with
  | zero => intro _ s hs; simpa using base s hs
  | succ n ih =>
    intro hn s hs
    have step (k : ℕ) : HasDerivAt (fun y => (n.choose k:ℝ)*(C k y*F (n-k) y))
        (-((n.choose k:ℝ)*(C (k+1) s*F (n-k) s+C k s*F (n-k+1) s))) s := by
      convert ((cd k s hs).mul (fd (n-k) s hs)).const_mul (n.choose k:ℝ) using 1 <;> first | rfl' | ring
    have h := HasDerivAt.fun_sum (u:=Finset.range (n+1)) (fun k _ => step k)
    have eq : F (n+1) =ᶠ[𝓝 s] (fun y => ∑ k ∈ Finset.range (n+1),
        (n.choose k:ℝ)*(C k y*F (n-k) y)) := by
      filter_upwards [Ioi_mem_nhds hs] with y hy
      exact ih (by omega) y hy
    have same := (fd (n+1) s hs).unique (h.congr_of_eventuallyEq eq)
    rw [Finset.sum_neg_distrib] at same
    exact (neg_inj.mp same).trans (pascal n (by omega) (fun k=>C k s) (fun k=>F k s))

/-- Exact Bell recurrence behind each positive angular moment through degree
twelve. The finite-cap tilted law and the omitted site's zero dust rate both
use this same identity. -/
theorem recurrence (a : Active) (n : ℕ) (hn : n<12) {s r : ℝ} (hs : 0<s) (hr : 0 ≤ r) :
    radialMoment (FrozenData.tables.tailEdge a) (n+1) s r =
    ∑ k ∈ Finset.range (n+1), (n.choose k:ℝ)*(cumulant a k s r*
      radialMoment (FrozenData.tables.tailEdge a) (n-k) s r) :=
  of_derivatives (fun k x => radialMoment (FrozenData.tables.tailEdge a) k x r)
    (fun k x => cumulant a k x r)
    (fun k _ hx=>LowMomentDerivative.physical_derivative _ k hx hr)
    (fun k _ hx=>cumulant_derivative a k hx hr)
    (fun _ hx=>first a hx hr) n hn s hs

#print axioms recurrence
end PrimeGap180.LowMomentCumulant
