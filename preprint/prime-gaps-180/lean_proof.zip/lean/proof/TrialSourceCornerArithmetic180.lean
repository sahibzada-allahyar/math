import TrialRootLookup180

/-! Exact rational evaluation of the two winning branches actually present
in the reduced schedules for the 4,301 source corners. -/
noncomputable section
open PrimeGap180.Sector.Lookup
namespace PrimeGap180.SourceCornerArithmetic

structure QSegment where
  lo : ℚ
  hi : ℚ
  intercept : ℚ
  slope : ℚ
  deriving Inhabited

def QSegment.real (s : QSegment) : Gate.TailSegment := ⟨s.lo,s.hi,s.intercept,s.slope⟩

def QSegment.combine (s t : QSegment) : QSegment :=
  ⟨max s.lo t.lo,min s.hi t.hi,s.intercept+t.intercept,s.slope+t.slope⟩

def QSegment.passes (s : QSegment) (width order bound : ℚ) : Prop :=
  width < s.hi → max s.lo width ≤ s.hi →
    s.intercept+(s.slope+order)*(if 0 ≤ s.slope+order then s.hi else max s.lo width) ≤ bound

instance (s : QSegment) (w k M : ℚ) : Decidable (s.passes w k M) := by unfold QSegment.passes; infer_instance

theorem pass_real (s : QSegment) (w k M : ℚ) (pass : s.passes w k M) : s.real.passes w k M := by
  unfold Gate.TailSegment.passes QSegment.real
  dsimp only
  intro lo hi
  have loQ : w < s.hi := by exact_mod_cast lo
  have hiQ : max s.lo w ≤ s.hi := by exact_mod_cast hi
  have h := pass loQ hiQ
  by_cases sign : 0 ≤ s.slope+k
  · have sr : (0:ℝ) ≤ (s.slope:ℝ)+(k:ℝ) := by exact_mod_cast sign
    rw [ite_eq_left sign] at h
    rw [ite_eq_left sr]
    exact_mod_cast h
  · have sr : ¬(0:ℝ) ≤ (s.slope:ℝ)+(k:ℝ) := by exact_mod_cast sign
    rw [ite_eq_right sign] at h
    rw [ite_eq_right sr]
    exact_mod_cast h

theorem combine_real (s t : QSegment) : (s.combine t).real = s.real.joint t.real := by
  simp [QSegment.combine,QSegment.real,Gate.TailSegment.joint]

def segments (z S L : ℚ) : Fin 4 → QSegment :=
  ![⟨0,z,z,0⟩,⟨0,z,S,-2⟩,⟨0,min z (min (L/3) (L-S)),S,0⟩,
    ⟨max 0 (L-S),min z (L/3),L,-1⟩]

theorem segment_real (z S L : ℚ) (i : Fin 4) :
    (segments z S L i).real = Gate.segments z S L i := by
  fin_cases i <;> simp [segments,QSegment.real,Gate.segments]

structure QCorner where
  z : ℚ
  w : ℚ
  S : ℚ
  T : ℚ
  level : ℚ
  deriving Inhabited

def QCorner.real (c : QCorner) : Corner := ⟨c.z,c.w,c.S,c.T,c.level⟩

def QCorner.check (c : QCorner) (width lower : ℚ) (order kind : ℕ) : Prop :=
  let s := segments c.z c.S c.level
  let t := segments c.w c.T c.level
  let M := lower+width
  if kind=1 then (∀ i, (s i).passes width order M) ∧ (∀ j, (t j).passes width order M) ∧
    ∀ i j, ((s i).combine (t j)).passes width order M
  else kind=4 ∧ order=2 ∧ 2*c.S-c.T ≤ M ∧ 2*c.T-c.S ≤ M ∧
    (∀ i, (s i).passes width 1 (M-c.T)) ∧ ∀ j, (t j).passes width 1 (M-c.S)

instance (c : QCorner) (w b : ℚ) (k mode : ℕ) : Decidable (c.check w b k mode) := by
  unfold QCorner.check
  dsimp only
  split <;> infer_instance

private theorem local_pass (z S L : ℚ) (i : Fin 4) (w k M : ℚ) (ok : (segments z S L i).passes w k M) :
    (Gate.segments z S L i).passes w k M := by rw [←segment_real]; exact pass_real _ _ _ _ ok

private theorem local_joint (z S x T L : ℚ) (i j : Fin 4) (w k M : ℚ)
    (ok : ((segments z S L i).combine (segments x T L j)).passes w k M) :
    ((Gate.segments z S L i).joint (Gate.segments x T L j)).passes w k M := by
  rw [←segment_real,←segment_real,←combine_real]
  exact pass_real _ _ _ _ ok

theorem finite (c : QCorner) (w b : ℚ) (order mode : ℕ) (ok : c.check w b order mode) :
    Gate.finiteCorner (Gate.segments c.real.z c.real.S c.real.level)
      (Gate.segments c.real.w c.real.T c.real.level) w b c.real.S c.real.T order := by
  change Gate.finiteCorner (Gate.segments (c.z:ℝ) c.S c.level) (Gate.segments (c.w:ℝ) c.T c.level)
    (w:ℝ) (b:ℝ) (c.S:ℝ) (c.T:ℝ) order
  unfold QCorner.check at ok
  dsimp only at ok
  split at ok
  · left
    exact ⟨fun i => by simpa using local_pass _ _ _ i _ _ _ (ok.1 i),
      fun j => by simpa using local_pass _ _ _ j _ _ _ (ok.2.1 j),
      fun i j => by simpa using local_joint _ _ _ _ _ i j _ _ _ (ok.2.2 i j)⟩
  · right; right
    obtain ⟨_,eq,ab,ba,left,right⟩ := ok
    exact ⟨eq,by exact_mod_cast ab,by exact_mod_cast ba,
      fun i => by simpa using local_pass _ _ _ i _ _ _ (left i),
      fun j => by simpa using local_pass _ _ _ j _ _ _ (right j)⟩

private theorem joint_swap (a b : Gate.TailSegment) : a.joint b = b.joint a := by
  simp [Gate.TailSegment.joint,max_comm,min_comm,add_comm]

theorem finite_swap {s t : Fin 4 → Gate.TailSegment} {w B S T : ℝ} {k : ℕ}
    (ok : Gate.finiteCorner s t w B S T k) : Gate.finiteCorner t s w B T S k := by
  rcases ok with joint | ⟨k,first | second⟩ | ⟨k,ab,ba,smallA,smallB⟩
  · left
    exact ⟨joint.2.1,joint.1,fun i j => by rw [joint_swap]; exact joint.2.2 j i⟩
  · exact Or.inr (Or.inl ⟨k,Or.inr first⟩)
  · exact Or.inr (Or.inl ⟨k,Or.inl second⟩)
  · exact Or.inr (Or.inr ⟨k,ba,ab,smallB,smallA⟩)

#print axioms finite
#print axioms finite_swap
end PrimeGap180.SourceCornerArithmetic
