import TrialPriceScalar180
namespace PrimeGap180.PriceExactCensus
set_option maxHeartbeats 100000000
set_option maxRecDepth 65536
private theorem c0 : PriceScalar.checked (0 : Book.Label) = true := by decide +kernel
private theorem c1 : PriceScalar.checked (1 : Book.Label) = true := by decide +kernel
private theorem c2 : PriceScalar.checked (2 : Book.Label) = true := by decide +kernel
private theorem c3 : PriceScalar.checked (3 : Book.Label) = true := by decide +kernel
private theorem c4 : PriceScalar.checked (4 : Book.Label) = true := by decide +kernel
private theorem c5 : PriceScalar.checked (5 : Book.Label) = true := by decide +kernel
private theorem c6 : PriceScalar.checked (6 : Book.Label) = true := by decide +kernel
private theorem c7 : PriceScalar.checked (7 : Book.Label) = true := by decide +kernel
private theorem c8 : PriceScalar.checked (8 : Book.Label) = true := by decide +kernel
private theorem c9 : PriceScalar.checked (9 : Book.Label) = true := by decide +kernel
private theorem c10 : PriceScalar.checked (10 : Book.Label) = true := by decide +kernel
private theorem c11 : PriceScalar.checked (11 : Book.Label) = true := by decide +kernel
private theorem c12 : PriceScalar.checked (12 : Book.Label) = true := by decide +kernel
private theorem c13 : PriceScalar.checked (13 : Book.Label) = true := by decide +kernel
private theorem c14 : PriceScalar.checked (14 : Book.Label) = true := by decide +kernel
private theorem c15 : PriceScalar.checked (15 : Book.Label) = true := by decide +kernel
private theorem c16 : PriceScalar.checked (16 : Book.Label) = true := by decide +kernel
private theorem c17 : PriceScalar.checked (17 : Book.Label) = true := by decide +kernel
private theorem c18 : PriceScalar.checked (18 : Book.Label) = true := by decide +kernel
private theorem c19 : PriceScalar.checked (19 : Book.Label) = true := by decide +kernel
private theorem c20 : PriceScalar.checked (20 : Book.Label) = true := by decide +kernel
private theorem c21 : PriceScalar.checked (21 : Book.Label) = true := by decide +kernel
private theorem c22 : PriceScalar.checked (22 : Book.Label) = true := by decide +kernel
private theorem c23 : PriceScalar.checked (23 : Book.Label) = true := by decide +kernel
private theorem c24 : PriceScalar.checked (24 : Book.Label) = true := by decide +kernel
private theorem c25 : PriceScalar.checked (25 : Book.Label) = true := by decide +kernel
private theorem c26 : PriceScalar.checked (26 : Book.Label) = true := by decide +kernel
private theorem c27 : PriceScalar.checked (27 : Book.Label) = true := by decide +kernel
private theorem c28 : PriceScalar.checked (28 : Book.Label) = true := by decide +kernel
private theorem c29 : PriceScalar.checked (29 : Book.Label) = true := by decide +kernel
private theorem c30 : PriceScalar.checked (30 : Book.Label) = true := by decide +kernel
private theorem c31 : PriceScalar.checked (31 : Book.Label) = true := by decide +kernel
theorem block0 : ∀ i : Fin 32, PriceScalar.checked ⟨0+i.val,by omega⟩ = true :=
  Fin.cases c0 (Fin.cases c1 (Fin.cases c2 (Fin.cases c3 (Fin.cases c4 (Fin.cases c5 (Fin.cases c6 (Fin.cases c7 (Fin.cases c8 (Fin.cases c9 (Fin.cases c10 (Fin.cases c11 (Fin.cases c12 (Fin.cases c13 (Fin.cases c14 (Fin.cases c15 (Fin.cases c16 (Fin.cases c17 (Fin.cases c18 (Fin.cases c19 (Fin.cases c20 (Fin.cases c21 (Fin.cases c22 (Fin.cases c23 (Fin.cases c24 (Fin.cases c25 (Fin.cases c26 (Fin.cases c27 (Fin.cases c28 (Fin.cases c29 (Fin.cases c30 (Fin.cases c31 (fun i => Fin.elim0 i))))))))))))))))))))))))))))))))
#print axioms block0
end PrimeGap180.PriceExactCensus
