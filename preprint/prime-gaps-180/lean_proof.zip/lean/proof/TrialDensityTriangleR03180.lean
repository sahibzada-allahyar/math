import TrialDensityTriangleInputs180
namespace PrimeGap180.DensitySimplex.Horner.TriangleChecks
private theorem lower_den3 (z : Fin 2 → ℝ) :
    ((L 3).map (factorValue z)).prod/((unit^3:Int):ℝ) = threeDen (lowerMap (r 3) (s 3) z) := by
  have hr : r 3 = 33793999/10000000000 := by decide +kernel
  have hs : s 3 = 599590501/5000000000 := by decide +kernel
  have forms : L 3 = factors 1266769000 67587998 0 2398362004 := rfl
  rw [hr,hs,forms]
  norm_num [factors,unit,factorValue,Fin.sum_univ_two,threeDen,lowerMap] <;> ring
private theorem upper_den3 (z : Fin 2 → ℝ) :
    ((U 3).map (factorValue z)).prod/((unit^3:Int):ℝ) = threeDen (upperMap (r 3) (s 3) z) := by
  have hr : r 3 = 33793999/10000000000 := by decide +kernel
  have hs : s 3 = 599590501/5000000000 := by decide +kernel
  have forms : U 3 = factors 67587998 0 2398362004 2432156003 := rfl
  rw [hr,hs,forms]
  norm_num [factors,unit,factorValue,Fin.sum_univ_two,threeDen,upperMap] <;> ring

set_option maxRecDepth 65536 in
set_option maxHeartbeats 0 in
theorem row03 : triangleQ (r 3) (s 3) = FrozenNumbers.triangles 3 := by
  rw [triangle_from_forms _ _ (L 3) (U 3) (unit^3) (unit^3) (by decide) (by decide)
    lower_den3 upper_den3]
  decide +kernel

#print axioms row03
end PrimeGap180.DensitySimplex.Horner.TriangleChecks
