import TrialCentralCuts180
import TrialPrimeDistribution180
import TrialIncidence180

/-! Distribution on the central cells for any bounded signed integer weight
determined by the monomial tests. The retained subset may change from tuple
to tuple. Compatible divisor moduli may use any subfamily. -/
noncomputable section
open scoped Classical BigOperators Topology
open Filter PrimeGap186 PrimeGap182Analytic.Harman PrimeGap182Audit
open PrimeGap180.Distribution
namespace PrimeGap180.Central

/-- Increasing the required order of dense divisibility only removes moduli. -/
theorem bilinear_order {i j : ℕ} {w d σ : ℝ} (le : i ≤ j)
    (src : SourceBilinearEstimate i w d σ) : SourceBilinearEstimate j w d σ := by
  intro ι M N α β c C W X k s hc hC hW hX sc supp coeff sw A hA
  obtain ⟨K,Y,hK,hY,bnd⟩ := src M N α β c C W X k s hc hC hW hX sc supp coeff sw A hA
  refine ⟨K,Y,hK,hY,?_⟩
  intro x hx t I hp a ha
  apply le_trans _ (bnd x hx t I hp a ha)
  apply Finset.sum_le_sum_of_subset_of_nonneg _ (fun _ _ _ => norm_nonneg _)
  intro q hq
  obtain ⟨b,h,wit⟩ := Finset.mem_filter.mp hq
  exact Finset.mem_filter.mpr ⟨b,h,denseDivisibility_mono_order wit le⟩

structure BilinearRoute (j : ℕ) (w d σ : ℝ) : Prop where
  positive : 0 < w ∧ 0 < d ∧ 0 < σ
  source :
    ((1 ≤ j ∧ 54*w+15*d+5*σ < 1 ∨ 2 ≤ j ∧ 56*w+16*d+4*σ < 1) ∧ 68*w+14*d < 1) ∨
    (j = 3 ∧ ∃ high w' d' cap, WorkingWindow w d σ high w' d' cap)

theorem BilinearRoute.estimate {j w d σ} (g : BilinearRoute j w d σ)
    (rank4 : AllIncidenceRankFourBounds) : SourceBilinearEstimate j w d σ := by
  obtain ⟨wp,dp,sp⟩ := g.positive
  rcases g.source with ⟨⟨hj,ht⟩ | ⟨hj,ht⟩,hII⟩ | ⟨rfl,_,_,_,_,win⟩
  · exact bilinear_order hj (sourceBilinearEstimate_lower_order 1 w d σ wp dp sp
      (Or.inl ⟨rfl,ht⟩) hII)
  · exact bilinear_order hj (sourceBilinearEstimate_lower_order 2 w d σ wp dp sp
      (Or.inr ⟨rfl,ht⟩) hII)
  · exact source_bilinear_of_rank_four rank4 win

private theorem weighted_discrepancy {α : Type*} (T : Finset α) (n : α → ℕ)
    (g : α → ℤ) (V : Finset ℤ) (hv : ∀ p ∈ T, g p ≠ 0 → g p ∈ V) (q b : ℕ) :
    fullDiscrepancy (∑ p ∈ T, Finsupp.single (n p) (g p : ℂ)) q b =
      ∑ z ∈ V, (z:ℂ)*fullDiscrepancy
        (∑ p ∈ T, Finsupp.single (n p) (if g p = z then (1:ℂ) else 0)) q b := by
  classical
  simp only [fullDiscrepancy_indexed_sample,Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro p hp
  simp only [← mul_assoc,← Finset.sum_mul,mul_ite,mul_one,mul_zero,Finset.sum_ite_eq]
  by_cases h : g p = 0 <;> simp [h,hv p hp]

def cutTest {k : ℕ} (d : PrimeGap182Analytic.Harman.MinorantSmallMonomialCut k)
    (t : Fin k → ℕ) : Prop :=
  if d.lower then
    if d.strict then d.threshold < d.value t else d.threshold ≤ d.value t
  else if d.strict then d.value t < d.threshold else d.value t ≤ d.threshold

theorem signed_central_distribution {k j : ℕ} (hk : k ≤ 4) (cutCount : ℕ) (hB : 0 < cutCount)
    (V : Finset ℤ) (nonzero : 0 ∉ V) {w d σ edge : ℝ} (he : edge ≤ 1/2)
    (gap : 1/2-edge < σ) (level : w < 1/4) (route : BilinearRoute j w d σ)
    (rank4 : AllIncidenceRankFourBounds) (A : ℝ) (hA : 0 < A) :
    ∃ K : ℝ, 0 < K ∧ ∀ᶠ x : ℝ in atTop,
      ∀ M : Finset (PrimeGap182Analytic.Harman.MinorantSmallMonomialCut (k+1)),
      M.card ≤ cutCount →
      (∀ u ∈ M, u.numerator.Nonempty ∧ Disjoint u.numerator u.denominator ∧
        u.numerator.card+u.denominator.card ≤ k+1 ∧ 0 < u.threshold) →
      let P := (Finset.Icc ⌈x^((4:ℝ)/25)⌉₊ ⌊x^((9:ℝ)/10)⌋₊).filter Nat.Prime
      let T := Fintype.piFinset (fun _ : Fin (k+1) => P)
      ∀ g : (Fin (k+1) → ℕ) → ℤ, (∀ p ∈ T, g p ≠ 0 → g p ∈ V) →
      (∀ p ∈ T, ∀ q ∈ T, (∀ u ∈ M, cutTest u p ↔ cutTest u q) → g p = g q) →
      (∀ p ∈ T, g p ≠ 0 → (∏ i, p i) ∈ window x ∧
        ∃ S : Finset (Fin (k+1)), S.Nonempty ∧ S ≠ Finset.univ ∧
          x^edge ≤ ((∏ i ∈ S, p i : ℕ):ℝ) ∧ ((∏ i ∈ S, p i : ℕ):ℝ) ≤ x^(1-edge)) →
      ∀ (I Q : Finset ℕ) (b : ℕ), (∀ p ∈ I, p.Prime) → b.Coprime (∏ p ∈ I, p) →
        Q ⊆ dense j (1/2+2*w) d x I →
        (∑ q ∈ Q, ‖fullDiscrepancy (∑ p ∈ T, Finsupp.single (∏ i, p i) (g p:ℂ)) q b‖)
          ≤ K*x/(Real.log x)^A := by
  classical
  obtain ⟨wp,dp,_⟩ := route.positive
  obtain ⟨K,X,hK,_,src⟩ := central_cut_distribution hk j cutCount hB w d σ edge he wp dp gap
    level (route.estimate rank4) A hA
  let H := ∑ z ∈ V, ‖(z:ℂ)‖
  have hH : 0 ≤ H := Finset.sum_nonneg fun _ _ => norm_nonneg _
  refine ⟨(1+H)*K,by positivity,?_⟩
  filter_upwards [eventually_ge_atTop X,eventually_gt_atTop (1:ℝ)] with x hX hx
  intro M hM data P T g values test central I Q b hp cop sub
  let D := fun (z : ℤ) q => fullDiscrepancy
    (∑ p ∈ T, Finsupp.single (∏ i, p i) (if g p = z then (1:ℂ) else 0)) q b
  have component (z : ℤ) (hz : z ∈ V) : ∑ q ∈ Q, ‖D z q‖ ≤ K*x/(Real.log x)^A := by
    have out := src x hX M (fun p => g p = z) hM data
      (fun p hp q hq h => by rw [test p hp q hq h])
      (fun p hp eq => central p hp (fun zero => nonzero ((eq.symm.trans zero) ▸ hz))) I hp b cop
    have indicator (t : Fin (k+1) → ℕ) : (if g t = z then (1:ℂ) else 0) =
        @ite ℂ (g t = z) (Classical.propDecidable _) 1 0 := by
      by_cases h : g t = z
      · exact (ite_eq_left h).trans (ite_eq_left h).symm
      · exact (ite_eq_right h).trans (ite_eq_right h).symm
    calc
      _ ≤ ∑ q ∈ dense j (1/2+2*w) d x I, ‖D z q‖ :=
        Finset.sum_le_sum_of_subset_of_nonneg sub (fun _ _ _ => norm_nonneg _)
      _ ≤ _ := by
        dsimp only [D]
        simp_rw [indicator]
        exact out
  calc
    _ ≤ ∑ q ∈ Q, ∑ z ∈ V, ‖(z:ℂ)‖*‖D z q‖ := by
      apply Finset.sum_le_sum
      intro q _
      rw [weighted_discrepancy T _ g V values]
      simpa only [D,norm_mul] using
        (norm_sum_le V (fun z => (z:ℂ)*D z q))
    _ = ∑ z ∈ V, ‖(z:ℂ)‖ * ∑ q ∈ Q, ‖D z q‖ := by
      rw [Finset.sum_comm]
      simp only [Finset.mul_sum]
    _ ≤ ∑ z ∈ V, ‖(z:ℂ)‖ * (K*x/(Real.log x)^A) := Finset.sum_le_sum
      fun z hz => mul_le_mul_of_nonneg_left (component z hz) (norm_nonneg _)
    _ = H*(K*x/(Real.log x)^A) := by simp only [H,Finset.sum_mul]
    _ ≤ (1+H)*(K*x/(Real.log x)^A) := mul_le_mul_of_nonneg_right (by linarith)
      (by have := Real.log_pos hx; positivity)
    _ = _ := by ring

#print axioms signed_central_distribution
end PrimeGap180.Central
