import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G302
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 302

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G302

namespace PrimeGap180.PriceIsolatedGroup.G307
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 307

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G307

namespace PrimeGap180.PriceIsolatedGroup.G312
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 312

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G312

namespace PrimeGap180.PriceIsolatedGroup.G317
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 317

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G317
