import TrialFrozenLedger180

/-! The frozen book admits independent intercept and inverse-price slope
checks. A nonnegative prime price then gives the required inequality on
the entire physical radius interval. -/
noncomputable section
open scoped BigOperators
open PrimeGap180.Book PrimeGap180.Price PrimeGap180.Sector
namespace PrimeGap180.PriceComponents

def fixed (b : Ledger) (s : SectorId) : ℝ :=
  (∑ j : Entry, weight b j (owner s) * base b j s) / b.ref (owner s)

def inverse (b : Ledger) (s : SectorId) : ℝ :=
  (∑ j : Entry, weight b j (owner s) * slope j) / b.ref (owner s)

theorem finite_of_components {b : Ledger} {s : SectorId} (q : ℝ) (up : q ≤ 0.2801)
    (intercept : p0 s.val ≤ fixed b s) (slopeBound : p1 s.val ≤ inverse b s) :
    finitePrice b s q := by
  have nn : 0 ≤ primePrice q := by
    unfold primePrice
    exact div_nonneg (by norm_num) (by linarith)
  exact add_le_add intercept (mul_le_mul_of_nonneg_right slopeBound nn)

theorem endpoints (intercept : ∀ s : SectorId, p0 s.val ≤ fixed FrozenLedger.ledger s)
    (slopeBound : ∀ s : SectorId, p1 s.val ≤ inverse FrozenLedger.ledger s) : FrozenLedger.Endpoints := by
  intro s
  exact ⟨finite_of_components 0 (by norm_num) (intercept s) (slopeBound s),
    finite_of_components _ (capR_bound s.val) (intercept s) (slopeBound s)⟩

#print axioms endpoints
end PrimeGap180.PriceComponents
