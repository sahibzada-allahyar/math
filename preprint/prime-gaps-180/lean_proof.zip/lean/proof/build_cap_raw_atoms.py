"""Regenerate exact 256-bit rounded angular atoms of the archived column of one cap (default 36)."""
import argparse
from pathlib import Path

from build_cap_square import input_tree
from build_historical_site_rows import columns
from cap_bank_names import Names, cap_argument
from check_exact_endpoint_pair import site
from endpoint_pair_arithmetic import COUNT, encode

HERE = Path(__file__).resolve().parent


def generate(destination, exponent, cap=36, dry_run=False):
    if exponent not in range(2, 13):
        raise ValueError(f'The marked cap-{cap} bank uses angular exponents 2 through 12')
    names = Names(cap)
    destination.mkdir(parents=True, exist_ok=True)
    template = names.template('TrialCapRawAtomData180')
    proof = names.template('TrialCapRawAtom180')
    label = f'{exponent:02d}'
    srcs = {}
    if not dry_run:
        values = site(columns()[cap][:COUNT], exponent)
        for scale_tag, ints in [('lo', values.low), ('hi', values.high)]:
            (destination/f'raw-atom-{exponent}-{scale_tag}.bin').write_bytes(encode(ints,80))
    for name, src in [(names.module(f'RawAtomData{label}'), template),
                      (names.module(f'RawAtom{label}'), proof)]:
        src = src.replace('__EXP__',str(exponent)).replace('__LABEL__',label)
        if '__INPUT_TREE__' in src:
            src = src.replace('__INPUT_TREE__',input_tree())
        path = destination/(name+'.lean')
        path.write_text(src)
        srcs[name] = path
    return srcs


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    cap_argument(p)
    p.add_argument('--output-dir', type=Path, required=True)
    p.add_argument('--dry-run', action='store_true', help='write Lean text without words')
    a = p.parse_args()
    for e in range(2, 13):
        for n in generate(a.output_dir, e, a.cap, a.dry_run):
            print(n)
