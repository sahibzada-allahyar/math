import TrialPriceFactorData180
import Batteries.Tactic.OpenPrivate

namespace PrimeGap180.PackedLedger
open private octet from TrialPackedLedger180

/-- The exact little-endian word used by the original hex-string reader. -/
def unsignedFactor (mat : ℕ × String) (g j : ℕ) : ℕ :=
  let off := 16*(g*mat.1+j)
  (List.range 8).foldr (fun k rest => octet mat.2 (off+2*k) + 256*rest) 0

theorem original_sign (mat : ℕ × String) (g j : ℕ) :
    integer mat g j = SourceAffine.signed (unsignedFactor mat g j) := rfl

end PrimeGap180.PackedLedger

namespace PrimeGap180.PriceFactorData

/-- The source reader and the numerical column reader agree on an original
eight-byte word placed at the same group and square-factor index. The archive
reader checks every such placement by the inverse transpose on exact bytes. -/
theorem original_entry (m g j : ℕ) (mat : ℕ × String) (raw : Fin (2^64))
    (source : PackedLedger.unsignedFactor mat g j = raw.val)
    (lane : PriceFactorDigits.slot (word m j) g &&& PriceFactorDigits.full =
      PriceFactorDigits.biasWord raw.val) :
    factor m g j = PackedLedger.integer mat g j := by
  unfold factor PriceFactorDigits.coefficient
  rw [lane,PackedLedger.original_sign,source]
  exact PriceFactorDigits.signed64 raw.isLt

#print axioms original_entry

set_option maxRecDepth 131072
set_option maxHeartbeats 100000000

/-- The two ends of a resource factor and of both signed factor families
exercise the group/column orientation and both native two's-complement signs. -/
private theorem boundary_coefficients :
    factor 0 0 0 = 0 ∧ factor 0 444 215 = -125936854 ∧
    factor 49 0 0 = 10527796 ∧ factor 49 444 319 = -16345670288 ∧
    factor 75 0 0 = -4147776547335 ∧ factor 75 444 124 = -497317 := by decide +kernel

/-- The largest-rank factor has 436 columns. This independent residue also
exercises the whole 85,313-bit Gram projection at its last physical group. -/
private theorem largest_factor_test :
    rank 65 = 436 ∧ diagonal 65 444 = 19324522926854398802 ∧
    (rowAction 65 444) % 1000000007 = 329134922 := by decide +kernel

#print axioms largest_factor_test

private def linearCheck (m : ℕ) := (columns m).toList.all validWord

private theorem scan : Nat.allLTTR 101 (fun i _ => linearCheck i) = true := by decide +kernel

theorem checked (i : Fin 101) : rowCheck i.val = true := by
  have row := (Nat.allLTTR_eq_true.mp scan) i.val i.isLt
  simpa only [linearCheck,Array.all_toList,rowCheck] using row

theorem frozen_projection (i : Fin 101) (j : Fin (rank i.val)) :
    PricePackedRows.pack (PriceFactorDigits.B:ℤ) (fun g : Fin 445 => factor i.val g.val j.val) =
      columnAction i.val j.val := action (checked i) j.isLt

#print axioms checked
#print axioms frozen_projection
end PrimeGap180.PriceFactorData
