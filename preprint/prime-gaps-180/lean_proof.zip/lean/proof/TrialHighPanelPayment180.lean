import TrialHighRationalPanel180

/-! Consume exact signed integer panel comparisons. The common scales are
kept outside the dot product and the tilt is bounded from below. -/
noncomputable section
open scoped BigOperators Classical
namespace PrimeGap180.HighPanelPayment

def term (h lo hi : ℤ) := h * if 0 ≤ h then hi else lo

theorem signed {A : Type*} [Fintype A] (h lo hi : A → ℤ) (K : A → ℝ)
    (den scale : ℝ) (hd : 0 < den) (hs : 0 < scale)
    (lower : ∀ a, (lo a:ℝ) ≤ scale * K a) (upper : ∀ a, scale * K a ≤ (hi a:ℝ)) :
    (∑ a, ((h a:ℝ)/den)*K a) ≤ (∑ a, term (h a) (lo a) (hi a) : ℤ) / (den*scale) := by
  apply (le_div_iff₀ (mul_pos hd hs)).mpr
  rw [Finset.sum_mul,Int.cast_sum]
  apply Finset.sum_le_sum
  intro a _
  have eq : ((h a:ℝ)/den)*K a*(den*scale) = (h a:ℝ)*(scale*K a) := by
    field_simp [hd.ne']
    <;> ring
  rw [eq]
  by_cases pos : 0 ≤ h a
  · simp only [term,if_pos pos,Int.cast_mul]
    exact mul_le_mul_of_nonneg_left (upper a) (by exact_mod_cast pos)
  · simp only [term,if_neg pos,Int.cast_mul]
    exact mul_le_mul_of_nonpos_left (lower a) (by exact_mod_cast (le_of_lt (lt_of_not_ge pos)))

/-- One raw mass unit is `446 / 10^94`. This comparison removes the
geometric tilt using its certified downward dyadic endpoint. -/
theorem mass_units {a r : ℝ} {dot : ℤ} {d t u : ℕ}
    (ha : a ≤ (dot:ℝ)/d) (hr : (t:ℝ)/2^320 ≤ r) (hd : 0 < d)
    (checked : dot * (2^320:ℤ) * 10^94 ≤ (u:ℤ) * d * t * 446) :
    a ≤ ((u:ℝ)*446/10^94)*r := by
  have dt : 0 < (d:ℝ) := by exact_mod_cast hd
  have c : (dot:ℝ)*2^320*10^94 ≤ (u:ℝ)*d*t*446 := by exact_mod_cast checked
  have b : (t:ℝ) ≤ r*2^320 :=
    (div_le_iff₀ (by positivity : (0:ℝ)<2^320)).mp hr
  have scaled := mul_le_mul_of_nonneg_right b
    (show 0 ≤ (u:ℝ)*d*446 by positivity)
  apply ha.trans
  apply (div_le_iff₀ dt).mpr
  have pw : 0 < (2^320:ℝ)*10^94 := by positivity
  apply (mul_le_mul_iff_right₀ pw).mp
  calc
    _ = (dot:ℝ)*2^320*10^94 := by ring
    _ ≤ (u:ℝ)*d*t*446 := c
    _ = (t:ℝ)*((u:ℝ)*d*446) := by ring
    _ ≤ (r*2^320)*((u:ℝ)*d*446) := scaled
    _ = _ := by field_simp

#print axioms signed
#print axioms mass_units
end PrimeGap180.HighPanelPayment
