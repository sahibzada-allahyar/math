import TrialPhysicalTagCount180

/-! Cover the high-mass event by the actual product laws on the one or two
sites owning its marks. Each unordered owner pair occurs once in the sum. -/
noncomputable section
open scoped BigOperators Classical ENNReal
open MeasureTheory PrimeGap186 PrimeGap180.Sector PrimeGap180.RemovedHighTags PrimeGap180.RemovedHighMass
namespace PrimeGap180.HighOwnerProduct
open FixedTagIntegral
open private meas_charged from TrialRemovedHighMass180

private theorem peel {n : Fin 39 → ℕ} {k : ℕ} (hn : ∑ i, n i = k+1) :
    ∃ (a : Fin 39) (g : Fin 39 → ℕ), (∀ i, n i = (if i=a then 1 else 0) + g i) ∧ ∑ i, g i = k := by
  have ex : ∃ i, 0 < n i := by
    by_contra! all
    have z := Finset.sum_eq_zero (s:=Finset.univ) (f:=n) (fun i _ => Nat.eq_zero_of_le_zero (all i))
    omega
  obtain ⟨a,ha⟩ := ex
  let g := fun i => n i - (if i=a then 1 else 0)
  have eq (i) : n i = (if i=a then 1 else 0) + g i := by
    by_cases e : i=a
    · subst i
      simp only [g,ite_true]
      omega
    · simp [g,e]
  refine ⟨a,g,eq,?_⟩
  have h := Finset.sum_congr (s₁:=Finset.univ) rfl (fun i _ => eq i)
  rw [Finset.sum_add_distrib] at h
  have ones : (∑ i : Fin 39, if i = a then (1:ℕ) else 0) = 1 := by simp
  rw [ones,hn] at h
  omega

abbrev Pair := Fin 39 × Fin 39
def pairs : Finset Pair := Finset.univ.filter (fun p => p.1 ≤ p.2)
def countAt (p : Pair) (i : Fin 39) : ℕ :=
  (if i=p.1 then 1 else 0) + (if i=p.2 then 1 else 0)

private theorem assign {n : Fin 39 → ℕ} (hn : ∑ i, n i = 2) :
    ∃ p ∈ pairs, ∀ i, n i = countAt p i := by
  obtain ⟨a,g,first,sg⟩ := peel (k:=1) hn
  obtain ⟨b,f,second,sf⟩ := peel (k:=0) sg
  have zero (i) : f i=0 := Nat.eq_zero_of_le_zero <| sf ▸
    Finset.single_le_sum (fun j _ => Nat.zero_le (f j)) (Finset.mem_univ i)
  by_cases order : a ≤ b
  · exact ⟨(a,b),Finset.mem_filter.mpr ⟨Finset.mem_univ _,order⟩,fun i => by
      rw [first,second,zero,add_zero]; rfl⟩
  · exact ⟨(b,a),Finset.mem_filter.mpr ⟨Finset.mem_univ _,(le_of_lt (lt_of_not_ge order))⟩,fun i => by
      rw [first,second,zero,add_zero]; exact add_comm _ _⟩

def siteSet (p : Pair) (i : Fin 39) := {Y : FiniteMeasure ℝ | markCount cutoff Y = countAt p i}
def box (p : Pair) := Set.univ.pi (siteSet p)
def restrictedLaw (p : Pair) := Measure.pi (fun i => (NativeSiteLaw.phys cap).restrict (siteSet p i))

private theorem mbox (p : Pair) : MeasurableSet (box p) :=
  MeasurableSet.univ_pi (fun i => measurableSet_eq_fun (FixedTagIntegral.count_meas _) measurable_const)

theorem count_pairs : pairs.card = 780 := by decide +kernel

/-- A measurable integrand may depend on all 39 sites and may impose
additional radial or spline restrictions. The 39 common-owner and 741
distinct-owner terms use separate restricted one-site laws. -/
theorem integral (F : Config → ℝ≥0∞) (mF : Measurable F) :
    (∫⁻ X in charged, F X ∂law) ≤ ∑ p ∈ pairs, ∫⁻ X, F X ∂restrictedLaw p := by
  let : IsProbabilityMeasure (fragmentLaw cap) := fragmentLaw_isProbabilityMeasure _
  let : IsFiniteMeasure (NativeSiteLaw.phys cap) := (fragmentLaw cap).smul_finite (by simp)
  have measures (p : Pair) : law.restrict (box p) = restrictedLaw p := Measure.restrict_pi_pi _ _
  have hits : ∀ᵐ X ∂law, X ∈ charged → ∃ p ∈ pairs, X ∈ box p := by
    have allK : ∀ᵐ X ∂law, ∀ k : ℕ, ∀ i : Fin 39,
        HighTagEnergy.count (X i) = k ↔ markCount cutoff (X i) = k := ae_all_iff.mpr PhysicalTagCount.product_ae
    filter_upwards [HighTagEnergy.owners,allK] with X total hX hn
    obtain ⟨p,hp,n⟩ := assign (total hn)
    exact ⟨p,hp,fun i _ => (hX _ i).mp (n i)⟩
  simp_rw [← measures,←lintegral_indicator (mbox _)]
  rw [←lintegral_finsetSum pairs (fun p _ => mF.indicator (mbox p)),←lintegral_indicator meas_charged]
  apply lintegral_mono_ae
  filter_upwards [hits] with X hit
  by_cases h : X ∈ charged
  · obtain ⟨p,hp,hx⟩ := hit h
    rw [Set.indicator_of_mem h]
    calc
      F X = (box p).indicator F X := (Set.indicator_of_mem hx F).symm
      _ ≤ _ := Finset.single_le_sum (f := fun q => (box q).indicator F X) (fun _ _ => zero_le) hp
  · rw [Set.indicator_of_notMem h]
    exact zero_le

#print axioms count_pairs
#print axioms integral
end PrimeGap180.HighOwnerProduct
