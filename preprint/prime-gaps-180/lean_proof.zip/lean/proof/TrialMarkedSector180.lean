import TrialFixedBandLookup180
import TrialMarkedMoment180
import SharpAuxiliaryArrays182

/-! The signed erasure used in the distribution estimate also supplies the
retained array in a marked square. Each mixed pair may choose a larger
common prime carrier containing both auxiliary arrays. -/
noncomputable section
open scoped Classical BigOperators Topology
open MeasureTheory Filter PrimeGap186 PrimeGap182Analytic
namespace PrimeGap180.Sector

private theorem carrier_mono {H : Finset ℕ} {x κ : ℝ} (hx : 1 < x) (hc : cap ≤ κ) :
    (carrier H x).divisors ⊆ (Marked.carrier (presievingModulus H x) x κ).divisors := by
  apply Nat.divisors_subset_of_dvd
  · exact Finset.prod_ne_zero_iff.mpr fun p hp =>
      (Nat.prime_of_mem_primesLE (Finset.mem_filter.mp hp).1).ne_zero
  · apply Finset.prod_dvd_prod_of_subset
    apply Finset.filter_subset_filter
    exact Nat.primesLE_mono (Nat.floor_mono (Real.rpow_le_rpow_of_exponent_le
      (Real.one_le_rpow hx.le (by norm_num [rho])) hc))

theorem retained_product_radius {m d : ℕ} {H : Finset ℕ} {x : ℝ} (hx : 1 < x)
    (a : Fin (m+2) → ℝ) (ha : Monotone a) (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (v : Fin d → ℕ) (sq : Squarefree (∏ j, v j)) (mem : ∀ j, v j ∈ (carrier H x).divisors) :
    ((∏ j, v j : ℕ):ℝ) = x^(rho*∑ i, ∑ j, stats a x (v i) j) := by
  have hR : 1 < scale x := Real.one_lt_rpow hx (by norm_num [rho])
  have each (i : Fin d) := sq.squarefree_of_dvd (Finset.dvd_prod_of_mem v (Finset.mem_univ i))
  simp_rw [fun i => divisor_total_from_bands hx (each i) (mem i) a ha first last]
  rw [Real.rpow_mul (zero_lt_one.trans hx).le]
  change ((∏ j, v j : ℕ):ℝ) = (scale x) ^ (∑ j, Real.logb (scale x) (v j : ℝ))
  rw [← Real.logb_prod _ _ (fun j _ => Nat.cast_ne_zero.mpr (each j).ne_zero),
    Real.rpow_logb (zero_lt_one.trans hR) hR.ne'
      (Finset.prod_pos (fun j _ => Nat.cast_pos.mpr (Nat.pos_of_ne_zero (each j).ne_zero))),Nat.cast_prod]

theorem marked_arrays_of_sector {m : ℕ} (H : Finset ℕ) (hH : H.card = 39)
    (i : Fin 39) (a : Fin (m+2) → ℝ) (ha : Monotone a) (first : a 0 = 0)
    (last : a (Fin.last (m+1)) = cap) (P : (Fin 38 → Band m) → Prop) (F : Profile 39 m)
    (bf : Bornology.IsBounded (Set.range F)) {r ζ κ : ℝ} (hζ : 0 < ζ)
    (hcap : cap ≤ κ) (haux : ζ/rho ≤ κ)
    (radius : ∀ v, P v → rho*∑ i, ∑ j, v i j ≤ r) :
    ∃ M N : ℝ, 0 < M ∧ 0 ≤ N ∧ ∀ᶠ x : ℝ in atTop,
      ∃ A : Marked.Arrays (Marked.carrier (presievingModulus H x) x κ) x
        (fragmentNormalization (presievingModulus H x) x) (norm H x) r ζ M N,
        A.u = sharpAuxiliaryArray H ζ x ∧ A.z = face H a i (restrictFace i P F) x := by
  have bounded : Bornology.IsBounded (Set.range (restrictFace i P F)) := by
    apply (bf.union (Bornology.isBounded_singleton (x := (0:ℝ)))).subset
    rintro y ⟨t,rfl⟩
    by_cases test : P (i.removeNth t) <;> simp [restrictFace,test]
  obtain ⟨M,hM,rootsBound⟩ := face_bounds H hH a i _ bounded
  obtain ⟨N,hN,auxBound⟩ := sharpAuxiliaryArray_bounds H ζ hζ
  refine ⟨M,N,hM,hN,?_⟩
  filter_upwards [rootsBound,auxBound] with x root aux
  have hx := aux.1
  have common := (fragment_divisors_common_cap (presievingModulus H x) x rho κ ζ hx
    (by norm_num [rho])).2
  rw [max_eq_left haux] at common
  refine ⟨⟨_,_,fun t ht => ⟨common (aux.2.2.2 t ht).1,(aux.2.2.2 t ht).2⟩,
    ?_,aux.2.2.1,root.2⟩,rfl,rfl⟩
  intro t ht
  obtain ⟨sq,mem⟩ := root.1 t ht
  have test : P (fun j => stats a x (t j)) := by
    by_contra h
    have ne := Finsupp.mem_support_iff.mp ht
    simp [face_restrict,h] at ne
  refine ⟨sq,fun j => carrier_mono hx hcap (mem j),?_⟩
  rw [retained_product_radius hx a ha first last t sq mem]
  exact Real.rpow_le_rpow_of_exponent_le hx.le (radius _ test)

/-- This counts the same sector-restricted amplitudes as the signed
distribution moment with the actual sharp auxiliary on each side. -/
theorem marked_sector_moment {m : ℕ} (H : Finset ℕ) (hH : H.card = 39) (i : Fin 39)
    (a : Fin (m+2) → ℝ) (ha : Monotone a) (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (P Q : (Fin 38 → Band m) → Prop) (F G : Profile 39 m)
    (bf : Bornology.IsBounded (Set.range F)) (bg : Bornology.IsBounded (Set.range G))
    {r t ζ ω κ s K ε : ℝ} (hr : 0 ≤ r) (ht : 0 ≤ t) (hζ : 0 < ζ) (hω : 0 < ω)
    (hc : cap ≤ κ) (hz : ζ/rho ≤ κ) (hw : ω/rho ≤ κ) (hs : 0 ≤ s) (hK : 0 ≤ K) (he : 0 < ε)
    (roomP : s+2*(r+ζ) < 1) (roomQ : s+2*(t+ω) < 1)
    (radP : ∀ v, P v → rho*∑ i, ∑ j, v i j ≤ r)
    (radQ : ∀ v, Q v → rho*∑ i, ∑ j, v i j ≤ t) :
    ∀ᶠ x : ℝ in atTop, let W := presievingModulus H x
      let h : Fin 39 → ℕ := H.orderEmbOfFin hH
      let u := sharpAuxiliaryArray H ζ x
      let v := sharpAuxiliaryArray H ω x
      let left := face H a i (restrictFace i P F) x
      let right := face H a i (restrictFace i Q G) x
      ∀ (S : Finset ℕ) (w : ℕ → ℝ) (b : ℕ),
        (∀ l ∈ S, 0 < l ∧ W.Coprime l ∧ (Marked.carrier W x κ).Coprime l ∧ 0 ≤ w l) →
        (∑ l ∈ S, w l) ≤ x^s → Marked.mass S w ≤ K →
        |(∑ l ∈ S, w l * Marked.interval (Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊) W b (h i) l
          (auxiliaryProductValue h i u left) (auxiliaryProductValue h i v right)) -
          Marked.mass S w * (x/(W:ℝ) *
            (mixedHarmonic (fun g : Fin 1 → ℕ => ((g 0).totient:ℝ)) u v *
             mixedHarmonic (fun g : Fin 38 → ℕ => ∏ j, ((g j).totient:ℝ)) left right))| ≤
        ε*(x/(W:ℝ)/fragmentNormalization W x/(norm H x)^38) := by
  obtain ⟨M,N,hM,hN,left⟩ := marked_arrays_of_sector H hH i a ha first last P F bf hζ hc hz radP
  obtain ⟨M',N',hM',hN',right⟩ := marked_arrays_of_sector H hH i a ha first last Q G bg hω hc hw radQ
  have pos := lt_of_lt_of_le (show 0 < cap by norm_num [cap,physicalCap,rho]) hc
  filter_upwards [left,right,Marked.marked_mixed_moment hH i κ s r ζ M N t ω M' N' K ε pos hs
    hr hζ hM.le hN ht hω hM'.le hN' hK he roomP roomQ] with x lx rx bound
  obtain ⟨A,au,az⟩ := lx
  obtain ⟨D,du,dz⟩ := rx
  simpa only [au,az,du,dz,norm,scale,Marked.rho,rho] using bound A D

theorem harmonic_disjoint_sectors {m : ℕ} (H : Finset ℕ) (a : Fin (m+2) → ℝ)
    (i : Fin 39) (P Q : (Fin 38 → Band m) → Prop) (sep : ∀ t, P t → ¬ Q t)
    (F G : Profile 39 m) (x : ℝ) :
    mixedHarmonic (fun g : Fin 38 → ℕ => ∏ j, ((g j).totient:ℝ))
      (face H a i (restrictFace i P F) x) (face H a i (restrictFace i Q G) x) = 0 := by
  apply Radial.disjoint_harmonic _ _ _ (Finset.disjoint_left.mpr ?_)
  intro t l r
  have l' := Finsupp.mem_support_iff.mp l
  have r' := Finsupp.mem_support_iff.mp r
  rw [face_restrict] at l' r'
  exact (sep _ (ite_ne_right_iff.mp l').1) (ite_ne_right_iff.mp r').1

/-- A marked diagonal of the actual erased trial has the continuum charge
(mark mass / auxiliary radius) times its signed erased energy. -/
theorem marked_sector_diagonal_limit {m : ℕ} (H : Finset ℕ) (hH : H.card = 39) (i : Fin 39)
    (a : Fin (m+2) → ℝ) (ha : StrictMono a) (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (P : (Fin 38 → Band m) → Prop) (F : Profile 39 m) (bf : Bornology.IsBounded (Set.range F))
    (mf : Measurable (restrictFace i P F)) (cf : ∀ᵐ y ∂Measure.pi (fun _ => bandLaw a),
      ContinuousAt (restrictFace i P F) y)
    {r ζ κ s K C : ℝ} (hr : 0 ≤ r) (hz : 0 < ζ) (hc : cap ≤ κ) (aux : ζ/rho ≤ κ)
    (hs : 0 ≤ s) (hK : 0 ≤ K) (room : s+2*(r+ζ) < 1)
    (radius : ∀ y, P y → rho*∑ j, ∑ k, y j k ≤ r)
    (S : ℝ → Finset ℕ) (w : ℝ → ℕ → ℝ) (b : ℝ → ℕ)
    (eligible : ∀ᶠ x : ℝ in atTop, let W := presievingModulus H x
      (∀ l ∈ S x, 0 < l ∧ W.Coprime l ∧ (Marked.carrier W x κ).Coprime l ∧ 0 ≤ w x l) ∧
      (∑ l ∈ S x, w x l) ≤ x^s ∧ Marked.mass (S x) (w x) ≤ K)
    (mass : Tendsto (fun x => Marked.mass (S x) (w x)) atTop (𝓝 C)) :
    let Z := restrictFace i P F
    let h : Fin 39 → ℕ := H.orderEmbOfFin hH
    let Y := fun x : ℝ => x/(presievingModulus H x : ℝ)/
      fragmentNormalization (presievingModulus H x) x/(norm H x)^38
    let A := fun x => auxiliaryProductValue h i (sharpAuxiliaryArray H ζ x) (face H a i Z x)
    Tendsto (fun x => (∑ l ∈ S x, w x l * Marked.interval (Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊)
      (presievingModulus H x) (b x) (h i) l (A x) (A x)) / Y x) atTop
      (𝓝 (C*(1/ζ)*(∫ t, (integralFace a i Z t)^2 ∂Measure.pi (fun _ => bandLaw a)))) := by
  intro Z h Y A
  let Bx (x : ℝ) := fragmentNormalization (presievingModulus H x) x
  let u := sharpAuxiliaryArray H ζ
  let z := face H a i Z
  let U (x : ℝ) := mixedHarmonic (fun t : Fin 1 → ℕ => ((t 0).totient : ℝ)) (u x) (u x)
  let V (x : ℝ) := Distribution.harmonicPair (z x) (z x)
  let M (x : ℝ) := Marked.mass (S x) (w x)
  let count (x : ℝ) := ∑ l ∈ S x, w x l * Marked.interval (Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊)
    (presievingModulus H x) (b x) (h i) l (A x) (A x)
  let main (x : ℝ) := M x*(Bx x*U x)*(norm H x^38*V x)
  have uLim : Tendsto (fun x => Bx x*U x) atTop (𝓝 (1/ζ)) := by
    simpa only [Bx,U,u,mixedHarmonic,diagonalHarmonic,pow_two,Finsupp.sum] using
      sharpAuxiliaryArray_energy_tendsto H ζ hz
  have bounded : Bornology.IsBounded (Set.range Z) := by
    apply (bf.union (Bornology.isBounded_singleton (x := (0:ℝ)))).subset
    rintro y ⟨t,rfl⟩
    by_cases test : P (i.removeNth t) <;> simp [Z,restrictFace,test]
  have vLim := face_limit H a ha first last i Z Z mf mf bounded bounded cf cf
  have mainLim : Tendsto main atTop (𝓝 (C*(1/ζ)*(∫ t, (integralFace a i Z t)^2
      ∂Measure.pi (fun _ => bandLaw a)))) := by
    simpa only [main,M,V,z,pow_two] using (mass.mul uLim).mul vLim
  have err : Tendsto (fun x => count x / Y x - main x) atTop (𝓝 0) := by
    apply Metric.tendsto_nhds.mpr
    intro ε he
    have half := half_pos he
    have moment := marked_sector_moment H hH i a ha.monotone first last P P F F bf bf hr hr hz hz
      hc aux aux hs hK half room room radius radius
    filter_upwards [moment,eligible,eventually_gt_atTop (1:ℝ)] with x law marks hx
    have base := PrimeGap182.Selberg.fragmentNormalization_pos H x x hx
    have regular := PrimeGap182.Selberg.fragmentNormalization_pos H x (scale x)
      (Real.one_lt_rpow hx (by norm_num [rho]))
    have yp : 0 < Y x := by
      dsimp only [Y,norm]
      exact div_pos (div_pos (div_pos (zero_lt_one.trans hx) (Nat.cast_pos.mpr (presieving_pos H x))) base)
        (pow_pos regular _)
    have recorded : |count x - M x*(x/(presievingModulus H x:ℝ)*(U x*V x))| ≤ ε/2*Y x :=
      law (S x) (w x) (b x) marks.1 marks.2.1 marks.2.2
    have eq : count x / Y x - main x =
        (count x - M x*(x/(presievingModulus H x:ℝ)*(U x*V x))) / Y x := by
      apply (eq_div_iff yp.ne').2
      rw [sub_mul,div_mul_cancel₀ _ yp.ne']
      dsimp only [main,Y,Bx,norm]
      field_simp [base.ne',regular.ne']
    rw [Real.dist_eq,sub_zero,eq,abs_div,abs_of_pos yp]
    exact ((div_le_iff₀ yp).2 recorded).trans_lt (half_lt_self he)
  simpa only [sub_add_cancel,zero_add] using err.add mainLim

#print axioms marked_sector_diagonal_limit

#print axioms marked_sector_moment
#print axioms harmonic_disjoint_sectors
#print axioms retained_product_radius
#print axioms marked_arrays_of_sector
end PrimeGap180.Sector
