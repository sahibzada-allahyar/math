import TrialTripleHingeKernel180
import Mathlib.Order.SuccPred.IntervalSucc

/-! One fixed grid for pricing triple marks. Half the archived auxiliary
retreat pays for using the upper end of the bin in the counting theorem. -/
noncomputable section
open MeasureTheory Filter
open scoped BigOperators
namespace PrimeGap180.EventBins

def markRadius (ξ q d t : ℝ) := min ξ ((1-t)/2-q)-d
def gridPoint (lo b : ℝ) (i : ℕ) := lo+(b-lo)*i/10000

theorem grid_covers {lo b t : ℝ} (lt : lo < t) (tb : t ≤ b) :
    ∃ i : Fin 10000, gridPoint lo b i < t ∧ t ≤ gridPoint lo b (i+1 : ℕ) := by
  have mon : Monotone (gridPoint lo b) := by
    intro i j le
    unfold gridPoint
    gcongr
    linarith
  have mem : t ∈ Set.Ioc (gridPoint lo b 0) (gridPoint lo b 10000) := by
    simpa [gridPoint] using And.intro lt tb
  rw [← mon.biUnion_Ico_Ioc_map_succ 0 10000] at mem
  obtain ⟨i,ij,hit⟩ := Set.mem_iUnion₂.mp mem
  exact ⟨⟨i,ij.2⟩,hit⟩

private theorem radius_steps {ξ q l r t : ℝ} (lt : l ≤ t) (tr : t ≤ r) (width : r-l ≤ 1/10000) :
    markRadius ξ q (1/10000) t ≤ markRadius ξ q (1/20000) r := by
  unfold markRadius
  by_cases left : ξ ≤ (1-r)/2-q
  · rw [min_eq_left left,min_eq_left (show ξ ≤ (1-t)/2-q by linarith)]
    linarith
  · rw [min_eq_right (le_of_not_ge left)]
    linarith [min_le_right ξ ((1-t)/2-q)]

private theorem linear_mass {l r b : ℝ} (hl : 0 < l) (lr : l ≤ r) :
    (∫ t in l..r, (b-t)/t) = b*Real.log (r/l)-(r-l) := by
  have nn (t : ℝ) (ht : t ∈ Set.uIcc l r) : t ≠ 0 := by
    rw [Set.uIcc_of_le lr] at ht
    exact (hl.trans_le ht.1).ne'
  have ct : ContinuousOn (fun t => b*t⁻¹) (Set.uIcc l r) := continuousOn_const.mul (continuousOn_id.inv₀ nn)
  calc
    _ = ∫ t in l..r, b*t⁻¹-1 := intervalIntegral.integral_congr fun t ht => by field_simp [nn t ht]
    _ = _ := by
      rw [intervalIntegral.integral_sub (ct.intervalIntegrable) intervalIntegrable_const,
        intervalIntegral.integral_const_mul,integral_inv_of_pos hl (hl.trans_le lr),integral_one]

def hingeDensity (ξ q b t : ℝ) := ((b-t)/t) / markRadius ξ q (1/10000) t

private theorem radius_pos {ξ q b : ℝ} (minpos : 0 < markRadius ξ q (1/10000) b) {t : ℝ} (le : t ≤ b) :
    0 < markRadius ξ q (1/10000) t :=
  minpos.trans_le (sub_le_sub_right (min_le_min_left ξ (by linarith : (1-b)/2-q ≤ (1-t)/2-q)) _)

private theorem density_integrable {ξ q b l r : ℝ} (hl : 0 < l) (lr : l ≤ r) (rb : r ≤ b)
    (minpos : 0 < markRadius ξ q (1/10000) b) :
    IntervalIntegrable (hingeDensity ξ q b) volume l r := by
  have ct : Continuous (markRadius ξ q (1/10000)) := by unfold markRadius; fun_prop
  rw [intervalIntegrable_iff_integrableOn_Icc_of_le lr]
  exact (((continuous_const.sub continuous_id).continuousOn.div continuousOn_id
    (fun t ht => (hl.trans_le ht.1).ne')).div ct.continuousOn
    (fun t ht => (radius_pos minpos (ht.2.trans rb)).ne')).integrableOn_Icc

theorem hinge_bin_below_integral {ξ q b l r : ℝ} (hl : 0 < l) (lr : l ≤ r) (rb : r ≤ b)
    (width : r-l ≤ 1/10000) (minpos : 0 < markRadius ξ q (1/10000) b) :
    (b*Real.log (r/l)-(r-l)) / markRadius ξ q (1/20000) r ≤
      ∫ t in l..r, hingeDensity ξ q b t := by
  rw [← linear_mass hl lr, ← intervalIntegral.integral_div]
  apply intervalIntegral.integral_mono_on lr _ (density_integrable hl lr rb minpos)
  · intro t ht
    apply div_le_div_of_nonneg_left (div_nonneg (sub_nonneg.mpr (ht.2.trans rb)) (hl.le.trans ht.1))
      (radius_pos minpos (ht.2.trans rb)) (radius_steps ht.1 ht.2 width)
  · apply ContinuousOn.intervalIntegrable
    exact ((continuous_const.sub continuous_id).continuousOn.div continuousOn_id
      (fun t ht => (hl.trans_le ((Set.uIcc_of_le lr) ▸ ht).1).ne')).div_const _

/-- The exact price for the ten thousand half-open finite bins is at most
the continuum price used by the certificate. -/
theorem hinge_grid_below_integral {ξ q b lo : ℝ} (hl : 0 < lo) (lb : lo ≤ b)
    (b1 : b ≤ 1) (minpos : 0 < markRadius ξ q (1/10000) b) :
    (∑ i : Fin 10000, let l := gridPoint lo b i
                       let r := gridPoint lo b (i+1 : ℕ)
                       (b*Real.log (r/l)-(r-l)) / markRadius ξ q (1/20000) r) ≤
      ∫ t in lo..b, hingeDensity ξ q b t := by
  let g := gridPoint lo b
  have ends : g 0 = lo ∧ g 10000 = b := by simp [g,gridPoint]
  have mon : Monotone g := by intro i j le; dsimp [g,gridPoint]; gcongr
  have h0 (i : ℕ) : 0 < g i := by simpa only [ends.1] using (hl.trans_le (ends.1 ▸ mon (Nat.zero_le i)))
  have hb {i : ℕ} (hi : i < 10000) : g (i+1) ≤ b := ends.2 ▸ mon (show i+1 ≤ 10000 from hi)
  have width (i : ℕ) : g (i+1)-g i ≤ 1/10000 := by dsimp [g,gridPoint]; push_cast; linarith
  calc
    _ ≤ ∑ i : Fin 10000, ∫ t in g i..g (i+1 : ℕ), hingeDensity ξ q b t :=
      Finset.sum_le_sum fun i _ => hinge_bin_below_integral (h0 i) (mon (Nat.le_succ _)) (hb i.isLt) (width i) minpos
    _ = _ := by
      rw [Fin.sum_univ_eq_sum_range (fun i : ℕ => ∫ t in g i..g (i+1), hingeDensity ξ q b t) 10000,
        intervalIntegral.sum_integral_adjacent_intervals
        (fun i hi => density_integrable (h0 i) (mon (Nat.le_succ _)) (hb hi) minpos),ends.1,ends.2]

/-- Split the integral at exactly the switch in the archive's two-branch
calculation. Either segment can be empty. -/
theorem hinge_grid_price {ξ q b : ℝ} (hξ : 0 < ξ) (xb : ξ ≤ b)
    (room : 0 < markRadius ξ q (1/10000) b) :
    let s := max ξ (min b (1-2*q-2*ξ))
    let c := 1/2-q-1/10000
    (∫ t in ξ..b, hingeDensity ξ q b t) =
      (b*Real.log (s/ξ)-(s-ξ))/(ξ-1/10000) +
      b/c*Real.log (b/s) + (2-b/c)*Real.log ((c-b/2)/(c-s/2)) := by
  intro s c
  have xs : ξ ≤ s := le_max_left _ _
  have sb : s ≤ b := max_le xb (min_le_left _ _)
  have spos := hξ.trans_le xs
  have bpos := hξ.trans_le xb
  have cb : b/2 < c := by
    unfold markRadius at room
    dsimp [c]
    linarith [min_le_right ξ ((1-b)/2-q)]
  have lside : (∫ t in ξ..s, hingeDensity ξ q b t) =
      (b*Real.log (s/ξ)-(s-ξ))/(ξ-1/10000) := by
    rw [← linear_mass hξ xs, ← intervalIntegral.integral_div]
    by_cases same : s=ξ
    · rw [same]; simp
    have left : s ≤ 1-2*q-2*ξ := by
      have h : ξ < min b (1-2*q-2*ξ) :=
        lt_of_not_ge (fun no => same (max_eq_left no))
      exact (max_eq_right h.le).trans_le (min_le_right _ _)
    apply intervalIntegral.integral_congr
    intro t ht
    rw [Set.uIcc_of_le xs] at ht
    simp only [hingeDensity,markRadius,min_eq_left (show ξ ≤ (1-t)/2-q by linarith [ht.2])]
  have rside : (∫ t in s..b, hingeDensity ξ q b t) =
      b/c*Real.log (b/s) + (2-b/c)*Real.log ((c-b/2)/(c-s/2)) := by
    rw [← hinge_variable_integral spos sb cb]
    by_cases same : s=b
    · rw [same]; simp
    have sw : 1-2*q-2*ξ ≤ s := by
      have h : 1-2*q-2*ξ < b := lt_of_not_ge fun no => same (by
        dsimp [s]
        rw [min_eq_left no,max_eq_right xb])
      simpa [s,min_eq_right h.le] using (le_max_right ξ (1-2*q-2*ξ))
    apply intervalIntegral.integral_congr
    intro t ht
    rw [Set.uIcc_of_le sb] at ht
    simp only [hingeDensity,markRadius,min_eq_right (show (1-t)/2-q ≤ ξ by linarith [ht.1]),div_div]
    congr 2
    dsimp [c]
    ring
  calc
    _ = _ := (intervalIntegral.integral_add_adjacent_intervals (density_integrable hξ xs sb room)
      (density_integrable spos sb le_rfl room)).symm
    _ = _ := by rw [lside,rside]; ring

#print axioms hinge_grid_price

#print axioms grid_covers
#print axioms hinge_grid_below_integral
end PrimeGap180.EventBins
