import TrialPriceResourceBlock00180
import TrialPriceResourceBlock01180
import TrialPriceResourceBlock02180
import TrialPriceResourceBlock03180
import TrialPriceResourceBlock04180
import TrialPriceResourceBlock05180
import TrialPriceResourceBlock06180
namespace PrimeGap180.PriceResourceRows
theorem allResources (m : Fin 49) (g : Fin 445) : (PriceValues.resource g.val m.val:Int) = originalDiagonal (PriceFactorSource.factorShapes[m.val]!) g := by
  apply checked
  by_cases h0 : m.val < 7
  · let i : Fin 7 := ⟨m.val-0,by omega⟩
    have eq : 0+i.val=m.val := by dsimp [i]; omega
    exact (congrArg (fun n => checkResource n = true) eq).mp (block0 i)
  by_cases h7 : m.val < 14
  · let i : Fin 7 := ⟨m.val-7,by omega⟩
    have eq : 7+i.val=m.val := by dsimp [i]; omega
    exact (congrArg (fun n => checkResource n = true) eq).mp (block1 i)
  by_cases h14 : m.val < 21
  · let i : Fin 7 := ⟨m.val-14,by omega⟩
    have eq : 14+i.val=m.val := by dsimp [i]; omega
    exact (congrArg (fun n => checkResource n = true) eq).mp (block2 i)
  by_cases h21 : m.val < 28
  · let i : Fin 7 := ⟨m.val-21,by omega⟩
    have eq : 21+i.val=m.val := by dsimp [i]; omega
    exact (congrArg (fun n => checkResource n = true) eq).mp (block3 i)
  by_cases h28 : m.val < 35
  · let i : Fin 7 := ⟨m.val-28,by omega⟩
    have eq : 28+i.val=m.val := by dsimp [i]; omega
    exact (congrArg (fun n => checkResource n = true) eq).mp (block4 i)
  by_cases h35 : m.val < 42
  · let i : Fin 7 := ⟨m.val-35,by omega⟩
    have eq : 35+i.val=m.val := by dsimp [i]; omega
    exact (congrArg (fun n => checkResource n = true) eq).mp (block5 i)
  let i : Fin 7 := ⟨m.val-42,by omega⟩
  have eq : 42+i.val=m.val := by dsimp [i]; omega
  exact (congrArg (fun n => checkResource n = true) eq).mp (block6 i)
#print axioms allResources
end PrimeGap180.PriceResourceRows
