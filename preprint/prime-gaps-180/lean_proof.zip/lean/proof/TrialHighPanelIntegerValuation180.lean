import TrialHighMarkedNativePanel180
import TrialHighSignedControls180
import TrialHighPanelTiltBook180

/-! A single finite integer comparison pays a selected panel of the
actual frozen spline. The rate and terminal index select a certified
geometric endpoint, and both control matrices retain their exact signs. -/
noncomputable section
open scoped BigOperators Classical
namespace PrimeGap180.HighPanelIntegerValuation
open HighMarkedNativePanel HighPanelTiltBook HighSignedControls HighGroupedPayment
open HighAngularProduct (Cube)
open PrimeGap180.FrozenProfile (Fine amplitude)
open PrimeGap180.GateDeletion (T)

private theorem ratio_cast (r : HighTailTiles.Rate) :
    (HighTailSweep.ratio (HighTailTiles.beta r):ℝ) = ratio r := by
  unfold HighTailSweep.ratio ratio
  push_cast
  have step : (HighTailSweep.step:ℝ)=Native.step := by
    norm_num [HighTailSweep.step,HighTailSweep.num,HighTailSweep.den,Native.step]
  rw [step]

private theorem rate_bound (i : HighPanelTiltBook.Index) :
    ((read i).bound:ℝ)/2^320 ≤ (ratio (read i).rate)^(read i).stop := by
  have checked := (HighPanelTiltBook.below i).1
  have actual : ((((read i).bound:ℚ)/2^320:ℚ):ℝ) ≤
      (((HighTailSweep.ratio (HighTailTiles.beta (read i).rate))^(read i).stop:ℚ):ℝ) := by exact_mod_cast checked
  simpa only [Rat.cast_div,Rat.cast_natCast,Rat.cast_pow,Rat.cast_ofNat,ratio_cast] using actual

theorem panel (i : HighPanelTiltBook.Index) (a b : Fin 9) (selected : Finset Cube)
    (c : Fine) (s : ℕ) (l h : ℚ) (t : Cube→ℚ)
    (start : 3 ≤ s) (last : s < 33)
    (active : ∀ x ∈ selected, MassSplineSpan.knot s ≤ MassSplineSpan.sample (radial x) ∧
      MassSplineSpan.sample (radial x) < MassSplineSpan.knot (s+1))
    (place : ∀ x ∈ selected, MassSplineSpan.sample (radial x) = l+(h-l)*t x)
    (inside : ∀ x ∈ selected, 0 ≤ t x ∧ t x ≤ 1)
    (range : ∀ x ∈ selected, radial x ≤ (read i).stop)
    (method : Method) (C : Words) (Z : ControlWords) {d e u : ℕ}
    (dp : 0 < d) (ep : 0 < e)
    (control : ∀ p q, HighFrozenPanel.control s c l h p q = (C p q:ℝ)/d)
    (center : ∀ p q, matrixOf method p q = (Z p q:ℝ)/e)
    (payment : sumWord (read i).rate a b (HighSignedControls.coeff C Z)*(2^320:ℤ)*10^94 ≤
      (u:ℤ)*(d*d*e*scale*symmetry a b:ℕ)*(read i).bound*446) :
    (∑ x ∈ selected, sampleMass a b x * (amplitude T (indices x) c)^2) / (symmetry a b:ℝ) ≤
      (u:ℝ)*446/10^94 := by
  have controls_eq : HighFrozenPanel.control s c l h = fun p q => (C p q:ℝ)/d := by
    funext p q
    exact control p q
  have center_eq : matrixOf method = fun p q => (Z p q:ℝ)/e := by
    funext p q
    exact center p q
  apply HighMarkedNativePanel.bound (read i).rate a b selected c s l h t (read i).stop
    start last active place inside range method
  rw [controls_eq,center_eq]
  exact physical_payment (read i).rate a b _ _ (HighSignedControls.coeff C Z)
    (Nat.mul_pos (Nat.mul_pos dp dp) ep) (coefficient_exact C Z dp ep) (rate_bound i) payment

#print axioms panel
end PrimeGap180.HighPanelIntegerValuation
