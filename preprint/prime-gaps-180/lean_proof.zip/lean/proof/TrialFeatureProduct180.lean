import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Data.Fin.Tuple.Basic
import Mathlib.Tactic

/-! An exact equality of one-site integrals transports every finite product
of the site laws, including signed weights and arbitrary joint observables. -/
noncomputable section
open scoped Classical BigOperators
namespace PrimeGap180.FeatureProduct
variable {A B X R : Type*} [Fintype A] [Fintype B] [CommSemiring R]

def integral (w : A → R) (o : A → X) {d : ℕ} (f : (Fin d → X) → R) :=
  ∑ x : Fin d → A,(∏ i,w (x i))*f (o ∘ x)

private theorem cons (w : A → R) (o : A → X) (d : ℕ) (f : (Fin (d+1) → X) → R) :
    integral w o f=∑ a : A,w a*integral w o (fun z : Fin d → X => f (Fin.cons (α:=fun _ => X) (o a) z)) := by
  unfold integral
  rw [←Equiv.sum_comp (Fin.consEquiv (fun _ : Fin (d+1) => A)) (fun x => (∏ i,w (x i))*f (o ∘ x)),Fintype.sum_prod_type]
  apply Finset.sum_congr rfl
  intro a _
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro z _
  change (∏ i,w (Fin.cons (α:=fun _ => A) a z i))*f (o ∘ Fin.cons (α:=fun _ => A) a z)=_
  have obs : o ∘ Fin.cons (α:=fun _=>A) a z = Fin.cons (α:=fun _=>X) (o a) (o ∘ z) := by
    funext i
    exact Fin.cases rfl (fun _ => rfl) i
  rw [Fin.prod_univ_succ,obs]
  simp only [Fin.cons_zero,Fin.cons_succ,mul_assoc]

theorem transport (w : A → R) (v : B → R) (o : A → X) (p : B → X)
    (site : ∀ f : X → R,(∑ a : A,w a*f (o a))=∑ b : B,v b*f (p b))
    (d : ℕ) (f : (Fin d → X) → R) : integral w o f=integral v p f := by
  induction d with
  | zero =>
    simp only [integral,Fintype.sum_unique,Fin.prod_univ_zero,one_mul]
    exact congrArg f (Subsingleton.elim _ _)
  | succ d ih =>
    rw [cons,cons]
    calc
      _ = ∑ a : A,w a*integral v p (fun z : Fin d → X => f (Fin.cons (α:=fun _=>X) (o a) z)) :=
        Finset.sum_congr rfl (fun a _ => congrArg (w a*·) (ih _))
      _ = _ := site (fun t => integral v p (fun z : Fin d → X => f (Fin.cons (α:=fun _=>X) t z)))

#print axioms transport
end PrimeGap180.FeatureProduct
