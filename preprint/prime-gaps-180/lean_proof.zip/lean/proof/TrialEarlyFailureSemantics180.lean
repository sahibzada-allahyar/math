import TrialEarlyFailureData180

/-! The localized workers restrict the signed spline to full native indices
at least 102994 and the failing omission to indices at most 27970. -/
noncomputable section
open scoped Classical BigOperators
open PrimeGap186 PrimeGap180.Sector PrimeGap180.FrozenProfile PrimeGap180.FrozenData
open PrimeGap180.GateDeletion PrimeGap180.FrozenData.FiniteInput PrimeGap180.RunAlignment
namespace PrimeGap180.EarlyFailure
open private code_cons from TrialDebitRunData180
open private physical_sum from TrialStructuralGate180
open private key from TrialFrozenData180

private theorem early_sound (rs : List (Array ℕ)) (s : Label) : ∀ l j,
    l≤j → j<102994 → early l rs=true → debitCode rs (j+1)=s.val+1 → T.group s=445 := by
  induction rs with
  | nil=>intro l j lj small ok code; change 0=s.val+1 at code; omega
  | cons r rs ih=>
    intro l j lj small ok code
    obtain ⟨first,rest⟩:=Bool.and_eq_true_iff.mp ok
    rw [code_cons] at code
    by_cases here : j+1<stop r
    · rw [ite_eq_left here] at code
      have hh : lab r = s := by
        apply Fin.ext
        simp [lab,DebitRunData.lab,code,Fin.ofNat,Nat.mod_eq_of_lt s.isLt]
      have tested : 102994≤l ∨ T.group (lab r)=445 := by simpa using first
      exact hh ▸ tested.resolve_left (by omega)
    · rw [ite_eq_right here] at code
      exact ih _ j (by omega) small rest code

open private owner get from TrialFrozenData180

private theorem actual_owner_tag {c : Fine} {g : Group} {t : Bucket} {k : Key}
    (occ : T.key c g t=some k) : ∃ row∈(owners c).toList,
      field row 0=g.val ∧ field row 4≤k.val ∧ k.val<field row 4+(field row 3-field row 2) := by
  change key c g t=some k at occ
  unfold key at occ
  dsimp only at occ
  split at occ
  next good =>
    have eq := congrArg Fin.val (Option.some.inj occ)
    change field (owner c g) 4+t.val-field (owner c g) 2 = k.val at eq
    cases got : (owners c).find? (fun row=>field row 0==g.val) with
    | none =>
      have empty : owner c g = #[] := by change ((owners c).find? (fun r=>field r 0==g.val)).getD #[]=_; rw [got]; rfl
      rw [empty] at good
      exact (Nat.not_lt_zero t.val good.2.1).elim
    | some row =>
      have own : owner c g=row := by change ((owners c).find? (fun r=>field r 0==g.val)).getD #[]=_; rw [got]; rfl
      have found : (owners c).toList.find? (fun r=>field r 0==g.val)=some row := by simpa only [Array.find?_toList] using got
      have tested : (fun a => field a 0 == g.val) row = true := List.find?_some (p:=fun t : Array ℕ => field t 0 == g.val) (a:=row) found
      have tagOk : field row 0=g.val := beq_iff_eq.mp tested
      have lo : field (owner c g) 2≤t.val ∧ t.val<field (owner c g) 3 := ⟨good.1,good.2.1⟩
      rw [own] at eq lo
      exact ⟨row,List.mem_of_find?_eq_some found,tagOk,by omega,by omega⟩
  next => contradiction

private theorem expensive (checked : Checks) (r : Receipt) (sp : T.group r.sector=445)
    (occ : T.key r.fine (T.group r.sector) r.bucket=some r.key) (e : Active) :
    18000000 ≤ T.gate r.key e := by
  obtain ⟨a,ina,g,lo,hi⟩ := actual_owner_tag occ
  have mem : tag a ∈ spans := List.mem_flatMap.mpr
    ⟨r.fine,by simp,List.mem_map.mpr ⟨a,ina,rfl⟩⟩
  have sel := find_owner checked.order mem lo hi
  obtain ⟨b,found,bok⟩ := aligned_at endAt test checked.tags sel
  have lower : (tag a).cap=445 → 20000000≤field b 3 := of_decide_eq_true bok
  have eq : (tag a).cap=445 := by change field a 0=445; rw [g,sp]; rfl
  have val := lower eq
  have hu := checked.parents e
  have gr : field b 3-parentUpperNat e ≤ T.gate r.key e := by
    rw [(gate_row r.key b found).2 e]; exact (le_max_left _ _).trans (le_max_right _ _)
  omega

open private info_bounds from TrialFrozenData180

theorem source_cap (b : Bits 38) (r : Receipt) (sel : select T b=some r) :
    least (fun c=>b (.cap c))=some r.fine := by
  have inf := (receipt_data T b r sel).1
  cases hc : least (fun c=>b (.cap c)) with
  | none => simp [retainedInfo,hc] at inf
  | some c =>
    by_cases big : (∑ i,indices b i)>T.maxIndex c
    · simp [retainedInfo,hc,big] at inf
    · cases sec : T.sector c ((∑ i,indices b i)+1) with
      | none => simp [retainedInfo,hc,big,sec] at inf
      | some s =>
        simp [retainedInfo,hc,big,sec] at inf
        exact congrArg some inf.1

theorem index_data (y : Fin 38 → Band 216) (r : Receipt) (sel : select T (bits T y)=some r) :
    Native.cellSum y ≤ T.maxIndex r.fine ∧ T.sector r.fine (Native.cellSum y+1)=some r.sector := by
  obtain ⟨small,stored⟩ := info_bounds T _ (receipt_data T _ r sel).1
  have eq (i) : indices (bits T y) i=Native.cell (y i) := by
    have h := (Finset.single_le_sum (f:=indices (bits T y)) (fun j _=>Nat.zero_le _) (Finset.mem_univ i)).trans
      (small.trans (T.maxBound _))
    rw [index_eq] at h ⊢
    omega
  have total : (∑ i,indices (bits T y) i)=Native.cellSum y := Finset.sum_congr rfl fun i _=>eq i
  rw [total] at small stored
  exact ⟨small,stored⟩

theorem first_checked (checked : Checks) (y : Fin 38 → Band 216) (nn : ∀ i k,0≤y i k) (r : Receipt) (e : Active)
    (sel : select T (bits T y)=some r) (bad : bits T y (.high r.key e)=true) : 102994≤Native.cellSum y := by
  by_contra! small
  obtain ⟨bound,sec⟩ := index_data y r sel
  have sp := early_sound _ r.sector 0 _ (Nat.zero_le _) small
    ((List.all_eq_true (l:=List.finRange 44) (p:=fun c=>early 0 (debitSectorRows c))).mp checked.runs _ (List.mem_finRange r.fine))
    (debit_code_of_sector r.fine _ r.sector sec)
  have price := expensive checked r sp (receipt_data T _ r sel).2.2 e
  have pricey : (18000000:ℝ)≤T.gate r.key e := by exact_mod_cast price
  have hit : (T.gate r.key e:ℝ)<Lookup.ticks*Lookup.suffix y (T.tailEdge e) := by
    change (if -Lookup.ticks*Lookup.suffix y (T.tailEdge e) < -(T.gate r.key e:ℝ) then true else false)=true at bad
    split at bad
    next h => simpa only [neg_mul,neg_lt_neg_iff] using h
    next => exact (Bool.false_ne_true bad).elim
  have ord : Lookup.suffix y (T.tailEdge e) ≤ Lookup.total y := Finset.sum_le_sum fun i _ =>
    Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _) (fun j _ _=>nn i j)
  have tot := (physical_sum y nn).2
  have rad := StructuralRun.cell_upper _ _ _ bound sec
  have up : (T.upper r.fine (T.group r.sector):ℝ)≤2798706 := by exact_mod_cast T.upperBound _ _
  have gate := mul_le_mul_of_nonneg_left ord (by norm_num [Lookup.ticks] : (0:ℝ)≤Lookup.ticks)
  have impossible : (18000000:ℝ)<2798706 := pricey.trans_lt (hit.trans_le (gate.trans (tot.trans (rad.trans up))))
  norm_num at impossible

theorem support_checked (checked : Checks) (v : Full) (nn : ∀ i k,0≤v i k) (nz : original v≠0) (i : Fin 39)
    (e : Active) (r : Receipt) (sel : select T (bits T (i.removeNth v))=some r)
    (bad : bits T (i.removeNth v) (.high r.key e)=true) :
    102994≤Native.cellSum v ∧ Native.cell (v i)≤27970 := by
  have low := first_checked checked (i.removeNth v) (fun j k=>nn (i.succAbove j) k) r e sel bad
  have upper := Restoration.original_index v nz
  have split : Native.cellSum v=Native.cell (v i)+Native.cellSum (i.removeNth v) := Fin.sum_univ_succAbove _ i
  omega

#print axioms support_checked
end PrimeGap180.EarlyFailure
