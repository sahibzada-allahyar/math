import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G363
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 363

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G363

namespace PrimeGap180.PriceIsolatedGroup.G368
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 368

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G368

namespace PrimeGap180.PriceIsolatedGroup.G373
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 373

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G373

namespace PrimeGap180.PriceIsolatedGroup.G378
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 378

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G378
