import TrialFirstEdgePhysicalCell180
import TrialDebitNativeClasses180

/-! Fiber of the actual historical observation. Four supplementary fine caps
lie below the regularity threshold, so the observation here must use atom. -/
noncomputable section
open MeasureTheory Set PrimeGap186 PrimeGap180.FrozenProfile PrimeGap180.Sector
open PrimeGap180.CoarseLaw PrimeGap180.DebitNativeClasses
open scoped Classical
namespace PrimeGap180.FirstEdgeCoarseFibers
open private choose from TrialDebitNativeClasses180
open private one_nonneg from TrialFrozenData180
local instance : IsFiniteMeasure μ := bandLaw_finite _

instance atomSpace : MeasurableSpace Atom := ⊤
instance atomDiscrete : DiscreteMeasurableSpace Atom := ⟨fun _ => trivial⟩
local instance : IsFiniteMeasure law := Measure.isFiniteMeasure_map _ _

def seen (z : B) : Atom := atom (state z)
def fiber (b : Atom) : Set B := seen ⁻¹' {b}

theorem seenM : Measurable seen := (measurable_of_finite atom).comp state_meas
theorem fiberM (b : Atom) : MeasurableSet (fiber b) := seenM (measurableSet_singleton _)

private theorem native_iff (k : ℕ) : ∀ᵐ z ∂μ, Native.cell z=k ↔ z∈FirstEdgePieces.cell k := by
  filter_upwards [one_nonneg] with z nn
  have hz : 0≤NativeSiteLaw.radial z:=Finset.sum_nonneg fun i _=>nn i
  have h : 0<Native.step:=by norm_num [Native.step]
  change ⌊NativeSiteLaw.radial z/Native.step⌋₊ = k ↔ _
  rw [Nat.floor_eq_iff (div_nonneg hz h.le),le_div_iff₀ h,div_lt_iff₀ h]
  rfl

private theorem cheapest (k : ℕ) (hk : k<45067) :
    ∀ᵐ z ∂μ, z∈FirstEdgePieces.cell k → (seen z).2=some 0 := by
  filter_upwards [FirstEdgePieces.accepted k hk 0] with z on h
  apply choose (0:DebitNativeClasses.Class) _ (fun _ _=>Fin.zero_le _)
  have cap:=on h
  simpa [CoarseLaw.state,CoarseLaw.flag,FirstEdgePieces.price,NativeSiteLaw.capped] using cap

/-- On every regular native index, the only nonzero historical-price fiber
is the whole radial cell of that index. -/
theorem regular (b : Atom) (hb : b.1.val<45067) :
    fiber b =ᵐ[μ] (if b.2=some 0 then FirstEdgePieces.cell b.1 else ∅) := by
  filter_upwards [native_iff b.1.val,cheapest b.1.val hb] with z idx cls
  have ind : (seen z).1=b.1 ↔ z∈FirstEdgePieces.cell b.1 := by
    change (⟨min (Native.cell z) 130965,_⟩ : Fin 130966)=b.1 ↔ _
    rw [Fin.ext_iff,←idx]
    change min (Native.cell z) 130965=b.1.val ↔ Native.cell z=b.1.val
    omega
  apply propext
  by_cases first : b.2=some 0
  · rw [ite_eq_left first]
    change seen z=b ↔ _
    exact ⟨fun e=>ind.mp (congrArg Prod.fst e),fun h=>Prod.ext (ind.mpr h) ((cls h).trans first.symm)⟩
  · rw [ite_eq_right first]
    change seen z=b ↔ False
    exact ⟨fun e=>first ((congrArg Prod.snd e).symm.trans (cls (ind.mp (congrArg Prod.fst e)))),False.elim⟩

theorem raw_ae (d : ℕ) : ∀ᵐ v ∂prod d, ∀ i,weight (state (v i))≠0 := by
  have one : ∀ᵐ z ∂μ, weight (state z)≠0 := by
    have each (s : State) : ∀ᵐ z ∂μ, state z=s → weight s≠0 := by
      by_cases off : weight s=0
      · have empty : μ (state ⁻¹' {s})=0 := by
          have v : law {s}=0 := (ENNReal.toReal_eq_zero_iff _).mp off |>.resolve_right (measure_ne_top _ _)
          rwa [law,Measure.map_apply state_meas (measurableSet_singleton _)] at v
        have notin : ∀ᵐ z ∂μ,z ∉ state ⁻¹' {s} := by
          rw [ae_iff]
          simpa only [not_not,Set.ofPred_mem_eq] using empty
        exact notin.mono fun z h a=>False.elim (h a)
      · exact ae_of_all _ fun _ _=>off
    filter_upwards [ae_all_iff.mpr each] with z hz
    exact hz (state z) rfl
  exact ae_all_iff.mpr fun i=>(Measure.quasiMeasurePreserving_eval (fun _ : Fin d=>μ) i).ae one

theorem raw_observable : ∀ᵐ v ∂prod 39,
    Restoration.original v=rawAtom (fun i=>seen (v i)) := by
  filter_upwards [CoarseForms.good_prod 39,raw_ae 39] with v good live
  exact (CoarseForms.native_original v good).trans (original_eq _ live)

#print axioms regular
#print axioms raw_observable
end PrimeGap180.FirstEdgeCoarseFibers
