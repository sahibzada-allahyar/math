import Mathlib.Tactic

/-! Directed numerical targets for the 22 middle deletion groups. Bounds in units
of 10⁻¹² of the original mass are rounded upward. Each positive Young parameter
is in units of 10⁻⁶. -/
namespace PrimeGap180.RestorationRows

structure Row where
  mass : ℕ
  pairImage : ℕ
  joint : ℕ
  young : ℕ
  cost : ℕ
  deriving DecidableEq

def rows : Fin 22 → Row := ![
  ⟨461874, 29406, 52762757, 252323, 52995840⟩,
  ⟨739298, 8326, 28356540, 106123, 28513453⟩,
  ⟨1080665, 4148, 19656625, 61955, 19790530⟩,
  ⟨1735622, 3717, 18706334, 46278, 18866975⟩,
  ⟨2596110, 3091, 20249794, 34506, 20428954⟩,
  ⟨2806120, 2909, 20467913, 32198, 20648612⟩,
  ⟨3973255, 3985, 26857765, 31670, 27109427⟩,
  ⟨4197070, 3373, 28386459, 28349, 28624424⟩,
  ⟨3317520, 2800, 23518904, 29052, 23711664⟩,
  ⟨4822821, 4767, 30782556, 31440, 31085808⟩,
  ⟨6984635, 5139, 43643636, 27125, 44022551⟩,
  ⟨6938062, 4435, 41906551, 25283, 42257381⟩,
  ⟨8121594, 6256, 47001145, 27755, 47451961⟩,
  ⟨13127746, 8224, 73984739, 25030, 74641893⟩,
  ⟨16084177, 11140, 93861223, 26318, 94707811⟩,
  ⟨25476137, 22754, 152841995, 29886, 154364735⟩,
  ⟨30306032, 19921, 177530555, 25639, 179084552⟩,
  ⟨11876517, 7707, 74605111, 25475, 75210198⟩,
  ⟨5384148, 2770, 33640566, 22683, 33884813⟩,
  ⟨1859843, 921, 12418109, 22254, 12500884⟩,
  ⟨752430, 293, 4829021, 19734, 4858717⟩,
  ⟨84554, 67, 565105, 28150, 569866⟩]

/-- Clearing positive denominators in J+tD+P/t ≤ C. -/
theorem arithmetic (i : Fin 22) :
    0 < (rows i).young ∧
    (rows i).joint * (rows i).young * 1000000 + (rows i).young^2 * (rows i).mass +
      (rows i).pairImage * 1000000^2 ≤ (rows i).cost * (rows i).young * 1000000 := by
  revert i
  decide +kernel

theorem total : ∑ i : Fin 22, (rows i).cost = 1035331049 := by decide +kernel

noncomputable def ticks (n : ℕ) : ℝ := n / 10^12

theorem terms (i : Fin 22) :
    let w : ℝ := (rows i).young / 1000000
    0 < w ∧ ticks (rows i).joint + w*ticks (rows i).mass + (1/w)*ticks (rows i).pairImage ≤ ticks (rows i).cost := by
  let r := rows i
  obtain ⟨y,h⟩ := arithmetic i
  have pos : 0 < (r.young:ℝ) := by exact_mod_cast y
  have cast : (r.joint:ℝ)*r.young*1000000 + (r.young:ℝ)^2*r.mass +
      (r.pairImage:ℝ)*1000000^2 ≤ (r.cost:ℝ)*r.young*1000000 := by exact_mod_cast h
  change 0 < (r.young:ℝ)/1000000 ∧ _
  refine ⟨by positivity,?_⟩
  change ticks r.joint + (r.young/1000000:ℝ)*ticks r.mass + (1/((r.young:ℝ)/1000000))*ticks r.pairImage ≤ ticks r.cost
  unfold ticks
  field_simp [pos.ne']
  nlinarith only [cast]

#print axioms terms
#print axioms total
end PrimeGap180.RestorationRows
