"""Generate the Lean modules that discharge `MassCap36Assembly.GroupScores`.

The target is `TrialMassCap36Scores180`, which builds the score tables, proves
`MassCap36Assembly.cap36` for them and so gives both 27-bit cap-36 mass bounds.

Module layout (1,271 modules):

* `TrialCap36WordReader180` defines `cap36Word180%`, a copy of the
  `packedWord180%` reader with its own token.
* 74 word carriers, `TrialCap36WordEnd<LLLL>180` (21) and
  `TrialCap36WordAng<SS>180` (53). Each holds one lo/hi pair of final factor
  words behind `@[irreducible]` definitions, read from the `.bin` file that the
  factor-bank generator already wrote. A carrier imports only the reader, so a
  score module loads four words (about 42 MB) and not the bank proofs, whose
  closures contain many more intermediate words.
* `TrialCap36ScoreBase180`: the ten window starts and lengths.
* 9 row modules `TrialCap36Rows<p>180` and `TrialCap36RowTable180`: the 2,970
  values `FrozenData.rowQ 43 p s k`, one `decide +kernel` declaration per
  ten-entry chunk of each (p, s) row, and `coefficient_of`, which rewrites `coefficientQ j 43 u` into
  literal arithmetic once the spline row at `j` is known.
* 70 radial modules `TrialCap36Radial<w><i>180`: the 30 values of `splineQ` at
  one collocation tick (one declaration), then the 99 coefficients by literal
  arithmetic (one declaration). Evaluating `coefficientQ` directly cost about
  0.6 GB of kernel cache per key and about 10 s per key, so it is never
  evaluated in the kernel. No module below the score modules imports a word.
* `TrialCap36RadialTable180`: the radial table, the identity
  `differences 36 (start w) = totals 36 (start w) = channels w`, and the
  decidable per-window predicate `Check`.
* 1,113 score modules `TrialCap36Score<ee><ss>180`, one per endpoint pair `e`
  and angular signature `s`. Each proves ten kernel checks of integer bounds
  for one `(e, s)` group on the ten windows.
* `TrialMassCap36Scores180`: identifies the carriers with the bank words,
  rewrites `values` through the radial table, assembles `GroupScores`, checks
  the two totals and applies `MassCap36Assembly.cap36`.

Word data. The words are read from the `.bin` files that the factor-bank
generators (`build_cap_square`, `build_cap_unmarked`, `build_cap_end_pairs`,
`build_cap_weighted`) write under `<build>/generated` when
`build_conservative_proof.py` dispatches them. This generator does not rerun
them. The carriers refer to those files by relative path, so the Lean words
and the Python scores come from the same bytes. The final module re-proves by
`decide +kernel` that every carrier equals the corresponding bank word.

Scores. `values`, `score`, `radius`, `lowScore` and `highScore` are
recomputed exactly (rational arithmetic, GMP products) as the Lean definitions
state them. Each bound is the floor of `lowScore` or the ceiling of
`highScore`, an integer in the score unit 2^-640 of the mass. The run checks
that the per-(endpoint, window) sums reproduce `lower72`/`upper72` of
`TrialMassBatchTargets36180.lean` exactly and that both totals meet the 27-bit
targets.

Use `--dry-run` without any build directory to emit the module skeletons (with
placeholder score bounds that are not a certificate) and print the module
structure.
"""
import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction
from functools import lru_cache
from hashlib import sha256
import json
from math import comb, lcm
import os
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
COUNT = 130965
LANE = 640
WORD_BYTES = COUNT * 80
CAP_CLASS = 36
FINE_CAP = 43            # DebitNativeClasses.capAt 36, rechecked in Lean
LAST_TICK = 117732       # min 130964 (T.maxIndex 43), rechecked in Lean
STEP = Fraction(1399373467, 172031279104000)
DIRECTORY = "cap36_scores"
FINAL = "TrialMassCap36Scores180"
RESULT_FILE = "cap36-exact-scores.json"
OPTIONS = ["set_option maxHeartbeats 0", "set_option maxRecDepth 28000",
           "set_option exponentiation.threshold 100000000"]


# ---------------------------------------------------------------------------
# Lean data read directly from the tracked sources

def _source(name):
    return (HERE / name).read_text()


def _vector(text, name):
    m = re.search(rf"def {name} : Window → [ℕNat]+ := !\[([0-9,]+)\]", text)
    return [int(x) for x in m[1].split(",")]


@lru_cache(None)
def windows():
    text = _source("TrialUnmarkedDotData180.lean")
    starts, lengths = _vector(text, "start"), _vector(text, "length")
    if len(starts) != 10 or len(lengths) != 10:
        raise ValueError("Expected ten cap-36 windows")
    if any(a + n != b for a, n, b in zip(starts, lengths, starts[1:] + [LAST_TICK + 1])):
        raise ValueError("The windows do not tile 18,719-117,732")
    return tuple(zip(starts, lengths))


@lru_cache(None)
def end_labels():
    text = _source("TrialCheckedEnds36180.lean").split("def rows", 1)[1].split("def all", 1)[0]
    labels = re.findall(r"⟨CapEndPair([012]{4})\.lo,", text)
    if len(labels) != 21 or len(set(labels)) != 21:
        raise ValueError("Unexpected endpoint order in CheckedEnds36.rows")
    return tuple(labels)


def _pairs(body, arity):
    rows = []
    for row in re.findall(r"\[([^\[\]]*)\]", body):
        nums = [int(x) for x in re.findall(r"\d+", row)]
        if len(nums) % arity:
            raise ValueError("Malformed channel list")
        rows.append([tuple(nums[i:i + arity]) for i in range(0, len(nums), arity)])
    return rows


@lru_cache(None)
def channel_lists():
    text = _source("TrialMassChannelLists180.lean")
    ends = text.split("def endList", 1)[1].split(": Array (List EndChoice)", 1)[0]
    powers = text.split("def powerList", 1)[1].split(": Array (List PowerChoice)", 1)[0]
    ends = [[((a, b), (c, d)) for a, b, c, d in row] for row in _pairs(ends.split("(#[", 1)[1], 4)]
    powers = _pairs(powers.split("(#[", 1)[1], 2)
    if len(ends) != 21 or len(powers) != 53 or sum(map(len, ends)) != 81 or sum(map(len, powers)) != 121:
        raise ValueError("Unexpected MassChannelLists census")
    return ends, powers


@lru_cache(None)
def signatures():
    line = re.search(r"def signatures : Fin 11 → List ℕ := !\[(.*)\]\n", _source("TrialFrozenProfile180.lean"))[1]
    sigs = [tuple(int(x) for x in re.findall(r"\d+", part)) for part in re.findall(r"\[([0-9,]*)\]", line)]
    if len(sigs) != 11:
        raise ValueError("Unexpected signature table")
    return sigs


@lru_cache(None)
def cap_targets():
    text = _source("TrialCoarseMassTargets180.lean")
    lower = int(re.search(r"def lower .*?\| 36 => (\d+)", text, re.S)[1])
    upper = int(re.search(r"def upper .*?\| 36 => (\d+)", text, re.S)[1])
    return lower, upper


@lru_cache(None)
def window_targets():
    text = _source("TrialMassBatchTargets36180.lean")
    out = {}
    for side in ("lower", "upper"):
        block = text.split(f"def {side}72 :", 1)[1].split(f"def {side}64 :", 1)[0]
        out[side] = [[int(n) for n in s.split(",")] for s in re.findall(r"#\[([0-9,-]+)\]", block)]
    return out


# ---------------------------------------------------------------------------
# Exact MassRadialValues.coefficientQ (TrialFrozenData180 / TrialMassRadialValues180)

@lru_cache(None)
def archive():
    table = json.loads((HERE / "frozen_band_tables.json").read_text())
    if table["maxIndex"][FINE_CAP] != LAST_TICK:
        raise ValueError("Unexpected cap-36 cutoff")
    return table


def knot(j):
    pairs = archive()["knots"]
    a = pairs[j] if j < len(pairs) else []
    num = a[0] if len(a) > 0 else 0
    den = a[1] if len(a) > 1 else 0
    return Fraction(num, den) if den else Fraction(0)   # Lean: x / 0 = 0


def _div(a, b):
    return a / b if b else Fraction(0)


@lru_cache(None)
def spline_row(tick):
    """FrozenData.splineQ tick k for k < 30 (Cox-de Boor exactly as in Lean)."""
    x = (Fraction(tick) + Fraction(39, 2)) * STEP
    if not (knot(3) <= x < knot(33)):
        return (Fraction(0),) * 30

    @lru_cache(None)
    def basis(d, i):
        if d == 0:
            return Fraction(int(knot(i) <= x < knot(i + 1)))
        p = d - 1
        return (_div((x - knot(i)) * basis(p, i), knot(i + p + 1) - knot(i)) +
                _div((knot(i + p + 2) - x) * basis(p, i + 1), knot(i + p + 2) - knot(i + 1)))
    return tuple(basis(3, k) for k in range(30))


def row_q(fine, p, s, k):
    t = archive()
    total = Fraction(0)
    for l in range(3):
        if t["suffix"][fine] <= l:
            total += Fraction(t["coeff"][((p * 3 + l) * 11 + s) * 30 + k], t["coeffDen"])
    return total


def keys():
    """FullNativeTicks.Key = Fin 3 × Fin 3 × Fin 11 in flat order (a*3+b)*11+sig."""
    return [(a, b, g) for a in range(3) for b in range(3) for g in range(11)]


def coefficient_q(tick, fine, key):
    a, b, g = key
    sig = signatures()[g]
    exponent = max(0, sum(sig) - len(sig))
    spl = spline_row(tick)
    return Fraction(39) ** exponent * sum(spl[k] * row_q(fine, 3 * a + b, g, k) for k in range(30))


@lru_cache(None)
def radial_rows():
    """coefficientQ (start w + i) 43 u, as [w][i] -> (common denominator, numerators by key)."""
    out = []
    for start, _ in windows():
        rows = []
        for i in range(7):
            if start + i > LAST_TICK:
                raise ValueError("Collocation tick beyond the cap-36 cutoff")
            vals = [coefficient_q(start + i, FINE_CAP, u) for u in keys()]
            den = lcm(*(v.denominator for v in vals))
            rows.append((den, [v.numerator * (den // v.denominator) for v in vals]))
        out.append(rows)
    return out


def channel(w, i, key):
    """radialChannels w i u = 2^64 * coefficientQ."""
    den, nums = radial_rows()[w][i]
    a, b, g = key
    return Fraction(nums[(a * 3 + b) * 11 + g] << 64, den)


def newton(a):
    return [sum((-1) ** (i - j) * comb(i, j) * a[j] for j in range(i + 1)) for i in range(7)]


@lru_cache(None)
def values(w, e, s):
    """MassBatchRadial.newton (contracted (channels w) (channels w) e s), exactly."""
    ends, powers = channel_lists()
    contracted = []
    for k in range(7):
        den, nums = radial_rows()[w][k]
        total = 0
        for (a, b), (c, d) in ends[e]:
            for x, y in powers[s]:
                total += nums[(a * 3 + b) * 11 + x] * nums[(c * 3 + d) * 11 + y]
        contracted.append(Fraction(total << 128, den * den))
    return tuple(newton(contracted))


def amplitude(v, length):
    return sum(abs(c) * length ** k for k, c in enumerate(v))


# ---------------------------------------------------------------------------
# Words and exact scores (needs GMP and the bank .bin files)

def word_files(generated):
    """Relative locations used by build_conservative_proof's bank dispatch."""
    out = {}
    for e, label in enumerate(end_labels()):
        if label == "0000":
            out[("end", e)] = [generated / "cap_square" / f"square-{side}.bin" for side in ("low", "high")]
        else:
            out[("end", e)] = [generated / "cap_end_pairs" / f"cap-end-pair-{label}-{side}.bin" for side in ("lo", "hi")]
    for s in range(53):
        if s == 0:
            out[("ang", s)] = [generated / "cap_powers" / f"power-37-{side}.bin" for side in ("lo", "hi")]
        else:
            out[("ang", s)] = [generated / "cap_gram" / f"weighted-{s:02d}-{side}.bin" for side in ("lo", "hi")]
    return out


def _digest(path):
    h = sha256()
    with path.open("rb") as stream:
        while block := stream.read(1 << 20):
            h.update(block)
    return h.hexdigest()


def _scores_for_endpoint(task):
    """Exact lowScore/highScore for one endpoint pair, all 53 signatures and 10 windows."""
    e, end_paths, ang_paths = task
    sys.path.insert(0, str(HERE))
    from check_cap36_raw_batches import Moments, Word
    ends = [Word(p.read_bytes()) for p in end_paths]
    angular, product, extract = Word(), Word(), Moments()
    rows, sums = [], [[Fraction(0), Fraction(0)] for _ in range(10)]
    for s in range(53):
        digits = []
        for side in range(2):
            angular.load(ang_paths[s][side].read_bytes())
            product.multiply(ends[side], angular)     # raw 640 130965 x y: x, y < 2^(640*COUNT)
            digits.append([extract.seven(product, start, start + n) for start, n in windows()])
        row = []
        for w, (start, n) in enumerate(windows()):
            v = values(w, e, s)
            lo, hi = digits[0][w], digits[1][w]
            radius = amplitude(v, n) * (hi[0] - lo[0])
            low = sum(c * m for c, m in zip(v, lo)) - radius
            high = sum(c * m for c, m in zip(v, hi)) + radius
            if low > high:
                raise ArithmeticError(f"Inverted score at {(e, s, w)}")
            row.append([low.__floor__(), -((-high).__floor__())])
            sums[w][0] += low
            sums[w][1] += high
        rows.append(row)
    return e, rows, [[str(a), str(b)] for a, b in sums]


def exact_scores(generated, destination, jobs):
    files = word_files(generated)
    for paths in files.values():
        for p in paths:
            if not p.is_file() or p.stat().st_size != WORD_BYTES:
                raise FileNotFoundError(f"Missing or truncated factor word {p}")
    inputs = {str(p.relative_to(generated)): _digest(p) for ps in files.values() for p in ps}
    stamp = {"inputs": inputs, "generator": _digest(Path(__file__)),
             "table": _digest(HERE / "frozen_band_tables.json")}
    cache = destination / RESULT_FILE
    if cache.is_file():
        old = json.loads(cache.read_text())
        if old.get("stamp") == stamp:
            audit(old["bounds"], old["window_sums"])
            return old["bounds"]
    tasks = [(e, files[("end", e)], [files[("ang", s)] for s in range(53)]) for e in range(21)]
    results = {}
    with ProcessPoolExecutor(max_workers=jobs) as pool:
        for e, rows, sums in pool.map(_scores_for_endpoint, tasks):
            results[e] = (rows, sums)
    bounds = [results[e][0] for e in range(21)]
    low, high = audit(bounds, [results[e][1] for e in range(21)])
    print(f"Total margins after integer rounding, in units of 2^-72: lower {low:,d}, upper {high:,d}")
    destination.mkdir(parents=True, exist_ok=True)
    tmp = cache.with_suffix(".tmp")
    tmp.write_text(json.dumps({"stamp": stamp, "bounds": bounds,
                               "window_sums": [results[e][1] for e in range(21)]}) + "\n")
    tmp.replace(cache)
    return bounds


def audit(bounds, sums):
    """Cross-check against the frozen 72-bit window targets and the 27-bit cap targets."""
    targets = window_targets()
    for e in range(21):
        for w in range(10):
            low, high = (Fraction(x) for x in sums[e][w])
            if (low * 2**72 / 2**640).__floor__() != targets["lower"][e][w] or \
                    -((-high * 2**72 / 2**640).__floor__()) != targets["upper"][e][w]:
                raise ArithmeticError(f"Exact scores differ from lower72/upper72 at endpoint {e}, window {w}")
    lower, upper = cap_targets()
    total_lo = sum(b[0] for row in bounds for col in row for b in col)
    total_hi = sum(b[1] for row in bounds for col in row for b in col)
    if not (lower * 2**613 <= total_lo <= total_hi <= upper * 2**613):
        raise ArithmeticError("Rounded score totals miss the 27-bit cap-36 targets")
    return (total_lo - lower * 2**613) >> 568, (upper * 2**613 - total_hi) >> 568


# ---------------------------------------------------------------------------
# Module text

def name_end(e):
    return f"TrialCap36WordEnd{end_labels()[e]}180"


def name_ang(s):
    return f"TrialCap36WordAng{s:02d}180"


def ns_end(e):
    return f"Cap36Words.End{end_labels()[e]}"


def ns_ang(s):
    return f"Cap36Words.Ang{s:02d}"


def name_radial(w, i):
    return f"TrialCap36Radial{w}{i}180"


def name_score(e, s):
    return f"TrialCap36Score{e:02d}{s:02d}180"


def reader():
    return "\n".join([
        "import Lean", "",
        "/-! Read a packed 640-bit little-endian word, as `packedWord180%` does. -/",
        "namespace PrimeGap180.Cap36WordReader", "open Lean Elab Term", "",
        "private partial def readNat (a : ByteArray) (start n : Nat) : Nat :=",
        "  if n≤16 then Id.run do", "    let mut out := 0", "    for k in [:n] do",
        "      out := out ||| (a[start+k]!.toNat <<< (8*k))", "    return out", "  else",
        "    let n₁ := n/2", "    (readNat a start n₁) ||| ((readNat a (start+n₁) (n-n₁)) <<< (8*n₁))", "",
        'elab "cap36Word180% " name:str count:num : term => do',
        '  let directory := (System.FilePath.mk (←getFileName)).parent.getD "."',
        "  let bytes ← IO.FS.readBinFile (directory / name.getString)",
        '  unless bytes.size == count.getNat do throwError "invalid number of 640-bit radial lanes"',
        "  return mkNatLit (readNat bytes 0 bytes.size)", "",
        "end PrimeGap180.Cap36WordReader", ""])


def carrier(namespace, paths, destination):
    rel = [os.path.relpath(p, destination) for p in paths]
    for r in rel:
        if not re.fullmatch(r"[A-Za-z0-9_./-]+\.bin", r):
            raise ValueError(f"Unsupported word path {r}")
    return "\n".join([
        "import TrialCap36WordReader180", "",
        "/-! One final cap-36 factor word pair. `TrialMassCap36Scores180` proves it equal to the bank word. -/",
        f"namespace PrimeGap180.{namespace}", "set_option maxRecDepth 16000",
        f'@[irreducible] noncomputable def lo : Nat := cap36Word180% "{rel[0]}" {WORD_BYTES}',
        f'@[irreducible] noncomputable def hi : Nat := cap36Word180% "{rel[1]}" {WORD_BYTES}',
        f"end PrimeGap180.{namespace}", ""])


def base():
    starts = ",".join(str(a) for a, _ in windows())
    lengths = ",".join(str(n) for _, n in windows())
    return "\n".join([
        "import TrialMassRadialValues180", "import TrialMassSpanDot180", "",
        "/-! The ten cap-36 windows (equal to `UnmarkedDotData.start/length`, checked in",
        "`TrialMassCap36Scores180`). No factor word is imported below this module. -/",
        "namespace PrimeGap180.Cap36Scores",
        f"def start : Fin 10 → Nat := ![{starts}]",
        f"def length : Fin 10 → Nat := ![{lengths}]",
        "end PrimeGap180.Cap36Scores", ""])


def _fraction_table(values):
    den = lcm(*(v.denominator for v in values))
    return den, [v.numerator * (den // v.denominator) for v in values]


def _table_def(name, domain, values):
    den, nums = _fraction_table(values)
    return [f"def {name}Den : Nat := {den}",
            f"def {name}Nums : Array Int := #[" + ",".join(map(str, nums)) + "]",
            f"def {name} (k : {domain}) : ℚ := (({name}Nums[k.val]?.getD 0 : Int) : ℚ)/({name}Den : ℚ)"]


ROW_CHUNKS = ((0, 10), (10, 20), (20, 30))


def rows_module(p, chunks=ROW_CHUNKS):
    """rowQ 43 p s k for the 11 signatures s. `rowQ` walks the archive's 8,910-entry
    literal list to index ((p*3+l)*11+s)*30+k, so the kernel cache of one
    declaration grows with p; each declaration covers one k-chunk of one row."""
    lines = ["import TrialMassRadialValues180", "",
             f"/-! The rational row coefficients `FrozenData.rowQ 43 {p} s k`, one kernel",
             "declaration per k-chunk of each (shape, signature) row. -/",
             f"namespace PrimeGap180.Cap36Scores.Rows{p}", *OPTIONS]
    for s in range(11):
        lines += _table_def(f"r{s:02d}", "Fin 30", [row_q(FINE_CAP, p, s, k) for k in range(30)])
        for j, (lo, hi) in enumerate(chunks):
            lines.append(f"theorem row{s:02d}c{j} : ∀ k : Fin 30,{lo} ≤ k.val → k.val<{hi} → "
                         f"FrozenData.rowQ 43 {p} {s} k=r{s:02d} k := by decide +kernel")
        lines.append(f"theorem row{s:02d} (k : Fin 30) : FrozenData.rowQ 43 {p} {s} k=r{s:02d} k := by")
        for j, (lo, hi) in enumerate(chunks[:-1]):
            lines += [f"  by_cases h{j} : k.val<{hi}", f"  · exact row{s:02d}c{j} k (by omega) h{j}"]
        lines.append(f"  exact row{s:02d}c{len(chunks) - 1} k (by omega) k.isLt")
    lines += ["#print axioms row10", f"end PrimeGap180.Cap36Scores.Rows{p}", ""]
    return "\n".join(lines)


def row_table():
    table = ",\n  ".join("![" + ",".join(f"Rows{p}.r{s:02d}" for s in range(11)) + "]" for p in range(9))
    cases = ",".join(f"Rows{p}.row{s:02d}" for p in range(9) for s in range(11))
    return "\n".join([
        *(f"import TrialCap36Rows{p}180" for p in range(9)), "",
        "/-! `coefficientQ j 43 u` as literal arithmetic once the spline row at `j` is known. -/",
        "noncomputable section", "open scoped BigOperators", "namespace PrimeGap180.Cap36Scores",
        "open MassRadialValues", "open FullNativeTicks (Key)", *OPTIONS, "",
        "def rowTable : Fin 9 → Fin 11 → Fin 30 → ℚ := ![\n  " + table + "]", "",
        "theorem rows : ∀ (p : Fin 9) (s : Fin 11) (k : Fin 30),FrozenData.rowQ 43 p s k=rowTable p s k := by",
        "  intro p s", "  fin_cases p <;> fin_cases s", f"  exacts [{cases}]", "",
        "/-- The body of `coefficientQ j 43 u` with the spline row `sp` and `rowTable`. -/",
        "def coeffWith (sp : Fin 30 → ℚ) (u : Key) : ℚ :=",
        "  39^((FrozenProfile.signatures u.2.2).sum-(FrozenProfile.signatures u.2.2).length) *",
        "    ∑ k : Fin 30,sp k*rowTable ⟨3*u.1.val+u.2.1.val,by omega⟩ u.2.2 k", "",
        "theorem coefficient_of (j : Nat) (sp : Fin 30 → ℚ) (hs : ∀ k,FrozenData.splineQ j k=sp k) (u : Key) :",
        "    coefficientQ j 43 u=coeffWith sp u := by",
        "  unfold coefficientQ coeffWith", "  simp only [hs,rows]", "",
        "#print axioms coefficient_of", "end PrimeGap180.Cap36Scores", ""])


def radial(w, i):
    """One collocation tick: the 30 splineQ values (one declaration), then the 99
    coefficients by literal arithmetic against `rowTable` (one declaration)."""
    start = windows()[w][0]
    den, nums = radial_rows()[w][i]
    tick = f"start {w}+(({i} : Fin 7)).val"
    return "\n".join([
        "import TrialCap36ScoreBase180", "import TrialCap36RowTable180", "",
        f"/-! Exact radial coefficients at tick `start {w} + {i}` = {start + i} for the 99 channel keys. -/",
        "noncomputable section", f"namespace PrimeGap180.Cap36Scores.Radial{w}{i}",
        "open MassRadialValues", "open FullNativeTicks (Key)", *OPTIONS,
        *_table_def("sp", "Fin 30", list(spline_row(start + i))),
        f"def den : Nat := {den}",
        "def nums : Array Int := #[" + ",".join(map(str, nums)) + "]",
        "def c (u : Key) : ℚ := ((nums[(u.1.val*3+u.2.1.val)*11+u.2.2.val]?.getD 0 : Int) : ℚ)/(den : ℚ)",
        f"theorem spline : ∀ k : Fin 30,FrozenData.splineQ ({tick}) k=sp k := by decide +kernel",
        "theorem literal : ∀ u : Key,coeffWith sp u=c u := by decide +kernel",
        f"theorem table (u : Key) : coefficientQ ({tick}) 43 u=c u :=",
        "  (coefficient_of _ sp spline u).trans (literal u)",
        "#print axioms table", f"end PrimeGap180.Cap36Scores.Radial{w}{i}", ""])


def radial_table():
    rows = ",\n  ".join("![" + ",".join(f"Radial{w}{i}.c" for i in range(7)) + "]" for w in range(10))
    cases = ",\n    ".join(f"Radial{w}{i}.table u" for w in range(10) for i in range(7))
    return "\n".join([
        *(f"import {name_radial(w, i)}" for w in range(10) for i in range(7)),
        "import TrialMassBatchRadial180", "import TrialMassChannelLists180", "",
        "/-! The cap-36 channel tables on the ten windows and the per-window score predicate. -/",
        "noncomputable section", "namespace PrimeGap180.Cap36Scores",
        "open MassBatchRadial MassRadialValues MassSpanDot",
        "open FullNativeTicks (Key)", *OPTIONS, "",
        "def coeffTable : Fin 10 → Fin 7 → Key → ℚ := ![\n  " + rows + "]", "",
        "/-- `differences 36 (start w)` and `totals 36 (start w)` (cap 37 contributes zero). -/",
        "def channels (w : Fin 10) (i : Fin 7) (u : Key) : ℚ := (2^64:ℚ)*coeffTable w i u", "",
        "/-- `MassBatchTotal.values 36 (span36 w) e s`, after `values_eq`. -/",
        "def vals (w : Fin 10) (e : Fin 21) (s : Fin 53) : Fin 7 → ℚ :=",
        "  newton (contracted (channels w) (channels w) e s)", "",
        "/-- `lo ≤ lowScore` and `highScore ≤ hi` for words `l`, `h` on window `w`. -/",
        "def Check (e : Fin 21) (s : Fin 53) (l h : Nat) (lo hi : ℚ) (w : Fin 10) : Prop :=",
        "  lo ≤ score (vals w e s) (start w) (length w) l-radius (vals w e s) (start w) (length w) l h ∧",
        "  score (vals w e s) (start w) (length w) h+radius (vals w e s) (start w) (length w) l h ≤ hi", "",
        "instance (e : Fin 21) (s : Fin 53) (l h : Nat) (lo hi : ℚ) (w : Fin 10) :",
        "    Decidable (Check e s l h lo hi w) := by unfold Check; infer_instance", "",
        "theorem coeff_eq (w : Fin 10) (i : Fin 7) (u : Key) :",
        "    coefficientQ (start w+i.val) 43 u=coeffTable w i u := by",
        "  fin_cases w <;> fin_cases i",
        "  exacts [" + cases + "]", "",
        "theorem bound : ∀ (w : Fin 10) (i : Fin 7),start w+i.val ≤ 117732 := by decide +kernel", "",
        "private theorem capAt36 : DebitNativeClasses.capAt ⟨36,by decide⟩=43 := by decide +kernel",
        "private theorem cut36 : min 130964 (CoarseLaw.T.maxIndex 43)=117732 := by decide +kernel", "",
        "theorem value36 (j : Nat) (hj : j ≤ 117732) (u : Key) : value j 36 u=coefficientQ j 43 u := by",
        "  have hn : ¬ j>117732 := by omega",
        "  simp only [value,dif_pos (show (36:Nat)<37 by decide),capAt36,cut36,if_neg hn]", "",
        "theorem value37 (j : Nat) (u : Key) : value j 37 u=0 := by simp [value]", "",
        "theorem table (w : Fin 10) (i : Fin 7) (u : Key) :",
        "    differences 36 (start w) i u=channels w i u ∧ totals 36 (start w) i u=channels w i u := by",
        "  have a : value (start w+i.val) 36 u=coeffTable w i u :=",
        "    (value36 _ (bound w i) u).trans (coeff_eq w i u)",
        "  have b : value (start w+i.val) 37 u=0 := value37 _ u",
        "  show (2^64:ℚ)*(value (start w+i.val) 36 u-value (start w+i.val) 37 u)=channels w i u ∧",
        "    (2^64:ℚ)*(value (start w+i.val) 36 u+value (start w+i.val) 37 u)=channels w i u",
        "  rw [a,b,sub_zero,add_zero]",
        "  exact ⟨rfl,rfl⟩", "",
        "#print axioms table", "end PrimeGap180.Cap36Scores", ""])


def _rat(n):
    return f"({n}:ℚ)"


def score(e, s, bounds):
    lo = [b[0] for b in bounds] if bounds else [0] * 10
    hi = [b[1] for b in bounds] if bounds else [0] * 10
    words = (f"(raw 640 130965 {ns_end(e)}.lo {ns_ang(s)}.lo) "
             f"(raw 640 130965 {ns_end(e)}.hi {ns_ang(s)}.hi)")
    lines = [
        "import TrialCap36RadialTable180", "import TrialMassRawProduct180",
        f"import {name_end(e)}", f"import {name_ang(s)}", "",
        f"/-! Kernel score checks for endpoint pair {e} ({end_labels()[e]}) and angular signature {s}. -/",
    ]
    if bounds is None:
        lines.append("-- DRY RUN: placeholder bounds. This module is not a certificate and will not check.")
    lines += [
        f"namespace PrimeGap180.Cap36Scores.Score{e:02d}{s:02d}", "open MassRawProduct", *OPTIONS,
        "def lo : Fin 10 → ℚ := ![" + ",".join(map(_rat, lo)) + "]",
        "def hi : Fin 10 → ℚ := ![" + ",".join(map(_rat, hi)) + "]",
    ]
    lines += [f"theorem check{w} : Check {e} {s} {words} (lo {w}) (hi {w}) {w} := by decide +kernel"
              for w in range(10)]
    lines += [f"theorem check : ∀ w : Fin 10,Check {e} {s} {words} (lo w) (hi w) w := by",
              "  intro w", "  fin_cases w",
              "  exacts [" + ",".join(f"check{w}" for w in range(10)) + "]",
              "#print axioms check", f"end PrimeGap180.Cap36Scores.Score{e:02d}{s:02d}", ""]
    return "\n".join(lines)


def final():
    def vec(items):
        return "![" + ",".join(items) + "]"
    lines = ["import TrialMassCap36Assembly180",
             *(f"import {name_score(e, s)}" for e in range(21) for s in range(53)), "",
             "/-! Discharge `MassCap36Assembly.GroupScores` from the 1,113 generated score modules",
             "and conclude the cap-36 case of the 27-bit mass targets. -/",
             "noncomputable section", "open scoped BigOperators",
             "namespace PrimeGap180.MassCap36Scores",
             "open Cap36Scores MassRawProduct MassBatchRadial", *OPTIONS, "",
             "def endLo : Fin 21 → Nat := " + vec(f"{ns_end(e)}.lo" for e in range(21)),
             "def endHi : Fin 21 → Nat := " + vec(f"{ns_end(e)}.hi" for e in range(21)),
             "def angLo : Fin 53 → Nat := " + vec(f"{ns_ang(s)}.lo" for s in range(53)),
             "def angHi : Fin 53 → Nat := " + vec(f"{ns_ang(s)}.hi" for s in range(53)), "",
             "/-- Every carrier word is literally the bank word (148 literal comparisons). -/",
             "theorem end_words : ∀ e : Fin 21,",
             "    (CheckedEnds36.rows e).lo=endLo e ∧ (CheckedEnds36.rows e).hi=endHi e := by decide +kernel",
             "theorem ang_words : ∀ s : Fin 53,",
             "    (CapAngularComplete.rows s).lo=angLo s ∧ (CapAngularComplete.rows s).hi=angHi s := by decide +kernel", "",
             "theorem lowerWord_eq (e : Fin 21) (s : Fin 53) :",
             "    MassBatchBanks.lowerWord e s=raw 640 130965 (endLo e) (angLo s) := by",
             "  unfold MassBatchBanks.lowerWord",
             "  rw [(end_words e).1,(ang_words s).1]",
             "theorem upperWord_eq (e : Fin 21) (s : Fin 53) :",
             "    MassBatchBanks.upperWord e s=raw 640 130965 (endHi e) (angHi s) := by",
             "  unfold MassBatchBanks.upperWord",
             "  rw [(end_words e).2,(ang_words s).2]", "",
             "def lows : Fin 21 → Fin 53 → Fin 10 → ℚ := ![\n  " +
             ",\n  ".join(vec(f"Score{e:02d}{s:02d}.lo" for s in range(53)) for e in range(21)) + "]",
             "def highs : Fin 21 → Fin 53 → Fin 10 → ℚ := ![\n  " +
             ",\n  ".join(vec(f"Score{e:02d}{s:02d}.hi" for s in range(53)) for e in range(21)) + "]", ""]
    spec = ("Check {e} s (raw 640 130965 (endLo {e}) (angLo s)) (raw 640 130965 (endHi {e}) (angHi s)) "
            "(lows {e} s w) (highs {e} s w) w")
    for e in range(21):
        lines += [f"theorem row{e:02d} : ∀ (s : Fin 53) (w : Fin 10)," + spec.format(e=e) + " := by",
                  "  intro s", "  fin_cases s",
                  "  exacts [" + ",".join(f"Score{e:02d}{s:02d}.check" for s in range(53)) + "]"]
    lines += ["", "theorem allChecks : ∀ (e : Fin 21) (s : Fin 53) (w : Fin 10),",
              "    Check e s (raw 640 130965 (endLo e) (angLo s)) (raw 640 130965 (endHi e) (angHi s))",
              "      (lows e s w) (highs e s w) w := by",
              "  intro e", "  fin_cases e",
              "  exacts [" + ",".join(f"row{e:02d}" for e in range(21)) + "]", "",
              "theorem spans : ∀ w : Fin 10,(MassCap36Assembly.span36 w).start=start w ∧",
              "    (MassCap36Assembly.span36 w).len=length w := by decide +kernel", "",
              "theorem values_eq (w : Fin 10) (e : Fin 21) (s : Fin 53) :",
              "    MassBatchTotal.values 36 (MassCap36Assembly.span36 w) e s=vals w e s := by",
              "  have hd : differences 36 (MassCap36Assembly.span36 w).start=channels w := by",
              "    funext i u", "    rw [(spans w).1]", "    exact (table w i u).1",
              "  have ht : totals 36 (MassCap36Assembly.span36 w).start=channels w := by",
              "    funext i u", "    rw [(spans w).1]", "    exact (table w i u).2",
              "  unfold MassBatchTotal.values vals", "  rw [hd,ht]", "",
              "theorem low_bound (e : Fin 21) (s : Fin 53) (w : Fin 10) : lows e s w ≤",
              "    MassBatchBanks.lowScore (MassBatchTotal.values 36 (MassCap36Assembly.span36 w) e s)",
              "      (MassCap36Assembly.span36 w).start (MassCap36Assembly.span36 w).len",
              "      (MassBatchBanks.lowerWord e s) (MassBatchBanks.upperWord e s) := by",
              "  rw [values_eq,(spans w).1,(spans w).2,lowerWord_eq,upperWord_eq]",
              "  exact And.left (allChecks e s w)", "",
              "theorem high_bound (e : Fin 21) (s : Fin 53) (w : Fin 10) :",
              "    MassBatchBanks.highScore (MassBatchTotal.values 36 (MassCap36Assembly.span36 w) e s)",
              "      (MassCap36Assembly.span36 w).start (MassCap36Assembly.span36 w).len",
              "      (MassBatchBanks.lowerWord e s) (MassBatchBanks.upperWord e s) ≤ highs e s w := by",
              "  rw [values_eq,(spans w).1,(spans w).2,lowerWord_eq,upperWord_eq]",
              "  exact And.right (allChecks e s w)", "",
              "theorem low_total : (CoarseMassTargets.lower 36:ℚ)*2^613 ≤",
              "    ∑ e : Fin 21,∑ w : Fin 10,∑ s : Fin 53,lows e s w := by decide +kernel",
              "theorem high_total : ∑ e : Fin 21,∑ w : Fin 10,∑ s : Fin 53,highs e s w ≤",
              "    (CoarseMassTargets.upper 36:ℚ)*2^613 := by decide +kernel", "",
              "def groupScores : MassCap36Assembly.GroupScores :=",
              "  ⟨lows,highs,low_bound,high_bound,low_total,high_total⟩",
              "def scores : MassCap36Assembly.Scores := groupScores.toScores", "",
              "theorem cap36_mass :",
              "    (CoarseMassTargets.lower 36 : ℝ) ≤ 2^27*RoundedCaps.m PositiveCap.physicalGrid 36 ∧",
              "    2^27*RoundedCaps.m PositiveCap.physicalGrid 36 ≤ (CoarseMassTargets.upper 36 : ℝ) :=",
              "  MassCap36Assembly.cap36 scores", "",
              "#print axioms cap36_mass", "end PrimeGap180.MassCap36Scores", ""]
    return "\n".join(lines)


# ---------------------------------------------------------------------------

def emit(destination, generated, bounds):
    destination.mkdir(parents=True, exist_ok=True)
    files = word_files(generated)
    texts = {"TrialCap36WordReader180": reader(), "TrialCap36ScoreBase180": base()}
    for e in range(21):
        texts[name_end(e)] = carrier(ns_end(e), files[("end", e)], destination)
    for s in range(53):
        texts[name_ang(s)] = carrier(ns_ang(s), files[("ang", s)], destination)
    for p in range(9):
        texts[f"TrialCap36Rows{p}180"] = rows_module(p)
    texts["TrialCap36RowTable180"] = row_table()
    for w in range(10):
        for i in range(7):
            texts[name_radial(w, i)] = radial(w, i)
    texts["TrialCap36RadialTable180"] = radial_table()
    for e in range(21):
        for s in range(53):
            texts[name_score(e, s)] = score(e, s, None if bounds is None else bounds[e][s])
    texts[FINAL] = final()
    modules = {}
    for name, text in texts.items():
        path = destination / f"{name}.lean"
        if not path.is_file() or path.read_text() != text:
            path.write_text(text)
        modules[name] = path
    return modules


def generate(destination, generated, jobs=4):
    """Entry point for build_conservative_proof.py: all bank .bin files must already exist."""
    bounds = exact_scores(generated, destination, jobs)
    return emit(destination, generated, bounds)


KINDS = [("reader", r"TrialCap36WordReader180"), ("endpoint word carriers", r"TrialCap36WordEnd[012]{4}180"),
         ("angular word carriers", r"TrialCap36WordAng\d{2}180"), ("window base", r"TrialCap36ScoreBase180"),
         ("row modules", r"TrialCap36Rows\d180"), ("row table", r"TrialCap36RowTable180"),
         ("radial tick modules", r"TrialCap36Radial\d{2}180"), ("radial table", r"TrialCap36RadialTable180"),
         ("score modules", r"TrialCap36Score\d{4}180"), ("final assembly", FINAL)]


def summary(modules):
    groups, sizes = Counter(), Counter()
    for name, path in modules.items():
        kind = next(k for k, pattern in KINDS if re.fullmatch(pattern, name))
        groups[kind] += 1
        sizes[kind] += path.stat().st_size
    print("Module kinds (count, total source bytes):")
    for kind, _ in KINDS:
        print(f"  {kind:24s} {groups[kind]:5d} {sizes[kind]:12,d}")
    print(f"  {'total':24s} {sum(groups.values()):5d} {sum(sizes.values()):12,d}")
    local = {n: [line.split()[1] for line in p.read_text().splitlines() if line.startswith("import ")]
             for n, p in modules.items()}
    print("Import structure (examples; every module of a kind has the same shape):")
    shown = ["TrialCap36WordReader180", name_end(1), name_ang(7), "TrialCap36ScoreBase180",
             "TrialCap36Rows4180", "TrialCap36RowTable180", name_radial(3, 2), "TrialCap36RadialTable180", name_score(3, 7)]
    for n in shown:
        imports = local[n] if len(local[n]) < 8 else local[n][:2] + [f"... ({len(local[n])} imports)"]
        print(f"  {n} <- {', '.join(imports)}")
    print(f"  {FINAL} <- {local[FINAL][0]} + {len(local[FINAL]) - 1} score modules")
    print(f"Words loaded per score module: 4 x {WORD_BYTES:,d} bytes (one endpoint pair, one signature).")
    print(f"Carrier literals: {21 + 53} modules x 2 words = {(21 + 53) * 2 * WORD_BYTES / 2**30:.2f} GiB.")
    print("Kernel work: 99 rowQ rows (30 each); 70 splineQ rows (30 each) and 70 x 99 literal coefficients;")
    print("1,113 x 10 window checks (two 84-Mbit products each);")
    print("148 literal word identities; two sums of 11,130 rationals; then MassCap36Assembly.cap36.")


def crosscheck_values():
    """Compare `vals` with the independent channel arithmetic of check_span_mass_dots (no words)."""
    sys.path.insert(0, str(HERE))
    from check_span_mass_dots import groups, spans
    catalog = spans(CAP_CLASS)
    if [(a, b - a) for a, b, *_ in catalog] != list(windows()):
        raise ValueError("Python spans differ from the Lean windows")
    assignments = groups()
    sigs = sorted(assignments)
    shapes = sorted(assignments[sigs[0]])
    if ["".join(str(x) for shape in key for x in shape) for key in shapes] != list(end_labels()):
        raise ValueError("Endpoint order differs")
    for w, (start, stop, den, diff, total) in enumerate(catalog):
        for i in range(7):
            for u in keys():
                a, b, g = u
                if channel(w, i, u) != Fraction(diff[9 * g + 3 * a + b][i], den) or diff != total:
                    raise ArithmeticError(f"Channel mismatch at window {w}, tick {i}, key {u}")
        for s, sig in enumerate(sigs):
            for e, key in enumerate(shapes):
                rows = assignments[sig][key]
                coeff = newton([sum(diff[p][k] * total[q][k] for p, q in rows) for k in range(7)])
                if tuple(Fraction(c, den * den) for c in coeff) != values(w, e, s):
                    raise ArithmeticError(f"Weight mismatch at window {w}, endpoint {e}, signature {s}")
    print("Matched 6,930 channel values and 11,130 weight vectors with check_span_mass_dots.")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--build-dir", type=Path, help="build directory of build_conservative_proof.py")
    parser.add_argument("--output-dir", type=Path, help=f"default: <build>/generated/{DIRECTORY}")
    parser.add_argument("--jobs", type=int, default=4)
    parser.add_argument("--dry-run", action="store_true", help="emit skeletons without words or scores")
    parser.add_argument("--crosscheck", action="store_true",
                        help="compare the exact weights with check_span_mass_dots (no words needed)")
    args = parser.parse_args()
    if args.crosscheck:
        crosscheck_values()
    if args.dry_run:
        out = args.output_dir or parser.error("--dry-run needs --output-dir")
        generated = (args.build_dir / "generated") if args.build_dir else out.parent
        summary(emit(out, generated, None))
        return
    if args.build_dir is None:
        if args.crosscheck:
            return
        parser.error("--build-dir is required unless --dry-run")
    generated = args.build_dir.resolve() / "generated"
    destination = args.output_dir or generated / DIRECTORY
    modules = generate(destination, generated, args.jobs)
    summary(modules)


if __name__ == "__main__":
    main()
