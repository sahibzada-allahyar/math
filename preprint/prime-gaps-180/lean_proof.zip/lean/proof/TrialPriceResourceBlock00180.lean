import TrialPriceResourceRows180
namespace PrimeGap180.PriceResourceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 100000000
private theorem p0 : checkResource 0 = true := by decide +kernel
private theorem p1 : checkResource 1 = true := by decide +kernel
private theorem p2 : checkResource 2 = true := by decide +kernel
private theorem p3 : checkResource 3 = true := by decide +kernel
private theorem p4 : checkResource 4 = true := by decide +kernel
private theorem p5 : checkResource 5 = true := by decide +kernel
private theorem p6 : checkResource 6 = true := by decide +kernel
theorem block0 : ∀ j : Fin 7, checkResource (0+j.val) = true :=
  Fin.cases p0 (Fin.cases p1 (Fin.cases p2 (Fin.cases p3 (Fin.cases p4 (Fin.cases p5 (Fin.cases p6 (fun i => Fin.elim0 i)))))))
#print axioms block0
end PrimeGap180.PriceResourceRows
