import TrialPriceEvents180
import TrialPriceAssembly180
import TrialFrozenHigherDense180

/-! Match the affine rows to the physical event moments, including their
order in the price book and their cutoffs in the distribution theorem. -/
noncomputable section
open scoped Classical BigOperators
open PrimeGap180.Literal PrimeGap180.PriceEvents PrimeGap180.Price
namespace PrimeGap180.PhysicalPrices

inductive Row
  | prime | sharp | higher (i : Fin 12)
  deriving Fintype, DecidableEq

def channel (x : ℝ) : Row → Channel
  | .prime => .prime
  | .sharp => .sharp (base x)
  | .higher i => .higher (x^(Sifted.frozenCutoffs i).a) (x^(Frozen.parentCut i))

private theorem cuts (i : Fin 12) :
    (Sifted.frozenCutoffs i).a = (topTicks i : ℝ)/10^10 ∧
    Frozen.parentCut i = (lowTicks i : ℝ)/10^7 := by
  fin_cases i <;> norm_num [Sifted.frozenCutoffs,Frozen.parentCut,topTicks,lowTicks]

private def unitRow (e t : Event) : ℝ := if e = t then 1 else 0

def coefficient : Row → Event → ℝ
  | .prime, e => unitRow .prime e
  | .sharp, e => unitRow .prime e - unitRow .oldFive e
  | .higher i, e => unitRow .prime e - unitRow .oldFive e -
      (∑ j ∈ Finset.Iic i, unitRow (.three j) e) - ∑ j ∈ Finset.Iic i, unitRow (.newFive j) e

/-- The sign pattern is valid pointwise, before any averaging or sieve
estimate. Each composite event measure carries its original multiplicity. -/
theorem literal_mix {x : ℝ} (hx : 1 ≤ x) (n : ℕ) (k : Row) :
    (∑ e, coefficient k e * mass x n e) = value (channel x k) n := by
  have unit (e : Event) : (∑ t, unitRow e t * mass x n t) = mass x n e := by
    simp [unitRow,ite_mul]
  obtain ⟨prime,sharp,higher⟩ := literal_rows hx n
  cases k with
  | prime => exact (unit _).trans prime.symm
  | sharp => simpa only [channel,coefficient,sub_mul,Finset.sum_sub_distrib,unit] using sharp.symm
  | higher i =>
    have sc (f : Fin 12 → Event) :
        (∑ e, (∑ j ∈ Finset.Iic i, unitRow (f j) e) * mass x n e) =
          ∑ j ∈ Finset.Iic i, mass x n (f j) := by
      simp_rw [Finset.sum_mul]
      rw [Finset.sum_comm]
      simp only [unit]
    simp only [coefficient,sub_mul,Finset.sum_sub_distrib,unit,sc,channel,(cuts i).1,(cuts i).2]
    exact (higher i).symm

/-- For the actual dyadic sample and any common sector amplitudes, each
affine row is exactly the literal shifted prime/minorant matrix on that
sample. The factor Z can include the scale and progression indicator. -/
theorem physical_mix {I : Type*} (s : Finset ℕ) (v : ℕ → I → ℝ)
    (Z : ℕ → ℝ) (h : ℕ) {x : ℝ} (hx : 1 ≤ x) (k : Row) :
    mix (coefficient k) (fun e => moment s (fun n => mass x (n+h) e * Z n) v) =
      moment s (fun n => value (channel x k) (n+h) * Z n) v := by
  rw [mix_moment]
  congr 1
  funext n
  rw [← literal_mix hx (n+h) k,Finset.sum_mul]
  exact Finset.sum_congr rfl fun e _ => by ring

def objective {I : Type*} (w : I → ℝ) (e : Event) (i j : I) : ℝ :=
  if e = .prime then w i*w j else 0

private theorem objective_eq {I : Type*} [Fintype I] (w : I → ℝ) (s : Finset ℕ)
    (v : ℕ → I → ℝ) (Z : ℕ → ℝ) (h : ℕ) (x : ℝ) :
    (∑ e, pair (objective w e) (moment s (fun n => mass x (n+h) e * Z n) v)) =
      ∑ n ∈ s, (if (n+h).Prime then 1 else 0)*Z n*(∑ i, w i*v n i)^2 := by
  have onlyP (e : Event) : pair (objective w e) (moment s (fun n => mass x (n+h) e * Z n) v) =
      if e = .prime then pair (fun i j => w i*w j) (moment s (fun n => mass x (n+h) .prime * Z n) v)
      else 0 := by
    by_cases he : e = .prime
    · subst e; simp [pair,objective]
    · simp [pair,objective,he]
  simp_rw [onlyP]
  rw [Finset.sum_ite_eq',ite_eq_left (Finset.mem_univ _),pair_moment]
  apply Finset.sum_congr rfl
  intro n _
  congr 1
  simp only [Dual.quad,pow_two,Finset.sum_mul,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  exact Finset.sum_congr rfl fun j _ => by ring

/-- Conditional assembly for one actual shift. The affine premises refer
to the literal signed integer rows. The conclusion is the prime count
weighted by the square of the combined sector amplitude. -/
theorem lower_prime_count {L : Filter ℝ} {I U : Type*} [Fintype I] [Fintype U]
    (s : ℝ → Finset ℕ) (v : ℝ → ℕ → I → ℝ) (Z : ℝ → ℕ → ℝ) (h : ℕ) (w : I → ℝ)
    (A : Row → I → I → ℝ) (G : U → I → I → ℝ) (b : U → Event → ℝ)
    (R : Event → I → I → ℝ) (earned : Row → ℝ) (pen : Event → ℝ) (cost : U → ℝ)
    (res : ∀ e i j, R e i j = objective w e i j - (∑ k, coefficient k e*A k i j) +
      ∑ u, b u e*G u i j)
    (rows : ∀ k, Lower (fun x => pair (A k) (moment (s x)
      (fun n => value (channel x k) (n+h) * Z x n) (v x))) (earned k) L)
    (coupled : ∀ u, Lower (fun x => -pair (G u) (mix (b u) (fun e => moment (s x)
      (fun n => mass x (n+h) e * Z x n) (v x)))) (-cost u) L)
    (residual : ∀ e, Lower (fun x => pair (R e) (moment (s x)
      (fun n => mass x (n+h) e * Z x n) (v x))) (-pen e) L)
    (cofinal : L ≤ Filter.atTop := by exact le_rfl) :
    Lower (fun x => ∑ n ∈ s x, (if (n+h).Prime then 1 else 0) * Z x n *
      (∑ i, w i*v x n i)^2) ((∑ k, earned k)-(∑ u, cost u)-∑ e, pen e) L := by
  let H := fun (x : ℝ) (e : Event) => moment (s x) (fun n => mass x (n+h) e*Z x n) (v x)
  have affine (k : Row) : Lower (fun x => pair (A k) (mix (coefficient k) (H x))) (earned k) L := by
    intro ε he
    filter_upwards [rows k ε he, cofinal (Filter.eventually_ge_atTop (1:ℝ))] with x hx h1
    simpa only [H,physical_mix (s x) (v x) (Z x) h h1 k] using hx
  have book := lower_objective (objective w) R H A G coefficient b earned pen cost res affine coupled residual
  intro ε he
  filter_upwards [book ε he] with x hx
  simpa only [H,objective_eq] using hx

#print axioms lower_prime_count
#print axioms physical_mix
end PrimeGap180.PhysicalPrices
