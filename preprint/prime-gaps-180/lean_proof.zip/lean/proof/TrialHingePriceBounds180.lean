import TrialHingePriceAnalytic180
import TrialMarkedPriceRadii180
import TrialPriceEvents180

namespace PrimeGap180.HingePrices
open PackedLedger
def cut (j : Fin 12) : ℚ := (PriceEvents.lowTicks j:ℚ)/10^7
def cap (s : Fin 49) : ℚ := (PriceRadii.classes[s.val]!:ℚ)/10000
noncomputable def stored (j : Fin 12) (c : Fin 49) : ℚ :=
  let v := if j.val = 0 then (raw.eventKernel[2]!)[c.val]!
           else (raw.resourceKernel[26+j.val]!)[c.val]!
  (v.1:ℚ)/v.2

set_option maxRecDepth 65536 in
set_option maxHeartbeats 0 in
theorem domain : ∀ (j : Fin 12) (s : Fin 49), let a := cut j; let q := cap s
    0 < a ∧ a ≤ peak ∧ 1-2*q-2*a ≤ a ∧ 0 < min a ((1-peak)/2-q)-1/10000 ∧
    1 ≤ peak/a ∧ 1 ≤ ratio a q ∧ 0 ≤ peak/center q ∧ 0 ≤ 2-peak/center q := by decide +kernel

set_option maxRecDepth 65536 in
set_option maxHeartbeats 0 in
theorem checked : ∀ (j : Fin 12) (s : Fin 49),
    priceUpper (cut j) (cap s) 20 ≤ stored j s := by decide +kernel

theorem integral (j : Fin 12) (s : Fin 49) :
    (multiplier:ℝ) * (∫ t in (cut j:ℝ)..(peak:ℝ), EventBins.hingeDensity (cut j) (cap s) peak t) ≤
      (stored j s:ℝ) := by
  obtain ⟨ha,ab,sw,room,p,r,co,co'⟩ := domain j s
  exact (priced _ _ 20 ha ab sw room p r co co').trans (by exact_mod_cast checked j s)
#print axioms integral
end PrimeGap180.HingePrices
