import TrialPriceIsolatedChecks180
import TrialPriceFastAffine180
import Lean

noncomputable section
namespace PrimeGap180.PriceIsolatedGroup.G416
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

open Lean Elab Command
elab "price416stamp" n:str : command => do
  logInfo m!"{n.getString} {← IO.monoMsNow}"

price416stamp "begin"
declarePriceActions 416
price416stamp "numeric_candidates"
private theorem m0 : PriceFactorData.rowAction 0 416 = gramActions[0]! := by decide +kernel
private theorem m1 : PriceFactorData.rowAction 1 416 = gramActions[1]! := by decide +kernel
private theorem m2 : PriceFactorData.rowAction 2 416 = gramActions[2]! := by decide +kernel
private theorem m3 : PriceFactorData.rowAction 3 416 = gramActions[3]! := by decide +kernel
private theorem m4 : PriceFactorData.rowAction 4 416 = gramActions[4]! := by decide +kernel
private theorem m5 : PriceFactorData.rowAction 5 416 = gramActions[5]! := by decide +kernel
private theorem m6 : PriceFactorData.rowAction 6 416 = gramActions[6]! := by decide +kernel
private theorem m7 : PriceFactorData.rowAction 7 416 = gramActions[7]! := by decide +kernel
private theorem m8 : PriceFactorData.rowAction 8 416 = gramActions[8]! := by decide +kernel
private theorem m9 : PriceFactorData.rowAction 9 416 = gramActions[9]! := by decide +kernel
private theorem m10 : PriceFactorData.rowAction 10 416 = gramActions[10]! := by decide +kernel
private theorem m11 : PriceFactorData.rowAction 11 416 = gramActions[11]! := by decide +kernel
private theorem m12 : PriceFactorData.rowAction 12 416 = gramActions[12]! := by decide +kernel
private theorem m13 : PriceFactorData.rowAction 13 416 = gramActions[13]! := by decide +kernel
private theorem m14 : PriceFactorData.rowAction 14 416 = gramActions[14]! := by decide +kernel
private theorem m15 : PriceFactorData.rowAction 15 416 = gramActions[15]! := by decide +kernel
private theorem m16 : PriceFactorData.rowAction 16 416 = gramActions[16]! := by decide +kernel
private theorem m17 : PriceFactorData.rowAction 17 416 = gramActions[17]! := by decide +kernel
private theorem m18 : PriceFactorData.rowAction 18 416 = gramActions[18]! := by decide +kernel
private theorem m19 : PriceFactorData.rowAction 19 416 = gramActions[19]! := by decide +kernel
private theorem m20 : PriceFactorData.rowAction 20 416 = gramActions[20]! := by decide +kernel
private theorem m21 : PriceFactorData.rowAction 21 416 = gramActions[21]! := by decide +kernel
private theorem m22 : PriceFactorData.rowAction 22 416 = gramActions[22]! := by decide +kernel
private theorem m23 : PriceFactorData.rowAction 23 416 = gramActions[23]! := by decide +kernel
private theorem m24 : PriceFactorData.rowAction 24 416 = gramActions[24]! := by decide +kernel
private theorem m25 : PriceFactorData.rowAction 25 416 = gramActions[25]! := by decide +kernel
private theorem m26 : PriceFactorData.rowAction 26 416 = gramActions[26]! := by decide +kernel
private theorem m27 : PriceFactorData.rowAction 27 416 = gramActions[27]! := by decide +kernel
private theorem m28 : PriceFactorData.rowAction 28 416 = gramActions[28]! := by decide +kernel
private theorem m29 : PriceFactorData.rowAction 29 416 = gramActions[29]! := by decide +kernel
private theorem m30 : PriceFactorData.rowAction 30 416 = gramActions[30]! := by decide +kernel
private theorem m31 : PriceFactorData.rowAction 31 416 = gramActions[31]! := by decide +kernel
private theorem m32 : PriceFactorData.rowAction 32 416 = gramActions[32]! := by decide +kernel
private theorem m33 : PriceFactorData.rowAction 33 416 = gramActions[33]! := by decide +kernel
private theorem m34 : PriceFactorData.rowAction 34 416 = gramActions[34]! := by decide +kernel
private theorem m35 : PriceFactorData.rowAction 35 416 = gramActions[35]! := by decide +kernel
private theorem m36 : PriceFactorData.rowAction 36 416 = gramActions[36]! := by decide +kernel
private theorem m37 : PriceFactorData.rowAction 37 416 = gramActions[37]! := by decide +kernel
private theorem m38 : PriceFactorData.rowAction 38 416 = gramActions[38]! := by decide +kernel
private theorem m39 : PriceFactorData.rowAction 39 416 = gramActions[39]! := by decide +kernel
private theorem m40 : PriceFactorData.rowAction 40 416 = gramActions[40]! := by decide +kernel
private theorem m41 : PriceFactorData.rowAction 41 416 = gramActions[41]! := by decide +kernel
private theorem m42 : PriceFactorData.rowAction 42 416 = gramActions[42]! := by decide +kernel
private theorem m43 : PriceFactorData.rowAction 43 416 = gramActions[43]! := by decide +kernel
private theorem m44 : PriceFactorData.rowAction 44 416 = gramActions[44]! := by decide +kernel
private theorem m45 : PriceFactorData.rowAction 45 416 = gramActions[45]! := by decide +kernel
private theorem m46 : PriceFactorData.rowAction 46 416 = gramActions[46]! := by decide +kernel
private theorem m47 : PriceFactorData.rowAction 47 416 = gramActions[47]! := by decide +kernel
private theorem m48 : PriceFactorData.rowAction 48 416 = gramActions[48]! := by decide +kernel
private theorem m49 : PriceFactorData.rowAction 49 416 = gramActions[49]! := by decide +kernel
private theorem m50 : PriceFactorData.rowAction 50 416 = gramActions[50]! := by decide +kernel
private theorem m51 : PriceFactorData.rowAction 51 416 = gramActions[51]! := by decide +kernel
private theorem m52 : PriceFactorData.rowAction 52 416 = gramActions[52]! := by decide +kernel
private theorem m53 : PriceFactorData.rowAction 53 416 = gramActions[53]! := by decide +kernel
private theorem m54 : PriceFactorData.rowAction 54 416 = gramActions[54]! := by decide +kernel
private theorem m55 : PriceFactorData.rowAction 55 416 = gramActions[55]! := by decide +kernel
private theorem m56 : PriceFactorData.rowAction 56 416 = gramActions[56]! := by decide +kernel
private theorem m57 : PriceFactorData.rowAction 57 416 = gramActions[57]! := by decide +kernel
private theorem m58 : PriceFactorData.rowAction 58 416 = gramActions[58]! := by decide +kernel
private theorem m59 : PriceFactorData.rowAction 59 416 = gramActions[59]! := by decide +kernel
private theorem m60 : PriceFactorData.rowAction 60 416 = gramActions[60]! := by decide +kernel
private theorem m61 : PriceFactorData.rowAction 61 416 = gramActions[61]! := by decide +kernel
private theorem m62 : PriceFactorData.rowAction 62 416 = gramActions[62]! := by decide +kernel
private theorem m63 : PriceFactorData.rowAction 63 416 = gramActions[63]! := by decide +kernel
private theorem m64 : PriceFactorData.rowAction 64 416 = gramActions[64]! := by decide +kernel
private theorem m65 : PriceFactorData.rowAction 65 416 = gramActions[65]! := by decide +kernel
private theorem m66 : PriceFactorData.rowAction 66 416 = gramActions[66]! := by decide +kernel
private theorem m67 : PriceFactorData.rowAction 67 416 = gramActions[67]! := by decide +kernel
private theorem m68 : PriceFactorData.rowAction 68 416 = gramActions[68]! := by decide +kernel
private theorem m69 : PriceFactorData.rowAction 69 416 = gramActions[69]! := by decide +kernel
private theorem m70 : PriceFactorData.rowAction 70 416 = gramActions[70]! := by decide +kernel
private theorem m71 : PriceFactorData.rowAction 71 416 = gramActions[71]! := by decide +kernel
private theorem m72 : PriceFactorData.rowAction 72 416 = gramActions[72]! := by decide +kernel
private theorem m73 : PriceFactorData.rowAction 73 416 = gramActions[73]! := by decide +kernel
private theorem m74 : PriceFactorData.rowAction 74 416 = gramActions[74]! := by decide +kernel
private theorem m75 : PriceFactorData.rowAction 75 416 = gramActions[75]! := by decide +kernel
private theorem m76 : PriceFactorData.rowAction 76 416 = gramActions[76]! := by decide +kernel
private theorem m77 : PriceFactorData.rowAction 77 416 = gramActions[77]! := by decide +kernel
private theorem m78 : PriceFactorData.rowAction 78 416 = gramActions[78]! := by decide +kernel
private theorem m79 : PriceFactorData.rowAction 79 416 = gramActions[79]! := by decide +kernel
private theorem m80 : PriceFactorData.rowAction 80 416 = gramActions[80]! := by decide +kernel
private theorem m81 : PriceFactorData.rowAction 81 416 = gramActions[81]! := by decide +kernel
private theorem m82 : PriceFactorData.rowAction 82 416 = gramActions[82]! := by decide +kernel
private theorem m83 : PriceFactorData.rowAction 83 416 = gramActions[83]! := by decide +kernel
private theorem m84 : PriceFactorData.rowAction 84 416 = gramActions[84]! := by decide +kernel
private theorem m85 : PriceFactorData.rowAction 85 416 = gramActions[85]! := by decide +kernel
private theorem m86 : PriceFactorData.rowAction 86 416 = gramActions[86]! := by decide +kernel
private theorem m87 : PriceFactorData.rowAction 87 416 = gramActions[87]! := by decide +kernel
private theorem m88 : PriceFactorData.rowAction 88 416 = gramActions[88]! := by decide +kernel
private theorem m89 : PriceFactorData.rowAction 89 416 = gramActions[89]! := by decide +kernel
private theorem m90 : PriceFactorData.rowAction 90 416 = gramActions[90]! := by decide +kernel
private theorem m91 : PriceFactorData.rowAction 91 416 = gramActions[91]! := by decide +kernel
private theorem m92 : PriceFactorData.rowAction 92 416 = gramActions[92]! := by decide +kernel
private theorem m93 : PriceFactorData.rowAction 93 416 = gramActions[93]! := by decide +kernel
private theorem m94 : PriceFactorData.rowAction 94 416 = gramActions[94]! := by decide +kernel
private theorem m95 : PriceFactorData.rowAction 95 416 = gramActions[95]! := by decide +kernel
private theorem m96 : PriceFactorData.rowAction 96 416 = gramActions[96]! := by decide +kernel
private theorem m97 : PriceFactorData.rowAction 97 416 = gramActions[97]! := by decide +kernel
private theorem m98 : PriceFactorData.rowAction 98 416 = gramActions[98]! := by decide +kernel
private theorem m99 : PriceFactorData.rowAction 99 416 = gramActions[99]! := by decide +kernel
private theorem m100 : PriceFactorData.rowAction 100 416 = gramActions[100]! := by decide +kernel

attribute [local irreducible] PriceFactorData.rowAction gramActions

private theorem gram_values : moments (416 : Group) = gramActions := by
  apply PriceIsolatedChecks.moments_of_entries
  · decide +kernel
  · intro i
    fin_cases i
    · exact m0
    · exact m1
    · exact m2
    · exact m3
    · exact m4
    · exact m5
    · exact m6
    · exact m7
    · exact m8
    · exact m9
    · exact m10
    · exact m11
    · exact m12
    · exact m13
    · exact m14
    · exact m15
    · exact m16
    · exact m17
    · exact m18
    · exact m19
    · exact m20
    · exact m21
    · exact m22
    · exact m23
    · exact m24
    · exact m25
    · exact m26
    · exact m27
    · exact m28
    · exact m29
    · exact m30
    · exact m31
    · exact m32
    · exact m33
    · exact m34
    · exact m35
    · exact m36
    · exact m37
    · exact m38
    · exact m39
    · exact m40
    · exact m41
    · exact m42
    · exact m43
    · exact m44
    · exact m45
    · exact m46
    · exact m47
    · exact m48
    · exact m49
    · exact m50
    · exact m51
    · exact m52
    · exact m53
    · exact m54
    · exact m55
    · exact m56
    · exact m57
    · exact m58
    · exact m59
    · exact m60
    · exact m61
    · exact m62
    · exact m63
    · exact m64
    · exact m65
    · exact m66
    · exact m67
    · exact m68
    · exact m69
    · exact m70
    · exact m71
    · exact m72
    · exact m73
    · exact m74
    · exact m75
    · exact m76
    · exact m77
    · exact m78
    · exact m79
    · exact m80
    · exact m81
    · exact m82
    · exact m83
    · exact m84
    · exact m85
    · exact m86
    · exact m87
    · exact m88
    · exact m89
    · exact m90
    · exact m91
    · exact m92
    · exact m93
    · exact m94
    · exact m95
    · exact m96
    · exact m97
    · exact m98
    · exact m99
    · exact m100
price416stamp "gram_proofs"
private theorem a0 : affine (416 : Group) (.prime : Book.Row) = affineActions[0]! := by rw [PriceFastAffine.affine_eq] <;> decide +kernel
private theorem a1 : affine (416 : Group) (.sharp : Book.Row) = affineActions[1]! := by rw [PriceFastAffine.affine_eq] <;> decide +kernel
private theorem a2 : affine (416 : Group) (.higher 0 : Book.Row) = affineActions[2]! := by rw [PriceFastAffine.affine_eq] <;> decide +kernel
private theorem a3 : affine (416 : Group) (.higher 1 : Book.Row) = affineActions[3]! := by rw [PriceFastAffine.affine_eq] <;> decide +kernel
private theorem a4 : affine (416 : Group) (.higher 2 : Book.Row) = affineActions[4]! := by rw [PriceFastAffine.affine_eq] <;> decide +kernel
private theorem a5 : affine (416 : Group) (.higher 3 : Book.Row) = affineActions[5]! := by rw [PriceFastAffine.affine_eq] <;> decide +kernel
private theorem a6 : affine (416 : Group) (.higher 4 : Book.Row) = affineActions[6]! := by rw [PriceFastAffine.affine_eq] <;> decide +kernel
private theorem a7 : affine (416 : Group) (.higher 5 : Book.Row) = affineActions[7]! := by rw [PriceFastAffine.affine_eq] <;> decide +kernel
private theorem a8 : affine (416 : Group) (.higher 6 : Book.Row) = affineActions[8]! := by rw [PriceFastAffine.affine_eq] <;> decide +kernel
private theorem a9 : affine (416 : Group) (.higher 7 : Book.Row) = affineActions[9]! := by rw [PriceFastAffine.affine_eq] <;> decide +kernel
private theorem a10 : affine (416 : Group) (.higher 8 : Book.Row) = affineActions[10]! := by rw [PriceFastAffine.affine_eq] <;> decide +kernel
private theorem a11 : affine (416 : Group) (.higher 9 : Book.Row) = affineActions[11]! := by rw [PriceFastAffine.affine_eq] <;> decide +kernel
private theorem a12 : affine (416 : Group) (.higher 10 : Book.Row) = affineActions[12]! := by rw [PriceFastAffine.affine_eq] <;> decide +kernel
private theorem a13 : affine (416 : Group) (.higher 11 : Book.Row) = affineActions[13]! := by rw [PriceFastAffine.affine_eq] <;> decide +kernel

private theorem affine_values : affine (416 : Group) = fun k => affineActions[FrozenGuards.code k]! := by
  funext k
  cases k with
  | prime => exact a0
  | sharp => exact a1
  | higher i =>
    fin_cases i
    · exact a2
    · exact a3
    · exact a4
    · exact a5
    · exact a6
    · exact a7
    · exact a8
    · exact a9
    · exact a10
    · exact a11
    · exact a12
    · exact a13
price416stamp "affine_proofs"
private theorem e0 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.prime : Book.Event) := by decide +kernel
private theorem e1 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.oldFive : Book.Event) := by decide +kernel
private theorem e2 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 0 : Book.Event) := by decide +kernel
private theorem e3 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 1 : Book.Event) := by decide +kernel
private theorem e4 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 2 : Book.Event) := by decide +kernel
private theorem e5 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 3 : Book.Event) := by decide +kernel
private theorem e6 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 4 : Book.Event) := by decide +kernel
private theorem e7 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 5 : Book.Event) := by decide +kernel
private theorem e8 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 6 : Book.Event) := by decide +kernel
private theorem e9 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 7 : Book.Event) := by decide +kernel
private theorem e10 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 8 : Book.Event) := by decide +kernel
private theorem e11 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 9 : Book.Event) := by decide +kernel
private theorem e12 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 10 : Book.Event) := by decide +kernel
private theorem e13 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 11 : Book.Event) := by decide +kernel
private theorem e14 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 0 : Book.Event) := by decide +kernel
private theorem e15 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 1 : Book.Event) := by decide +kernel
private theorem e16 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 2 : Book.Event) := by decide +kernel
private theorem e17 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 3 : Book.Event) := by decide +kernel
private theorem e18 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 4 : Book.Event) := by decide +kernel
private theorem e19 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 5 : Book.Event) := by decide +kernel
private theorem e20 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 6 : Book.Event) := by decide +kernel
private theorem e21 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 7 : Book.Event) := by decide +kernel
private theorem e22 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 8 : Book.Event) := by decide +kernel
private theorem e23 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 9 : Book.Event) := by decide +kernel
private theorem e24 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 10 : Book.Event) := by decide +kernel
private theorem e25 : eventPass (416 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 11 : Book.Event) := by decide +kernel

price416stamp "signed_event_proofs"
attribute [local irreducible] eventPass

theorem events (e : Book.Event) : eventPass (416 : Group) (moments 416) (affine 416) e := by
  rw [gram_values,affine_values]
  cases e with
  | prime => exact e0
  | oldFive => exact e1
  | three i =>
    fin_cases i
    · exact e2
    · exact e3
    · exact e4
    · exact e5
    · exact e6
    · exact e7
    · exact e8
    · exact e9
    · exact e10
    · exact e11
    · exact e12
    · exact e13
  | newFive i =>
    fin_cases i
    · exact e14
    · exact e15
    · exact e16
    · exact e17
    · exact e18
    · exact e19
    · exact e20
    · exact e21
    · exact e22
    · exact e23
    · exact e24
    · exact e25

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G416
