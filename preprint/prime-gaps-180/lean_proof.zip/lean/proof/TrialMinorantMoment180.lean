import TrialSharpDense180
import TrialHigherOrdinary180
import TrialSupportedMoment180

/-! Pass the available distribution theorems for the literal minorants
to the signed sieve coefficients. The prime-factor cap applies only to
moduli that actually arise from compatible coefficient pairs. -/
noncomputable section
open scoped BigOperators Classical
open Filter PrimeGap186 PrimeGap182.TypeIII PrimeGap180.Signed PrimeGap182Audit
namespace PrimeGap180.Distribution

/-- Both forms of modulus set supply the carrier and size restrictions used
by the weighted average over divisor pairs. -/
inductive SieveBand where
  | unrestricted (θ : ℝ) (pos : 0 < θ) (half : θ < 1/2)
  | divisible (order : ℕ) (w d : ℝ) (level : 1/2+2*w < 0.54)

def SieveBand.moduli : SieveBand → ℝ → Finset ℕ → Finset ℕ
  | .unrestricted θ _ _ => ordinary θ
  | .divisible j w d _ => dense j (1/2+2*w) d

theorem SieveBand.support (b : SieveBand) {x : ℝ} (hx : 1 < x) (I : Finset ℕ)
    (pr : ∀ p ∈ I, p.Prime) {q : ℕ} (hq : q ∈ b.moduli x I) :
    q ∈ (∏ p ∈ I, p).divisors ∧ q ∈ Finset.Icc 1 ⌊x^(0.54:ℝ)⌋₊ := by
  have nz : (∏ p ∈ I, p) ≠ 0 := Finset.prod_ne_zero_iff.mpr fun p hp => (pr p hp).ne_zero
  have level {θ : ℝ} (lt : θ ≤ 0.54) (h : q ∈ Finset.Icc 1 ⌊x^θ⌋₊) :
      q ∈ Finset.Icc 1 ⌊x^(0.54:ℝ)⌋₊ := Finset.mem_Icc.mpr
    ⟨(Finset.mem_Icc.mp h).1,(Finset.mem_Icc.mp h).2.trans
      (Nat.floor_mono (Real.rpow_le_rpow_of_exponent_le hx.le lt))⟩
  cases b with
  | unrestricted θ _ half =>
    obtain ⟨h,d⟩ := Finset.mem_filter.mp hq
    exact ⟨Nat.mem_divisors.mpr ⟨d,nz⟩,level (by linarith : θ ≤ 0.54) h⟩
  | divisible j w d maxLevel =>
    obtain ⟨h,dv,_⟩ := Finset.mem_filter.mp hq
    exact ⟨Nat.mem_divisors.mpr ⟨dv,nz⟩,level maxLevel.le h⟩

/-- Each inhabitant contains an actual source theorem for this row and band. -/
structure ProvedBand (ch : ℝ → Literal.Channel) where
  toSieveBand : SieveBand
  source : ∀ h, RowBound ch toSieveBand.moduli h

def sharpUnrestricted {θ : ℝ} (h0 : 0 < θ) (half : θ < 1/2) : ProvedBand sharpChannel :=
  ⟨.unrestricted θ h0 half, sharp_ordinary h0 half⟩

def sharpDivisible {C : ℝ} {D p₀ : ℕ} (hC : 0 ≤ C)
    (fourier : LocalFourierHypothesis C D p₀) (rank4 : AllIncidenceRankFourBounds)
    {j : ℕ} {w d r τ σ β v : ℝ} (g : SharpGuards j w d r τ σ β v) :
    ProvedBand sharpChannel :=
  ⟨.divisible j w d (by linarith only [g.theta]),sharp_dense hC fourier rank4 g⟩

def higherUnrestricted {θ a c : ℝ} (h0 : 0 < θ) (half : θ < 1/2)
    (ha : a ≤ 417/1000) (hc : 4/25 ≤ c) :
    ProvedBand (fun x => .higher (x^a) (x^c)) :=
  ⟨.unrestricted θ h0 half,higher_ordinary h0 half ha hc⟩

theorem scheduled_minorant_moment {ι : Type*} [Fintype ι] [Nonempty ι] [DecidableEq ι]
    (ch : ℝ → Literal.Channel) (bands : ι → ProvedBand ch)
    (cuts : ∀ᶠ x : ℝ in atTop, Literal.admissible x (x^(0.1668:ℝ)) (ch x)) (h : Fin 39 → ℕ)
    (hi : Function.Injective h) (i : Fin 39)
    (A : ℝ) (hA : 0 < A) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      ∀ (D E : Finset (Fin 38 → ℕ)) (F G : (Fin 38 → ℕ) → ℝ) (W v : ℕ),
      0 < W →
      (∀ d ∈ D, Squarefree (∏ j, d j) ∧ Nat.Coprime (∏ j, d j) W) →
      (∀ e ∈ E, Squarefree (∏ j, e j) ∧ Nat.Coprime (∏ j, e j) W) →
      (∀ a b, h a ≠ h b → ∀ p : ℕ, p.Prime → p ∣ Nat.dist (h a) (h b) → p ∣ W) →
      Nat.Coprime (v+h i) W →
      ∀ (B₁ B₂ : ℝ), 0 ≤ B₁ → 0 ≤ B₂ →
      (∀ d ∈ D, |F d| ≤ B₁) → (∀ e ∈ E, |G e| ≤ B₂) →
      ∀ primes : Finset ℕ, (∀ p ∈ primes, p.Prime) →
      (∀ d ∈ D, ∀ e ∈ E, (∀ a b : Fin 38, a ≠ b → Nat.Coprime (d a) (e b)) →
        let q := W.lcm ((∏ k, d k).lcm (∏ k, e k))
        (∃ j, q ∈ (bands j).toSieveBand.moduli x primes) ∧
          ∀ p : ℕ, p.Prime → p ∣ q → (p:ℝ) ≤ x^(0.1668:ℝ)) →
      let f := Literal.value (ch x)
      |(∑ n ∈ window x, if Nat.ModEq W n v then f (n+h i) *
          (∑ d ∈ D, if ∀ j, d j ∣ n+h (i.succAbove j) then F d else 0) *
          (∑ e ∈ E, if ∀ j, e j ∣ n+h (i.succAbove j) then G e else 0) else 0) -
        ((∑ n ∈ window x, f (n+h i))/(W.totient:ℝ)) *
          (∑ d ∈ D, ∑ e ∈ E, if ∀ a b : Fin 38, a ≠ b → Nat.Coprime (d a) (e b)
            then F d*G e/(∏ j, ((Nat.lcm (d j) (e j)).totient:ℝ)) else 0)| ≤
        B₁*B₂*(C*x/(Real.log x)^A) := by
  classical
  obtain ⟨P,C,hC,moment⟩ := signed_moment_over_rows (ι := ι)
  have hAp : 0 < 2*A+(P:ℝ) := by positivity
  choose K hK src using fun j => (bands j).source (h i) (2*A+(P:ℝ)) hAp
  have sumpos : 0 < ∑ j, K j := Finset.sum_pos (fun j _ => hK j) Finset.univ_nonempty
  refine ⟨(∑ j, K j)+C,add_pos sumpos hC,?_⟩
  filter_upwards [cuts,eventually_all.mpr src, eventually_ge_atTop (Real.exp 1),
    eventually_ge_atTop (h i:ℝ)] with x cut hx hxe hxh
  intro D E F G W v hW hd he hc hv B₁ B₂ hb₁ hb₂ hf hg I hp gate f
  have hx1 := (Real.one_lt_exp_iff.mpr zero_lt_one).trans_le hxe
  let Q := fun j => (bands j).toSieveBand.moduli x I
  have bud (j) {q} (hq : q ∈ Q j) := (bands j).toSieveBand.support hx1 I hp hq
  have dy (n : ℕ) (hn : n ∈ window x) : x ≤ (n+h i:ℕ) ∧ ((n+h i:ℕ):ℝ) ≤ 3*x := by
    obtain ⟨hl,hu⟩ := Finset.mem_Icc.mp hn
    have l := Nat.ceil_le.mp hl
    have u := (Nat.cast_le.mpr hu).trans (Nat.floor_le (by linarith : 0 ≤ 2*x))
    push_cast
    exact ⟨by linarith [(Nat.cast_nonneg (h i) : (0:ℝ) ≤ h i)], by linarith⟩
  apply moment x hxe h hi i D E F G W v hW hd he hc hv (window x) f
    (fun n hn => ⟨Nat.cast_pos.mp ((zero_lt_one.trans hx1).trans_le (dy n hn).1), (dy n hn).2⟩)
    (fun n _ => Literal.bounded _ _) _ B₁ B₂ hb₁ hb₂ hf hg I hp Finset.univ Q
    (fun j _ _ hq => (bud j hq).1) (fun j _ _ hq => (bud j hq).2) _ A K sumpos _
  · intro d hD e hE compat n hn nonzero
    have small := Real.rpow_lt_rpow_of_exponent_lt hx1 (by norm_num : (0.1668:ℝ)<1)
    rw [Real.rpow_one] at small
    exact Literal.coprime_modulus (Real.rpow_nonneg (by linarith) _) small (dy n hn).1
      cut nonzero (gate d hD e hE compat).2
  · intro d hD e hE compat _ _
    obtain ⟨j,hj⟩ := (gate d hD e hE compat).1
    exact ⟨j,Finset.mem_univ _,hj⟩
  · intro a ha j _
    exact hx j I (Q j) a hp ha (fun _ hq => hq)

theorem sharp_cut {x : ℝ} (hx : 1 < x) :
    Literal.admissible x (x^(0.1668:ℝ)) (sharpChannel x) :=
  (Literal.cutoffs_of_exponents (a := 41361/100000) (c := 1) hx (by norm_num)
    (by norm_num : (0.1668:ℝ) ≤ 1)).1

#print axioms scheduled_minorant_moment
end PrimeGap180.Distribution
