import TrialSourcePlanBlocks180

namespace PrimeGap180.SourcePlanBlocks.Higher05

set_option maxRecDepth 131072
set_option maxHeartbeats 100000000

private theorem b0 : all (.higher 5) 0 = true := by decide +kernel
private theorem b1 : all (.higher 5) 1 = true := by decide +kernel
private theorem b2 : all (.higher 5) 2 = true := by decide +kernel
private theorem b3 : all (.higher 5) 3 = true := by decide +kernel
private theorem b4 : all (.higher 5) 4 = true := by decide +kernel
private theorem b5 : all (.higher 5) 5 = true := by decide +kernel
private theorem b6 : all (.higher 5) 6 = true := by decide +kernel
private theorem b7 : all (.higher 5) 7 = true := by decide +kernel
private theorem b8 : all (.higher 5) 8 = true := by decide +kernel
private theorem b9 : all (.higher 5) 9 = true := by decide +kernel
private theorem b10 : all (.higher 5) 10 = true := by decide +kernel
private theorem b11 : all (.higher 5) 11 = true := by decide +kernel
private theorem b12 : all (.higher 5) 12 = true := by decide +kernel
private theorem b13 : all (.higher 5) 13 = true := by decide +kernel
private theorem b14 : all (.higher 5) 14 = true := by decide +kernel
private theorem b15 : all (.higher 5) 15 = true := by decide +kernel
private theorem b16 : all (.higher 5) 16 = true := by decide +kernel
private theorem b17 : all (.higher 5) 17 = true := by decide +kernel
private theorem b18 : all (.higher 5) 18 = true := by decide +kernel
private theorem b19 : all (.higher 5) 19 = true := by decide +kernel
private theorem b20 : all (.higher 5) 20 = true := by decide +kernel
private theorem b21 : all (.higher 5) 21 = true := by decide +kernel
private theorem b22 : all (.higher 5) 22 = true := by decide +kernel
private theorem b23 : all (.higher 5) 23 = true := by decide +kernel
private theorem b24 : all (.higher 5) 24 = true := by decide +kernel
private theorem b25 : all (.higher 5) 25 = true := by decide +kernel
private theorem b26 : all (.higher 5) 26 = true := by decide +kernel
private theorem b27 : all (.higher 5) 27 = true := by decide +kernel
private theorem b28 : all (.higher 5) 28 = true := by decide +kernel
private theorem b29 : all (.higher 5) 29 = true := by decide +kernel
private theorem b30 : all (.higher 5) 30 = true := by decide +kernel
private theorem b31 : all (.higher 5) 31 = true := by decide +kernel
private theorem b32 : all (.higher 5) 32 = true := by decide +kernel
private theorem b33 : all (.higher 5) 33 = true := by decide +kernel
private theorem b34 : all (.higher 5) 34 = true := by decide +kernel
private theorem b35 : all (.higher 5) 35 = true := by decide +kernel
private theorem b36 : all (.higher 5) 36 = true := by decide +kernel
private theorem b37 : all (.higher 5) 37 = true := by decide +kernel
private theorem b38 : all (.higher 5) 38 = true := by decide +kernel

private theorem checked : ∀ j : Fin 39, all (.higher 5) j.val = true :=
  (Fin.cases b0
    (Fin.cases b1
    (Fin.cases b2
    (Fin.cases b3
    (Fin.cases b4
    (Fin.cases b5
    (Fin.cases b6
    (Fin.cases b7
    (Fin.cases b8
    (Fin.cases b9
    (Fin.cases b10
    (Fin.cases b11
    (Fin.cases b12
    (Fin.cases b13
    (Fin.cases b14
    (Fin.cases b15
    (Fin.cases b16
    (Fin.cases b17
    (Fin.cases b18
    (Fin.cases b19
    (Fin.cases b20
    (Fin.cases b21
    (Fin.cases b22
    (Fin.cases b23
    (Fin.cases b24
    (Fin.cases b25
    (Fin.cases b26
    (Fin.cases b27
    (Fin.cases b28
    (Fin.cases b29
    (Fin.cases b30
    (Fin.cases b31
    (Fin.cases b32
    (Fin.cases b33
    (Fin.cases b34
    (Fin.cases b35
    (Fin.cases b36
    (Fin.cases b37
    (Fin.cases b38
    (fun z => Fin.elim0 z))))))))))))))))))))))))))))))))))))))))

theorem every : Every (.higher 5) := of_blocks (.higher 5) 39 (by decide +kernel) checked

#print axioms every
end PrimeGap180.SourcePlanBlocks.Higher05
