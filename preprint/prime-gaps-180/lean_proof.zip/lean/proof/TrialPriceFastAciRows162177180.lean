import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G162
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 162

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G162

namespace PrimeGap180.PriceIsolatedGroup.G167
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 167

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G167

namespace PrimeGap180.PriceIsolatedGroup.G172
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 172

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G172

namespace PrimeGap180.PriceIsolatedGroup.G177
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 177

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G177
