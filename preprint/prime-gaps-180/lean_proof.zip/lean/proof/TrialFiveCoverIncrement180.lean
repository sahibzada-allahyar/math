import TrialCoverPacked180

/-! Check one complete cover table, one possible fourth bin per theorem. -/
namespace PrimeGap180.CoverEnumeration

set_option maxRecDepth 40000
set_option maxHeartbeats 100000000

private theorem increment35 : band true (column 2) 35 = true := by decide +kernel
private theorem increment36 : band true (column 2) 36 = true := by decide +kernel
private theorem increment37 : band true (column 2) 37 = true := by decide +kernel
private theorem increment38 : band true (column 2) 38 = true := by decide +kernel
private theorem increment39 : band true (column 2) 39 = true := by decide +kernel
private theorem increment40 : band true (column 2) 40 = true := by decide +kernel
private theorem increment41 : band true (column 2) 41 = true := by decide +kernel
private theorem increment42 : band true (column 2) 42 = true := by decide +kernel
private theorem increment43 : band true (column 2) 43 = true := by decide +kernel
private theorem increment44 : band true (column 2) 44 = true := by decide +kernel
private theorem increment45 : band true (column 2) 45 = true := by decide +kernel
private theorem increment46 : band true (column 2) 46 = true := by decide +kernel
private theorem increment47 : band true (column 2) 47 = true := by decide +kernel
private theorem increment48 : band true (column 2) 48 = true := by decide +kernel
private theorem increment49 : band true (column 2) 49 = true := by decide +kernel
private theorem increment50 : band true (column 2) 50 = true := by decide +kernel
private theorem increment51 : band true (column 2) 51 = true := by decide +kernel
private theorem increment52 : band true (column 2) 52 = true := by decide +kernel
private theorem increment53 : band true (column 2) 53 = true := by decide +kernel
private theorem increment54 : band true (column 2) 54 = true := by decide +kernel

theorem incrementBands : ∀ j : Fin 20, band true (column 2) (35+j.val) = true :=
  (Fin.cases increment35
    (Fin.cases increment36
    (Fin.cases increment37
    (Fin.cases increment38
    (Fin.cases increment39
    (Fin.cases increment40
    (Fin.cases increment41
    (Fin.cases increment42
    (Fin.cases increment43
    (Fin.cases increment44
    (Fin.cases increment45
    (Fin.cases increment46
    (Fin.cases increment47
    (Fin.cases increment48
    (Fin.cases increment49
    (Fin.cases increment50
    (Fin.cases increment51
    (Fin.cases increment52
    (Fin.cases increment53
    (Fin.cases increment54
    (fun x => Fin.elim0 x)))))))))))))))))))))

#print axioms incrementBands
end PrimeGap180.CoverEnumeration
