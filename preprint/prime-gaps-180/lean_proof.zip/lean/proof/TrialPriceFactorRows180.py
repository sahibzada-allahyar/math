"""Copy the 101 original signed-64 factor matrices in row-major archive order."""
import hashlib
import json
from pathlib import Path
import struct
import sys
from tempfile import TemporaryDirectory

from read_frozen_ledger import unpack

if not __debug__:
    raise RuntimeError("Certificate extraction requires Python assertions to be enabled")

EXPECTED = '103048b6552ee9b3e97b1834d10fc7b68a610e8c1526bd0d6f589a2c01028933'
GROUPS = 445

def write(target):
    digest = hashlib.sha256(b'PrimeGap180/factors/signed64/v1\0')
    count = 0
    with TemporaryDirectory() as tmp, target.open('wb') as output:
        folder = Path(tmp)
        unpack(folder)
        ranks = json.loads((folder/'meta.json').read_bytes())['shapes']
        if len(ranks) != 115:
            raise ValueError('incorrect matrix count')
        for m in range(14, 115):
            rank = ranks[m]
            if not 0 <= rank <= GROUPS:
                raise ValueError(f'invalid rank in matrix {m}')
            raw = bytes.fromhex((folder/str(m)).read_text(encoding='ascii'))
            if len(raw) != 8*GROUPS*rank:
                raise ValueError(f'wrong physical volume of matrix {m}')
            digest.update(struct.pack('<II',m,rank))
            digest.update(raw)
            output.write(struct.pack('<I',rank))
            output.write(raw)
            count += GROUPS*rank
    if digest.hexdigest() != EXPECTED or count != 9975565:
        raise ValueError('source row checksum or entry count changed')
    print(digest.hexdigest(), count)

if __name__ == '__main__':
    write(Path(sys.argv[1]))
