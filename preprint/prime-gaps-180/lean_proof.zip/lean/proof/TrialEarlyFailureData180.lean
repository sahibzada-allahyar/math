import TrialStructuralRuns180
import TrialMeshKeySemantics180

/-! The localized workers restrict the signed spline to full native indices
at least 102994 and the failing omission to indices at most 27970. -/
noncomputable section
open scoped Classical BigOperators
open PrimeGap186 PrimeGap180.Sector PrimeGap180.FrozenProfile PrimeGap180.FrozenData
open PrimeGap180.GateDeletion PrimeGap180.FrozenData.FiniteInput PrimeGap180.RunAlignment
namespace PrimeGap180.EarlyFailure
open private code_cons from TrialDebitRunData180
open private physical_sum from TrialStructuralGate180
open private key from TrialFrozenData180

abbrev stop := DebitRunData.stop
abbrev lab := DebitRunData.lab

def early (l : ℕ) : List (Array ℕ) → Bool
  | []=>true
  | r::rs=>(decide (102994≤l) || decide (T.group (lab r)=445)) && early (stop r-1) rs

def earlyRows := (List.finRange 44).all (fun c=>early 0 (debitSectorRows c))
def tag (a : Array ℕ) : Span :=
  ⟨field a 4,field a 4+(field a 3-field a 2),field a 0,0⟩
def spans := (List.finRange 44).flatMap (fun c=>(owners c).toList.map tag)
def test (s : Span) (r : Array ℕ) := decide (s.cap=445 → 20000000≤field r 3)
def endAt (r : Array ℕ) := field r 0


structure Checks : Prop where
  runs : earlyRows=true
  order : ordered 0 spans=true
  tags : aligned endAt test 8192 spans gates.toList=true
  parents : ∀ e : Active,parentUpperNat e≤1800000

end PrimeGap180.EarlyFailure
