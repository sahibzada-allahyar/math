import TrialPrimeBandPartition180
import TrialRetainedPrimeBoxes180

noncomputable section
open scoped BigOperators Topology
open Filter PrimeGap186 PrimeGap182Audit
open PrimeGap180.Distribution
namespace PrimeGap180.Retained

theorem wide_prime_boxes {j : ℕ} {a I cut w v d σb σ : ℝ}
    (g : CoefficientGuards j a I cut w v d σb σ)
    (block : Averaged.SelectedBlockEstimate) (rank4 : AllIncidenceRankFourBounds)
    (zlo : 23/100 ≤ 1-a-I) (ahi : a ≤ 42/100) (level : 1/2+2*w ≤ 53/100)
    (A : ℝ) (hA : 0 < A) :
    ∃ K : ℝ, 0 < K ∧ ∀ᶠ x : ℝ in atTop, ∀ (L U : Fin 3 → ℕ),
      (∀ i, x^(1-a-I) ≤ (L i:ℝ)) → (∀ i, (U i:ℝ) ≤ x^a) → (U 0:ℝ) ≤ x^cut →
      ∀ (P Q : Finset ℕ) (b : ℕ), (∀ p ∈ P, p.Prime) → b.Coprime (∏ p ∈ P, p) →
        Q ⊆ dense j (1/2+2*w) d x P →
        ∑ q ∈ Q, ‖fullDiscrepancy ((primeIntervalBoxAlgebra (fun i => (L i:ℝ))
          (fun i => (U i:ℝ)) Finset.univ).coeff.filter (fun n => n ∈ Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊))
          q b‖ ≤ K*x/(Real.log x)^A := by
  classical
  obtain ⟨K,X,k,_,raw⟩ := closed_prime_boxes g block rank4 zlo ahi level (A+3) (by linarith)
  let C := 1+(Real.log 2)⁻¹
  have cp : 0 < C := by dsimp [C]; positivity
  refine ⟨C^3*K,by positivity,?_⟩
  filter_upwards [eventually_ge_atTop X,eventually_ge_atTop (Real.exp 1)] with x hx hx'
  intro L U low high cap P Q b primes cop sub
  have xp := (Real.exp_pos _).trans_le hx'
  have x1 := (Real.one_le_exp zero_le_one).trans hx'
  have lg : 1 ≤ Real.log x := (Real.le_log_iff_exp_le xp).mpr hx'
  have lp := zero_lt_one.trans_le lg
  let B := Fintype.piFinset (fun i => bands (L i) (U i))
  let F := fun z : Fin 3 → ℕ => ((primeIntervalBoxAlgebra (fun i => (left (L i) (z i):ℝ))
    (fun i => (right (U i) (z i):ℝ)) Finset.univ).coeff.filter
      (fun n => n ∈ Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊))
  have each (z : Fin 3 → ℕ) (hz : z ∈ B) :
      ∑ q ∈ Q, ‖fullDiscrepancy (F z) q b‖ ≤ K*x/(Real.log x)^(A+3) := by
    have sz (i : Fin 3) := band_size (Fintype.mem_piFinset.mp hz i)
    apply (Finset.sum_le_sum_of_subset_of_nonneg sub (fun q _ _ => norm_nonneg _)).trans
    apply raw x hx _ _
    · exact fun i => (low i).trans (Nat.cast_le.mpr (sz i).1)
    · intro i
      exact ⟨Nat.cast_le.mpr (sz i).2.1,by exact_mod_cast (sz i).2.2.1⟩
    · exact fun i => (Nat.cast_le.mpr (sz i).2.2.2).trans (high i)
    · exact (Nat.cast_le.mpr (sz 0).2.2.2).trans cap
    · exact primes
    · exact cop
  have card : (B.card:ℝ) ≤ (C*Real.log x)^3 := by
    calc
      _ = ∏ i, ((bands (L i) (U i)).card:ℝ) := by dsimp only [B]; rw [Fintype.card_piFinset,Nat.cast_prod]
      _ ≤ ∏ _ : Fin 3, C*Real.log x := Finset.prod_le_prod (fun _ _ => Nat.cast_nonneg _)
        (fun i _ => band_count lg ((high i).trans (Real.rpow_le_self_of_one_le x1 (by linarith only [ahi]))))
      _ = _ := by simp
  rw [band_partition,MonoidAlgebra.coeff_sum,Finsupp.filter_sum]
  simp only [fullDiscrepancy_finset_sum]
  calc
    _ ≤ ∑ q ∈ Q, ∑ z ∈ B, ‖fullDiscrepancy (F z) q b‖ :=
      Finset.sum_le_sum fun q _ => norm_sum_le _ _
    _ = ∑ z ∈ B, ∑ q ∈ Q, ‖fullDiscrepancy (F z) q b‖ := Finset.sum_comm
    _ ≤ ∑ _z ∈ B, K*x/(Real.log x)^(A+3) := Finset.sum_le_sum each
    _ ≤ (C*Real.log x)^3*(K*x/(Real.log x)^(A+3)) := by
      rw [Finset.sum_const,nsmul_eq_mul]
      exact mul_le_mul_of_nonneg_right card (by positivity)
    _ = _ := by
      rw [Real.rpow_add lp,show (Real.log x)^(3:ℝ) = (Real.log x)^3 by norm_cast]
      field_simp

#print axioms wide_prime_boxes
end PrimeGap180.Retained
