import Mathlib.MeasureTheory.Constructions.Pi
import Mathlib.Topology.Order.IsLUB
import Mathlib.Tactic

/-! Marginal CDF bounds tensorize on every measurable downward closed event.
No random quantile or choice of a conditional coupling enters the probability
of the first erased-coordinate event. -/
noncomputable section
open scoped Classical ENNReal BigOperators
open Filter Set MeasureTheory
namespace PrimeGap180.FirstEdgeProduct

private theorem open_ray (P Q : Measure ℝ) (closed : ∀ t,P (Iic t)≤Q (Iic t)) (t : ℝ) :
    P (Iio t)≤Q (Iio t) := by
  obtain ⟨u,mono,under,lim⟩:=dense_univ.exists_seq_strictMono_tendsto t
  have sets : Monotone (fun n=>Iic (u n)) := fun _ _ h=>Iic_subset_Iic.mpr (mono.monotone h)
  have eq:=iUnion_Iic_eq_Iio_of_lt_of_tendsto (fun n=>(under n).1) lim
  rw [←eq,sets.measure_iUnion,sets.measure_iUnion]
  exact iSup_mono fun n=>closed (u n)

theorem lower (P Q : Measure ℝ) (mass : P univ≤Q univ) (closed : ∀ t,P (Iic t)≤Q (Iic t))
    {s : Set ℝ} (down : IsLowerSet s) : P s≤Q s := by
  by_cases empty : s=∅
  · simp [empty]
  have ne:=Set.nonempty_iff_ne_empty.mpr empty
  by_cases bounded : BddAbove s
  · by_cases contains : sSup s∈s
    · have eq : s=Iic (sSup s) := Set.ext fun t=>⟨fun h=>le_csSup bounded h,fun h=>down h contains⟩
      rw [eq]; exact closed _
    · have eq : s=Iio (sSup s) := by
        ext t
        constructor
        · intro ht
          exact lt_of_le_of_ne (le_csSup bounded ht) (fun eq=>contains (eq ▸ ht))
        · intro ht
          obtain ⟨w,hw,tw⟩:=(lt_csSup_iff bounded ne).mp ht
          exact down tw.le hw
      rw [eq]; exact open_ray P Q closed _
  · have eq : s=univ := eq_univ_of_forall fun t=>by
        obtain ⟨w,hw,tw⟩:=not_bddAbove_iff.mp bounded t
        exact down tw.le hw
    rwa [eq]

private theorem slice {d : ℕ} (P : Fin (d+1)→Measure ℝ) [∀ j,IsFiniteMeasure (P j)]
    (i : Fin (d+1)) (s : Set (Fin (d+1)→ℝ)) (ms : MeasurableSet s) :
    Measure.pi P s = ∫⁻ y,P i {t | i.insertNth (α:=fun _=>ℝ) t y∈s}
      ∂(Measure.pi fun j : Fin d=>P (i.succAbove j)) := by
  let E:=MeasurableEquiv.piFinSuccAbove (fun _ : Fin (d+1)=>ℝ) i
  have mp:=measurePreserving_piFinSuccAbove P i
  rw [←mp.symm.measure_preimage ms.nullMeasurableSet,Measure.prod_apply_symm (E.symm.measurable ms)]
  rfl

private theorem swap {d : ℕ} (P Q : Fin (d+1)→Measure ℝ) [∀ i,IsFiniteMeasure (P i)]
    [∀ i,IsFiniteMeasure (Q i)] (i : Fin (d+1)) (same : ∀ j : Fin d,P (i.succAbove j)=Q (i.succAbove j))
    (mass : P i univ≤Q i univ) (cmp : ∀ t,P i (Iic t)≤Q i (Iic t))
    (s : Set (Fin (d+1)→ℝ)) (ms : MeasurableSet s) (down : IsLowerSet s) :
    Measure.pi P s≤Measure.pi Q s := by
  rw [slice P i s ms,slice Q i s ms,show (fun j=>P (i.succAbove j))=(fun j=>Q (i.succAbove j)) from funext same]
  apply lintegral_mono
  intro y
  apply lower _ _ mass cmp
  intro t u tu hu
  apply down _ hu
  intro j
  apply i.forall_iff_succAbove.mpr _ j
  simp [tu]

theorem tensor {d : ℕ} (P Q : Fin (d+1)→Measure ℝ) [∀ i, IsFiniteMeasure (P i)]
    [∀ i, IsFiniteMeasure (Q i)] (mass : ∀ i,P i univ≤Q i univ)
    (cmp : ∀ i t,P i (Iic t)≤Q i (Iic t))
    (s : Set (Fin (d+1)→ℝ)) (ms : MeasurableSet s) (down : IsLowerSet s) :
    Measure.pi P s ≤ Measure.pi Q s := by
  let M:=fun (k : ℕ) (i : Fin (d+1))=>if i.val<k then Q i else P i
  have fin (k : ℕ) (i : Fin (d+1)) : IsFiniteMeasure (M k i) := by
    dsimp [M]; split <;> infer_instance
  have step (k : ℕ) (hk : k<d+1) : Measure.pi (M k) s≤Measure.pi (M (k+1)) s := by
    let i : Fin (d+1):=⟨k,hk⟩
    have mi : M k i=P i := by simp [M,i]
    have qi : M (k+1) i=Q i := by simp [M,i]
    apply swap _ _ i _ (by rw [mi,qi];exact mass i) (by rw [mi,qi];exact cmp i) _ ms down
    intro j
    have neq : (i.succAbove j).val≠k := fun h=>(Fin.succAbove_ne i j) (Fin.ext h)
    simp only [M]
    congr 1
    exact propext (by omega)
  have h (k : ℕ) (hk : k≤d+1) : Measure.pi (M 0) s≤Measure.pi (M k) s := by
    induction k with
    | zero=>exact le_rfl
    | succ k ih=>exact (ih (by omega)).trans (step k (by omega))
  have ini : M 0=P := funext (fun i=>by simp [M])
  have fin : M (d+1)=Q := funext (fun i=>by simp [M,i.isLt])
  simpa only [ini,fin] using h (d+1) le_rfl

/-- The erased-coordinate event is downward closed even when the two
endpoints can be removed. This is the event to tensorize before partitioning
the maximum, because the difference of two lower sets need not be lower. -/
def erased (N : ℕ) (B : ℝ) : Set (Fin (N+1)→ℝ) := {w | ∃ i : Fin (N+1), ∑ j,w (i.succAbove j)<B}

theorem erased_probability (N : ℕ) (P Q : Fin (N+1)→Measure ℝ) [∀ i, IsFiniteMeasure (P i)]
    [∀ i,IsFiniteMeasure (Q i)] (mass : ∀ i,P i univ≤Q i univ)
    (cmp : ∀ i t,P i (Iic t)≤Q i (Iic t)) (B : ℝ) :
    Measure.pi P (erased N B) ≤ Measure.pi Q (erased N B) := by
  apply tensor P Q mass cmp
  · change MeasurableSet {w : Fin (N+1)→ℝ | ∃ i : Fin (N+1),∑ j,w (i.succAbove j)<B}
    simp only [Set.ofPred_exists]
    exact MeasurableSet.iUnion fun i=>measurableSet_lt (by fun_prop) measurable_const
  · rintro v w vw ⟨i,h⟩
    exact ⟨i,lt_of_le_of_lt (Finset.sum_le_sum (fun j _=>vw (i.succAbove j))) h⟩

#print axioms erased_probability
end PrimeGap180.FirstEdgeProduct
