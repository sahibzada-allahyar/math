import TrialLaterLowFixedGrid180
namespace PrimeGap180.LaterLowFixed
set_option maxHeartbeats 0
set_option maxRecDepth 131072

theorem scalar_row_04 : bookU 10000 8 0 = 8237619048529054255843 ∧ bookU 10000 8 2320 = 771236886998925253994 ∧
    rawQ 20000 8 2320 8237619048529054255843 771236886998925253994 * 100^39 / (94.17312:ℚ) ≤ 1156055/10^18 := by decide +kernel

#print axioms scalar_row_04
end PrimeGap180.LaterLowFixed
