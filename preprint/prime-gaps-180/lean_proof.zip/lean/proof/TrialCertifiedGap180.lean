import TrialRobustTransfer180
import TrialFrozenKeyMesh180
import TrialResolvedHalf180
import TrialPositiveMass180
import TrialFrozenFiveCovers180
import TrialDebitReceiver180
import TrialSourceCoverageCertificate180

/-! Diameter-180 endpoint with finite mesh, resolved sectors, five-prime covers,
source coverage, positive mass and the removed-spline Schur estimate filled by kernel proofs. -/
noncomputable section
open PrimeGap186 PrimeGap180.NumericalAccount
namespace PrimeGap180

theorem gap_of_remaining_inputs (input : SourceSchedule.Inputs)
    (prices : FrozenLedger.Endpoints)
    (resource : ∀ u : Resources.Resource, u ≠ .prime → ∀ s,
      (Book.resourceRow u).price s ≤ FrozenLedger.ledger.resourceKernel u s)
    (event : ∀ e : PriceEvents.Event, e ≠ .prime → ∀ s,
      (Book.eventRow e).price s ≤ FrozenLedger.ledger.eventKernel e s)
    (densities : Terminal.DensityIntegrals)
    (uncut : 1.00119224 * mass Restoration.original ≤ numerator Restoration.original)
    (removed : restoredLoss ≤ (0.000071406420 + 0.001035091858) * mass Restoration.original)
    (uncutDebit : PhysicalDebit.debit Restoration.original ≤ 0.000023399 * mass Restoration.original)
    (removedMass : mass Restoration.deleted ≤ 0.000160674 * mass Restoration.original) :
    primeGapLiminf ≤ (180 : EReal) :=
  RobustTransfer.gap input prices ⟨FrozenFiveCovers.checked, resource, event⟩ densities
    FrozenMesh.checked SourceCoverageCertificate.checked ResolvedCertificate.checked
    ⟨PositiveMass.positive, uncut, removed, DebitRunData.restored_from_uncut uncutDebit removedMass⟩

#print axioms gap_of_remaining_inputs
end PrimeGap180
