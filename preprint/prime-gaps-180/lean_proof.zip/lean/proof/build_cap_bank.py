"""Generate the complete factor bank of one changing cap and its `CapMass.MassBank` module.

`generate_bank(generated, cap)` writes `TrialCap{cc}MassBank180`, which packs
the 21 endpoint-pair rows and the 53 weighted angular rows of cap `cc` into a
`CapMass.MassBank cc` (the cap-36 bank is `Cap36MassBank.bank`, built from the
compiled `CheckedEnds36`/`CapAngularComplete` rows). `generate_all` runs every
bank generator for the cap into the directory layout that
`build_conservative_proof.py` uses (`<build>/generated/cap{cc}_<kind>`).

`--dry-run` writes the Lean text of every module without computing any word,
then checks that every import resolves to a generated or tracked module and
prints the module census of the bank closure.
"""
import argparse
from collections import Counter
from pathlib import Path
import re

from cap_bank_names import CHANGING, LEGACY, Names

HERE = Path(__file__).resolve().parent
END_LABELS = ("0000", "0001", "0002", "0011", "0012", "0022", "0101", "0102", "0111", "0112", "0122",
              "0202", "0211", "0212", "0222", "1111", "1112", "1122", "1212", "1222", "2222")


def bank_text(names):
    c = names.cap
    ends = [names.ns(f"EndPair{label}") for label in END_LABELS]
    angs = [names.ns(f"Weighted{s:02d}") for s in range(53)]
    lines = ["import TrialCapMassBank180", "import TrialCapWordMaskList180",
             *(f"import Trial{n}180" for n in ends), *(f"import Trial{n}180" for n in angs), "",
             f"/-! The complete factor bank of cap {c}: 21 endpoint-pair rows, 53 angular rows",
             "and one bitwise union that narrows every angular word to 252-bit lanes. -/",
             "noncomputable section", f"namespace PrimeGap180.{names.ns('Bank')}",
             "open CapMass MassGroupIndex CapAngularCatalog CapWordConvolution CapWordMaskList",
             "set_option maxRecDepth 30000", "set_option maxHeartbeats 0",
             "set_option exponentiation.threshold 100000000", "",
             f"def ends : (i : Fin 21) → EndEntry {c} (ep i) :="]
    lines += [f"  Fin.cases ⟨{n}.lo,{n}.hi,{n}.actual,{n}.narrow⟩ <|" for n in ends]
    lines += ["  fun i => False.elim (Nat.not_lt_zero i.val i.isLt)", "",
              f"def angs : (i : Fin 53) → AngEntry {c} (spec i) :="]
    lines += [f"  Fin.cases ⟨{n}.lo,{n}.hi,{n}.actual,{n}.masks⟩ <|" for n in angs]
    lines += ["  fun i => False.elim (Nat.not_lt_zero i.val i.isLt)", "",
              "def words := (List.finRange 53).flatMap fun i => [(angs i).lo,(angs i).hi]",
              "theorem united : mask 640 252 130965 (union words)=true := by decide +kernel", "",
              "theorem narrow (i : Fin 53) : mask 640 252 130965 (angs i).lo=true ∧ mask 640 252 130965 (angs i).hi=true := by",
              "  have h : i ∈ List.finRange 53 := by simp", "  constructor",
              "  · apply member_mask united", "    exact List.mem_flatMap.mpr ⟨i,h,by simp⟩",
              "  · apply member_mask united", "    exact List.mem_flatMap.mpr ⟨i,h,by simp⟩", "",
              f"def bank : MassBank {c} := ⟨ends,angs,narrow⟩", "",
              "#print axioms bank", f"end PrimeGap180.{names.ns('Bank')}", ""]
    return "\n".join(lines)


def generate_bank(generated, cap):
    names = Names(cap)
    if names.legacy:
        raise ValueError("The cap-36 bank is TrialCap36MassBank180 (tracked)")
    destination = generated / names.directory("bank")
    destination.mkdir(parents=True, exist_ok=True)
    name = names.module("MassBank")
    path = destination / (name + ".lean")
    text = bank_text(names)
    if not path.is_file() or path.read_text() != text:
        path.write_text(text)
    return {name: path}


def generate_all(generated, cap, dry_run=False):
    """Every bank module of one cap (the dispatcher builds the same files lazily, kind by kind)."""
    import build_cap_end_pairs, build_cap_end_site, build_cap_gram_nodes, build_cap_raw_atoms
    import build_cap_square, build_cap_unmarked, build_cap_weighted
    names = Names(cap)
    out = {}
    out.update(build_cap_square.generate(generated / names.directory("square"), cap, dry_run))
    out.update(build_cap_unmarked.generate(generated / names.directory("powers"), cap, dry_run))
    for e in range(2, 13):
        out.update(build_cap_raw_atoms.generate(generated / names.directory("raw_atoms"), e, cap, dry_run))
    for pair in sorted(build_cap_end_site.PAIR_CODES):
        out.update(build_cap_end_site.generate(generated / names.directory("end_sites"), pair, cap, dry_run))
    for label in END_LABELS:
        out.update(build_cap_end_pairs.generate(generated / names.directory("end_pairs"), label, cap, dry_run))
    out.update(build_cap_gram_nodes.generate(generated / names.directory("gram"), cap=cap, dry_run=dry_run))
    out.update(build_cap_weighted.generate(generated / names.directory("gram"), cap=cap, dry_run=dry_run))
    if not names.legacy:
        out.update(generate_bank(generated, cap))
    return out


def imports(path):
    for line in path.read_text().splitlines():
        m = re.match(r"^import\s+(\S+)", line)
        if m:
            yield m[1]


def closure(modules, root):
    """Generated modules reachable from `root`; every other import must be a tracked module."""
    tracked = {p.stem for p in HERE.glob("*.lean")}
    seen, missing, todo = set(), set(), [root]
    while todo:
        n = todo.pop()
        if n in seen:
            continue
        seen.add(n)
        for im in imports(modules[n]):
            if im in modules:
                todo.append(im)
            elif im not in tracked and im.startswith("Trial") and not re.fullmatch(
                    r"TrialSiteShard\d{3}180|TrialHistoricalSiteGrid180", im):
                missing.add(im)
    return seen, missing


KINDS = [("square numbers", r"SquareNumbers"), ("aligned blocks", r"AlignedBlock\d\d"),
         ("aligned grid", r"AlignedGrid"), ("unmarked rules", r"Unmarked"), ("powers", r"Power\d\d"),
         ("raw atom data", r"RawAtomData\d\d"), ("raw atoms", r"RawAtom\d\d"),
         ("end site data", r"EndSiteData\d\d"), ("end sites", r"EndSite\d\d"), ("end pairs", r"EndPair\d{4}"),
         ("Gram nodes", r"Gram(?:Base|Group|Distinct)V[\dX]+"), ("weighted rows", r"Weighted\d\d"),
         ("bank", r"MassBank")]


def census(names, reached):
    counts = Counter()
    for n in reached:
        body = n.removeprefix(f"TrialCap{names.tag}").removesuffix("180")
        kind = next((k for k, pattern in KINDS if re.fullmatch(pattern, body)), "other")
        counts[kind] += 1
    return counts


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--cap", type=int, required=True, choices=[c for c in CHANGING if c != LEGACY])
    p.add_argument("--generated", type=Path, required=True, help="<build>/generated, or a scratch directory")
    p.add_argument("--dry-run", action="store_true", help="write Lean text without words")
    a = p.parse_args()
    names = Names(a.cap)
    modules = generate_all(a.generated, a.cap, a.dry_run)
    root = names.module("MassBank")
    reached, missing = closure(modules, root)
    if missing:
        raise SystemExit(f"Unresolved imports: {sorted(missing)}")
    counts = census(names, reached)
    print(f"Cap {a.cap}: {len(modules)} modules written, {len(reached)} in the closure of {root}")
    for kind, _ in KINDS:
        print(f"  {kind:16s} {counts[kind]:4d}")
    if counts["other"]:
        print(f"  {'other':16s} {counts['other']:4d}")
    unused = sorted(set(modules) - reached)
    print(f"Written but not imported by the bank: {len(unused)} ({', '.join(unused[:6])}{' …' if len(unused) > 6 else ''})")


if __name__ == "__main__":
    main()
