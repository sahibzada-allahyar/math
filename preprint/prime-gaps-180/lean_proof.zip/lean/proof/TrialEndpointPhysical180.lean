import TrialEndpointFibre180
import TrialEndpointMoment180
import TrialRadialLaw180
import TrialMarkedSector180

/-! The two endpoint coordinates of the physical 39-site weight, its
37-site retained kernel, and the negligible mass of illegal shared primes. -/
noncomputable section
open scoped BigOperators Classical Topology ENNReal
open MeasureTheory Filter PrimeGap186 PrimeGap180.Sector
namespace PrimeGap180.EndpointPhysical

abbrev wide : ℝ := 49995/100000
abbrev ledger : ℝ := 4999/10000
abbrev radiusCap : ℝ := 1399373467/5000000000

/-- Endpoint zero is the first coordinate. Endpoint 182 is the last.
All 37 interiors keep their original order. -/
def join {E : Type*} (r : Fin 37 → E) (a b : E) : Fin 39 → E := Fin.cons a (Fin.snoc r b)

theorem join_preserving {E : Type*} [MeasurableSpace E] (μ : Measure E) [IsFiniteMeasure μ] :
    MeasurePreserving (fun t : (Fin 37 → E) × E × E => join t.1 t.2.1 t.2.2)
      ((Measure.pi fun _ : Fin 37 => μ).prod (μ.prod μ)) (Measure.pi fun _ : Fin 39 => μ) := by
  let η := Measure.pi fun _ : Fin 37 => μ
  have swap := (MeasurePreserving.id η).prod (Measure.measurePreserving_swap (μ := μ) (ν := μ))
  have assoc := (measurePreserving_prodAssoc η μ μ).symm
  have addLast := (PrimeGap186.measurePreserving_insertNth μ (Fin.last 37)).prod (MeasurePreserving.id μ)
  have addFirst := PrimeGap186.measurePreserving_insertNth μ (0 : Fin 39)
  convert addFirst.comp (addLast.comp (assoc.comp swap)) using 1
  funext t
  rcases t with ⟨r,a,b⟩
  change Fin.cons a (Fin.snoc r b) = (0:Fin 39).insertNth (α := fun _ => E) a ((Fin.last 37).insertNth (α := fun _ => E) b r)
  rw [Fin.insertNth_last',Fin.insertNth_zero']

def pairPrice {m : ℕ} (r : Fin 37 → Band m) : ℝ :=
  2*rho^2/(ledger-min radiusCap (max 0 (rho*∑ j, ∑ k, r j k)))^2

theorem price_continuous {m : ℕ} : Continuous (@pairPrice m) := by
  unfold pairPrice
  apply Continuous.div continuous_const (by fun_prop)
  intro t
  apply pow_ne_zero
  have h := min_le_left radiusCap (max 0 (rho*∑ j, ∑ k, t j k))
  exact (sub_pos.mpr (h.trans_lt (by norm_num [radiusCap,ledger]))).ne'

theorem price_bounded {m : ℕ} : Bornology.IsBounded (Set.range (@pairPrice m)) := by
  apply isBounded_iff_forall_norm_le.mpr
  refine ⟨2*rho^2/(ledger-radiusCap)^2, ?_⟩
  rintro _ ⟨t,rfl⟩
  dsimp only [pairPrice]
  rw [Real.norm_eq_abs,abs_of_nonneg (by positivity)]
  apply div_le_div_of_nonneg_left (by positivity) (by norm_num [ledger,radiusCap])
  apply pow_le_pow_left₀ (by norm_num [ledger,radiusCap])
  exact sub_le_sub_left (min_le_left _ _) _

/-- The sampled signed erasure in the double-prime numerator has 41
harmonic copies when squared. The same 37 interiors feed both copies. -/
theorem physical_pair_limit {m : ℕ} (H : Finset ℕ) (a : Fin (m+2) → ℝ)
    (ha : StrictMono a) (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (F : Profile 39 m) (mf : Measurable F) (bf : Bornology.IsBounded (Set.range F))
    (cf : ∀ᵐ y ∂Measure.pi (fun _ : Fin 39 => bandLaw a), ContinuousAt F y) :
    let Q := fun x => (carrier H x).divisors
    Tendsto (fun x => ((norm H x)^41)⁻¹ * EndpointMoment.cube (Q x) (fun r =>
      pairPrice (fun j => stats a x (r j))*(EndpointMoment.twice (Q x)
        (fun rr l h => F (join (fun j => stats a x (rr j)) (stats a x l) (stats a x h))) r)^2))
      atTop (𝓝 (∫ r, pairPrice r*(∫ l, ∫ h, F (join r l h) ∂bandLaw a ∂bandLaw a)^2
        ∂Measure.pi fun _ : Fin 37 => bandLaw a)) := by
  let := bandLaw_finite a
  have μ := join_preserving (bandLaw a)
  have cont : Continuous (fun t : (Fin 37 → Band m) × Band m × Band m => join t.1 t.2.1 t.2.2) := by
    dsimp [join]; fun_prop
  have cf' := μ.quasiMeasurePreserving.ae cf
  apply EndpointMoment.signed_pair_limit_ae H (by norm_num [rho]) (by norm_num [cap,physicalCap,rho])
    a ha first last pairPrice (fun r l h => F (join r l h)) price_continuous.measurable
    (mf.comp cont.measurable) ⟨Eventually.of_forall fun _ => price_continuous.continuousAt,?_⟩
    price_bounded (bf.subset (Set.range_comp_subset_range _ _))
  filter_upwards [cf'] with t ht
  change ContinuousAt F (join t.1 t.2.1 t.2.2) at ht
  exact ContinuousAt.comp (f := fun z : (Fin 37 → Band m) × Band m × Band m => join z.1 z.2.1 z.2.2) ht cont.continuousAt

def widePrimes (H : Finset ℕ) (x : ℝ) :=
  fragmentPrimes (presievingModulus H x) (scale x) (wide/rho)

def wideCube (H : Finset ℕ) (x : ℝ) :=
  Fintype.piFinset (fun _ : Fin 39 => (∏ p ∈ widePrimes H x, p).divisors)

def badCube (H : Finset ℕ) (x : ℝ) :=
  (wideCube H x).filter fun r => ¬ Squarefree (∏ j, r j)

/-- All 39 variables range over the wider prime carrier here. Any illegal
pair inside the size cutoff contributes at most this full cube tail. -/
theorem bad_cube_mass (H : Finset ℕ) :
    Tendsto (fun x => (norm H x^39)⁻¹*∑ r ∈ badCube H x, Endpoint.harmonic r) atTop (𝓝 0) := by
  let κ : ℝ := wide/rho
  let a : Fin 2 → ℝ := ![0,κ]
  have hp : 0 < κ := by norm_num [κ,wide,rho]
  have ha : StrictMono a := by
    intro i j hij
    fin_cases i <;> fin_cases j <;> simp_all [a]
  let K : (Fin 39 → Band 0) → ℝ := fun _ => 1
  have bf : Bornology.IsBounded (Set.range K) := by simp [K]
  have good := tendsto_restricted_harmonic_pi_sum (m := 0) (n := 39)
    H rho κ a (by norm_num [rho]) hp ha (by rfl) (by rfl)
    (fun r => Squarefree (∏ j, r j))
    (fun S hs r => exists_shared_prime_of_not_squarefree_prod S hs r) K measurable_const bf
    (Eventually.of_forall fun _ => continuousAt_const)
  have full := tendsto_harmonic_pi_sum H rho κ a (by norm_num [rho]) hp ha (by rfl) (by rfl)
    39 K measurable_const bf (Eventually.of_forall fun _ => continuousAt_const)
  have diff := full.sub good
  rw [sub_self] at diff
  apply diff.congr
  intro x
  dsimp only [K]
  rw [←mul_sub,←Finset.sum_sub_distrib]
  congr 1
  unfold badCube wideCube
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro r _
  by_cases h : Squarefree (∏ j, r j) <;> simp [h,Endpoint.harmonic,one_div,Finset.prod_inv_distrib]

/-- Each of the 39 coordinates is separately squarefree and coprime to the
presieve in the larger fibre. Its total product still satisfies the cutoff. -/
def unrestricted (W L : ℕ) :=
  (Fintype.piFinset fun _ : Fin 39 => Finset.Icc 1 L).filter fun r =>
    (∀ j, Squarefree (r j) ∧ (r j).Coprime W) ∧ (∏ j, r j) ≤ L

theorem legal_sub (W L : ℕ) : Endpoint.legalRoots (Fin 39) W L ⊆ unrestricted W L := by
  intro r hr
  obtain ⟨sq,cop,cut⟩ := (Endpoint.mem_legalRoots r).mp hr
  exact Finset.mem_filter.mpr ⟨(Finset.mem_filter.mp hr).1,
    fun j => ⟨sq.squarefree_of_dvd (Finset.dvd_prod_of_mem r (Finset.mem_univ j)),
      cop.coprime_dvd_left (Finset.dvd_prod_of_mem r (Finset.mem_univ j))⟩,cut⟩

theorem missing_subset (H : Finset ℕ) {x : ℝ} (hx : 1 < x) :
    unrestricted (presievingModulus H x) ⌊x^wide⌋₊ \ Endpoint.legalRoots (Fin 39)
      (presievingModulus H x) ⌊x^wide⌋₊ ⊆ badCube H x := by
  intro r hr
  obtain ⟨inU,notT⟩ := Finset.mem_sdiff.mp hr
  obtain ⟨coord,each,cut⟩ := Finset.mem_filter.mp inU
  have pwr : (scale x)^(wide/rho) = x^wide := by
    rw [scale,← Real.rpow_mul (zero_lt_one.trans hx).le]
    congr 1
    field_simp [show rho ≠ 0 by norm_num [rho]]
  have room : 1 ≤ (scale x)^(wide/rho) := by rw [pwr]; exact Real.one_le_rpow hx.le (by norm_num [wide])
  apply Finset.mem_filter.mpr
  refine ⟨Fintype.mem_piFinset.mpr (fun j => ?_),?_⟩
  · apply (mem_fragment_divisors_iff _ _ _ room (r j)).mpr
    refine ⟨(each j).1,(each j).2,?_⟩
    have le := (Finset.mem_Icc.mp (Fintype.mem_piFinset.mp coord j)).2
    rw [Nat.cast_max,Nat.cast_one]
    apply max_le room
    rw [pwr]
    apply (Nat.cast_le.mpr (show (r j).primeFactors.sup id ≤ ⌊x^wide⌋₊ from
      Finset.sup_le fun p hp => (Nat.le_of_dvd (Nat.pos_of_ne_zero (each j).1.ne_zero)
        (Nat.dvd_of_mem_primeFactors hp)).trans le)).trans
    exact Nat.floor_le (Real.rpow_nonneg (zero_lt_one.trans hx).le _)
  · intro sq
    exact notT ((Endpoint.mem_legalRoots r).mpr ⟨sq,Nat.Coprime.prod_left (fun j _ => (each j).2),cut⟩)

theorem missing_mass (H : Finset ℕ) :
    let W := presievingModulus H
    let big := fun x => unrestricted (W x) ⌊x^wide⌋₊
    let legal := fun x => Endpoint.legalRoots (Fin 39) (W x) ⌊x^wide⌋₊
    Tendsto (fun x => (norm H x^39)⁻¹*((∑ r ∈ big x, Endpoint.harmonic r) -
      ∑ r ∈ legal x, Endpoint.harmonic r)) atTop (𝓝 0) := by
  intro W big legal
  apply squeeze_zero' _ _ (bad_cube_mass H)
  all_goals filter_upwards [eventually_gt_atTop (1:ℝ)] with x hx
  all_goals have pos : 0 < norm H x := PrimeGap182.Selberg.fragmentNormalization_pos H x (scale x) (Real.one_lt_rpow hx (by norm_num [rho]))
  all_goals rw [←Finset.sum_sdiff_eq_sub (legal_sub _ _)]
  · exact mul_nonneg (by positivity) (Finset.sum_nonneg fun r _ => by unfold Endpoint.harmonic; positivity)
  · apply mul_le_mul_of_nonneg_left _ (by positivity)
    apply Finset.sum_le_sum_of_subset_of_nonneg (missing_subset H hx)
    intro r _ _
    unfold Endpoint.harmonic
    positivity

theorem sampled_in_legal {m : ℕ} (H : Finset ℕ) {x : ℝ} (hx : 1 < x) (a : Fin (m+2) → ℝ)
    (ha : StrictMono a) (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap) (F : Profile 39 m)
    (room : ∀ y, F y ≠ 0 → rho*(∑ j, ∑ k, y j k) ≤ radiusCap) :
    (sample H a F x).support ⊆ Endpoint.legalRoots (Fin 39) (presievingModulus H x) ⌊x^wide⌋₊ := by
  intro r hr
  obtain ⟨mem,nz⟩ := sample_witness hr
  obtain ⟨coords,sq⟩ := Finset.mem_filter.mp mem
  have ms := Fintype.mem_piFinset.mp coords
  have cut := retained_product_radius hx a ha.monotone first last r sq ms
  have cp : (carrier H x).Coprime (presievingModulus H x) :=
    Nat.Coprime.prod_left fun p hp => (Nat.prime_of_mem_primesLE (Finset.mem_filter.mp hp).1).coprime_iff_not_dvd.mpr
      (Finset.mem_filter.mp hp).2
  apply (Endpoint.mem_legalRoots r).mpr
  refine ⟨sq,Nat.Coprime.prod_left (fun j _ => cp.coprime_dvd_left (Nat.dvd_of_mem_divisors (ms j))),?_⟩
  apply Nat.le_floor
  rw [cut]
  exact Real.rpow_le_rpow_of_exponent_le hx.le ((room _ nz).trans (by norm_num [radiusCap,wide]))

theorem sampled_bound {m : ℕ} (H : Finset ℕ) {x : ℝ} (hx : 1 < x)
    (a : Fin (m+2) → ℝ) (F : Profile 39 m) {M : ℝ} (hM : 0 ≤ M) (bound : ∀ y, |F y| ≤ M)
    (r : Fin 39 → ℕ) : |sample H a F x r| ≤ M/norm H x^39 := by
  have pos : 0 < norm H x := PrimeGap182.Selberg.fragmentNormalization_pos H x (scale x)
    (Real.one_lt_rpow hx (by norm_num [rho]))
  simp only [sample,Finsupp.finsetSum_apply,Finsupp.single_apply,Finset.sum_ite_eq']
  split_ifs
  · rw [abs_div,abs_of_pos (pow_pos pos _)]
    exact div_le_div_of_nonneg_right (bound _) (pow_pos pos _).le
  · simpa using div_nonneg hM (pow_pos pos 39).le

/-- The actual full 39-site array on the simultaneous 0/182 prime event.
Enlarging its two-endpoint denominator costs o(1) in ordinary-mass units,
uniformly over the selected progression. -/
theorem sampled_pair_unrestricted {m : ℕ} (H : Finset ℕ) (hH : H.card = 39)
    (a : Fin (m+2) → ℝ) (ha : StrictMono a) (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (F : Profile 39 m) (bf : Bornology.IsBounded (Set.range F))
    (room : ∀ y, F y ≠ 0 → rho*(∑ j, ∑ k, y j k) ≤ radiusCap) {ε : ℝ} (he : 0 < ε) :
    ∀ᶠ x : ℝ in atTop, ∀ b : ℕ,
      let h := H.orderEmbOfFin hH
      let W := presievingModulus H x
      let y := sample H a F x
      let T := Endpoint.legalRoots (Fin 39) W ⌊x^wide⌋₊
      let U := unrestricted W ⌊x^wide⌋₊
      let j := Fin.last 38
      let C := x/(W:ℝ)/norm H x^39
      (∑ n ∈ Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊, if Nat.ModEq W n b ∧ (n+h 0).Prime ∧ (n+h j).Prime
        then (PrimeGap182Analytic.sampledSelbergRoot y (fun k => n+h k))^2 else 0) ≤
        x/(W:ℝ)*(∑ t ∈ T.image (Endpoint.retained 0 j),
          (Endpoint.integral T 0 j y t)^2 / Endpoint.volume U 0 j t) + ε*C := by
  obtain ⟨M,hm,bd⟩ := bf.exists_pos_norm_le
  have bnd (v) : |F v| ≤ M := bd (F v) ⟨v,rfl⟩
  have tol := (missing_mass H).const_mul (M^2)
  rw [mul_zero] at tol
  have small := tol.eventually_le_const (half_pos he)
  have raw := Endpoint.prime_pair_upper hH (0 : Fin 39) (Fin.last 38)
    (by norm_num [wide] : 0 < wide) (by norm_num [wide]) hm.le (half_pos he)
  filter_upwards [raw,small,eventually_gt_atTop (1:ℝ)] with x raw tiny hx
  intro b h W y T U j C
  have pos : 0 < norm H x := PrimeGap182.Selberg.fragmentNormalization_pos H x (scale x)
    (Real.one_lt_rpow hx (by norm_num [rho]))
  have bounded := sampled_bound H hx a F hm.le bnd
  have sub := sampled_in_legal H hx a ha first last F room
  have law := raw y b sub bounded
  have hp (r) (mem : r ∈ U) : 0 < Endpoint.harmonic r := by
    apply one_div_pos.mpr
    apply Finset.prod_pos
    intro k _
    exact_mod_cast Nat.totient_pos.mpr (Finset.mem_Icc.mp (Fintype.mem_piFinset.mp (Finset.mem_filter.mp mem).1 k)).1
  have enlarge := Endpoint.enlarge_denominator (legal_sub W _) 0 j y hp
    (div_nonneg hm.le (pow_pos pos _).le) (fun r _ => bounded r)
  let V := (∑ r ∈ U, Endpoint.harmonic r)-(∑ r ∈ T, Endpoint.harmonic r)
  change M^2*((norm H x^39)⁻¹*V) ≤ ε/2 at tiny
  have cost : x/(W:ℝ)*((M/norm H x^39)^2*V) ≤ (ε/2)*C := by
    have v := mul_le_mul_of_nonneg_right tiny (show 0 ≤ C by dsimp [C]; positivity)
    apply le_trans _ v
    exact le_of_eq (by dsimp [C]; field_simp)
  have term := mul_le_mul_of_nonneg_left enlarge (show 0 ≤ x/(W:ℝ) by positivity)
  change _ ≤ x/(W:ℝ)*(∑ t ∈ T.image (Endpoint.retained 0 j), (Endpoint.integral T 0 j y t)^2 /
    Endpoint.volume T 0 j t) + (ε/2)*C at law
  rw [mul_add] at term
  apply law.trans
  apply (add_le_add term le_rfl).trans
  apply (add_le_add (add_le_add le_rfl cost) le_rfl).trans
  exact le_of_eq (by ring)

#print axioms sampled_pair_unrestricted
#print axioms missing_mass
#print axioms physical_pair_limit
#print axioms bad_cube_mass
end PrimeGap180.EndpointPhysical
