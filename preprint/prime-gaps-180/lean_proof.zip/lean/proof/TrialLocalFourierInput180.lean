import TrialSourceSchedule180

namespace PrimeGap180.SourceSchedule

/-- The independently supplied local Fourier theorem has exactly the pinned upstream type.
The other classical exponential-sum estimates remain separate inputs. -/
theorem inputs_of_local_fourier
    (prime : PrimeGap180.Distribution.ClassicalPrimeBounds)
    (rank4 : PrimeGap182Audit.AllIncidenceRankFourBounds)
    (localFourier : PrimeGap182.TypeIII.HasFiniteExceptionalTypeIIIInput) :
    Nonempty Inputs := by
  obtain ⟨C, hC, D, p₀, h⟩ := localFourier
  exact ⟨⟨prime, rank4, C, D, p₀, hC.le, h⟩⟩

/-- The two classical estimates already present on the 180 side can be
passed straight to the 182 argument. Only this implication is needed from the
local Fourier input; the classical estimates are supplied once overall. -/
theorem inputs_of_local_fourier_from_baseline
    (prime : PrimeGap180.Distribution.ClassicalPrimeBounds)
    (rank4 : PrimeGap182Audit.AllIncidenceRankFourBounds)
    (localFourier : PrimeGap182.TypeIII.BaselineLocalInputs →
      PrimeGap182.TypeIII.HasFiniteExceptionalTypeIIIInput) :
    Nonempty Inputs :=
  inputs_of_local_fourier prime rank4 (localFourier prime)

#print axioms inputs_of_local_fourier_from_baseline
#print axioms inputs_of_local_fourier
end PrimeGap180.SourceSchedule
