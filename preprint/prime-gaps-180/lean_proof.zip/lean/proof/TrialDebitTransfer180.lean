import TrialDebitReceiver180
import TrialDebitBinLift180

/-! Positive restored debit using the native numerator and a symmetric
two-parts-in-100,000 comparison of the physical site masses. -/
noncomputable section
open MeasureTheory PrimeGap180.CoarseLaw PrimeGap180.PhysicalDebit
namespace PrimeGap180.DebitWeights

theorem frozen_bottom : bottomPrices := DebitRunData.bottom

theorem restored_of_weights {w : State → ℝ} (law : LawComparison w)
    (native : debitW w ≤ 0.000023397128*massW w)
    (removed : NumericalAccount.mass Restoration.deleted ≤ 0.000160674*NumericalAccount.mass Restoration.original) :
    NumericalAccount.directDebit ≤ 0.000042838*NumericalAccount.mass Restoration.original :=
  DebitRunData.restored_from_uncut (uncut law frozen_bottom native) removed

theorem restored_of_bins {K : Type*} [DecidableEq K] (C : State → K) (index : K → ℕ)
    (u : K → ℝ) (bins : BinComparison C index u)
    (native : debitW (liftNative C u) ≤ 0.000023397128*massW (liftNative C u))
    (removed : NumericalAccount.mass Restoration.deleted ≤ 0.000160674*NumericalAccount.mass Restoration.original) :
    NumericalAccount.directDebit ≤ 0.000042838*NumericalAccount.mass Restoration.original :=
  restored_of_weights (law_of_bins C index u bins) native removed

#print axioms restored_of_bins
end PrimeGap180.DebitWeights
