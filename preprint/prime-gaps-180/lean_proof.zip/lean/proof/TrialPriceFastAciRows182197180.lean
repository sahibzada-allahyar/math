import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G182
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 182

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G182

namespace PrimeGap180.PriceIsolatedGroup.G187
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 187

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G187

namespace PrimeGap180.PriceIsolatedGroup.G192
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 192

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G192

namespace PrimeGap180.PriceIsolatedGroup.G197
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 197

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G197
