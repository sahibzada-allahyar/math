import TrialDensityTriangleData180
namespace PrimeGap180.DensitySimplex.Horner.TriangleChecks
open scoped BigOperators
def unit : Int := 20000000000

structure VertexTicks where
  lowerX : Int
  cornerX : Int
  cornerY : Int
  upperY : Int

def ticks : Fin 12 → VertexTicks := ![
  ⟨1208449000,4227998,2408442004,2410556003⟩,
  ⟨1218169000,14787998,2406762004,2414156003⟩,
  ⟨1234369000,32387998,2403962004,2420156003⟩,
  ⟨1266769000,67587998,2398362004,2432156003⟩,
  ⟨1299169000,102787998,2392762004,2444156003⟩,
  ⟨1331569000,137987998,2387162004,2456156003⟩,
  ⟨1363969000,173187998,2381562004,2468156003⟩,
  ⟨1380169000,190787998,2378762004,2474156003⟩,
  ⟨1396369000,208387998,2375962004,2480156003⟩,
  ⟨1412569000,225987998,2373162004,2486156003⟩,
  ⟨1429000000,243895998,2370208004,2492156003⟩,
  ⟨1441729000,257667998,2368122004,2496956003⟩
]

def factors (g₀ g₁ h₀ h₁ : Int) : List (Factor 2) :=
  [(unit,![-2*g₀-h₀,-2*g₁-h₁]),(unit,![g₀-h₀,g₁-h₁]),(unit,![g₀+2*h₀,g₁+2*h₁])]
def L (i : Fin 12) := factors (ticks i).lowerX (ticks i).cornerX 0 (ticks i).cornerY
def U (i : Fin 12) := factors (ticks i).cornerX 0 (ticks i).cornerY (ticks i).upperY
def r (i : Fin 12) := cxQ (cutoffQ i) (parentQ i)
def s (i : Fin 12) := cyQ (cutoffQ i) (parentQ i)

end PrimeGap180.DensitySimplex.Horner.TriangleChecks
