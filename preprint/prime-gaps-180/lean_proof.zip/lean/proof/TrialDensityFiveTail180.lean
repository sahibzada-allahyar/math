import TrialDensityBernstein180

noncomputable section
open MeasureTheory
open scoped BigOperators
namespace PrimeGap180.DensitySimplex

private theorem normalized_product (z : Fin 4 → ℝ) :
    fiveDen z = 3125*(∏ i, fromWeighted5 z i)*LiteralDensity.residual (fromWeighted5 z) := by
  unfold fiveDen fiveNumerator fromWeighted5 sites5 first5 LiteralDensity.residual
  norm_num [Fin.prod_univ_four, Fin.sum_univ_four]
  ring

theorem five_kernel (z : Fin 4 → ℝ) :
    kernel (fromWeighted5 z) = 3125*(fiveDen z)⁻¹ := by
  rw [normalized_product]
  simp only [kernel, mul_inv_rev, Finset.prod_inv_distrib]
  ring

def fiveApprox (a : ℝ) : ℝ :=
  (3125/30:ℝ)*(∫ z in region 4 (5*a-2),
    ∑ j ∈ Finset.range 11, (1-fiveDen z)^j)

theorem five_loss_error (a : ℝ) (ha : 0 < 5*a-2) (hb : 5*a-2 ≤ 1/10) :
    |24*Terminal.fiveIntegral a-fiveApprox a| ≤
      (3125/30:ℝ)*((1/32)^11/(1-1/32))*((5*a-2)^4/24) := by
  have cont : Continuous fiveDen := by unfold fiveDen fiveNumerator; fun_prop
  have estimate := reciprocal_integral_error (5*a-2) ha fiveDen cont (1/32) 11
    (by norm_num) (fiveDen_error hb)
  have main : 24*Terminal.fiveIntegral a = (3125/30:ℝ)*
      (∫ z in region 4 (5*a-2), (fiveDen z)⁻¹) := by
    rw [five_integral,cone5_region]
    simp_rw [five_kernel]
    rw [integral_const_mul]
    ring
  rw [main,fiveApprox,← mul_sub,abs_mul,abs_of_pos (by norm_num : (0:ℝ) < 3125/30)]
  simpa [Nat.factorial, mul_assoc] using
    mul_le_mul_of_nonneg_left estimate (by norm_num : (0:ℝ) ≤ 3125/30)

theorem sharp_five_error :
    |24*Terminal.fiveIntegral (41361/100000)-fiveApprox (41361/100000)| ≤ 1/10^20 := by
  apply (five_loss_error _ (by norm_num) (by norm_num)).trans
  norm_num

theorem higher_five_error (i : Fin 12) :
    let a := (Sifted.frozenCutoffs i).a
    |24*Terminal.fiveIntegral a-fiveApprox a| ≤ 1/10^20 := by
  dsimp only
  have h (j : Fin 12) : 0 < 5*(Sifted.frozenCutoffs j).a-2 ∧
      5*(Sifted.frozenCutoffs j).a-2 ≤ 1/12 := by
    fin_cases j <;> norm_num [Sifted.frozenCutoffs]
  apply (five_loss_error _ (h i).1 (by linarith [(h i).2])).trans
  have p := pow_le_pow_left₀ (h i).1.le (h i).2 4
  linarith

#print axioms five_loss_error
#print axioms sharp_five_error
#print axioms higher_five_error
end PrimeGap180.DensitySimplex
