import TrialJointEdgeWeighted180
import TrialLaterLowTransform180
import TrialRestorationIdentity180
import Mathlib.MeasureTheory.Integral.Pi

/-! The actual 39-site unconditioned Chernoff comparison, including every
possible erased site. The pointwise amplitude majorant is an explicit input. -/
noncomputable section
open MeasureTheory Set Filter PrimeGap186 PrimeGap180.Sector PrimeGap180.FrozenProfile
open scoped Classical NNReal BigOperators
namespace PrimeGap180.LaterLowProduct
open NativeSiteLaw (radial tail)
open JointEdgeConditional (erasedSet)
open private one_nonneg from TrialFrozenData180
open private radial_meas tail_meas from TrialNativeSiteLaw180

abbrev ν := bandLaw FrozenData.mesh
abbrev μ := Measure.pi (fun _ : Fin 39 => ν)
local instance : IsFiniteMeasure ν := bandLaw_finite _
def totalCap := 131072*Native.step

def weight (g : ℝ→ℝ) (edge : Fin 217) (b r : ℝ) (z : Band 216) :=
  g (radial z) * Real.exp (-(b*radial z + r*(radial z-tail edge z)))

private theorem total {v : Fin 39→Band 216} (nz : Restoration.original v≠0) :
    (∑ i,radial (v i)) ≤ totalCap := by
  have h:=Native.physical_le_adverse v
  unfold Native.physical Native.adverse at h
  rw [mul_assoc] at h
  have idx := Restoration.original_index v nz
  have bound : ((Native.cellSum v:ℕ):ℝ)+39 ≤ 131072 := by exact_mod_cast (show Native.cellSum v+39≤131072 by omega)
  exact ((mul_le_mul_iff_right₀ (show (0:ℝ)<rho by norm_num [rho])).mp h).trans
    (mul_le_mul_of_nonneg_right bound (by norm_num [Native.step]))

private theorem dust {edge : Fin 217} {c : ℝ} {v : Fin 39→Band 216} {i : Fin 39}
    (fail : (∑ k,JointEdgeFailure.slack edge 1 (v (i.succAbove k)))<c) :
    (∑ k, (radial (v (i.succAbove k))-tail edge (v (i.succAbove k)))) ≤ c := by
  apply le_trans _ fail.le
  apply Finset.sum_le_sum
  intro k _
  simp only [JointEdgeFailure.slack,one_mul]
  apply sub_le_sub_right
  exact ((div_lt_iff₀ (show 0<Native.step by norm_num [Native.step])).mp (Nat.lt_floor_add_one _)).le

private def rate (i k : Fin 39) (r : ℝ) := if k=i then 0 else r

private theorem tilted {g : ℝ→ℝ} (gp : ∀ t,0≤g t) {edge : Fin 217} (b r : ℝ≥0) (c : ℝ)
    {v : Fin 39→Band 216} (nz : Restoration.original v≠0) (i : Fin 39)
    (fail : (∑ k,JointEdgeFailure.slack edge 1 (v (i.succAbove k)))<c) :
    (∏ k,g (radial (v k))) ≤ Real.exp ((b:ℝ)*totalCap + (r:ℝ)*c)*
      ∏ k,weight g edge b (rate i k r) (v k) := by
  have hsum : (∑ k,rate i k r*(radial (v k)-tail edge (v k))) =
      (r:ℝ)*∑ k, (radial (v (i.succAbove k))-tail edge (v (i.succAbove k))) := by
    rw [Fin.sum_univ_succAbove _ i,Finset.mul_sum]
    simp [rate,Fin.succAbove_ne]
  have hs := add_le_add (mul_le_mul_of_nonneg_left (total nz) b.2)
    (mul_le_mul_of_nonneg_left (dust fail) r.2)
  have hpos : (1:ℝ) ≤ Real.exp ((b:ℝ)*totalCap+(r:ℝ)*c)*
      ∏ k,Real.exp (-((b:ℝ)*radial (v k)+rate i k r*(radial (v k)-tail edge (v k)))) := by
    rw [←Real.exp_sum,←Real.exp_add,Real.one_le_exp_iff,Finset.sum_neg_distrib,Finset.sum_add_distrib,
      ←Finset.mul_sum,hsum]
    rw [←sub_eq_add_neg]
    apply sub_nonneg.mpr
    convert hs using 1 <;> rfl'
  simp only [weight,Finset.prod_mul_distrib]
  calc
    _ = (∏ k,g (radial (v k)))*1 := (mul_one _).symm
    _ ≤ _ := (mul_le_mul_of_nonneg_left hpos (Finset.prod_nonneg fun k _=>gp _)).trans_eq (by ring)

/-- All thirty-nine candidate erasures of an actual nonzero spline are
paid by one erased and thirty-eight tilted factors of the same band law. -/
theorem bound (g : ℝ→ℝ) (gp : ∀ t,0≤g t) (edge : Fin 217) (b r : ℝ≥0) (c A : ℝ) (hA : 0≤A)
    (E : Set (Fin 39→Band 216)) (mE : MeasurableSet E) (cover : E ⊆ erasedSet edge 1 c)
    (amplitude : ∀ᵐ v ∂μ, v∈E → (Restoration.original v)^2 ≤ A*∏ k,g (radial (v k)))
    (iw : ∀ s ∈ ({0,(r:ℝ)} : Finset ℝ), Integrable (weight g edge b s) ν) :
    (∫ v in E,(Restoration.original v)^2 ∂μ) ≤
    39*A*Real.exp ((b:ℝ)*totalCap+(r:ℝ)*c) * (∫ z,weight g edge b 0 z ∂ν) * (∫ z,weight g edge b r z ∂ν)^38 := by
  let L := A*Real.exp ((b:ℝ)*totalCap+(r:ℝ)*c)
  let f := fun (i : Fin 39) (v : Fin 39→Band 216) => ∏ k,weight g edge b (rate i k r) (v k)
  have fn (i : Fin 39) (v : Fin 39→Band 216) : 0≤f i v :=
    Finset.prod_nonneg fun k _=>mul_nonneg (gp _) (Real.exp_pos _).le
  have fi (i : Fin 39) : Integrable (f i) μ := by
    apply Integrable.fintype_prod_dep
    intro k
    apply iw
    by_cases h : k=i <;> simp [rate,h]
  have ln : 0≤L := mul_nonneg hA (Real.exp_pos _).le
  have mono : (∫ v in E,(Restoration.original v)^2 ∂μ) ≤
      ∫ v,L*∑ i,f i v ∂μ := by
    rw [←integral_indicator mE]
    apply integral_mono_of_nonneg (Eventually.of_forall fun v=>Set.indicator_nonneg (fun _ _ => sq_nonneg _) _)
      ((integrable_finsetSum _ fun i _=>fi i).const_mul L)
    filter_upwards [amplitude] with v av
    by_cases on : v∈E
    · rw [Set.indicator_of_mem on]
      by_cases nz : Restoration.original v=0
      · rw [nz,zero_pow (by decide)]
        exact mul_nonneg ln (Finset.sum_nonneg fun k _=>fn k v)
      obtain ⟨i,bad⟩ := cover on
      apply (av on).trans
      apply (mul_le_mul_of_nonneg_left (tilted gp b r c nz i bad) hA).trans
      rw [←mul_assoc]
      exact mul_le_mul_of_nonneg_left (Finset.single_le_sum (f:=fun k=>f k v) (fun k _=>fn k v) (Finset.mem_univ i)) ln
    · rw [Set.indicator_of_notMem on]
      exact mul_nonneg ln (Finset.sum_nonneg fun k _=>fn k v)
  apply mono.trans_eq
  have per (i : Fin 39) : (∫ v,f i v ∂μ)=(∫ z,weight g edge b 0 z ∂ν)*(∫ z,weight g edge b r z ∂ν)^38 := by
    change (∫ v, ∏ k,weight g edge b (rate i k r) (v k) ∂μ)=_
    rw [integral_fintype_prod_eq_prod,Fin.prod_univ_succAbove _ i]
    simp [rate,Fin.succAbove_ne]
  rw [integral_const_mul,integral_finsetSum _ fun i _=>fi i]
  simp only [per,Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul]
  dsimp [L]
  ring

#print axioms bound
end PrimeGap180.LaterLowProduct
