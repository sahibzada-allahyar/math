import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G364
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 364

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G364

namespace PrimeGap180.PriceIsolatedGroup.G369
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 369

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G369

namespace PrimeGap180.PriceIsolatedGroup.G374
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 374

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G374

namespace PrimeGap180.PriceIsolatedGroup.G379
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 379

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G379
