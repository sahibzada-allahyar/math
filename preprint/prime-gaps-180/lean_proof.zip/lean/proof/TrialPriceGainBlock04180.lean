import TrialPriceGainRows180
open scoped BigOperators
namespace PrimeGap180.PriceGainRows
open Book
set_option maxRecDepth 131072
set_option maxHeartbeats 100000000
private theorem g256 : (PriceValues.group 256).gain = ∑ k : Book.Row, row k (256:Group) := by decide +kernel
private theorem g257 : (PriceValues.group 257).gain = ∑ k : Book.Row, row k (257:Group) := by decide +kernel
private theorem g258 : (PriceValues.group 258).gain = ∑ k : Book.Row, row k (258:Group) := by decide +kernel
private theorem g259 : (PriceValues.group 259).gain = ∑ k : Book.Row, row k (259:Group) := by decide +kernel
private theorem g260 : (PriceValues.group 260).gain = ∑ k : Book.Row, row k (260:Group) := by decide +kernel
private theorem g261 : (PriceValues.group 261).gain = ∑ k : Book.Row, row k (261:Group) := by decide +kernel
private theorem g262 : (PriceValues.group 262).gain = ∑ k : Book.Row, row k (262:Group) := by decide +kernel
private theorem g263 : (PriceValues.group 263).gain = ∑ k : Book.Row, row k (263:Group) := by decide +kernel
private theorem g264 : (PriceValues.group 264).gain = ∑ k : Book.Row, row k (264:Group) := by decide +kernel
private theorem g265 : (PriceValues.group 265).gain = ∑ k : Book.Row, row k (265:Group) := by decide +kernel
private theorem g266 : (PriceValues.group 266).gain = ∑ k : Book.Row, row k (266:Group) := by decide +kernel
private theorem g267 : (PriceValues.group 267).gain = ∑ k : Book.Row, row k (267:Group) := by decide +kernel
private theorem g268 : (PriceValues.group 268).gain = ∑ k : Book.Row, row k (268:Group) := by decide +kernel
private theorem g269 : (PriceValues.group 269).gain = ∑ k : Book.Row, row k (269:Group) := by decide +kernel
private theorem g270 : (PriceValues.group 270).gain = ∑ k : Book.Row, row k (270:Group) := by decide +kernel
private theorem g271 : (PriceValues.group 271).gain = ∑ k : Book.Row, row k (271:Group) := by decide +kernel
private theorem g272 : (PriceValues.group 272).gain = ∑ k : Book.Row, row k (272:Group) := by decide +kernel
private theorem g273 : (PriceValues.group 273).gain = ∑ k : Book.Row, row k (273:Group) := by decide +kernel
private theorem g274 : (PriceValues.group 274).gain = ∑ k : Book.Row, row k (274:Group) := by decide +kernel
private theorem g275 : (PriceValues.group 275).gain = ∑ k : Book.Row, row k (275:Group) := by decide +kernel
private theorem g276 : (PriceValues.group 276).gain = ∑ k : Book.Row, row k (276:Group) := by decide +kernel
private theorem g277 : (PriceValues.group 277).gain = ∑ k : Book.Row, row k (277:Group) := by decide +kernel
private theorem g278 : (PriceValues.group 278).gain = ∑ k : Book.Row, row k (278:Group) := by decide +kernel
private theorem g279 : (PriceValues.group 279).gain = ∑ k : Book.Row, row k (279:Group) := by decide +kernel
private theorem g280 : (PriceValues.group 280).gain = ∑ k : Book.Row, row k (280:Group) := by decide +kernel
private theorem g281 : (PriceValues.group 281).gain = ∑ k : Book.Row, row k (281:Group) := by decide +kernel
private theorem g282 : (PriceValues.group 282).gain = ∑ k : Book.Row, row k (282:Group) := by decide +kernel
private theorem g283 : (PriceValues.group 283).gain = ∑ k : Book.Row, row k (283:Group) := by decide +kernel
private theorem g284 : (PriceValues.group 284).gain = ∑ k : Book.Row, row k (284:Group) := by decide +kernel
private theorem g285 : (PriceValues.group 285).gain = ∑ k : Book.Row, row k (285:Group) := by decide +kernel
private theorem g286 : (PriceValues.group 286).gain = ∑ k : Book.Row, row k (286:Group) := by decide +kernel
private theorem g287 : (PriceValues.group 287).gain = ∑ k : Book.Row, row k (287:Group) := by decide +kernel
private theorem g288 : (PriceValues.group 288).gain = ∑ k : Book.Row, row k (288:Group) := by decide +kernel
private theorem g289 : (PriceValues.group 289).gain = ∑ k : Book.Row, row k (289:Group) := by decide +kernel
private theorem g290 : (PriceValues.group 290).gain = ∑ k : Book.Row, row k (290:Group) := by decide +kernel
private theorem g291 : (PriceValues.group 291).gain = ∑ k : Book.Row, row k (291:Group) := by decide +kernel
private theorem g292 : (PriceValues.group 292).gain = ∑ k : Book.Row, row k (292:Group) := by decide +kernel
private theorem g293 : (PriceValues.group 293).gain = ∑ k : Book.Row, row k (293:Group) := by decide +kernel
private theorem g294 : (PriceValues.group 294).gain = ∑ k : Book.Row, row k (294:Group) := by decide +kernel
private theorem g295 : (PriceValues.group 295).gain = ∑ k : Book.Row, row k (295:Group) := by decide +kernel
private theorem g296 : (PriceValues.group 296).gain = ∑ k : Book.Row, row k (296:Group) := by decide +kernel
private theorem g297 : (PriceValues.group 297).gain = ∑ k : Book.Row, row k (297:Group) := by decide +kernel
private theorem g298 : (PriceValues.group 298).gain = ∑ k : Book.Row, row k (298:Group) := by decide +kernel
private theorem g299 : (PriceValues.group 299).gain = ∑ k : Book.Row, row k (299:Group) := by decide +kernel
private theorem g300 : (PriceValues.group 300).gain = ∑ k : Book.Row, row k (300:Group) := by decide +kernel
private theorem g301 : (PriceValues.group 301).gain = ∑ k : Book.Row, row k (301:Group) := by decide +kernel
private theorem g302 : (PriceValues.group 302).gain = ∑ k : Book.Row, row k (302:Group) := by decide +kernel
private theorem g303 : (PriceValues.group 303).gain = ∑ k : Book.Row, row k (303:Group) := by decide +kernel
private theorem g304 : (PriceValues.group 304).gain = ∑ k : Book.Row, row k (304:Group) := by decide +kernel
private theorem g305 : (PriceValues.group 305).gain = ∑ k : Book.Row, row k (305:Group) := by decide +kernel
private theorem g306 : (PriceValues.group 306).gain = ∑ k : Book.Row, row k (306:Group) := by decide +kernel
private theorem g307 : (PriceValues.group 307).gain = ∑ k : Book.Row, row k (307:Group) := by decide +kernel
private theorem g308 : (PriceValues.group 308).gain = ∑ k : Book.Row, row k (308:Group) := by decide +kernel
private theorem g309 : (PriceValues.group 309).gain = ∑ k : Book.Row, row k (309:Group) := by decide +kernel
private theorem g310 : (PriceValues.group 310).gain = ∑ k : Book.Row, row k (310:Group) := by decide +kernel
private theorem g311 : (PriceValues.group 311).gain = ∑ k : Book.Row, row k (311:Group) := by decide +kernel
private theorem g312 : (PriceValues.group 312).gain = ∑ k : Book.Row, row k (312:Group) := by decide +kernel
private theorem g313 : (PriceValues.group 313).gain = ∑ k : Book.Row, row k (313:Group) := by decide +kernel
private theorem g314 : (PriceValues.group 314).gain = ∑ k : Book.Row, row k (314:Group) := by decide +kernel
private theorem g315 : (PriceValues.group 315).gain = ∑ k : Book.Row, row k (315:Group) := by decide +kernel
private theorem g316 : (PriceValues.group 316).gain = ∑ k : Book.Row, row k (316:Group) := by decide +kernel
private theorem g317 : (PriceValues.group 317).gain = ∑ k : Book.Row, row k (317:Group) := by decide +kernel
private theorem g318 : (PriceValues.group 318).gain = ∑ k : Book.Row, row k (318:Group) := by decide +kernel
private theorem g319 : (PriceValues.group 319).gain = ∑ k : Book.Row, row k (319:Group) := by decide +kernel
theorem batch4 : ∀ i : Fin 64, (PriceValues.group (256+i.val)).gain = ∑ k : Book.Row, row k ⟨256+i.val,by omega⟩ :=
  Fin.cases g256 (Fin.cases g257 (Fin.cases g258 (Fin.cases g259 (Fin.cases g260 (Fin.cases g261 (Fin.cases g262 (Fin.cases g263 (Fin.cases g264 (Fin.cases g265 (Fin.cases g266 (Fin.cases g267 (Fin.cases g268 (Fin.cases g269 (Fin.cases g270 (Fin.cases g271 (Fin.cases g272 (Fin.cases g273 (Fin.cases g274 (Fin.cases g275 (Fin.cases g276 (Fin.cases g277 (Fin.cases g278 (Fin.cases g279 (Fin.cases g280 (Fin.cases g281 (Fin.cases g282 (Fin.cases g283 (Fin.cases g284 (Fin.cases g285 (Fin.cases g286 (Fin.cases g287 (Fin.cases g288 (Fin.cases g289 (Fin.cases g290 (Fin.cases g291 (Fin.cases g292 (Fin.cases g293 (Fin.cases g294 (Fin.cases g295 (Fin.cases g296 (Fin.cases g297 (Fin.cases g298 (Fin.cases g299 (Fin.cases g300 (Fin.cases g301 (Fin.cases g302 (Fin.cases g303 (Fin.cases g304 (Fin.cases g305 (Fin.cases g306 (Fin.cases g307 (Fin.cases g308 (Fin.cases g309 (Fin.cases g310 (Fin.cases g311 (Fin.cases g312 (Fin.cases g313 (Fin.cases g314 (Fin.cases g315 (Fin.cases g316 (Fin.cases g317 (Fin.cases g318 (Fin.cases g319 (fun i => Fin.elim0 i))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
#print axioms batch4
end PrimeGap180.PriceGainRows
