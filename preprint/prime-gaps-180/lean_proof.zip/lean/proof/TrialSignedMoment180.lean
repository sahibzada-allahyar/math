import Selberg39
import TrialModulusGate180
import TrialLiteralSupport180

/-! Use a finite cover of actual coefficient moduli in the signed 39-shift
moment. Each source row only supplies an unweighted coherent discrepancy. -/
noncomputable section
open scoped Classical BigOperators
open PrimeGap186 PrimeGap182.Selberg

namespace PrimeGap180.Gate

theorem size_after_presieve {x η H θ : ℝ} {W q : ℕ} (hx : 1 < x)
    (hw : 0 < W) (hq : 0 < q) (hsize : (q:ℝ) ≤ (x^η)^H)
    (hslack : (W:ℝ) ≤ x^(θ-η*H)) : (W.lcm q : ℝ) ≤ x^θ := by
  have hd := Nat.lcm_dvd (Nat.dvd_mul_right W q) (Nat.dvd_mul_left q W)
  calc
    (W.lcm q : ℝ) ≤ (W:ℝ)*q := by exact_mod_cast Nat.le_of_dvd (Nat.mul_pos hw hq) hd
    _ ≤ x^(θ-η*H) * (x^η)^H := mul_le_mul hslack hsize (Nat.cast_nonneg q)
      (Real.rpow_nonneg (by linarith) _)
    _ = x^θ := by rw [← Real.rpow_mul (by linarith : 0 ≤ x),
        ← Real.rpow_add (by linarith : 0 < x)]; ring_nf

theorem source_scale {x η δ : ℝ} (hx : 1 < x) (hη : η ≤ 1) (hδ : 0 ≤ δ) :
    (x^η)^δ ≤ x^δ := by
  rw [← Real.rpow_mul (by linarith : 0 ≤ x)]
  exact Real.rpow_le_rpow_of_exponent_le hx.le (by nlinarith)

/-- The source can demand a strictly smaller scale than its nominal width.
The midpoint exponent leaves strict room on both sides. -/
theorem presieved_source_row {x η δ B U S T : ℝ} {X Y d e W r j : ℕ}
    (hx : 1 < x) (hη : 0 < η) (hη1 : η < 1) (hδ : 0 < δ)
    (hX : Squarefree X) (hY : Squarefree Y) (hd : d ∣ X) (he : e ∣ Y)
    (hS : logSize (x^η) X ≤ S) (hT : logSize (x^η) Y ≤ T)
    (hband : (x^η)^B < (d.lcm e : ℝ)) (hupper : (d.lcm e : ℝ) ≤ (x^η)^U)
    (hW : Squarefree W) (hwY : (W:ℝ) ≤ (x^η)^δ) (hwSize : (W:ℝ) ≤ x^(U-η*U))
    (hdW : d.Coprime W) (heW : e.Coprime W) (hj : j ≤ r)
    (test : tailTest (x^η) B δ S T r X Y) :
    let δ' := ((1+η)/2)*δ
    0 < δ' ∧ δ' < δ ∧ (W.lcm (d.lcm e) : ℝ) ≤ x^U ∧ Squarefree (W.lcm (d.lcm e)) ∧
      Nonempty (DenseDivisibilityWitness ⟨x^δ', Real.one_le_rpow hx.le (by positivity)⟩
        j (W.lcm (d.lcm e))) := by
  intro δ'
  have hR := Real.one_lt_rpow hx hη
  have sq := squarefree_lcm_nat (hX.squarefree_of_dvd hd) (hY.squarefree_of_dvd he)
  have w := dense_presieved_descendant hR hδ.le hX hY hd he hS hT hband
    (Nat.pos_of_ne_zero hW.ne_zero) hwY hdW heW test
  have hgap : 0 < (1-η)*δ := mul_pos (by linarith) hδ
  refine ⟨by dsimp [δ']; positivity, by dsimp [δ']; nlinarith,
    size_after_presieve hx (Nat.pos_of_ne_zero hW.ne_zero) (Nat.pos_of_ne_zero sq.ne_zero)
      hupper hwSize, squarefree_lcm_nat hW sq, ?_⟩
  apply denseDivisibility_mono_scale _ (denseDivisibility_mono_order w hj)
  change (x^η)^δ ≤ x^δ'
  rw [← Real.rpow_mul (by linarith : 0 ≤ x)]
  apply Real.rpow_le_rpow_of_exponent_le hx.le
  dsimp [δ']
  nlinarith

theorem presieve_below_all_powers (H : Finset ℕ) (exponents : Finset ℝ)
    (positive : ∀ t ∈ exponents, 0 < t) :
    ∀ᶠ x : ℝ in Filter.atTop, ∀ t ∈ exponents, (presievingModulus H x : ℝ) ≤ x^t := by
  apply (Filter.eventually_all_finset exponents).mpr
  intro t ht
  filter_upwards [PrimeGap186.presieving_le_mul_log_eventually H 1 zero_lt_one,
    (isLittleO_log_rpow_atTop (positive t ht)).bound zero_lt_one,
    Filter.eventually_ge_atTop (1:ℝ)] with x hw hl hx
  simp only [Real.norm_eq_abs, abs_of_nonneg (Real.log_nonneg hx),
    abs_of_nonneg (Real.rpow_nonneg (zero_le_one.trans hx) t), one_mul] at hl
  simpa only [one_mul] using hw.trans (by simpa only [one_mul] using hl : 1*Real.log x ≤ x^t)

#print axioms presieved_source_row
#print axioms presieve_below_all_powers

end PrimeGap180.Gate

namespace PrimeGap180.Signed

def sample (I : Finset ℕ) (s : ℕ) (f : ℕ → ℝ) : ℕ →₀ ℂ :=
  ∑ m ∈ I.image (fun n => n+s), Finsupp.single m (f m : ℂ)

private theorem sample_value (I : Finset ℕ) (s n : ℕ) (f : ℕ → ℝ) :
    sample I s f n = if n ∈ I.image (fun m => m+s) then (f n : ℂ) else 0 := by
  classical
  simp only [sample, Finsupp.finsetSum_apply, Finsupp.single_apply, Finset.sum_ite_eq']

private theorem cover_sum {ι : Type*} [DecidableEq ι] (rows : Finset ι)
    (Q : ι → Finset ℕ) (g : ℕ → ℝ) (hg : ∀ n, 0 ≤ g n) :
    ∑ q ∈ rows.biUnion Q, g q ≤ ∑ j ∈ rows, ∑ q ∈ Q j, g q := by
  induction rows using Finset.induction_on with
  | empty => simp
  | insert j rows hj ih =>
    rw [Finset.biUnion_insert, Finset.sum_insert hj]
    have hu := Finset.sum_union_inter (s₁ := Q j) (s₂ := rows.biUnion Q) (f := g)
    have h0 : 0 ≤ ∑ q ∈ Q j ∩ rows.biUnion Q, g q := Finset.sum_nonneg fun q _ => hg q
    linarith

/-- Changing from the source interval to the shifted sieve interval costs at
most two terminal strips, uniformly in the residue and in the actual row. -/
theorem literal_shift_bound (ch : Literal.Channel) (a b s q v : ℕ)
    (hab : a ≤ b) (hq : 0 < q) :
    ‖fullDiscrepancy (sample (Finset.Ico a b) s (Literal.value ch)) q v -
      fullDiscrepancy (sample (Finset.Ico a b) 0 (Literal.value ch)) q v‖ ≤ 108*(s:ℝ) := by
  classical
  let f := fun n : ℕ => ((Literal.value ch n : ℝ) : ℂ)
  let window := fun lo hi : ℕ => ∑ n ∈ Finset.Ico lo hi, Finsupp.single n (f n)
  have sample_eq (t : ℕ) : sample (Finset.Ico a b) t (Literal.value ch) = window (a+t) (b+t) := by
    unfold sample window
    rw [Finset.image_add_right_Ico]
  have strip (m : ℕ) : ‖fullDiscrepancy (window m (m+s)) q v‖ ≤ 54*(s:ℝ) := by
    apply (norm_fullDiscrepancy_sample_le_two_sum_norm (Finset.Ico m (m+s)) f q v hq).trans
    calc
      _ ≤ 2*(∑ n ∈ Finset.Ico m (m+s), (27:ℝ)) := by
        gcongr with n hn
        simpa [f] using Literal.bounded ch n
      _ = _ := by simp; ring
  have join (u t w : ℕ) (hut : u ≤ t) (htw : t ≤ w) :
      fullDiscrepancy (window u t) q v + fullDiscrepancy (window t w) q v =
        fullDiscrepancy (window u w) q v := by
    simp only [window,fullDiscrepancy_sample]
    exact Finset.sum_Ico_consecutive _ hut htw
  have joinA := join a (a+s) (b+s) (by omega) (by omega)
  have joinB := join a b (b+s) hab (by omega)
  have diff : fullDiscrepancy (window (a+s) (b+s)) q v - fullDiscrepancy (window a b) q v =
      fullDiscrepancy (window b (b+s)) q v - fullDiscrepancy (window a (a+s)) q v := by
    linear_combination joinA - joinB
  rw [sample_eq, sample_eq, Nat.add_zero, Nat.add_zero, diff]
  exact (norm_sub_le _ _).trans (by linarith [strip a, strip b])

theorem literal_row_shift (ch : Literal.Channel) (a b s : ℕ) (hab : a ≤ b)
    (Q : Finset ℕ) (hq : ∀ q ∈ Q, 0 < q) (v : ℕ) :
    ∑ q ∈ Q, ‖fullDiscrepancy (sample (Finset.Ico a b) s (Literal.value ch)) q v‖ ≤
      (∑ q ∈ Q, ‖fullDiscrepancy (sample (Finset.Ico a b) 0 (Literal.value ch)) q v‖) +
        Q.card*(108*(s:ℝ)) := by
  classical
  rw [← nsmul_eq_mul, ← Finset.sum_const, ← Finset.sum_add_distrib]
  apply Finset.sum_le_sum
  intro q h
  have d := literal_shift_bound ch a b s q v hab (hq q h)
  exact (norm_le_insert' _ _).trans (add_le_add le_rfl d)

#print axioms literal_row_shift

/-- The logarithmic growth constants apply to every signed sequence bounded
in absolute value by 27, including the prime and all thirteen literal minorants.
The sets of moduli may overlap and the source residue is coherent. -/
theorem signed_moment_over_rows {ι : Type*} [DecidableEq ι] :
    ∃ P : ℕ, ∃ C : ℝ, 0 < C ∧
    ∀ (x : ℝ) (_hx : Real.exp 1 ≤ x) (h : Fin 39 → ℕ) (_hi : Function.Injective h)
      (i : Fin 39) (D E : Finset (Fin 38 → ℕ)) (F G : (Fin 38 → ℕ) → ℝ)
      (W v : ℕ) (_hW : 0 < W)
      (_hD : ∀ d ∈ D, Squarefree (∏ j, d j) ∧ Nat.Coprime (∏ j, d j) W)
      (_hE : ∀ e ∈ E, Squarefree (∏ j, e j) ∧ Nat.Coprime (∏ j, e j) W)
      (_hcover : ∀ a b, h a ≠ h b → ∀ p : ℕ, p.Prime → p ∣ Nat.dist (h a) (h b) → p ∣ W)
      (_hv : Nat.Coprime (v+h i) W) (I : Finset ℕ) (f : ℕ → ℝ)
      (_hI : ∀ n ∈ I, 0 < n+h i ∧ ((n+h i:ℕ):ℝ) ≤ 3*x)
      (_hf : ∀ n ∈ I, |f (n+h i)| ≤ 27)
      (_hrough : ∀ d ∈ D, ∀ e ∈ E, (∀ a b : Fin 38, a ≠ b → Nat.Coprime (d a) (e b)) →
        ∀ n ∈ I, f (n+h i) ≠ 0 →
          Nat.Coprime (n+h i) (W.lcm ((∏ j, d j).lcm (∏ j, e j))))
      (B₁ B₂ : ℝ) (_hB₁ : 0 ≤ B₁) (_hB₂ : 0 ≤ B₂)
      (_hF : ∀ d ∈ D, |F d| ≤ B₁) (_hG : ∀ e ∈ E, |G e| ≤ B₂)
      (primes : Finset ℕ) (_hp : ∀ p ∈ primes, p.Prime)
      (rows : Finset ι) (Q : ι → Finset ℕ)
      (_hcarrier : ∀ j ∈ rows, Q j ⊆ (∏ p ∈ primes, p).divisors)
      (_hlevel : ∀ j ∈ rows, Q j ⊆ Finset.Icc 1 ⌊x^(0.54:ℝ)⌋₊)
      (_hgate : ∀ d ∈ D, ∀ e ∈ E, (∀ a b : Fin 38, a ≠ b → Nat.Coprime (d a) (e b)) →
        F d ≠ 0 → G e ≠ 0 → ∃ j ∈ rows, W.lcm ((∏ j, d j).lcm (∏ j, e j)) ∈ Q j)
      (A : ℝ) (K : ι → ℝ) (_hK : 0 < ∑ j ∈ rows, K j)
      (_hsource : ∀ a, Nat.Coprime a (∏ p ∈ primes, p) → ∀ j ∈ rows,
        (∑ q ∈ Q j, ‖fullDiscrepancy (sample I (h i) f) q a‖) ≤
          K j*x/(Real.log x)^(2*A+(P:ℝ))),
      |(∑ n ∈ I, if Nat.ModEq W n v then f (n+h i) *
          (∑ d ∈ D, if ∀ j, d j ∣ n+h (i.succAbove j) then F d else 0) *
          (∑ e ∈ E, if ∀ j, e j ∣ n+h (i.succAbove j) then G e else 0) else 0) -
        ((∑ n ∈ I, f (n+h i))/(W.totient:ℝ)) *
          (∑ d ∈ D, ∑ e ∈ E, if ∀ a b : Fin 38, a ≠ b → Nat.Coprime (d a) (e b)
            then F d*G e/(∏ j, ((Nat.lcm (d j) (e j)).totient:ℝ)) else 0)| ≤
        B₁*B₂*((((∑ j ∈ rows, K j)+C)*x)/(Real.log x)^A) := by
  classical
  obtain ⟨P, C, hC, growth⟩ := weighted_fullDiscrepancy_positiveSupport_log_growth
    0.54 (by norm_num) (by norm_num) 0 26 0 3 (by norm_num)
  refine ⟨P, C*27, by positivity, ?_⟩
  intro x hx h hi i D E F G W v hW hD hE hcover hv I f hI hf hrough B₁ B₂
    hB₁ hB₂ hF hG primes hp rows Q hcarrier hlevel hgate A K hK hsource
  let S := rows.biUnion Q
  have incl {T : Finset ℕ} (ht : ∀ j ∈ rows, Q j ⊆ T) : S ⊆ T := by
    intro q hq
    obtain ⟨j,hj,hqj⟩ := Finset.mem_biUnion.mp hq
    exact ht j hj hqj
  let u := sample I (h i) f
  have support {n} (hn : n ∈ u.support) : n ∈ I.image (fun n => n+h i) := by
    by_contra hm
    exact (Finsupp.mem_support_iff.mp hn) (by simp [u, sample_value, hm])
  apply selberg38_coherent_weighted_moment_bound h hi i D E F G W v hW hD hE
    hcover hv I f hrough B₁ B₂ _ hB₁ hB₂ hF hG primes hp S (incl hcarrier)
    (fun d hd e he hc hfd hge => Finset.mem_biUnion.mpr (hgate d hd e he hc hfd hge))
  intro a ha
  have hcr := growth x hx 27 (by norm_num) S (incl hlevel) (fun _ => a)
    (fun q hq => ha.of_dvd_right (Nat.mem_divisors.mp (incl hcarrier hq)).1) u
  have hsupp : ∀ n ∈ u.support, 0 < n ∧ (n:ℝ) ≤ 3*x := by
    intro n hn
    obtain ⟨m,hm,rfl⟩ := Finset.mem_image.mp (support hn)
    exact hI m hm
  have henv : ∀ n ∈ u.support, ‖u n‖ ≤ 27*(n.divisors.card:ℝ)^0*(Real.log x)^(0:ℝ) := by
    intro n hn
    obtain ⟨m,hm,rfl⟩ := Finset.mem_image.mp (support hn)
    simpa [u, sample_value, Finset.mem_image_of_mem _ hm] using hf m hm
  have hraw := (cover_sum rows Q (fun q => ‖fullDiscrepancy u q a‖) (fun _ => norm_nonneg _)).trans
    (Finset.sum_le_sum (hsource a ha))
  rw [← Finset.sum_div, ← Finset.sum_mul] at hraw
  have hx1 := Real.one_lt_exp_iff.mpr zero_lt_one
  exact sum_divisor_weighted_log_saving_of_two_bounds S 13
    (fun q => ‖fullDiscrepancy u q a‖) (fun _ _ => norm_nonneg _) x (Real.log x) A
    _ _ P ((Real.exp_pos 1).le.trans hx) (Real.log_pos (hx1.trans_le hx)) hK
    (mul_pos hC (by norm_num)) hraw (hcr hsupp henv)

#print axioms signed_moment_over_rows
#print axioms Gate.size_after_presieve
end PrimeGap180.Signed
