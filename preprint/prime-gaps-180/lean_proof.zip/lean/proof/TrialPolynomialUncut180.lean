import TrialNativeRoleTotals180
import TrialShardScore180

/-! The native comparison now asks only for the directed values of five
explicit finite polynomial contractions, on the exact site grid chosen
by the consecutive physical-bin shards. -/
noncomputable section
open PrimeGap180.PackedSiteAudit PrimeGap180.Sector PrimeGap180.PackedLaw
namespace PrimeGap180.PolynomialUncut

def data (a : Array Chunk) := ShardScore.grid (chooseRow a)

/-- These endpoints are exact rationals from the serial 37-cap run. -/
structure Five (a : Array Chunk) : Prop where
  mass : NativeRoleTotals.ordinary (data a) ≤ ReferenceRoles.upperMass
  core : ReferenceRoles.lowerCore ≤ NativeRoleTotals.single (data a) 1
  first : ReferenceRoles.lowerA ≤ NativeRoleTotals.single (data a) 0
  last : ReferenceRoles.lowerB ≤ NativeRoleTotals.single (data a) (Fin.last 38)
  pair : NativeRoleTotals.pair (data a) ≤ ReferenceRoles.upperPair

theorem uncut (a : Array Chunk) (schema_ok : schema a=true) (checks : Five a) :
    1.00119224 * NumericalAccount.mass Restoration.original ≤ NumericalAccount.numerator Restoration.original := by
  apply ShardScore.uncut (chooseRow a) (fun j h => by simp [chooseRow,h])
    (fun j => checked_grid a schema_ok j.val j.isLt)
  · exact (NativeRoleTotals.mass_eq (data a)).le.trans checks.mass
  · exact checks.core.trans (NativeRoleTotals.single_eq (data a) 1).ge
  · exact checks.first.trans (NativeRoleTotals.single_eq (data a) 0).ge
  · exact checks.last.trans (NativeRoleTotals.single_eq (data a) (Fin.last 38)).ge
  · exact (NativeRoleTotals.pair_eq (data a)).le.trans checks.pair

#print axioms uncut
end PrimeGap180.PolynomialUncut
