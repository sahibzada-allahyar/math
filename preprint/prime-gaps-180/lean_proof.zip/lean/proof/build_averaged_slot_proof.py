"""Generate the six-term version of the pinned Type III distribution proof.

The input is a square estimate for one dyadic block of selected moduli.
Generated declarations retain the upstream coefficient arrays and moduli.
"""
import argparse
from hashlib import sha256
from pathlib import Path

from build_sampled_slot_proof import generate as generate_slots


DIGESTS = {
    "SelectedKernelBound": "4174edd39612155ec9635560287c49bedd501936df80ed1475d6d4030670fcdf",
    "DyadicKernelBound": "f4572fb7e164f7cd2778df42bdcbed7c2ad998327f100f2fea9275dabea3ba05",
    "KernelPowerBound": "afa585dacf4b0a60324918de9d80ce52c1296b5deb80b350d87f53cf8e72097a",
    "DenseKernelBound": "4cf6214f47bcddcc4f0cb8ca1786c49f90cb4c0d81b28d8b39ce7b19abb9df94",
    "LinearScale": "c3a5fa6a4206d4f1fbdc1f0fc152a2051bef878b5346ba78b6cc5e6e7c49d076",
    "FineBandKernel": "a1a5b422432911266ecb93196a01f66238679dfc6d467cfd60a48b8719e1e3a5",
    "NonzeroFourier": "f0112b72f85d4091f1a6eb5827179402822657c4b9ccd23407fcb8d9f4812548",
    "SampledFineBand": "cb5de5b9edc9558472ae2a61f2ecdd7ee29dfc242fe7965596b6098988264b6f",
}
PREMISE = "(hblock : SelectedBlockEstimate)"
HEADER = """import {dependency}

-- Derived from the pinned PrimeGaps186 and Sharifi 182 developments.
-- The original source notices and licenses apply.
noncomputable section
open scoped BigOperators Classical ContDiff NNReal Topology
open PrimeGap186 PrimeGap182.TypeIII PrimeGap182Audit UniqueFactorizationMonoid Filter
namespace PrimeGap180.Averaged
set_option backward.isDefEq.respectTransparency false
set_option backward.isDefEq.respectTransparency.types false
set_option maxHeartbeats 4000000
"""
FOOTER = "\nend PrimeGap180.Averaged\nend\n"


def declaration(root, module, name):
    data = (root / "formal" / f"TypeIII{module}.lean").read_bytes()
    if sha256(data).hexdigest() != DIGESTS[module]:
        raise ValueError(f"Unexpected source revision for {module}")
    source = data.decode()
    start = source.index("theorem " + name)
    return source[start:source.index("\n#print axioms", start)].rstrip()


def change_premise(text):
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if "hlocal : LocalFourierHypothesis" in line:
            if not line.strip().startswith("{C"):
                raise ValueError(line)
            lines[i] = "    " + PREMISE
    return "\n".join(lines).replace("hC₀ hlocal", "hblock")


def with_scales(text):
    # Keep replacement single-pass so changing the linear name never rewrites it twice.
    return (text.replace("selectedMomentScale", "selectedSixMoment")
            .replace("linearFiveScale", "linearSixScale").replace("fiveScale", "sixScale"))


def generate(root, destination):
    source = declaration(root, "SelectedKernelBound", "LocalFourierHypothesis.exists_selected_kernel_square_estimate")
    start = source.index("    {ε : ℝ}")
    signature = source[start:source.index(" := by")].replace("{ε : ℝ} (hε : 0 < ε) :", "∀ {ε : ℝ}, 0 < ε →", 1)
    block = "def SelectedBlockEstimate : Prop :=\n" + with_scales(signature)
    files = []
    previous = "TrialSixScale180"

    def emit(name, body, checks):
        nonlocal previous
        footer = "\n".join(f"#print axioms {n}" for n in checks)
        (destination / (name + ".lean")).write_text(HEADER.format(dependency=previous) + "\n"
            + body + "\n\n" + footer + FOOTER)
        previous = name
        files.append(name)

    definitions = [block]
    prior = "exists_selected_kernel_square_estimate"
    for module, name in (("DyadicKernelBound", "exists_dyadic_kernel_square_estimate"),
                         ("KernelPowerBound", "exists_selected_kernel_power_estimate"),
                         ("DenseKernelBound", "exists_dense_kernel_power_estimate")):
        proof = change_premise(declaration(root, module, "LocalFourierHypothesis." + name))
        proof = with_scales(proof.replace("theorem LocalFourierHypothesis.", "theorem "))
        invocation = "hblock" if module == "DyadicKernelBound" else prior + " hblock"
        proof = proof.replace("hlocal." + prior + " hC", invocation)
        proof = proof.replace("unfold selectedSixMoment nonzeroSGScale", "unfold selectedSixMoment selectedMomentScale nonzeroSGScale")
        definitions.append(proof)
        prior = name
    emit("TrialAveragedDense180", "\n\n".join(definitions), [prior])

    # Reuse the five original bad-divisor inequalities and add the sixth one
    # before the same square-root argument. All six positive terms share 1/(b sqrt B).
    normal = with_scales(declaration(root, "LinearScale", "kernelSquare_normalize"))
    normal = normal.replace("theorem kernelSquare_normalize", "theorem kernelSquareSix_normalize", 1)
    mark = "  have hsquares"
    index = normal.index(mark)
    normal = normal[:index] + """  let extra := H ^ (1/2 : ℝ) * M ^ (7/8 : ℝ) * Q ^ (5/4 : ℝ) * S ^ (3/16 : ℝ)
  let zextra := M ^ (7/4 : ℝ) * (Q/b) ^ (5/2 : ℝ) * S ^ (3/8 : ℝ)
  have he₆ : Hb * zextra ≤ (k * extra)^2 := by
    apply (Real.log_le_log_iff (by dsimp [zextra]; positivity) (by dsimp [k, extra]; positivity)).mp
    dsimp only [zextra, k, extra]
    rw [hHb]
    simp (disch := positivity) only [Real.log_mul, Real.log_div, Real.log_rpow,
      Real.log_pow, Real.log_sqrt, Nat.cast_ofNat]
    nlinarith only [hεlogx, hlogb]
""" + normal[index:]
    normal = (normal.replace("(k * w) ^ 2 ≤", "(k * w) ^ 2 + (k * extra)^2 ≤")
              .replace("u + v + w)", "u + v + w + extra)")
              .replace("k * v, k * w]", "k * v, k * w, k * extra]")
              .replace("dsimp <;> positivity", "dsimp [extra] <;> positivity")
              .replace("M ^ 2 * (Q / b))) ≤", "M ^ 2 * (Q / b)) + zextra) ≤")
              .replace("[h₁, h₂, h₃, h₄, h₅, hsquares]", "[h₁, h₂, h₃, h₄, h₅, he₆, hsquares]"))
    fine = with_scales(change_premise(declaration(root, "FineBandKernel",
        "LocalFourierHypothesis.exists_fineBand_weighted_kl3_estimate")))
    fine = (fine.replace("theorem LocalFourierHypothesis.", "theorem ")
            .replace("hlocal.exists_dense_kernel_power_estimate hC₀", "exists_dense_kernel_power_estimate hblock")
            .replace("kernelSquare_normalize", "kernelSquareSix_normalize"))
    emit("TrialAveragedWeights180", normal + "\n\n" + fine,
         ["kernelSquareSix_normalize", "exists_fineBand_weighted_kl3_estimate"])

    nonzero = with_scales(change_premise(declaration(root, "NonzeroFourier",
        "LocalFourierHypothesis.fineBand_nonzero_fourier_power_saving")))
    nonzero = (nonzero.replace("theorem LocalFourierHypothesis.", "theorem ")
               .replace("hlocal.exists_fineBand_weighted_kl3_estimate hC₀", "exists_fineBand_weighted_kl3_estimate hblock")
               .replace("10 * C ^ 8", "11 * C ^ 8").replace("640 * Cbad", "704 * Cbad"))
    start = nonzero.index("    exact normalized_cappedFiveScale_le")
    end = nonzero.index("  obtain", start)
    nonzero = nonzero[:start] + """    have old := normalized_cappedFiveScale_le hμ.le hμupper hδ hA hB hε hεcap
      hC hx hM0 hN0 hQ hMNlo hMNhi hNlow' hQup
    have extra := extra_capped_normalization hδ hA hB hε hεcap
      hC hx hM0 hN0 hQ hMNlo hMNhi hNlow' hQup
    dsimp only at old extra
    unfold linearSixScale
    rw [mul_add]
    dsimp only [s]
    linarith only [old, extra]
""" + nonzero[end:]
    emit("TrialAveragedFourier180", nonzero, ["fineBand_nonzero_fourier_power_saving"])

    sampled = change_premise(declaration(root, "SampledFineBand",
        "LocalFourierHypothesis.sampled_convolution_fineBand_discrepancy"))
    sampled = (sampled.replace("theorem LocalFourierHypothesis.", "theorem ")
               .replace("hlocal.fineBand_nonzero_fourier_power_saving hC₀", "fineBand_nonzero_fourier_power_saving hblock"))
    emit("TrialAveragedSampled180", sampled, ["sampled_convolution_fineBand_discrepancy"])
    slots = change_premise(generate_slots(root, "182"))
    begin = slots.index("theorem sampledGlobal")
    end = slots.index("#print axioms sampledGlobal", begin)
    slots = slots[begin:end].replace("hlocal.sampled_convolution_fineBand_discrepancy hC₀",
                                     "sampled_convolution_fineBand_discrepancy hblock")
    emit("TrialAveragedSlots180", slots, ["sampledGlobal", "sampledSlots"])
    return files


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    for filename in generate(args.source, args.destination):
        print(filename)
