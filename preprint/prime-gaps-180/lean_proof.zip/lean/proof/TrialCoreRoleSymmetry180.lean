import TrialReferenceRoles180
import Mathlib.Logic.Equiv.Fin.Basic

/-! The 37 interior faces have the same signed integral. The coordinate
permutation preserves the two distinct ordered endpoint polynomials. -/
noncomputable section
open scoped Classical BigOperators
open PrimeGap180.FrozenProfile PrimeGap180.DebitNativeClasses PrimeGap180.CoarseLaw
namespace PrimeGap180.ReferenceRoles

private def mid (k : Fin 37) : Fin 39 := k.castSucc.succ
private def swap (k : Fin 37) := Equiv.swap (mid k) (mid 0)
private def faceMap (k : Fin 37) (j : Fin 38) : Fin 38 :=
  (finSuccEquiv' (mid 0) (swap k ((mid k).succAbove j))).getD 0
private def faceInv (k : Fin 37) (j : Fin 38) : Fin 38 :=
  (finSuccEquiv' (mid k) (swap k ((mid 0).succAbove j))).getD 0

set_option maxRecDepth 6000 in
set_option maxHeartbeats 5000000 in
private theorem finite_coordinates : ∀ k : Fin 37,
    (swap k 0=0 ∧ swap k (Fin.last 38)=Fin.last 38 ∧ swap k (mid k)=mid 0) ∧
    (∀ j : Fin 37,swap k (mid j) = mid ((Equiv.swap k 0) j)) ∧
    (∀ j : Fin 38,(mid 0).succAbove (faceMap k j)=swap k ((mid k).succAbove j)) ∧
    (∀ j : Fin 38,faceInv k (faceMap k j)=j) ∧ (∀ j : Fin 38,faceMap k (faceInv k j)=j) := by
  decide +kernel

private def facePerm (k : Fin 37) : Equiv.Perm (Fin 38) where
  toFun := faceMap k
  invFun := faceInv k
  left_inv := (finite_coordinates k).2.2.2.1
  right_inv := (finite_coordinates k).2.2.2.2

private theorem max_perm {d : ℕ} (x : Fin d → Atom) (p : Equiv.Perm (Fin d)) :
    maximum (x ∘ p)=maximum x := by
  unfold maximum
  congr 1
  funext k
  apply Bool.eq_iff_iff.mpr
  simp only [decide_eq_true_eq,Function.comp_apply]
  constructor
  · intro h i
    obtain ⟨j,rfl⟩ := p.surjective i
    exact h j
  · exact fun h i => h (p i)

private theorem raw_perm (x : Fin 39 → Atom) (k : Fin 37) :
    rawAtom (x ∘ swap k)=rawAtom x := by
  have summ := Equiv.sum_comp (swap k) (fun j => (x j).1.val)
  let y (i : Fin 39) : ℝ := (((x i).1.val:ℝ)+1/2)*Native.step
  have sites := Equiv.prod_comp (swap k) (fun i => siteFactor (y i))
  have angular (e : ℕ) : (∑ j : Fin 37,y (swap k (mid j))^e) = ∑ j : Fin 37,y (mid j)^e := by
    simp only [(finite_coordinates k).2.1]
    exact Equiv.sum_comp (Equiv.swap k 0) (fun j : Fin 37 => y (mid j)^e)
  unfold rawAtom
  rw [max_perm]
  split
  · rfl
  · unfold FrozenProfile.raw FrozenProfile.amplitude
    simp only [Function.comp_apply,summ,sites,(finite_coordinates k).1.1,(finite_coordinates k).1.2.1]
    dsimp only [y,mid] at sites angular
    simp only [sites,angular]

private theorem insert_perm (k : Fin 37) (x : Fin 38 → Atom) (z : Atom) :
    (mid k).insertNth (α := fun _ => Atom) z (x ∘ facePerm k) =
      ((mid 0).insertNth (α := fun _ => Atom) z x) ∘ swap k := by
  funext i
  refine Fin.succAboveCases (mid k) ?_ (fun j => ?_) i
  · simp only [Function.comp_apply,(finite_coordinates k).1.2.2,Fin.insertNth_apply_same]
  · simp only [Fin.insertNth_apply_succAbove,Function.comp_apply]
    rw [←(finite_coordinates k).2.2.1 j,Fin.insertNth_apply_succAbove]
    rfl

/-- The face permutation also applies to the positive price replacement, which
uses the retained sector and total radius of the same 38 observed sites. -/
theorem interior_with_price (p : Fin 521 → ℕ → ℝ) (v : Atom → ℝ) (k : Fin 37) :
    (∑ x : Fin 38 → Atom,p (sectorAtom x) (retained x)*(singleN v (mid k) x)^2*∏ j,v (x j)) =
    ∑ x : Fin 38 → Atom,p (sectorAtom x) (retained x)*(singleN v (mid 0) x)^2*∏ j,v (x j) := by
  let e : (Fin 38 → Atom) ≃ (Fin 38 → Atom) :=
    { toFun := fun x => x ∘ facePerm k
      invFun := fun x => x ∘ (facePerm k).symm
      left_inv := fun x => by funext i; simp
      right_inv := fun x => by funext i; simp }
  rw [←Equiv.sum_comp e]
  apply Finset.sum_congr rfl
  intro x _
  change p (sectorAtom (x ∘ facePerm k)) (retained (x ∘ facePerm k))*
    (singleN v (mid k) (x ∘ facePerm k))^2*∏ j,v (x (facePerm k j))=_
  have sum := Equiv.sum_comp (facePerm k) (fun i => (x i).1.val)
  have retain : retained (x ∘ facePerm k)=retained x := sum
  have sector : sectorAtom (x ∘ facePerm k)=sectorAtom x := by unfold sectorAtom; rw [max_perm,retain]
  have inner : singleN v (mid k) (x ∘ facePerm k) = singleN v (mid 0) x := by
    unfold singleN
    apply Finset.sum_congr rfl
    intro z _
    rw [insert_perm]
    exact congrArg (v z*·) (raw_perm _ k)
  rw [sector,retain,inner,Equiv.prod_comp (facePerm k) (fun j => v (x j))]

theorem interior_same (κ : ℝ) (v : Atom → ℝ) (k : Fin 37) :
    single κ v (mid k) = single κ v (mid 0) :=
  interior_with_price (fun s j => κ*NativeContractions.price s j) v k

theorem interior_lower (κ : ℝ) (v : Atom → ℝ) (x : ℝ)
    (one : x ≤ single κ v (1 : Fin 39)) (k : Fin 37) :
    x ≤ single κ v k.castSucc.succ := by
  change x ≤ single κ v (mid k)
  rw [interior_same]
  exact one

#print axioms interior_lower
end PrimeGap180.ReferenceRoles
