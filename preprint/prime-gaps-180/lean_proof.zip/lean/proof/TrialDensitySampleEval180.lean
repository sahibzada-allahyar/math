import Init
namespace PrimeGap180.PackedFive
def b : Int := 2^320
def factor (x a c d e f : Int) := a+c*x+d*b^2601+e*b+f*b^51
def sample (x : Int) : Int :=
  let k := (12^5:Int)
  let product := factor x 12 (-24) (-9) (-4) (-4) * factor x 12 6 (-9) (-4) (-4) *
    factor x 12 6 6 (-4) (-4) * factor x 12 6 6 6 (-4) * factor x 12 6 6 6 16
  (List.range 11).foldl (fun s j => s+k^(10-j)*(k-product)^j) 0
def unsignedEval (x : Int) (c : List Int) := c.foldr (fun a s => a+x*s) 0
end PrimeGap180.PackedFive
