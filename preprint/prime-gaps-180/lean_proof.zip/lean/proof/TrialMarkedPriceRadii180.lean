import TrialApplyBook180
import TrialPackedLedger180
namespace PrimeGap180.PriceRadii
open Book PackedLedger

def physicalTicks : Array Nat := archiveRadii% (include_str "../data/h1_priced_168_table.json")
def classes : Array Nat := #[2001,2101,2151,2201,2251,2301,2327,2351,2369,2375,2401,2411,2435,2437,2445,2447,2449,2451,2452,2475,2486,2492,2501,2515,2521,2526,2533,2551,2555,2557,2567,2568,2580,2601,2609,2613,2642,2649,2651,2682,2690,2701,2719,2723,2731,2751,2759,2799,2801]

theorem physical_cap (s : Book.Label) : capR s = (physicalTicks[s.val]!:ℝ)/10000 := rfl

noncomputable def id (s : Book.Label) := raw.radiusIndex[s.val]!

set_option maxRecDepth 65536 in
set_option maxHeartbeats 0 in
theorem classified : ∀ s : Book.Label, id s < 49 ∧ physicalTicks[s.val]! = classes[id s]! := by decide +kernel

#print axioms classified
end PrimeGap180.PriceRadii
