import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G180
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 180

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G180

namespace PrimeGap180.PriceIsolatedGroup.G185
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 185

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G185

namespace PrimeGap180.PriceIsolatedGroup.G190
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 190

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G190

namespace PrimeGap180.PriceIsolatedGroup.G195
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 195

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G195
