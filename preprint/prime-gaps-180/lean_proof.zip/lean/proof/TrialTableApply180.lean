import TrialMarkedKernelReduction180
import TrialTablePriceCensus180
namespace PrimeGap180.TablePrices
open Book ClippedPair
private noncomputable def classOf (s : SectorId) : Fin 49 := ⟨PriceRadii.id s.val,(PriceRadii.classified _).1⟩

private theorem cap_eq (s : SectorId) : (capOf (classOf s):ℝ) = Book.capR s.val := by
  unfold capOf
  push_cast
  rw [PriceRadii.physical_cap,(PriceRadii.classified _).2]
  rfl

private theorem budget_eq (row : FiveRow) (s : SectorId) :
    (ratioQ row (classOf s):ℝ) = MarkedKernelReduction.budget row s := by
  cases row <;> unfold ratioQ <;> dsimp only <;> push_cast <;> rfl

theorem tables_of_certified (all_certified : ∀ n : Fin 25, certified n) : MarkedKernelReduction.TableBounds := by
  intro row s
  have h := all_certified (code row)
  have z := paid (code row) (classOf s) h.1 (h.2 (classOf s))
  rw [row_code] at z
  have r : (table row (capOf (classOf s)):ℝ) ≤ (ratioQ row (classOf s):ℝ) := Rat.cast_le.mpr z
  rw [table_eq,budget_eq,cap_eq] at r
  change frozenPairPrice row (Book.coverWeights row) (Book.capR s.val) ≤ _
  exact r


#print axioms tables_of_certified
end PrimeGap180.TablePrices
