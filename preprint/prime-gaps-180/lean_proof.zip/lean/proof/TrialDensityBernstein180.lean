import TrialDensityRemainder180

noncomputable section
namespace PrimeGap180.DensitySimplex

/-- The five homogeneous linear forms give the normalized exponents at the vertices
of the gap simplex with radius 1/10. All coefficients use the denominator 120. -/
def fiveNumerator (v w x y z : ℝ) : ℝ :=
  (120*v+96*w+111*x+116*y+116*z) *
  (120*v+126*w+111*x+116*y+116*z) *
  (120*v+126*w+126*x+116*y+116*z) *
  (120*v+126*w+126*x+126*y+116*z) *
  (120*v+126*w+126*x+126*y+136*z)

set_option maxHeartbeats 12000000 in
private theorem lower_five (v w x y z : ℝ) (hv : 0 ≤ v) (hw : 0 ≤ w)
    (hx : 0 ≤ x) (hy : 0 ≤ y) (hz : 0 ≤ z) :
    31 * (120*(v+w+x+y+z))^5 ≤ 32*fiveNumerator v w x y z := by
  apply sub_nonneg.mp
  unfold fiveNumerator
  ring_nf
  positivity

set_option maxHeartbeats 12000000 in
private theorem upper_five (v w x y z : ℝ) (hv : 0 ≤ v) (hw : 0 ≤ w)
    (hx : 0 ≤ x) (hy : 0 ≤ y) (hz : 0 ≤ z) :
    32*fiveNumerator v w x y z ≤ 33 * (120*(v+w+x+y+z))^5 := by
  apply sub_nonneg.mp
  unfold fiveNumerator
  ring_nf
  positivity

def fiveDen (z : Fin 4 → ℝ) : ℝ :=
  fiveNumerator (1-10*(z 0+z 1+z 2+z 3)) (10*z 0) (10*z 1) (10*z 2) (10*z 3) / 120^5

theorem fiveDen_error {t : ℝ} (ht : t ≤ 1/10) (z : Fin 4 → ℝ) (hz : z ∈ region 4 t) :
    |1-fiveDen z| ≤ 1/32 := by
  let v := 1-10*(z 0+z 1+z 2+z 3)
  have hv : 0 ≤ v := by
    have h := hz.2
    rw [Fin.sum_univ_four] at h
    dsimp [v]
    linarith
  have nonneg (i : Fin 4) : 0 ≤ 10*z i := mul_nonneg (by norm_num) (hz.1 i).le
  have l := lower_five v _ _ _ _ hv (nonneg 0) (nonneg 1) (nonneg 2) (nonneg 3)
  have u := upper_five v _ _ _ _ hv (nonneg 0) (nonneg 1) (nonneg 2) (nonneg 3)
  have partition : v+10*z 0+10*z 1+10*z 2+10*z 3 = 1 := by dsimp [v]; ring
  rw [partition] at l u
  change |1-fiveNumerator v _ _ _ _ / 120^5| ≤ 1/32
  rw [abs_le]
  constructor <;> linarith

#print axioms fiveDen_error
end PrimeGap180.DensitySimplex
