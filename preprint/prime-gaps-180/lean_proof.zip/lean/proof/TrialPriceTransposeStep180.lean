import TrialPriceAffineScatter180
import Mathlib.Tactic.Ring

namespace PrimeGap180.PriceTranspose
open PriceAffineScatter

def width := 16777216
def addr (r c b : Nat) := 32768*r + 64*c+b
def scale (k : Nat) := 2^k
def distance (k : Nat) := 32704*scale k

def firstBand (p d : Nat) := copies (2*p) d (2^p-1)
def lastBand (p d : Nat) := copies (2*p) d ((2^p-1) <<< p)

private theorem small_word (p : Nat) : 2^p-1 < 2^p := by have := Nat.two_pow_pos p; omega
private theorem first_word (p : Nat) : 2^p-1 < 2^(2*p) :=
  Nat.lt_of_lt_of_le (small_word p) (Nat.pow_le_pow_right (by decide) (by omega))
private theorem last_word (p : Nat) : ((2^p-1) <<< p) < 2^(2*p) := by
  rw [Nat.shiftLeft_eq,show 2*p=p+p by omega,Nat.pow_add]
  exact Nat.mul_lt_mul_of_pos_right (small_word p) (Nat.two_pow_pos p)

theorem first_bit (p d i : Nat) (hi : i < 2*p*2^d) :
    (firstBand p d).testBit i = decide (i%(2*p)<p) := by
  rw [firstBand,copies_bit (first_word p),if_pos hi,Nat.testBit_two_pow_sub_one]

theorem last_bit (p d i : Nat) (hp : 0<p) (hi : i < 2*p*2^d) :
    (lastBand p d).testBit i = decide (p ≤ i%(2*p)) := by
  rw [lastBand,copies_bit (last_word p),if_pos hi,Nat.testBit_shiftLeft,Nat.testBit_two_pow_sub_one]
  have bound := Nat.mod_lt i (by omega : 0<2*p)
  by_cases h : p ≤ i%(2*p)
  · have h' : i%(2*p)-p < p := by omega
    simp [h,h']
  · simp [h]

/-- Select rows and columns whose index bit `k` differs, in either direction. -/
def lower (k : Nat) := lastBand (64*scale k) (17-k) &&& firstBand (32768*scale k) (8-k)
def upper (k : Nat) := firstBand (64*scale k) (17-k) &&& lastBand (32768*scale k) (8-k)
def keep (k : Nat) := (2^width-1) ^^^ (lower k ||| upper k)

def step (k z : Nat) : Nat :=
  (z &&& keep k) ||| ((z >>> distance k) &&& lower k) ||| ((z <<< distance k) &&& upper k)

private theorem periods : ∀ k : Fin 9,
    2*(64*scale k.val)*2^(17-k.val) = width ∧
    2*(32768*scale k.val)*2^(8-k.val) = width ∧
    128*scale k.val ∣ 32768 := by decide +kernel

private theorem rem (period mult rest : Nat) (small : rest<period) :
    (period*mult+rest)%period = rest := by
  rw [Nat.add_comm,Nat.add_mul_mod_self_left,Nat.mod_eq_of_lt small]

private theorem col_rem (s r c b : Nat) (positive : 0<s) (aligned : 128*s ∣ 32768) (bb : b<64) :
    addr r c b % (128*s) = 64*(c%(2*s))+b := by
  obtain ⟨u,hu⟩ := aligned
  have decomp := Nat.div_add_mod c (2*s)
  have form : addr r c b = (128*s)*(u*r+c/(2*s))+(64*(c%(2*s))+b) := by
    calc addr r c b = 32768*r + 64*((2*s)*(c/(2*s))+c%(2*s))+b := by rw [decomp];rfl
         _ = _ := by rw [hu];ring
  rw [form,rem]
  have bound := Nat.mod_lt c (by omega : 0<2*s)
  omega

private theorem row_rem (s r c b : Nat) (positive : 0<s) (cc : c<512) (bb : b<64) :
    addr r c b % (65536*s) = 32768*(r%(2*s))+(64*c+b) := by
  have decomp := Nat.div_add_mod r (2*s)
  have form : addr r c b = (65536*s)*(r/(2*s))+(32768*(r%(2*s))+(64*c+b)) := by
    calc addr r c b = 32768*((2*s)*(r/(2*s))+r%(2*s)) + 64*c+b := by rw [decomp];rfl
         _ = _ := by ring
  rw [form,rem]
  have bound := Nat.mod_lt r (by omega : 0<2*s)
  omega

def high (s i : Nat) : Bool := decide (s≤i%(2*s))

theorem masks (k : Fin 9) (r c b : Nat) (rr : r<512) (cc : c<512) (bb : b<64) :
    (lower k.val).testBit (addr r c b) = (high (scale k.val) c && !high (scale k.val) r) ∧
    (upper k.val).testBit (addr r c b) = (!high (scale k.val) c && high (scale k.val) r) := by
  let s := scale k.val
  have positive : 0<s := Nat.two_pow_pos k.val
  have ai : addr r c b < width := by dsimp [addr,width];omega
  have hcol : addr r c b < 2*(64*s)*2^(17-k.val) := by rw [(periods k).1];exact ai
  have hrow : addr r c b < 2*(32768*s)*2^(8-k.val) := by rw [(periods k).2.1];exact ai
  have hc := col_rem s r c b positive (periods k).2.2 bb
  have hr := row_rem s r c b positive cc bb
  have fc : (firstBand (64*s) (17-k.val)).testBit (addr r c b) = !high s c := by
    rw [first_bit _ _ _ hcol,show 2*(64*s)=128*s by omega,hc]
    by_cases hx : s≤c%(2*s) <;> simp [high,hx] <;> omega
  have lc : (lastBand (64*s) (17-k.val)).testBit (addr r c b) = high s c := by
    rw [last_bit _ _ _ (by omega) hcol,show 2*(64*s)=128*s by omega,hc]
    by_cases hx : s≤c%(2*s) <;> simp [high,hx] <;> omega
  have fr : (firstBand (32768*s) (8-k.val)).testBit (addr r c b) = !high s r := by
    rw [first_bit _ _ _ hrow,show 2*(32768*s)=65536*s by omega,hr]
    by_cases hx : s≤r%(2*s) <;> simp [high,hx] <;> omega
  have lr : (lastBand (32768*s) (8-k.val)).testBit (addr r c b) = high s r := by
    rw [last_bit _ _ _ (by omega) hrow,show 2*(32768*s)=65536*s by omega,hr]
    by_cases hx : s≤r%(2*s) <;> simp [high,hx] <;> omega
  exact ⟨by rw [lower,Nat.testBit_and,lc,fr],by rw [upper,Nat.testBit_and,fc,lr]⟩

#print axioms masks
end PrimeGap180.PriceTranspose
