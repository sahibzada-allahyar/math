import TrialPriceScalar180
namespace PrimeGap180.PriceExactCensus
set_option maxHeartbeats 100000000
set_option maxRecDepth 65536
private theorem c352 : PriceScalar.checked (352 : Book.Label) = true := by decide +kernel
private theorem c353 : PriceScalar.checked (353 : Book.Label) = true := by decide +kernel
private theorem c354 : PriceScalar.checked (354 : Book.Label) = true := by decide +kernel
private theorem c355 : PriceScalar.checked (355 : Book.Label) = true := by decide +kernel
private theorem c356 : PriceScalar.checked (356 : Book.Label) = true := by decide +kernel
private theorem c357 : PriceScalar.checked (357 : Book.Label) = true := by decide +kernel
private theorem c358 : PriceScalar.checked (358 : Book.Label) = true := by decide +kernel
private theorem c359 : PriceScalar.checked (359 : Book.Label) = true := by decide +kernel
private theorem c360 : PriceScalar.checked (360 : Book.Label) = true := by decide +kernel
private theorem c361 : PriceScalar.checked (361 : Book.Label) = true := by decide +kernel
private theorem c362 : PriceScalar.checked (362 : Book.Label) = true := by decide +kernel
private theorem c363 : PriceScalar.checked (363 : Book.Label) = true := by decide +kernel
private theorem c364 : PriceScalar.checked (364 : Book.Label) = true := by decide +kernel
private theorem c365 : PriceScalar.checked (365 : Book.Label) = true := by decide +kernel
private theorem c366 : PriceScalar.checked (366 : Book.Label) = true := by decide +kernel
private theorem c367 : PriceScalar.checked (367 : Book.Label) = true := by decide +kernel
private theorem c368 : PriceScalar.checked (368 : Book.Label) = true := by decide +kernel
private theorem c369 : PriceScalar.checked (369 : Book.Label) = true := by decide +kernel
private theorem c370 : PriceScalar.checked (370 : Book.Label) = true := by decide +kernel
private theorem c371 : PriceScalar.checked (371 : Book.Label) = true := by decide +kernel
private theorem c372 : PriceScalar.checked (372 : Book.Label) = true := by decide +kernel
private theorem c373 : PriceScalar.checked (373 : Book.Label) = true := by decide +kernel
private theorem c374 : PriceScalar.checked (374 : Book.Label) = true := by decide +kernel
private theorem c375 : PriceScalar.checked (375 : Book.Label) = true := by decide +kernel
private theorem c376 : PriceScalar.checked (376 : Book.Label) = true := by decide +kernel
private theorem c377 : PriceScalar.checked (377 : Book.Label) = true := by decide +kernel
private theorem c378 : PriceScalar.checked (378 : Book.Label) = true := by decide +kernel
private theorem c379 : PriceScalar.checked (379 : Book.Label) = true := by decide +kernel
private theorem c380 : PriceScalar.checked (380 : Book.Label) = true := by decide +kernel
private theorem c381 : PriceScalar.checked (381 : Book.Label) = true := by decide +kernel
private theorem c382 : PriceScalar.checked (382 : Book.Label) = true := by decide +kernel
private theorem c383 : PriceScalar.checked (383 : Book.Label) = true := by decide +kernel
theorem block11 : ∀ i : Fin 32, PriceScalar.checked ⟨352+i.val,by omega⟩ = true :=
  Fin.cases c352 (Fin.cases c353 (Fin.cases c354 (Fin.cases c355 (Fin.cases c356 (Fin.cases c357 (Fin.cases c358 (Fin.cases c359 (Fin.cases c360 (Fin.cases c361 (Fin.cases c362 (Fin.cases c363 (Fin.cases c364 (Fin.cases c365 (Fin.cases c366 (Fin.cases c367 (Fin.cases c368 (Fin.cases c369 (Fin.cases c370 (Fin.cases c371 (Fin.cases c372 (Fin.cases c373 (Fin.cases c374 (Fin.cases c375 (Fin.cases c376 (Fin.cases c377 (Fin.cases c378 (Fin.cases c379 (Fin.cases c380 (Fin.cases c381 (Fin.cases c382 (Fin.cases c383 (fun i => Fin.elim0 i))))))))))))))))))))))))))))))))
#print axioms block11
end PrimeGap180.PriceExactCensus
