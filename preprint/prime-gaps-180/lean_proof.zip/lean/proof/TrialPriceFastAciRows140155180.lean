import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G140
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 140

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G140

namespace PrimeGap180.PriceIsolatedGroup.G145
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 145

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G145

namespace PrimeGap180.PriceIsolatedGroup.G150
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 150

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G150

namespace PrimeGap180.PriceIsolatedGroup.G155
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 155

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G155
