import TrialLaterLowFixedGrid180
namespace PrimeGap180.LaterLowFixed
set_option maxHeartbeats 0
set_option maxRecDepth 131072

theorem scalar_row_07 : bookU 40000 5 0 = 9735286871469661665597 ∧ bookU 40000 5 805 = 1167802882257556116479 ∧
    rawQ 50000 5 805 9735286871469661665597 1167802882257556116479 * 100^39 / (94.17312:ℚ) ≤ 3586486591/10^18 := by decide +kernel

#print axioms scalar_row_07
end PrimeGap180.LaterLowFixed
