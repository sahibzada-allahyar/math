import TrialFrozenData180
import Mathlib.MeasureTheory.Function.Floor

/-! The native-cell score uses the same signed, restored fibre numerators
as the arithmetic theorem. Only the kernel arguments move to adverse cell edges. -/
noncomputable section
open scoped Classical BigOperators Topology
open Filter MeasureTheory PrimeGap186 PrimeGap180.Sector PrimeGap180.FrozenData
open PrimeGap180.EndpointPhysical PrimeGap180.Detection
namespace PrimeGap180.AdverseScore

abbrev Bands := Band 216
abbrev law := bandLaw mesh
abbrev prodLaw (d : ℕ) := Measure.pi (fun _ : Fin d => law)
private def cut (c q : ℝ) := min c (max 0 q)
private def kernel (c q : ℝ) := 1/(ledger-cut c q)
private def native {d : ℕ} (r : Fin d → Bands) := Native.adverse (d := d) (Native.cellSum r)

private theorem nativeMeasurable (d : ℕ) : Measurable (@native d) := by
  unfold native Native.adverse Native.cellSum Native.cell
  fun_prop

private theorem kernel_nonneg {c : ℝ} (room : c < ledger) (q : ℝ) : 0 ≤ kernel c q :=
  one_div_nonneg.mpr (sub_nonneg.mpr ((min_le_left c _).trans room.le))

private theorem kernel_mono {c : ℝ} (room : c < ledger) : Monotone (kernel c) := by
  intro q r qr
  exact one_div_le_one_div_of_le (sub_pos.mpr ((min_le_left c _).trans_lt room))
    (sub_le_sub_left (min_le_min_left c (max_le_max_left 0 qr)) _)

private theorem kernel_cont {c : ℝ} (room : c < ledger) : Continuous (kernel c) := by
  apply Continuous.div continuous_const (by unfold cut; fun_prop)
  exact fun q => (sub_pos.mpr ((min_le_left c _).trans_lt room)).ne'

private theorem kernel_bounded {c : ℝ} (room : c < ledger) : Bornology.IsBounded (Set.range (kernel c)) := by
  apply isBounded_iff_forall_norm_le.mpr
  refine ⟨1/(ledger-c),?_⟩
  rintro _ ⟨q,rfl⟩
  rw [Real.norm_eq_abs,abs_of_nonneg (kernel_nonneg room q)]
  exact one_div_le_one_div_of_le (sub_pos.mpr room) (sub_le_sub_left (min_le_left _ _) _)

private theorem average {α β : Type*} [MeasurableSpace α] [MeasurableSpace β] (μ : Measure β)
    [IsFiniteMeasure μ] (F : α × β → ℝ) (mf : Measurable F) (bf : Bornology.IsBounded (Set.range F)) :
    Measurable (fun x => ∫ t, F (x,t) ∂μ) ∧ Bornology.IsBounded (Set.range (fun x => ∫ t, F (x,t) ∂μ)) := by
  refine ⟨mf.stronglyMeasurable.integral_prod_right'.measurable,isBounded_iff_forall_norm_le.mpr ?_⟩
  obtain ⟨C,_,bound⟩ := bf.exists_pos_norm_le
  refine ⟨C*μ.real Set.univ,?_⟩
  rintro _ ⟨x,rfl⟩
  exact norm_integral_le_of_norm_le_const (Eventually.of_forall fun t => bound _ ⟨(x,t),rfl⟩)

private theorem weighted_integrable {α : Type*} [MeasurableSpace α] (μ : Measure α) [IsFiniteMeasure μ]
    (K V : α → ℝ) (mk : Measurable K) (bk : Bornology.IsBounded (Set.range K))
    (mv : Measurable V) (bv : Bornology.IsBounded (Set.range V)) :
    Integrable (fun r => K r*(V r)^2) μ := by
  apply integrable_of_measurable_of_bounded_range _ _ (mk.mul (mv.pow_const 2))
  obtain ⟨C,hC,c⟩ := bk.exists_pos_norm_le
  obtain ⟨D,hD,d⟩ := bv.exists_pos_norm_le
  apply isBounded_iff_forall_norm_le.mpr
  refine ⟨C*D^2,?_⟩
  rintro _ ⟨x,rfl⟩
  change ‖K x*(V x)^2‖ ≤ _
  rw [norm_mul,norm_pow]
  exact mul_le_mul (c _ ⟨x,rfl⟩) (pow_le_pow_left₀ (norm_nonneg _) (d _ ⟨x,rfl⟩) 2) (by positivity) hC.le

private def V (i : Fin 39) (s : Fin 521) := integralFace mesh i (restrictFace i (fun r => label r=s) trial)

private theorem V_regular (i : Fin 39) (s : Fin 521) : Measurable (V i s) ∧ Bornology.IsBounded (Set.range (V i s)) := by
  let := bandLaw_finite mesh
  let F := restrictFace i (fun r => label r=s) trial
  have reg := FrozenData.signed_regular i (fun _ => 1) (fun z => z=s)
  have mF : Measurable F := by simpa only [one_mul] using reg.1
  have bF : Bornology.IsBounded (Set.range F) := by simpa only [one_mul] using reg.2.1
  let ins := fun p : (Fin 38 → Bands) × Bands => i.insertNth (α := fun _ => Bands) p.2 p.1
  have mi : Measurable ins := (continuous_snd.finInsertNth i continuous_fst).measurable
  exact average law (F ∘ ins) (mF.comp mi) (bF.subset (Set.range_comp_subset_range _ _))

private theorem fibre_room (i : Fin 39) (s : Fin 521) (t : Fin 38 → Bands) (nz : V i s t ≠ 0) :
    (0 ≤ retainedRadius t ∧ retainedRadius t ≤ 0.2801) ∧ native t ≤ 0.2801 := by
  have witness : ∃ u : Bands, trial (i.insertNth (α := fun _ => Bands) u t) ≠ 0 := by
    by_contra! mute
    apply nz
    simp [V,integralFace,restrictFace,mute]
  obtain ⟨u,hit⟩ := witness
  have a := FrozenData.trial_support i _ hit
  have b := FrozenData.retained_adverse _ (ite_ne_right_iff.mp hit).2 i
  simp only [Fin.removeNth_insertNth] at a b
  exact ⟨⟨a.1,a.2.trans (Book.capR_bound _)⟩,b.trans (Book.capR_bound _)⟩

def income (i : Fin 39) := (∑ s : Fin 521,
    ((archivedPrice s).1*(∫ t, (V i s t)^2 ∂prodLaw 38) +
    (archivedPrice s).2*(∫ t, kernel 0.2801 (native t)*(V i s t)^2 ∂prodLaw 38)))/(10^14:ℝ)

-- The stored slope sign is verified from the integer literals.
set_option maxRecDepth 8192 in
set_option maxHeartbeats 1000000 in
private theorem nonpos : ∀ s : Fin 521, (archivedPrice s).2 ≤ 0 := by decide

theorem native_kernel_on_fibre (i : Fin 39) (s : Fin 521) (t : Fin 38 → Bands) (nz : V i s t ≠ 0) :
    kernel 0.2801 (native t) = primePrice (native t) := by
  obtain ⟨⟨lo,_⟩,up⟩ := fibre_room i s t nz
  have nn : 0 ≤ native t := lo.trans (Native.retained_le_cell t)
  simp only [kernel,cut,max_eq_right nn,min_eq_right up,primePrice,ledger]
  norm_num

theorem income_le (i : Fin 39) : income i ≤ shiftIncome mesh trial i label := by
  let := bandLaw_finite mesh
  apply div_le_div_of_nonneg_right _ (by norm_num)
  apply Finset.sum_le_sum
  intro s _
  apply add_le_add_right
  apply mul_le_mul_of_nonpos_left _ (by exact_mod_cast nonpos s)
  have room : (0.2801:ℝ) < ledger := by norm_num [ledger]
  obtain ⟨mv,bv⟩ := V_regular i s
  have bK := (kernel_bounded room).subset (Set.range_comp_subset_range (native (d := 38)) (kernel 0.2801))
  have intg := weighted_integrable (prodLaw 38) ((kernel 0.2801) ∘ native) (V i s)
    ((kernel_cont room).measurable.comp (nativeMeasurable 38)) bK mv bv
  have eq (t : Fin 38 → Bands) : primePrice (retainedRadius t)*(V i s t)^2 =
      kernel 0.2801 (retainedRadius t)*(V i s t)^2 := by
    by_cases z : V i s t = 0
    · simp [z]
    · obtain ⟨⟨lo,hi⟩,_⟩ := fibre_room i s t z
      simp only [primePrice,kernel,cut,max_eq_right lo,min_eq_right hi,ledger]
      norm_num
  change (∫ t, primePrice (retainedRadius t)*(V i s t)^2 ∂prodLaw 38) ≤ _
  simp_rw [eq]
  apply integral_mono_of_nonneg (ae_of_all _ fun t => mul_nonneg (kernel_nonneg room _) (sq_nonneg _)) intg
  exact ae_of_all _ fun t => mul_le_mul_of_nonneg_right (kernel_mono room (Native.retained_le_cell t)) (sq_nonneg _)

private def B (r : Fin 37 → Bands) := ∫ l, ∫ h, trial (join r l h) ∂law ∂law

private theorem B_regular : Measurable B ∧ Bornology.IsBounded (Set.range B) := by
  let := bandLaw_finite mesh
  let j := fun p : ((Fin 37 → Bands) × Bands) × Bands => join p.1.1 p.1.2 p.2
  have cj : Continuous j := by dsimp [j,EndpointPhysical.join]; fun_prop
  have inn := average law (trial ∘ j) (trial_regular.1.comp cj.measurable) (trial_bounded.subset (Set.range_comp_subset_range _ _))
  exact average law _ inn.1 inn.2

private def pairNative (r : Fin 37 → Bands) := 2*rho^2*(kernel radiusCap (native r))^2

def endpoint := ∫ r, pairNative r*(B r)^2 ∂prodLaw 37

theorem endpoint_le : endpointCost mesh trial ≤ endpoint := by
  let := bandLaw_finite mesh
  have room : radiusCap < ledger := by norm_num [radiusCap,ledger]
  have meas : Measurable pairNative := (measurable_const.mul (((kernel_cont room).measurable.comp (nativeMeasurable 37)).pow_const 2))
  have bb : Bornology.IsBounded (Set.range pairNative) := by
    obtain ⟨C,hC,c⟩ := (kernel_bounded room).exists_pos_norm_le
    apply isBounded_iff_forall_norm_le.mpr
    refine ⟨2*rho^2*C^2,?_⟩
    rintro _ ⟨r,rfl⟩
    change ‖2*rho^2*(kernel radiusCap (native r))^2‖ ≤ _
    rw [norm_mul,norm_pow,Real.norm_eq_abs,abs_of_nonneg (by positivity)]
    exact mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (norm_nonneg _) (c _ ⟨native r,rfl⟩) 2) (by positivity)
  have integr := weighted_integrable (prodLaw 37) pairNative B meas bb B_regular.1 B_regular.2
  apply integral_mono_of_nonneg (ae_of_all _ fun r => mul_nonneg (by unfold pairPrice; positivity) (sq_nonneg _)) integr
  apply ae_of_all
  intro r
  apply mul_le_mul_of_nonneg_right _ (sq_nonneg (B r))
  have lower := kernel_mono room (Native.physical_le_adverse r)
  have hsq := pow_le_pow_left₀ (kernel_nonneg room (Native.physical r)) lower 2
  convert mul_le_mul_of_nonneg_left hsq (by positivity : 0 ≤ 2*rho^2) using 1 <;>
    simp [pairNative,pairPrice,Native.physical,kernel,cut,native,div_eq_mul_inv]

theorem physical_margin_of_native (h : (∫ v, (trial v)^2 ∂prodLaw 39) + endpoint < rho*∑ i, income i) :
    (∫ v, (trial v)^2 ∂prodLaw 39) + endpointCost mesh trial < rho*∑ i : Fin 39, shiftIncome mesh trial i label :=
  lt_of_le_of_lt (add_le_add_right endpoint_le _) (h.trans_le (mul_le_mul_of_nonneg_left
    (Finset.sum_le_sum fun i _ => income_le i) (by norm_num [rho])))

/-- These are the three native receipt kernels before the common factor
100^39. They have no clamping, including outside the nonzero fibres. -/
def cellIncome (i : Fin 39) := (∑ s : Fin 521,
    ((archivedPrice s).1*(∫ t, (V i s t)^2 ∂prodLaw 38) +
    (archivedPrice s).2*(∫ t, primePrice (Native.adverse (d := 38) (Native.cellSum t))*(V i s t)^2 ∂prodLaw 38)))/(10^14:ℝ)

def cellEndpoint := ∫ r, (2*rho^2/(ledger-Native.adverse (d := 37) (Native.cellSum r))^2)*(B r)^2 ∂prodLaw 37

theorem income_exact (i : Fin 39) : income i = cellIncome i := by
  apply congrArg (fun v : ℝ => v/(10^14:ℝ))
  apply Finset.sum_congr rfl
  intro s _
  have eq : (∫ t, kernel 0.2801 (native t)*(V i s t)^2 ∂prodLaw 38) =
      ∫ t, primePrice (native t)*(V i s t)^2 ∂prodLaw 38 := by
    apply integral_congr_ae
    apply ae_of_all
    intro t
    by_cases z : V i s t = 0
    · simp [z]
    · exact congrArg (fun w => w*(V i s t)^2) (native_kernel_on_fibre i s t z)
  rw [eq]
  rfl

private theorem pair_index (r : Fin 37 → Bands) (nz : B r ≠ 0) : Native.cellSum r ≤ 130964 := by
  have insert : ∃ l h, trial (EndpointPhysical.join r l h) ≠ 0 := by
    by_contra! mute
    apply nz
    simp [B,mute]
  obtain ⟨l,h,hit⟩ := insert
  have bound := retained_index_le _ (ite_ne_right_iff.mp hit).2 (0 : Fin 39)
  have rm : (0 : Fin 39).removeNth (EndpointPhysical.join r l h) = Fin.snoc (α := fun _ => Bands) r h := by
    funext j
    simp [Fin.removeNth,EndpointPhysical.join]
  rw [rm] at bound
  unfold Native.cellSum at bound ⊢
  rw [Fin.sum_univ_castSucc] at bound
  simpa only [Fin.snoc_castSucc,Fin.snoc_last] using (Nat.le_add_right _ _).trans bound

private theorem adverse_mono (d : ℕ) : Monotone (@Native.adverse d) := by
  intro j k h
  unfold Native.adverse
  exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left
    (add_le_add_left (Nat.cast_le.mpr h : (j:ℝ) ≤ k) _) (by norm_num [rho])) (by norm_num [Native.step])

private theorem interior_room (r : Fin 37 → Bands) (nz : B r ≠ 0) : 0 ≤ native r ∧ native r ≤ radiusCap := by
  have lower := adverse_mono 37 (Nat.zero_le (Native.cellSum r))
  have upper := adverse_mono 37 (pair_index r nz)
  exact ⟨le_trans (by norm_num [Native.adverse,Native.step,rho]) lower,
    upper.trans (by norm_num [Native.adverse,Native.step,rho,radiusCap])⟩

theorem endpoint_exact : endpoint = cellEndpoint := by
  apply integral_congr_ae
  apply ae_of_all
  intro r
  by_cases zero : B r = 0
  · simp [zero]
  · obtain ⟨low,high⟩ := interior_room r zero
    change (2*rho^2*(1/(ledger-min radiusCap (max 0 (native r))))^2)*(B r)^2 =
      (2*rho^2/(ledger-native r)^2)*(B r)^2
    rw [max_eq_right low,min_eq_right high]
    simp only [div_eq_mul_inv,one_mul,inv_pow]

theorem physical_margin_of_receipt (h : (∫ v, (trial v)^2 ∂prodLaw 39) + cellEndpoint < rho*∑ i, cellIncome i) :
    (∫ v, (trial v)^2 ∂prodLaw 39) + endpointCost mesh trial < rho*∑ i : Fin 39, shiftIncome mesh trial i label := by
  apply physical_margin_of_native
  simpa only [income_exact,endpoint_exact] using h

/- The finite producer first scores the historical prices and pays only
the positive difference to the current prices. -/
private def oldRows : Array (Int × Int) :=
  archiveRows% (include_str "../data/h1_multilevel_strip_free.json")

set_option maxRecDepth 8192 in
private theorem old_count : oldRows.size = 521 := by rfl

set_option maxRecDepth 8192 in
def oldPrice (s : Fin 521) := oldRows[s.val]'(by rw [old_count]; exact s.isLt)

private def affine (p : Int × Int) (q : ℝ) := ((p.1:ℝ) + (p.2:ℝ)*q)/10^14
private def weight (i : Fin 39) (s : Fin 521) (f : ℝ → ℝ) :=
  ∫ t, f (kernel 0.2801 (native t))*(V i s t)^2 ∂prodLaw 38
private theorem affine_cont (p : Int × Int) : Continuous (affine p) := by unfold affine; fun_prop
private theorem weight_int (i : Fin 39) (s : Fin 521) (f : ℝ → ℝ) (cf : Continuous f) :
    Integrable (fun t => f (kernel 0.2801 (native t))*(V i s t)^2) (prodLaw 38) := by
  let := bandLaw_finite mesh
  have room : (0.2801:ℝ) < ledger := by norm_num [ledger]
  have range_bound : Bornology.IsBounded (Set.range (fun t : Fin 38 → Bands => f (kernel 0.2801 (native t)))) := by
    apply (isCompact_Icc (a := (0:ℝ)) (b := 1/(ledger-0.2801))).image cf |>.isBounded.subset
    rintro _ ⟨t,rfl⟩
    exact ⟨_,⟨kernel_nonneg room _,one_div_le_one_div_of_le (sub_pos.mpr room)
      (sub_le_sub_left (min_le_left _ _) _)⟩,rfl⟩
  exact weighted_integrable _ _ _ (cf.measurable.comp ((kernel_cont room).measurable.comp (nativeMeasurable 38)))
    range_bound (V_regular i s).1 (V_regular i s).2

theorem income_weights (i : Fin 39) : income i = ∑ s : Fin 521, weight i s (affine (archivedPrice s)) := by
  unfold income
  rw [Finset.sum_div]
  apply Finset.sum_congr rfl
  intro s _
  have energy : Integrable (fun t => (V i s t)^2) (prodLaw 38) := by
    simpa only [one_mul] using weight_int i s (fun _ => 1) continuous_const
  have inv : Integrable (fun t => kernel 0.2801 (native t)*(V i s t)^2) (prodLaw 38) := weight_int i s id continuous_id
  let a : ℝ := (archivedPrice s).1
  let b : ℝ := (archivedPrice s).2
  have pt (t : Fin 38 → Bands) : affine (archivedPrice s) (kernel 0.2801 (native t))*(V i s t)^2 =
      (a/10^14)*(V i s t)^2 + (b/10^14)*(kernel 0.2801 (native t)*(V i s t)^2) := by dsimp [affine,a,b]; ring
  unfold weight
  simp_rw [pt]
  rw [integral_add (energy.const_mul (a/10^14)) (inv.const_mul (b/10^14)),integral_const_mul,integral_const_mul]
  dsimp only [a,b]; ring

private def debitPrice (s : Fin 521) (q : ℝ) := max 0 (affine (oldPrice s) q - affine (archivedPrice s) q)
private theorem debit_cont (s : Fin 521) : Continuous (debitPrice s) :=
  continuous_const.max ((affine_cont _).sub (affine_cont _))

def historicalIncome (i : Fin 39) := ∑ s : Fin 521, weight i s (affine (oldPrice s))
def positiveDebit (i : Fin 39) := ∑ s : Fin 521, weight i s (debitPrice s)

theorem portable_debit (i : Fin 39) : historicalIncome i ≤ income i + positiveDebit i := by
  rw [income_weights,positiveDebit,←Finset.sum_add_distrib]
  apply Finset.sum_le_sum
  intro s _
  unfold weight
  have new_int := weight_int i s _ (affine_cont (archivedPrice s))
  have debit_int := weight_int i s _ (debit_cont s)
  rw [← integral_add new_int debit_int]
  refine integral_mono (weight_int i s _ (affine_cont (oldPrice s))) (new_int.add debit_int) (fun t => ?_)
  let q := kernel 0.2801 (native t)
  have le : affine (oldPrice s) q ≤ affine (archivedPrice s) q + debitPrice s q := by
    have := le_max_right 0 (affine (oldPrice s) q-affine (archivedPrice s) q)
    dsimp only [debitPrice]
    linarith
  simpa only [add_mul] using mul_le_mul_of_nonneg_right le (sq_nonneg (V i s t))

theorem historical_margin (h : (∫ v, (trial v)^2 ∂prodLaw 39) + cellEndpoint + rho*(∑ i, positiveDebit i) <
    rho*∑ i, historicalIncome i) :
    (∫ v, (trial v)^2 ∂prodLaw 39) + endpointCost mesh trial < rho*∑ i : Fin 39, shiftIncome mesh trial i label := by
  apply physical_margin_of_native
  have sums := Finset.sum_le_sum (s := Finset.univ) (fun i _ => portable_debit i)
  rw [Finset.sum_add_distrib] at sums
  have scaled := mul_le_mul_of_nonneg_left sums (by norm_num [rho] : 0 ≤ rho)
  rw [mul_add] at scaled
  rw [endpoint_exact]
  linarith only [scaled,h]

/-- The historical cap contraction used before restoring the 39 erasures. -/
def historicalFor (F : Profile 39 216) (i : Fin 39) := ∑ s : Fin 521,
    ∫ t, affine (oldPrice s) (primePrice (Native.adverse (d := 38) (Native.cellSum t)))*
      (integralFace mesh i (restrictFace i (fun r => label r=s) F) t)^2 ∂prodLaw 38

theorem historical_exact (i : Fin 39) : historicalIncome i = historicalFor trial i := by
  apply Finset.sum_congr rfl
  intro s _
  apply integral_congr_ae
  apply ae_of_all
  intro t
  change affine (oldPrice s) (kernel 0.2801 (native t))*(V i s t)^2 =
    affine (oldPrice s) (primePrice (native t))*(V i s t)^2
  by_cases z : V i s t = 0
  · simp [z]
  · rw [native_kernel_on_fibre i s t z]

#print axioms historical_margin

#print axioms physical_margin_of_receipt
#print axioms physical_margin_of_native
end PrimeGap180.AdverseScore
