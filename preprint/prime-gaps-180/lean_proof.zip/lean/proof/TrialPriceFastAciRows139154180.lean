import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G139
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 139

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G139

namespace PrimeGap180.PriceIsolatedGroup.G144
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 144

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G144

namespace PrimeGap180.PriceIsolatedGroup.G149
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 149

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G149

namespace PrimeGap180.PriceIsolatedGroup.G154
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 154

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G154
