import TrialCoverPacked180

/-! Check one complete cover table, one possible fourth bin per theorem. -/
namespace PrimeGap180.CoverEnumeration

set_option maxRecDepth 40000
set_option maxHeartbeats 100000000

private theorem full35 : band false (column 1) 35 = true := by decide +kernel
private theorem full36 : band false (column 1) 36 = true := by decide +kernel
private theorem full37 : band false (column 1) 37 = true := by decide +kernel
private theorem full38 : band false (column 1) 38 = true := by decide +kernel
private theorem full39 : band false (column 1) 39 = true := by decide +kernel
private theorem full40 : band false (column 1) 40 = true := by decide +kernel
private theorem full41 : band false (column 1) 41 = true := by decide +kernel
private theorem full42 : band false (column 1) 42 = true := by decide +kernel
private theorem full43 : band false (column 1) 43 = true := by decide +kernel
private theorem full44 : band false (column 1) 44 = true := by decide +kernel
private theorem full45 : band false (column 1) 45 = true := by decide +kernel
private theorem full46 : band false (column 1) 46 = true := by decide +kernel
private theorem full47 : band false (column 1) 47 = true := by decide +kernel
private theorem full48 : band false (column 1) 48 = true := by decide +kernel
private theorem full49 : band false (column 1) 49 = true := by decide +kernel
private theorem full50 : band false (column 1) 50 = true := by decide +kernel
private theorem full51 : band false (column 1) 51 = true := by decide +kernel
private theorem full52 : band false (column 1) 52 = true := by decide +kernel
private theorem full53 : band false (column 1) 53 = true := by decide +kernel
private theorem full54 : band false (column 1) 54 = true := by decide +kernel

theorem fullBands : ∀ j : Fin 20, band false (column 1) (35+j.val) = true :=
  (Fin.cases full35
    (Fin.cases full36
    (Fin.cases full37
    (Fin.cases full38
    (Fin.cases full39
    (Fin.cases full40
    (Fin.cases full41
    (Fin.cases full42
    (Fin.cases full43
    (Fin.cases full44
    (Fin.cases full45
    (Fin.cases full46
    (Fin.cases full47
    (Fin.cases full48
    (Fin.cases full49
    (Fin.cases full50
    (Fin.cases full51
    (Fin.cases full52
    (Fin.cases full53
    (Fin.cases full54
    (fun x => Fin.elim0 x)))))))))))))))))))))

#print axioms fullBands
end PrimeGap180.CoverEnumeration
