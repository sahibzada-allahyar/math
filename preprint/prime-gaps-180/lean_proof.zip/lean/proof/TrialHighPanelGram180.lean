import Mathlib.Analysis.Real.Sqrt
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum

/-! Bounds for the signed four-control Gram matrix in the high-edge mass
calculation. Convex radial weights may depend on the entire sample. -/
noncomputable section
open scoped BigOperators
namespace PrimeGap180.HighPanelGram
variable {α : Type*} [Fintype α]

def energy (f : α → ℝ) := ∑ x, f x ^ 2
def dot (f g : α → ℝ) := ∑ x, f x * g x
def mix (b f : Fin 4 → ℝ) := ∑ i, b i * f i
def gram (F : Fin 4 → α → ℝ) (i j : Fin 4) := dot (F i) (F j)
def line (K : Fin 4 → Fin 4 → ℝ) (w : Fin 4 → ℝ) (i : Fin 4) := ∑ j, w j * K i j
def centerSq (K : Fin 4 → Fin 4 → ℝ) (w : Fin 4 → ℝ) := ∑ i, w i * line K w i
def trace (K : Fin 4 → Fin 4 → ℝ) := ∑ i, K i i
def residual (K : Fin 4 → Fin 4 → ℝ) (w : Fin 4 → ℝ) :=
  trace K - 2 * (∑ i, line K w i) + 4 * centerSq K w

private theorem convex (b f : Fin 4 → ℝ) (nn : ∀ i, 0 ≤ b i) (one : ∑ i, b i = 1) :
    (mix b f)^2 ≤ ∑ i, (f i)^2 := by
  have h := Finset.sum_sq_le_sum_mul_sum_of_sq_le_mul Finset.univ
    (r:=fun i => b i*f i) (f:=b) (g:=fun i => b i*(f i)^2)
    (fun i _ => nn i) (fun i _ => mul_nonneg (nn i) (sq_nonneg _))
    (fun i _ => le_of_eq (by ring))
  rw [one,one_mul] at h
  apply h.trans
  apply Finset.sum_le_sum
  intro i _
  have up : b i ≤ 1 := one ▸ Finset.single_le_sum (fun j _ => nn j) (Finset.mem_univ i)
  exact mul_le_of_le_one_left (sq_nonneg _) up

private theorem energy_add (f g : α → ℝ) :
    energy (fun x => f x + g x) ≤ (Real.sqrt (energy f) + Real.sqrt (energy g))^2 := by
  have pos (a : α → ℝ) : 0 ≤ energy a := Finset.sum_nonneg fun x _ => sq_nonneg _
  have eq : energy (fun x => f x + g x) = energy f + 2*dot f g + energy g := by
    unfold energy dot
    simp only [add_sq,Finset.sum_add_distrib,Finset.mul_sum,mul_assoc]
  have bound := Real.sum_mul_le_sqrt_mul_sqrt Finset.univ f g
  change dot f g ≤ Real.sqrt (energy f) * Real.sqrt (energy g) at bound
  rw [eq,add_sq,Real.sq_sqrt (pos f),Real.sq_sqrt (pos g)]
  linarith only [bound]

private theorem dot_mixture (F : Fin 4 → α → ℝ) (f : α → ℝ) (w : Fin 4 → ℝ) :
    dot f (fun x => mix w (fun i => F i x)) = ∑ j, w j * dot f (F j) := by
  unfold mix dot
  simp only [Finset.mul_sum]
  rw [Finset.sum_comm]
  exact Finset.sum_congr rfl fun i _ => Finset.sum_congr rfl fun j _ => by ring

theorem diagonal (F : Fin 4 → α → ℝ) (b : α → Fin 4 → ℝ)
    (nn : ∀ x i, 0 ≤ b x i) (one : ∀ x, ∑ i, b x i = 1) :
    energy (fun x => mix (b x) (fun i => F i x)) ≤ trace (gram F) := by
  apply (Finset.sum_le_sum (s:=Finset.univ) (fun x _ => convex _ _ (nn x) (one x))).trans_eq
  rw [Finset.sum_comm]
  simp only [trace,gram,dot,pow_two]

/-- The archived centered bound holds for each fixed center; it therefore
also holds for the best of the three centers used in the certificate. -/
theorem centered (F : Fin 4 → α → ℝ) (b : α → Fin 4 → ℝ)
    (nn : ∀ x i, 0 ≤ b x i) (one : ∀ x, ∑ i, b x i = 1) (w : Fin 4 → ℝ) :
    energy (fun x => mix (b x) (fun i => F i x)) ≤
      (Real.sqrt (centerSq (gram F) w) + Real.sqrt (residual (gram F) w))^2 := by
  let c := fun x => mix w (fun i => F i x)
  let d := fun x => mix (b x) (fun i => F i x) - c x
  have row (i : Fin 4) : dot (F i) c = line (gram F) w i := dot_mixture F (F i) w
  have crow (i : Fin 4) : dot c (F i) = line (gram F) w i := by
    rw [←row i]
    unfold dot
    exact Finset.sum_congr rfl fun x _ => mul_comm _ _
  have ec : energy c = centerSq (gram F) w := by
    have eq : energy c = dot c c := by simp only [energy,dot,pow_two]
    rw [eq,dot_mixture F c w]
    simp only [centerSq,crow]
  have total : (∑ i, energy (fun x => F i x - c x)) = residual (gram F) w := by
    have each (i : Fin 4) : energy (fun x => F i x - c x) =
        gram F i i - 2 * line (gram F) w i + energy c := by
      rw [←row i]
      unfold energy gram dot
      have expand (x : α) : (F i x - c x)^2 =
          F i x * F i x - 2*(F i x * c x) + (c x)^2 := by ring
      simp only [expand,Finset.sum_add_distrib,Finset.sum_sub_distrib,Finset.mul_sum]
    simp only [each,Finset.sum_add_distrib,Finset.sum_sub_distrib,←Finset.mul_sum,
      Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,Nat.cast_ofNat,ec,residual,trace]
  have ed : energy d ≤ residual (gram F) w := by
    rw [←total]
    unfold energy
    rw [Finset.sum_comm (f:=fun i x => (F i x-c x)^2)]
    apply Finset.sum_le_sum
    intro x _
    have de : d x = mix (b x) (fun i => F i x - c x) := by
      simp only [d,mix,mul_sub,Finset.sum_sub_distrib,←Finset.sum_mul,one,one_mul]
    rw [de]
    exact convex _ _ (nn x) (one x)
  have eq : (fun x => mix (b x) (fun i => F i x)) = (fun x => c x + d x) := by
    funext x
    dsimp only [d]
    ring
  rw [eq,←ec]
  apply (energy_add c d).trans
  exact pow_le_pow_left₀ (add_nonneg (Real.sqrt_nonneg _) (Real.sqrt_nonneg _))
    (add_le_add le_rfl (Real.sqrt_le_sqrt ed)) _

#print axioms diagonal
#print axioms centered
end PrimeGap180.HighPanelGram
