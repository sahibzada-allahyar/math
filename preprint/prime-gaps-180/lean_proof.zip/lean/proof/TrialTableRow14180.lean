import TrialTableChunks180
namespace PrimeGap180.TablePrices
set_option maxRecDepth 65536
set_option maxHeartbeats 0
theorem row14 : certified 14 := by
  apply of_chunks
  · intro b
    fin_cases b <;> decide +kernel
  · intro b
    fin_cases b <;> decide +kernel
#print axioms row14
end PrimeGap180.TablePrices
