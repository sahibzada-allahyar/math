import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Data.Rat.Defs

namespace PrimeGap180.JointEdgeSecondNumbers
open scoped BigOperators
def w : Rat := 367334135714033 / 17203127910400
def E : Rat := 100 / w
def ratio : Rat := 1/E
def atom : Rat := E-1/2
def budget : Rat := 600/w+1
def contribution (k j a : Nat) : Rat :=
  let d:=2*(37-k)+j
  let t:=budget-k-a
  if t<0 then 0 else
    ((37:Nat).choose k:Rat)*(k.choose j)*((37-k).choose a)*(-1:Rat)^j*(-1:Rat)^a*
      atom^(k-j)*t^d/d.factorial

def numeric : Rat := ratio^37 * ∑ k∈Finset.range 38,
  ∑ j∈Finset.range (k+1), ∑ a∈Finset.range (38-k),contribution k j a

set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
theorem checked : numeric < (10600555:Rat)/10^15 := by decide +kernel

#print axioms checked
end PrimeGap180.JointEdgeSecondNumbers
