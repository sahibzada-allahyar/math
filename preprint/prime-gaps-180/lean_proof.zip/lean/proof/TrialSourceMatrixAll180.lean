import TrialSourceMatrixPrime180
import TrialSourceMatrixSharp180
import TrialSourceMatrixHigher00180
import TrialSourceMatrixHigher01180
import TrialSourceMatrixHigher02180
import TrialSourceMatrixHigher03180
import TrialSourceMatrixHigher04180
import TrialSourceMatrixHigher05180
import TrialSourceMatrixHigher06180
import TrialSourceMatrixHigher07180
import TrialSourceMatrixHigher08180
import TrialSourceMatrixHigher09180
import TrialSourceMatrixHigher10180
import TrialSourceMatrixHigher11180

namespace PrimeGap180.SourceMatrixBits

theorem checked (k : Book.Row) : row k = true := by
  cases k with
  | prime => exact Prime.verified
  | sharp => exact Sharp.verified
  | higher i =>
    fin_cases i
    · exact Higher00.verified
    · exact Higher01.verified
    · exact Higher02.verified
    · exact Higher03.verified
    · exact Higher04.verified
    · exact Higher05.verified
    · exact Higher06.verified
    · exact Higher07.verified
    · exact Higher08.verified
    · exact Higher09.verified
    · exact Higher10.verified
    · exact Higher11.verified

#print axioms checked
end PrimeGap180.SourceMatrixBits
