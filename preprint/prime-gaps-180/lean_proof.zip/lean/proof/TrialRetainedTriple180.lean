import TrialWidePrimeBoxes180
import TrialPrimeCriterion180

noncomputable section
open scoped BigOperators Topology
open Filter PrimeGap186 PrimeGap182Audit
open PrimeGap180.Distribution PrimeGap180.Prefix PrimeGap182.TypeIII
namespace PrimeGap180.Retained

def tripleLower (x ζ cut : ℝ) (i : Fin 3) : ℕ :=
  if i=0 then ⌈x^ζ⌉₊ else ⌊x^cut⌋₊+1

def tripleUpper (x cut a : ℝ) (i : Fin 3) : ℕ :=
  if i=0 then ⌊x^cut⌋₊ else ⌈x^a⌉₊-1

/-- The small prime includes both endpoints; the two large primes exclude both. -/
theorem triple_prime_ranges {x : ℝ} (xp : 0 < x) (ζ cut a : ℝ) (i : Fin 3) (p : ℕ) :
    p ∈ primesIn (tripleLower x ζ cut i) (tripleUpper x cut a i) ↔ p.Prime ∧
      (if i=0 then x^ζ ≤ (p:ℝ) ∧ (p:ℝ) ≤ x^cut else x^cut < (p:ℝ) ∧ (p:ℝ) < x^a) := by
  by_cases s : i=0
  · simp only [primesIn,tripleLower,tripleUpper,s,↓reduceIte,Finset.mem_filter,
      Finset.mem_Icc,Nat.ceil_le,Nat.le_floor_iff (Real.rpow_nonneg xp.le _),and_comm]
  · simp only [primesIn,tripleLower,tripleUpper,s,↓reduceIte,Finset.mem_filter,Finset.mem_Icc]
    have ce : 0 < ⌈x^a⌉₊ := Nat.ceil_pos.mpr (Real.rpow_pos_of_pos xp _)
    have l := Nat.floor_lt (a := x^cut) (n := p) (Real.rpow_nonneg xp.le _)
    have u := Nat.lt_ceil (a := x^a) (n := p)
    constructor
    · rintro ⟨⟨hl,hu⟩,pp⟩
      exact ⟨pp,l.mp (by omega),u.mp (by omega)⟩
    · rintro ⟨pp,hl,hu⟩
      have l' := l.mpr hl
      have u' := u.mpr hu
      exact ⟨⟨by omega,by omega⟩,pp⟩

def retainedTriple (x ζ cut a : ℝ) : ℕ →₀ ℂ :=
  let T := Fintype.piFinset fun i : Fin 3 =>
    primesIn (tripleLower x ζ cut i) (tripleUpper x cut a i)
  (∑ p ∈ T, Finsupp.single (∏ i, p i) (1:ℂ)).filter (fun n => n ∈ window x)

theorem retained_triple_distribution_of_block {j : ℕ} {a I cut w v d σb σ : ℝ}
    (g : CoefficientGuards j a I cut w v d σb σ)
    (block : Averaged.SelectedBlockEstimate) (rank4 : AllIncidenceRankFourBounds)
    (zlo : 23/100 ≤ 1-a-I) (ahi : a ≤ 42/100) (level : 1/2+2*w ≤ 53/100)
    (zc : 1-a-I ≤ cut) (ca : cut ≤ a) (A : ℝ) (hA : 0 < A) :
    ∃ K : ℝ, 0 < K ∧ ∀ᶠ x : ℝ in atTop, ∀ (P Q : Finset ℕ) (b : ℕ),
      (∀ p ∈ P, p.Prime) → b.Coprime (∏ p ∈ P, p) → Q ⊆ dense j (1/2+2*w) d x P →
        ∑ q ∈ Q, ‖fullDiscrepancy (retainedTriple x (1-a-I) cut a) q b‖ ≤ K*x/(Real.log x)^A := by
  classical
  obtain ⟨K,hK,raw⟩ := wide_prime_boxes g block rank4 zlo ahi level A hA
  refine ⟨K,hK,?_⟩
  filter_upwards [raw,eventually_ge_atTop (1:ℝ)] with x h hx
  let L := tripleLower x (1-a-I) cut
  let U := tripleUpper x cut a
  have xp := zero_lt_one.trans_le hx
  have fl := Nat.floor_le (Real.rpow_nonneg xp.le cut)
  have ceilLo : (⌈x^a⌉₊ - 1 : ℕ) < x^a := by
    have ce := Nat.ceil_pos.mpr (Real.rpow_pos_of_pos xp a)
    exact Nat.lt_ceil.mp (by omega)
  have lo (i : Fin 3) : x^(1-a-I) ≤ (L i:ℝ) := by
    by_cases s : i=0
    · simpa [L,tripleLower,s] using Nat.le_ceil (x^(1-a-I))
    · simp only [L,tripleLower,s,↓reduceIte,Nat.cast_add,Nat.cast_one]
      exact (Real.rpow_le_rpow_of_exponent_le hx zc).trans (Nat.lt_floor_add_one _).le
  have hi (i : Fin 3) : (U i:ℝ) ≤ x^a := by
    by_cases s : i=0
    · simpa [U,tripleUpper,s] using fl.trans (Real.rpow_le_rpow_of_exponent_le hx ca)
    · simpa [U,tripleUpper,s] using ceilLo.le
  have eq : (primeIntervalBoxAlgebra (fun i => (L i:ℝ)) (fun i => (U i:ℝ)) Finset.univ).coeff.filter
      (fun n => n ∈ Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊) = retainedTriple x (1-a-I) cut a := by
    rw [primeIntervalBoxAlgebra_univ_eq_tuple_sum]
    simp only [MonoidAlgebra.coeff_sum,MonoidAlgebra.coeff_single,Nat.ceil_natCast,Nat.floor_natCast]
    rfl
  intro P Q b primes cop sub
  rw [← eq]
  exact h L U lo hi (by simpa [U,tripleUpper] using fl) P Q b primes cop sub

theorem retained_triple_distribution {j : ℕ} {a I cut w v d σb σ : ℝ}
    (g : CoefficientGuards j a I cut w v d σb σ)
    (C : ℝ) (hC : 0 ≤ C) (D : ℕ) (hD : 1 ≤ D)
    (base : BaselineLocalInputs) (fourier : PrimeFourierBounds C D) (rank4 : AllIncidenceRankFourBounds)
    (zlo : 23/100 ≤ 1-a-I) (ahi : a ≤ 42/100) (level : 1/2+2*w ≤ 53/100)
    (zc : 1-a-I ≤ cut) (ca : cut ≤ a) (A : ℝ) (hA : 0 < A) :
    ∃ K : ℝ, 0 < K ∧ ∀ᶠ x : ℝ in atTop, ∀ (P Q : Finset ℕ) (b : ℕ),
      (∀ p ∈ P, p.Prime) → b.Coprime (∏ p ∈ P, p) → Q ⊆ dense j (1/2+2*w) d x P →
        ∑ q ∈ Q, ‖fullDiscrepancy (retainedTriple x (1-a-I) cut a) q b‖ ≤ K*x/(Real.log x)^A :=
  retained_triple_distribution_of_block g
    (Averaged.matrixToBlock (Averaged.cyclesToMatrix (primeBoundsToCycles hC hD base fourier)))
    rank4 zlo ahi level zc ca A hA

#print axioms retained_triple_distribution
end PrimeGap180.Retained
