import TrialPriceAllResources180

noncomputable section
namespace PrimeGap180.PriceResourceRows
open Book Price PriceFactorSource

private theorem index_bound (u : Resource) : PriceScalar.resourceIndex u < 49 := by
  cases u <;> simp only [PriceScalar.resourceIndex] <;> omega

/-- Every stored resource charge equals the actual Gram diagonal of the original
named physical signed rows. The public ledger uses a separate matrix-slot expression. -/
theorem resource_grams (u : Resource) (g : Group) :
    let s := factorShapes[PriceScalar.resourceIndex u]!
    (PriceValues.resource g.val (PriceScalar.resourceIndex u):Int) =
      intGram (fun i : Group => fun j : Fin s.1 => PackedLedger.integer (PriceFactorSource.physical s) i.val j.val) g g := by
  let m : Fin 49 := ⟨PriceScalar.resourceIndex u,index_bound u⟩
  simpa only [m,originalDiagonal,Price.intGram,pow_two] using allResources m g

#print axioms resource_grams
end PrimeGap180.PriceResourceRows
