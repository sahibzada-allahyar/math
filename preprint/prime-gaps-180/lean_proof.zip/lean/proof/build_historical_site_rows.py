"""Generate Lean witnesses for the fixed 57-bit historical cumulative grid.

Every input column is authenticated before packing. Every generated shard
contains a kernel proof obligation covering each of its original radial indices.
"""
from array import array
from pathlib import Path
import argparse

from check_refined_site_bins import (
    BITS, GRID_SHA, SITES, TRANSFER_SHA, frozen_native, receipt,
)

FIRST = 45067
SIZE = 128
TILE = 8
GRID_MODULE = "TrialHistoricalSiteGrid180"


def columns():
    source = receipt("cap_law_transfer.json", TRANSFER_SHA)
    grid = receipt("h1_dickman_native_bounds.json", GRID_SHA)
    if source["dickman_receipt_sha256"] != GRID_SHA or len(source["bins"]) != 37:
        raise ValueError("Unexpected historical grid or number of cutoffs")
    result = []
    for row in source["bins"]:
        values = frozen_native(row["cap"], grid["count"], row["binary64_cdf_sha256"])
        column = array("Q")
        for value in values:
            numerator, remainder = divmod(value, 1 << (BITS - 57))
            if remainder or not 0 <= numerator <= 1 << 57:
                raise ValueError("Historical cumulative mass is not on the fixed 57-bit grid")
            column.append(numerator)
        if any(value != 1 << 57 for value in column[:FIRST]):
            raise ValueError("Nonconstant early cumulative mass")
        result.append(column)
    return result


def packed_row(data, j):
    row = 0
    for column in reversed(data):
        row = (row << 58) + column[j]
    return row


def shard_source(index, start, rows):
    tag = f"{index:03d}"
    name = f"rows{tag}"
    test = f"test{tag}"
    count = len(rows)
    lines = ["import TrialSiteSpans180", "namespace PrimeGap180.PackedSiteAudit",
             "set_option maxHeartbeats 0", "set_option maxRecDepth 65536",
             f"private def {name} : Array Nat := #["]
    lines.extend(hex(n) + ("," if i+1 < count else "") for i,n in enumerate(rows))
    lines.extend(["]", f"private def {test} (i : Nat) := rowOK ({start}+i) ({name}[i]?.getD 0)"])
    parts = []
    for offset in range(0, count, TILE):
        length = min(TILE, count-offset)
        proof = f"pass{tag}at{offset}"
        lines.append(f"private theorem {proof} : spanOK {test} {offset} {length} := by decide +kernel")
        parts.append((offset,length,proof))
    _, remaining, combined = parts.pop()
    for offset,length,proof in reversed(parts):
        combined = f"(span_join {test} {offset} {length} {remaining} {proof} {combined})"
        remaining += length
    lines.extend([f"def shard{tag} : Chunk := checkedChunk {start} {count} {name} rfl {combined}",
                  f"#print axioms shard{tag}", "end PrimeGap180.PackedSiteAudit"])
    return "\n".join(lines) + "\n"


def generate(destination):
    destination.mkdir(parents=True, exist_ok=True)
    data = columns()
    sources = {}
    for index,start in enumerate(range(FIRST,SITES,SIZE)):
        name = f"TrialSiteShard{index:03d}180"
        path = destination / (name + ".lean")
        rows = [packed_row(data,j) for j in range(start,min(start+SIZE,SITES))]
        path.write_text(shard_source(index,start,rows))
        sources[name] = path
    lines = ["import TrialSiteShardBook180", *("import "+name for name in sources),
             "namespace PrimeGap180.PackedSiteAudit", "set_option maxHeartbeats 0",
             "set_option maxRecDepth 65536", "def gridChunks : Array Chunk := #["]
    lines.extend(f"  shard{i:03d}" + ("," if i+1 < len(sources) else "") for i in range(len(sources)))
    lines.extend(["]", "theorem gridSchema : schema gridChunks = true := by decide +kernel",
                  "def gridRow := chooseRow gridChunks",
                  "theorem gridRow_ok (j : Nat) (hj : j < 130965) : rowOK j (gridRow j) = true :=",
                  "  checked_grid gridChunks gridSchema j hj",
                  "#print axioms gridRow_ok", "end PrimeGap180.PackedSiteAudit"])
    path = destination / (GRID_MODULE + ".lean")
    path.write_text("\n".join(lines)+"\n")
    sources[GRID_MODULE] = path
    return sources


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination", type=Path)
    print("\n".join(generate(parser.parse_args().destination)))
