import TrialFrozenData180
import TrialPoissonSplit180

/-! The one-site law of a frozen native radial cell and an actual
largest-fragment cutoff. The cap restriction keeps the physical mass. -/
noncomputable section
open scoped BigOperators Classical NNReal ENNReal Topology
open MeasureTheory Filter PrimeGap186 PrimeGap180.Sector
namespace PrimeGap180.NativeSiteLaw

abbrev mesh := FrozenData.mesh
def radial (z : Band 216) := ∑ j, z j
def tail (j : Fin 217) (z : Band 216) := ∑ k ∈ Finset.univ.filter (fun k => j ≤ k), z k
def capped (j : Fin 217) := {z : Band 216 | tail j z < mesh j.castSucc/2}
def phys (c : ℝ) := ENNReal.ofReal (Real.exp Real.eulerMascheroniConstant*c) • fragmentLaw c

private theorem cap_pos : 0 < cap := by norm_num [cap,physicalCap,rho]
private theorem tail_meas (j : Fin 217) : Measurable (tail j) := by unfold tail; fun_prop
private theorem radial_meas : Measurable radial := by unfold radial; fun_prop
private theorem capped_meas (j : Fin 217) : MeasurableSet (capped j) :=
  measurableSet_lt (tail_meas j) measurable_const

private theorem band_map : Measure.map (fragmentBandMasses mesh) (phys cap) = bandLaw mesh :=
  Measure.map_smul _ (measurable_fragmentBandMasses mesh).aemeasurable

private theorem reach (j : Fin 217) (hj : 0 < mesh j.castSucc) :
    (fragmentBandMasses mesh ⁻¹' capped j) =ᵐ[phys cap]
      {X : FiniteMeasure ℝ | (X : Measure ℝ) (Set.Ioi (mesh j.castSucc)) = 0} := by
  let c := mesh j.castSucc
  have hg := fragmentLaw_restricted_mass_gap cap c cap hj
  apply Measure.ae_smul_measure
  filter_upwards [hg,ae_restrict_Ioc_fragmentLaw cap] with X gap support
  apply propext
  change tail j (fragmentBandMasses mesh X) < c/2 ↔ (X : Measure ℝ) (Set.Ioi c) = 0
  have suffix := FrozenProfile.band_suffix mesh FrozenData.tables.ordered.monotone j X
  rw [show mesh (Fin.last 217) = cap from FrozenData.tables.last] at suffix
  change (X : Measure ℝ).real (Set.Ioc c cap) = tail j (fragmentBandMasses mesh X) at suffix
  have exactMass : ((X.restrict (Set.Ioc c cap)).mass:ℝ) = (X : Measure ℝ).real (Set.Ioc c cap) :=
    congrArg (fun n : ℝ≥0 => (n:ℝ)) (FiniteMeasure.restrict_mass X _)
  rw [exactMass] at gap
  have supportMeasure := congrArg (fun v : FiniteMeasure ℝ => (v : Measure ℝ)) support
  change (X:Measure ℝ).restrict (Set.Ioc 0 cap) = (X:Measure ℝ) at supportMeasure
  have intersection : Set.Ioi c ∩ Set.Ioc 0 cap = Set.Ioc c cap := by
    ext t
    constructor
    · intro h; exact ⟨h.1,h.2.2⟩
    · intro h; exact ⟨h.1,hj.trans h.1,h.2⟩
  have measureEq : (X:Measure ℝ) (Set.Ioi c) = (X:Measure ℝ) (Set.Ioc c cap) := by
    calc
      _ = (X:Measure ℝ).restrict (Set.Ioc 0 cap) (Set.Ioi c) := by rw [supportMeasure]
      _ = _ := by rw [Measure.restrict_apply measurableSet_Ioi,intersection]
  rw [measureEq,←measureReal_eq_zero_iff (measure_ne_top _ _),←suffix]
  have pos : 0 < c := hj
  rcases gap with zero | big
  · rw [zero]
    exact iff_of_true (by linarith only [pos]) rfl
  · exact iff_of_false (not_lt.mpr ((half_lt_self pos).le.trans big.le)) (ne_of_gt (pos.trans big))

/-- An occupied suffix contains a mark strictly larger than its lower cap. -/
theorem threshold_gap (j : Fin 217) (hj : 0 < mesh j.castSucc) :
    ∀ᵐ z ∂bandLaw mesh, tail j z = 0 ∨ mesh j.castSucc < tail j z := by
  have m : MeasurableSet {z | tail j z = 0 ∨ mesh j.castSucc < tail j z} :=
    (measurableSet_eq_fun (tail_meas j) measurable_const).union (measurableSet_lt measurable_const (tail_meas j))
  apply Measure.ae_smul_measure
  apply (ae_map_iff (measurable_fragmentBandMasses mesh).aemeasurable m).mpr
  filter_upwards [fragmentLaw_restricted_mass_gap cap (mesh j.castSucc) cap hj] with X gap
  have eq := FrozenProfile.band_suffix mesh FrozenData.tables.ordered.monotone j X
  rw [show mesh (Fin.last 217) = cap from FrozenData.tables.last] at eq
  have val : ((X.restrict (Set.Ioc (mesh j.castSucc) cap)).mass:ℝ) =
      tail j (fragmentBandMasses mesh X) :=
    (congrArg (fun n : ℝ≥0 => (n:ℝ)) (FiniteMeasure.restrict_mass X _)).trans eq
  rcases gap with h | h
  · exact Or.inl (val.symm.trans h)
  · exact Or.inr (h.trans_eq val)

/-- The entire Poisson configuration after imposing this maximum cap has
the physically normalized law at the smaller cap. This applies equally
to nonlinear joint suffix tests, before any radial marginal is taken. -/
theorem capped_bandLaw (j : Fin 217) (hj : 0 < mesh j.castSucc) :
    (bandLaw mesh).restrict (capped j) = Measure.map (fragmentBandMasses mesh) (phys (mesh j.castSucc)) := by
  have le : mesh j.castSucc ≤ cap := FrozenData.tables.last ▸ FrozenData.tables.ordered.monotone (Fin.le_last j.castSucc)
  rw [←band_map,Measure.restrict_map (measurable_fragmentBandMasses mesh) (capped_meas j),
      Measure.restrict_congr_set (reach j hj)]
  exact congrArg _ (fragmentLaw_full_configuration_cap_restriction cap _ hj le).2

/-- The density in a radial cell is exactly Dickman's function of the
total divided by the mark cap. There is no conditional normalization. -/
theorem capped_radial (j : Fin 217) (hj : 0 < mesh j.castSucc) :
    Measure.map radial ((bandLaw mesh).restrict (capped j)) =
      (volume.restrict (Set.Ici (0:ℝ))).withDensity
        (fun t => ENNReal.ofReal (dickmanRho (t/mesh j.castSucc))) := by
  let c := mesh j.castSucc
  have capLe : c ≤ cap := FrozenData.tables.last ▸ FrozenData.tables.ordered.monotone (Fin.le_last j.castSucc)
  rw [capped_bandLaw j hj,Measure.map_map radial_meas (measurable_fragmentBandMasses mesh)]
  have ae : ∀ᵐ X ∂phys c, (radial ∘ fragmentBandMasses mesh) X = (X.mass : ℝ) := by
    apply Measure.ae_smul_measure
    filter_upwards [ae_restrict_Ioc_fragmentLaw c] with X hX
    have covers := trial_restrict_eq_self_of_subset X _ _ hX (Set.Ioc_subset_Ioc le_rfl capLe)
    change (∑ i, fragmentBandMasses mesh X i) = (X.mass : ℝ)
    rw [sum_fragmentBandMasses mesh FrozenData.tables.ordered.monotone X,
      show mesh 0 = 0 from FrozenData.tables.first,show mesh (Fin.last 217) = cap from FrozenData.tables.last,covers]
  have mm : Measurable (fun X : FiniteMeasure ℝ => (X.mass:ℝ)) :=
    ((Measure.measurable_coe MeasurableSet.univ).comp measurable_subtype_coe).ennreal_toReal
  rw [Measure.map_congr ae,phys,Measure.map_smul _ mm.aemeasurable]
  exact normalized_fragmentLaw_mass_eq_dickman _ hj

theorem cell_mass (k : ℕ) (j : Fin 217) (hj : 0 < mesh j.castSucc) :
    (bandLaw mesh) ({z | (k:ℝ)*Native.step ≤ radial z ∧ radial z < ((k:ℝ)+1)*Native.step} ∩ capped j) =
      ∫⁻ t in Set.Ico ((k:ℝ)*Native.step) (((k:ℝ)+1)*Native.step),
        ENNReal.ofReal (dickmanRho (t/mesh j.castSucc)) ∂volume := by
  let I := Set.Ico ((k:ℝ)*Native.step) (((k:ℝ)+1)*Native.step)
  have incl : I ⊆ Set.Ici (0:ℝ) := fun t ht => (mul_nonneg (Nat.cast_nonneg k)
    (by norm_num [Native.step])).trans ht.1
  have eq := congrArg (fun M : Measure ℝ => M I) (capped_radial j hj)
  change (Measure.map radial ((bandLaw mesh).restrict (capped j))) I = _ at eq
  rw [Measure.map_apply radial_meas measurableSet_Ico,Measure.restrict_apply (radial_meas measurableSet_Ico),
    withDensity_apply _ measurableSet_Ico, Measure.restrict_restrict_of_subset incl] at eq
  exact eq

/-- On the physical mesh any nonnegative measurable function of all suffix
masses can be integrated by splitting at an arbitrary positive gate edge.
Multiple large marks at the same site remain in the integrand. -/
theorem capped_marks (j : Fin 217) (e : ℝ) (he : 0 < e) (le : e ≤ mesh j.castSucc)
    (F : Band 216 → ℝ≥0∞) (mF : Measurable F) :
    (∫⁻ z,F z ∂(bandLaw mesh).restrict (capped j)) =
      ∫⁻ Y, ∑' n : ℕ, (n.factorial:ℝ≥0∞)⁻¹ *
        ∫⁻ u : Fin n → ℝ, F (fragmentBandMasses mesh (Y+weightedEmpirical n u))
          ∂Measure.pi (fun _ : Fin n => PoissonSplit.intensity e (mesh j.castSucc)) ∂phys e := by
  rw [capped_bandLaw j (he.trans_le le),lintegral_map mF (measurable_fragmentBandMasses mesh)]
  exact PoissonSplit.physical_marks he le (F ∘ fragmentBandMasses mesh) (mF.comp (measurable_fragmentBandMasses mesh))

#print axioms capped_bandLaw
#print axioms capped_radial
#print axioms cell_mass
#print axioms capped_marks
end PrimeGap180.NativeSiteLaw
