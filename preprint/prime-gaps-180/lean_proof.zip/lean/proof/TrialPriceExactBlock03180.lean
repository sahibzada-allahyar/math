import TrialPriceScalar180
namespace PrimeGap180.PriceExactCensus
set_option maxHeartbeats 100000000
set_option maxRecDepth 65536
private theorem c96 : PriceScalar.checked (96 : Book.Label) = true := by decide +kernel
private theorem c97 : PriceScalar.checked (97 : Book.Label) = true := by decide +kernel
private theorem c98 : PriceScalar.checked (98 : Book.Label) = true := by decide +kernel
private theorem c99 : PriceScalar.checked (99 : Book.Label) = true := by decide +kernel
private theorem c100 : PriceScalar.checked (100 : Book.Label) = true := by decide +kernel
private theorem c101 : PriceScalar.checked (101 : Book.Label) = true := by decide +kernel
private theorem c102 : PriceScalar.checked (102 : Book.Label) = true := by decide +kernel
private theorem c103 : PriceScalar.checked (103 : Book.Label) = true := by decide +kernel
private theorem c104 : PriceScalar.checked (104 : Book.Label) = true := by decide +kernel
private theorem c105 : PriceScalar.checked (105 : Book.Label) = true := by decide +kernel
private theorem c106 : PriceScalar.checked (106 : Book.Label) = true := by decide +kernel
private theorem c107 : PriceScalar.checked (107 : Book.Label) = true := by decide +kernel
private theorem c108 : PriceScalar.checked (108 : Book.Label) = true := by decide +kernel
private theorem c109 : PriceScalar.checked (109 : Book.Label) = true := by decide +kernel
private theorem c110 : PriceScalar.checked (110 : Book.Label) = true := by decide +kernel
private theorem c111 : PriceScalar.checked (111 : Book.Label) = true := by decide +kernel
private theorem c112 : PriceScalar.checked (112 : Book.Label) = true := by decide +kernel
private theorem c113 : PriceScalar.checked (113 : Book.Label) = true := by decide +kernel
private theorem c114 : PriceScalar.checked (114 : Book.Label) = true := by decide +kernel
private theorem c115 : PriceScalar.checked (115 : Book.Label) = true := by decide +kernel
private theorem c116 : PriceScalar.checked (116 : Book.Label) = true := by decide +kernel
private theorem c117 : PriceScalar.checked (117 : Book.Label) = true := by decide +kernel
private theorem c118 : PriceScalar.checked (118 : Book.Label) = true := by decide +kernel
private theorem c119 : PriceScalar.checked (119 : Book.Label) = true := by decide +kernel
private theorem c120 : PriceScalar.checked (120 : Book.Label) = true := by decide +kernel
private theorem c121 : PriceScalar.checked (121 : Book.Label) = true := by decide +kernel
private theorem c122 : PriceScalar.checked (122 : Book.Label) = true := by decide +kernel
private theorem c123 : PriceScalar.checked (123 : Book.Label) = true := by decide +kernel
private theorem c124 : PriceScalar.checked (124 : Book.Label) = true := by decide +kernel
private theorem c125 : PriceScalar.checked (125 : Book.Label) = true := by decide +kernel
private theorem c126 : PriceScalar.checked (126 : Book.Label) = true := by decide +kernel
private theorem c127 : PriceScalar.checked (127 : Book.Label) = true := by decide +kernel
theorem block3 : ∀ i : Fin 32, PriceScalar.checked ⟨96+i.val,by omega⟩ = true :=
  Fin.cases c96 (Fin.cases c97 (Fin.cases c98 (Fin.cases c99 (Fin.cases c100 (Fin.cases c101 (Fin.cases c102 (Fin.cases c103 (Fin.cases c104 (Fin.cases c105 (Fin.cases c106 (Fin.cases c107 (Fin.cases c108 (Fin.cases c109 (Fin.cases c110 (Fin.cases c111 (Fin.cases c112 (Fin.cases c113 (Fin.cases c114 (Fin.cases c115 (Fin.cases c116 (Fin.cases c117 (Fin.cases c118 (Fin.cases c119 (Fin.cases c120 (Fin.cases c121 (Fin.cases c122 (Fin.cases c123 (Fin.cases c124 (Fin.cases c125 (Fin.cases c126 (Fin.cases c127 (fun i => Fin.elim0 i))))))))))))))))))))))))))))))))
#print axioms block3
end PrimeGap180.PriceExactCensus
