import TrialPricePhysicalGains180
import TrialPriceScalarVerified180

noncomputable section
open scoped BigOperators
namespace PrimeGap180.PriceGainRows
open Book Price
private abbrev ledger := FrozenLedger.ledger

/-- Every physical row gain is proved. Identifying the two families of Gram charges
with the original ledger supplies the grouped-price endpoint. -/
theorem endpoints_of_grams
    (resource : ∀ (u : Resource) (g : Group), (PriceValues.resource g.val (PriceScalar.resourceIndex u):Int) =
      intGram (ledger.factor u) g g)
    (event : ∀ (e : Book.Event) (g : Group), (PriceValues.event g.val (PriceScalar.eventIndex e):Int) =
      intGram (ledger.negative e) g g + intDeficit (intRemainder (ledger.remainder e) (ledger.positive e) (ledger.negative e)) g) :
    FrozenLedger.Endpoints :=
  PriceExactCensus.endpoints_of_charges ⟨checked,resource,event⟩

#print axioms endpoints_of_grams
end PrimeGap180.PriceGainRows
