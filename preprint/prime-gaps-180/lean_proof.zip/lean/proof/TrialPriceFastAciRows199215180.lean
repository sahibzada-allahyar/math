import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G199
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 199

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G199

namespace PrimeGap180.PriceIsolatedGroup.G205
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 205

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G205

namespace PrimeGap180.PriceIsolatedGroup.G210
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 210

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G210

namespace PrimeGap180.PriceIsolatedGroup.G215
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 215

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G215
