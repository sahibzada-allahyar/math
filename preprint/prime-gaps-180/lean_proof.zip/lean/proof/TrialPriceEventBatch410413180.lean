import TrialPriceIsolatedChecks180


noncomputable section
namespace PrimeGap180.PriceIsolatedGroup.G410
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

declarePriceActions 410
private theorem m0 : PriceFactorData.rowAction 0 410 = gramActions[0]! := by decide +kernel
private theorem m1 : PriceFactorData.rowAction 1 410 = gramActions[1]! := by decide +kernel
private theorem m2 : PriceFactorData.rowAction 2 410 = gramActions[2]! := by decide +kernel
private theorem m3 : PriceFactorData.rowAction 3 410 = gramActions[3]! := by decide +kernel
private theorem m4 : PriceFactorData.rowAction 4 410 = gramActions[4]! := by decide +kernel
private theorem m5 : PriceFactorData.rowAction 5 410 = gramActions[5]! := by decide +kernel
private theorem m6 : PriceFactorData.rowAction 6 410 = gramActions[6]! := by decide +kernel
private theorem m7 : PriceFactorData.rowAction 7 410 = gramActions[7]! := by decide +kernel
private theorem m8 : PriceFactorData.rowAction 8 410 = gramActions[8]! := by decide +kernel
private theorem m9 : PriceFactorData.rowAction 9 410 = gramActions[9]! := by decide +kernel
private theorem m10 : PriceFactorData.rowAction 10 410 = gramActions[10]! := by decide +kernel
private theorem m11 : PriceFactorData.rowAction 11 410 = gramActions[11]! := by decide +kernel
private theorem m12 : PriceFactorData.rowAction 12 410 = gramActions[12]! := by decide +kernel
private theorem m13 : PriceFactorData.rowAction 13 410 = gramActions[13]! := by decide +kernel
private theorem m14 : PriceFactorData.rowAction 14 410 = gramActions[14]! := by decide +kernel
private theorem m15 : PriceFactorData.rowAction 15 410 = gramActions[15]! := by decide +kernel
private theorem m16 : PriceFactorData.rowAction 16 410 = gramActions[16]! := by decide +kernel
private theorem m17 : PriceFactorData.rowAction 17 410 = gramActions[17]! := by decide +kernel
private theorem m18 : PriceFactorData.rowAction 18 410 = gramActions[18]! := by decide +kernel
private theorem m19 : PriceFactorData.rowAction 19 410 = gramActions[19]! := by decide +kernel
private theorem m20 : PriceFactorData.rowAction 20 410 = gramActions[20]! := by decide +kernel
private theorem m21 : PriceFactorData.rowAction 21 410 = gramActions[21]! := by decide +kernel
private theorem m22 : PriceFactorData.rowAction 22 410 = gramActions[22]! := by decide +kernel
private theorem m23 : PriceFactorData.rowAction 23 410 = gramActions[23]! := by decide +kernel
private theorem m24 : PriceFactorData.rowAction 24 410 = gramActions[24]! := by decide +kernel
private theorem m25 : PriceFactorData.rowAction 25 410 = gramActions[25]! := by decide +kernel
private theorem m26 : PriceFactorData.rowAction 26 410 = gramActions[26]! := by decide +kernel
private theorem m27 : PriceFactorData.rowAction 27 410 = gramActions[27]! := by decide +kernel
private theorem m28 : PriceFactorData.rowAction 28 410 = gramActions[28]! := by decide +kernel
private theorem m29 : PriceFactorData.rowAction 29 410 = gramActions[29]! := by decide +kernel
private theorem m30 : PriceFactorData.rowAction 30 410 = gramActions[30]! := by decide +kernel
private theorem m31 : PriceFactorData.rowAction 31 410 = gramActions[31]! := by decide +kernel
private theorem m32 : PriceFactorData.rowAction 32 410 = gramActions[32]! := by decide +kernel
private theorem m33 : PriceFactorData.rowAction 33 410 = gramActions[33]! := by decide +kernel
private theorem m34 : PriceFactorData.rowAction 34 410 = gramActions[34]! := by decide +kernel
private theorem m35 : PriceFactorData.rowAction 35 410 = gramActions[35]! := by decide +kernel
private theorem m36 : PriceFactorData.rowAction 36 410 = gramActions[36]! := by decide +kernel
private theorem m37 : PriceFactorData.rowAction 37 410 = gramActions[37]! := by decide +kernel
private theorem m38 : PriceFactorData.rowAction 38 410 = gramActions[38]! := by decide +kernel
private theorem m39 : PriceFactorData.rowAction 39 410 = gramActions[39]! := by decide +kernel
private theorem m40 : PriceFactorData.rowAction 40 410 = gramActions[40]! := by decide +kernel
private theorem m41 : PriceFactorData.rowAction 41 410 = gramActions[41]! := by decide +kernel
private theorem m42 : PriceFactorData.rowAction 42 410 = gramActions[42]! := by decide +kernel
private theorem m43 : PriceFactorData.rowAction 43 410 = gramActions[43]! := by decide +kernel
private theorem m44 : PriceFactorData.rowAction 44 410 = gramActions[44]! := by decide +kernel
private theorem m45 : PriceFactorData.rowAction 45 410 = gramActions[45]! := by decide +kernel
private theorem m46 : PriceFactorData.rowAction 46 410 = gramActions[46]! := by decide +kernel
private theorem m47 : PriceFactorData.rowAction 47 410 = gramActions[47]! := by decide +kernel
private theorem m48 : PriceFactorData.rowAction 48 410 = gramActions[48]! := by decide +kernel
private theorem m49 : PriceFactorData.rowAction 49 410 = gramActions[49]! := by decide +kernel
private theorem m50 : PriceFactorData.rowAction 50 410 = gramActions[50]! := by decide +kernel
private theorem m51 : PriceFactorData.rowAction 51 410 = gramActions[51]! := by decide +kernel
private theorem m52 : PriceFactorData.rowAction 52 410 = gramActions[52]! := by decide +kernel
private theorem m53 : PriceFactorData.rowAction 53 410 = gramActions[53]! := by decide +kernel
private theorem m54 : PriceFactorData.rowAction 54 410 = gramActions[54]! := by decide +kernel
private theorem m55 : PriceFactorData.rowAction 55 410 = gramActions[55]! := by decide +kernel
private theorem m56 : PriceFactorData.rowAction 56 410 = gramActions[56]! := by decide +kernel
private theorem m57 : PriceFactorData.rowAction 57 410 = gramActions[57]! := by decide +kernel
private theorem m58 : PriceFactorData.rowAction 58 410 = gramActions[58]! := by decide +kernel
private theorem m59 : PriceFactorData.rowAction 59 410 = gramActions[59]! := by decide +kernel
private theorem m60 : PriceFactorData.rowAction 60 410 = gramActions[60]! := by decide +kernel
private theorem m61 : PriceFactorData.rowAction 61 410 = gramActions[61]! := by decide +kernel
private theorem m62 : PriceFactorData.rowAction 62 410 = gramActions[62]! := by decide +kernel
private theorem m63 : PriceFactorData.rowAction 63 410 = gramActions[63]! := by decide +kernel
private theorem m64 : PriceFactorData.rowAction 64 410 = gramActions[64]! := by decide +kernel
private theorem m65 : PriceFactorData.rowAction 65 410 = gramActions[65]! := by decide +kernel
private theorem m66 : PriceFactorData.rowAction 66 410 = gramActions[66]! := by decide +kernel
private theorem m67 : PriceFactorData.rowAction 67 410 = gramActions[67]! := by decide +kernel
private theorem m68 : PriceFactorData.rowAction 68 410 = gramActions[68]! := by decide +kernel
private theorem m69 : PriceFactorData.rowAction 69 410 = gramActions[69]! := by decide +kernel
private theorem m70 : PriceFactorData.rowAction 70 410 = gramActions[70]! := by decide +kernel
private theorem m71 : PriceFactorData.rowAction 71 410 = gramActions[71]! := by decide +kernel
private theorem m72 : PriceFactorData.rowAction 72 410 = gramActions[72]! := by decide +kernel
private theorem m73 : PriceFactorData.rowAction 73 410 = gramActions[73]! := by decide +kernel
private theorem m74 : PriceFactorData.rowAction 74 410 = gramActions[74]! := by decide +kernel
private theorem m75 : PriceFactorData.rowAction 75 410 = gramActions[75]! := by decide +kernel
private theorem m76 : PriceFactorData.rowAction 76 410 = gramActions[76]! := by decide +kernel
private theorem m77 : PriceFactorData.rowAction 77 410 = gramActions[77]! := by decide +kernel
private theorem m78 : PriceFactorData.rowAction 78 410 = gramActions[78]! := by decide +kernel
private theorem m79 : PriceFactorData.rowAction 79 410 = gramActions[79]! := by decide +kernel
private theorem m80 : PriceFactorData.rowAction 80 410 = gramActions[80]! := by decide +kernel
private theorem m81 : PriceFactorData.rowAction 81 410 = gramActions[81]! := by decide +kernel
private theorem m82 : PriceFactorData.rowAction 82 410 = gramActions[82]! := by decide +kernel
private theorem m83 : PriceFactorData.rowAction 83 410 = gramActions[83]! := by decide +kernel
private theorem m84 : PriceFactorData.rowAction 84 410 = gramActions[84]! := by decide +kernel
private theorem m85 : PriceFactorData.rowAction 85 410 = gramActions[85]! := by decide +kernel
private theorem m86 : PriceFactorData.rowAction 86 410 = gramActions[86]! := by decide +kernel
private theorem m87 : PriceFactorData.rowAction 87 410 = gramActions[87]! := by decide +kernel
private theorem m88 : PriceFactorData.rowAction 88 410 = gramActions[88]! := by decide +kernel
private theorem m89 : PriceFactorData.rowAction 89 410 = gramActions[89]! := by decide +kernel
private theorem m90 : PriceFactorData.rowAction 90 410 = gramActions[90]! := by decide +kernel
private theorem m91 : PriceFactorData.rowAction 91 410 = gramActions[91]! := by decide +kernel
private theorem m92 : PriceFactorData.rowAction 92 410 = gramActions[92]! := by decide +kernel
private theorem m93 : PriceFactorData.rowAction 93 410 = gramActions[93]! := by decide +kernel
private theorem m94 : PriceFactorData.rowAction 94 410 = gramActions[94]! := by decide +kernel
private theorem m95 : PriceFactorData.rowAction 95 410 = gramActions[95]! := by decide +kernel
private theorem m96 : PriceFactorData.rowAction 96 410 = gramActions[96]! := by decide +kernel
private theorem m97 : PriceFactorData.rowAction 97 410 = gramActions[97]! := by decide +kernel
private theorem m98 : PriceFactorData.rowAction 98 410 = gramActions[98]! := by decide +kernel
private theorem m99 : PriceFactorData.rowAction 99 410 = gramActions[99]! := by decide +kernel
private theorem m100 : PriceFactorData.rowAction 100 410 = gramActions[100]! := by decide +kernel

attribute [local irreducible] PriceFactorData.rowAction gramActions

private theorem gram_values : moments (410 : Group) = gramActions := by
  apply PriceIsolatedChecks.moments_of_entries
  · decide +kernel
  · intro i
    fin_cases i
    · exact m0
    · exact m1
    · exact m2
    · exact m3
    · exact m4
    · exact m5
    · exact m6
    · exact m7
    · exact m8
    · exact m9
    · exact m10
    · exact m11
    · exact m12
    · exact m13
    · exact m14
    · exact m15
    · exact m16
    · exact m17
    · exact m18
    · exact m19
    · exact m20
    · exact m21
    · exact m22
    · exact m23
    · exact m24
    · exact m25
    · exact m26
    · exact m27
    · exact m28
    · exact m29
    · exact m30
    · exact m31
    · exact m32
    · exact m33
    · exact m34
    · exact m35
    · exact m36
    · exact m37
    · exact m38
    · exact m39
    · exact m40
    · exact m41
    · exact m42
    · exact m43
    · exact m44
    · exact m45
    · exact m46
    · exact m47
    · exact m48
    · exact m49
    · exact m50
    · exact m51
    · exact m52
    · exact m53
    · exact m54
    · exact m55
    · exact m56
    · exact m57
    · exact m58
    · exact m59
    · exact m60
    · exact m61
    · exact m62
    · exact m63
    · exact m64
    · exact m65
    · exact m66
    · exact m67
    · exact m68
    · exact m69
    · exact m70
    · exact m71
    · exact m72
    · exact m73
    · exact m74
    · exact m75
    · exact m76
    · exact m77
    · exact m78
    · exact m79
    · exact m80
    · exact m81
    · exact m82
    · exact m83
    · exact m84
    · exact m85
    · exact m86
    · exact m87
    · exact m88
    · exact m89
    · exact m90
    · exact m91
    · exact m92
    · exact m93
    · exact m94
    · exact m95
    · exact m96
    · exact m97
    · exact m98
    · exact m99
    · exact m100
private theorem a0 : affine (410 : Group) (.prime : Book.Row) = affineActions[0]! := by decide +kernel
private theorem a1 : affine (410 : Group) (.sharp : Book.Row) = affineActions[1]! := by decide +kernel
private theorem a2 : affine (410 : Group) (.higher 0 : Book.Row) = affineActions[2]! := by decide +kernel
private theorem a3 : affine (410 : Group) (.higher 1 : Book.Row) = affineActions[3]! := by decide +kernel
private theorem a4 : affine (410 : Group) (.higher 2 : Book.Row) = affineActions[4]! := by decide +kernel
private theorem a5 : affine (410 : Group) (.higher 3 : Book.Row) = affineActions[5]! := by decide +kernel
private theorem a6 : affine (410 : Group) (.higher 4 : Book.Row) = affineActions[6]! := by decide +kernel
private theorem a7 : affine (410 : Group) (.higher 5 : Book.Row) = affineActions[7]! := by decide +kernel
private theorem a8 : affine (410 : Group) (.higher 6 : Book.Row) = affineActions[8]! := by decide +kernel
private theorem a9 : affine (410 : Group) (.higher 7 : Book.Row) = affineActions[9]! := by decide +kernel
private theorem a10 : affine (410 : Group) (.higher 8 : Book.Row) = affineActions[10]! := by decide +kernel
private theorem a11 : affine (410 : Group) (.higher 9 : Book.Row) = affineActions[11]! := by decide +kernel
private theorem a12 : affine (410 : Group) (.higher 10 : Book.Row) = affineActions[12]! := by decide +kernel
private theorem a13 : affine (410 : Group) (.higher 11 : Book.Row) = affineActions[13]! := by decide +kernel

private theorem affine_values : affine (410 : Group) = fun k => affineActions[FrozenGuards.code k]! := by
  funext k
  cases k with
  | prime => exact a0
  | sharp => exact a1
  | higher i =>
    fin_cases i
    · exact a2
    · exact a3
    · exact a4
    · exact a5
    · exact a6
    · exact a7
    · exact a8
    · exact a9
    · exact a10
    · exact a11
    · exact a12
    · exact a13
private theorem e0 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.prime : Book.Event) := by decide +kernel
private theorem e1 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.oldFive : Book.Event) := by decide +kernel
private theorem e2 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 0 : Book.Event) := by decide +kernel
private theorem e3 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 1 : Book.Event) := by decide +kernel
private theorem e4 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 2 : Book.Event) := by decide +kernel
private theorem e5 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 3 : Book.Event) := by decide +kernel
private theorem e6 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 4 : Book.Event) := by decide +kernel
private theorem e7 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 5 : Book.Event) := by decide +kernel
private theorem e8 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 6 : Book.Event) := by decide +kernel
private theorem e9 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 7 : Book.Event) := by decide +kernel
private theorem e10 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 8 : Book.Event) := by decide +kernel
private theorem e11 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 9 : Book.Event) := by decide +kernel
private theorem e12 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 10 : Book.Event) := by decide +kernel
private theorem e13 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 11 : Book.Event) := by decide +kernel
private theorem e14 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 0 : Book.Event) := by decide +kernel
private theorem e15 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 1 : Book.Event) := by decide +kernel
private theorem e16 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 2 : Book.Event) := by decide +kernel
private theorem e17 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 3 : Book.Event) := by decide +kernel
private theorem e18 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 4 : Book.Event) := by decide +kernel
private theorem e19 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 5 : Book.Event) := by decide +kernel
private theorem e20 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 6 : Book.Event) := by decide +kernel
private theorem e21 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 7 : Book.Event) := by decide +kernel
private theorem e22 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 8 : Book.Event) := by decide +kernel
private theorem e23 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 9 : Book.Event) := by decide +kernel
private theorem e24 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 10 : Book.Event) := by decide +kernel
private theorem e25 : eventPass (410 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 11 : Book.Event) := by decide +kernel

attribute [local irreducible] eventPass

theorem events (e : Book.Event) : eventPass (410 : Group) (moments 410) (affine 410) e := by
  rw [gram_values,affine_values]
  cases e with
  | prime => exact e0
  | oldFive => exact e1
  | three i =>
    fin_cases i
    · exact e2
    · exact e3
    · exact e4
    · exact e5
    · exact e6
    · exact e7
    · exact e8
    · exact e9
    · exact e10
    · exact e11
    · exact e12
    · exact e13
  | newFive i =>
    fin_cases i
    · exact e14
    · exact e15
    · exact e16
    · exact e17
    · exact e18
    · exact e19
    · exact e20
    · exact e21
    · exact e22
    · exact e23
    · exact e24
    · exact e25

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G410
end


noncomputable section
namespace PrimeGap180.PriceIsolatedGroup.G411
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

declarePriceActions 411
private theorem m0 : PriceFactorData.rowAction 0 411 = gramActions[0]! := by decide +kernel
private theorem m1 : PriceFactorData.rowAction 1 411 = gramActions[1]! := by decide +kernel
private theorem m2 : PriceFactorData.rowAction 2 411 = gramActions[2]! := by decide +kernel
private theorem m3 : PriceFactorData.rowAction 3 411 = gramActions[3]! := by decide +kernel
private theorem m4 : PriceFactorData.rowAction 4 411 = gramActions[4]! := by decide +kernel
private theorem m5 : PriceFactorData.rowAction 5 411 = gramActions[5]! := by decide +kernel
private theorem m6 : PriceFactorData.rowAction 6 411 = gramActions[6]! := by decide +kernel
private theorem m7 : PriceFactorData.rowAction 7 411 = gramActions[7]! := by decide +kernel
private theorem m8 : PriceFactorData.rowAction 8 411 = gramActions[8]! := by decide +kernel
private theorem m9 : PriceFactorData.rowAction 9 411 = gramActions[9]! := by decide +kernel
private theorem m10 : PriceFactorData.rowAction 10 411 = gramActions[10]! := by decide +kernel
private theorem m11 : PriceFactorData.rowAction 11 411 = gramActions[11]! := by decide +kernel
private theorem m12 : PriceFactorData.rowAction 12 411 = gramActions[12]! := by decide +kernel
private theorem m13 : PriceFactorData.rowAction 13 411 = gramActions[13]! := by decide +kernel
private theorem m14 : PriceFactorData.rowAction 14 411 = gramActions[14]! := by decide +kernel
private theorem m15 : PriceFactorData.rowAction 15 411 = gramActions[15]! := by decide +kernel
private theorem m16 : PriceFactorData.rowAction 16 411 = gramActions[16]! := by decide +kernel
private theorem m17 : PriceFactorData.rowAction 17 411 = gramActions[17]! := by decide +kernel
private theorem m18 : PriceFactorData.rowAction 18 411 = gramActions[18]! := by decide +kernel
private theorem m19 : PriceFactorData.rowAction 19 411 = gramActions[19]! := by decide +kernel
private theorem m20 : PriceFactorData.rowAction 20 411 = gramActions[20]! := by decide +kernel
private theorem m21 : PriceFactorData.rowAction 21 411 = gramActions[21]! := by decide +kernel
private theorem m22 : PriceFactorData.rowAction 22 411 = gramActions[22]! := by decide +kernel
private theorem m23 : PriceFactorData.rowAction 23 411 = gramActions[23]! := by decide +kernel
private theorem m24 : PriceFactorData.rowAction 24 411 = gramActions[24]! := by decide +kernel
private theorem m25 : PriceFactorData.rowAction 25 411 = gramActions[25]! := by decide +kernel
private theorem m26 : PriceFactorData.rowAction 26 411 = gramActions[26]! := by decide +kernel
private theorem m27 : PriceFactorData.rowAction 27 411 = gramActions[27]! := by decide +kernel
private theorem m28 : PriceFactorData.rowAction 28 411 = gramActions[28]! := by decide +kernel
private theorem m29 : PriceFactorData.rowAction 29 411 = gramActions[29]! := by decide +kernel
private theorem m30 : PriceFactorData.rowAction 30 411 = gramActions[30]! := by decide +kernel
private theorem m31 : PriceFactorData.rowAction 31 411 = gramActions[31]! := by decide +kernel
private theorem m32 : PriceFactorData.rowAction 32 411 = gramActions[32]! := by decide +kernel
private theorem m33 : PriceFactorData.rowAction 33 411 = gramActions[33]! := by decide +kernel
private theorem m34 : PriceFactorData.rowAction 34 411 = gramActions[34]! := by decide +kernel
private theorem m35 : PriceFactorData.rowAction 35 411 = gramActions[35]! := by decide +kernel
private theorem m36 : PriceFactorData.rowAction 36 411 = gramActions[36]! := by decide +kernel
private theorem m37 : PriceFactorData.rowAction 37 411 = gramActions[37]! := by decide +kernel
private theorem m38 : PriceFactorData.rowAction 38 411 = gramActions[38]! := by decide +kernel
private theorem m39 : PriceFactorData.rowAction 39 411 = gramActions[39]! := by decide +kernel
private theorem m40 : PriceFactorData.rowAction 40 411 = gramActions[40]! := by decide +kernel
private theorem m41 : PriceFactorData.rowAction 41 411 = gramActions[41]! := by decide +kernel
private theorem m42 : PriceFactorData.rowAction 42 411 = gramActions[42]! := by decide +kernel
private theorem m43 : PriceFactorData.rowAction 43 411 = gramActions[43]! := by decide +kernel
private theorem m44 : PriceFactorData.rowAction 44 411 = gramActions[44]! := by decide +kernel
private theorem m45 : PriceFactorData.rowAction 45 411 = gramActions[45]! := by decide +kernel
private theorem m46 : PriceFactorData.rowAction 46 411 = gramActions[46]! := by decide +kernel
private theorem m47 : PriceFactorData.rowAction 47 411 = gramActions[47]! := by decide +kernel
private theorem m48 : PriceFactorData.rowAction 48 411 = gramActions[48]! := by decide +kernel
private theorem m49 : PriceFactorData.rowAction 49 411 = gramActions[49]! := by decide +kernel
private theorem m50 : PriceFactorData.rowAction 50 411 = gramActions[50]! := by decide +kernel
private theorem m51 : PriceFactorData.rowAction 51 411 = gramActions[51]! := by decide +kernel
private theorem m52 : PriceFactorData.rowAction 52 411 = gramActions[52]! := by decide +kernel
private theorem m53 : PriceFactorData.rowAction 53 411 = gramActions[53]! := by decide +kernel
private theorem m54 : PriceFactorData.rowAction 54 411 = gramActions[54]! := by decide +kernel
private theorem m55 : PriceFactorData.rowAction 55 411 = gramActions[55]! := by decide +kernel
private theorem m56 : PriceFactorData.rowAction 56 411 = gramActions[56]! := by decide +kernel
private theorem m57 : PriceFactorData.rowAction 57 411 = gramActions[57]! := by decide +kernel
private theorem m58 : PriceFactorData.rowAction 58 411 = gramActions[58]! := by decide +kernel
private theorem m59 : PriceFactorData.rowAction 59 411 = gramActions[59]! := by decide +kernel
private theorem m60 : PriceFactorData.rowAction 60 411 = gramActions[60]! := by decide +kernel
private theorem m61 : PriceFactorData.rowAction 61 411 = gramActions[61]! := by decide +kernel
private theorem m62 : PriceFactorData.rowAction 62 411 = gramActions[62]! := by decide +kernel
private theorem m63 : PriceFactorData.rowAction 63 411 = gramActions[63]! := by decide +kernel
private theorem m64 : PriceFactorData.rowAction 64 411 = gramActions[64]! := by decide +kernel
private theorem m65 : PriceFactorData.rowAction 65 411 = gramActions[65]! := by decide +kernel
private theorem m66 : PriceFactorData.rowAction 66 411 = gramActions[66]! := by decide +kernel
private theorem m67 : PriceFactorData.rowAction 67 411 = gramActions[67]! := by decide +kernel
private theorem m68 : PriceFactorData.rowAction 68 411 = gramActions[68]! := by decide +kernel
private theorem m69 : PriceFactorData.rowAction 69 411 = gramActions[69]! := by decide +kernel
private theorem m70 : PriceFactorData.rowAction 70 411 = gramActions[70]! := by decide +kernel
private theorem m71 : PriceFactorData.rowAction 71 411 = gramActions[71]! := by decide +kernel
private theorem m72 : PriceFactorData.rowAction 72 411 = gramActions[72]! := by decide +kernel
private theorem m73 : PriceFactorData.rowAction 73 411 = gramActions[73]! := by decide +kernel
private theorem m74 : PriceFactorData.rowAction 74 411 = gramActions[74]! := by decide +kernel
private theorem m75 : PriceFactorData.rowAction 75 411 = gramActions[75]! := by decide +kernel
private theorem m76 : PriceFactorData.rowAction 76 411 = gramActions[76]! := by decide +kernel
private theorem m77 : PriceFactorData.rowAction 77 411 = gramActions[77]! := by decide +kernel
private theorem m78 : PriceFactorData.rowAction 78 411 = gramActions[78]! := by decide +kernel
private theorem m79 : PriceFactorData.rowAction 79 411 = gramActions[79]! := by decide +kernel
private theorem m80 : PriceFactorData.rowAction 80 411 = gramActions[80]! := by decide +kernel
private theorem m81 : PriceFactorData.rowAction 81 411 = gramActions[81]! := by decide +kernel
private theorem m82 : PriceFactorData.rowAction 82 411 = gramActions[82]! := by decide +kernel
private theorem m83 : PriceFactorData.rowAction 83 411 = gramActions[83]! := by decide +kernel
private theorem m84 : PriceFactorData.rowAction 84 411 = gramActions[84]! := by decide +kernel
private theorem m85 : PriceFactorData.rowAction 85 411 = gramActions[85]! := by decide +kernel
private theorem m86 : PriceFactorData.rowAction 86 411 = gramActions[86]! := by decide +kernel
private theorem m87 : PriceFactorData.rowAction 87 411 = gramActions[87]! := by decide +kernel
private theorem m88 : PriceFactorData.rowAction 88 411 = gramActions[88]! := by decide +kernel
private theorem m89 : PriceFactorData.rowAction 89 411 = gramActions[89]! := by decide +kernel
private theorem m90 : PriceFactorData.rowAction 90 411 = gramActions[90]! := by decide +kernel
private theorem m91 : PriceFactorData.rowAction 91 411 = gramActions[91]! := by decide +kernel
private theorem m92 : PriceFactorData.rowAction 92 411 = gramActions[92]! := by decide +kernel
private theorem m93 : PriceFactorData.rowAction 93 411 = gramActions[93]! := by decide +kernel
private theorem m94 : PriceFactorData.rowAction 94 411 = gramActions[94]! := by decide +kernel
private theorem m95 : PriceFactorData.rowAction 95 411 = gramActions[95]! := by decide +kernel
private theorem m96 : PriceFactorData.rowAction 96 411 = gramActions[96]! := by decide +kernel
private theorem m97 : PriceFactorData.rowAction 97 411 = gramActions[97]! := by decide +kernel
private theorem m98 : PriceFactorData.rowAction 98 411 = gramActions[98]! := by decide +kernel
private theorem m99 : PriceFactorData.rowAction 99 411 = gramActions[99]! := by decide +kernel
private theorem m100 : PriceFactorData.rowAction 100 411 = gramActions[100]! := by decide +kernel

attribute [local irreducible] PriceFactorData.rowAction gramActions

private theorem gram_values : moments (411 : Group) = gramActions := by
  apply PriceIsolatedChecks.moments_of_entries
  · decide +kernel
  · intro i
    fin_cases i
    · exact m0
    · exact m1
    · exact m2
    · exact m3
    · exact m4
    · exact m5
    · exact m6
    · exact m7
    · exact m8
    · exact m9
    · exact m10
    · exact m11
    · exact m12
    · exact m13
    · exact m14
    · exact m15
    · exact m16
    · exact m17
    · exact m18
    · exact m19
    · exact m20
    · exact m21
    · exact m22
    · exact m23
    · exact m24
    · exact m25
    · exact m26
    · exact m27
    · exact m28
    · exact m29
    · exact m30
    · exact m31
    · exact m32
    · exact m33
    · exact m34
    · exact m35
    · exact m36
    · exact m37
    · exact m38
    · exact m39
    · exact m40
    · exact m41
    · exact m42
    · exact m43
    · exact m44
    · exact m45
    · exact m46
    · exact m47
    · exact m48
    · exact m49
    · exact m50
    · exact m51
    · exact m52
    · exact m53
    · exact m54
    · exact m55
    · exact m56
    · exact m57
    · exact m58
    · exact m59
    · exact m60
    · exact m61
    · exact m62
    · exact m63
    · exact m64
    · exact m65
    · exact m66
    · exact m67
    · exact m68
    · exact m69
    · exact m70
    · exact m71
    · exact m72
    · exact m73
    · exact m74
    · exact m75
    · exact m76
    · exact m77
    · exact m78
    · exact m79
    · exact m80
    · exact m81
    · exact m82
    · exact m83
    · exact m84
    · exact m85
    · exact m86
    · exact m87
    · exact m88
    · exact m89
    · exact m90
    · exact m91
    · exact m92
    · exact m93
    · exact m94
    · exact m95
    · exact m96
    · exact m97
    · exact m98
    · exact m99
    · exact m100
private theorem a0 : affine (411 : Group) (.prime : Book.Row) = affineActions[0]! := by decide +kernel
private theorem a1 : affine (411 : Group) (.sharp : Book.Row) = affineActions[1]! := by decide +kernel
private theorem a2 : affine (411 : Group) (.higher 0 : Book.Row) = affineActions[2]! := by decide +kernel
private theorem a3 : affine (411 : Group) (.higher 1 : Book.Row) = affineActions[3]! := by decide +kernel
private theorem a4 : affine (411 : Group) (.higher 2 : Book.Row) = affineActions[4]! := by decide +kernel
private theorem a5 : affine (411 : Group) (.higher 3 : Book.Row) = affineActions[5]! := by decide +kernel
private theorem a6 : affine (411 : Group) (.higher 4 : Book.Row) = affineActions[6]! := by decide +kernel
private theorem a7 : affine (411 : Group) (.higher 5 : Book.Row) = affineActions[7]! := by decide +kernel
private theorem a8 : affine (411 : Group) (.higher 6 : Book.Row) = affineActions[8]! := by decide +kernel
private theorem a9 : affine (411 : Group) (.higher 7 : Book.Row) = affineActions[9]! := by decide +kernel
private theorem a10 : affine (411 : Group) (.higher 8 : Book.Row) = affineActions[10]! := by decide +kernel
private theorem a11 : affine (411 : Group) (.higher 9 : Book.Row) = affineActions[11]! := by decide +kernel
private theorem a12 : affine (411 : Group) (.higher 10 : Book.Row) = affineActions[12]! := by decide +kernel
private theorem a13 : affine (411 : Group) (.higher 11 : Book.Row) = affineActions[13]! := by decide +kernel

private theorem affine_values : affine (411 : Group) = fun k => affineActions[FrozenGuards.code k]! := by
  funext k
  cases k with
  | prime => exact a0
  | sharp => exact a1
  | higher i =>
    fin_cases i
    · exact a2
    · exact a3
    · exact a4
    · exact a5
    · exact a6
    · exact a7
    · exact a8
    · exact a9
    · exact a10
    · exact a11
    · exact a12
    · exact a13
private theorem e0 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.prime : Book.Event) := by decide +kernel
private theorem e1 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.oldFive : Book.Event) := by decide +kernel
private theorem e2 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 0 : Book.Event) := by decide +kernel
private theorem e3 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 1 : Book.Event) := by decide +kernel
private theorem e4 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 2 : Book.Event) := by decide +kernel
private theorem e5 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 3 : Book.Event) := by decide +kernel
private theorem e6 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 4 : Book.Event) := by decide +kernel
private theorem e7 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 5 : Book.Event) := by decide +kernel
private theorem e8 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 6 : Book.Event) := by decide +kernel
private theorem e9 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 7 : Book.Event) := by decide +kernel
private theorem e10 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 8 : Book.Event) := by decide +kernel
private theorem e11 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 9 : Book.Event) := by decide +kernel
private theorem e12 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 10 : Book.Event) := by decide +kernel
private theorem e13 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 11 : Book.Event) := by decide +kernel
private theorem e14 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 0 : Book.Event) := by decide +kernel
private theorem e15 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 1 : Book.Event) := by decide +kernel
private theorem e16 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 2 : Book.Event) := by decide +kernel
private theorem e17 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 3 : Book.Event) := by decide +kernel
private theorem e18 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 4 : Book.Event) := by decide +kernel
private theorem e19 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 5 : Book.Event) := by decide +kernel
private theorem e20 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 6 : Book.Event) := by decide +kernel
private theorem e21 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 7 : Book.Event) := by decide +kernel
private theorem e22 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 8 : Book.Event) := by decide +kernel
private theorem e23 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 9 : Book.Event) := by decide +kernel
private theorem e24 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 10 : Book.Event) := by decide +kernel
private theorem e25 : eventPass (411 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 11 : Book.Event) := by decide +kernel

attribute [local irreducible] eventPass

theorem events (e : Book.Event) : eventPass (411 : Group) (moments 411) (affine 411) e := by
  rw [gram_values,affine_values]
  cases e with
  | prime => exact e0
  | oldFive => exact e1
  | three i =>
    fin_cases i
    · exact e2
    · exact e3
    · exact e4
    · exact e5
    · exact e6
    · exact e7
    · exact e8
    · exact e9
    · exact e10
    · exact e11
    · exact e12
    · exact e13
  | newFive i =>
    fin_cases i
    · exact e14
    · exact e15
    · exact e16
    · exact e17
    · exact e18
    · exact e19
    · exact e20
    · exact e21
    · exact e22
    · exact e23
    · exact e24
    · exact e25

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G411
end


noncomputable section
namespace PrimeGap180.PriceIsolatedGroup.G412
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

declarePriceActions 412
private theorem m0 : PriceFactorData.rowAction 0 412 = gramActions[0]! := by decide +kernel
private theorem m1 : PriceFactorData.rowAction 1 412 = gramActions[1]! := by decide +kernel
private theorem m2 : PriceFactorData.rowAction 2 412 = gramActions[2]! := by decide +kernel
private theorem m3 : PriceFactorData.rowAction 3 412 = gramActions[3]! := by decide +kernel
private theorem m4 : PriceFactorData.rowAction 4 412 = gramActions[4]! := by decide +kernel
private theorem m5 : PriceFactorData.rowAction 5 412 = gramActions[5]! := by decide +kernel
private theorem m6 : PriceFactorData.rowAction 6 412 = gramActions[6]! := by decide +kernel
private theorem m7 : PriceFactorData.rowAction 7 412 = gramActions[7]! := by decide +kernel
private theorem m8 : PriceFactorData.rowAction 8 412 = gramActions[8]! := by decide +kernel
private theorem m9 : PriceFactorData.rowAction 9 412 = gramActions[9]! := by decide +kernel
private theorem m10 : PriceFactorData.rowAction 10 412 = gramActions[10]! := by decide +kernel
private theorem m11 : PriceFactorData.rowAction 11 412 = gramActions[11]! := by decide +kernel
private theorem m12 : PriceFactorData.rowAction 12 412 = gramActions[12]! := by decide +kernel
private theorem m13 : PriceFactorData.rowAction 13 412 = gramActions[13]! := by decide +kernel
private theorem m14 : PriceFactorData.rowAction 14 412 = gramActions[14]! := by decide +kernel
private theorem m15 : PriceFactorData.rowAction 15 412 = gramActions[15]! := by decide +kernel
private theorem m16 : PriceFactorData.rowAction 16 412 = gramActions[16]! := by decide +kernel
private theorem m17 : PriceFactorData.rowAction 17 412 = gramActions[17]! := by decide +kernel
private theorem m18 : PriceFactorData.rowAction 18 412 = gramActions[18]! := by decide +kernel
private theorem m19 : PriceFactorData.rowAction 19 412 = gramActions[19]! := by decide +kernel
private theorem m20 : PriceFactorData.rowAction 20 412 = gramActions[20]! := by decide +kernel
private theorem m21 : PriceFactorData.rowAction 21 412 = gramActions[21]! := by decide +kernel
private theorem m22 : PriceFactorData.rowAction 22 412 = gramActions[22]! := by decide +kernel
private theorem m23 : PriceFactorData.rowAction 23 412 = gramActions[23]! := by decide +kernel
private theorem m24 : PriceFactorData.rowAction 24 412 = gramActions[24]! := by decide +kernel
private theorem m25 : PriceFactorData.rowAction 25 412 = gramActions[25]! := by decide +kernel
private theorem m26 : PriceFactorData.rowAction 26 412 = gramActions[26]! := by decide +kernel
private theorem m27 : PriceFactorData.rowAction 27 412 = gramActions[27]! := by decide +kernel
private theorem m28 : PriceFactorData.rowAction 28 412 = gramActions[28]! := by decide +kernel
private theorem m29 : PriceFactorData.rowAction 29 412 = gramActions[29]! := by decide +kernel
private theorem m30 : PriceFactorData.rowAction 30 412 = gramActions[30]! := by decide +kernel
private theorem m31 : PriceFactorData.rowAction 31 412 = gramActions[31]! := by decide +kernel
private theorem m32 : PriceFactorData.rowAction 32 412 = gramActions[32]! := by decide +kernel
private theorem m33 : PriceFactorData.rowAction 33 412 = gramActions[33]! := by decide +kernel
private theorem m34 : PriceFactorData.rowAction 34 412 = gramActions[34]! := by decide +kernel
private theorem m35 : PriceFactorData.rowAction 35 412 = gramActions[35]! := by decide +kernel
private theorem m36 : PriceFactorData.rowAction 36 412 = gramActions[36]! := by decide +kernel
private theorem m37 : PriceFactorData.rowAction 37 412 = gramActions[37]! := by decide +kernel
private theorem m38 : PriceFactorData.rowAction 38 412 = gramActions[38]! := by decide +kernel
private theorem m39 : PriceFactorData.rowAction 39 412 = gramActions[39]! := by decide +kernel
private theorem m40 : PriceFactorData.rowAction 40 412 = gramActions[40]! := by decide +kernel
private theorem m41 : PriceFactorData.rowAction 41 412 = gramActions[41]! := by decide +kernel
private theorem m42 : PriceFactorData.rowAction 42 412 = gramActions[42]! := by decide +kernel
private theorem m43 : PriceFactorData.rowAction 43 412 = gramActions[43]! := by decide +kernel
private theorem m44 : PriceFactorData.rowAction 44 412 = gramActions[44]! := by decide +kernel
private theorem m45 : PriceFactorData.rowAction 45 412 = gramActions[45]! := by decide +kernel
private theorem m46 : PriceFactorData.rowAction 46 412 = gramActions[46]! := by decide +kernel
private theorem m47 : PriceFactorData.rowAction 47 412 = gramActions[47]! := by decide +kernel
private theorem m48 : PriceFactorData.rowAction 48 412 = gramActions[48]! := by decide +kernel
private theorem m49 : PriceFactorData.rowAction 49 412 = gramActions[49]! := by decide +kernel
private theorem m50 : PriceFactorData.rowAction 50 412 = gramActions[50]! := by decide +kernel
private theorem m51 : PriceFactorData.rowAction 51 412 = gramActions[51]! := by decide +kernel
private theorem m52 : PriceFactorData.rowAction 52 412 = gramActions[52]! := by decide +kernel
private theorem m53 : PriceFactorData.rowAction 53 412 = gramActions[53]! := by decide +kernel
private theorem m54 : PriceFactorData.rowAction 54 412 = gramActions[54]! := by decide +kernel
private theorem m55 : PriceFactorData.rowAction 55 412 = gramActions[55]! := by decide +kernel
private theorem m56 : PriceFactorData.rowAction 56 412 = gramActions[56]! := by decide +kernel
private theorem m57 : PriceFactorData.rowAction 57 412 = gramActions[57]! := by decide +kernel
private theorem m58 : PriceFactorData.rowAction 58 412 = gramActions[58]! := by decide +kernel
private theorem m59 : PriceFactorData.rowAction 59 412 = gramActions[59]! := by decide +kernel
private theorem m60 : PriceFactorData.rowAction 60 412 = gramActions[60]! := by decide +kernel
private theorem m61 : PriceFactorData.rowAction 61 412 = gramActions[61]! := by decide +kernel
private theorem m62 : PriceFactorData.rowAction 62 412 = gramActions[62]! := by decide +kernel
private theorem m63 : PriceFactorData.rowAction 63 412 = gramActions[63]! := by decide +kernel
private theorem m64 : PriceFactorData.rowAction 64 412 = gramActions[64]! := by decide +kernel
private theorem m65 : PriceFactorData.rowAction 65 412 = gramActions[65]! := by decide +kernel
private theorem m66 : PriceFactorData.rowAction 66 412 = gramActions[66]! := by decide +kernel
private theorem m67 : PriceFactorData.rowAction 67 412 = gramActions[67]! := by decide +kernel
private theorem m68 : PriceFactorData.rowAction 68 412 = gramActions[68]! := by decide +kernel
private theorem m69 : PriceFactorData.rowAction 69 412 = gramActions[69]! := by decide +kernel
private theorem m70 : PriceFactorData.rowAction 70 412 = gramActions[70]! := by decide +kernel
private theorem m71 : PriceFactorData.rowAction 71 412 = gramActions[71]! := by decide +kernel
private theorem m72 : PriceFactorData.rowAction 72 412 = gramActions[72]! := by decide +kernel
private theorem m73 : PriceFactorData.rowAction 73 412 = gramActions[73]! := by decide +kernel
private theorem m74 : PriceFactorData.rowAction 74 412 = gramActions[74]! := by decide +kernel
private theorem m75 : PriceFactorData.rowAction 75 412 = gramActions[75]! := by decide +kernel
private theorem m76 : PriceFactorData.rowAction 76 412 = gramActions[76]! := by decide +kernel
private theorem m77 : PriceFactorData.rowAction 77 412 = gramActions[77]! := by decide +kernel
private theorem m78 : PriceFactorData.rowAction 78 412 = gramActions[78]! := by decide +kernel
private theorem m79 : PriceFactorData.rowAction 79 412 = gramActions[79]! := by decide +kernel
private theorem m80 : PriceFactorData.rowAction 80 412 = gramActions[80]! := by decide +kernel
private theorem m81 : PriceFactorData.rowAction 81 412 = gramActions[81]! := by decide +kernel
private theorem m82 : PriceFactorData.rowAction 82 412 = gramActions[82]! := by decide +kernel
private theorem m83 : PriceFactorData.rowAction 83 412 = gramActions[83]! := by decide +kernel
private theorem m84 : PriceFactorData.rowAction 84 412 = gramActions[84]! := by decide +kernel
private theorem m85 : PriceFactorData.rowAction 85 412 = gramActions[85]! := by decide +kernel
private theorem m86 : PriceFactorData.rowAction 86 412 = gramActions[86]! := by decide +kernel
private theorem m87 : PriceFactorData.rowAction 87 412 = gramActions[87]! := by decide +kernel
private theorem m88 : PriceFactorData.rowAction 88 412 = gramActions[88]! := by decide +kernel
private theorem m89 : PriceFactorData.rowAction 89 412 = gramActions[89]! := by decide +kernel
private theorem m90 : PriceFactorData.rowAction 90 412 = gramActions[90]! := by decide +kernel
private theorem m91 : PriceFactorData.rowAction 91 412 = gramActions[91]! := by decide +kernel
private theorem m92 : PriceFactorData.rowAction 92 412 = gramActions[92]! := by decide +kernel
private theorem m93 : PriceFactorData.rowAction 93 412 = gramActions[93]! := by decide +kernel
private theorem m94 : PriceFactorData.rowAction 94 412 = gramActions[94]! := by decide +kernel
private theorem m95 : PriceFactorData.rowAction 95 412 = gramActions[95]! := by decide +kernel
private theorem m96 : PriceFactorData.rowAction 96 412 = gramActions[96]! := by decide +kernel
private theorem m97 : PriceFactorData.rowAction 97 412 = gramActions[97]! := by decide +kernel
private theorem m98 : PriceFactorData.rowAction 98 412 = gramActions[98]! := by decide +kernel
private theorem m99 : PriceFactorData.rowAction 99 412 = gramActions[99]! := by decide +kernel
private theorem m100 : PriceFactorData.rowAction 100 412 = gramActions[100]! := by decide +kernel

attribute [local irreducible] PriceFactorData.rowAction gramActions

private theorem gram_values : moments (412 : Group) = gramActions := by
  apply PriceIsolatedChecks.moments_of_entries
  · decide +kernel
  · intro i
    fin_cases i
    · exact m0
    · exact m1
    · exact m2
    · exact m3
    · exact m4
    · exact m5
    · exact m6
    · exact m7
    · exact m8
    · exact m9
    · exact m10
    · exact m11
    · exact m12
    · exact m13
    · exact m14
    · exact m15
    · exact m16
    · exact m17
    · exact m18
    · exact m19
    · exact m20
    · exact m21
    · exact m22
    · exact m23
    · exact m24
    · exact m25
    · exact m26
    · exact m27
    · exact m28
    · exact m29
    · exact m30
    · exact m31
    · exact m32
    · exact m33
    · exact m34
    · exact m35
    · exact m36
    · exact m37
    · exact m38
    · exact m39
    · exact m40
    · exact m41
    · exact m42
    · exact m43
    · exact m44
    · exact m45
    · exact m46
    · exact m47
    · exact m48
    · exact m49
    · exact m50
    · exact m51
    · exact m52
    · exact m53
    · exact m54
    · exact m55
    · exact m56
    · exact m57
    · exact m58
    · exact m59
    · exact m60
    · exact m61
    · exact m62
    · exact m63
    · exact m64
    · exact m65
    · exact m66
    · exact m67
    · exact m68
    · exact m69
    · exact m70
    · exact m71
    · exact m72
    · exact m73
    · exact m74
    · exact m75
    · exact m76
    · exact m77
    · exact m78
    · exact m79
    · exact m80
    · exact m81
    · exact m82
    · exact m83
    · exact m84
    · exact m85
    · exact m86
    · exact m87
    · exact m88
    · exact m89
    · exact m90
    · exact m91
    · exact m92
    · exact m93
    · exact m94
    · exact m95
    · exact m96
    · exact m97
    · exact m98
    · exact m99
    · exact m100
private theorem a0 : affine (412 : Group) (.prime : Book.Row) = affineActions[0]! := by decide +kernel
private theorem a1 : affine (412 : Group) (.sharp : Book.Row) = affineActions[1]! := by decide +kernel
private theorem a2 : affine (412 : Group) (.higher 0 : Book.Row) = affineActions[2]! := by decide +kernel
private theorem a3 : affine (412 : Group) (.higher 1 : Book.Row) = affineActions[3]! := by decide +kernel
private theorem a4 : affine (412 : Group) (.higher 2 : Book.Row) = affineActions[4]! := by decide +kernel
private theorem a5 : affine (412 : Group) (.higher 3 : Book.Row) = affineActions[5]! := by decide +kernel
private theorem a6 : affine (412 : Group) (.higher 4 : Book.Row) = affineActions[6]! := by decide +kernel
private theorem a7 : affine (412 : Group) (.higher 5 : Book.Row) = affineActions[7]! := by decide +kernel
private theorem a8 : affine (412 : Group) (.higher 6 : Book.Row) = affineActions[8]! := by decide +kernel
private theorem a9 : affine (412 : Group) (.higher 7 : Book.Row) = affineActions[9]! := by decide +kernel
private theorem a10 : affine (412 : Group) (.higher 8 : Book.Row) = affineActions[10]! := by decide +kernel
private theorem a11 : affine (412 : Group) (.higher 9 : Book.Row) = affineActions[11]! := by decide +kernel
private theorem a12 : affine (412 : Group) (.higher 10 : Book.Row) = affineActions[12]! := by decide +kernel
private theorem a13 : affine (412 : Group) (.higher 11 : Book.Row) = affineActions[13]! := by decide +kernel

private theorem affine_values : affine (412 : Group) = fun k => affineActions[FrozenGuards.code k]! := by
  funext k
  cases k with
  | prime => exact a0
  | sharp => exact a1
  | higher i =>
    fin_cases i
    · exact a2
    · exact a3
    · exact a4
    · exact a5
    · exact a6
    · exact a7
    · exact a8
    · exact a9
    · exact a10
    · exact a11
    · exact a12
    · exact a13
private theorem e0 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.prime : Book.Event) := by decide +kernel
private theorem e1 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.oldFive : Book.Event) := by decide +kernel
private theorem e2 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 0 : Book.Event) := by decide +kernel
private theorem e3 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 1 : Book.Event) := by decide +kernel
private theorem e4 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 2 : Book.Event) := by decide +kernel
private theorem e5 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 3 : Book.Event) := by decide +kernel
private theorem e6 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 4 : Book.Event) := by decide +kernel
private theorem e7 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 5 : Book.Event) := by decide +kernel
private theorem e8 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 6 : Book.Event) := by decide +kernel
private theorem e9 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 7 : Book.Event) := by decide +kernel
private theorem e10 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 8 : Book.Event) := by decide +kernel
private theorem e11 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 9 : Book.Event) := by decide +kernel
private theorem e12 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 10 : Book.Event) := by decide +kernel
private theorem e13 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 11 : Book.Event) := by decide +kernel
private theorem e14 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 0 : Book.Event) := by decide +kernel
private theorem e15 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 1 : Book.Event) := by decide +kernel
private theorem e16 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 2 : Book.Event) := by decide +kernel
private theorem e17 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 3 : Book.Event) := by decide +kernel
private theorem e18 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 4 : Book.Event) := by decide +kernel
private theorem e19 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 5 : Book.Event) := by decide +kernel
private theorem e20 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 6 : Book.Event) := by decide +kernel
private theorem e21 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 7 : Book.Event) := by decide +kernel
private theorem e22 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 8 : Book.Event) := by decide +kernel
private theorem e23 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 9 : Book.Event) := by decide +kernel
private theorem e24 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 10 : Book.Event) := by decide +kernel
private theorem e25 : eventPass (412 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 11 : Book.Event) := by decide +kernel

attribute [local irreducible] eventPass

theorem events (e : Book.Event) : eventPass (412 : Group) (moments 412) (affine 412) e := by
  rw [gram_values,affine_values]
  cases e with
  | prime => exact e0
  | oldFive => exact e1
  | three i =>
    fin_cases i
    · exact e2
    · exact e3
    · exact e4
    · exact e5
    · exact e6
    · exact e7
    · exact e8
    · exact e9
    · exact e10
    · exact e11
    · exact e12
    · exact e13
  | newFive i =>
    fin_cases i
    · exact e14
    · exact e15
    · exact e16
    · exact e17
    · exact e18
    · exact e19
    · exact e20
    · exact e21
    · exact e22
    · exact e23
    · exact e24
    · exact e25

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G412
end


noncomputable section
namespace PrimeGap180.PriceIsolatedGroup.G413
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

declarePriceActions 413
private theorem m0 : PriceFactorData.rowAction 0 413 = gramActions[0]! := by decide +kernel
private theorem m1 : PriceFactorData.rowAction 1 413 = gramActions[1]! := by decide +kernel
private theorem m2 : PriceFactorData.rowAction 2 413 = gramActions[2]! := by decide +kernel
private theorem m3 : PriceFactorData.rowAction 3 413 = gramActions[3]! := by decide +kernel
private theorem m4 : PriceFactorData.rowAction 4 413 = gramActions[4]! := by decide +kernel
private theorem m5 : PriceFactorData.rowAction 5 413 = gramActions[5]! := by decide +kernel
private theorem m6 : PriceFactorData.rowAction 6 413 = gramActions[6]! := by decide +kernel
private theorem m7 : PriceFactorData.rowAction 7 413 = gramActions[7]! := by decide +kernel
private theorem m8 : PriceFactorData.rowAction 8 413 = gramActions[8]! := by decide +kernel
private theorem m9 : PriceFactorData.rowAction 9 413 = gramActions[9]! := by decide +kernel
private theorem m10 : PriceFactorData.rowAction 10 413 = gramActions[10]! := by decide +kernel
private theorem m11 : PriceFactorData.rowAction 11 413 = gramActions[11]! := by decide +kernel
private theorem m12 : PriceFactorData.rowAction 12 413 = gramActions[12]! := by decide +kernel
private theorem m13 : PriceFactorData.rowAction 13 413 = gramActions[13]! := by decide +kernel
private theorem m14 : PriceFactorData.rowAction 14 413 = gramActions[14]! := by decide +kernel
private theorem m15 : PriceFactorData.rowAction 15 413 = gramActions[15]! := by decide +kernel
private theorem m16 : PriceFactorData.rowAction 16 413 = gramActions[16]! := by decide +kernel
private theorem m17 : PriceFactorData.rowAction 17 413 = gramActions[17]! := by decide +kernel
private theorem m18 : PriceFactorData.rowAction 18 413 = gramActions[18]! := by decide +kernel
private theorem m19 : PriceFactorData.rowAction 19 413 = gramActions[19]! := by decide +kernel
private theorem m20 : PriceFactorData.rowAction 20 413 = gramActions[20]! := by decide +kernel
private theorem m21 : PriceFactorData.rowAction 21 413 = gramActions[21]! := by decide +kernel
private theorem m22 : PriceFactorData.rowAction 22 413 = gramActions[22]! := by decide +kernel
private theorem m23 : PriceFactorData.rowAction 23 413 = gramActions[23]! := by decide +kernel
private theorem m24 : PriceFactorData.rowAction 24 413 = gramActions[24]! := by decide +kernel
private theorem m25 : PriceFactorData.rowAction 25 413 = gramActions[25]! := by decide +kernel
private theorem m26 : PriceFactorData.rowAction 26 413 = gramActions[26]! := by decide +kernel
private theorem m27 : PriceFactorData.rowAction 27 413 = gramActions[27]! := by decide +kernel
private theorem m28 : PriceFactorData.rowAction 28 413 = gramActions[28]! := by decide +kernel
private theorem m29 : PriceFactorData.rowAction 29 413 = gramActions[29]! := by decide +kernel
private theorem m30 : PriceFactorData.rowAction 30 413 = gramActions[30]! := by decide +kernel
private theorem m31 : PriceFactorData.rowAction 31 413 = gramActions[31]! := by decide +kernel
private theorem m32 : PriceFactorData.rowAction 32 413 = gramActions[32]! := by decide +kernel
private theorem m33 : PriceFactorData.rowAction 33 413 = gramActions[33]! := by decide +kernel
private theorem m34 : PriceFactorData.rowAction 34 413 = gramActions[34]! := by decide +kernel
private theorem m35 : PriceFactorData.rowAction 35 413 = gramActions[35]! := by decide +kernel
private theorem m36 : PriceFactorData.rowAction 36 413 = gramActions[36]! := by decide +kernel
private theorem m37 : PriceFactorData.rowAction 37 413 = gramActions[37]! := by decide +kernel
private theorem m38 : PriceFactorData.rowAction 38 413 = gramActions[38]! := by decide +kernel
private theorem m39 : PriceFactorData.rowAction 39 413 = gramActions[39]! := by decide +kernel
private theorem m40 : PriceFactorData.rowAction 40 413 = gramActions[40]! := by decide +kernel
private theorem m41 : PriceFactorData.rowAction 41 413 = gramActions[41]! := by decide +kernel
private theorem m42 : PriceFactorData.rowAction 42 413 = gramActions[42]! := by decide +kernel
private theorem m43 : PriceFactorData.rowAction 43 413 = gramActions[43]! := by decide +kernel
private theorem m44 : PriceFactorData.rowAction 44 413 = gramActions[44]! := by decide +kernel
private theorem m45 : PriceFactorData.rowAction 45 413 = gramActions[45]! := by decide +kernel
private theorem m46 : PriceFactorData.rowAction 46 413 = gramActions[46]! := by decide +kernel
private theorem m47 : PriceFactorData.rowAction 47 413 = gramActions[47]! := by decide +kernel
private theorem m48 : PriceFactorData.rowAction 48 413 = gramActions[48]! := by decide +kernel
private theorem m49 : PriceFactorData.rowAction 49 413 = gramActions[49]! := by decide +kernel
private theorem m50 : PriceFactorData.rowAction 50 413 = gramActions[50]! := by decide +kernel
private theorem m51 : PriceFactorData.rowAction 51 413 = gramActions[51]! := by decide +kernel
private theorem m52 : PriceFactorData.rowAction 52 413 = gramActions[52]! := by decide +kernel
private theorem m53 : PriceFactorData.rowAction 53 413 = gramActions[53]! := by decide +kernel
private theorem m54 : PriceFactorData.rowAction 54 413 = gramActions[54]! := by decide +kernel
private theorem m55 : PriceFactorData.rowAction 55 413 = gramActions[55]! := by decide +kernel
private theorem m56 : PriceFactorData.rowAction 56 413 = gramActions[56]! := by decide +kernel
private theorem m57 : PriceFactorData.rowAction 57 413 = gramActions[57]! := by decide +kernel
private theorem m58 : PriceFactorData.rowAction 58 413 = gramActions[58]! := by decide +kernel
private theorem m59 : PriceFactorData.rowAction 59 413 = gramActions[59]! := by decide +kernel
private theorem m60 : PriceFactorData.rowAction 60 413 = gramActions[60]! := by decide +kernel
private theorem m61 : PriceFactorData.rowAction 61 413 = gramActions[61]! := by decide +kernel
private theorem m62 : PriceFactorData.rowAction 62 413 = gramActions[62]! := by decide +kernel
private theorem m63 : PriceFactorData.rowAction 63 413 = gramActions[63]! := by decide +kernel
private theorem m64 : PriceFactorData.rowAction 64 413 = gramActions[64]! := by decide +kernel
private theorem m65 : PriceFactorData.rowAction 65 413 = gramActions[65]! := by decide +kernel
private theorem m66 : PriceFactorData.rowAction 66 413 = gramActions[66]! := by decide +kernel
private theorem m67 : PriceFactorData.rowAction 67 413 = gramActions[67]! := by decide +kernel
private theorem m68 : PriceFactorData.rowAction 68 413 = gramActions[68]! := by decide +kernel
private theorem m69 : PriceFactorData.rowAction 69 413 = gramActions[69]! := by decide +kernel
private theorem m70 : PriceFactorData.rowAction 70 413 = gramActions[70]! := by decide +kernel
private theorem m71 : PriceFactorData.rowAction 71 413 = gramActions[71]! := by decide +kernel
private theorem m72 : PriceFactorData.rowAction 72 413 = gramActions[72]! := by decide +kernel
private theorem m73 : PriceFactorData.rowAction 73 413 = gramActions[73]! := by decide +kernel
private theorem m74 : PriceFactorData.rowAction 74 413 = gramActions[74]! := by decide +kernel
private theorem m75 : PriceFactorData.rowAction 75 413 = gramActions[75]! := by decide +kernel
private theorem m76 : PriceFactorData.rowAction 76 413 = gramActions[76]! := by decide +kernel
private theorem m77 : PriceFactorData.rowAction 77 413 = gramActions[77]! := by decide +kernel
private theorem m78 : PriceFactorData.rowAction 78 413 = gramActions[78]! := by decide +kernel
private theorem m79 : PriceFactorData.rowAction 79 413 = gramActions[79]! := by decide +kernel
private theorem m80 : PriceFactorData.rowAction 80 413 = gramActions[80]! := by decide +kernel
private theorem m81 : PriceFactorData.rowAction 81 413 = gramActions[81]! := by decide +kernel
private theorem m82 : PriceFactorData.rowAction 82 413 = gramActions[82]! := by decide +kernel
private theorem m83 : PriceFactorData.rowAction 83 413 = gramActions[83]! := by decide +kernel
private theorem m84 : PriceFactorData.rowAction 84 413 = gramActions[84]! := by decide +kernel
private theorem m85 : PriceFactorData.rowAction 85 413 = gramActions[85]! := by decide +kernel
private theorem m86 : PriceFactorData.rowAction 86 413 = gramActions[86]! := by decide +kernel
private theorem m87 : PriceFactorData.rowAction 87 413 = gramActions[87]! := by decide +kernel
private theorem m88 : PriceFactorData.rowAction 88 413 = gramActions[88]! := by decide +kernel
private theorem m89 : PriceFactorData.rowAction 89 413 = gramActions[89]! := by decide +kernel
private theorem m90 : PriceFactorData.rowAction 90 413 = gramActions[90]! := by decide +kernel
private theorem m91 : PriceFactorData.rowAction 91 413 = gramActions[91]! := by decide +kernel
private theorem m92 : PriceFactorData.rowAction 92 413 = gramActions[92]! := by decide +kernel
private theorem m93 : PriceFactorData.rowAction 93 413 = gramActions[93]! := by decide +kernel
private theorem m94 : PriceFactorData.rowAction 94 413 = gramActions[94]! := by decide +kernel
private theorem m95 : PriceFactorData.rowAction 95 413 = gramActions[95]! := by decide +kernel
private theorem m96 : PriceFactorData.rowAction 96 413 = gramActions[96]! := by decide +kernel
private theorem m97 : PriceFactorData.rowAction 97 413 = gramActions[97]! := by decide +kernel
private theorem m98 : PriceFactorData.rowAction 98 413 = gramActions[98]! := by decide +kernel
private theorem m99 : PriceFactorData.rowAction 99 413 = gramActions[99]! := by decide +kernel
private theorem m100 : PriceFactorData.rowAction 100 413 = gramActions[100]! := by decide +kernel

attribute [local irreducible] PriceFactorData.rowAction gramActions

private theorem gram_values : moments (413 : Group) = gramActions := by
  apply PriceIsolatedChecks.moments_of_entries
  · decide +kernel
  · intro i
    fin_cases i
    · exact m0
    · exact m1
    · exact m2
    · exact m3
    · exact m4
    · exact m5
    · exact m6
    · exact m7
    · exact m8
    · exact m9
    · exact m10
    · exact m11
    · exact m12
    · exact m13
    · exact m14
    · exact m15
    · exact m16
    · exact m17
    · exact m18
    · exact m19
    · exact m20
    · exact m21
    · exact m22
    · exact m23
    · exact m24
    · exact m25
    · exact m26
    · exact m27
    · exact m28
    · exact m29
    · exact m30
    · exact m31
    · exact m32
    · exact m33
    · exact m34
    · exact m35
    · exact m36
    · exact m37
    · exact m38
    · exact m39
    · exact m40
    · exact m41
    · exact m42
    · exact m43
    · exact m44
    · exact m45
    · exact m46
    · exact m47
    · exact m48
    · exact m49
    · exact m50
    · exact m51
    · exact m52
    · exact m53
    · exact m54
    · exact m55
    · exact m56
    · exact m57
    · exact m58
    · exact m59
    · exact m60
    · exact m61
    · exact m62
    · exact m63
    · exact m64
    · exact m65
    · exact m66
    · exact m67
    · exact m68
    · exact m69
    · exact m70
    · exact m71
    · exact m72
    · exact m73
    · exact m74
    · exact m75
    · exact m76
    · exact m77
    · exact m78
    · exact m79
    · exact m80
    · exact m81
    · exact m82
    · exact m83
    · exact m84
    · exact m85
    · exact m86
    · exact m87
    · exact m88
    · exact m89
    · exact m90
    · exact m91
    · exact m92
    · exact m93
    · exact m94
    · exact m95
    · exact m96
    · exact m97
    · exact m98
    · exact m99
    · exact m100
private theorem a0 : affine (413 : Group) (.prime : Book.Row) = affineActions[0]! := by decide +kernel
private theorem a1 : affine (413 : Group) (.sharp : Book.Row) = affineActions[1]! := by decide +kernel
private theorem a2 : affine (413 : Group) (.higher 0 : Book.Row) = affineActions[2]! := by decide +kernel
private theorem a3 : affine (413 : Group) (.higher 1 : Book.Row) = affineActions[3]! := by decide +kernel
private theorem a4 : affine (413 : Group) (.higher 2 : Book.Row) = affineActions[4]! := by decide +kernel
private theorem a5 : affine (413 : Group) (.higher 3 : Book.Row) = affineActions[5]! := by decide +kernel
private theorem a6 : affine (413 : Group) (.higher 4 : Book.Row) = affineActions[6]! := by decide +kernel
private theorem a7 : affine (413 : Group) (.higher 5 : Book.Row) = affineActions[7]! := by decide +kernel
private theorem a8 : affine (413 : Group) (.higher 6 : Book.Row) = affineActions[8]! := by decide +kernel
private theorem a9 : affine (413 : Group) (.higher 7 : Book.Row) = affineActions[9]! := by decide +kernel
private theorem a10 : affine (413 : Group) (.higher 8 : Book.Row) = affineActions[10]! := by decide +kernel
private theorem a11 : affine (413 : Group) (.higher 9 : Book.Row) = affineActions[11]! := by decide +kernel
private theorem a12 : affine (413 : Group) (.higher 10 : Book.Row) = affineActions[12]! := by decide +kernel
private theorem a13 : affine (413 : Group) (.higher 11 : Book.Row) = affineActions[13]! := by decide +kernel

private theorem affine_values : affine (413 : Group) = fun k => affineActions[FrozenGuards.code k]! := by
  funext k
  cases k with
  | prime => exact a0
  | sharp => exact a1
  | higher i =>
    fin_cases i
    · exact a2
    · exact a3
    · exact a4
    · exact a5
    · exact a6
    · exact a7
    · exact a8
    · exact a9
    · exact a10
    · exact a11
    · exact a12
    · exact a13
private theorem e0 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.prime : Book.Event) := by decide +kernel
private theorem e1 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.oldFive : Book.Event) := by decide +kernel
private theorem e2 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 0 : Book.Event) := by decide +kernel
private theorem e3 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 1 : Book.Event) := by decide +kernel
private theorem e4 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 2 : Book.Event) := by decide +kernel
private theorem e5 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 3 : Book.Event) := by decide +kernel
private theorem e6 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 4 : Book.Event) := by decide +kernel
private theorem e7 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 5 : Book.Event) := by decide +kernel
private theorem e8 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 6 : Book.Event) := by decide +kernel
private theorem e9 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 7 : Book.Event) := by decide +kernel
private theorem e10 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 8 : Book.Event) := by decide +kernel
private theorem e11 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 9 : Book.Event) := by decide +kernel
private theorem e12 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 10 : Book.Event) := by decide +kernel
private theorem e13 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.three 11 : Book.Event) := by decide +kernel
private theorem e14 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 0 : Book.Event) := by decide +kernel
private theorem e15 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 1 : Book.Event) := by decide +kernel
private theorem e16 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 2 : Book.Event) := by decide +kernel
private theorem e17 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 3 : Book.Event) := by decide +kernel
private theorem e18 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 4 : Book.Event) := by decide +kernel
private theorem e19 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 5 : Book.Event) := by decide +kernel
private theorem e20 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 6 : Book.Event) := by decide +kernel
private theorem e21 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 7 : Book.Event) := by decide +kernel
private theorem e22 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 8 : Book.Event) := by decide +kernel
private theorem e23 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 9 : Book.Event) := by decide +kernel
private theorem e24 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 10 : Book.Event) := by decide +kernel
private theorem e25 : eventPass (413 : Group) gramActions (fun k => affineActions[FrozenGuards.code k]!) (.newFive 11 : Book.Event) := by decide +kernel

attribute [local irreducible] eventPass

theorem events (e : Book.Event) : eventPass (413 : Group) (moments 413) (affine 413) e := by
  rw [gram_values,affine_values]
  cases e with
  | prime => exact e0
  | oldFive => exact e1
  | three i =>
    fin_cases i
    · exact e2
    · exact e3
    · exact e4
    · exact e5
    · exact e6
    · exact e7
    · exact e8
    · exact e9
    · exact e10
    · exact e11
    · exact e12
    · exact e13
  | newFive i =>
    fin_cases i
    · exact e14
    · exact e15
    · exact e16
    · exact e17
    · exact e18
    · exact e19
    · exact e20
    · exact e21
    · exact e22
    · exact e23
    · exact e24
    · exact e25

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G413
end
