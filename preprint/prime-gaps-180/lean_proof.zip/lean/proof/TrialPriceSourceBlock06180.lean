import TrialPriceFrozenSourceRows180
namespace PrimeGap180.PriceFactorSourceProof
set_option maxRecDepth 131072
set_option maxHeartbeats 100000000
set_option profiler true in
private theorem m60 : PriceFactorData.sourceCheck 60 = true := by decide +kernel
set_option profiler true in
private theorem m61 : PriceFactorData.sourceCheck 61 = true := by decide +kernel
set_option profiler true in
private theorem m62 : PriceFactorData.sourceCheck 62 = true := by decide +kernel
set_option profiler true in
private theorem m63 : PriceFactorData.sourceCheck 63 = true := by decide +kernel
set_option profiler true in
private theorem m64 : PriceFactorData.sourceCheck 64 = true := by decide +kernel
set_option profiler true in
private theorem m65 : PriceFactorData.sourceCheck 65 = true := by decide +kernel
set_option profiler true in
private theorem m66 : PriceFactorData.sourceCheck 66 = true := by decide +kernel
set_option profiler true in
private theorem m67 : PriceFactorData.sourceCheck 67 = true := by decide +kernel
set_option profiler true in
private theorem m68 : PriceFactorData.sourceCheck 68 = true := by decide +kernel
set_option profiler true in
private theorem m69 : PriceFactorData.sourceCheck 69 = true := by decide +kernel
theorem batch6 : ∀ i : Fin 10, PriceFactorData.sourceCheck (60+i.val) = true :=
  Fin.cases m60 (Fin.cases m61 (Fin.cases m62 (Fin.cases m63 (Fin.cases m64 (Fin.cases m65 (Fin.cases m66 (Fin.cases m67 (Fin.cases m68 (Fin.cases m69 (fun i => Fin.elim0 i))))))))))
#print axioms batch6
end PrimeGap180.PriceFactorSourceProof
