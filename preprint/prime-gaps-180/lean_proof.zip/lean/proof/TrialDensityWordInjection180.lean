import TrialDensityPackedDigits180

namespace PrimeGap180.DensitySimplex.PackedDigits

/-- Equal integer evaluations identify bounded signed coefficient lists of
equal length. The sign bias depends only on that common length. -/
theorem injective_on_digits (b c : Int) (hb : 0 < b) (l r : List Int)
    (sameLength : l.length = r.length)
    (hl : ∀ a ∈ l, 0 ≤ a+c ∧ a+c<b) (hr : ∀ a ∈ r, 0 ≤ a+c ∧ a+c<b)
    (same : encode b l = encode b r) : l = r := by
  apply List.ext_getElem sameLength
  intro j jl jr
  rw [← signed_digit b c hb l hl j jl,← signed_digit b c hb r hr j jr,same,sameLength]

#print axioms injective_on_digits
end PrimeGap180.DensitySimplex.PackedDigits
