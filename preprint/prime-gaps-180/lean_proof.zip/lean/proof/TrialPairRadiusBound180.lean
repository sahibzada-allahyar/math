import TrialNativeRadius180
import TrialEndpointPhysical180
import Mathlib.Data.Finset.NatAntidiagonal

/-! The adverse retained-radius price times the triangle of legal native endpoint indices. -/
noncomputable section
open scoped Classical BigOperators
open PrimeGap180.Sector
namespace PrimeGap180.PairRadiusBound

private theorem gauss (n : ℕ) : 2*(∑ i ∈ Finset.range (n+1), (i+1)) = (n+1)*(n+2) := by
  induction n with
  | zero => norm_num
  | succ n ih =>
    rw [Finset.sum_range_succ]
    nlinarith only [ih]

theorem card (n : ℕ) (A : Finset (ℕ × ℕ)) (incl : ∀ t ∈ A,t.1+t.2 ≤ n) :
    (2:ℝ)*(A.card:ℝ) ≤ ((n:ℝ)+1)*((n:ℝ)+2) := by
  let T := (Finset.range (n+1)).biUnion (fun a : ℕ => Finset.HasAntidiagonal.antidiagonal a)
  have subset : A ⊆ T := by
    intro p hp
    exact Finset.mem_biUnion.mpr ⟨p.1+p.2,Finset.mem_range.mpr (Nat.lt_succ_of_le (incl p hp)),Finset.HasAntidiagonal.mem_antidiagonal.mpr rfl⟩
  have ct : A.card ≤ ∑ i ∈ Finset.range (n+1),(i+1) := by
    refine (Finset.card_le_card subset).trans ?_
    simpa only [T,Finset.Nat.card_antidiagonal] using
      (Finset.card_biUnion_le (s := Finset.range (n+1)) (t := fun a : ℕ => Finset.HasAntidiagonal.antidiagonal a))
  exact_mod_cast (Nat.mul_le_mul_left 2 ct).trans_eq (gauss n)

theorem price (J : ℕ) (small : J ≤ 130964) (A : Finset (ℕ × ℕ))
    (live : ∀ z ∈ A,z.1+z.2+J ≤ 130964) :
    (2*rho^2/(EndpointPhysical.ledger-Native.adverse (d := 37) J)^2)*(A.card:ℝ)*Native.step^2 ≤ 0.3135 := by
  let n := 130964-J
  let t := rho*Native.step
  let D := EndpointPhysical.ledger
  let den := D-t*((J:ℝ)+37)
  have room : (n:ℝ)+(J:ℝ) = 130964 := by exact_mod_cast Nat.sub_add_cancel small
  have jmax : (J:ℝ) ≤ 130964 := by exact_mod_cast small
  have nn : 0 ≤ (n:ℝ) := Nat.cast_nonneg _
  have t0 : 0 ≤ t := by norm_num [t,rho,Native.step]
  have d0 : 0 < D := by norm_num [D,EndpointPhysical.ledger]
  have tD : t*(130964+39) < D := by norm_num [t,D,EndpointPhysical.ledger,rho,Native.step]
  have denpos : 0 < den := by
    unfold den
    have h := mul_le_mul_of_nonneg_left (show (J:ℝ)+37 ≤ 130964+39 by linarith) t0
    linarith only [tD,h]
  have numerator : ((n:ℝ)+2)*D ≤ (130964+39)*den := by
    unfold den
    have prod := mul_nonneg (show 0 ≤ (J:ℝ)+37 by positivity) (sub_nonneg.mpr tD.le)
    nlinarith only [prod,congrArg (fun z : ℝ => z*D) room]
  have ratio : t*((n:ℝ)+2)/den ≤ t*(130964+39)/D := by
    apply (div_le_div_iff₀ denpos d0).mpr
    nlinarith only [mul_le_mul_of_nonneg_left numerator t0]
  have legal (z) (hz : z ∈ A) : z.1+z.2 ≤ n := by
    have := live z hz
    dsimp [n]; omega
  have size := card n A legal
  have cover : (2:ℝ)*A.card ≤ ((n:ℝ)+2)^2 := size.trans (by nlinarith only [nn])
  have adverse : EndpointPhysical.ledger-Native.adverse (d := 37) J = den := by
    unfold den D t Native.adverse; push_cast; ring
  have upper : (t*(130964+39)/D)^2 ≤ 0.3135 := by norm_num [t,D,rho,Native.step,EndpointPhysical.ledger]
  rw [adverse]
  calc
    _ = (t/den)^2*(2*A.card) := by unfold t; ring
    _ ≤ (t/den)^2*((n:ℝ)+2)^2 := mul_le_mul_of_nonneg_left cover (sq_nonneg _)
    _ = (t*((n:ℝ)+2)/den)^2 := by ring
    _ ≤ _ := (pow_le_pow_left₀ (div_nonneg (mul_nonneg t0 (by positivity)) denpos.le) ratio 2).trans upper

#print axioms card
#print axioms price
end PrimeGap180.PairRadiusBound
