"""Read the original fourteen signed matrices and encode their rows as exact words."""
import gzip
from hashlib import sha256
import json
from pathlib import Path
import re
import sys

BOOK_HASH = "d6c80fee0ee5b8f12d88baf0a08ba2b7a12bf202dc9bb651826c63389b692cb1"
GROUPS = 445
WORD = 8


def rows(path):
    if sha256(path.read_bytes()).hexdigest() != BOOK_HASH:
        raise ValueError("source affine archive hash mismatch")
    with gzip.open(path, "rb") as stream:
        buffer = b""
        while True:
            part = stream.read(65536)
            if not part:
                raise ValueError("missing affine matrix field")
            buffer = buffer[-32:] + part
            found = re.search(rb'"affine"\s*:', buffer)
            if found:
                buffer = buffer[found.end():]
                break

        def token(char):
            nonlocal buffer
            while not buffer.strip():
                buffer = stream.read(65536)
                if not buffer:
                    raise ValueError("truncated matrix archive")
            buffer = buffer.lstrip()
            if not buffer.startswith(char):
                raise ValueError(f"expected {char!r}")
            buffer = buffer[len(char):]

        token(b"[")
        for channel in range(14):
            if channel:
                token(b",")
            token(b"[")
            matrix = []
            for index in range(GROUPS):
                if index:
                    token(b",")
                token(b"[")
                while b"]" not in buffer:
                    part = stream.read(65536)
                    if not part:
                        raise ValueError("truncated matrix row")
                    buffer += part
                elements, buffer = buffer.split(b"]", 1)
                row = json.loads(b"[" + elements + b"]")
                if len(row) != GROUPS or any(type(x) != int for x in row):
                    raise ValueError("invalid signed row")
                matrix.append(row)
            token(b"]")
            if any(matrix[g][h] != matrix[h][g]
                   for g in range(GROUPS) for h in range(g)):
                raise ValueError("non-symmetric source matrix")
            yield from matrix


def emit(source, dest, compact=False):
    signed_hash = sha256()
    count = 0
    with dest.open("wb") as out:
        for row in rows(source):
            raw = b"".join(x.to_bytes(WORD, "little", signed=True) for x in row)
            mask = b"".join((b"\xff" if x == 0 else b"\0") * WORD for x in row)
            # Each input slot round-trips with the same signed convention as Lean.
            word = int.from_bytes(raw, "little")
            excluded = int.from_bytes(mask, "little")
            if word & excluded:
                raise ValueError("exclusion mask intersects source values")
            for col, value in enumerate(row):
                u = (word >> (64 * col)) & ((1 << 64) - 1)
                recovered = u - (1 << 64) if u >= (1 << 63) else u
                if recovered != value:
                    raise ValueError("wrong matrix lane")
            signed_hash.update(raw)
            if compact:
                flags = sum((x == 0) << j for j, x in enumerate(row))
                out.write(raw + flags.to_bytes(56, "little"))
            else:
                out.write(raw + mask)
            count += 1
    if count != 14 * GROUPS or dest.stat().st_size != 14 * GROUPS * (WORD*GROUPS + (56 if compact else WORD*GROUPS)):
        raise ValueError("wrong source dimensions")
    return signed_hash.hexdigest()


if __name__ == '__main__':
    print(emit(Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3:] == ["compact"]))
