import TrialAngularSubset180
import Mathlib.Logic.Equiv.Fin.Rotate
import Mathlib.Order.Interval.Finset.Fin
import Mathlib.Algebra.BigOperators.Group.Finset.Basic

/-! Group equal angular assignments by the already occupied sites.
A new angular factor joins each existing block or one representative
of all unused sites. There are at most six blocks for this trial. -/
noncomputable section
open scoped Classical BigOperators
namespace PrimeGap180.AngularOccupied
variable {A R : Type*} [Fintype A] [CommSemiring R]

def marked (W V : A → R) {d : ℕ} (w : Fin d → ℕ) (es : List ℕ) :=
  ∑ x : Fin d → A,(∏ i,W (x i)*(V (x i))^(w i))*
    (es.map fun e => ∑ i : Fin d,(V (x i))^e).prod

def bump {d : ℕ} (w : Fin d → ℕ) (i : Fin d) (e : ℕ) (j : Fin d) :=
  w j + if j=i then e else 0

private theorem factor (W V : A → R) {d : ℕ} (w : Fin d → ℕ) (i : Fin d) (e : ℕ)
    (x : Fin d → A) : (∏ j,W (x j)*(V (x j))^(bump w i e j))=
      (∏ j,W (x j)*(V (x j))^(w j))*(V (x i))^e := by
  simp only [bump,pow_add,←mul_assoc,Finset.prod_mul_distrib]
  have val (j : Fin d) : V (x j)^(if j=i then e else 0)=if j=i then V (x j)^e else 1 := by
    by_cases eq : j=i <;> simp [eq]
  simp only [val,Finset.prod_ite_eq',Finset.mem_univ,if_true]

theorem advance (W V : A → R) {d : ℕ} (w : Fin d → ℕ) (e : ℕ) (es : List ℕ) :
    marked W V w (e::es) = ∑ i : Fin d,marked W V (bump w i e) es := by
  unfold marked
  rw [Finset.sum_comm (s:=(Finset.univ : Finset (Fin d))) (t:=(Finset.univ : Finset (Fin d → A)))]
  apply Finset.sum_congr rfl
  intro x _
  simp only [List.map_cons,List.prod_cons,factor,←Finset.sum_mul,←Finset.mul_sum,mul_assoc]

theorem finish (W V : A → R) {d : ℕ} (w : Fin d → ℕ) :
    marked W V w []=∏ i : Fin d,AngularSubset.moment W V (w i) := by
  simp [marked,AngularSubset.moment,Fintype.prod_sum]

theorem perm (W V : A → R) {d : ℕ} (w : Fin d → ℕ) (es : List ℕ) (p : Equiv.Perm (Fin d)) :
    marked W V (w ∘ p) es=marked W V w es := by
  let h : (Fin d → A) ≃ (Fin d → A) :=
    { toFun := fun x => x ∘ p
      invFun := fun x => x ∘ p.symm
      left_inv := fun x => by funext i; simp
      right_inv := fun x => by funext i; simp }
  unfold marked
  rw [←Equiv.sum_comp h]
  apply Finset.sum_congr rfl
  intro x _
  change (∏ i,W (x (p i))*(V (x (p i)))^(w (p i)))*
    (es.map fun e => ∑ i : Fin d,(V (x (p i)))^e).prod=_
  rw [Equiv.prod_comp p (fun i => W (x i)*(V (x i))^(w i))]
  have weights (e : ℕ) : (∑ i,V (x (p i))^e)=∑ i,V (x i)^e :=
    Equiv.sum_comp p (fun i => V (x i)^e)
  simp_rw [weights]

theorem equal_site (W V : A → R) {d : ℕ} (w : Fin d → ℕ) (i j : Fin d)
    (same : w i=w j) (e : ℕ) (es : List ℕ) :
    marked W V (bump w i e) es=marked W V (bump w j e) es := by
  have inv : bump w i e = bump w j e ∘ Equiv.swap i j := by
    funext x
    by_cases xi : x=i
    · subst x; simp [bump,same]
    · by_cases xj : x=j
      · subst x; simp [bump,xi,Ne.symm xi,same]
      · simp [bump,Equiv.swap_apply_of_ne_of_ne xi xj,xi,xj]
  rw [inv,perm]

theorem grouped (W V : A → R) {d : ℕ} (w : Fin d → ℕ) (k : Fin d)
    (fresh : ∀ j,k≤j → w j=0) (e : ℕ) (es : List ℕ) :
    marked W V w (e::es) =
      (∑ i ∈ Finset.Iio k,marked W V (bump w i e) es) +
      (d-k.val) • marked W V (bump w k e) es := by
  let f (j : Fin d) := marked W V (bump w j e) es
  have splice : (Finset.univ : Finset (Fin d))=Finset.Iio k ∪ Finset.Ici k := by
    ext j
    simp only [Finset.mem_univ,Finset.mem_union,Finset.mem_Iio,Finset.mem_Ici,true_iff]
    exact lt_or_ge j k
  have dis : Disjoint (Finset.Iio k) (Finset.Ici k) := by
    refine Finset.disjoint_left.mpr (fun j lo hi => ?_)
    exact (not_lt_of_ge (Finset.mem_Ici.mp hi)) (Finset.mem_Iio.mp lo)
  rw [advance]
  change (∑ j : Fin d,f j)=(∑ i ∈ Finset.Iio k,f i)+(d-k.val) • f k
  rw [splice,Finset.sum_union dis]
  apply congrArg ((∑ i ∈ Finset.Iio k,f i)+·)
  calc
    _ = ∑ _ ∈ Finset.Ici k,f k := Finset.sum_congr rfl (fun j hj =>
      equal_site W V w j k ((fresh j (Finset.mem_Ici.mp hj)).trans (fresh k le_rfl).symm) e es)
    _ = _ := by simp [Fin.card_Ici]

#print axioms grouped
#print axioms advance
#print axioms finish
#print axioms equal_site
end PrimeGap180.AngularOccupied
