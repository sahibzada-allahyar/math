import TrialOrderedFactors180

/-! Exact closed dyadic counts of sorted literal products, split at the final prime.
The five-prime box bounds the fourth prime using its product with the fifth. -/
noncomputable section
open scoped Classical BigOperators Topology
open Filter MeasureTheory
open PrimeGap180 PrimeGap180.Literal PrimeGap180.Ordinary PrimeGap180.Distribution
namespace PrimeGap180.LiteralDensity

def band (x hi : ℝ) :=
  (Nat.primesBelow ⌈x^hi⌉₊).filter (fun p : ℕ => x^(4/25:ℝ) ≤ (p:ℝ))

theorem mem_band {x hi : ℝ} {p : ℕ} : p ∈ band x hi ↔
    p.Prime ∧ x^(4/25:ℝ) ≤ (p:ℝ) ∧ (p:ℝ) < x^hi := by
  simp only [band,Finset.mem_filter,Nat.mem_primesBelow,Nat.lt_ceil]
  tauto

def prefixes (d : ℕ) (x hi : ℝ) :=
  Fintype.piFinset (fun _ : Fin d => band x hi)

def finals (x : ℝ) (P : ℕ) :=
  (Finset.Icc ⌈x/(P:ℝ)⌉₊ ⌊2*x/(P:ℝ)⌋₊).filter Nat.Prime

theorem mem_finals {x : ℝ} (hx : 0 < x) {P q : ℕ} (hP : 0 < P) :
    q ∈ finals x P ↔ q.Prime ∧ P*q ∈ window x := by
  have hp : (0:ℝ) < P := by exact_mod_cast hP
  simp only [finals,window,Finset.mem_filter,Finset.mem_Icc,Nat.ceil_le,
    Nat.le_floor_iff (by positivity : 0 ≤ 2*x/(P:ℝ)),
    Nat.le_floor_iff (by positivity : 0 ≤ 2*x),div_le_iff₀ hp,le_div_iff₀ hp,
    Nat.cast_mul,mul_comm (q:ℝ) (P:ℝ)]
  tauto

def sliced {d : ℕ} (x hi : ℝ) (A : (Fin d → ℕ) → ℕ → Prop) :=
  ∑ p ∈ prefixes d x hi, ((finals x (∏ i, p i)).filter (A p)).card

private theorem count_sliced {d : ℕ} {x hi : ℝ} (hx : 1 < x)
    (A : (Fin d → ℕ) → ℕ → Prop) (E : ℕ → Prop)
    (hmono : ∀ p q, A p q → StrictMono (@Fin.snoc d (fun _ => ℕ) p q))
    (hspec : ∀ n ∈ window x, E n ↔ ∃ p ∈ prefixes d x hi, ∃ q : ℕ,
      q.Prime ∧ A p q ∧ (∏ i, p i)*q = n) :
    ((window x).filter E).card = sliced x hi A := by
  classical
  let R := fun p : Fin d → ℕ => (finals x (∏ i, p i)).filter (A p)
  let S := (prefixes d x hi).sigma R
  let f := fun z : (Σ _ : Fin d → ℕ, ℕ) => (∏ i, z.1 i)*z.2
  have x0 : 0 < x := by linarith
  have prime {p : Fin d → ℕ} (hp : p ∈ prefixes d x hi) (i : Fin d) : (p i).Prime :=
    (mem_band.mp (Fintype.mem_piFinset.mp hp i)).1
  have pos {p : Fin d → ℕ} (hp : p ∈ prefixes d x hi) : 0 < ∏ i, p i :=
    Finset.prod_pos fun i _ => (prime hp i).pos
  have mem (p : Fin d → ℕ) (q : ℕ) : Sigma.mk p q ∈ S ↔
      p ∈ prefixes d x hi ∧ q.Prime ∧ (∏ i, p i)*q ∈ window x ∧ A p q := by
    change Sigma.mk p q ∈ (prefixes d x hi).sigma R ↔ _
    rw [Finset.mem_sigma]
    by_cases hp : p ∈ prefixes d x hi
    · simp only [hp,true_and,R,Finset.mem_filter,mem_finals x0 (pos hp)]
      tauto
    · simp [hp]
  have image : S.image f = (window x).filter E := by
    ext n
    constructor
    · intro hn
      obtain ⟨⟨p,q⟩,h,rfl⟩ := Finset.mem_image.mp hn
      obtain ⟨hp,hq,hwin,ha⟩ := (mem p q).mp h
      exact Finset.mem_filter.mpr ⟨hwin,(hspec _ hwin).mpr ⟨p,hp,q,hq,ha,rfl⟩⟩
    · intro hn
      obtain ⟨hw,he⟩ := Finset.mem_filter.mp hn
      obtain ⟨p,hp,q,hq,ha,eq⟩ := (hspec n hw).mp he
      exact Finset.mem_image.mpr ⟨⟨p,q⟩,(mem p q).mpr ⟨hp,hq,eq ▸ hw,ha⟩,eq⟩
  have inj : Set.InjOn f S := by
    rintro ⟨p,q⟩ h ⟨p',q'⟩ h' e
    obtain ⟨hp,hq,_,ha⟩ := (mem p q).mp h
    obtain ⟨hp',hq',_,ha'⟩ := (mem p' q').mp h'
    have all {t : Fin d → ℕ} {r : ℕ} (hm : t ∈ prefixes d x hi) (hr : r.Prime) :
        ∀ i, ((@Fin.snoc d (fun _ => ℕ) t r) i).Prime := by
      apply Fin.lastCases
      · simpa using hr
      · intro i
        simpa using prime hm i
    have same := ordered_primes_unique (all hp hq) (all hp' hq') (hmono p q ha)
      (hmono p' q' ha') (by simpa [Fin.prod_univ_castSucc,f] using e)
    have pp : p = p' := by simpa using congrArg Fin.init same
    have qq : q = q' := by simpa using congrFun same (Fin.last d)
    cases pp; cases qq; rfl
  rw [← image,Finset.card_image_iff.mpr inj]
  exact Finset.card_sigma _ _

def threeAccept (x a c : ℝ) (p : Fin 2 → ℕ) (q : ℕ) :=
  p 0 < p 1 ∧ p 1 < q ∧ x^c < (p 0 : ℝ) ∧ (q:ℝ) < x^a

def fiveAccept (x a : ℝ) (p : Fin 4 → ℕ) (q : ℕ) :=
  p 0 < p 1 ∧ p 1 < p 2 ∧ p 2 < p 3 ∧ p 3 < q ∧ (p 3:ℝ)*q < x^a

theorem three_sliced {x a c : ℝ} (hx : 1 < x) (hc : 4/25 ≤ c) (ha : a ≤ 42/100) :
    ((window x).filter (Three (x^c) (x^a))).card = sliced x (42/100) (threeAccept x a c) := by
  apply count_sliced hx
  · intro p q h
    obtain ⟨h1,h2,_,_⟩ := h
    apply Fin.strictMono_iff_lt_succ.mpr
    intro i
    fin_cases i <;> first | exact h1 | exact h2
  intro n _
  have x0 : 0 < x := by linarith
  constructor
  · rintro ⟨p,q,r,hp,hq,hr,hpq,hqr,pr,lo,hi⟩
    let t : Fin 2 → ℕ := ![p,q]
    refine ⟨t,Fintype.mem_piFinset.mpr ?_,r,hr,⟨hpq,hqr,lo,hi⟩,?_⟩
    · intro i
      apply mem_band.mpr
      have lower := (Real.rpow_le_rpow_of_exponent_le hx.le hc).trans lo.le
      have upper := hi.trans_le (Real.rpow_le_rpow_of_exponent_le hx.le ha)
      have pq : (p:ℝ) ≤ q := by exact_mod_cast hpq.le
      have qr : (q:ℝ) ≤ r := by exact_mod_cast hqr.le
      fin_cases i
      · exact ⟨hp,lower,pq.trans_lt (qr.trans_lt upper)⟩
      · exact ⟨hq,lower.trans pq,qr.trans_lt upper⟩
    · simpa [t,Fin.prod_univ_two] using pr.symm
  · rintro ⟨p,hp,q,hq,⟨h1,h2,lo,hi⟩,pr⟩
    have hprime (i : Fin 2) := (mem_band.mp (Fintype.mem_piFinset.mp hp i)).1
    exact ⟨p 0,p 1,q,hprime 0,hprime 1,hq,h1,h2,by simpa [Fin.prod_univ_two] using pr.symm,lo,hi⟩

theorem five_sliced {x a : ℝ} (hx : 1 < x) (ha : a ≤ 417/1000) :
    ((window x).filter (Five (x^a))).card = sliced x (21/100) (fiveAccept x a) := by
  apply count_sliced hx
  · intro p q h
    obtain ⟨h1,h2,h3,h4,_⟩ := h
    apply Fin.strictMono_iff_lt_succ.mpr
    intro i
    fin_cases i <;> first | exact h1 | exact h2 | exact h3 | exact h4
  intro n hn
  have x0 : 0 < x := by linarith
  constructor
  · intro event
    obtain ⟨p,q,r,s,t,hp,hq,hr,hs,ht,hpq,hqr,hrs,hst,pr,cut⟩ := id event
    let f : Fin 4 → ℕ := ![p,q,r,s]
    refine ⟨f,Fintype.mem_piFinset.mpr ?_,t,ht,⟨hpq,hqr,hrs,hst,cut⟩,?_⟩
    · intro i
      apply mem_band.mpr
      have rho : x^(4/25:ℝ)*(x^a)^2 < x := by
        rw [sq,← Real.rpow_add x0,← Real.rpow_add x0]
        exact (Real.rpow_lt_rpow_of_exponent_lt hx (by linarith : (4:ℝ)/25+(a+a)<1)).trans_eq
          (Real.rpow_one x)
      have lower := (five_rough (Real.rpow_nonneg x0.le _) rho
        (Nat.ceil_le.mp (Finset.mem_Icc.mp hn).1) event hp
          (pr ▸ by simp [mul_assoc])).le
      have upper : (s:ℝ) < x^(21/100:ℝ) := by
        have hst' : (s:ℝ) ≤ t := by exact_mod_cast hst.le
        have hsq := (mul_le_mul_of_nonneg_left hst' (Nat.cast_nonneg s)).trans_lt cut
        have hpow := Real.rpow_le_rpow_of_exponent_le hx.le (by linarith : a ≤ 21/100+21/100)
        rw [Real.rpow_add x0] at hpow
        nlinarith only [hsq.trans_le hpow,Real.rpow_pos_of_pos x0 (21/100:ℝ), (by positivity : (0:ℝ) ≤ s)]
      have pq : (p:ℝ) ≤ q := by exact_mod_cast hpq.le
      have qr : (q:ℝ) ≤ r := by exact_mod_cast hqr.le
      have rs : (r:ℝ) ≤ s := by exact_mod_cast hrs.le
      fin_cases i
      · exact ⟨hp,lower,pq.trans_lt (qr.trans_lt (rs.trans_lt upper))⟩
      · exact ⟨hq,lower.trans pq,qr.trans_lt (rs.trans_lt upper)⟩
      · exact ⟨hr,lower.trans (pq.trans qr),rs.trans_lt upper⟩
      · exact ⟨hs,lower.trans (pq.trans (qr.trans rs)),upper⟩
    · simpa [f,Fin.prod_univ_four,mul_assoc] using pr.symm
  · rintro ⟨p,hp,q,hq,⟨h1,h2,h3,h4,cut⟩,pr⟩
    have hprime (i : Fin 4) := (mem_band.mp (Fintype.mem_piFinset.mp hp i)).1
    exact ⟨p 0,p 1,p 2,p 3,q,hprime 0,hprime 1,hprime 2,hprime 3,hq,h1,h2,h3,h4,
      by simpa [Fin.prod_univ_four,mul_assoc] using pr.symm,cut⟩


def exponents {d : ℕ} (x : ℝ) (p : Fin d → ℕ) (i : Fin d) : ℝ := Real.logb x (p i : ℝ)
def residual {d : ℕ} (t : Fin d → ℝ) := 1 - ∑ i, t i

theorem prefix_bounds {d : ℕ} {x hi : ℝ} (hx : 1 < x) {p : Fin d → ℕ}
    (hp : p ∈ prefixes d x hi) (i : Fin d) :
    (p i).Prime ∧ 4/25 ≤ exponents x p i ∧ exponents x p i ≤ hi := by
  obtain ⟨pr,lo,top⟩ := mem_band.mp (Fintype.mem_piFinset.mp hp i)
  have pos : (0:ℝ) < p i := by exact_mod_cast pr.pos
  exact ⟨pr,(Real.le_logb_iff_rpow_le hx pos).mpr lo,(Real.logb_le_iff_le_rpow hx pos).mpr top.le⟩

theorem three_residual_floor {t : Fin 2 → ℝ} (ht : ∀ i, t i ≤ 42/100) :
    4/25 ≤ residual t := by simp only [residual,Fin.sum_univ_two]; linarith [ht 0,ht 1]

theorem five_residual_floor {t : Fin 4 → ℝ} (ht : ∀ i, t i ≤ 21/100) :
    4/25 ≤ residual t := by simp only [residual,Fin.sum_univ_four]; linarith [ht 0,ht 1,ht 2,ht 3]

theorem final_motion {d : ℕ} {x hi : ℝ} (hx : 1 < x) {p : Fin d → ℕ}
    (hp : p ∈ prefixes d x hi) {q : ℕ} (hq : q ∈ finals x (∏ i, p i)) :
    residual (exponents x p) ≤ Real.logb x q ∧
      Real.logb x q ≤ residual (exponents x p) + Real.logb x 2 := by
  have x0 : 0 < x := by linarith
  have pos (i : Fin d) := (prefix_bounds hx hp i).1.pos
  have P0 : 0 < (∏ i, p i) := Finset.prod_pos fun i _ => pos i
  obtain ⟨pr,wi⟩ := (mem_finals x0 P0).mp hq
  have q0 : (0:ℝ) < q := by exact_mod_cast pr.pos
  have p0 (i : Fin d) : (0:ℝ) < p i := by exact_mod_cast pos i
  have Ppos : (0:ℝ) < ∏ i, (p i : ℝ) := Finset.prod_pos fun i _ => p0 i
  have lo : x ≤ (∏ i, (p i : ℝ))*(q:ℝ) := by exact_mod_cast Nat.ceil_le.mp (Finset.mem_Icc.mp wi).1
  have up : (∏ i, (p i : ℝ))*(q:ℝ) ≤ 2*x := by
    exact_mod_cast (Nat.le_floor_iff (by positivity : 0 ≤ 2*x)).mp (Finset.mem_Icc.mp wi).2
  have lower := Real.logb_le_logb_of_le hx x0 lo
  have upper := Real.logb_le_logb_of_le hx (mul_pos Ppos q0) up
  rw [Real.logb_mul Ppos.ne' q0.ne',Real.logb_prod _ _ (fun i _ => (p0 i).ne')] at lower upper
  rw [Real.logb_self_eq_one hx] at lower
  rw [Real.logb_mul (by norm_num) x0.ne',Real.logb_self_eq_one hx] at upper
  dsimp [residual,exponents]
  constructor <;> linarith

/-- The only final-prime conditions in either channel are strict lower and
upper faces in its log exponent; all prefix sorting constraints remain exact. -/
def bracket {d : ℕ} (base : (Fin d → ℝ) → Prop) (L H : (Fin d → ℝ) → ℝ)
    (u v : ℝ) (t : Fin d → ℝ) :=
  base t ∧ L t < residual t + u ∧ residual t + v < H t

def threeBase (c : ℝ) (t : Fin 2 → ℝ) := c < t 0 ∧ t 0 < t 1
def fiveBase (t : Fin 4 → ℝ) := t 0 < t 1 ∧ t 1 < t 2 ∧ t 2 < t 3
def threeRegion (a c u v : ℝ) := bracket (threeBase c) (fun t => t 1) (fun _ => a) u v
def fiveRegion (a u v : ℝ) := bracket fiveBase (fun t => t 3) (fun t => a-t 3) u v

theorem three_exponents {x a c : ℝ} (hx : 1 < x) {p : Fin 2 → ℕ}
    (hp : p ∈ prefixes 2 x (42/100)) {q : ℕ} (hq : q ∈ finals x (∏ i, p i)) :
    threeAccept x a c p q ↔ threeBase c (exponents x p) ∧
      exponents x p 1 < Real.logb x q ∧ Real.logb x q < a := by
  have pp (i : Fin 2) : (0:ℝ) < p i := by exact_mod_cast (prefix_bounds hx hp i).1.pos
  have qp : (0:ℝ) < q := by exact_mod_cast (Finset.mem_filter.mp hq).2.pos
  simp only [threeAccept,threeBase,exponents,Real.logb_lt_logb_iff hx (pp _) (pp _),
    Real.logb_lt_logb_iff hx (pp _) qp,Real.lt_logb_iff_rpow_lt hx (pp _),
    Real.logb_lt_iff_lt_rpow hx qp,Nat.cast_lt]
  tauto

theorem five_exponents {x a : ℝ} (hx : 1 < x) {p : Fin 4 → ℕ}
    (hp : p ∈ prefixes 4 x (21/100)) {q : ℕ} (hq : q ∈ finals x (∏ i, p i)) :
    fiveAccept x a p q ↔ fiveBase (exponents x p) ∧
      exponents x p 3 < Real.logb x q ∧ Real.logb x q < a - exponents x p 3 := by
  have pp (i : Fin 4) : (0:ℝ) < p i := by exact_mod_cast (prefix_bounds hx hp i).1.pos
  have qp : (0:ℝ) < q := by exact_mod_cast (Finset.mem_filter.mp hq).2.pos
  have cap : Real.logb x q < a - Real.logb x (p 3) ↔ (p 3:ℝ)*q < x^a := by
    rw [lt_sub_iff_add_lt',← Real.logb_mul (pp 3).ne' qp.ne',Real.logb_lt_iff_lt_rpow hx (mul_pos (pp 3) qp)]
  simp only [fiveAccept,fiveBase,exponents,Real.logb_lt_logb_iff hx (pp _) (pp _),
    Real.logb_lt_logb_iff hx (pp _) qp,Nat.cast_lt,cap]
  tauto

def fullSlices {d : ℕ} (x hi : ℝ) (D : (Fin d → ℝ) → Prop) :=
  ∑ p ∈ prefixes d x hi, if D (exponents x p) then (finals x (∏ i, p i)).card else 0

private theorem bracket_sandwich {d : ℕ} {x hi δ : ℝ} (hx : 1 < x) (hδ : Real.logb x 2 ≤ δ)
    (A : (Fin d → ℕ) → ℕ → Prop) (B : (Fin d → ℝ) → Prop) (L H : (Fin d → ℝ) → ℝ)
    (eq : ∀ p ∈ prefixes d x hi, ∀ q ∈ finals x (∏ i, p i), A p q ↔
      B (exponents x p) ∧ L (exponents x p) < Real.logb x q ∧ Real.logb x q < H (exponents x p)) :
    fullSlices x hi (bracket B L H 0 δ) ≤ sliced x hi A ∧
      sliced x hi A ≤ fullSlices x hi (bracket B L H δ 0) := by
  constructor <;> apply Finset.sum_le_sum <;> intro p hp
  · split_ifs with h
    · obtain ⟨b,lo,up⟩ := h
      apply Finset.card_le_card
      intro q hq
      obtain ⟨l,u⟩ := final_motion hx hp hq
      exact Finset.mem_filter.mpr ⟨hq,(eq p hp q hq).mpr ⟨b,by linarith,by linarith⟩⟩
    · exact Nat.zero_le _
  · split_ifs with h
    · exact Finset.card_filter_le _ _
    · apply le_of_eq
      rw [Finset.card_eq_zero]
      apply Finset.eq_empty_iff_forall_notMem.mpr
      intro q hq
      obtain ⟨hq,hA⟩ := Finset.mem_filter.mp hq
      obtain ⟨l,u⟩ := final_motion hx hp hq
      obtain ⟨b,lo,up⟩ := (eq p hp q hq).mp hA
      exact h ⟨b,by linarith,by linarith⟩

theorem three_count_sandwich {x a c δ : ℝ} (hx : 1 < x) (hc : 4/25 ≤ c) (ha : a ≤ 42/100)
    (hδ : Real.logb x 2 ≤ δ) :
    fullSlices x (42/100) (threeRegion a c 0 δ) ≤ ((window x).filter (Three (x^c) (x^a))).card ∧
      ((window x).filter (Three (x^c) (x^a))).card ≤ fullSlices x (42/100) (threeRegion a c δ 0) := by
  rw [three_sliced hx hc ha]
  exact bracket_sandwich hx hδ _ _ _ _ (fun _ hp _ hq => three_exponents hx hp hq)

theorem five_count_sandwich {x a δ : ℝ} (hx : 1 < x) (ha : a ≤ 417/1000)
    (hδ : Real.logb x 2 ≤ δ) :
    fullSlices x (21/100) (fiveRegion a 0 δ) ≤ ((window x).filter (Five (x^a))).card ∧
      ((window x).filter (Five (x^a))).card ≤ fullSlices x (21/100) (fiveRegion a δ 0) := by
  rw [five_sliced hx ha]
  exact bracket_sandwich hx hδ _ _ _ _ (fun _ hp _ hq => five_exponents hx hp hq)


theorem residual_power {d : ℕ} {x hi : ℝ} (hx : 1 < x) {p : Fin d → ℕ}
    (hp : p ∈ prefixes d x hi) : x/(∏ i, (p i : ℝ)) = x^(residual (exponents x p)) := by
  have xp : 0 < x := by linarith
  have pp (i : Fin d) : (0:ℝ) < p i := by exact_mod_cast (prefix_bounds hx hp i).1.pos
  rw [residual,Real.rpow_sub xp,Real.rpow_one]
  congr 1
  change _ = x^(∑ i, Real.logb x (p i : ℝ))
  rw [← Real.logb_prod _ _ (fun i _ => (pp i).ne'),Real.rpow_logb xp (ne_of_gt hx)
    (Finset.prod_pos fun i _ => pp i)]

/-- The fixed-dimensional affine-null argument in the Apache-2.0
PrimeGaps186 source, applied here to finite prefix vectors of any dimension. -/
theorem affine_null {d : ℕ} (w : Fin d → ℝ) (b : ℝ) (hw : ∃ i, w i ≠ 0) :
    volume {t : Fin d → ℝ | (∑ i, w i*t i) = b} = 0 := by
  classical
  let s : AffineSubspace ℝ (Fin d → ℝ) :=
    (affineSpan ℝ ({b} : Set ℝ)).comap (dotProductBilin ℝ ℝ w).toAffineMap
  have proper : s ≠ ⊤ := by
    intro he
    have eq (t : Fin d → ℝ) : (∑ i, w i*t i) = b := by
      simpa [s,dotProduct] using (he.symm ▸ AffineSubspace.mem_top ℝ (Fin d → ℝ) t : t ∈ s)
    have bz : b = 0 := by simpa [eq_comm] using eq (0 : Fin d → ℝ)
    obtain ⟨i,h⟩ := hw
    have v := eq (Pi.single i 1)
    simp only [Pi.single_apply,mul_ite,mul_one,mul_zero,Finset.sum_ite_eq',Finset.mem_univ,
      ↓reduceIte,bz] at v
    exact h v
  simpa [s,Set.preimage,dotProduct] using Measure.addHaar_affineSubspace volume s proper

def half {d : ℕ} (w : Fin d → ℝ) (b : ℝ) : Set (Fin d → ℝ) := {t | (∑ i, w i*t i) < b}

def Regular {d : ℕ} (s : Set (Fin d → ℝ)) := IsOpen s ∧ volume (frontier s) = 0

private theorem regular_half {d : ℕ} (w : Fin d → ℝ) (b : ℝ) (hw : ∃ i, w i ≠ 0) :
    Regular (half w b) := by
  have cont : Continuous (fun t : Fin d → ℝ => ∑ i, w i*t i) := by fun_prop
  exact ⟨isOpen_lt cont continuous_const,
    measure_mono_null (frontier_lt_subset_eq cont continuous_const) (affine_null w b hw)⟩

private theorem regular_inter {d : ℕ} {s t : Set (Fin d → ℝ)} (hs : Regular s) (ht : Regular t) :
    Regular (s ∩ t) := ⟨hs.1.inter ht.1,measure_mono_null (frontier_inter_subset s t)
      (measure_union_null (measure_mono_null Set.inter_subset_left hs.2)
        (measure_mono_null Set.inter_subset_right ht.2))⟩

theorem three_regular (a c u v : ℝ) : Regular {t | threeRegion a c u v t} := by
  have eq : {t | threeRegion a c u v t} =
      half ![-1,0] (-c) ∩ half ![1,-1] 0 ∩ half ![1,2] (1+u) ∩ half ![-1,-1] (a-1-v) := by
    ext t
    simp [threeRegion,bracket,threeBase,residual,half,Fin.sum_univ_two]
    constructor
    · rintro ⟨⟨h1,h2⟩,h3,h4⟩
      exact ⟨⟨⟨by linarith,by linarith⟩,by linarith⟩,by linarith⟩
    · rintro ⟨⟨⟨h1,h2⟩,h3⟩,h4⟩
      exact ⟨⟨by linarith,by linarith⟩,by linarith,by linarith⟩
  rw [eq]
  apply regular_inter <;> first | apply regular_inter | skip
  all_goals first | apply regular_inter | skip
  all_goals apply regular_half
  all_goals exact ⟨0,by norm_num⟩

theorem five_regular (a u v : ℝ) : Regular {t | fiveRegion a u v t} := by
  have eq : {t | fiveRegion a u v t} =
      half ![1,-1,0,0] 0 ∩ half ![0,1,-1,0] 0 ∩ half ![0,0,1,-1] 0 ∩
        half ![1,1,1,2] (1+u) ∩ half ![-1,-1,-1,0] (a-1-v) := by
    ext t
    simp [fiveRegion,bracket,fiveBase,residual,half,Fin.sum_univ_four]
    constructor
    · rintro ⟨⟨h1,h2,h3⟩,h4,h5⟩
      exact ⟨⟨⟨⟨by linarith,by linarith⟩,by linarith⟩,by linarith⟩,by linarith⟩
    · rintro ⟨⟨⟨⟨h1,h2⟩,h3⟩,h4⟩,h5⟩
      exact ⟨⟨by linarith,by linarith,by linarith⟩,by linarith,by linarith⟩
  rw [eq]
  repeat' first | apply regular_inter | apply regular_half
  · exact ⟨0,by norm_num⟩
  · exact ⟨1,by norm_num⟩
  · exact ⟨2,by change (1:ℝ) ≠ 0; norm_num⟩
  · exact ⟨0,by norm_num⟩
  · exact ⟨0,by norm_num⟩

private theorem ae_ne_face {d : ℕ} (w : Fin d → ℝ) (b : ℝ) (hw : ∃ i, w i ≠ 0) :
    ∀ᵐ t : Fin d → ℝ, (∑ i, w i*t i) ≠ b := by
  simpa only [ae_iff,not_not] using affine_null w b hw

private theorem lock {x y : ℝ} (ne : x ≠ y) : ∃ e > 0, ∀ δ : ℝ, |δ| < e →
    (x < y+δ ↔ x < y) ∧ (x+δ < y ↔ x < y) := by
  rcases lt_or_gt_of_ne ne with h | h
  · refine ⟨y-x,by linarith,fun δ hd => ?_⟩
    obtain ⟨l,r⟩ := abs_lt.mp hd
    constructor <;> constructor <;> intro <;> linarith
  · refine ⟨x-y,by linarith,fun δ hd => ?_⟩
    obtain ⟨l,r⟩ := abs_lt.mp hd
    constructor <;> constructor <;> intro <;> linarith

private theorem bracket_stable {d : ℕ} {B : (Fin d → ℝ) → Prop} {L H : (Fin d → ℝ) → ℝ}
    {t : Fin d → ℝ} (lo : L t ≠ residual t) (hi : residual t ≠ H t) :
    ∃ e > 0, ∀ u v : ℝ, |u| < e → |v| < e →
      (bracket B L H u v t ↔ bracket B L H 0 0 t) := by
  obtain ⟨e,ep,el⟩ := lock lo
  obtain ⟨f,fp,fl⟩ := lock hi
  refine ⟨min e f,lt_min ep fp,fun u v hu hv => ?_⟩
  simp only [bracket,add_zero,(el u (hu.trans_le (min_le_left _ _))).1,
    (fl v (hv.trans_le (min_le_right _ _))).2]

theorem three_stable (a c : ℝ) : ∀ᵐ t : Fin 2 → ℝ, ∃ e > 0, ∀ u v : ℝ,
    |u| < e → |v| < e → (threeRegion a c u v t ↔ threeRegion a c 0 0 t) := by
  filter_upwards [ae_ne_face ![1,2] 1 ⟨0,by norm_num⟩,
    ae_ne_face ![1,1] (1-a) ⟨0,by norm_num⟩] with t l h
  apply bracket_stable
  · intro eq
    apply l
    simp [residual,Fin.sum_univ_two] at eq ⊢
    linarith
  · intro eq
    apply h
    simp [residual,Fin.sum_univ_two] at eq ⊢
    linarith

theorem five_stable (a : ℝ) : ∀ᵐ t : Fin 4 → ℝ, ∃ e > 0, ∀ u v : ℝ,
    |u| < e → |v| < e → (fiveRegion a u v t ↔ fiveRegion a 0 0 t) := by
  filter_upwards [ae_ne_face ![1,1,1,2] 1 ⟨0,by norm_num⟩,
    ae_ne_face ![1,1,1,0] (1-a) ⟨0,by norm_num⟩] with t l h
  apply bracket_stable
  · intro eq
    apply l
    simp [residual,Fin.sum_univ_four] at eq ⊢
    linarith
  · intro eq
    apply h
    simp [residual,Fin.sum_univ_four] at eq ⊢
    linarith

#print axioms three_count_sandwich
#print axioms five_count_sandwich
#print axioms three_regular
#print axioms five_regular
#print axioms three_stable
#print axioms five_stable
end PrimeGap180.LiteralDensity
