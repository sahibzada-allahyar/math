import TrialPriceScalar180
namespace PrimeGap180.PriceExactCensus
set_option maxHeartbeats 100000000
set_option maxRecDepth 65536
private theorem c416 : PriceScalar.checked (416 : Book.Label) = true := by decide +kernel
private theorem c417 : PriceScalar.checked (417 : Book.Label) = true := by decide +kernel
private theorem c418 : PriceScalar.checked (418 : Book.Label) = true := by decide +kernel
private theorem c419 : PriceScalar.checked (419 : Book.Label) = true := by decide +kernel
private theorem c420 : PriceScalar.checked (420 : Book.Label) = true := by decide +kernel
private theorem c421 : PriceScalar.checked (421 : Book.Label) = true := by decide +kernel
private theorem c422 : PriceScalar.checked (422 : Book.Label) = true := by decide +kernel
private theorem c423 : PriceScalar.checked (423 : Book.Label) = true := by decide +kernel
private theorem c424 : PriceScalar.checked (424 : Book.Label) = true := by decide +kernel
private theorem c425 : PriceScalar.checked (425 : Book.Label) = true := by decide +kernel
private theorem c426 : PriceScalar.checked (426 : Book.Label) = true := by decide +kernel
private theorem c427 : PriceScalar.checked (427 : Book.Label) = true := by decide +kernel
private theorem c428 : PriceScalar.checked (428 : Book.Label) = true := by decide +kernel
private theorem c429 : PriceScalar.checked (429 : Book.Label) = true := by decide +kernel
private theorem c430 : PriceScalar.checked (430 : Book.Label) = true := by decide +kernel
private theorem c431 : PriceScalar.checked (431 : Book.Label) = true := by decide +kernel
private theorem c432 : PriceScalar.checked (432 : Book.Label) = true := by decide +kernel
private theorem c433 : PriceScalar.checked (433 : Book.Label) = true := by decide +kernel
private theorem c434 : PriceScalar.checked (434 : Book.Label) = true := by decide +kernel
private theorem c435 : PriceScalar.checked (435 : Book.Label) = true := by decide +kernel
private theorem c436 : PriceScalar.checked (436 : Book.Label) = true := by decide +kernel
private theorem c437 : PriceScalar.checked (437 : Book.Label) = true := by decide +kernel
private theorem c438 : PriceScalar.checked (438 : Book.Label) = true := by decide +kernel
private theorem c439 : PriceScalar.checked (439 : Book.Label) = true := by decide +kernel
private theorem c440 : PriceScalar.checked (440 : Book.Label) = true := by decide +kernel
private theorem c441 : PriceScalar.checked (441 : Book.Label) = true := by decide +kernel
private theorem c442 : PriceScalar.checked (442 : Book.Label) = true := by decide +kernel
private theorem c443 : PriceScalar.checked (443 : Book.Label) = true := by decide +kernel
private theorem c444 : PriceScalar.checked (444 : Book.Label) = true := by decide +kernel
private theorem c445 : PriceScalar.checked (445 : Book.Label) = true := by decide +kernel
private theorem c446 : PriceScalar.checked (446 : Book.Label) = true := by decide +kernel
private theorem c447 : PriceScalar.checked (447 : Book.Label) = true := by decide +kernel
theorem block13 : ∀ i : Fin 32, PriceScalar.checked ⟨416+i.val,by omega⟩ = true :=
  Fin.cases c416 (Fin.cases c417 (Fin.cases c418 (Fin.cases c419 (Fin.cases c420 (Fin.cases c421 (Fin.cases c422 (Fin.cases c423 (Fin.cases c424 (Fin.cases c425 (Fin.cases c426 (Fin.cases c427 (Fin.cases c428 (Fin.cases c429 (Fin.cases c430 (Fin.cases c431 (Fin.cases c432 (Fin.cases c433 (Fin.cases c434 (Fin.cases c435 (Fin.cases c436 (Fin.cases c437 (Fin.cases c438 (Fin.cases c439 (Fin.cases c440 (Fin.cases c441 (Fin.cases c442 (Fin.cases c443 (Fin.cases c444 (Fin.cases c445 (Fin.cases c446 (Fin.cases c447 (fun i => Fin.elim0 i))))))))))))))))))))))))))))))))
#print axioms block13
end PrimeGap180.PriceExactCensus
