import TrialReceiptGap180
import TrialPriceFrozenEndpoints180

/-! The current end point of the diameter-180 formalization. The price ledger is closed.
The analytic hypotheses are the three classical exponential-sum bounds and Proposition 3.1
of the 182 Type III companion. The remaining finite and numerical inputs are the fields
of `ReceiptGap.Numerical`. -/
namespace PrimeGap180

theorem h1_le_180_of_numerical (prime : Distribution.ClassicalPrimeBounds)
    (rank4 : PrimeGap182Audit.AllIncidenceRankFourBounds)
    (prop31 : PrimeGap182.TypeIII.HasFiniteExceptionalTypeIIIInput)
    (numerical : ReceiptGap.Numerical) :
    PrimeGap186.primeGapLiminf ≤ (180 : EReal) :=
  ReceiptGap.gap_of_cited prime rank4 prop31 PriceBindings.frozen_endpoints numerical

#print axioms h1_le_180_of_numerical
end PrimeGap180
