import TrialLaterLowTransformBound180

/-! Upper transform in exactly the positive exponential-integral representation
used by the archived scalar Chernoff estimates. -/
noncomputable section
open Filter MeasureTheory Set PrimeGap186 PrimeGap180.Sector PrimeGap180.FrozenProfile
open scoped NNReal
namespace PrimeGap180.LaterLowTransform

def tailCorrection (e s r : ℝ) :=
  ∫ x in Ioi e, (Real.exp (-s*x)-Real.exp (-(s+r)*x))/x

theorem correction_le {e s r : ℝ} (he : 0<e) (hc : e≤cap) (hs : 0<s) (hr : 0≤r) :
    correction e s r ≤ tailCorrection e s r := by
  let f := fun x : ℝ => (Real.exp (-s*x)-Real.exp (-(s+r)*x))/x
  have nn (x : ℝ) (hx : x∈Ioi e) : 0 ≤ f x := by
    have xp : 0<x := he.trans hx
    apply div_nonneg _ xp.le
    exact sub_nonneg.mpr (Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_right (by linarith) xp.le))
  have integ : IntegrableOn f (Ioi e) := by
    have mg : Measurable f := by unfold f; fun_prop
    apply ((integrableOn_exp_mul_Ioi (a:=-s) (by linarith) e).div_const e).mono' mg.aestronglyMeasurable
    filter_upwards [ae_restrict_mem (μ:=volume) measurableSet_Ioi] with x hx
    rw [Real.norm_eq_abs,abs_of_nonneg (nn x hx)]
    calc
      f x ≤ Real.exp (-s*x)/x := div_le_div_of_nonneg_right (sub_le_self _ (Real.exp_pos _).le) (he.trans hx).le
      _ ≤ Real.exp (-s*x)/e := div_le_div_of_nonneg_left (Real.exp_pos _).le he hx.le
  rw [correction,intervalIntegral.integral_of_le hc]
  change (∫ x in Ioc e cap, f x) ≤ ∫ x in Ioi e, f x
  exact setIntegral_mono_set integ ((ae_restrict_mem (μ:=volume) measurableSet_Ioi).mono nn)
    (Eventually.of_forall fun _ h=>h.1)

/-- Actual one-site transform bounded by its infinite-cap scalar majorant. -/
theorem bound_tail (a : Active) (s r : ℝ≥0) (hs : 0<s) :
    site (FrozenData.tables.tailEdge a) s r ≤
      (1/((s:ℝ)+r))*Real.exp (tailCorrection (edge (FrozenData.tables.tailEdge a)) s r) := by
  apply (bound a s r (add_pos_of_pos_of_nonneg hs (show 0≤r from r.2))).trans
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  exact Real.exp_le_exp.mpr (correction_le (FrozenData.tables.tailPos a)
    (FrozenData.tables.last ▸ FrozenData.tables.ordered.monotone (Fin.le_last _)) (by exact_mod_cast hs) r.2)

#print axioms bound_tail
end PrimeGap180.LaterLowTransform
