import TrialSourceRectValidation180
import TrialSourcePhysicalFrontier180
import TrialTerminal180

/-! Per-row bitmap and schedule checks suffice for the actual signed source
coverage of the 521 physical labels. Both orientations use the same
nonzero signed entry, also when the larger plateau is on the right. -/
noncomputable section
open PrimeGap180.Book PrimeGap180.Sector PrimeGap180.Sector.Lookup PrimeGap180.FrozenProfile
open PrimeGap180.SourceFrontier PrimeGap180.SourcePlans PrimeGap180.LongSchedule
open PrimeGap180.SourcePhysicalFrontier PrimeGap180.SourceRectValidation
namespace PrimeGap180.SourceFrontierApply

private def shadows (g : Nat) (o : Owner) (p : Partner) :=
  decide (p.group = g ∧ o.cap ≤ p.cap ∧ o.radius ≤ p.radius ∧ o.upper ≤ p.upper)

set_option maxRecDepth 131072
set_option maxHeartbeats 100000000

private theorem shadows_all : ∀ g : Fin 445, (SourceFrontier.owners g.val).all
    (fun o => partners.any (shadows g.val o)) = true := by decide +kernel

private def groupPass (s : Book.Label) : Bool :=
  if hs : s.val < 170 ∨ 173 < s.val then
    decide ((FrozenData.tables.group s).val = (Book.owner ⟨s,hs⟩).val)
  else true

private theorem group_pass : ∀ s : Book.Label, groupPass s = true := by decide +kernel

private theorem groups (s : SectorId) : (FrozenData.tables.group s.val).val = (Book.owner s).val := by
  have hs : s.val.val < 170 ∨ 173 < s.val.val := s.property
  simpa only [groupPass,dif_pos hs,decide_eq_true_eq] using group_pass s.val

private theorem shadow {g : Fin 445} {o : Owner} (member : o ∈ SourceFrontier.owners g.val) :
    ∃ (j : Nat) (p : Partner), partners[j]? = some p ∧ p.group = g.val ∧
      o.cap ≤ p.cap ∧ o.radius ≤ p.radius ∧ o.upper ≤ p.upper := by
  obtain ⟨p,pmem,meet⟩ := List.any_eq_true.mp (List.all_eq_true.mp (shadows_all g) _ member)
  obtain ⟨j,lt,atP⟩ := List.mem_iff_getElem.mp pmem
  have lookup : partners[j]? = some p := by rw [List.getElem?_eq_getElem lt,atP]
  exact ⟨j,p,lookup,of_decide_eq_true meet⟩

def Schedules := ∀ k e, e ∈ entries k → Nonempty (Booked k e.corner.q.real)

def Rectangles := ∀ k (g : Fin 445) o, o ∈ SourceFrontier.owners g.val → check k g.val o = true

def Permitted (b : Ledger) := ∀ k (g h : Fin 445) (p : Partner) (j : Nat),
  partners[j]? = some p → p.group = h.val → b.affine k g h ≠ 0 ∨ b.affine k h g ≠ 0 →
    (allow k g.val).testBit j = true

private theorem tick_le {x : ℝ} {n : Nat} (le : x ≤ n) : x/unit ≤ (LongSchedule.tick n : ℝ) := by
  change x/10000000 ≤ (((n:ℚ)/10000000:ℚ):ℝ)
  push_cast
  exact div_le_div_of_nonneg_right le (by norm_num)

private theorem oriented {b : Ledger} (schedules : Schedules) (rects : Rectangles) (perm : Permitted b)
    (k : Row) (g h : Fin 445) (a a' : Receipt) (oa : FrozenPairGate.occurs a) (ob : FrozenPairGate.occurs a')
    (ga : (FrozenData.tables.group a.sector).val = g.val) (gb : (FrozenData.tables.group a'.sector).val = h.val)
    (nz : b.affine k g h ≠ 0 ∨ b.affine k h g ≠ 0)
    (big : unit/2 < FrozenPairGate.upper a+FrozenPairGate.upper a') :
    ∃ c, Nonempty (Booked k c) ∧ c.owner (FrozenPairGate.k a) (FrozenPairGate.k a') := by
  obtain ⟨o,mem,dom⟩ := dominant oa (by rw [ga]; exact g.isLt)
  obtain ⟨o',mem',dom'⟩ := dominant ob (by rw [gb]; exact h.isLt)
  rw [ga] at mem
  rw [gb] at mem'
  obtain ⟨j,p,atP,grp,capB,radiusB,upperB⟩ := shadow mem'
  have larger : 5000000 < o.upper+p.upper := by
    have u : (5000000:ℝ) < FrozenPairGate.upper a+FrozenPairGate.upper a' := by
      convert big using 1 <;> norm_num [unit]
    exact_mod_cast lt_of_lt_of_le u (add_le_add dom.2.2.1 (dom'.2.2.1.trans (Nat.cast_le.mpr upperB)))
  obtain ⟨sel⟩ := selected (rects k g o mem) larger atP (perm k g h p j atP grp nz)
  let c := orient sel.e.corner sel.flip
  obtain ⟨za,zb,sa,sb,la⟩ := sel.geom
  have original := schedules k sel.e sel.inRow
  have booked : Nonempty (Booked k c.q.real) := by
    obtain ⟨s⟩ := original
    cases f : sel.flip
    · simpa [c,orient,f] using (show Nonempty (Booked k sel.e.corner.q.real) from ⟨s⟩)
    · exact ⟨by simpa [c,orient,f,Corner.swap,CornerData.q,SourceCornerArithmetic.QCorner.real] using s.swap⟩
  refine ⟨c.q.real,booked,tick_le (dom.1.trans (Nat.cast_le.mpr za)),?_,
    tick_le (dom.2.1.trans (Nat.cast_le.mpr sa)),?_,tick_le (dom.2.2.2.trans (Nat.cast_le.mpr la))⟩
  · exact tick_le (dom'.1.trans (Nat.cast_le.mpr (capB.trans zb)))
  · exact tick_le (dom'.2.1.trans (Nat.cast_le.mpr (radiusB.trans sb)))

theorem covered (b : Ledger) (schedule : Schedules) (rect : Rectangles) (matrix : Permitted b) :
    Terminal.SourceCoverage b := by
  intro k s t nz a b' oa ob sa sb hi
  have ea : s.val = a.sector := by simpa [joinLabel] using sa
  have eb : t.val = b'.sector := by simpa [joinLabel] using sb
  have ag : (FrozenData.tables.group a.sector).val = (Book.owner s).val := by rw [←ea]; exact groups s
  have bg : (FrozenData.tables.group b'.sector).val = (Book.owner t).val := by rw [←eb]; exact groups t
  have an : b.affine k (Book.owner s) (Book.owner t) ≠ 0 := by
    intro zero
    apply nz
    simp [Book.lifted,Book.matrix,zero]
  obtain ⟨c,⟨plan⟩,own,other⟩ := common_corner (inTable := fun c => Nonempty (Booked k c))
    (fun c w => w.map Booked.swap)
    (oriented schedule rect matrix k _ _ a b' oa ob ag bg (Or.inl an) hi)
    (oriented schedule rect matrix k _ _ b' a ob oa bg ag (Or.inr an) (by simpa [add_comm] using hi))
  exact ⟨plan.plan a b' own other⟩

#print axioms covered
end PrimeGap180.SourceFrontierApply
