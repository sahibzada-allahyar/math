import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G303
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 303

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G303

namespace PrimeGap180.PriceIsolatedGroup.G308
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 308

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G308

namespace PrimeGap180.PriceIsolatedGroup.G313
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 313

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G313

namespace PrimeGap180.PriceIsolatedGroup.G318
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 318

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G318
