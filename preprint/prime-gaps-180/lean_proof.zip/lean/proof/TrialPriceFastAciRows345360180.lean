import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G345
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 345

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G345

namespace PrimeGap180.PriceIsolatedGroup.G350
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 350

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G350

namespace PrimeGap180.PriceIsolatedGroup.G355
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 355

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G355

namespace PrimeGap180.PriceIsolatedGroup.G360
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 360

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G360
