import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G138
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 138

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G138

namespace PrimeGap180.PriceIsolatedGroup.G143
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 143

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G143

namespace PrimeGap180.PriceIsolatedGroup.G148
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 148

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G148

namespace PrimeGap180.PriceIsolatedGroup.G153
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 153

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G153
