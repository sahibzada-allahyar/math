import TrialDebitNativeClasses180
import TrialDebitTransfer180

/-! Pure historical-bin numerator and denominator for the frozen original
trial. All fine flags disappear, including inside the signed insertion. -/
noncomputable section
open scoped Classical BigOperators
open PrimeGap180.CoarseLaw PrimeGap180.CoarseForms PrimeGap180.Sector
open PrimeGap180.DebitWeights PrimeGap180.PhysicalDebit
namespace PrimeGap180.DebitNativeClasses

def index (t : Atom) := t.1.val
def massN (u : Atom → ℝ) := ∑ t : Fin 39 → Atom, (rawAtom t)^2*∏ j,u (t j)
def singleN (u : Atom → ℝ) (i : Fin 39) (t : Fin 38 → Atom) :=
  ∑ b : Atom,u b*rawAtom (i.insertNth (α := fun _ => Atom) b t)
def debitN (u : Atom → ℝ) :=
  rho*∑ i : Fin 39, ∑ t, rateAtom t*(singleN u i t)^2 * ∏ j,u (t j)

theorem first_mass (j : Fin 130966) :
    physicalBin atom (j,some 0) = CellQuadrature.cdf j.val (capAt 0) := by
  unfold physicalBin fibre CellQuadrature.cdf
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro s _
  by_cases off : weight s=0
  · simp [off]
  have val : atom s=(j,some 0) ↔ s.1.val=j.val ∧ s.2 (capAt 0)=true := by
    change (s.1,(atom s).2)=(j,some 0) ↔ _
    rw [Prod.ext_iff,Fin.ext_iff,first_atom s off]
  simp only [val]

theorem next_mass (j : Fin 130966) (k : Fin 36) : physicalBin atom (j,some k.succ) =
    CellQuadrature.bin j.val (capAt k.castSucc) (capAt k.succ) := by
  unfold physicalBin fibre CellQuadrature.bin
  rw [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro s _
  by_cases off : weight s=0
  · simp [off]
  have val : atom s=(j,some k.succ) ↔ s.1.val=j.val ∧ s.2 (capAt k.succ)=true ∧ s.2 (capAt k.castSucc)=false := by
    change (s.1,(atom s).2)=(j,some k.succ) ↔ _
    rw [Prod.ext_iff,Fin.ext_iff,next_atom s off]
  simp only [val]

private theorem supported {u : Atom → ℝ} {d : ℕ} (x : Fin d → State)
    (nz : (∏ j,liftNative atom u (x j)) ≠ 0) : ∀ j,weight (x j)≠0 := by
  intro j off
  exact nz (Finset.prod_eq_zero (Finset.mem_univ j) (by simp [liftNative,off]))

private theorem observed_sum {X Y : Type*} [Fintype X] [Fintype Y] [DecidableEq Y]
    (C : X → Y) (w : X → ℝ) (u f : Y → ℝ)
    (marginal : ∀ b, (∑ z ∈ Finset.univ.filter (fun z => C z=b),w z) = u b) :
    (∑ z, f (C z)*w z) = ∑ b, f b*u b := by
  rw [←Finset.sum_fiberwise Finset.univ C (fun z => f (C z)*w z)]
  apply Finset.sum_congr rfl
  intro b _
  rw [←marginal b,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro z mem
  rw [(Finset.mem_filter.mp mem).2]

theorem one_observation (u : Atom → ℝ) (bins : BinComparison atom index u) (f : Atom → ℝ) :
    (∑ z : State, f (atom z)*liftNative atom u z) = ∑ b : Atom, f b*u b :=
  observed_sum atom (liftNative atom u) u f (native_marginal atom index u bins)

private theorem inserted_atom (i : Fin 39) (x : Fin 38 → State) (z : State) :
    atom ∘ i.insertNth (α := fun _ => State) z x =
    i.insertNth (α := fun _ => Atom) (atom z) (atom ∘ x) := by
  funext j
  exact i.succAboveCases (by simp) (fun k => by simp) j

theorem single_eq (u : Atom → ℝ) (bins : BinComparison atom index u)
    (i : Fin 39) (x : Fin 38 → State) (nz : ∀ j,weight (x j)≠0) :
    singleW (liftNative atom u) i x = singleN u i (atom ∘ x) := by
  let f : Atom → ℝ := fun b => rawAtom (i.insertNth (α := fun _ => Atom) b (atom ∘ x))
  calc
    _ = ∑ z : State, f (atom z)*liftNative atom u z := by
      apply Finset.sum_congr rfl
      intro z _
      by_cases zero : weight z=0
      · simp [liftNative,zero]
      · have ok (j : Fin 39) : weight ((i.insertNth (α := fun _ => State) z x) j) ≠ 0 :=
          i.succAboveCases (by simpa using zero) (fun k => by simpa using nz k) j
        rw [original_eq _ ok,inserted_atom,mul_comm]
    _ = ∑ b : Atom, f b*u b := one_observation u bins f
    _ = _ := by unfold singleN; apply Finset.sum_congr rfl; intro b _; exact mul_comm _ _

theorem mass_eq (u : Atom → ℝ) (bins : BinComparison atom index u) : massW (liftNative atom u)=massN u := by
  unfold massN
  rw [←native_product atom index u bins 39 (fun t => (rawAtom t)^2)]
  apply Finset.sum_congr rfl
  intro x _
  by_cases off : (∏ j,liftNative atom u (x j))=0
  · simp [off]
  · rw [original_eq x (supported x off)]

theorem debit_eq (u : Atom → ℝ) (bins : BinComparison atom index u) : debitW (liftNative atom u)=debitN u := by
  unfold debitW debitN
  apply congrArg (rho*·)
  apply Finset.sum_congr rfl
  intro i _
  rw [←native_product atom index u bins 38 (fun t => rateAtom t*(singleN u i t)^2)]
  apply Finset.sum_congr rfl
  intro x _
  by_cases off : (∏ j,liftNative atom u (x j))=0
  · simp [off]
  · have ok := supported x off
    have p : priceAt x = rateAtom (atom ∘ x) := by
      unfold priceAt rateAtom
      rw [label_eq x ok]
      rfl
    rw [p,single_eq u bins i x ok]

/-- Exterior marks and the overflow index never contribute to the raw norm
or either side of a signed insertion. Their mass may be completed by zero
for the historical convolution and by the physical law for comparison. -/
theorem mass_live (u w : Atom → ℝ) (same : ∀ b,live b → u b=w b) : massN u=massN w := by
  apply Finset.sum_congr rfl
  intro t _
  by_cases off : rawAtom t=0
  · simp [off]
  · rw [Finset.prod_congr rfl (fun i _ => same (t i) (live_of_raw t off i))]

theorem single_live (u w : Atom → ℝ) (same : ∀ b,live b → u b=w b)
    (i : Fin 39) (t : Fin 38 → Atom) : singleN u i t=singleN w i t := by
  apply Finset.sum_congr rfl
  intro z _
  by_cases off : rawAtom (i.insertNth (α := fun _ => Atom) z t)=0
  · simp [off]
  · have on : live z := by simpa using live_of_raw _ off i
    rw [same z on]

theorem debit_live (u w : Atom → ℝ) (same : ∀ b,live b → u b=w b) : debitN u=debitN w := by
  unfold debitN
  apply congrArg (rho*·)
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro x _
  rw [single_live u w same]
  by_cases off : singleN w i x=0
  · simp [off]
  have hit : ∃ b,rawAtom (i.insertNth (α := fun _ => Atom) b x)≠0 := by
    by_contra! z
    apply off
    simp [singleN,z]
  obtain ⟨b,ok⟩ := hit
  have inside (j : Fin 38) : live (x j) := by simpa using live_of_raw _ ok (i.succAbove j)
  rw [Finset.prod_congr rfl (fun j _ => same (x j) (inside j))]

def completed (u : Atom → ℝ) (b : Atom) := if live b then u b else physicalBin atom b

structure LiveBinComparison (u : Atom → ℝ) : Prop where
  nonnegative : ∀ b,live b → 0 ≤ u b
  small : ∀ b,live b → index b < 45067 → u b=physicalBin atom b
  lower : ∀ b,live b → (if 45067 ≤ index b then (1-0.00002:ℝ) else 1)*u b ≤ physicalBin atom b
  upper : ∀ b,live b → physicalBin atom b ≤ (if 45067 ≤ index b then (1.00002:ℝ) else 1)*u b

theorem complete_bins (u : Atom → ℝ) (bins : LiveBinComparison u) :
    BinComparison atom index (completed u) := by
  have p (b : Atom) : 0 ≤ physicalBin atom b := Finset.sum_nonneg (fun _ _ => ENNReal.toReal_nonneg)
  refine ⟨fun _ => rfl,?_,?_,?_,?_⟩
  · intro b
    by_cases h : live b
    · simpa [completed,h] using bins.nonnegative b h
    · simpa [completed,h] using p b
  · intro b low
    by_cases h : live b
    · simpa [completed,h] using bins.small b h low
    · simp [completed,h]
  · intro b
    by_cases h : live b
    · simpa [completed,h] using bins.lower b h
    · simp only [completed,ite_eq_right h]
      split_ifs <;> linarith only [p b]
  · intro b
    by_cases h : live b
    · simpa [completed,h] using bins.upper b h
    · simp only [completed,ite_eq_right h]
      split_ifs <;> linarith only [p b]

/-- The only remaining numerical form inputs are the outward native scalar
on 37 historical caps and the ordinary physical mass erased by restoration. -/
theorem restored_of_native_bins (u : Atom → ℝ) (bins : BinComparison atom index u)
    (native : debitN u ≤ 0.000023397128*massN u)
    (removed : NumericalAccount.mass Restoration.deleted ≤ 0.000160674*NumericalAccount.mass Restoration.original) :
    NumericalAccount.directDebit ≤ 0.000042838*NumericalAccount.mass Restoration.original := by
  apply restored_of_bins atom index u bins _ removed
  simpa only [mass_eq u bins,debit_eq u bins] using native

theorem restored_of_live_bins (u : Atom → ℝ) (bins : LiveBinComparison u)
    (native : debitN u ≤ 0.000023397128*massN u)
    (removed : NumericalAccount.mass Restoration.deleted ≤ 0.000160674*NumericalAccount.mass Restoration.original) :
    NumericalAccount.directDebit ≤ 0.000042838*NumericalAccount.mass Restoration.original := by
  have same (b : Atom) (h : live b) : completed u b = u b := by simp [completed,h]
  apply restored_of_native_bins (completed u) (complete_bins u bins) _ removed
  simpa only [debit_live (completed u) u same,mass_live (completed u) u same] using native

#print axioms restored_of_live_bins
#print axioms mass_eq
#print axioms debit_eq
#print axioms restored_of_native_bins
end PrimeGap180.DebitNativeClasses
