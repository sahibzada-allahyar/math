import TrialFirstEdgeScaling180
import TrialFirstEdgeClosed180

noncomputable section
open MeasureTheory Set
open scoped BigOperators ENNReal
namespace PrimeGap180.JointEdgeSecond
open FirstEdgeKernels
open private u from TrialFirstEdgeCappedCDF180
open private saturated negative from TrialFirstEdgeScaling180

theorem law (E : ℝ) (he : 1 ≤ E) :
    FirstEdgeReference.law 1 E = (ENNReal.ofReal E)⁻¹ • siteLaw 1 (E-1/2) := by
  have pos : 0<E := zero_lt_one.trans_le he
  have nn : 0≤E-1/2 := by linarith
  have : IsFiniteMeasure (FirstEdgeReference.law 1 E) :=
    ⟨by rw [FirstEdgeReference.mass pos]; exact ENNReal.ofReal_lt_top⟩
  have : IsFiniteMeasure ((ENNReal.ofReal E)⁻¹ • siteLaw 1 (E-1/2)) :=
    Measure.smul_finite _ ((ENNReal.inv_lt_top).mpr (ENNReal.ofReal_pos.mpr pos)).ne
  apply Measure.ext_of_Iic
  intro z
  rw [Measure.smul_apply,smul_eq_mul,FirstEdgeSiteCDF.cdf 1 _ z nn,
    ←ENNReal.div_eq_inv_mul,←ENNReal.ofReal_div_of_pos pos]
  by_cases neg : z<0
  · rw [negative zero_lt_one pos neg.le]
    have z1 : z≤1 := by linarith
    simp [u,min_eq_right z1,max_eq_left neg.le,max_eq_left (by linarith : z-1≤0),show ¬1≤z by linarith]
  by_cases high : 1≤z
  · rw [saturated 1 E z pos high]
    congr 1
    simp [u,high]
    field_simp
  · have zp := le_of_not_gt neg
    have z1 := lt_of_not_ge high
    rw [FirstEdgeReference.cdf pos zp z1]
    simp [u,min_eq_right z1.le,min_eq_right (z1.le.trans he),max_eq_right zp,
      max_eq_left (by linarith : z-1≤0),high]
    congr 1
    ring

#print axioms law
end PrimeGap180.JointEdgeSecond
