import TrialPriceSignedCensus180
import TrialPriceChargeAssembly180
import TrialPriceFactorChecks180

noncomputable section
namespace PrimeGap180.PriceGroupCensus
open Book

/-- All prices on the frozen ledger follow from the original 101 public factor-slot identities. -/
theorem endpoints_of_public_factor_slots (source : PricePhysicalGrams.Bound) : FrozenLedger.Endpoints := by
  apply PriceResourceSlots.endpoints
  · intro u
    exact source ⟨PriceScalar.resourceIndex u, Nat.lt_trans (PricePhysicalGrams.resource_index u) (by decide)⟩
  · intro e g
    exact PriceChargeAssembly.event_charge source PriceFactorData.checked e g (all g e)

#print axioms endpoints_of_public_factor_slots
end PrimeGap180.PriceGroupCensus
