import TrialMarkedEventBins180
import PrimeGaps186

/-! Upper prices of the clipped rectangles in the 72-bin five-prime cover.
The only partially cut rectangles have index sum 107 and are half squares. -/
noncomputable section
open scoped Classical BigOperators Topology
open MeasureTheory Filter PrimeGap186
namespace PrimeGap180.ClippedPair

def band (x l u : ℝ) := (Nat.primesBelow ⌈x ^ u⌉₊).filter fun p : ℕ => x ^ l ≤ (p : ℝ)

theorem band_mem {x l u : ℝ} {p : ℕ} : p ∈ band x l u ↔
    p.Prime ∧ x^l ≤ (p:ℝ) ∧ (p:ℝ) < x^u := by
  simp only [band,Finset.mem_filter,Nat.mem_primesBelow,Nat.lt_ceil]
  tauto

def pairBin (x l r h a : ℝ) := ((band x l (l+h)) ×ˢ (band x r (r+h))).filter
  fun v => v.1 < v.2 ∧ ((v.1*v.2:ℕ):ℝ) < x^a

def weight (v : ℕ × ℕ) : ℝ := (v.1:ℝ)⁻¹ * (v.2:ℝ)⁻¹
def mass (x l r h a : ℝ) := ∑ v ∈ pairBin x l r h a, weight v

private theorem tendsto_band {l h : ℝ} (lp : 0 < l) (hp : 0 ≤ h) :
    Tendsto (fun x => ∑ p ∈ band x l (l+h), (p:ℝ)⁻¹) atTop
      (𝓝 (∫ t in l..l+h, 1/t)) := by
  simpa only [band,one_div] using prime_band_logarithmic_weight_tendsto l (l+h) lp
    (by linarith) (fun _ => (1:ℝ)) (fun _ => 0)
    (fun t _ => hasDerivAt_const t 1) continuousOn_const

private theorem int_const_le {l h : ℝ} (lp : 0 < l) (hp : 0 ≤ h) :
    (∫ t in l..l+h, 1/t) ≤ h/l := by
  have le : l ≤ l+h := by linarith
  have int := (continuousOn_const.div continuousOn_id (fun t ht =>
    (lp.trans_le ht.1).ne') : ContinuousOn (fun t : ℝ => 1/t) (Set.Icc l (l+h))).intervalIntegrable_of_Icc
      (μ := volume) le
  have z := intervalIntegral.integral_mono_on (μ := volume) le int
    (g := fun _ => 1/l) intervalIntegrable_const
    (fun t ht => one_div_le_one_div_of_le lp ht.1)
  simpa [intervalIntegral.integral_const,smul_eq_mul,div_eq_mul_inv] using z

private theorem uniform_band {r h : ℝ} (rp : 0 < r) :
    ∃ E : ℝ → ℝ, Tendsto E atTop (𝓝 0) ∧ ∀ᶠ x : ℝ in atTop, ∀ b ∈ Set.Icc r (r+h),
      (∑ q ∈ band x r b, (q:ℝ)⁻¹) ≤ (b-r)/r + E x := by
  obtain ⟨C,hC,err⟩ := prime_band_logarithmic_weight_error r (r+h) rp
  let E := fun x : ℝ => (2*C/r)/Real.log x + (x^r)⁻¹
  refine ⟨E,?_,?_⟩
  · simpa [E] using (Real.tendsto_log_atTop.const_div_atTop (2*C/r)).add
      ((tendsto_rpow_atTop rp).inv_tendsto_atTop)
  filter_upwards [eventually_gt_atTop (1:ℝ),(tendsto_rpow_atTop rp).eventually_ge_atTop 2]
    with x hx hx2
  intro b hb
  let S := (Nat.primesLE ⌊x^b⌋₊).filter fun p : ℕ => x^r < (p:ℝ)
  let v := ⌊x^r⌋₊
  have sub : band x r b ⊆ insert v S := by
    intro p hp
    obtain ⟨prime,lo,hi⟩ := band_mem.mp hp
    rcases lo.eq_or_lt with eq|lt
    · exact Finset.mem_insert.mpr (Or.inl (by simp [v,eq]))
    · exact Finset.mem_insert.mpr (Or.inr (Finset.mem_filter.mpr
        ⟨Nat.mem_primesLE.mpr ⟨Nat.le_floor hi.le,prime⟩,lt⟩))
  have hsum : (∑ q ∈ band x r b, (q:ℝ)⁻¹) ≤
      (∑ q ∈ S, (q:ℝ)⁻¹) + (x^r)⁻¹ := by
    by_cases ev : ∃ p : ℕ, (p:ℝ) = x^r
    · obtain ⟨p,eq⟩ := ev
      have ep : v=p := by simp [v,←eq]
      have e : v ∉ S := by simp [S,ep,eq]
      have hs := Finset.sum_le_sum_of_subset_of_nonneg sub
        (fun q _ _ => inv_nonneg.mpr (Nat.cast_nonneg q) : ∀ q ∈ insert v S, q ∉ band x r b → 0 ≤ (q:ℝ)⁻¹)
      rw [Finset.sum_insert e,ep,eq] at hs
      linarith
    · have sub' : band x r b ⊆ S := by
        intro p hp
        obtain ⟨pr,lo,hi⟩ := band_mem.mp hp
        exact Finset.mem_filter.mpr ⟨Nat.mem_primesLE.mpr ⟨Nat.le_floor hi.le,pr⟩,
          lt_of_le_of_ne lo (fun e => ev ⟨p,e.symm⟩)⟩
      have hs := Finset.sum_le_sum_of_subset_of_nonneg sub'
        (fun q _ _ => inv_nonneg.mpr (Nat.cast_nonneg q) : ∀ q ∈ S, q ∉ band x r b → 0 ≤ (q:ℝ)⁻¹)
      have z := inv_nonneg.mpr (Real.rpow_nonneg (zero_lt_one.trans hx).le r)
      linarith
  have e := (abs_le.mp (err (fun _ => 1) (fun _ => 0) 1 0 (by norm_num) le_rfl
    (fun t _ => hasDerivAt_const t 1) continuousOn_const (by simp) (by simp)
    x hx hx2 b hb.1 hb.2)).2
  have z := int_const_le rp (sub_nonneg.mpr hb.1)
  rw [show r+(b-r)=b by ring] at z
  simp only [one_div,zero_mul,add_zero] at e z
  change _ ≤ _ + ((2*C/r)/Real.log x + (x^r)⁻¹)
  dsimp only [S] at hsum
  linarith

private theorem mass_expand (x l r h a : ℝ) : mass x l r h a =
    ∑ p ∈ band x l (l+h), (p:ℝ)⁻¹ * ∑ q ∈ (band x r (r+h)).filter
      (fun q => p < q ∧ ((p*q:ℕ):ℝ) < x^a), (q:ℝ)⁻¹ := by
  classical
  simp only [mass,pairBin,Finset.sum_filter,Finset.sum_product,Finset.mul_sum,weight]
  apply Finset.sum_congr rfl
  intro p _
  apply Finset.sum_congr rfl
  intro q _
  split_ifs <;> simp

private theorem triangle_int {l r h : ℝ} (lp : 0 < l) (rp : 0 < r) (hp : 0 ≤ h) :
    (∫ t in l..l+h, ((l+h-t)/r)/t) ≤ h^2/(2*l*r) := by
  have le : l ≤ l+h := by linarith
  have num : Continuous (fun t : ℝ => (l+h-t)/r) := by fun_prop
  have L := (num.continuousOn.div continuousOn_id (fun t ht =>
    (lp.trans_le ht.1).ne') : ContinuousOn (fun t : ℝ => ((l+h-t)/r)/t)
    (Set.Icc l (l+h))).intervalIntegrable_of_Icc (μ := volume) le
  have R : Continuous (fun t : ℝ => ((l+h-t)/r)/l) := by fun_prop
  have z := intervalIntegral.integral_mono_on (μ := volume) le L (R.intervalIntegrable ..)
    (fun t ht => div_le_div_of_nonneg_left (div_nonneg (sub_nonneg.mpr ht.2) rp.le) lp ht.1)
  apply z.trans_eq
  rw [intervalIntegral.integral_div,intervalIntegral.integral_div,
    intervalIntegral.integral_sub (f := fun _ : ℝ => l+h) (g := fun t : ℝ => t) intervalIntegrable_const (continuous_id.intervalIntegrable ..),
    intervalIntegral.integral_const,integral_id,smul_eq_mul]
  ring

/-- A strict cap across the two far corners cuts exactly half a bin. -/
theorem half_square {l r h : ℝ} (lp : 0 < l) (rp : 0 < r) (hp : 0 < h)
    {ε : ℝ} (ep : 0 < ε) :
    ∀ᶠ x : ℝ in atTop, mass x l r h (l+r+h) ≤ h^2/(2*l*r) + ε := by
  obtain ⟨E,hE,inner⟩ := uniform_band (h := h) rp
  let f := fun t : ℝ => (l+h-t)/r
  have hf := prime_band_logarithmic_weight_tendsto l (l+h) lp (by linarith)
    f (fun _ => -1/r) (fun t _ => by
      simpa [f] using ((hasDerivAt_id t).const_sub (l+h)).div_const r) continuousOn_const
  have lim := hf.add ((tendsto_band lp hp.le).mul hE)
  simp only [mul_zero,add_zero] at lim
  have upper := lim.eventually_le_const
    ((triangle_int lp rp hp.le).trans_lt (lt_add_of_pos_right _ ep))
  filter_upwards [eventually_gt_atTop (1:ℝ),inner,upper] with x hx hin hup
  rw [mass_expand]
  apply le_trans _ hup
  change _ ≤ (∑ p ∈ band x l (l+h), f (Real.logb x p) / p) +
    (∑ p ∈ band x l (l+h), (p:ℝ)⁻¹) * E x
  rw [Finset.sum_mul,← Finset.sum_add_distrib]
  apply Finset.sum_le_sum
  intro p mem
  obtain ⟨pr,lo,hi⟩ := band_mem.mp mem
  have pp : 0 < (p:ℝ) := Nat.cast_pos.mpr pr.pos
  let t := Real.logb x (p:ℝ)
  have tl : l ≤ t := (Real.le_logb_iff_rpow_le hx pp).mpr lo
  have th : t < l+h := (Real.logb_lt_iff_lt_rpow hx pp).mpr hi
  let b := l+r+h-t
  have ib : b ∈ Set.Icc r (r+h) := ⟨by dsimp [b]; linarith,by dsimp [b]; linarith⟩
  have sub : (band x r (r+h)).filter (fun q => p < q ∧ ((p*q:ℕ):ℝ)<x^(l+r+h))
      ⊆ band x r b := by
    intro q hq
    obtain ⟨qmem,_,top⟩ := Finset.mem_filter.mp hq
    obtain ⟨qr,ql,_⟩ := band_mem.mp qmem
    have qp : 0 < (q:ℝ) := Nat.cast_pos.mpr qr.pos
    have z := (Real.logb_lt_iff_lt_rpow hx (mul_pos pp qp)).mpr (by simpa using top)
    rw [Real.logb_mul pp.ne' qp.ne'] at z
    apply band_mem.mpr
    refine ⟨qr,ql,(Real.logb_lt_iff_lt_rpow hx qp).mp ?_⟩
    dsimp [b,t]
    linarith
  have w := (Finset.sum_le_sum_of_subset_of_nonneg sub
    (fun q _ _ => inv_nonneg.mpr (Nat.cast_nonneg q))).trans (hin b ib)
  apply (mul_le_mul_of_nonneg_left w (inv_nonneg.mpr pp.le)).trans_eq
  change (p:ℝ)⁻¹ * ((l+r+h-t-r)/r+E x) = ((l+h-t)/r)/p + (p:ℝ)⁻¹*E x
  ring

private theorem square_bounds (x l r h a : ℝ) :
    mass x l r h a ≤ (∑ p ∈ band x l (l+h), (p:ℝ)⁻¹) *
      ∑ q ∈ band x r (r+h), (q:ℝ)⁻¹ := by
  rw [mass_expand,Finset.sum_mul]
  apply Finset.sum_le_sum
  intro p _
  apply mul_le_mul_of_nonneg_left _ (inv_nonneg.mpr (Nat.cast_nonneg p))
  exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset ..)
    (fun q _ _ => inv_nonneg.mpr (Nat.cast_nonneg q))

private theorem symmetry_bound (x l h a : ℝ) : 2*mass x l l h a ≤
    (∑ p ∈ band x l (l+h), (p:ℝ)⁻¹)^2 := by
  let S := band x l (l+h)
  let f := fun p q : ℕ => if p<q ∧ ((p*q:ℕ):ℝ)<x^a then (p:ℝ)⁻¹*(q:ℝ)⁻¹ else 0
  have eq : mass x l l h a = ∑ p ∈ S, ∑ q ∈ S, f p q := by
    simp only [mass,pairBin,Finset.sum_filter,Finset.sum_product,S,f,weight]
  have sw : mass x l l h a = ∑ p ∈ S, ∑ q ∈ S, f q p := eq.trans Finset.sum_comm
  rw [two_mul,congrArg₂ (·+·) eq sw,← Finset.sum_add_distrib,pow_two,Finset.sum_mul]
  apply Finset.sum_le_sum
  intro p _
  rw [← Finset.sum_add_distrib,Finset.mul_sum]
  apply Finset.sum_le_sum
  intro q _
  dsimp [f]
  split_ifs with g k k
  · omega
  · simp
  · simp [mul_comm]
  · simp only [zero_add]
    positivity

theorem full_square {l r h a : ℝ} (lp : 0 < l) (rp : 0 < r) (hp : 0 < h)
    {ε : ℝ} (ep : 0 < ε) :
    ∀ᶠ x : ℝ in atTop, mass x l r h a ≤ h^2/(l*r) + ε := by
  have lim := (tendsto_band lp hp.le).mul (tendsto_band rp hp.le)
  have nn : 0 ≤ ∫ t in r..r+h, 1/t := le_of_tendsto_of_tendsto' tendsto_const_nhds
    (tendsto_band rp hp.le) (fun _ => Finset.sum_nonneg (fun p _ => inv_nonneg.mpr (Nat.cast_nonneg p)))
  have bound := mul_le_mul (int_const_le lp hp.le) (int_const_le rp hp.le) nn (div_nonneg hp.le lp.le)
  rw [div_mul_div_comm,←sq] at bound
  filter_upwards [lim.eventually_le_const (bound.trans_lt (lt_add_of_pos_right _ ep))] with x z
  exact (square_bounds ..).trans z

theorem diagonal_square {l h a : ℝ} (lp : 0 < l) (hp : 0 < h)
    {ε : ℝ} (ep : 0 < ε) :
    ∀ᶠ x : ℝ in atTop, mass x l l h a ≤ h^2/(2*l*l) + ε := by
  have lim := (tendsto_band lp hp.le).pow 2
  have nn : 0 ≤ ∫ t in l..l+h, 1/t := le_of_tendsto_of_tendsto' tendsto_const_nhds
    (tendsto_band lp hp.le) (fun _ => Finset.sum_nonneg (fun p _ => inv_nonneg.mpr (Nat.cast_nonneg p)))
  have bound := pow_le_pow_left₀ nn (int_const_le lp hp.le) 2
  filter_upwards [lim.eventually_le_const (bound.trans_lt (lt_add_of_pos_right _ (by positivity : 0<2*ε)))] with x z
  have s := symmetry_bound x l h a
  change _ ≤ (h/l)^2+2*ε at z
  rw [show (h/l)^2=2*(h^2/(2*l*l)) by ring] at z
  linarith

theorem empty_mass {x l r h a : ℝ} (hx : 1 < x) (cut : a ≤ l+r) :
    mass x l r h a = 0 := by
  apply Finset.sum_eq_zero
  intro v hv
  obtain ⟨inBin,_,top⟩ := Finset.mem_filter.mp hv
  obtain ⟨p,q⟩ := Finset.mem_product.mp inBin
  have lo := mul_le_mul (band_mem.mp p).2.1 (band_mem.mp q).2.1
    (Real.rpow_nonneg (zero_lt_one.trans hx).le _) (Nat.cast_nonneg _)
  rw [← Real.rpow_add (zero_lt_one.trans hx)] at lo
  have bad := (Real.rpow_le_rpow_of_exponent_le hx.le cut).trans lo
  exact False.elim (not_lt_of_ge bad (by simpa using top))

def edge (a : ℝ) (i : Fin 72) := EventBins.lower a + (i.val:ℝ)*EventBins.width a

/-- This is the positive-part formula used by the exact price checker. -/
def clippedArea (v h : ℝ) :=
  ((max 0 v)^2 - 2*(max 0 (v-h))^2 + (max 0 (v-2*h))^2)/2

def price (a : ℝ) (i j : Fin 72) :=
  clippedArea (a-edge a i-edge a j) (EventBins.width a) /
    (edge a i*edge a j*(if i=j then 2 else 1))

theorem archived_pair_mass {a ε : ℝ} (lo : 0 < EventBins.lower a)
    (hw : 0 < EventBins.width a) (ep : 0 < ε) (i j : Fin 72) :
    ∀ᶠ x : ℝ in atTop, mass x (edge a i) (edge a j) (EventBins.width a) a ≤
      price a i j + ε := by
  let h := EventBins.width a
  let l := edge a i
  let r := edge a j
  have hl : 0 < l := add_pos_of_pos_of_nonneg lo (mul_nonneg (Nat.cast_nonneg _) hw.le)
  have hr : 0 < r := add_pos_of_pos_of_nonneg lo (mul_nonneg (Nat.cast_nonneg _) hw.le)
  have hpos : 0 < h := hw
  have eq : a-l-r = (108-(i.val+j.val:ℝ))*h := by
    dsimp [l,r,h,edge,EventBins.lower,EventBins.width]
    ring
  change ∀ᶠ x : ℝ in atTop, mass x l r h a ≤ clippedArea (a-l-r) h /
    (l*r*(if i=j then 2 else 1)) + ε
  by_cases empty : 108 ≤ i.val+j.val
  · have e : 108 ≤ (i.val+j.val:ℝ) := by exact_mod_cast empty
    have z : a-l-r ≤ 0 := eq.trans_le (mul_nonpos_of_nonpos_of_nonneg (by linarith) hw.le)
    simp only [clippedArea,max_eq_left z,max_eq_left (show a-l-r-h ≤ 0 by linarith),
      max_eq_left (show a-l-r-2*h ≤ 0 by linarith)]
    filter_upwards [eventually_gt_atTop (1:ℝ)] with x hx
    rw [empty_mass hx (by linarith)]
    simpa using ep.le
  by_cases half : i.val+j.val=107
  · have e : (i.val+j.val:ℝ)=107 := by exact_mod_cast half
    have z : a-l-r=h := by rw [eq,e]; ring
    have ij : i≠j := by rintro rfl; omega
    have ar : clippedArea (a-l-r) h = h^2/2 := by
      rw [z,clippedArea,max_eq_right hw.le,sub_self,max_self,
        max_eq_left (show h-2*h ≤ 0 by linarith)]
      ring
    rw [ar,ite_eq_right ij,mul_one]
    have cut : a=l+r+h := by linarith
    rw [cut]
    rw [show h^2/2/(l*r) = h^2/(2*l*r) by ring]
    exact half_square hl hr hpos ep
  have e : i.val+j.val ≤ 106 := by omega
  have e' : (i.val+j.val:ℝ) ≤ 106 := by exact_mod_cast e
  have z : 2*h ≤ a-l-r := by rw [eq]; exact mul_le_mul_of_nonneg_right (by linarith) hw.le
  have ar : clippedArea (a-l-r) h = h^2 := by
    rw [clippedArea,max_eq_right (by linarith),max_eq_right (by linarith),max_eq_right (by linarith)]
    ring
  rw [ar]
  by_cases ij : i=j
  · have same : r=l := congrArg (edge a) ij.symm
    rw [same,ite_eq_left ij]
    rw [show l*l*2 = 2*l*l by ring]
    exact diagonal_square hl hpos ep
  · rw [ite_eq_right ij,mul_one]
    exact full_square hl hr hpos ep

def marks (x a : ℝ) (i j : Fin 72) : Finset ℕ :=
  (pairBin x (edge a i) (edge a j) (EventBins.width a) a).image (fun v => v.1*v.2)

theorem mark_mass_eq (x a : ℝ) (i j : Fin 72) :
    (∑ m ∈ marks x a i j, (m:ℝ)⁻¹) = mass x (edge a i) (edge a j) (EventBins.width a) a := by
  let S := pairBin x (edge a i) (edge a j) (EventBins.width a) a
  have iffPrime (v : ℕ × ℕ) (hv : v ∈ S) : v.1.Prime ∧ v.2.Prime ∧ v.1<v.2 := by
    obtain ⟨both,lt,_⟩ := Finset.mem_filter.mp hv
    obtain ⟨p,q⟩ := Finset.mem_product.mp both
    exact ⟨(band_mem.mp p).1,(band_mem.mp q).1,lt⟩
  have inj : Set.InjOn (fun v : ℕ × ℕ => v.1*v.2) S := by
    rintro ⟨p,q⟩ pq ⟨s,t⟩ st eq
    obtain ⟨pp,qp,lt⟩ := iffPrime _ pq
    obtain ⟨sp,tp,lt'⟩ := iffPrime _ st
    change p*q=s*t at eq
    have dvd : p ∣ s*t := eq ▸ dvd_mul_right _ _
    rcases pp.dvd_mul.mp dvd with h|h
    · have same : p=s := (Nat.prime_dvd_prime_iff_eq pp sp).mp h
      subst s
      exact Prod.ext rfl (Nat.eq_of_mul_eq_mul_left pp.pos eq)
    · have same : p=t := (Nat.prime_dvd_prime_iff_eq pp tp).mp h
      subst t
      have qs : q=s := Nat.eq_of_mul_eq_mul_left pp.pos (eq.trans (mul_comm _ _))
      change p<q at lt
      change s<p at lt'
      omega
  change (∑ m ∈ S.image (fun z : ℕ × ℕ => (z.1*z.2:ℕ)), (m:ℝ)⁻¹) = ∑ v ∈ S, weight v
  rw [Finset.sum_image inj]
  simp [weight,mul_comm]

theorem pair_mark_witness {x a : ℝ} {n : ℕ} (hx : 1 < x) (f : EventBins.FiveFactors x a n)
    (box : EventBins.Box a (fun j => Real.logb x (f.p j))) {j k : Fin 5} (lt : j<k) :
    f.p j*f.p k ∈ marks x a (box.bin j) (box.bin k) ∧ f.p j*f.p k ∣ n := by
  have inBand (i : Fin 5) : f.p i ∈ band x (edge a (box.bin i)) (edge a (box.bin i)+EventBins.width a) := by
    have pp : 0 < (f.p i:ℝ) := Nat.cast_pos.mpr (f.prime i).pos
    obtain ⟨lo,hi⟩ := box.inside i
    apply band_mem.mpr
    refine ⟨f.prime i,(Real.le_logb_iff_rpow_le hx pp).mp lo,(Real.logb_lt_iff_lt_rpow hx pp).mp ?_⟩
    simpa [edge,add_mul,add_assoc] using hi
  have jle : j ≤ 3 := by omega
  have kle : k ≤ 4 := Fin.le_last _
  have pm (s t : Fin 5) (le : s≤t) : Real.logb x (f.p s) ≤ Real.logb x (f.p t) :=
    (Real.logb_le_logb_of_le hx (Nat.cast_pos.mpr (f.prime s).pos) (Nat.cast_le.mpr (f.ordered.monotone le)))
  have u := (add_le_add (pm _ _ jle) (pm _ _ kle)).trans_lt f.cap
  have qp (i : Fin 5) : 0 < (f.p i:ℝ) := Nat.cast_pos.mpr (f.prime i).pos
  rw [← Real.logb_mul (qp j).ne' (qp k).ne'] at u
  refine ⟨Finset.mem_image.mpr ⟨(f.p j,f.p k),Finset.mem_filter.mpr
    ⟨Finset.mem_product.mpr ⟨inBand j,inBand k⟩,f.ordered lt,?_⟩,rfl⟩,f.pair_dvd lt⟩
  simpa using (Real.logb_lt_iff_lt_rpow hx (mul_pos (qp j) (qp k))).mp u

theorem mark_size {x a : ℝ} (hx : 1 < x) (i j : Fin 72) {m : ℕ} (hm : m ∈ marks x a i j) :
    (m:ℝ) < x^(min a (edge a i+edge a j+2*EventBins.width a)) := by
  obtain ⟨⟨p,q⟩,pq,rfl⟩ := Finset.mem_image.mp hm
  obtain ⟨bpq,_,cut⟩ := Finset.mem_filter.mp pq
  obtain ⟨bp,bq⟩ := Finset.mem_product.mp bpq
  have top := mul_lt_mul_of_pos_right (band_mem.mp bp).2.2
    (Nat.cast_pos.mpr (band_mem.mp bq).1.pos : 0 < (q:ℝ))
  have top' := top.trans (mul_lt_mul_of_pos_left (band_mem.mp bq).2.2
    (Real.rpow_pos_of_pos (zero_lt_one.trans hx) _))
  have eq : x^(edge a i+EventBins.width a)*x^(edge a j+EventBins.width a) =
      x^(edge a i+edge a j+2*EventBins.width a) := by
    rw [←Real.rpow_add (zero_lt_one.trans hx)]
    congr 1
    ring
  rw [eq] at top'
  rcases le_total a (edge a i+edge a j+2*EventBins.width a) with le|le
  · simpa [min_eq_left le] using cut
  · simpa [min_eq_right le] using top'

theorem price_nonneg {a : ℝ} (lo : 0 < EventBins.lower a) (hw : 0 < EventBins.width a)
    (i j : Fin 72) : 0 ≤ price a i j := by
  by_contra! neg
  obtain ⟨x,z⟩ := (archived_pair_mass lo hw (show 0 < -(price a i j)/2 by linarith) i j).exists
  have nn : 0 ≤ mass x (edge a i) (edge a j) (EventBins.width a) a :=
    Finset.sum_nonneg (fun v _ => mul_nonneg (inv_nonneg.mpr (Nat.cast_nonneg _))
      (inv_nonneg.mpr (Nat.cast_nonneg _)))
  linarith

#print axioms archived_pair_mass
#print axioms mark_mass_eq
#print axioms pair_mark_witness
end PrimeGap180.ClippedPair
