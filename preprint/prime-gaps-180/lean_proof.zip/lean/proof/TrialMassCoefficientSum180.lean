import TrialEndpointShapeTensor180
import TrialPairCoefficientSum180

/-! Each ordinary cap increment contracts 99 signed radial fields against
the factored 39-site kernel, retaining all 9,801 ordered cross-products. -/
noncomputable section
open scoped Classical BigOperators Polynomial
open PrimeGap180.PackedLaw PrimeGap180.PackedSingleFields PrimeGap180.FrozenChannels
open PrimeGap180.NativePairTicks PrimeGap180.FrozenProfile PrimeGap180.FullNativeTicks
namespace PrimeGap180.MassCoefficientSum
set_option maxRecDepth 6500
set_option maxHeartbeats 1200000

private def gate (g : Grid) (c : Hist) (J : ℕ) (t : Fin 39 → Tick) : ℝ :=
  if (∑ i,(t i).val)=J then ∏ i,PairMomentPolynomial.site g c (t i) else 0

private theorem prod_site (g : Grid) (c : Hist) (t : Fin 39 → Tick) :
    (∏ i,PairMomentPolynomial.site g c (t i))=
      100^39*(∏ i,w g c (t i))*(∏ i,siteFactor (center (t i).val))^2 := by
  simp only [PairMomentPolynomial.site,Finset.prod_mul_distrib,Finset.prod_const,
    Finset.card_univ,Fintype.card_fin,Finset.prod_pow]

private theorem picked (g : Grid) (c : Hist) (J : ℕ) (s u : FullNativeTicks.Key) :
    (∑ t : Fin 39 → Tick,gate g c J t*angular s (fun i => (t i).val)*angular u (fun i => (t i).val))=
      (EndpointShapeTensor.tensor g c s u).coeff J := by
  rw [←EndpointShapeTensor.factor]
  simp only [EndpointShapeTensor.orig,EndpointShapeTensor.sumValue_def,EndpointShapeTensor.fullTerm,Polynomial.finsetSum_coeff,Polynomial.coeff_monomial]
  apply Finset.sum_congr rfl
  intro t _
  unfold gate
  split <;> simp

theorem gram (g : Grid) (c : Hist) (J k : ℕ) :
    100^39*NativeRadialMass.fullGram g c J k=
      ∑ s,∑ u,radialField J k s*radialField J k u*(EndpointShapeTensor.tensor g c s u).coeff J := by
  rw [FullNativeTicks.gram]
  calc
    _ = ∑ t : Fin 39 → Tick,gate g c J t*
        (∑ s,radialField J k s*angular s (fun i => (t i).val))^2 := by
      unfold full
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro t _
      unfold gate FullNativeTicks.val
      by_cases yes : (∑ i,(t i).val)=J
      · rw [ite_eq_left yes,ite_eq_left yes,prod_site]
        ring
      · simp [yes]
    _ = _ := by rw [PairCoefficientSum.square]; simp only [picked]

private theorem symmetric (g : Grid) (c : Hist) (J : ℕ) (s t : FullNativeTicks.Key) :
    (EndpointShapeTensor.tensor g c s t).coeff J=(EndpointShapeTensor.tensor g c t s).coeff J := by
  rw [←picked,←picked]
  apply Finset.sum_congr rfl
  intro x _
  ring

theorem cap (g : Grid) (c : Hist) : RoundedCaps.m g c =
    ∑ j : Tick,∑ s : FullNativeTicks.Key,∑ t : FullNativeTicks.Key,
      (radialField j.val c.val s-radialField j.val (c.val+1) s)*
      (radialField j.val c.val t+radialField j.val (c.val+1) t)*(EndpointShapeTensor.tensor g c s t).coeff j.val := by
  unfold RoundedCaps.m
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro j _
  rw [mul_sub,gram,gram,PairCoefficientSum.difference _ _ _ (symmetric g c j.val)]

#print axioms gram
#print axioms cap
end PrimeGap180.MassCoefficientSum
