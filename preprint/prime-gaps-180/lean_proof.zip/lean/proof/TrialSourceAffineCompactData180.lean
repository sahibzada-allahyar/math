import TrialSourceAffineMask180
import Lean.Elab.Command
import Lean.ToExpr

/-! The original signed matrix rows and their zero masks, in the same
little-endian two's-complement format as the frozen ledger. Each row is two
kernel numerals regardless of its number of zero entries. -/
namespace PrimeGap180.SourceAffine.Compact

private def readWord (bytes : ByteArray) (start count : Nat) : Nat := Id.run do
  let mut value := 0
  for j in [:count] do
    let off := start+8*(count-1-j)
    let mut lane := 0
    for b in [:8] do
      lane := (lane <<< 8) + (bytes[off+7-b]!).toNat
    value := (value <<< 64)+lane
  return value

open Lean Elab Term in
elab "sourceAffineCompact%" : term => do
  let dir := (System.FilePath.mk (← getFileName)).parent.getD "."
  let input := dir / "../minorants/data/ml12_w25.json.gz"
  IO.FS.withTempDir fun tmp => do
    let file := tmp / "words"
    let proc ← IO.Process.output {cmd := "python3", args := #[(dir / "read_source_affine_rows.py").toString,input.toString,file.toString,"compact"]}
    if proc.exitCode != 0 || proc.stdout.trimAscii.toString != "0eaa32fe71d1daab20f8de453c0094b8a1a131140260f3151e4aa65184c8483b" then
      throwError "unexpected signed matrix input {proc.stderr}"
    let bytes ← IO.FS.readBinFile file
    unless bytes.size == 14*445*(8*445+56) do throwError "wrong affine row volume"
    let rows := (Array.range 14).map fun k => ((Array.range 445).map fun g =>
      let o := (445*k+g)*(8*445+56)
      (readWord bytes o 445,readWord bytes (o+8*445) 7)).toList
    return toExpr rows.toList

noncomputable section
set_option maxHeartbeats 100000000
set_option maxRecDepth 100000 in
private def words : List (List (Nat × Nat)) := sourceAffineCompact%

def pair (k g : Nat) : Nat × Nat := ((words[k]?.getD [])[g]?).getD (0,0)

def matrix (k g h : Nat) : Int := entry (pair k (min g h)).1 (max g h)

def forbidden (k g h : Nat) : Prop := (pair k (min g h)).2.testBit (max g h) = true

instance (k g h : Nat) : Decidable (forbidden k g h) := by unfold forbidden; infer_instance

def check (r : Nat × Nat) := (r.1 &&& expand 445 r.2) == 0

def rowCheck (k : Nat) := (words[k]?.getD []).all check

private theorem count : words.length = 14 := by decide +kernel

theorem beyond (k : Nat) (late : 14 ≤ k) : rowCheck k = true := by
  have past : words.length ≤ k := by rw [count]; exact late
  rw [rowCheck,List.getElem?_eq_none past]
  rfl

attribute [local irreducible] words

theorem disjoint_row {k : Nat} (yes : rowCheck k = true) (g : Nat) :
    (pair k g).1 &&& expand 445 (pair k g).2 = 0 := by
  cases a : words[k]? with
  | none => simp [pair,a]
  | some rows =>
    cases b : rows[g]? with
    | none => simp [pair,a,b]
    | some r =>
      have valid : rows.all check = true := by simpa only [rowCheck,a,Option.getD_some] using yes
      have cr := List.all_eq_true.mp valid _ (List.mem_of_getElem? b)
      simpa [pair,a,b,check] using cr

end
end PrimeGap180.SourceAffine.Compact
