import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G100
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 100

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G100

namespace PrimeGap180.PriceIsolatedGroup.G105
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 105

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G105

namespace PrimeGap180.PriceIsolatedGroup.G110
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 110

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G110

namespace PrimeGap180.PriceIsolatedGroup.G115
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 115

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G115
