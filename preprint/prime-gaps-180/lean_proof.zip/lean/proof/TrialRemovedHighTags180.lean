import TrialRemovedLowProjection180

/-! An actual high-edge deletion of the frozen trial retains at least two
large physical marks and the full configuration contains exactly two.
The mark index remembers its site, including repeated owners. -/
noncomputable section
open scoped Classical BigOperators ENNReal
open MeasureTheory PrimeGap186 PrimeGap180.Sector PrimeGap180.FrozenProfile
open PrimeGap180.GateDeletion
namespace PrimeGap180.RemovedHighTags

def cutoff : ℝ := 940000/Lookup.ticks
private theorem pos : 0<cutoff := by norm_num [cutoff,Lookup.ticks]
private theorem zero_pos : 0<Lookup.ticks := by norm_num [Lookup.ticks]

open private original_room from TrialGateDeletion180

theorem full_room (v : Full) (nonzero : original v ≠ 0) : Lookup.total v < 3*cutoff := by
  have h := original_room v nonzero
  change (2624989/10000000:ℝ)*Lookup.total v ≤ _ at h
  unfold cutoff Lookup.ticks
  linarith only [h]

/-- The Poisson representation that appears directly under the disintegrated
physical integral; its index n at each site is an actual mark count. -/
def state (Y : Fin 39 → FiniteMeasure ℝ) (n : Fin 39 → ℕ)
    (x : (i : Fin 39) → Fin (n i) → ℝ) : Full :=
  fun i=>fragmentBandMasses FrozenData.mesh (Y i + weightedEmpirical _ (x i))

private theorem suffix_tags (Y : FiniteMeasure ℝ) (n : ℕ) (x : Fin n → ℝ)
    (hY : Y.restrict (Set.Ioc 0 cutoff)=Y) (hx : ∀ a,cutoff<x a ∧ x a≤cap)
    (j : Fin 217) (edge : cutoff≤FrozenData.mesh j.castSucc) :
    NativeSiteLaw.tail j (fragmentBandMasses FrozenData.mesh (Y+weightedEmpirical n x)) =
      ∑ a, if FrozenData.mesh j.castSucc<x a then x a else 0 := by
  have mono : Monotone FrozenData.mesh := FrozenData.tables.ordered.monotone
  have last : FrozenData.mesh (Fin.last 217)=cap := FrozenData.tables.last
  rw [NativeSiteLaw.tail,trial_band_tail_eq FrozenData.mesh mono,
    last,trial_finite_tail_measureReal _ cutoff x
      (trial_finite_tail_coordinate_mass _ _ _ _ hY fun a=>(hx a).1)
      (fun a=>pos.le.trans (hx a).1.le) _ measurableSet_Ioc (fun p h=>edge.trans_lt h.1)]
  simp only [Set.mem_Ioc]
  exact Finset.sum_congr rfl (fun a _=>by simp [(hx a).2])

private def firstHigh : Active := 99

set_option maxRecDepth 65536 in
private theorem firstHigh_cut : FrozenData.mesh (T.tailEdge firstHigh).castSucc=cutoff := by
  have atEdge := RemovalEdgeBook.ticks_eq firstHigh
  have eq : RemovalEdgeBook.lowerNat firstHigh=940000 := by decide +kernel
  rw [eq] at atEdge
  unfold cutoff
  exact (eq_div_iff zero_pos.ne').mpr (by simpa [mul_comm] using atEdge)

open private least_spec from TrialStructuralGate180

private theorem cap_bit (v : Full) (i : Fin 39) (r : Receipt)
    (chosen : select T (bits T (i.removeNth v))=some r) :
    Lookup.suffix (i.removeNth v) (T.capEdge r.fine) < FrozenData.mesh (T.capEdge r.fine).castSucc/2 := by
  have bit := (least_spec (EarlyFailure.source_cap _ r chosen)).1
  change (if _<_ then true else false)=true at bit
  split at bit <;> first | assumption | contradiction

theorem two_tags (Y : Fin 39 → FiniteMeasure ℝ) (n : Fin 39 → ℕ)
    (x : (i : Fin 39) → Fin (n i) → ℝ)
    (hY : ∀ i,(Y i).restrict (Set.Ioc 0 cutoff)=Y i) (hx : ∀ i a,cutoff<x i a ∧ x i a≤cap)
    (nz : original (state Y n x)≠0)
    (owned : owner (encode (state Y n x))=some (.group 23)) : ∑ i,n i=2 := by
  let v := state Y n x
  have nn (i : Fin 39) (j : Fin 217) : 0≤v i j := NNReal.zero_le_coe
  obtain ⟨e,⟨i,r,sel,bad,_⟩,group,_⟩ := group_highest _ _ owned
  have edge : cutoff ≤ FrozenData.mesh (T.tailEdge e).castSucc := by
    apply (div_le_iff₀ zero_pos).mpr
    rw [mul_comm,RemovalEdgeBook.ticks_eq]
    exact_mod_cast (RemovalEdgeBook.high e).mp group
  let C := FrozenData.mesh (T.capEdge r.fine).castSucc
  have cpos : 0<C := T.capPos _
  have capPass := cap_bit v i r sel
  have price := (RemovedLowProjection.threshold_bounds r (receipt_data T _ r sel).2.2 e).2
  have capGate : Lookup.ticks*C ≤ T.gate r.key e := (Nat.le_ceil _).trans (Nat.cast_le.mpr price)
  have hit : (T.gate r.key e:ℝ)<Lookup.ticks*Lookup.suffix (i.removeNth v) (T.tailEdge e) := by
    change (if -Lookup.ticks*Lookup.suffix (i.removeNth v) (T.tailEdge e) < -(T.gate r.key e:ℝ) then true else false)=true at bad
    split at bad
    next h => simpa only [neg_mul,neg_lt_neg_iff] using h
    next => exact (Bool.false_ne_true bad).elim
  have ex : C < Lookup.suffix (i.removeNth v) (T.tailEdge e) :=
    lt_of_mul_lt_mul_left (capGate.trans_lt hit) zero_pos.le
  have before : T.tailEdge e < T.capEdge r.fine := by
    by_contra! reverse
    have h := Lookup.suffix_antitone (i.removeNth v) (fun j k=>nn (i.succAbove j) k) reverse
    change Lookup.suffix (i.removeNth v) (T.capEdge r.fine)<C/2 at capPass
    linarith only [ex,capPass,h,cpos]
  have ge : cutoff≤C := edge.trans (T.ordered.monotone ((Fin.castSucc_lt_castSucc_iff.mpr before).le))
  have capped (j : Fin 38) (a : Fin (n (i.succAbove j))) : x (i.succAbove j) a≤C := by
    by_contra! large
    have within : NativeSiteLaw.tail (T.capEdge r.fine) (v (i.succAbove j)) ≤ Lookup.suffix (i.removeNth v) (T.capEdge r.fine) :=
      Finset.single_le_sum (fun h _=>Finset.sum_nonneg (fun k _=>nn (i.succAbove h) k)) (Finset.mem_univ j)
    change NativeSiteLaw.tail _ (fragmentBandMasses _ (_+weightedEmpirical _ _))≤_ at within
    rw [suffix_tags _ _ _ (hY _) (hx _) _ ge] at within
    have nonnegative (t : Fin (n (i.succAbove j))) : 0≤(if C<x (i.succAbove j) t then x (i.succAbove j) t else 0) := by
      split <;> first | exact pos.le.trans (hx _ _).1.le | exact le_rfl
    have each := Finset.single_le_sum (fun t _=>nonnegative t) (Finset.mem_univ a)
    rw [ite_eq_left large] at each
    change (∑ t, if C<x (i.succAbove j) t then x (i.succAbove j) t else 0)≤_ at within
    change Lookup.suffix (i.removeNth v) (T.capEdge r.fine)<C/2 at capPass
    linarith only [within,each,capPass,large,cpos]
  have per (j : Fin 38) : NativeSiteLaw.tail (T.tailEdge e) (v (i.succAbove j)) ≤ (n (i.succAbove j):ℝ)*C := by
    change NativeSiteLaw.tail _ (fragmentBandMasses _ (_+weightedEmpirical _ _))≤_
    rw [suffix_tags _ _ _ (hY _) (hx _) _ edge]
    calc
      _ ≤ ∑ _ : Fin (n (i.succAbove j)), C := Finset.sum_le_sum (fun a _=>by split <;> first | exact capped j a | exact cpos.le)
      _ = _ := by simp
  have lower := Finset.sum_le_sum (s:=Finset.univ) (fun j _=>per j)
  change Lookup.suffix (i.removeNth v) (T.tailEdge e) ≤ _ at lower
  rw [←Finset.sum_mul,←Nat.cast_sum] at lower
  have erased : 1 < ∑ j,n (i.succAbove j) := by
    by_contra! small
    have one : ((∑ j,n (i.succAbove j):ℕ):ℝ)≤1 := by exact_mod_cast small
    have contradiction := mul_le_mul_of_nonneg_right one cpos.le
    linarith only [ex,lower,contradiction]
  have root : 2 ≤ ∑ j,n j := by rw [Fin.sum_univ_succAbove n i]; omega
  have total (j : Fin 39) : (n j:ℝ)*cutoff ≤ ∑ k,v j k := by
    calc
      _ = ∑ _ : Fin (n j),cutoff := by simp
      _ ≤ ∑ a,x j a := Finset.sum_le_sum (fun a _=>(hx j a).1.le)
      _ = NativeSiteLaw.tail (T.tailEdge firstHigh) (v j) := by
        change _=NativeSiteLaw.tail _ (fragmentBandMasses _ (_+weightedEmpirical _ _))
        rw [suffix_tags _ _ _ (hY j) (hx j) _ firstHigh_cut.ge,firstHigh_cut]
        exact Finset.sum_congr rfl (fun a _=>(ite_eq_left (hx j a).1).symm)
      _ ≤ _ := Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _) (fun k _ _=>nn j k)
  have all := Finset.sum_le_sum (s:=Finset.univ) (fun j _=>total j)
  rw [←Finset.sum_mul,←Nat.cast_sum] at all
  have up := full_room v nz
  change _≤Lookup.total v at all
  have three : (((∑ j,n j):ℕ):ℝ)<3 := lt_of_mul_lt_mul_right (all.trans_lt up) pos.le
  have : (∑ j,n j)<3 := by exact_mod_cast three
  omega

/-- Both tags pay their individual lower native indices even when the same
site owns them. This is the second lower endpoint of the tagged Gram panels. -/
theorem tag_indices (Y : Fin 39 → FiniteMeasure ℝ) (n : Fin 39 → ℕ)
    (x : (i : Fin 39) → Fin (n i) → ℝ)
    (hY : ∀ i,(Y i).restrict (Set.Ioc 0 cutoff)=Y i) (hx : ∀ i a,cutoff<x i a ∧ x i a≤cap) :
    (∑ i,∑ a, ⌊x i a/Native.step⌋₊) ≤ Native.cellSum (state Y n x) := by
  have step : 0<Native.step := by norm_num [Native.step]
  apply Finset.sum_le_sum
  intro i _
  have total : (∑ a,x i a) ≤ ∑ k,state Y n x i k := by
    calc
      _ = NativeSiteLaw.tail (T.tailEdge firstHigh) (state Y n x i) := by
        change _=NativeSiteLaw.tail _ (fragmentBandMasses _ (_+weightedEmpirical _ _))
        rw [suffix_tags _ _ _ (hY i) (hx i) _ firstHigh_cut.ge,firstHigh_cut]
        exact Finset.sum_congr rfl (fun a _=>(ite_eq_left (hx i a).1).symm)
      _ ≤ _ := Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _) (fun _ _ _=>NNReal.zero_le_coe)
  apply Nat.le_floor
  apply (le_div_iff₀ step).mpr
  rw [Nat.cast_sum,Finset.sum_mul]
  exact (Finset.sum_le_sum (fun a _=>
    (le_div_iff₀ step).mp (Nat.floor_le (div_nonneg (pos.le.trans (hx i a).1.le) step.le)))).trans total

/-- Above the high cutoff, the largest stored tag determines the full
physical cap bit exactly, prior to choosing the native spline suffix. -/
theorem tagged_cap (Y : Fin 39 → FiniteMeasure ℝ) (n : Fin 39 → ℕ)
    (x : (i : Fin 39) → Fin (n i) → ℝ)
    (hY : ∀ i,(Y i).restrict (Set.Ioc 0 cutoff)=Y i) (hx : ∀ i a,cutoff<x i a ∧ x i a≤cap)
    (c : Fine) (ge : cutoff≤FrozenData.mesh (T.capEdge c).castSucc) :
    bits T (state Y n x) (.cap c)=true ↔ ∀ i a,x i a≤FrozenData.mesh (T.capEdge c).castSucc := by
  let C:=FrozenData.mesh (T.capEdge c).castSucc
  have cpos : 0<C:=T.capPos _
  have site (i) : NativeSiteLaw.tail (T.capEdge c) (state Y n x i) = ∑ a, if C<x i a then x i a else 0 :=
    suffix_tags _ _ _ (hY i) (hx i) _ ge
  have full : Lookup.suffix (state Y n x) (T.capEdge c) = ∑ i,∑ a,if C<x i a then x i a else 0 :=
    Finset.sum_congr rfl (fun i _=>site i)
  change (if Lookup.suffix (state Y n x) (T.capEdge c)<C/2 then true else false)=true ↔ _
  rw [full]
  constructor
  · intro ok i a
    have small : (∑ j,∑ t,if C<x j t then x j t else 0)<C/2 := by split at ok <;> first | assumption | contradiction
    by_contra! bad
    have nn (j) (t) : 0≤(if C<x j t then x j t else 0) := by
      split <;> first | exact pos.le.trans (hx _ _).1.le | exact le_rfl
    have one := Finset.single_le_sum (fun t _=>nn i t) (Finset.mem_univ a)
    rw [ite_eq_left bad] at one
    have two := Finset.single_le_sum (f:=fun j=>∑ t,if C<x j t then x j t else 0)
      (fun j _=>Finset.sum_nonneg fun t _=>nn j t) (Finset.mem_univ i)
    linarith only [one,two,bad,cpos,small]
  · intro none
    have off (i) (a) : ¬ C<x i a := (none i a).not_gt
    simp only [off,ite_false,Finset.sum_const_zero]
    exact ite_eq_left (by linarith only [cpos])

#print axioms tag_indices
#print axioms tagged_cap
#print axioms two_tags
end PrimeGap180.RemovedHighTags
