import TrialFrozenData180
import TrialMassSplineSpan180

/-! Cubic spline interpolation about an actual pair of discrete native ticks.
The coefficient list represents a polynomial in the normalized panel
coordinate. Every operation preserves its full polynomial. -/
noncomputable section
open scoped BigOperators
namespace PrimeGap180.EnvelopePolynomial
open FrozenData MassSplineSpan

abbrev Coeffs := List ℚ

def eval (z : ℚ) : Coeffs → ℚ
  | [] => 0
  | a::p => a+z*eval z p

def plus : Coeffs → Coeffs → Coeffs
  | [],q=>q
  | p,[]=>p
  | a::p,b::q=>(a+b)::plus p q

def times (c : ℚ) (p : Coeffs) := p.map (c*·)
def affine (c m : ℚ) (p : Coeffs) := plus (times c p) (0::times m p)

theorem plus_eval (z : ℚ) (p q : Coeffs) : eval z (plus p q)=eval z p+eval z q := by
  induction p generalizing q with
  | nil=>simp [plus,eval]
  | cons a p ih=>cases q with
    | nil=>simp [plus,eval]
    | cons b q=>simp [plus,eval,ih]; ring

theorem times_eval (z c : ℚ) (p : Coeffs) : eval z (times c p)=c*eval z p := by
  induction p with
  | nil=>simp [times,eval]
  | cons a p ih=>change c*a+z*eval z (times c p) = c*(a+z*eval z p); rw [ih]; ring

theorem affine_eval (z c m : ℚ) (p : Coeffs) : eval z (affine c m p)=(c+m*z)*eval z p := by
  simp only [affine,plus_eval,times_eval,eval,zero_add]
  ring

structure Panel where
  lo : ℕ
  hi : ℕ
  span : ℕ
  deriving DecidableEq, Repr

def left (p : Panel) := sample p.lo
def right (p : Panel) := sample p.hi
def width (p : Panel) := right p-left p

/-- Exact recursive power coefficients of the original Cox–de Boor basis,
with the same convention for repeated knots as the frozen implementation. -/
def basis (p : Panel) : ℕ  →  ℕ  →  Coeffs
  | 0,i=> [if i=p.span then 1 else 0]
  | d+1,i=>
    plus (times ((knot (i+d+1)-knot i)⁻¹) (affine (left p-knot i) (width p) (basis p d i)))
      (times ((knot (i+d+2)-knot (i+1))⁻¹) (affine (knot (i+d+2)-left p) (-width p) (basis p d (i+1))))

theorem basis_eval (p : Panel) (z : ℚ) (d i : ℕ) :
    eval z (basis p d i)=(piece p.span d i).eval (left p+width p*z) := by
  induction d generalizing i with
  | zero => by_cases h : i=p.span <;> simp [basis,eval,piece,h]
  | succ d ih =>
    simp only [basis,plus_eval,times_eval,affine_eval,piece,Polynomial.eval_add,Polynomial.eval_mul,
      Polynomial.eval_sub,Polynomial.eval_X,Polynomial.eval_C,ih]
    ring

theorem physical (p : Panel) {j : ℕ} (inside : p.lo ≤ j ∧ j ≤ p.hi) (wide : p.lo<p.hi)
    (leftOk : 3 ≤ p.span) (rightOk : p.span<33) (active : knot p.span ≤ left p ∧ right p<knot (p.span+1)) :
    ∃ z : ℚ, 0 ≤ z ∧ z ≤ 1 ∧ ∀ k : Fin 30,splineQ j k=eval z (basis p 3 k.val) := by
  have hL := sample_mono inside.1
  have hR := sample_mono inside.2
  have w : 0<width p := by
    unfold width left right sample
    have jlt : (p.lo:ℚ)<p.hi := by exact_mod_cast wide
    linarith only [jlt]
  let z := (sample j-left p)/width p
  have zz : 0 ≤ z := div_nonneg (sub_nonneg.mpr hL) w.le
  have zo : z ≤ 1 := (div_le_one w).mpr (by exact sub_le_sub_right hR _)
  refine ⟨z,zz,zo,fun k=>?_⟩
  rw [spline_on_span j k p.span leftOk rightOk ⟨active.1.trans hL,hR.trans_lt active.2⟩,basis_eval]
  congr 1
  dsimp [z]
  field_simp [w.ne']
  <;> ring

/-- Range of a power coefficient list on a positive unit interval.
The constant is kept signed. Every later power lies between zero and one. -/
def tailUpper (p : Coeffs) := (p.map (max 0)).sum
def upper : Coeffs → ℚ
  | []=>0
  | a::p=>a+tailUpper p

theorem eval_le (p : Coeffs) {z : ℚ} (hz : 0 ≤ z) (ho : z ≤ 1) : eval z p ≤ upper p := by
  have tail (q : Coeffs) : z*eval z q ≤ tailUpper q := by
    induction q with
    | nil => simp [eval,tailUpper]
    | cons a q ih =>
      have aU : z*a ≤ max 0 a := by
        by_cases pos : 0 ≤ a
        · exact (mul_le_of_le_one_left pos ho).trans (le_max_right _ _)
        · exact (mul_nonpos_of_nonneg_of_nonpos hz (le_of_not_ge pos)).trans (le_max_left _ _)
      have zt : z*(z*eval z q) ≤ tailUpper q :=
        (mul_le_mul_of_nonneg_left ih hz).trans (mul_le_of_le_one_left
          (List.sum_nonneg fun x hx=>by obtain ⟨y,_,rfl⟩:=List.mem_map.mp hx; exact le_max_left _ _) ho)
      simpa [eval,tailUpper,mul_add] using add_le_add aU zt
  cases p with
  | nil=>simp [eval,upper]
  | cons a p=>exact add_le_add le_rfl (tail p)

#print axioms physical
#print axioms eval_le
end PrimeGap180.EnvelopePolynomial
