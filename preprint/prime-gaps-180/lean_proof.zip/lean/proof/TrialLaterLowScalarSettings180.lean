import TrialLaterLowFixedGrid180
import TrialRemovalEdgeBook180
import TrialLaterLowHybrid180

/-! Exact sums and scalar charges, matched to the actual active edge and its
parent cutoff. One charge unit is 10^-18 of the ordinary-mass floor. -/
namespace PrimeGap180.LaterLowFixed
open PrimeGap180.FrozenProfile
structure Row where
  edge : ℕ
  nextEdge : ℕ
  beta : ℕ
  rate : ℕ
  erased : ℕ
  retained : ℕ
  charge : ℕ
  deriving DecidableEq

def row : Fin 9 → Row := ![
    ⟨300,1000,11,49560,7411797029235623657743,755893145071238666868,131228442⟩,
    ⟨1000,3000,11,16450,7411797029235623657743,704208306409935005869,7579163⟩,
    ⟨3000,6000,10,8160,7646734329598192954559,533374366926557773296,53⟩,
    ⟨6000,10000,9,4820,7918053722942522594893,527602194447368498243,7⟩,
    ⟨10000,20000,8,2320,8237619048529054255843,771236886998925253994,1156055⟩,
    ⟨20000,30000,7,1470,8623608190508661477678,839621683219972132321,1818117⟩,
    ⟨30000,40000,6,1050,9105556386512150577812,992918267150902035195,77804134⟩,
    ⟨40000,50000,5,805,9735286871469661665597,1167802882257556116479,3586486591⟩,
    ⟨50000,60000,5,645,9735286871469661665597,1317095709767815766881,106594565674⟩]
def active (i : Fin 9) : Active := ⟨i.val+2,by omega⟩

open Lean
open private scalarText from TrialLaterLowHybrid180
private abbrev Settings := ℕ × ℕ × ℕ × List (ℕ × ℕ × ℕ × ℕ)

private def readSettings : Except String Settings := do
  let j ← Json.parse scalarText
  let grid ← j.getObjValAs? ℕ "gamma_mesh"
  let tail ← j.getObjValAs? ℕ "gamma_stop"
  let A ← j.getObjValAs? ℕ "amplitude_upper"
  let obj ← j.getObjVal? "upper_in_raw_ordinary_norm"
  let mut cases := []
  for i in List.finRange 9 do
    let e := (row i).edge
    let x ← obj.getObjVal? (toString e)
    let n ← x.getObjValAs? ℕ "next_edge"
    let b ← x.getObjValAs? ℕ "beta"
    let r ← x.getObjValAs? ℕ "dust_rate"
    cases := cases ++ [(e,n,b,r)]
  return (grid,tail,A,cases)

open Lean.Elab.Term in
elab "laterLowSettings%" : term => do return toExpr (← IO.ofExcept readSettings)

private def archived : Settings := laterLowSettings%

theorem settings : archived=(100,16,728975,(List.finRange 9).map fun i=>
    ((row i).edge,(row i).nextEdge,(row i).beta,(row i).rate)) := by rfl'

set_option maxHeartbeats 0 in
set_option maxRecDepth 131072 in
theorem aligned : ∀ i : Fin 9,
    RemovalEdgeBook.lowerNat (active i)=(row i).edge ∧
    FrozenData.parentUpperNat (active i)=(row i).nextEdge ∧
    0<(row i).edge ∧ 0<(row i).beta ∧ 0<(row i).rate := by decide +kernel

def totalCharge : ℚ := (∑ i : Fin 9,((row i).charge:ℚ))/10^18
def lastThree : ℚ := ((LaterLowHybrid.rows.filter (fun (e,_,_,_)=>50000<e)).map
  (fun (_,_,_,u)=>u)).sum * 100^39/(94.17312:ℚ)

theorem total_eq : totalCharge=110400638236/10^18 := by decide +kernel

theorem headroom : (28000:ℚ)/10^12 <
    LaterLowHybrid.allowance-(totalCharge+lastThree) := by decide +kernel

#print axioms settings
#print axioms aligned
#print axioms total_eq
#print axioms headroom
end PrimeGap180.LaterLowFixed
