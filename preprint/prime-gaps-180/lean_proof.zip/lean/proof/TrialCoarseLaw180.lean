import TrialRestorationIdentity180
import TrialNativeSiteLaw180
import Mathlib.MeasureTheory.Integral.Bochner.SumMeasure
import Mathlib.MeasureTheory.Function.Floor

/-! Push the uncut continuum spline to finite native index and maximum states.
A signed erasure is integrated in those states before its square is formed. -/
noncomputable section
open scoped Classical BigOperators Topology ENNReal
open MeasureTheory Filter PrimeGap186 PrimeGap180.Sector PrimeGap180.FrozenProfile
namespace PrimeGap180.CoarseLaw

abbrev T := FrozenData.tables
abbrev μ := bandLaw FrozenData.mesh
abbrev B := Band 216
abbrev State := Fin 130966 × (Fine → Bool)
abbrev prod (d : ℕ) := Measure.pi (fun _ : Fin d => μ)
local instance : IsFiniteMeasure μ := bandLaw_finite _

def flag (z : B) (c : Fine) : Bool :=
  if NativeSiteLaw.tail (T.capEdge c) z < FrozenData.mesh (T.capEdge c).castSucc/2 then true else false

def state (z : B) : State := (⟨min (Native.cell z) 130965,by omega⟩,flag z)

theorem state_meas : Measurable state := by
  apply Measurable.prodMk
  · let truncate := fun j : ℕ => (⟨min j 130965,by omega⟩ : Fin 130966)
    change Measurable (truncate ∘ Native.cell)
    apply (measurable_of_countable truncate).comp
    unfold Native.cell
    fun_prop
  · apply measurable_pi_lambda
    intro c
    unfold flag
    apply Measurable.ite _ measurable_const measurable_const
    apply measurableSet_lt _ measurable_const
    unfold NativeSiteLaw.tail
    fun_prop

def law := Measure.map state μ
local instance : IsFiniteMeasure law := Measure.isFiniteMeasure_map _ _
def weight (x : State) := law.real {x}
def array {d : ℕ} (v : Fin d → B) := fun i => state (v i)

private theorem array_meas (d : ℕ) : Measurable (@array d) :=
  measurable_pi_lambda _ fun i => state_meas.comp (measurable_pi_apply i)

theorem push (d : ℕ) : (prod d).map array = Measure.pi (fun _ : Fin d => law) :=
  Measure.pi_map_pi (fun _ => state_meas.aemeasurable)

/-- Actual product integrals, including signed integrands. -/
theorem integral_states {d : ℕ} (F : (Fin d → State) → ℝ) :
    (∫ v,F (array v) ∂prod d) = ∑ x,F x * ∏ i,weight (x i) := by
  let M := Measure.pi (fun _ : Fin d => law)
  have mF : Measurable F := measurable_of_finite F
  have finite : Integrable F M := integrable_of_measurable_of_bounded_range _ _ mF (Set.finite_range F).isBounded
  have map := integral_map (array_meas d).aemeasurable (mF.aestronglyMeasurable (μ := (prod d).map array))
  rw [←map,push,integral_fintype finite]
  apply Finset.sum_congr rfl
  intro x _
  rw [smul_eq_mul,mul_comm]
  congr 1
  simp only [M,measureReal_def,Measure.pi_singleton,ENNReal.toReal_prod,weight]

theorem one_state (F : State → ℝ) : (∫ z,F (state z) ∂μ) = ∑ x,weight x * F x := by
  have mF : Measurable F := measurable_of_finite F
  have int : Integrable F law := integrable_of_measurable_of_bounded_range _ _ mF (Set.finite_range F).isBounded
  rw [←integral_map state_meas.aemeasurable (mF.aestronglyMeasurable (μ := law))]
  change (∫ x,F x ∂law) = _
  rw [integral_fintype int]
  rfl

/-- Finite summed masses for any specified index and cumulative cap below
the sentinel, before forming maximum-class differences. -/
theorem cumulative (k : ℕ) (hk : k < 130965) (c : Fine) :
    (∑ s : State, if s.1.val = k ∧ s.2 c = true then weight s else 0) =
      ((bandLaw FrozenData.mesh) ({z | (k:ℝ)*Native.step ≤ NativeSiteLaw.radial z ∧
       NativeSiteLaw.radial z < ((k:ℝ)+1)*Native.step} ∩ NativeSiteLaw.capped (T.capEdge c))).toReal := by
  let P := fun s : State => s.1.val = k ∧ s.2 c = true
  let S := {s : State | P s}
  have h : MeasurableSet S := Set.Finite.measurableSet (Set.toFinite _)
  have eq := one_state (S.indicator (fun _ => (1:ℝ)))
  have each (s : State) : weight s*S.indicator (fun _ => (1:ℝ)) s = if P s then weight s else 0 := by
    by_cases p : P s <;> simp [S,p]
  change (∑ s : State, if P s then weight s else 0) = _
  rw [← Finset.sum_congr rfl (fun s (_ : s ∈ (Finset.univ : Finset State)) => each s)]
  rw [← eq,show (fun z : B => S.indicator (fun _ => (1:ℝ)) (state z)) =
      (state ⁻¹' S).indicator (fun _ => (1:ℝ)) from rfl,integral_indicator (state_meas h),setIntegral_const,smul_eq_mul,mul_one]
  have nn : ∀ᵐ z ∂μ, 0 ≤ NativeSiteLaw.radial z := by
    apply Measure.ae_smul_measure
    apply (ae_map_iff (measurable_fragmentBandMasses _).aemeasurable
      (measurableSet_le measurable_const (show Measurable NativeSiteLaw.radial by unfold NativeSiteLaw.radial; fun_prop))).mpr
    exact ae_of_all _ fun X => Finset.sum_nonneg (fun _ _ => NNReal.zero_le_coe)
  apply congrArg ENNReal.toReal
  apply measure_congr
  filter_upwards [nn] with z hz
  have pos : 0 < Native.step := by norm_num [Native.step]
  have floor : Native.cell z = k ↔
      (k:ℝ)*Native.step ≤ NativeSiteLaw.radial z ∧ NativeSiteLaw.radial z < ((k:ℝ)+1)*Native.step := by
    change ⌊NativeSiteLaw.radial z/Native.step⌋₊ = k ↔ _
    rw [Nat.floor_eq_iff (div_nonneg hz pos.le),le_div_iff₀ pos,div_lt_iff₀ pos]
  have trunc : min (Native.cell z) 130965 = k ↔ Native.cell z = k := by omega
  have cf : flag z c = true ↔ z ∈ NativeSiteLaw.capped (T.capEdge c) := by
    simp [flag,NativeSiteLaw.capped]
  apply propext
  change (min (Native.cell z) 130965 = k ∧ flag z c = true) ↔ _
  exact and_congr (trunc.trans floor) cf

#print axioms integral_states
#print axioms cumulative
end PrimeGap180.CoarseLaw
