import TrialSixScale180
import TypeIIIFrequencyScale
import TypeIIIResidualInterval
import TypeIIINonzeroSummation

/-! The fourth matrix term through matching, the integer frequency sum,
the dyadic interval comparison, and the shared-factor and gcd sums. -/
noncomputable section
open scoped BigOperators Classical
open PrimeGap182.TypeIII
namespace PrimeGap180.Averaged

def matrixExtra (M R w : ℝ) := M^(3/4 : ℝ) * w^(7/8 : ℝ) / R^(1/2 : ℝ)
def matrixFourScale (M R w : ℝ) := matrixThreeScale M R w + matrixExtra M R w
def sharedFourScale (M R w E : ℝ) :=
  sharedThreeScale M R w E + matrixExtra M R w * E^(1/8 : ℝ)
def dyadicFourScale (M R w : ℝ) := M * R^3 * matrixFourScale M R w
def nonzeroFourSGScale (M R S : ℝ) :=
  nonzeroSGScale M R S + M^(7/4 : ℝ) * (R*S)^(5/2 : ℝ) * S^(3/8 : ℝ)

theorem matrixFourScale_nonneg {M R w : ℝ} (hm : 0 ≤ M) (hr : 0 ≤ R) (hw : 0 ≤ w) :
    0 ≤ matrixFourScale M R w :=
  add_nonneg (matrixThreeScale_nonneg hm hr hw) (by unfold matrixExtra; positivity)

theorem dyadicFourScale_nonneg {M R w : ℝ} (hm : 0 ≤ M) (hr : 0 ≤ R) (hw : 0 ≤ w) :
    0 ≤ dyadicFourScale M R w := mul_nonneg (by positivity) (matrixFourScale_nonneg hm hr hw)

theorem mul_matrixFourScale_eq_sharedFourScale (M R E P : ℝ) (he : 0 < E) (hp : 0 ≤ P) :
    E * matrixFourScale M R P = sharedFourScale M R (E*P) E := by
  unfold matrixFourScale sharedFourScale
  rw [mul_add, mul_matrixThreeScale_eq_sharedThreeScale M R E P he hp]
  congr 1
  have h : E^(7/8 : ℝ) * E^(1/8 : ℝ) = E := by rw [← Real.rpow_add he]; norm_num
  unfold matrixExtra
  rw [Real.mul_rpow he.le hp]
  linear_combination -(M^(3/4 : ℝ)*P^(7/8 : ℝ)/R^(1/2 : ℝ))*h

theorem exists_sharedFourScale_frequency_sum {A ε : ℝ} (hA : 1 < A) (he : 0 < ε) :
    ∃ C : ℝ, 0 < C ∧ ∀ (w : ℕ), 0 < w → ∀ (K M R : ℝ),
      0 < K → 0 ≤ M → 0 ≤ R → ∀ F : Finset ℤ,
      (∑ c ∈ F, (integerFrequencyDecay K⁻¹ A c / K) *
        sharedFourScale M R w (Int.gcd c (w : ℤ))) ≤
        C * (w : ℝ)^ε * matrixFourScale M R w := by
  obtain ⟨C, hc, old⟩ := exists_sharedThreeScale_frequency_sum hA he
  obtain ⟨D, hd, new⟩ := exists_frequencyGCDWeight_subpower hA
    (show (1/8 : ℝ) ≤ 1 by norm_num) he
  refine ⟨max C D, lt_of_lt_of_le hc (le_max_left _ _), ?_⟩
  intro w hw K M R hk hm hr F
  have freq := ((frequencyGCDWeight_tsum w hw hk hA (1/8)).1.sum_le_tsum F
    (fun c _ => frequencyGCDWeight_nonneg w hk A (1/8) c)).trans (new w hw K hk)
  have hu : 0 ≤ matrixExtra M R w := by unfold matrixExtra; positivity
  unfold sharedFourScale matrixFourScale
  simp only [mul_add, Finset.sum_add_distrib]
  apply add_le_add
  · exact (old w hw K M R hk hm hr F).trans
      (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right (le_max_left C D)
        (Real.rpow_nonneg (Nat.cast_nonneg w) _)) (matrixThreeScale_nonneg hm hr (Nat.cast_nonneg w)))
  · calc
      _ = (∑ c ∈ F, frequencyGCDWeight w K A (1/8) c) * matrixExtra M R w := by
        rw [Finset.sum_mul]; apply Finset.sum_congr rfl; intro c _; unfold frequencyGCDWeight; ring
      _ ≤ (D * (w : ℝ)^ε) * matrixExtra M R w := mul_le_mul_of_nonneg_right freq hu
      _ ≤ _ := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right (le_max_right C D)
        (Real.rpow_nonneg (Nat.cast_nonneg w) _)) hu

theorem outer_matrixFourScale_comparison {M N R w : ℝ}
    (hm : 0 ≤ M) (hw : 0 ≤ w) (hn : 0 < N) (hr : 0 < R) (hnr : N ≤ 2*R) :
    N^2 * matrixFourScale M N w ≤ 4 * (R^2 * matrixFourScale M R w) := by
  unfold matrixFourScale
  simp only [mul_add]
  apply add_le_add (outer_matrix_scale_comparison hm hw hn hr hnr)
  have expand (t : ℝ) (ht : 0 < t) :
      t^2 * matrixExtra M t w = (M^(3/4 : ℝ)*w^(7/8 : ℝ))*t^(3/2 : ℝ) := by
    rw [show (3/2 : ℝ) = 2-1/2 by norm_num, Real.rpow_sub ht, Real.rpow_two]
    unfold matrixExtra
    ring
  rw [expand N hn, expand R hr]
  have comp := Real.rpow_le_rpow hn.le hnr (by norm_num : 0 ≤ (3/2 : ℝ))
  rw [Real.mul_rpow (by norm_num : (0:ℝ) ≤ 2) hr.le] at comp
  have two := Real.rpow_le_rpow_of_exponent_le (by norm_num : (1:ℝ) ≤ 2)
    (by norm_num : (3/2 : ℝ) ≤ 2)
  rw [Real.rpow_two] at two
  calc
    _ ≤ (M^(3/4 : ℝ)*w^(7/8 : ℝ)) * (2^ (2:ℕ) * R^(3/2 : ℝ)) := by gcongr; exact comp.trans (by gcongr)
    _ = _ := by ring

theorem exists_nonzero_four_sg_sum_bound :
    ∃ K : ℝ, 0 < K ∧ ∀ (M R : ℝ), 0 < M → 0 < R → ∀ (S G : ℕ),
      (∑ s ∈ Finset.Icc 1 S, ∑ g ∈ Finset.Icc 1 G,
        (s : ℝ) * dyadicFourScale M (R / (g : ℝ)) ((s : ℝ) * (g : ℝ))) ≤
          K * nonzeroFourSGScale M R S := by
  obtain ⟨K, hk, old⟩ := exists_nonzero_sg_sum_bound
  let Z := ∑' g : ℕ, (g : ℝ)^(-(13/8 : ℝ))
  have hz : 0 ≤ Z := tsum_nonneg (fun g => Real.rpow_nonneg (Nat.cast_nonneg g) _)
  refine ⟨max K Z, lt_of_lt_of_le hk (le_max_left _ _), ?_⟩
  intro M R hm hr S G
  let U := M^(7/4 : ℝ) * R^(5/2 : ℝ)
  have hu : 0 ≤ U := by dsimp [U]; positivity
  have expand (s g : ℝ) (hs : 0 < s) (hg : 0 < g) :
      s * dyadicFourScale M (R/g) (s*g) =
        s * dyadicNonzeroScale M (R/g) (s*g) + U * s^(15/8 : ℝ) * g^(-(13/8 : ℝ)) := by
    have mon := shared_scale_monomial hr hs hg (5/2) (7/8)
    norm_num at mon
    have m := Real.rpow_add hm 1 (3/4)
    have r := Real.rpow_sub (div_pos hr hg) 3 (1/2)
    norm_num at m r
    unfold dyadicFourScale matrixFourScale dyadicNonzeroScale matrixExtra U
    rw [m]
    rw [r] at mon
    linear_combination (M*M^(3/4 : ℝ))*mon
  have eqsum := Finset.sum_congr rfl (fun s (hs : s ∈ Finset.Icc 1 S) =>
    Finset.sum_congr rfl (fun g (hg : g ∈ Finset.Icc 1 G) =>
      expand (s : ℝ) (g : ℝ) (Nat.cast_pos.mpr (Finset.mem_Icc.mp hs).1)
        (Nat.cast_pos.mpr (Finset.mem_Icc.mp hg).1)))
  rw [eqsum]
  simp only [Finset.sum_add_distrib]
  unfold nonzeroFourSGScale
  rw [mul_add]
  apply add_le_add
  · exact (old M R hm hr S G).trans (mul_le_mul_of_nonneg_right (le_max_left _ _)
      (by unfold nonzeroSGScale; positivity))
  · have gsum := (Real.summable_nat_rpow.mpr (by norm_num : -(13/8 : ℝ) < -1)).sum_le_tsum
          (Finset.Icc 1 G) (fun g _ => Real.rpow_nonneg (Nat.cast_nonneg g) _)
    have ssum := sum_Icc_nonneg_rpow_le S (by norm_num : (0 : ℝ) ≤ 15/8)
    norm_num at ssum
    have ident : U * (S : ℝ)^(23/8 : ℝ) = M^(7/4 : ℝ) * (R*S)^(5/2 : ℝ) * S^(3/8 : ℝ) := by
      rw [Real.mul_rpow hr.le (Nat.cast_nonneg S),
          show (23/8 : ℝ) = 5/2 + 3/8 by norm_num,
          Real.rpow_add_of_nonneg (Nat.cast_nonneg S) (by norm_num) (by norm_num)]
      dsimp [U]; ring
    rw [← ident]
    simp only [← Finset.mul_sum, ← Finset.sum_mul]
    calc
      _ ≤ (U * (S : ℝ)^(23/8 : ℝ)) * Z := by gcongr
      _ ≤ _ := by rw [mul_comm (max K Z)]; gcongr; exact le_max_right _ _

end PrimeGap180.Averaged
