import TrialHighGroupedPayment180

/-! Clearing the two small matrix denominators preserves the full signed
coefficient of every angular fiber. The integer summand used downstream
retains the sign of the entire fiber sum. -/
noncomputable section
open scoped BigOperators Classical
namespace PrimeGap180.HighSignedControls
open HighAngularGram HighRationalPanel HighGroupedPayment
open MassAngularGroups (Group Fiber)

abbrev Words := Fin 4 → Channels → ℤ
abbrev ControlWords := Fin 4 → Fin 4 → ℤ
def pulled (C : Words) (Z : ControlWords) (p q : Channels) :=
  ∑ i : Fin 4, ∑ j : Fin 4, C i p * Z i j * C j q

def coeff (C : Words) (Z : ControlWords) (g : Group) :=
  ∑ p : Fiber g, pulled C Z (HighFrozenPanel.chart p.val.1) (HighFrozenPanel.chart p.val.2)

theorem pull_exact (C : Words) (Z : ControlWords) {d e : ℕ} (dp : 0 < d) (ep : 0 < e)
    (p q : Channels) :
    pullback (fun i j => (C i j:ℝ)/d) (fun i j => (Z i j:ℝ)/e) p q =
      (pulled C Z p q:ℝ)/(d*d*e:ℕ) := by
  have dr : 0 < (d:ℝ) := by exact_mod_cast dp
  have er : 0 < (e:ℝ) := by exact_mod_cast ep
  unfold pullback pulled
  push_cast
  simp only [Finset.sum_div]
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro j _
  field_simp [dr.ne',er.ne']
  <;> ring

theorem coefficient_exact (C : Words) (Z : ControlWords) {d e : ℕ} (dp : 0 < d) (ep : 0 < e)
    (g : Group) :
    coefficient (fun i j => (C i j:ℝ)/d) (fun i j => (Z i j:ℝ)/e) g =
      (coeff C Z g:ℝ)/(d*d*e:ℕ) := by
  unfold coefficient coeff
  simp_rw [pull_exact C Z dp ep]
  rw [Int.cast_sum,Finset.sum_div]

#print axioms pull_exact
#print axioms coefficient_exact
end PrimeGap180.HighSignedControls
