import TrialSourceFrontierData180
import TrialSourceGeometryBitmap180
import Lean.Elab.Command
import Lean.Data.Json

/-! Reusable partner bitsets for the 415 distinct rectangles and the
above-half thresholds. A rectangle number names both physical axes. -/
namespace PrimeGap180.SourceRect

structure Rectangle where
  cap : Nat
  radius : Nat
  mask : Nat
  deriving Inhabited, Lean.ToExpr
structure Arc where
  rectangle : Nat
  source : Nat
  flip : Bool
  deriving Inhabited, Lean.ToExpr

private structure Raw where
  version : Nat
  rectangles : Array (Array Nat)
  above : Array (Array Nat)
  allowed : Array (Array Nat)
  arcs : Array (Array (Array (Array Nat)))
  deriving Lean.FromJson

structure Data where
  rectangles : List Rectangle
  above : Array (Nat × Nat)
  allowed : Array (Array Nat)
  arcs : Array (Array (List Arc))
  deriving Lean.ToExpr

private def decode (s : String) : Except String Data := do
  let r : Raw ← Lean.fromJson? (← Lean.Json.parse s)
  unless r.version == 1 && r.rectangles.size == 415 && r.above.size == 469 &&
      r.allowed.size == 14 && r.arcs.size == 14 do throw "wrong common-corner dimensions"
  let rects ← r.rectangles.mapM fun x => do
    unless x.size == 3 do throw "invalid rectangle"
    return (⟨x[0]!,x[1]!,x[2]!⟩ : Rectangle)
  let high ← r.above.mapM fun x => do
    unless x.size == 2 do throw "invalid upper-radius cut"
    return (x[0]!,x[1]!)
  for x in r.allowed do unless x.size == 445 do throw "wrong matrix-mask dimensions"
  let rows ← r.arcs.mapM fun x => do
    unless x.size == 469 do throw "missing owner"
    x.mapM fun row => do
      let words ← row.mapM fun a => do
        unless a.size == 3 && a[0]! < rects.size && a[2]! ≤ 1 do throw "wrong arc"
        return (⟨a[0]!,a[1]!,a[2]! == 1⟩ : Arc)
      return words.toList
  return ⟨rects.toList,high,r.allowed,rows⟩

open Lean Elab Term in
elab "sourceRectangles%" : term => do
  let dir := (System.FilePath.mk (← getFileName)).parent.getD "."
  let source ← IO.FS.readFile (dir / "frozen_source_rectangles.json")
  return toExpr (← IO.ofExcept (decode source))

noncomputable section
set_option maxHeartbeats 100000000
set_option maxRecDepth 131072 in
def data : Data := sourceRectangles%

open SourceFrontier SourceBitmap

def member (r : Rectangle) (p : Partner) : Bool := decide (p.cap ≤ r.cap ∧ p.radius ≤ r.radius)
def above (cut : Nat) (p : Partner) : Bool := decide (5000000 < cut+p.upper)

set_option maxRecDepth 131072
set_option maxHeartbeats 100000000

private theorem rectMasks : data.rectangles.all (fun r => r.mask == bitmap (member r) partners) = true := by decide +kernel
private theorem highMasks : data.above.toList.all (fun p => p.2 == bitmap (above p.1) partners) = true := by decide +kernel

theorem member_iff {r : Rectangle} {p : Partner} {i : Nat} (inData : r ∈ data.rectangles)
    (atIndex : partners[i]? = some p) : r.mask.testBit i = member r p := by
  have m : r.mask = bitmap (member r) partners := of_decide_eq_true (by simpa using List.all_eq_true.mp rectMasks _ inData)
  rw [m,hit _ atIndex]

theorem high_iff {h : Nat × Nat} {p : Partner} {j i : Nat}
    (found : data.above[j]? = some h) (atIndex : partners[i]? = some p) : h.2.testBit i = above h.1 p := by
  have member : h ∈ data.above.toList := by simpa using Array.mem_of_getElem? found
  have m : h.2 = bitmap (above h.1) partners := by simpa using List.all_eq_true.mp highMasks _ member
  rw [m,hit _ atIndex]

#print axioms member_iff
#print axioms high_iff
end
end PrimeGap180.SourceRect
