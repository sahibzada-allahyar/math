import TrialJointEdgeLowRemainder180
import TrialSignedEnvelopeClosed180

/-! The physical low group after paying two first-edge and nine scalar rows.
Each of the three remaining events retains the omitted site's original support restrictions. -/
noncomputable section
open MeasureTheory Set PrimeGap186
open PrimeGap180.Sector PrimeGap180.FrozenProfile
open scoped BigOperators
namespace PrimeGap180.LowMassReceiver
open GateDeletion (T Full μ)
open JointEdgeLowRows (row both remaining)
open private row_scale from TrialJointEdgeLowRows180

def lastEdge (i : Fin 3) : Active := ⟨11+i.val,by omega⟩

def lastRow (i : Fin 3) : Set Full :=
  {v | ∃ k : Fin 39, 102994 ≤ Native.cellSum v ∧ Native.cell (v k) ≤ 27970 ∧
    (∑ j, RemovedLowProjection.slackDust (k.removeNth v) j (lastEdge i)) <
      2*FrozenData.parentUpper (lastEdge i)}

def lastCharge : Fin 3 → ℚ := ![153239/10^89,248961/10^88,298974/10^87]
def residual := remaining \ ⋃ i, LaterLowFixed.event i

theorem matches_archive : (∑ i, lastCharge i)*100^39/(94.17312:ℚ) = LaterLowFixed.lastThree := by
  decide +kernel

set_option maxRecDepth 131072 in
set_option maxHeartbeats 0 in
theorem low_edges : ∀ i : Fin 3,
    (RemovalEdgeBook.lowerNat (lastEdge i), FrozenData.parentUpperNat (lastEdge i)) =
      ![(60000,70000),(70000,80000),(80000,90000)] i := by
  decide +kernel

theorem old_headroom : (28:ℚ)/10^9 < RemovalReceipts.low -
    (53209245/10^15+LaterLowFixed.totalCharge+(∑ i,lastCharge i)*100^39/(94.17312:ℚ)) := by
  decide +kernel

theorem tighter_overshoot : (109304:ℚ)/10^12 <
    (53209245/10^15+LaterLowFixed.totalCharge+(∑ i,lastCharge i)*100^39/(94.17312:ℚ))-
      3509670/10^12 := by decide +kernel

private theorem paid_event (i : Fin 9) : LaterLowFixed.event i =
    {v | 102994 ≤ Native.cellSum v} ∩ row (LaterLowFixed.active i) := by
  rw [row_scale (LaterLowFixed.active i) (by norm_num : (0:ℝ)<1)]
  unfold LaterLowFixed.event LaterLowFixed.cutoff
  ring_nf

theorem last_covers : residual ⊆ ⋃ i, lastRow i := by
  rintro v ⟨mem,off⟩
  obtain ⟨k,a,lo,hi,t,cell,sl⟩:=JointEdgeLowRows.later mem
  by_cases old : a.val<11
  · let i : Fin 9 := ⟨a.val-2,by omega⟩
    have eq : LaterLowFixed.active i=a := Fin.ext (by dsimp [LaterLowFixed.active,i]; omega)
    exfalso
    apply off
    apply Set.mem_iUnion.mpr
    exact ⟨i, by rw [paid_event,eq]; exact ⟨t,k,sl⟩⟩
  · let i : Fin 3 := ⟨a.val-11,by omega⟩
    have eq : lastEdge i=a := Fin.ext (by dsimp [lastEdge,i]; omega)
    apply Set.mem_iUnion.mpr
    exact ⟨i,k,t,cell,by simpa only [eq] using sl⟩

private theorem regular : Integrable (fun v => (Restoration.original v)^2) μ := by
  let := bandLaw_finite FrozenData.mesh
  have h := coded_regular T (fun p=>(GateDeletion.originalValue p.1)^2)
  exact PrimeGap186.integrable_of_measurable_of_bounded_range _ _ h.1 h.2.1

theorem last_meas (i : Fin 3) : MeasurableSet (lastRow i) := by
  change MeasurableSet {v : Full | ∃ k : Fin 39, _}
  simp only [Set.ofPred_exists]
  apply MeasurableSet.iUnion
  intro k
  change MeasurableSet ({v : Full | 102994 ≤ Native.cellSum v} ∩
      ({v : Full | Native.cell (v k) ≤ 27970} ∩ {v : Full | (∑ j, RemovedLowProjection.slackDust (k.removeNth v) j (lastEdge i)) < 2*FrozenData.parentUpper (lastEdge i)}))
  have ms : Measurable (fun v : Full=>Native.cellSum v) := by unfold Native.cellSum Native.cell; fun_prop
  have mc : Measurable (fun v : Full=>Native.cell (v k)) := by unfold Native.cell; fun_prop
  apply (measurableSet_le measurable_const ms).inter
  apply (measurableSet_le mc measurable_const).inter
  apply measurableSet_lt _ measurable_const
  unfold RemovedLowProjection.slackDust Native.cell
  change Measurable fun v : Full => ∑ j : Fin 38, Lookup.ticks *
      (((((⌊(∑ l,v (k.succAbove j) l)/Native.step⌋₊:ℕ):ℝ)+1)*Native.step -
        ∑ l,v (k.succAbove j) l) +
      ((∑ l,v (k.succAbove j) l)-∑ l ∈ Finset.univ.filter (fun l=>T.tailEdge (lastEdge i) ≤ l),v (k.succAbove j) l))
  fun_prop

private theorem sum_bound (h : ∀ i : Fin 3,
    (∫ v in lastRow i, (Restoration.original v)^2 ∂μ) ≤ (lastCharge i:ℝ)) :
    (∫ v in ⋃ i,lastRow i, (Restoration.original v)^2 ∂μ) ≤ ((∑ i,lastCharge i:ℚ):ℝ) := by
  classical
  let F := fun v => (Restoration.original v)^2
  let U := ⋃ i,lastRow i
  have cmp : (∫ v in U,F v ∂μ) ≤ ∑ i,∫ v in lastRow i,F v ∂μ := by
    rw [←integral_indicator (MeasurableSet.iUnion last_meas)]
    simp_rw [←integral_indicator (last_meas _)]
    rw [←integral_finsetSum _ (fun i _=>regular.indicator (last_meas i))]
    apply integral_mono_of_nonneg (Filter.Eventually.of_forall fun _=>Set.indicator_nonneg (fun _ _=>sq_nonneg _) _)
      (integrable_finsetSum _ fun i _=>regular.indicator (last_meas i))
    apply Filter.Eventually.of_forall
    intro v
    change U.indicator F v ≤ ∑ i,(lastRow i).indicator F v
    by_cases on : v∈U
    · obtain ⟨i,hi⟩:=Set.mem_iUnion.mp on
      rw [Set.indicator_of_mem on]
      exact (Finset.single_le_sum (f:=fun j=>(lastRow j).indicator F v)
        (fun j _=>Set.indicator_nonneg (fun _ _=>sq_nonneg _) _) (Finset.mem_univ i)).trans'
        (le_of_eq (Set.indicator_of_mem hi F).symm)
    · rw [Set.indicator_of_notMem on]
      exact Finset.sum_nonneg fun j _=>Set.indicator_nonneg (fun _ _=>sq_nonneg _) _
  push_cast
  exact cmp.trans (Finset.sum_le_sum fun i _=>h i)

theorem low_mass
    (floor : (94.17312:ℝ) ≤ 100^39*NumericalAccount.mass Restoration.original)
    (h : ∀ i : Fin 3, (∫ v in lastRow i, (Restoration.original v)^2 ∂μ) ≤ (lastCharge i:ℝ)) :
    StructuralRun.layerMass 0 ≤ (RemovalReceipts.low:ℝ)*NumericalAccount.mass Restoration.original := by
  let F := fun v => (Restoration.original v)^2
  let N := ⋃ i, LaterLowFixed.event i
  have m : MeasurableSet N := MeasurableSet.iUnion LaterLowFixed.measurable_event
  have nine := LaterLowFixed.union_payment EnvelopeClosed.envelope
  have a : (∫ v in remaining ∩ N,F v ∂μ) ≤ (LaterLowFixed.totalCharge:ℝ)*(94.17312/(100:ℝ)^39) :=
    (setIntegral_mono_set regular.integrableOn (Filter.Eventually.of_forall fun v=>sq_nonneg _) (Filter.Eventually.of_forall fun _ => And.right)).trans nine
  have b : (∫ v in remaining \ N,F v ∂μ) ≤ ((∑ i,lastCharge i:ℚ):ℝ) :=
    (setIntegral_mono_set regular.integrableOn (Filter.Eventually.of_forall fun v=>sq_nonneg _) (Filter.Eventually.of_forall fun _ v=>last_covers v)).trans (sum_bound h)
  have price : LaterLowFixed.totalCharge*(94.17312/(100:ℚ)^39)+(∑ i,lastCharge i) ≤
      (RemovalReceipts.low-53209245/(10:ℚ)^15)*(94.17312/(100:ℚ)^39) := by decide +kernel
  have realPrice := (Rat.cast_le (K:=ℝ)).mpr price
  push_cast at realPrice
  have available : 94.17312/(100:ℝ)^39 ≤ NumericalAccount.mass Restoration.original :=
    (div_le_iff₀ (by positivity)).mpr (by simpa only [mul_comm] using floor)
  apply RemovedLowProjection.mass_low.trans
  apply JointEdgeLowRows.low_of_remaining
  rw [←integral_inter_add_sdiff (s:=remaining) m regular.integrableOn]
  apply (add_le_add a b).trans
  apply le_trans _ (mul_le_mul_of_nonneg_left available (by norm_num [RemovalReceipts.low]))
  convert realPrice using 1
  push_cast
  norm_num

#print axioms last_covers
#print axioms low_mass
#print axioms old_headroom
#print axioms tighter_overshoot
end PrimeGap180.LowMassReceiver
