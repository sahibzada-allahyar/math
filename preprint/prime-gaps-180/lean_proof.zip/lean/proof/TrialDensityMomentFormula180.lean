import TrialDensityMoments180

noncomputable section
open MeasureTheory Set
open scoped BigOperators ENNReal
namespace PrimeGap180.DensitySimplex

theorem moment_value {d : ℕ} (p : Fin d → ℕ) (t : ℝ) (ht : 0 < t) :
    moment p t = t^(d+∑ i,p i) * (∏ i, ((p i).factorial : ℝ)) / ((d+∑ i,p i).factorial:ℝ) := by
  induction d generalizing t with
  | zero =>
    have h : region 0 t = Set.univ := by ext x; simp [region,ht]
    rw [moment,h,setIntegral_univ,Measure.volume_pi_eq_dirac (fun i : Fin 0 => Fin.elim0 i)]
    simp [monomial]
  | succ d ih =>
    let q : Fin d → ℕ := fun i => p i.succ
    let k := d+∑ i,q i
    let A : ℝ := (∏ i,((q i).factorial:ℝ))/(k.factorial:ℝ)
    have h₁ : moment p t = ∫ x in Ioo 0 t, (x^(p 0)*(t-x)^k)*A := by
      rw [moment_slice]
      apply setIntegral_congr_fun measurableSet_Ioo
      intro x hx
      change x^(p 0)*moment q (t-x) = _
      rw [ih q (t-x) (sub_pos.mpr hx.2)]
      dsimp only [A,k]
      ring
    have h₂ : (∫ x in Ioo 0 t, (x^(p 0)*(t-x)^k)*A) = beta (p 0) k t * A := by
      rw [integral_mul_const,beta,intervalIntegral.integral_of_le ht.le]
      exact congrArg (· * A) (setIntegral_congr_set Ioo_ae_eq_Ioc)
    have exp : d+1+∑ i,p i = p 0+k+1 := by
      rw [Fin.sum_univ_succ]
      dsimp [k,q]
      omega
    rw [h₁,h₂,beta_value,exp,Fin.prod_univ_succ]
    dsimp only [A,q]
    have nz : (k.factorial:ℝ) ≠ 0 := by positivity
    field_simp

#print axioms moment_value
end PrimeGap180.DensitySimplex
