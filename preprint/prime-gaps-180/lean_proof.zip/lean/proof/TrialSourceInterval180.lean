import Mathlib.Data.List.Basic
import Mathlib.Data.Nat.Basic

/-! A linear certificate for comparing two piecewise constant integer tables
at every address. The first end strictly beyond the address owns the cell.
The verifier visits one pair of runs at a time. -/
namespace PrimeGap180.SourceInterval

variable {α : Type*} (start stop : α → ℕ)

def ordered : ℕ → List α → Bool
  | _, [] => true
  | bound, a::xs => decide (bound ≤ (start a) ∧ (start a) ≤ (stop a)) && ordered (stop a) xs

private theorem lower {xs : List α} {n : ℕ} {b : α}
    (h : ordered start stop n xs = true) (m : b ∈ xs) : n ≤ (start b) := by
  induction xs generalizing n with
  | nil => simp at m
  | cons a xs ih =>
    simp only [ordered,Bool.and_eq_true,decide_eq_true_eq] at h
    obtain rfl | inTail := List.mem_cons.mp m
    · exact h.1.1
    · exact Nat.le_trans h.1.1 (Nat.le_trans h.1.2 (ih h.2 inTail))

theorem find_owner {xs : List α} {n k : ℕ} {b : α}
    (h : ordered start stop n xs = true) (hb : b ∈ xs) (lo : (start b) ≤ k) (hi : k < (stop b)) :
    xs.find? (fun x => k < (stop x)) = some b := by
  induction xs generalizing n with
  | nil => simp at hb
  | cons a xs ih =>
    simp only [ordered,Bool.and_eq_true,decide_eq_true_eq] at h
    obtain rfl | inTail := List.mem_cons.mp hb
    · simp [hi]
    · have stop : ¬k < (stop a) := not_lt.mpr (Nat.le_trans (lower start stop h.2 inTail) lo)
      simpa [stop] using ih h.2 inTail

section
variable {β : Type*} (last : β → ℕ) (fits : α → β → Bool)

def aligned : ℕ → List α → List β → Bool
  | 0, _, _ => false
  | _ + 1, [], _ => true
  | _ + 1, _ :: _, [] => false
  | n + 1, a::xs, b::ys => fits a b &&
    if (stop a) < last b then aligned n xs (b::ys)
    else if last b < (stop a) then aligned n (a::xs) ys
    else aligned n xs ys

theorem aligned_at {n : ℕ} {xs : List α} {ys : List β} {k : ℕ} {v : α}
    (h : aligned stop last fits n xs ys = true) (mem : xs.find? (fun x => k < (stop x)) = some v) :
    ∃ b, ys.find? (fun x => k < last x) = some b ∧ fits v b = true := by
  induction n generalizing xs ys with
  | zero => simp [aligned] at h
  | succ n ih =>
    cases xs with
    | nil => simp at mem
    | cons a xs =>
      cases ys with
      | nil => simp [aligned] at h
      | cons b ys =>
        have parts := Bool.and_eq_true_iff.mp h
        have both (o : k < (stop a)) (g : k < last b) :
            ∃ r, (b::ys).find? (fun x => k < last x) = some r ∧ fits v r = true := by
          have av : a=v := by simpa [o] using mem
          exact ⟨b,by simp [g],av ▸ parts.1⟩
        by_cases e : (stop a) < last b
        · have next : aligned stop last fits n xs (b::ys) = true := by simpa [e] using parts.2
          by_cases o : k < (stop a)
          · exact both o (Nat.lt_trans o e)
          · exact ih next (by simpa [o] using mem)
        · by_cases f : last b < (stop a)
          · have next : aligned stop last fits n (a::xs) ys = true := by simpa [e,f] using parts.2
            by_cases g : k < last b
            · exact both (Nat.lt_trans g f) g
            · obtain ⟨w,hit,ok⟩ := ih next mem
              exact ⟨w,by simpa [g] using hit,ok⟩
          · have next : aligned stop last fits n xs ys = true := by simpa [e,f] using parts.2
            by_cases o : k < (stop a)
            · exact both o (Nat.lt_of_lt_of_le o (Nat.le_of_not_gt f))
            · have g : ¬ k < last b := by omega
              obtain ⟨w,hit,ok⟩ := ih next (by simpa [o] using mem)
              exact ⟨w,by simpa [g] using hit,ok⟩
end

#print axioms find_owner
#print axioms aligned_at
end PrimeGap180.SourceInterval
