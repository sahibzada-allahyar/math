import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G323
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 323

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G323

namespace PrimeGap180.PriceIsolatedGroup.G328
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 328

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G328

namespace PrimeGap180.PriceIsolatedGroup.G333
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 333

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G333

namespace PrimeGap180.PriceIsolatedGroup.G338
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 338

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G338
