import TrialFrozenBook180
import TrialHigherDensityIntegrals180
import TrialFrozenPairGate180
import TrialRestoredScore180
import TrialFrozenGuardArchive180

/-! The concrete 39-site trial with the thirteen nontrivial row densities
given by integrals on ordered prime-exponent regions. -/
noncomputable section
open scoped BigOperators Classical Topology
open MeasureTheory Filter PrimeGap186 PrimeGap182Analytic PrimeGap180.Distribution
open PrimeGap180.Sector PrimeGap180.Price PrimeGap180.Detection PrimeGap180.Book
open PrimeGap180.Literal PrimeGap180.Density PrimeGap180.HigherMeans PrimeGap180.LiteralDensity
namespace PrimeGap180.Terminal

def fiveIntegral (a : ℝ) :=
  ∫ t in {t | fiveRegion a 0 0 t}, (∏ k, (t k)⁻¹)*(residual t)⁻¹
def threeIntegral (a c : ℝ) :=
  ∫ t in {t | threeRegion a c 0 0 t}, (∏ k, (t k)⁻¹)*(residual t)⁻¹

def loss : Book.Row → ℝ
  | .prime => 0
  | .sharp => 24*fiveIntegral (41361/100000)
  | .higher j => 24*fiveIntegral (Sifted.frozenCutoffs j).a +
    2*threeIntegral (Sifted.frozenCutoffs j).a (Frozen.parentCut j)

private theorem sharp_integral_mean (h : ℕ) : Mean .sharp (1-loss .sharp) h := by
  let a : ℝ := 41361/100000
  have le : a ≤ 417/1000 := by norm_num [a]
  have pl : Tendsto (fun x : ℝ => Real.log x/x * ∑ n ∈ window x, if n.Prime then (1:ℝ) else 0)
      atTop (𝓝 1) := by simpa [Mean,PhysicalPrices.channel,value] using (prime_mean 0)
  have fm : fiveMass a = fiveIntegral a := fiveMass_integral le
  have both := pl.sub ((five_mean le).const_mul 24)
  rw [fm] at both
  apply shifted
  apply both.congr
  intro x
  have literal (n : ℕ) : value (PhysicalPrices.channel x .sharp) n =
      (if n.Prime then (1:ℝ) else 0) - 24*(if Five (x^a) n then 1 else 0) := by
    change _ - _ = _
    simp only [mul_ite,mul_one,mul_zero]
    rfl
  simp_rw [literal]
  rw [Finset.sum_sub_distrib,← Finset.mul_sum]
  simp only [Finset.sum_boole]
  ring

theorem row_mean (k : Book.Row) (h : ℕ) : Mean k (1-loss k) h := by
  cases k with
  | prime => simpa only [loss,sub_zero] using prime_mean h
  | sharp => exact sharp_integral_mean h
  | higher j =>
    have ha : (Sifted.frozenCutoffs j).a ≤ 417/1000 := by fin_cases j <;> norm_num [Sifted.frozenCutoffs]
    have hc : 4/25 ≤ Frozen.parentCut j := by fin_cases j <;> norm_num [Frozen.parentCut]
    have e : higherDensity j = 1-loss (.higher j) := by
      dsimp only [higherDensity,loss]
      rw [show fiveMass (Sifted.frozenCutoffs j).a = fiveIntegral _ from fiveMass_integral ha,
        show threeMass (Sifted.frozenCutoffs j).a (Frozen.parentCut j) = threeIntegral _ _ from
          threeMass_integral hc (by linarith)]
      ring
    rw [←e]
    exact higher_mean j h

/-- Reconcile the 182 sharp-mass constant with the independently enclosed
four-dimensional integral, using uniqueness of the arithmetic mean. -/
theorem sharp_mass_eq : SharpMean.sharpMass = 24*fiveIntegral (41361/100000) := by
  have e := tendsto_nhds_unique (sharp_mean 0) (sharp_integral_mean 0)
  change 1-SharpMean.sharpMass = 1-24*fiveIntegral (41361/100000) at e
  linarith

/-- The archived loss endpoints expressed exactly in units of 10^-18.
The prime row has density one; the other 13 require quadrature. -/
def lossTicks : Book.Row → ℕ × ℕ
  | .prime => (0,0)
  | .sharp => (93307088324061,93307088324062)
  | .higher i => ![
    (66518764631232985,66518764632232986),
    (67599561407830339,67599561408830340),
    (69403785033994032,69403785034994033),
    (73023151504160503,73023151505160504),
    (76657190160639539,76657190161639540),
    (80306038770890718,80306038771890719),
    (83969837273387121,83969837274387123),
    (85807387060853447,85807387061853450),
    (87648727786935702,87648727787935705),
    (89493877561985658,89493877562985663),
    (91368129103126749,91368129104126754),
    (92824804285011955,92824804286011962)] i

def lossLo (k : Book.Row) : ℝ := ((lossTicks k).1:ℝ)/10^18
def lossHi (k : Book.Row) : ℝ := ((lossTicks k).2:ℝ)/10^18

/-- Thirteen ordered-prime integrals. In the five-prime quadrature, sorting
the four predecessors of the largest exponent z cancels the factor 24.
For v=min(z,a-z), r=(4v+z-1)/v, their simplex Jacobian leaves
r³ |dz|/(z v). The two branches contribute dr and dr/(4a-1-ar) times
r³ respectively. In the three-prime quadrature the multiplicity is two. -/
def DensityIntegrals := ∀ k : Book.Row, k ≠ .prime → lossLo k ≤ loss k ∧ loss k ≤ lossHi k

/-- Finite-data identity allowing either archive ordering of the two
density values in a row. -/
def DensitySlots (b : Ledger) := ∀ k,
  min (b.densityLo k) (b.densityHi k) = 1-lossHi k ∧ max (b.densityLo k) (b.densityHi k) = 1-lossLo k

private theorem mean_between (b : Ledger) (slots : DensitySlots b) (enclosed : DensityIntegrals) (k : Book.Row) :
    min (b.densityLo k) (b.densityHi k) ≤ 1-loss k ∧ 1-loss k ≤ max (b.densityLo k) (b.densityHi k) := by
  rw [(slots k).1,(slots k).2]
  by_cases prime : k = .prime
  · subst k; norm_num [lossHi,lossLo,lossTicks,loss]
  · obtain ⟨lo,hi⟩ := enclosed k prime
    exact ⟨sub_le_sub_left hi 1,sub_le_sub_left lo 1⟩

def Margin : Prop :=
  (∫ t, (FrozenData.trial t)^2 ∂Measure.pi (fun _ => bandLaw FrozenData.mesh)) +
      endpointCost FrozenData.mesh FrozenData.trial <
      rho * ∑ i : Fin 39, shiftIncome FrozenData.mesh FrozenData.trial i FrozenData.label

/-- This is the native-cell version of the score computed by the
outward 22-group ledger, on the same signed fibre erasures. -/
def NativeMargin : Prop :=
  (∫ t, (FrozenData.trial t)^2 ∂AdverseScore.prodLaw 39) + AdverseScore.endpoint <
    rho * ∑ i : Fin 39, AdverseScore.income i

theorem margin_of_native (h : NativeMargin) : Margin := AdverseScore.physical_margin_of_native h

/-- One may evaluate the adverse score on the original restored profile.
The two unclamped price kernels and both types of erased fibre agree. -/
theorem native_margin_iff_restored : NativeMargin ↔ RestoredScore.Margin := RestoredScore.native_iff

/-- Every row limit and all marked upper bounds are derived from their
analytic theorems. The gate concerns the actual supported integer moduli. -/
theorem gap_of_integrals (b : Ledger) (balance : FiniteChecks b) (kernels : KernelChecks b)
    (slots : DensitySlots b) (enclosed : DensityIntegrals)
    (number : Book.Row → ℕ) (bands : ∀ k, Fin (number k+1) → ProvedBand (fun x => PhysicalPrices.channel x k))
    (gates : ∀ i k, PairGate FrozenData.mesh FrozenData.trial i FrozenData.label Sum.inl (lifted b k) k (bands k))
    (directGate : ∀ i, PairGate FrozenData.mesh FrozenData.trial i FrozenData.label id resolvedMask .prime
      (fun _ : Unit => PhysicalPrices.ordinary_row .prime)) (margin : Margin) : primeGapLiminf ≤ (180 : EReal) :=
  gap_of_frozen_arithmetic b balance kernels number bands (fun k => 1-loss k) (mean_between b slots enclosed)
    (fun i k => row_mean k (shifts i)) gates directGate margin

/-- The optional bands in the source theorem consist of the common
ordinary grant and one of the positive source schedules. -/
private theorem reindex_gate {J α β : Type*} (i : Fin 39) (idx : J → Split)
    (A : J → J → ℝ) (k : Book.Row) (B : β → ProvedBand (fun x => PhysicalPrices.channel x k))
    (e : α ≃ β) (gate : PairGate FrozenData.mesh FrozenData.trial i FrozenData.label idx A k B) :
    PairGate FrozenData.mesh FrozenData.trial i FrozenData.label idx A k (fun j => B (e j)) := by
  intro u v nz
  filter_upwards [gate u v nz] with x hx
  intro y z sy sz cop
  obtain ⟨j,hj⟩ := hx y z sy sz cop
  exact ⟨e.symm j,by simpa only [e.apply_symm_apply] using hj⟩

def ResolvedHalf := ∀ u v : Split, resolvedMask u v ≠ 0 → ∀ a b : FrozenProfile.Receipt,
  FrozenPairGate.occurs a → FrozenPairGate.occurs b → joinLabel u = a.sector → joinLabel v = b.sector →
  FrozenPairGate.upper a + FrozenPairGate.upper b ≤ Lookup.unit/2

/-- End-to-end statement for the named native trial. All conditions
depending on selected sector pairs now have only finite receipt indices.
The classical prime and complete algebraic-sum estimates are contained
in SourceSchedule.Inputs. -/
theorem gap_of_finite_gates (input : SourceSchedule.Inputs) (b : Ledger)
    (balance : FiniteChecks b) (kernels : KernelChecks b) (slots : DensitySlots b)
    (enclosed : DensityIntegrals) (number : Book.Row → ℕ)
    (grants : ∀ k, Fin (number k) → SourceSchedule.Grant)
    (valid : ∀ k j, SourceSchedule.Valid k (grants k j))
    (mesh : FrozenPairGate.MeshChecks)
    (cover : ∀ k, FrozenPairGate.Covered (grants k) Sum.inl (lifted b k))
    (half : ResolvedHalf) (margin : Margin) : primeGapLiminf ≤ (180 : EReal) := by
  let B := fun k => SourceSchedule.bands input k (grants k) (valid k)
  apply gap_of_integrals b balance kernels slots enclosed number
    (fun k j => B k ((finSuccEquiv (number k)) j)) _ (fun i => FrozenPairGate.resolved i half) margin
  intro i k
  exact reindex_gate i Sum.inl (lifted b k) k (B k) (finSuccEquiv (number k))
    (FrozenPairGate.affine input k (grants k) (valid k) i Sum.inl (lifted b k) mesh (cover k))

/-- The final source mask uses exactly the original positive-width records
that satisfy their analytic parameter test. A finite corner must name a
member of this literal registry to pay for an above-half modulus. -/
def SourceCoverage (b : Ledger) := ∀ k,
  FrozenPairGate.Covered (FrozenGuards.indexedGrant k) Sum.inl (lifted b k)

attribute [local irreducible] FrozenGuards.sourceCount FrozenGuards.sourceAt

/-- Source and arithmetic reductions on the named trial, with its physical
score isolated for use by either of the numerical accounts. -/
theorem gap_of_frozen_margin (input : SourceSchedule.Inputs) (b : Ledger)
    (balance : FiniteChecks b) (kernels : KernelChecks b) (slots : DensitySlots b)
    (enclosed : DensityIntegrals) (mesh : FrozenPairGate.MeshChecks)
    (cover : SourceCoverage b) (half : ResolvedHalf) (margin : Margin) :
    primeGapLiminf ≤ (180 : EReal) := by
  classical
  let number := fun k => Fintype.card (FrozenGuards.SourceIndex k)
  let e (k) : Fin (number k+1) ≃ Option (FrozenGuards.SourceIndex k) :=
    (finSuccEquiv (number k)).trans (Equiv.optionCongr (Fintype.equivFin (FrozenGuards.SourceIndex k)).symm)
  let B := fun k => SourceSchedule.bands input k (FrozenGuards.indexedGrant k) (FrozenGuards.indexed_valid k)
  apply gap_of_integrals b balance kernels slots enclosed number (fun k j => B k (e k j))
    _ (fun i => FrozenPairGate.resolved i half) margin
  intro i k
  exact reindex_gate i Sum.inl (lifted b k) k (B k) (e k)
    (FrozenPairGate.affine input k (FrozenGuards.indexedGrant k) (FrozenGuards.indexed_valid k)
      i Sum.inl (lifted b k) mesh (cover k))

/-- The named frozen trial, literal grants and native-cell adverse score.
The two complete-sum hypotheses and prime estimates enter through input.
The remaining statements are the finite certificate, thirteen explicit
integral enclosures, and the strict native score. -/
theorem gap_of_frozen_certificate (input : SourceSchedule.Inputs) (b : Ledger)
    (balance : FiniteChecks b) (kernels : KernelChecks b) (slots : DensitySlots b)
    (enclosed : DensityIntegrals) (mesh : FrozenPairGate.MeshChecks)
    (cover : SourceCoverage b) (half : ResolvedHalf) (score : NativeMargin) :
    primeGapLiminf ≤ (180 : EReal) :=
  gap_of_frozen_margin input b balance kernels slots enclosed mesh cover half (margin_of_native score)

#print axioms margin_of_native
#print axioms native_margin_iff_restored
#print axioms sharp_mass_eq
#print axioms row_mean
#print axioms gap_of_integrals
#print axioms gap_of_finite_gates
#print axioms gap_of_frozen_certificate
end PrimeGap180.Terminal
