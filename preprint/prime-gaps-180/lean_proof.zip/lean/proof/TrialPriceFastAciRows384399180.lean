import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G384
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 384

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G384

namespace PrimeGap180.PriceIsolatedGroup.G389
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 389

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G389

namespace PrimeGap180.PriceIsolatedGroup.G394
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 394

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G394

namespace PrimeGap180.PriceIsolatedGroup.G399
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 399

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G399
