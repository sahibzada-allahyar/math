import TrialDensityHornerApplication180
import TrialDensityFrozenNumbers180
namespace PrimeGap180.DensitySimplex.Horner
open MeasureTheory
open scoped BigOperators

theorem triangle_from_forms (r s : ℚ) (L U : List (Factor 2)) (D E : Int) (d : D≠0) (e : E≠0)
    (lower : ∀ z : Fin 2 → ℝ, (L.map (factorValue z)).prod/(D:ℝ) = threeDen (lowerMap r s z))
    (upper : ∀ z : Fin 2 → ℝ, (U.map (factorValue z)).prod/(E:ℝ) = threeDen (upperMap r s z)) :
    triangleQ r s = 18*(((r+s/2)*s)*runQ 2 D L 1 + (r*(s+r/2))*runQ 2 E U 1) := by
  have hl := runQ_correct 2 D d L 1 (by norm_num)
  have hu := runQ_correct 2 E e U 1 (by norm_num)
  simp only [lower,Rat.cast_one] at hl
  simp only [upper,Rat.cast_one] at hu
  have physical := triangleQ_correct r s
  unfold triangleApprox threePolynomial at physical
  rw [hl,hu] at physical
  exact_mod_cast physical.symm

#print axioms triangle_from_forms
end PrimeGap180.DensitySimplex.Horner
