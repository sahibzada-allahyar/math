import TrialPriceRows180
import Batteries.Tactic.OpenPrivate
import Lean

namespace PrimeGap180.PriceEventRowCache
open Lean Elab Command
open private matrices from TrialPriceFactorArchive180
open private words from TrialSourceAffineCompactData180

private def body (n : Name) : CommandElabM Expr := do
  let some (.defnInfo ci) := (← getEnv).find? n | throwError "missing compiled table {n}"
  return ci.value

private def arrayList (xs : Expr) : CommandElabM Expr := do
  unless xs.isAppOfArity ``List.toArray 2 do throwError "expected original literal column array"
  return xs.appArg!

private def entries (xs : Expr) : CommandElabM (Array Expr) := do
  let mut xs := xs
  let mut a := #[]
  while xs.isAppOfArity ``List.cons 3 do
    a := a.push xs.appFn!.appArg!
    xs := xs.appArg!
  unless xs.isAppOfArity ``List.nil 1 do throwError "expected a complete list"
  return a

private def natValue (e : Expr) : CommandElabM Nat := do
  let some n ← liftTermElabM (Meta.getNatValue? e) | throwError "expected a physical row numeral"
  return n

private def defineArray (n : Name) (values : Array Int) : CommandElabM Unit := do
  let ty := mkApp (mkConst ``Array [.zero]) (mkConst ``Int)
  let name := (← getCurrNamespace) ++ n
  liftCoreM <| addDecl (.defnDecl {name,levelParams:=[],type:=ty,value:=toExpr values,hints:=.regular 1,safety:=.safe})

/-- Generate candidate actions for a single physical group directly from the
original compiled column and affine literals. Each consuming module proves
the two result arrays agree with the original definitions by kernel reduction. -/
elab "declarePriceActions" group:num : command => do
  let g := group.getNat
  unless g < 445 do throwError "group outside the physical ledger"
  let B := (2:Nat)^192
  let bias := (2:Nat)^63
  let mask := (2:Nat)^64-1
  let offset : Int := (bias*((B^445-1)/(B-1)):Nat)
  let all ← entries (← arrayList (← body ``matrices))
  unless all.size == 101 do throwError "expected 101 original column matrices"
  let mut U := #[]
  for matrix in all do
    let mut sum : Int := 0
    for e in (← entries (← arrayList matrix)) do
      let w ← natValue e
      let v : Int := (((w >>> (192*g)) &&& mask:Nat):Int) - bias
      sum := sum+v*((w:Int)-offset)
    U := U.push sum
  let affine ← entries (← body ``words)
  unless affine.size == 14 do throwError "expected 14 original affine channels"
  let mut A := #[]
  for channel in affine do
    let pairs ← entries channel
    unless pairs.size == 445 do throwError "expected 445 affine rows"
    let mut sum : Int := 0
    for t in [:445] do
      let h := 444-t
      let pair := pairs[min g h]!
      unless pair.isAppOfArity ``Prod.mk 4 do throwError "expected row and exclusion mask"
      let w ← natValue pair.getAppArgs[2]!
      let v := (w >>> (64*(max g h))) &&& mask
      let x : Int := if bias ≤ v then (v:Int)-2^64 else v
      sum := x+(B:Int)*sum
    A := A.push sum
  defineArray `gramActions U
  defineArray `affineActions A

end PrimeGap180.PriceEventRowCache
