import TrialDensitySampleEval180
namespace PrimeGap180.PackedFive
def radix : Nat := 1 <<< 320
def h : Int := (1:Nat) <<< 512
def fac : Nat → Nat | 0 => 1 | n+1 => (n+1)*fac n
def slice (x : Nat) (start width : Nat) : Nat := (x >>> (320*start)) &&& ((1 <<< (320*width))-1)
def addTerms (n : Nat) (f : Nat → Int) : Int := (List.range (n+1)).foldr (fun i a => f i + a) 0
def inner (x : Nat) (n : Nat) : Int := addTerms n fun k =>
  ((slice x k 1:Int) - (radix/2:Nat))*(fac k:Int)*h^k
def middle (x : Nat) (n : Nat) : Int := addTerms n fun l =>
  inner (slice x (51*l) (n-l+1)) (n-l)*(fac l:Int)*h^l
def moments (word : Int) (i : Nat) : Int :=
  let n := 50-i
  let width := 2601*n+1
  let offset := (radix/2)*(((1 <<< (320*width))-1)/(radix-1))
  let x := (word+(offset:Int)).toNat
  (fac i:Int)*h^i*addTerms n (fun j =>
    middle (slice x (2601*j) (51*(n-j)+1)) (n-j)*(fac j:Int)*h^j)
end PrimeGap180.PackedFive
