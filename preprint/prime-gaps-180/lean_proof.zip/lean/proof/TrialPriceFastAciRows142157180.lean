import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G142
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 142

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G142

namespace PrimeGap180.PriceIsolatedGroup.G147
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 147

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G147

namespace PrimeGap180.PriceIsolatedGroup.G152
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 152

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G152

namespace PrimeGap180.PriceIsolatedGroup.G157
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 157

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G157
