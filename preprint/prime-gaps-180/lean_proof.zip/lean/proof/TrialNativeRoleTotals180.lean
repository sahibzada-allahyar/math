import TrialNativeRadialScore180
import TrialNativeRadialMass180

/-! Every degree and cap of each of the five historical native role integrals.
The displayed total-index range is the genuine 130,965 supported coefficients. -/
noncomputable section
open scoped Classical BigOperators
open PrimeGap180.DebitNativeClasses PrimeGap180.PackedLaw PrimeGap180.PackedSingleFields
open PrimeGap180.NativeShellErasures PrimeGap180.PackedRoleKernels PrimeGap180.SignedCapContractions
open PrimeGap180.Sector
namespace PrimeGap180.NativeRoleTotals
set_option maxRecDepth 5500
set_option maxHeartbeats 1500000

private theorem raw_room (t : Fin 39 → Atom) (large : 130964 < retained t) : rawAtom t=0 := by
  unfold rawAtom
  split
  · rfl
  · rename_i c h
    unfold FrozenProfile.raw
    exact if_pos (lt_of_le_of_lt (min_le_left _ _) large)

private theorem single_off (v : Atom → ℝ) (i : Fin 39) (t : Fin 38 → Atom) (h : 130964 < retained t) :
    singleN v i t=0 := by
  unfold singleN
  apply Finset.sum_eq_zero
  intro a _
  have room : 130964 < retained (i.insertNth (α:=fun _=>Atom) a t) := by rw [insertTotal]; omega
  rw [raw_room _ room,mul_zero]

private theorem pair_off (v : Atom → ℝ) (t : Fin 37 → Atom) (h : 130964 < retained t) :
    ReferenceRoles.insertPair v t=0 := by
  unfold ReferenceRoles.insertPair
  apply Finset.sum_eq_zero
  intro a _
  suffices z : (∑ b : Atom,v b*rawAtom (EndpointPhysical.join t a b))=0 by rw [z,mul_zero]
  apply Finset.sum_eq_zero
  intro b _
  have room : 130964 < retained (EndpointPhysical.join t a b) := by rw [PackedPairFields.total]; omega
  rw [raw_room _ room,mul_zero]

private theorem cut {X : Type*} [Fintype X] (rad : X → ℕ) (f : X → ℝ)
    (support : ∀ x,130964 < rad x → f x=0) :
    (∑ x : X,f x) = ∑ j : Tick,∑ x : X,if rad x=j.val then f x else 0 := by
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro x _
  by_cases yes : rad x < 130965
  · let k : Tick := ⟨rad x,yes⟩
    symm
    rw [Finset.sum_eq_single k]
    · simp [k]
    · intro a _ ne
      have no : rad x ≠ a.val := fun e => ne (Fin.ext e.symm)
      simp [no]
    · simp
  · simp [support x (by omega)]

private theorem scaled {d : ℕ} (g : Grid) (t : Fin d → Atom) :
    (∏ i,ReferenceRoles.archive (law g) (t i)) = 100^d*(∏ i,law g (t i)) := by
  simp only [ReferenceRoles.archive,Finset.prod_mul_distrib,Finset.prod_const,Finset.card_univ,Fintype.card_fin]

def ordinary (g : Grid) : ℝ := 100^39*∑ j : Tick,∑ c : Hist,
    (NativeRadialMass.fullGram g c j.val c.val-NativeRadialMass.fullGram g c j.val (c.val+1))
def single (g : Grid) (i : Fin 39) : ℝ := (rho/100)*100^38*∑ j : Tick,∑ c : Hist,
    (keyPrice j.val c.val*singleGram g i c j.val c.val-keyPrice j.val (c.val+1)*singleGram g i c j.val (c.val+1))
def q (j : ℕ) := 2*(rho/100)^2/(EndpointPhysical.ledger-Native.adverse (d:=37) j)^2
def pair (g : Grid) : ℝ := 100^37*∑ j : Tick,∑ c : Hist,
    (q j.val*pairGram g c j.val c.val-q j.val*pairGram g c j.val (c.val+1))

theorem mass_eq (g : Grid) : massN (ReferenceRoles.archive (law g))=ordinary g := by
  unfold ordinary massN
  let W (t : Fin 39 → Atom) := (rawAtom t)^2*∏ j,law g (t j)
  have off (t) (large : 130964 < retained t) : W t=0 := by simp [W,raw_room t large]
  calc
    _ = 100^39*∑ t : Fin 39 → Atom,W t := by
      rw [Finset.mul_sum]
      exact Finset.sum_congr rfl (fun t _ => by rw [scaled]; unfold W; ring)
    _ = _ := by rw [cut retained W off]; simp only [W,NativeRadialMass.radial_mass]

theorem single_eq (g : Grid) (i : Fin 39) :
    ReferenceRoles.single (rho/100) (ReferenceRoles.archive (law g)) i=single g i := by
  let v := ReferenceRoles.archive (law g)
  let W (t : Fin 38 → Atom) := (NativeContractions.price (sectorAtom t) (retained t)*(singleN v i t)^2)*∏ j,law g (t j)
  have off (t) (large : 130964 < retained t) : W t=0 := by simp [W,single_off v i t large]
  unfold ReferenceRoles.single single
  calc
    _ = (rho/100)*100^38*∑ t : Fin 38 → Atom,W t := by
      rw [Finset.mul_sum]
      exact Finset.sum_congr rfl (fun t _ => by rw [scaled]; unfold W v; ring)
    _ = _ := by rw [cut retained W off]; simp only [W,v,NativeRadialScore.single]

theorem pair_eq (g : Grid) : ReferenceRoles.pair (rho/100) (ReferenceRoles.archive (law g)) = pair g := by
  let v := ReferenceRoles.archive (law g)
  let W (t : Fin 37 → Atom) := (q (retained t)*(ReferenceRoles.insertPair v t)^2)*∏ j,law g (t j)
  have off (t) (large : 130964 < retained t) : W t=0 := by simp [W,pair_off v t large]
  unfold ReferenceRoles.pair pair
  calc
    _ = 100^37*∑ t : Fin 37 → Atom,W t := by
      rw [Finset.mul_sum]
      exact Finset.sum_congr rfl (fun t _ => by rw [scaled]; unfold W v q; ring)
    _ = _ := by rw [cut retained W off]; simp only [W,v,NativeRadialScore.pair]

/-- The positive price replacement on a single erased face, on the same
archived normalization as the ordinary mass and the historical role bounds. -/
def positiveDebit (g : Grid) (i : Fin 39) : ℝ :=
  (rho*100^37)*∑ j : Tick,∑ c : Hist,
    (NativeRadialScore.debitPrice j.val c.val*singleGram g i c j.val c.val-
     NativeRadialScore.debitPrice j.val (c.val+1)*singleGram g i c j.val (c.val+1))

theorem debit_at (g : Grid) (i : Fin 39) :
    (100^39*rho)*(∑ t : Fin 38 → Atom,rateAtom t*(singleN (law g) i t)^2*∏ j,law g (t j)) = positiveDebit g i := by
  let v := ReferenceRoles.archive (law g)
  have ins (i : Fin 39) (t : Fin 38 → Atom) : singleN v i t=100*singleN (law g) i t := by
    unfold singleN
    rw [Finset.mul_sum]
    exact Finset.sum_congr rfl fun _ _ => mul_assoc _ _ _
  let W (t : Fin 38 → Atom) := (rateAtom t*(singleN v i t)^2)*∏ j,law g (t j)
  have off (t) (large : 130964 < retained t) : W t=0 := by simp [W,single_off v i t large]
  calc
    _ = (rho*100^37)*∑ t : Fin 38 → Atom,W t := by
      rw [Finset.mul_sum,Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro t _
      dsimp only [W]
      rw [ins]
      ring
    _ = _ := by rw [cut retained W off]; simp only [W,v,NativeRadialScore.debit,positiveDebit]

theorem debit_eq (g : Grid) : 100^39*debitN (law g) = ∑ i,positiveDebit g i := by
  unfold debitN
  rw [←mul_assoc,Finset.mul_sum]
  exact Finset.sum_congr rfl fun i _ => debit_at g i

#print axioms debit_eq
#print axioms mass_eq
#print axioms single_eq
#print axioms pair_eq
end PrimeGap180.NativeRoleTotals
