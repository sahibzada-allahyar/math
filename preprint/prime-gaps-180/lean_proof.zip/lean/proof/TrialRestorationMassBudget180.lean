import TrialRestorationRows180
import TrialRemovalReceipts180

/-! The identical 24 mass integrals pay for the signed restoration and for
the independent debit charged to the deleted spline. Middle receipts on disk
are absolute and carry the factor 100^39. -/
noncomputable section
open scoped BigOperators Classical
open MeasureTheory PrimeGap180.Sector PrimeGap180.RestorationRows
namespace PrimeGap180.RestorationBudget

def originalMass := NumericalAccount.mass Restoration.original

def middle (i : Fin 22) : Fin 24 := i.succ.castSucc

theorem splitGroups (f : Fin 24 → ℝ) :
    (∑ g, f g) = f 0 + (∑ i : Fin 22, f (middle i)) + f 23 := by
  rw [Fin.sum_univ_castSucc]
  rw [Fin.sum_univ_succ (fun k : Fin 23 => f k.castSucc)]
  rfl

theorem middle_price (i : Fin 22) :
    RemovalReceipts.middle i ≤ ((rows i).mass : ℚ) / 10^12 * (9417312/100000) := by
  revert i
  decide +kernel

theorem middle_of_absolute (i : Fin 22) (floor : (94.17312 : ℝ) ≤ 100^39 * originalMass)
    (raw : (100:ℝ)^39 * StructuralRun.layerMass (middle i) ≤ (RemovalReceipts.middle i : ℝ)) :
    StructuralRun.layerMass (middle i) ≤ ticks (rows i).mass * originalMass := by
  have cap : (RemovalReceipts.middle i : ℝ) ≤ ticks (rows i).mass * 94.17312 := by
    unfold ticks
    have h := (Rat.cast_le (K := ℝ)).mpr (middle_price i)
    push_cast at h
    rw [show (94.17312 : ℝ) = 9417312/100000 by norm_num]
    exact h
  have nn : 0 ≤ ticks (rows i).mass := by unfold ticks; positivity
  have h := raw.trans (cap.trans (mul_le_mul_of_nonneg_left floor nn))
  calc
    _ ≤ ticks (rows i).mass * originalMass := by
      apply le_of_mul_le_mul_left (a := (100:ℝ)^39) _ (by positivity)
      linarith only [h]

theorem middle_mass_total : ∑ i : Fin 22, (rows i).mass = 152726230 := by decide +kernel

theorem deleted_bound
    (low : StructuralRun.layerMass 0 ≤ ticks 3509670 * originalMass)
    (mid : ∀ i : Fin 22, StructuralRun.layerMass (middle i) ≤ ticks (rows i).mass * originalMass)
    (high : StructuralRun.layerMass 23 ≤ ticks 4135470 * originalMass) :
    NumericalAccount.mass Restoration.deleted ≤ ticks 160371370 * originalMass := by
  have h := Finset.sum_le_sum (s := Finset.univ) (fun i _ => mid i)
  rw [←Finset.sum_mul] at h
  have s : (∑ i : Fin 22, ticks (rows i).mass) = ticks 152726230 := by
    unfold ticks
    rw [←Finset.sum_div,←Nat.cast_sum,middle_mass_total]
  rw [s] at h
  rw [StructuralRun.deleted_mass,splitGroups]
  unfold ticks at low h high ⊢
  linarith only [low,h,high]

#print axioms middle_of_absolute
#print axioms deleted_bound
end PrimeGap180.RestorationBudget
