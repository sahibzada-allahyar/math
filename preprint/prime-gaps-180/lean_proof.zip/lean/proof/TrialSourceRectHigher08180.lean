import TrialSourceRectChecks180
namespace PrimeGap180.SourceRectChecks.Higher08

set_option maxRecDepth 131072
set_option maxHeartbeats 100000000

theorem verified : row (.higher 8) = true := by decide +kernel

#print axioms verified
end PrimeGap180.SourceRectChecks.Higher08
