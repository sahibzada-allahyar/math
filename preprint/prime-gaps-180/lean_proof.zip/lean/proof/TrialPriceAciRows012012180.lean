import TrialPriceIsolatedChecks180
import TrialPriceGroupElab180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G012
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifySignedPriceGroup 12

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G012
