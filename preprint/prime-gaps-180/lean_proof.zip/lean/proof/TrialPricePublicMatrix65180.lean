import TrialPriceSlotReflect180

namespace PrimeGap180.PriceBindings.M65
open PrimeGap180.PriceProjection PrimeGap180.PriceWordText
set_option maxRecDepth 24000000
set_option maxHeartbeats 400000000

declareSlotParts 65

theorem selected_public : PackedLedger.raw.matrices[79]! = (rank,whole) := by rfl
theorem selected_rows : PriceFactorSource.factorShapes[65]! = (rank,numerals.toArray) := by rfl
theorem group_count : numerals.length=445 := by decide +kernel

proveWholeText 65
proveSlotRows 65 0 445
collectSlotRows 65

theorem bound : PackedLedger.raw.matrices[79]! = PriceFactorSource.physical (PriceFactorSource.factorShapes[65]!) :=
  slot group_count selected_rows (selected_public.trans (congrArg (fun s : String => (rank,s)) whole_text)) all_rows

#print axioms bound
end PrimeGap180.PriceBindings.M65
