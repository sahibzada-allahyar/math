import TrialHighTailTiles180
import TrialHighMomentTails180
import TrialExactTagArea180
import TrialOneTagCell180
import TrialFrozenChannels180

/-! The interval table bounds moments of the original frozen one-site
profile at the actual native midpoints, with the same harmonic clipping
weights obtained by integrating the Poisson marks. -/
noncomputable section
namespace PrimeGap180.HighTailPhysical
open scoped BigOperators ENNReal
open HighMomentTails HighTailTiles FrozenChannels FrozenProfile MeasureTheory

def weight (r : Rate) (j : ℕ) : ℝ :=
  (1-(beta r:ℝ)*Native.step)^j * Native.step *
    (siteFactor (center j)/(1+300*center j))^2

theorem center_eq (j : ℕ) : (HighTailSweep.mid j : ℝ) = center j := by
  unfold HighTailSweep.mid HighTailSweep.xn HighTailSweep.xd HighTailSweep.num HighTailSweep.den
    center Native.step
  push_cast
  ring

private theorem step_eq : (HighTailSweep.step : ℝ) = Native.step := by
  norm_num [HighTailSweep.step,HighTailSweep.num,HighTailSweep.den,Native.step]

theorem term_eq (r : Rate) (p : Degree) (j : ℕ) :
    (term r p j : ℝ) = weight r j * (center j)^p.val := by
  unfold term HighTailSweep.basic HighTailSweep.ratio HighTailSweep.root weight siteFactor
  push_cast
  rw [center_eq,step_eq]
  ring

theorem native {first : ℕ} (r : Rate) (p : Degree) (hf : first ≤ 131072) :
    (segment r p first (131072-first):ℝ) =
      ∑ j : Fin 131072, if first ≤ j.val then weight r j.val*(center j.val)^p.val else 0 := by
  let f := fun j : ℕ => if first ≤ j then weight r j*(center j)^p.val else 0
  change _ = ∑ j : Fin 131072, f j.val
  rw [Fin.sum_univ_eq_sum_range f]
  have decomp := Finset.sum_range_add f first (131072-first)
  rw [Nat.add_sub_of_le hf] at decomp
  rw [decomp,show ∑ j ∈ Finset.range first, f j = 0 from
    Finset.sum_eq_zero (fun j hj => if_neg (Nat.not_le.mpr (Finset.mem_range.mp hj))),zero_add]
  unfold HighTailTiles.segment
  push_cast
  apply Finset.sum_congr rfl
  intro j _
  rw [term_eq]
  simp [f]

/-- Every nonnegative physical cutoff, including one beyond all native cells,
selects the clipped floor of its coordinate. -/
theorem tail_eq {θ : ℝ} (hθ : 0 ≤ θ) (r : Rate) (p : Degree) :
    tail (fun j : Fin 131072 => center j.val) (fun j => weight r j.val) Native.step θ p.val =
      (segment r p (min ⌊θ/Native.step⌋₊ 131072) (131072-min ⌊θ/Native.step⌋₊ 131072):ℝ) := by
  rw [native r p (min_le_right _ _)]
  unfold tail
  apply Finset.sum_congr rfl
  intro j _
  have positive : 0 < Native.step := by norm_num [Native.step]
  have ceiling : center j.val + Native.step/2 = ((j.val:ℝ)+1)*Native.step := by unfold center; ring
  rw [ceiling]
  have same : θ < ((j.val:ℝ)+1)*Native.step ↔ min ⌊θ/Native.step⌋₊ 131072 ≤ j.val :=
    (native_cut hθ positive j.val).trans (by simp [min_le_iff, Nat.not_le.mpr j.isLt])
  by_cases hit : θ < ((j.val:ℝ)+1)*Native.step
  · simp only [ite_eq_left hit,ite_eq_left (same.mp hit)]
  · simp only [ite_eq_right hit,ite_eq_right (fun h => hit (same.mpr h))]

theorem one_weight {a b : ℝ} (ab : a ≤ b) (H : ℝ) :
    oneWeight a b H = max (min b H - a) 0/a := by
  unfold oneWeight
  by_cases ha : H ≤ a
  · rw [max_eq_right (sub_nonpos.mpr ha), max_eq_right (sub_nonpos.mpr (ha.trans ab)),
      min_eq_right (ha.trans ab),max_eq_right (sub_nonpos.mpr ha),sub_zero]
  · have ah := le_of_not_ge ha
    by_cases hb : H ≤ b
    · rw [max_eq_left (sub_nonneg.mpr ah),max_eq_right (sub_nonpos.mpr hb),
        min_eq_right hb,max_eq_left (sub_nonneg.mpr ah),sub_zero]
    · have bh := le_of_not_ge hb
      rw [max_eq_left (sub_nonneg.mpr ah),max_eq_left (sub_nonneg.mpr bh),
        min_eq_left bh,max_eq_left (sub_nonneg.mpr ab)]
      ring

theorem two_weight (a b c d H : ℝ) :
    twoWeight a b c d H = ExactTagArea.rectangle a b c d H / (a*c) := by
  unfold twoWeight ExactTagArea.rectangle ExactTagArea.ramp
  simp only [show H-(a+c)=H-c-a by ring, show H-(b+c)=H-c-b by ring,
    show H-(a+d)=H-d-a by ring,show H-(b+d)=H-d-b by ring]
  ring

def ordinary (r : Rate) (j : ℕ) :=
  (1-(beta r:ℝ)*Native.step)^j * Native.step * (siteFactor (center j))^2

def numerator (x : ℝ) : Fin 3 → ℝ :=
  ![1+300*x, (x/(131072*Native.step))^2*(1+300*x), 1]

private theorem positive (j : ℕ) : 0 < 1+300*center j := by
  have h : 0 < Native.step := by norm_num [Native.step]
  unfold center
  positivity

theorem core (r : Rate) (j : ℕ) :
    weight r j * (1+300*center j)^2 = ordinary r j := by
  unfold weight ordinary
  field_simp [(positive j).ne']

private theorem restore (j : ℕ) (a : Fin 3) :
    numerator (center j) a = shapes (center j) a *(1+300*center j) := by
  fin_cases a <;> simp [numerator,shapes,(positive j).ne']

theorem endpoints (r : Rate) (j : ℕ) (a b : Fin 3) :
    weight r j * numerator (center j) a * numerator (center j) b =
      ordinary r j * shapes (center j) a * shapes (center j) b := by
  rw [restore,restore,←core]
  ring

#print axioms core
#print axioms endpoints
#print axioms term_eq
#print axioms native
#print axioms tail_eq
#print axioms one_weight
#print axioms two_weight
end PrimeGap180.HighTailPhysical
