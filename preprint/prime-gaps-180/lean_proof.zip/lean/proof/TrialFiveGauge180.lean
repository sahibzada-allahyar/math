import TrialSignedGauge180
import TrialFrozenFivePrice180

/-! Full and incremental five-prime covers on literal signed group columns
for the same original 39-site trial, retaining separate sector prices. -/
noncomputable section
open scoped Classical BigOperators Topology
open Filter MeasureTheory PrimeGap186 PrimeGap182Analytic
open PrimeGap180.Sector PrimeGap180.EventBins
namespace PrimeGap180.ClippedPair

def frozenPairPrice (row : FiveRow) (weights : Bin → ℝ) (q : ℝ) :=
  ∑ t : Bin, weights t * price row.cut t.1 t.2 *
    (1/(min (lower row.cut) ((1-markExponent row.cut t)/2-q)-0.0001))

theorem gauge_table_upper {m : ℕ} {S G : Type*} [Fintype S] [Fintype G]
    (H : Finset ℕ) (hH : H.card=39) (k : Fin 39) (smallShift : H.orderEmbOfFin hH k ≤ 182)
    (row : FiveRow) (weights : Bin → ℝ) (nn : ∀ t, 0 ≤ weights t) (table : TableCover row.incremental weights)
    (a : Fin (m+2) → ℝ) (ha : StrictMono a) (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (P : S → (Fin 38 → Band m) → Prop) (F : Profile 39 m)
    (sep : ∀ s t, s ≠ t → ∀ y, P s y → ¬ P t y)
    (bf : Bornology.IsBounded (Set.range F))
    (r : S → ℝ) (hr : ∀ s, 0 ≤ r s) (rad : ∀ s y, P s y → rho*∑ t, ∑ u, y t u ≤ r s)
    (rmax : ∀ s, r s ≤ 0.2801)
    (mf : ∀ s, Measurable (restrictFace k (P s) F))
    (cf : ∀ s, ∀ᵐ y ∂Measure.pi (fun _ => bandLaw a), ContinuousAt (restrictFace k (P s) F) y)
    (owner : S → G) (ref c : G → ℝ) (pos : ∀ g, 0 < ref g)
    (b : ℝ → ℕ) (L : Filter ℝ) (cofinal : L ≤ atTop) :
    let h : Fin 39 → ℕ := H.orderEmbOfFin hH
    let Z := fun s => restrictFace k (P s) F
    let V := fun x n s => sampledSelbergRoot (face H a k (Z s) x) (fun t => n+h (k.succAbove t))
    let E := fun s => ∫ y, (integralFace a k (Z s) y)^2 ∂Measure.pi (fun _ => bandLaw a)
    let pay := fun x n => if Nat.ModEq (presievingModulus H x) n (b x) then (markedScale H x)⁻¹ else 0
    Price.Upper L (fun x => Price.squareCount (Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊)
      (fun n => row.value x (n+h k) * pay x n) (fun n => gaugeGroup owner ref (V x n)) c)
      (∑ g, gaugeCost owner ref (fun s => frozenPairPrice row weights (r s) * E s) g * (c g)^2) := by
  intro h Z V E pay
  let d := fun s => c (owner s) / Real.sqrt (ref (owner s))
  have reg := fun s => signed_sector_regular a k (P s) F (d s) bf (mf s) (cf s)
  have eq (s) : restrictFace k (P s) (fun t => d s * F t) = fun t => d s * Z s t := by
    funext t
    by_cases hs : P s (k.removeNth t) <;> simp [Z,restrictFace,hs]
  have adapter := gauge_physical_upper H a k h Z (fun s _ => frozenPairPrice row weights (r s)) owner ref c pos
    (fun x n => row.value x (n+h k)) (fun x => Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊) b L cofinal
  simp only [integral_const_mul] at adapter
  apply adapter
  intro ε he
  have bound := frozen_table_upper H hH k smallShift row weights nn table a ha first last P
    (fun s y => d s * F y) sep (fun s => (reg s).1) (fun s => (reg s).2.1) (fun s => (reg s).2.2)
    r hr rad rmax b he
  filter_upwards [bound] with x paid
  simp only [eq] at paid
  rw [Finset.sum_comm (s := (Finset.univ : Finset Bin)) (t := (Finset.univ : Finset S))] at paid
  simpa only [frozenPairPrice,Finset.sum_mul] using paid

#print axioms gauge_table_upper
end PrimeGap180.ClippedPair
