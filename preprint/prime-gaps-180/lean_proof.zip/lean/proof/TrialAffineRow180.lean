import TrialAffineLimit180
import TrialPhysicalPrices180

/-! Pair a frozen signed multiplier only on its supported moduli.
Disjoint retained sectors force all continuum cross terms to vanish. -/
noncomputable section
open scoped BigOperators Classical Topology
open MeasureTheory Filter PrimeGap186 PrimeGap182Analytic PrimeGap180.Distribution PrimeGap180.Price
namespace PrimeGap180.Sector

private theorem mixed_energy {m : ℕ} (a : Fin (m+2) → ℝ) (i : Fin 39)
    (P Q : (Fin 38 → Band m) → Prop) (F G : Profile 39 m) (sep : ∀ t, P t → ¬ Q t) :
    (∫ t, integralFace a i (restrictFace i P F) t * integralFace a i (restrictFace i Q G) t
      ∂Measure.pi (fun _ => bandLaw a)) = 0 := by
  have erase (S : (Fin 38 → Band m) → Prop) (T : Profile 39 m) (y : Fin 38 → Band m)
      (hy : ¬ S y) : integralFace a i (restrictFace i S T) y = 0 := by
    simp [integralFace,restrictFace,Fin.removeNth_insertNth,hy]
  have zero (t : Fin 38 → Band m) : integralFace a i (restrictFace i P F) t *
      integralFace a i (restrictFace i Q G) t = 0 := by
    by_cases pos : P t
    · rw [erase Q G t (sep t pos),mul_zero]
    · rw [erase P F t pos,zero_mul]
  simp only [zero,integral_zero]

/-- One affine row in the form required by the physical prime lower bound.
The two endpoints of the density interval may be in either order. The
matrix A is the signed integer multiplier divided by the certificate unit. -/
theorem signed_price_row {ι J : Type*} [Fintype ι] [Nonempty ι] [DecidableEq ι] [Fintype J]
    (L : Filter ℝ) (cofinal : L ≤ atTop) (ch : ℝ → Literal.Channel) (bands : ι → ProvedBand ch)
    (cuts : ∀ᶠ x in atTop, Literal.admissible x (x^physicalCap) (ch x))
    {m : ℕ} (H : Finset ℕ) (hH : H.card = 39) (i : Fin 39) (a : Fin (m+2) → ℝ)
    (inc : StrictMono a) (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (P : J → (Fin 38 → Band m) → Prop) (F : J → Profile 39 m)
    (sep : ∀ j k, j ≠ k → ∀ t, P j t → ¬ P k t)
    (bf : ∀ j, Bornology.IsBounded (Set.range (F j)))
    (mf : ∀ j, Measurable (restrictFace i (P j) (F j)))
    (cf : ∀ j, ∀ᵐ t ∂Measure.pi (fun _ => bandLaw a), ContinuousAt (restrictFace i (P j) (F j)) t)
    (v : ℝ → ℕ) (I : ℝ → Finset ℕ) (A : J → J → ℝ)
    (d l u : ℝ) (enclose : min l u ≤ d ∧ d ≤ max l u)
    (gate : ∀ j k, A j k ≠ 0 → ∀ᶠ x in L, let W := presievingModulus H x
      (v x + H.orderEmbOfFin hH i).Coprime W ∧ (∀ p ∈ I x, p.Prime) ∧
      ∀ y z : Fin 38 → ℕ, inSector H a i (P j) (F j) x y → inSector H a i (P k) (F k) x z →
        (∀ s t : Fin 38, s ≠ t → (y s).Coprime (z t)) →
        ∃ b, W.lcm ((∏ s, y s).lcm (∏ s, z s)) ∈ (bands b).toSieveBand.moduli x (I x))
    (density : Tendsto (fun x => Real.log x/x *
      ∑ n ∈ window x, Literal.value (ch x) (n+H.orderEmbOfFin hH i)) L (𝓝 d)) :
    let h := H.orderEmbOfFin hH
    let U := fun j => restrictFace i (P j) (F j)
    let V := fun x n j => sectorAmplitude (face H a i (U j) x) h i n
    let Z := fun x n => if Nat.ModEq (presievingModulus H x) n (v x) then 1/markedScale H x else 0
    let E := fun j => ∫ t, (integralFace a i (U j) t)^2 ∂Measure.pi (fun _ => bandLaw a)
    Lower (fun x => pair A (moment (window x) (fun n => Literal.value (ch x) (n+h i)*Z x n) (V x)))
      (∑ j, min (l*A j j) (u*A j j) * E j) L := by
  classical
  intro h U V Z E
  let M := fun x => moment (window x) (fun n => Literal.value (ch x) (n+h i)*Z x n) (V x)
  have entry (x : ℝ) (j k : J) : M x j k = (∑ n ∈ window x,
      if Nat.ModEq (presievingModulus H x) n (v x) then
        Literal.value (ch x) (n+h i)*V x n j*V x n k else 0)/markedScale H x := by
    rw [Finset.sum_div]
    apply Finset.sum_congr rfl
    intro n _
    by_cases ok : Nat.ModEq (presievingModulus H x) n (v x)
    · simp [Z,ok,div_eq_mul_inv]; ring
    · simp [Z,ok]
  have limit (j k : J) : Tendsto (fun x => A j k * M x j k) L
      (𝓝 (if j=k then A j j * (d*E j) else 0)) := by
    by_cases az : A j k = 0
    · by_cases eq : j=k
      · subst k; simpa [az] using (tendsto_const_nhds (x := (0:ℝ)) (f := L))
      · simpa [az,eq] using (tendsto_const_nhds (x := (0:ℝ)) (f := L))
    have lim := priced_sector_limit L cofinal ch bands cuts H hH i a inc first last (P j) (P k)
      (F j) (F k) (bf j) (bf k) (mf j) (mf k) (cf j) (cf k) v I d (gate j k az) density
    by_cases eq : j=k
    · subst k
      simpa only [entry,ite_true,E,U,h,V,pow_two] using lim.const_mul (A j j)
    · rw [ite_eq_right eq]
      simpa only [entry,U,h,V,mixed_energy a i (P j) (P k) (F j) (F k) (sep j k eq),mul_zero] using
        lim.const_mul (A j k)
  have lim : Tendsto (fun x => pair A (M x)) L (𝓝 (∑ j, A j j*(d*E j))) := by
    simpa [pair] using tendsto_finsetSum Finset.univ
      (fun j _ => tendsto_finsetSum Finset.univ (fun k _ => limit j k))
  have safe : (∑ j, min (l*A j j) (u*A j j) * E j) ≤ ∑ j, A j j*(d*E j) := by
    apply Finset.sum_le_sum
    intro j _
    have below : min (l*A j j) (u*A j j) ≤ d*A j j := by
      by_cases pos : 0 ≤ A j j
      · rw [← min_mul_of_nonneg _ _ pos]
        exact mul_le_mul_of_nonneg_right enclose.1 pos
      · have neg := le_of_lt (lt_of_not_ge pos)
        rcases le_total l u with order | order
        · exact (min_le_right _ _).trans (mul_le_mul_of_nonpos_right (enclose.2.trans_eq (max_eq_right order)) neg)
        · exact (min_le_left _ _).trans (mul_le_mul_of_nonpos_right (enclose.2.trans_eq (max_eq_left order)) neg)
    exact (mul_le_mul_of_nonneg_right below (integral_nonneg fun _ => sq_nonneg _)).trans_eq (by ring)
  intro ε he
  exact (lim.eventually_const_le (by linarith only [he,safe]))

#print axioms signed_price_row
end PrimeGap180.Sector
