import TrialPriceWordText180
import Mathlib.Data.List.Forall2

namespace PrimeGap180.PriceWordText
open PriceRowBinding PriceFactorSource

def join : List String → String
  | [] => ""
  | s::ss => s ++ join ss

theorem flatten_text (xs : List (List Char)) : String.ofList xs.flatten = join (xs.map String.ofList) := by
  induction xs with
  | nil => rfl
  | cons a as ih =>
    change String.ofList (a ++ as.flatten) = String.ofList a ++ join (as.map String.ofList)
    rw [String.ofList_append,ih]

def RowMatch (rank n : Nat) (s : String) : Prop :=
  ∃ ws : List Nat, ws.length=rank ∧ pack ws=n ∧ String.ofList (characters ws)=s

theorem row_match (rank n : Nat) (s : String) (ws : List Nat) (length : ws.length=rank)
    (num : pack ws=n) (chars : String.ofList (characters ws)=s) : RowMatch rank n s :=
  ⟨ws,length,num,chars⟩

private theorem witnesses {rank : Nat} {nums : List Nat} {ss : List String}
    (ok : List.Forall₂ (RowMatch rank) nums ss) :
    ∃ rows : List (List Nat), (∀ ws ∈ rows, ws.length=rank) ∧
      nums = rows.map pack ∧ ss = (rows.map characters).map String.ofList := by
  induction ok with
  | nil => exact ⟨[],by simp, rfl,rfl⟩
  | cons h _ ih =>
    obtain ⟨w,hl,hn,ht⟩ := h
    obtain ⟨ws,hw,hu,hs⟩ := ih
    exact ⟨w::ws,by simpa using And.intro hl hw,by simp [hu,hn],by simp [hs,ht]⟩

private def pick (rows : List (List Nat)) (g : Nat) := rows[g]?.getD []

private theorem as_list (rows : List (List Nat)) (rank : Nat)
    (length : ∀ ws ∈ rows, ws.length=rank) :
    (sourceMatrix rows.length rank (fun g => (rows.map pack)[g]?.getD 0)).2 =
      join ((rows.map characters).map String.ofList) := by
  have lens (g : Nat) (hg : g<rows.length) : (pick rows g).length=rank := by
    simp only [pick,List.getElem?_eq_getElem hg,Option.getD_some]
    exact length _ (List.getElem_mem hg)
  have ps (g : Nat) : (rows.map pack)[g]?.getD 0 = pack (pick rows g) := by
    by_cases h : g < rows.length
    · simp [pick,List.getElem?_eq_getElem h,List.getElem?_eq_getElem (by simpa using h : g < (rows.map pack).length)]
    · simp [pick,List.getElem?_eq_none (by omega : rows.length ≤ g),List.getElem?_eq_none (by simpa using Nat.le_of_not_gt h : (rows.map pack).length ≤ g),pack]
  rw [show (fun g => (rows.map pack)[g]?.getD 0) = (fun g => pack (pick rows g)) from funext ps,← as_matrix rows.length rank (pick rows) lens]
  unfold text
  rw [← flatten_text]
  apply congrArg String.ofList
  have idx : (List.range rows.length).map (pick rows) = rows := by
    apply List.ext_getElem
    · simp
    · intro i _ hi; simp [pick,List.getElem?_eq_getElem hi]
  rw [← List.flatMap_map]
  exact congrArg (fun xs => xs.flatMap characters) idx

theorem slot {p : Nat × String} {s : Nat × Array Nat} {rank : Nat} {nums : List Nat} {ss : List String}
    (nrows : nums.length=445) (named : s = (rank,nums.toArray)) (original : p=(rank,join ss))
    (cert : List.Forall₂ (RowMatch rank) nums ss) : p=physical s := by
  subst p; subst s
  obtain ⟨ws,hl,rfl,rfl⟩ := witnesses cert
  have card : ws.length=445 := by simpa using nrows
  apply Prod.ext
  · rfl
  symm
  change (sourceMatrix 445 rank (fun g => ((ws.map pack).toArray[g]?).getD 0)).2 = _
  simp only [List.getElem?_toArray,←card]
  exact as_list ws rank hl

#print axioms slot
end PrimeGap180.PriceWordText
