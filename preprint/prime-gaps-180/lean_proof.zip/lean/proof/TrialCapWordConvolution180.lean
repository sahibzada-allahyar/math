import TrialParallelConvolution180

/-! Integer-word checks for outward-rounded polynomial products on the
130,965-degree cap grid. A single mask check bounds every input lane. -/
noncomputable section
open scoped Polynomial BigOperators
open Polynomial
namespace PrimeGap180.CapWordConvolution
open ParallelDyad ParallelConvolution

theorem eval_unpack (w n x : ℕ) : (unpack w n x).eval (2^w) = x%(2^w)^n := by
  induction n with
  | zero => simp [unpack,Nat.mod_one]
  | succ n ih =>
    simp only [unpack,eval_finsetSum,eval_monomial] at ih ⊢
    rw [Finset.sum_range_succ,ih,Nat.mod_pow_succ]
    simp only [lane]
    ring

theorem lane_and (w i x y : ℕ) :
    lane w i (x &&& y) = lane w i x &&& lane w i y := by
  apply Nat.eq_of_testBit_eq
  intro j
  simp [lane,←Nat.pow_mul,Nat.testBit_div_two_pow,Nat.testBit_and,Bool.and_assoc,
    Bool.and_left_comm]

def mask (w b n x : ℕ) : Bool := x &&& repeated w (2^b-1) n == x

theorem lane_bound {w b n x : ℕ} (hw : 0<w) (hb : b≤w) (valid : mask w b n x=true)
    (i : ℕ) (hi : i<n) : lane w i x ≤ 2^b-1 := by
  have pos := Nat.two_pow_pos b
  have small : 2^b-1 < 2^w := by have := Nat.pow_le_pow_right (by decide : 0<2) hb;omega
  have hx : x &&& repeated w (2^b-1) n = x := beq_iff_eq.mp valid
  have h := congrArg (lane w i) hx
  rw [lane_and,lane_repeat w _ n i hw small hi] at h
  exact h ▸ Nat.and_le_right

theorem eval_one_le {w b n x : ℕ} (hw : 0<w) (hb : b≤w) (ok : mask w b n x=true) :
    (unpack w n x).eval 1 ≤ n*(2^b-1) := by
  simp only [unpack,eval_finsetSum,eval_monomial,one_pow,mul_one]
  calc
    _ ≤ ∑ _ ∈ Finset.range n,(2^b-1) := Finset.sum_le_sum fun i hi =>
      lane_bound hw hb ok i (Finset.mem_range.mp hi)
    _ = _ := by simp

def wordLow (w s n x y : ℕ) := down w s n ((x%(2^w)^n)*(y%(2^w)^n))
def wordHigh (w s n x y : ℕ) := down w s n ((x%(2^w)^n)*(y%(2^w)^n)+repeated w (2^s-1) n)

theorem product (w s n b : ℕ) (f g : ℝ[X]) (x X y Y : ℕ) (hw : 0<w) (hs : s≤w) (hb : b≤w)
    (mx : mask w b n x=true) (mX : mask w b n X=true) (my : mask w b n y=true) (mY : mask w b n Y=true)
    (budget : (n*(2^b-1))*(n*(2^b-1))+n*(2^s-1)<2^w)
    (left : DirectedConvolution.encloses n (2^s) f (unpack w n x) (unpack w n X))
    (right : DirectedConvolution.encloses n (2^s) g (unpack w n y) (unpack w n Y)) :
    DirectedConvolution.encloses n (2^s) (f*g)
      (unpack w n (wordLow w s n x y)) (unpack w n (wordHigh w s n X Y)) := by
  have fitL := Nat.mul_le_mul (eval_one_le hw hb mx) (eval_one_le hw hb my)
  have fitH := Nat.mul_le_mul (eval_one_le hw hb mX) (eval_one_le hw hb mY)
  have z : (bias (2^s-1) n).eval 1 = n*(2^s-1) := by simp [bias,eval_finsetSum]
  simpa only [low,high,eval_unpack,wordLow,wordHigh] using ParallelConvolution.product w s n f g
    (unpack w n x) (unpack w n X) (unpack w n y) (unpack w n Y) hw hs left right
    (lt_of_le_of_lt fitL (by omega)) (by rw [z]; omega)

#print axioms product
end PrimeGap180.CapWordConvolution
