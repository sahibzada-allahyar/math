import TrialPrimeRadialPrice180
import TrialRadialLaw180
import BandRadialPartition182

/-! Split an existing signed sector into the prime-price slices. The sampled
root and its weighted continuum square reconstruct the original sector. -/
noncomputable section
open scoped Classical BigOperators Topology
open Filter MeasureTheory PrimeGap186 PrimeGap182Analytic
namespace PrimeGap180.Sector

set_option maxRecDepth 16384
set_option maxHeartbeats 800000

def radialSlice {m : ℕ} (P : (Fin 38 → Band m) → Prop) (j : Slice) (y : Fin 38 → Band m) : Prop :=
  P y ∧ inSlice j (retainedRadius y)

private theorem slice_sum {m : ℕ} (P : (Fin 38 → Band m) → Prop)
    (bound : ∀ y, P y → 0 ≤ retainedRadius y ∧ retainedRadius y ≤ 0.2801)
    (y : Fin 38 → Band m) (g : ℝ) :
    (∑ j : Slice, if radialSlice P j y then g else 0) = if P y then g else 0 := by
  by_cases hit : P y
  · obtain ⟨b,hb,only⟩ := unique_slice (bound y hit).1 (bound y hit).2
    rw [Finset.sum_eq_single b]
    · simp [radialSlice,hit,hb]
    · intro j _ ne
      simp [radialSlice,show ¬inSlice j (retainedRadius y) from fun hj => ne (only j hj)]
    · simp
  · simp [radialSlice,hit]

theorem sliced_face_sum {m : ℕ} (H : Finset ℕ) (a : Fin (m+2) → ℝ) (k : Fin 39)
    (P : (Fin 38 → Band m) → Prop) (F : Profile 39 m)
    (bound : ∀ y, P y → 0 ≤ retainedRadius y ∧ retainedRadius y ≤ 0.2801) (x : ℝ) :
    (∑ j : Slice, face H a k (restrictFace k (radialSlice P j) F) x) = face H a k (restrictFace k P F) x := by
  apply Finsupp.ext
  intro r
  simp only [Finsupp.finsetSum_apply,face_restrict]
  exact slice_sum P bound _ _

theorem sliced_root_sum {m : ℕ} (H : Finset ℕ) (a : Fin (m+2) → ℝ) (k : Fin 39)
    (P : (Fin 38 → Band m) → Prop) (F : Profile 39 m)
    (bound : ∀ y, P y → 0 ≤ retainedRadius y ∧ retainedRadius y ≤ 0.2801) (x : ℝ) (v : Fin 38 → ℕ) :
    (∑ j : Slice, sampledSelbergRoot (face H a k (restrictFace k (radialSlice P j) F) x) v) =
      sampledSelbergRoot (face H a k (restrictFace k P F) x) v := by
  rw [← sampledSelbergRoot_finsetSum]
  exact congrArg (fun z => sampledSelbergRoot z v) (sliced_face_sum H a k P F bound x)


theorem integralFace_restrict {m : ℕ} (a : Fin (m+2) → ℝ) (k : Fin 39)
    (P : (Fin 38 → Band m) → Prop) (F : Profile 39 m) (y : Fin 38 → Band m) :
    integralFace a k (restrictFace k P F) y = if P y then integralFace a k F y else 0 := by
  by_cases test : P y <;> simp [integralFace,restrictFace,Fin.removeNth_insertNth,test]

theorem sliced_energy_sum {m : ℕ} (a : Fin (m+2) → ℝ) (k : Fin 39)
    (P : (Fin 38 → Band m) → Prop) (F : Profile 39 m)
    (bound : ∀ y, P y → 0 ≤ retainedRadius y ∧ retainedRadius y ≤ 0.2801)
    (ok : ∀ j, Integrable (fun y => primePrice (retainedRadius y)*
      (integralFace a k (restrictFace k (radialSlice P j) F) y)^2) (Measure.pi fun _ => bandLaw a)) :
    (∑ j : Slice, ∫ y, primePrice (retainedRadius y)*(integralFace a k (restrictFace k (radialSlice P j) F) y)^2
      ∂Measure.pi (fun _ => bandLaw a)) =
      ∫ y, primePrice (retainedRadius y)*(integralFace a k (restrictFace k P F) y)^2
      ∂Measure.pi (fun _ => bandLaw a) := by
  rw [←integral_finsetSum Finset.univ (fun j _ => ok j)]
  apply integral_congr_ae
  apply ae_of_all
  intro y
  simp only [integralFace_restrict,ite_pow,zero_pow (by decide : 2≠0),mul_ite,mul_zero]
  exact slice_sum P bound _ _

/-- The original unsliced signed amplitude has the variable continuum price.
The fixed subdivision is used only inside the proof. -/
theorem prime_sector_price {m : ℕ} {J : Type*} [Fintype J] (H : Finset ℕ) (hH : H.card=39)
    (k : Fin 39) (a : Fin (m+2) → ℝ) (ha : StrictMono a) (first : a 0 = 0)
    (last : a (Fin.last (m+1)) = cap) (P : J → (Fin 38 → Band m) → Prop) (F : J → Profile 39 m)
    (sep : ∀ j t, j≠t → ∀ y, P j y → ¬ P t y)
    (bf : ∀ j, Bornology.IsBounded (Set.range (F j)))
    (rad : ∀ j y, P j y → 0 ≤ retainedRadius y ∧ retainedRadius y ≤ 0.2801)
    (mf : ∀ j e, Measurable (restrictFace k (radialSlice (P j) e) (F j)))
    (cf : ∀ j e, ∀ᵐ y ∂Measure.pi (fun _ => bandLaw a), ContinuousAt (restrictFace k (radialSlice (P j) e) (F j)) y)
    (ok : ∀ j e, Integrable (fun y => primePrice (retainedRadius y)*
      (integralFace a k (restrictFace k (radialSlice (P j) e) (F j)) y)^2) (Measure.pi fun _ => bandLaw a))
    (b : ℝ → ℕ) {ε : ℝ} (he : 0 < ε) :
    let Z := fun j => restrictFace k (P j) (F j)
    let h : Fin 39 → ℕ := H.orderEmbOfFin hH
    ∀ᶠ x : ℝ in atTop, (∑ n ∈ Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊, if Nat.ModEq (presievingModulus H x) n (b x) ∧
      (n+h k).Prime then (∑ j, sampledSelbergRoot (face H a k (Z j) x) (fun t => n+h (k.succAbove t)))^2 else 0) /
      markedScale H x ≤ (∑ j, ∫ y, primePrice (retainedRadius y)*(integralFace a k (Z j) y)^2
      ∂Measure.pi (fun _ => bandLaw a))+ε := by
  intro Z h
  let D (v : J × Slice) := radialSlice (P v.1) v.2
  have disj (v w : J × Slice) (ne : v≠w) (y) (hv : D v y) (hw : D w y) : False := by
    by_cases same : v.1=w.1
    · obtain ⟨j,_,only⟩ := unique_slice (rad v.1 y hv.1).1 (rad v.1 y hv.1).2
      exact ne (Prod.ext same ((only _ hv.2).trans (only _ hw.2).symm))
    · exact sep _ _ same y hv.1 hw.1
  have law := prime_radial_upper H hH k a ha first last D (fun v => F v.1) disj
    (fun v => bf v.1) (fun v => mf v.1 v.2) (fun v => cf v.1 v.2) Prod.snd (fun _ _ mem => mem.2)
    b (fun v => ok v.1 v.2) he
  filter_upwards [law] with x paid
  simpa only [D,Fintype.sum_prod_type,fun j => sliced_energy_sum a k (P j) (F j) (rad j) (ok j),
    fun j => sliced_root_sum H a k (P j) (F j) (rad j) x,Z,h] using paid

private theorem signed_slice_regular {m : ℕ} (a : Fin (m+2) → ℝ) (ha : StrictMono a)
    (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap) (k : Fin 39)
    (P : (Fin 38 → Band m) → Prop) (F : Profile 39 m) (j : Slice)
    (mf : Measurable (restrictFace k P F))
    (cf : ∀ᵐ y ∂Measure.pi (fun _ => bandLaw a), ContinuousAt (restrictFace k P F) y) :
    Measurable (restrictFace k (radialSlice P j) F) ∧
      ∀ᵐ y ∂Measure.pi (fun _ => bandLaw a), ContinuousAt (restrictFace k (radialSlice P j) F) y := by
  have reg := radial_slab_regular a ha first last k (sliceLo j) (sliceHi j) (restrictFace k P F) mf cf
  have eq : restrictFace k (radialSlice P j) F =
      restrictFace k (fun y => inSlice j (retainedRadius y)) (restrictFace k P F) := by
    funext y
    dsimp only [restrictFace,radialSlice]
    by_cases hP : P (k.removeNth y) <;> by_cases hj : inSlice j (retainedRadius (k.removeNth y)) <;> simp [hP,hj]
  rw [eq]
  exact reg

private theorem priced_slice_integrable {m : ℕ} (a : Fin (m+2) → ℝ) (k : Fin 39)
    (P : (Fin 38 → Band m) → Prop) (F : Profile 39 m) (j : Slice)
    (bf : Bornology.IsBounded (Set.range F)) (mf : Measurable (restrictFace k (radialSlice P j) F)) :
    Integrable (fun y => primePrice (retainedRadius y)*(integralFace a k (restrictFace k (radialSlice P j) F) y)^2)
      (Measure.pi (fun _ => bandLaw a)) := by
  let _ := bandLaw_finite a
  let Z := restrictFace k (radialSlice P j) F
  let V := integralFace a k Z
  obtain ⟨B,_,bounded⟩ := bf.exists_pos_norm_le
  have zbound (t) : ‖Z t‖ ≤ B := by
    dsimp only [Z,restrictFace]
    split_ifs
    · exact bounded _ ⟨t,rfl⟩
    · simp; exact (norm_nonneg (F t)).trans (bounded _ ⟨t,rfl⟩)
  have vins (y) : ‖V y‖ ≤ B*(bandLaw a).real Set.univ := norm_integral_le_of_norm_le_const
    (μ := bandLaw a) (Eventually.of_forall fun t => zbound (k.insertNth t y))
  have vm : Measurable V := by
    have insert : Measurable (fun p : (Fin 38 → Band m) × Band m =>
        k.insertNth (α := fun _ => Band m) p.2 p.1) := (continuous_snd.finInsertNth k continuous_fst).measurable
    exact ((mf.comp insert).stronglyMeasurable.integral_prod_right').measurable
  have rad : Continuous (@retainedRadius m) := by unfold retainedRadius; fun_prop
  have km : Measurable (fun y : Fin 38 → Band m => primePrice (retainedRadius y)) :=
    measurable_const.div (measurable_const.sub rad.measurable)
  apply integrable_of_measurable_of_bounded_range _ _ (km.mul (vm.pow_const 2))
  apply isBounded_iff_forall_norm_le.mpr
  refine ⟨5*(B*(bandLaw a).real Set.univ)^2,?_⟩
  rintro _ ⟨y,rfl⟩
  by_cases hit : radialSlice P j y
  · have jhi : (j.val:ℝ)<5603 := by exact_mod_cast j.isLt
    have qhi : retainedRadius y < 0.281 := by
      linarith only [jhi,(show retainedRadius y < ((j.val:ℝ)+1)/20000 from hit.2.2)]
    have pos : 0 < 0.4999-retainedRadius y := by linarith
    have kp : ‖primePrice (retainedRadius y)‖ ≤ 5 := by
      rw [primePrice,Real.norm_eq_abs,abs_of_pos (one_div_pos.mpr pos),div_le_iff₀ pos]
      linarith
    change ‖primePrice (retainedRadius y) * (V y)^2‖ ≤ _
    rw [norm_mul,norm_pow]
    exact mul_le_mul kp (pow_le_pow_left₀ (norm_nonneg _) (vins y) 2) (by positivity) (by norm_num)
  · have zero := integralFace_restrict a k (radialSlice P j) F y
    simp only [hit,ite_false] at zero
    change ‖primePrice (retainedRadius y) * (integralFace a k (restrictFace k (radialSlice P j) F) y)^2‖ ≤ _
    rw [zero,zero_pow (by decide : 2≠0),mul_zero,norm_zero]
    positivity

/-- Every original sector may retain its own signed profile. Boundedness,
measurability and almost-everywhere continuity on the original sectors
suffice for the exact variable prime kernel. -/
theorem prime_sector_price_of_regular {m : ℕ} {J : Type*} [Fintype J] (H : Finset ℕ) (hH : H.card=39)
    (k : Fin 39) (a : Fin (m+2) → ℝ) (ha : StrictMono a) (first : a 0 = 0)
    (last : a (Fin.last (m+1)) = cap) (P : J → (Fin 38 → Band m) → Prop) (F : J → Profile 39 m)
    (sep : ∀ j t, j≠t → ∀ y, P j y → ¬ P t y)
    (bf : ∀ j, Bornology.IsBounded (Set.range (F j)))
    (rad : ∀ j y, P j y → 0 ≤ retainedRadius y ∧ retainedRadius y ≤ 0.2801)
    (mf : ∀ j, Measurable (restrictFace k (P j) (F j)))
    (cf : ∀ j, ∀ᵐ y ∂Measure.pi (fun _ => bandLaw a), ContinuousAt (restrictFace k (P j) (F j)) y)
    (b : ℝ → ℕ) {ε : ℝ} (he : 0 < ε) :
    let Z := fun j => restrictFace k (P j) (F j)
    let h : Fin 39 → ℕ := H.orderEmbOfFin hH
    ∀ᶠ x : ℝ in atTop, (∑ n ∈ Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊, if Nat.ModEq (presievingModulus H x) n (b x) ∧
      (n+h k).Prime then (∑ j, sampledSelbergRoot (face H a k (Z j) x) (fun t => n+h (k.succAbove t)))^2 else 0) /
      markedScale H x ≤ (∑ j, ∫ y, primePrice (retainedRadius y)*(integralFace a k (Z j) y)^2
      ∂Measure.pi (fun _ => bandLaw a))+ε := by
  have reg := fun j e => signed_slice_regular a ha first last k (P j) (F j) e (mf j) (cf j)
  exact prime_sector_price H hH k a ha first last P F sep bf rad
    (fun j e => (reg j e).1) (fun j e => (reg j e).2)
    (fun j e => priced_slice_integrable a k (P j) (F j) e (bf j) (reg j e).1) b he

#print axioms prime_sector_price_of_regular
#print axioms prime_sector_price
#print axioms sliced_root_sum
#print axioms sliced_energy_sum
end PrimeGap180.Sector
