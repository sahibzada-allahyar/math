import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G282
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 282

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G282

namespace PrimeGap180.PriceIsolatedGroup.G287
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 287

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G287

namespace PrimeGap180.PriceIsolatedGroup.G292
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 292

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G292

namespace PrimeGap180.PriceIsolatedGroup.G297
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 297

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G297
