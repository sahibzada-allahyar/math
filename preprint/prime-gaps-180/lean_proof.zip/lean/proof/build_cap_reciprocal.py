"""Regenerate the cap-36 reciprocal endpoint enclosure from the physical grid."""
from pathlib import Path

from build_historical_site_rows import columns
from check_exact_endpoint_pair import STEP, site
from endpoint_pair_arithmetic import COUNT, encode

HERE = Path(__file__).resolve().parent
MODULE = "TrialCapAtomR180"


def generate(destination):
    destination.mkdir(parents=True, exist_ok=True)
    ordinary = site(columns()[36][:COUNT])
    numerator, step_denominator = STEP.as_integer_ratio()
    twice_denominator = 2*step_denominator
    lower, upper = [], []
    for j, (lo, hi) in enumerate(zip(ordinary.low, ordinary.high, strict=True)):
        denominator = twice_denominator+300*(2*j+1)*numerator
        lower.append(lo*twice_denominator//denominator)
        upper.append((hi*twice_denominator+denominator-1)//denominator)
    for label, values in [("lo", lower), ("hi", upper)]:
        (destination/f"atom-r-{label}.bin").write_bytes(encode(values, 80))
    source = destination/(MODULE+".lean")
    source.write_bytes((HERE/(MODULE+".lean.in")).read_bytes())
    return {MODULE: source}
