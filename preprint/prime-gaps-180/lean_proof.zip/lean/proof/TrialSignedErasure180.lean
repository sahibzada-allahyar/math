import TrialRemovedPairSchur180

/-! Polarization on the actual signed single-site and endpoint fibres. -/
noncomputable section
open scoped Classical BigOperators Topology
open MeasureTheory PrimeGap186 PrimeGap180.Sector PrimeGap180.CoarseLaw PrimeGap180.EndpointPhysical
open PrimeGap180.PhysicalDebit (Regular)
namespace PrimeGap180.SignedErasure

abbrev Full := Fin 39 → B
abbrev Face := Fin 38 → B
abbrev Interior := Fin 37 → B
local instance : IsFiniteMeasure μ := bandLaw_finite _

open private raw_reg deleted_reg face_reg face_sub from TrialPhysicalDebit180
open private average from TrialAdverseScore180

private def reciprocal (d j : ℕ) : ℝ := 1 / (ledger-Native.adverse (d := d) j)

/-- The reciprocal is evaluated on a discrete lattice. A finite initial segment
contains all possible near-pole values, and uniformly past it the distance is ≥ 1. -/
private theorem reciprocal_bounded (d : ℕ) : Bornology.IsBounded (Set.range (reciprocal d)) := by
  obtain ⟨C,_,small⟩ := (Set.finite_range (fun k : Fin 2000001 => reciprocal d k.val)).isBounded.exists_pos_norm_le
  refine isBounded_iff_forall_norm_le.mpr ⟨max C 1,?_⟩
  rintro _ ⟨j,rfl⟩
  by_cases hj : j < 2000001
  · exact (small _ ⟨⟨j,hj⟩,rfl⟩).trans (le_max_left _ _)
  · have lower : (2000000:ℝ) ≤ j := by exact_mod_cast (show 2000000 ≤ j by omega)
    have far : 1 ≤ Native.adverse (d := d) j - ledger := by
      unfold Native.adverse Native.step ledger rho
      linarith only [lower,Nat.cast_nonneg (α := ℝ) d]
    apply le_trans _ (le_max_right _ _)
    rw [reciprocal,Real.norm_eq_abs,abs_div,abs_one,abs_of_nonpos (by linarith only [far])]
    exact (div_le_iff₀ (by linarith only [far])).mpr (by linarith only [far])

private theorem cell_meas (d : ℕ) : Measurable (@Native.cellSum 216 d) := by
  unfold Native.cellSum Native.cell
  fun_prop

private theorem reciprocal_reg (d : ℕ) : Regular (fun v : Fin d → B => reciprocal d (Native.cellSum v)) :=
  ⟨(measurable_of_countable (reciprocal d)).comp (cell_meas d),
   (reciprocal_bounded d).subset (Set.range_comp_subset_range (@Native.cellSum 216 d) (reciprocal d))⟩

theorem continuous_reg {X : Type*} [MeasurableSpace X] {f : X → ℝ} (hf : Regular f)
    (g : ℝ → ℝ) (hg : Continuous g) : Regular (fun x => g (f x)) := by
  refine ⟨hg.measurable.comp hf.1,?_⟩
  obtain ⟨C,_,bound⟩ := hf.2.exists_pos_norm_le
  apply ((isCompact_Icc (a := -C) (b := C)).image hg).isBounded.subset
  rintro _ ⟨x,rfl⟩
  exact ⟨f x,abs_le.mp (by simpa [Real.norm_eq_abs] using bound _ ⟨x,rfl⟩),rfl⟩

theorem prod_reg {X : Type*} [MeasurableSpace X] {f g : X → ℝ} (hf : Regular f) (hg : Regular g) :
    Regular (fun x => f x*g x) := by
  obtain ⟨C,hC,bf⟩ := hf.2.exists_pos_norm_le
  obtain ⟨D,_,bg⟩ := hg.2.exists_pos_norm_le
  refine ⟨hf.1.mul hg.1,isBounded_iff_forall_norm_le.mpr ⟨C*D,?_⟩⟩
  rintro _ ⟨x,rfl⟩
  rw [norm_mul]
  exact mul_le_mul (bf _ ⟨x,rfl⟩) (bg _ ⟨x,rfl⟩) (norm_nonneg _) hC.le

def facePrice (s : Fin 521) (v : Face) := NativeContractions.price s (Native.cellSum v)
def pairPrice (v : Interior) := 2*rho^2/(ledger-Native.adverse (d := 37) (Native.cellSum v))^2
def pairAvg (F : Full → ℝ) (r : Interior) := ∫ l, ∫ h, F (join r l h) ∂μ ∂μ

theorem face_price_reg (s : Fin 521) : Regular (facePrice s) := by
  change Regular (fun v : Face => NativeContractions.price s (Native.cellSum v))
  have eq : (0.4999:ℝ) = ledger := by norm_num [ledger]
  simp only [NativeContractions.price,Sector.primePrice,eq]
  exact continuous_reg (reciprocal_reg 38)
    (fun q => (((AdverseScore.oldPrice s).1:ℝ)+(AdverseScore.oldPrice s).2*q)/10^14) (by fun_prop)

theorem pair_price_reg : Regular pairPrice := by
  have h := continuous_reg (reciprocal_reg 37) (fun q => 2*rho^2*q^2) (by fun_prop)
  change Regular (fun v : Interior => 2*rho^2/(ledger-Native.adverse (d := 37) (Native.cellSum v))^2)
  simpa [reciprocal,div_eq_mul_inv,inv_pow] using h

theorem pair_reg {F : Full → ℝ} (hf : Regular F) : Regular (pairAvg F) := by
  let j := fun p : (Interior × B) × B => join p.1.1 p.1.2 p.2
  have cj : Continuous j := by dsimp [j,join]; fun_prop
  have inn := average μ (F ∘ j) (hf.1.comp cj.measurable) (hf.2.subset (Set.range_comp_subset_range _ _))
  exact average μ _ inn.1 inn.2

private theorem pair_sub (r : Interior) : pairAvg FrozenData.trial r =
    pairAvg Restoration.original r - pairAvg Restoration.deleted r := by
  let j := fun p : B × B => join r p.1 p.2
  have cj : Continuous j := by dsimp [j,join]; fun_prop
  have good {F : Full → ℝ} (hf : Regular F) : Integrable (F ∘ j) (μ.prod μ) :=
    integrable_of_measurable_of_bounded_range _ _ (hf.1.comp cj.measurable) (hf.2.subset (Set.range_comp_subset_range _ _))
  have tr : Regular FrozenData.trial := ⟨FrozenData.trial_regular.1,FrozenData.trial_bounded⟩
  have one {F : Full → ℝ} (hf : Regular F) : pairAvg F r = ∫ z, (F ∘ j) z ∂μ.prod μ :=
    (integral_prod (F ∘ j) (good hf)).symm
  rw [one tr, one raw_reg, one deleted_reg]
  change _ = _ - ∫ z, (Restoration.original ∘ j) z - (FrozenData.trial ∘ j) z ∂μ.prod μ
  rw [integral_sub (good raw_reg) (good tr)]
  ring

private theorem polar {X : Type*} [MeasurableSpace X] (ν : Measure X) [IsFiniteMeasure ν]
    {w a b t : X → ℝ} (hw : Regular w) (ha : Regular a) (hb : Regular b) (ht : Regular t)
    (diff : ∀ x, t x = a x - b x) :
    (∫ x,w x*(a x)^2 ∂ν) - (∫ x,w x*(t x)^2 ∂ν) =
      2*(∫ x,w x*a x*b x ∂ν) - (∫ x,w x*(b x)^2 ∂ν) := by
  have intg {f : X → ℝ} (hf : Regular f) := integrable_of_measurable_of_bounded_range ν _ hf.1 hf.2
  have sq {f : X → ℝ} (hf : Regular f) := continuous_reg hf (fun v => v^2) (by fun_prop)
  have mix := intg (prod_reg (prod_reg hw ha) hb)
  rw [←integral_sub (intg (prod_reg hw (sq ha))) (intg (prod_reg hw (sq ht))),
    ←integral_const_mul,←integral_sub (mix.const_mul 2) (intg (prod_reg hw (sq hb)))]
  apply integral_congr_ae
  apply ae_of_all
  intro x
  simp only [diff]
  ring

def mixedSingle (i : Fin 39) (s : Fin 521) := ∫ v : Face,
  facePrice s v * PhysicalDebit.face Restoration.original i s v * PhysicalDebit.face Restoration.deleted i s v ∂prod 38

def mixedPair := ∫ r : Interior,
  pairPrice r * pairAvg Restoration.original r * pairAvg Restoration.deleted r ∂prod 37

def mixed := rho * ∑ i, ∑ s, mixedSingle i s - mixedPair

theorem single_identity (i : Fin 39) :
    AdverseScore.historicalFor Restoration.original i - AdverseScore.historicalFor FrozenData.trial i =
    2*(∑ s, mixedSingle i s) - AdverseScore.historicalFor Restoration.deleted i := by
  unfold AdverseScore.historicalFor
  rw [←Finset.sum_sub_distrib,Finset.mul_sum,←Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro s _
  exact polar (prod 38) (face_price_reg s) (face_reg raw_reg i s) (face_reg deleted_reg i s)
    (face_reg ⟨FrozenData.trial_regular.1,FrozenData.trial_bounded⟩ i s) (face_sub i s)

theorem pair_identity : NumericalAccount.pairFor Restoration.original - NumericalAccount.pairFor FrozenData.trial =
    2*mixedPair - NumericalAccount.pairFor Restoration.deleted :=
  polar (prod 37) pair_price_reg (pair_reg raw_reg) (pair_reg deleted_reg)
    (pair_reg ⟨FrozenData.trial_regular.1,FrozenData.trial_bounded⟩) pair_sub

/-- Identity for the actual signed restoration loss. Both self-terms use the whole deleted vector. -/
theorem restored_identity : NumericalAccount.restoredLoss =
    2*mixed - NumericalAccount.historical Restoration.deleted + NumericalAccount.pairFor Restoration.deleted -
      NumericalAccount.mass Restoration.deleted := by
  have each := Finset.sum_congr (s₁ := Finset.univ) rfl (fun i _ => single_identity i)
  rw [Finset.sum_sub_distrib,Finset.sum_sub_distrib,←Finset.mul_sum] at each
  unfold NumericalAccount.restoredLoss NumericalAccount.numerator NumericalAccount.historical mixed
  linear_combination rho * each - pair_identity

/-- Accounting for the signed pair self-interaction gives back at least 0.6865 times
the removed mass before pricing the single-site self-term and the mixed fields. -/
theorem loss_upper : NumericalAccount.restoredLoss ≤
    2*mixed - NumericalAccount.historical Restoration.deleted - 0.6865*NumericalAccount.mass Restoration.deleted := by
  rw [restored_identity]
  linarith only [RemovedPairSupport.deleted_pair]

#print axioms restored_identity
#print axioms loss_upper
end PrimeGap180.SignedErasure
