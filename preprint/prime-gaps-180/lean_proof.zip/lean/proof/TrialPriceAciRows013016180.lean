import TrialPriceIsolatedChecks180
import TrialPriceGroupElab180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G013
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifySignedPriceGroup 13

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G013

namespace PrimeGap180.PriceIsolatedGroup.G014
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifySignedPriceGroup 14

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G014

namespace PrimeGap180.PriceIsolatedGroup.G015
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifySignedPriceGroup 15

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G015

namespace PrimeGap180.PriceIsolatedGroup.G016
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifySignedPriceGroup 16

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G016
