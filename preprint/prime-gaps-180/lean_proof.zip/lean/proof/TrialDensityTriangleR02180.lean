import TrialDensityTriangleInputs180
namespace PrimeGap180.DensitySimplex.Horner.TriangleChecks
private theorem lower_den2 (z : Fin 2 → ℝ) :
    ((L 2).map (factorValue z)).prod/((unit^3:Int):ℝ) = threeDen (lowerMap (r 2) (s 2) z) := by
  have hr : r 2 = 16193999/10000000000 := by decide +kernel
  have hs : s 2 = 600990501/5000000000 := by decide +kernel
  have forms : L 2 = factors 1234369000 32387998 0 2403962004 := rfl
  rw [hr,hs,forms]
  norm_num [factors,unit,factorValue,Fin.sum_univ_two,threeDen,lowerMap] <;> ring
private theorem upper_den2 (z : Fin 2 → ℝ) :
    ((U 2).map (factorValue z)).prod/((unit^3:Int):ℝ) = threeDen (upperMap (r 2) (s 2) z) := by
  have hr : r 2 = 16193999/10000000000 := by decide +kernel
  have hs : s 2 = 600990501/5000000000 := by decide +kernel
  have forms : U 2 = factors 32387998 0 2403962004 2420156003 := rfl
  rw [hr,hs,forms]
  norm_num [factors,unit,factorValue,Fin.sum_univ_two,threeDen,upperMap] <;> ring

set_option maxRecDepth 65536 in
set_option maxHeartbeats 0 in
theorem row02 : triangleQ (r 2) (s 2) = FrozenNumbers.triangles 2 := by
  rw [triangle_from_forms _ _ (L 2) (U 2) (unit^3) (unit^3) (by decide) (by decide)
    lower_den2 upper_den2]
  decide +kernel

#print axioms row02
end PrimeGap180.DensitySimplex.Horner.TriangleChecks
