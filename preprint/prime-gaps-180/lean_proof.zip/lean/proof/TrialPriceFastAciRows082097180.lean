import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G082
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 82

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G082

namespace PrimeGap180.PriceIsolatedGroup.G087
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 87

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G087

namespace PrimeGap180.PriceIsolatedGroup.G092
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 92

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G092

namespace PrimeGap180.PriceIsolatedGroup.G097
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 97

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G097
