import TrialFiveTablePrice180
import TrialResourceEvents180

/-! The old event, twelve cumulative five-prime resources, the first
increment and the eleven cumulative increments at their actual cutoffs. -/
noncomputable section
open scoped Classical BigOperators Topology
open Filter MeasureTheory PrimeGap186 PrimeGap182Analytic
open PrimeGap180.EventBins PrimeGap180.Literal PrimeGap180.PriceEvents
namespace PrimeGap180.ClippedPair

inductive FiveRow
  | old | full (i : Fin 12) | firstExtra | extras (i : Fin 11)

def FiveRow.cut : FiveRow → ℝ
  | .old => 41361/100000
  | .full i => FiveMarks.top i
  | .firstExtra => FiveMarks.top 0
  | .extras i => FiveMarks.top i.succ

def FiveRow.incremental : FiveRow → Bool
  | .old | .full _ => false
  | .firstExtra | .extras _ => true

def FiveRow.value (row : FiveRow) (x : ℝ) (n : ℕ) := match row with
  | .old => PriceEvents.mass x n .oldFive
  | .full i => Resources.physical x n (.fullFive i)
  | .firstExtra => PriceEvents.mass x n (.newFive 0)
  | .extras i => Resources.physical x n (.extraFives i)

theorem FiveRow.value_eq (row : FiveRow) {x : ℝ} (hx : 1 ≤ x) (n : ℕ) :
    row.value x n = if Five (x^row.cut) n ∧ (row.incremental = true → ¬ Five (base x) n) then 24 else 0 := by
  cases row with
  | old => simp [FiveRow.value,FiveRow.cut,FiveRow.incremental,PriceEvents.mass,base] <;> congr!
  | full i => simp [FiveRow.value,FiveRow.cut,FiveRow.incremental,Resources.physical,high,FiveMarks.top] <;> congr!
  | extras i => simp [FiveRow.value,FiveRow.cut,FiveRow.incremental,Resources.physical,high,FiveMarks.top] <;> congr!
  | firstExtra =>
    have h := (cumulative_masses hx n 0).2.1
    have z : Finset.Iic (0:Fin 12) = {0} := by decide
    rw [z,Finset.sum_singleton] at h
    change PriceEvents.mass x n (.newFive 0) = _
    rw [h]
    simp only [FiveRow.cut,FiveRow.incremental,true_implies,high,FiveMarks.top]
    congr!

private theorem row_guards (row : FiveRow) :
    0.4136 ≤ row.cut ∧ row.cut ≤ 0.41657 ∧
      (row.incremental=true → 2*lower row.cut+104*width row.cut ≤ 41361/100000) := by
  have span (i : Fin 12) : 0.4136 ≤ FiveMarks.top i ∧ FiveMarks.top i ≤ 0.41657 := by
    fin_cases i <;> norm_num [FiveMarks.top,topTicks]
  cases row with
  | old => norm_num [FiveRow.cut,FiveRow.incremental]
  | full i => exact ⟨(span i).1,(span i).2,by simp [FiveRow.incremental]⟩
  | firstExtra => exact ⟨(span 0).1,(span 0).2,fun _ => (frozen_widths 0).2.1⟩
  | extras i => exact ⟨(span i.succ).1,(span i.succ).2,fun _ => (frozen_widths i.succ).2.1⟩

theorem frozen_table_upper {m : ℕ} {J : Type*} [Fintype J] (H : Finset ℕ) (hH : H.card = 39)
    (k : Fin 39) (smallShift : H.orderEmbOfFin hH k ≤ 182)
    (row : FiveRow) (c : Bin → ℝ) (nn : ∀ t, 0 ≤ c t) (table : TableCover row.incremental c)
    (bands : Fin (m+2) → ℝ) (inc : StrictMono bands) (first : bands 0 = 0)
    (last : bands (Fin.last (m+1)) = Sector.cap)
    (P : J → (Fin 38 → Sector.Band m) → Prop) (F : J → Sector.Profile 39 m)
    (sep : ∀ j z, j ≠ z → ∀ y, P j y → ¬ P z y) (bf : ∀ j, Bornology.IsBounded (Set.range (F j)))
    (mf : ∀ j, Measurable (Sector.restrictFace k (P j) (F j)))
    (cf : ∀ j, ∀ᵐ y ∂Measure.pi (fun _ => Sector.bandLaw bands), ContinuousAt (Sector.restrictFace k (P j) (F j)) y)
    (r : J → ℝ) (hr : ∀ j, 0 ≤ r j) (rad : ∀ j y, P j y → Sector.rho*∑ t, ∑ u, y t u ≤ r j)
    (rmax : ∀ j, r j ≤ 0.2801) (b : ℝ → ℕ) {ε : ℝ} (he : 0 < ε) :
    let h : Fin 39 → ℕ := H.orderEmbOfFin hH
    let Z := fun j => Sector.restrictFace k (P j) (F j)
    let V := fun j x n => sampledSelbergRoot (Sector.face H bands k (Z j) x) (fun q => n+h (k.succAbove q))
    let E := fun j => ∫ t, (Sector.integralFace bands k (Z j) t)^2 ∂Measure.pi (fun _ => Sector.bandLaw bands)
    let ζ := fun t j => min (lower row.cut) ((1-markExponent row.cut t)/2-r j)-0.0001
    ∀ᶠ x : ℝ in atTop, (∑ n ∈ Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊, if Nat.ModEq (presievingModulus H x) n (b x)
      then row.value x (n+h k)*
        (∑ j, V j x n)^2 else 0)/Sector.markedScale H x ≤
      (∑ t : Bin, ∑ j, (c t*price row.cut t.1 t.2)*(1/ζ t j)*E j)+ε := by
  classical
  intro h Z V E ζ
  obtain ⟨alo,ahi,cut⟩ := row_guards row
  have room (t : Bin) (j : J) : (0.0001:ℝ) < (1-markExponent row.cut t)/2-r j := by
    have le : markExponent row.cut t ≤ row.cut := min_le_left _ _
    linarith only [le,ahi,rmax j]
  have bound := table_upper H hH k smallShift row.cut (41361/100000)
    (by unfold lower; linarith) (by unfold lower; linarith) (by linarith) (by linarith)
    (by unfold pad width; linarith) row.incremental cut c nn table bands inc first last P F sep bf mf cf r hr rad
    (by norm_num : (0:ℝ)<0.0001) (by unfold lower; linarith)
    (by unfold Sector.physicalCap lower; linarith) room b he
  filter_upwards [bound,eventually_ge_atTop (1:ℝ)] with x upper hx
  simp only [FiveRow.value_eq row hx,base,V,h,Z,E,ζ]
  convert upper using 2
  apply Finset.sum_congr rfl
  intro n _
  congr!

#print axioms frozen_table_upper
end PrimeGap180.ClippedPair
