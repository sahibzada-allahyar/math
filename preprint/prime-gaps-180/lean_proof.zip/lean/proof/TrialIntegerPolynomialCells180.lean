import TrialSitePolynomials180
import TrialFrozenPolynomialCells180
import TrialHornerRounding180

/-! Fixed-point integer endpoints for the physical cumulative masses.
All evaluations refer to the same rational chart coefficients as the
delay-equation proof. The denominator of every exported endpoint is 2^111. -/
noncomputable section
open Set MeasureTheory PrimeGap186 PrimeGap180.CoarseLaw PrimeGap180.FrozenProfile
open PrimeGap180.CellQuadrature PrimeGap180.DickmanPolynomial PrimeGap180.FrozenPolynomialCells
namespace PrimeGap180.IntegerPolynomialCells

def nominal (k m c : ℕ) (q : List ℚ) : ℤ :=
  (m:ℤ)*(Horner.rounded (primitive q) scale (num (k+1) m c) m -
         Horner.rounded (primitive q) scale (num k m c) m)
def pad (m : ℕ) (q : List ℚ) (e : ℚ) : ℤ :=
  ⌈(units:ℚ)*e⌉ + 4*(m:ℤ)*(primitive q).length

def piece (k m c : ℕ) (q : List ℚ) (e : ℚ) : ℤ × ℤ :=
  let x := nominal k m c q
  let p := pad m q e
  (max 0 (x-p),min (units:ℤ) (x+p))

def ticks (k m : ℕ) : ℤ × ℤ :=
  if k < m then (units,units) else if k < 2*m then piece k m 3 p3 r3 else piece k m 5 p5 e5

private theorem coordinate_num (k m c : ℕ) (hm : 0 < m) :
    (num k m c:ℚ)/m = coordinate k m c := by
  have pos : (0:ℚ) < m := by exact_mod_cast hm
  unfold num coordinate
  push_cast
  field_simp

private theorem rounded_error (k m c : ℕ) (hm : 0 < m) (q : List ℚ)
    (ha : |coordinate k m c| ≤ 1) (hb : |coordinate (k+1) m c| ≤ 1) :
    |(units:ℚ)*center k m c q-(nominal k m c q:ℚ)| ≤ 4*(m:ℚ)*(primitive q).length := by
  have h := Horner.cell (primitive q) scale m (num k m c) (num (k+1) m c)
    (by rw [coordinate_num _ _ _ hm]; exact ha) (by rw [coordinate_num _ _ _ hm]; exact hb)
  rw [coordinate_num _ _ _ hm,coordinate_num _ _ _ hm] at h
  change |(m:ℚ)*(scale:ℚ)*(evalQ (primitive q) (coordinate (k+1) m c) -
    evalQ (primitive q) (coordinate k m c)) - _| ≤ _ at h
  unfold units FrozenPolynomialCells.center nominal
  push_cast
  convert h using 2 <;> ring

private theorem chart_encloses (k m c : ℕ) (hm : 0 < m) (q : List ℚ) (e : ℚ)
    (x : ℝ) (norm : 0 ≤ x ∧ x ≤ 1)
    (interval : ((center k m c q - e : ℚ):ℝ) ≤ x ∧ x ≤ ((center k m c q + e : ℚ):ℝ))
    (ha : |coordinate k m c| ≤ 1) (hb : |coordinate (k+1) m c| ≤ 1) :
    ((piece k m c q e).1:ℝ) ≤ (units:ℝ)*x ∧ (units:ℝ)*x ≤ ((piece k m c q e).2:ℝ) := by
  let u : ℝ := units
  let y : ℝ := center k m c q
  let n : ℝ := nominal k m c q
  have hu : 0 ≤ u := Nat.cast_nonneg units
  have h0 : 0 ≤ u*x := mul_nonneg hu norm.1
  have h1 : u*x ≤ u := (mul_le_mul_of_nonneg_left norm.2 hu).trans_eq (mul_one _)
  have err := abs_le.mp (rounded_error k m c hm q ha hb)
  have down : -(4*(m:ℝ)*(primitive q).length) ≤ u*y-n := by
    have h := (Rat.cast_le (K := ℝ)).mpr err.1
    push_cast at h
    exact h
  have up : u*y-n ≤ 4*(m:ℝ)*(primitive q).length := by
    have h := (Rat.cast_le (K := ℝ)).mpr err.2
    push_cast at h
    exact h
  have ce : (units:ℚ)*e ≤ (⌈(units:ℚ)*e⌉:ℤ) := Int.le_ceil _
  have ceilR : u*(e:ℝ) ≤ (⌈(units:ℚ)*e⌉:ℤ) := by
    have h := (Rat.cast_le (K := ℝ)).mpr ce
    push_cast at h
    exact h
  push_cast at interval
  have lows := mul_le_mul_of_nonneg_left interval.1 hu
  have highs := mul_le_mul_of_nonneg_left interval.2 hu
  change u*(y-(e:ℝ)) ≤ u*x at lows
  change u*x ≤ u*(y+(e:ℝ)) at highs
  unfold piece pad
  push_cast
  constructor
  · apply max_le h0
    change n - _ ≤ u*x
    linarith only [down,ceilR,lows]
  · apply le_min h1
    change u*x ≤ n + _
    linarith only [up,ceilR,highs]

private theorem cdf_range (k : ℕ) (hk : k < 130965) (f : Fine) :
    0 ≤ cdf k f / Native.step ∧ cdf k f / Native.step ≤ 1 := by
  have pos : 0 < Native.step := by norm_num [Native.step]
  have nn : 0 ≤ cdf k f := by
    unfold cdf
    apply Finset.sum_nonneg
    intro s _
    split_ifs <;> first | exact measureReal_nonneg | exact le_rfl
  refine ⟨div_nonneg nn pos.le,(div_le_one pos).mpr ?_⟩
  rw [cdf_integral k hk f]
  let a := (k:ℝ)*Native.step
  let b := ((k:ℝ)+1)*Native.step
  have ab : a ≤ b := by dsimp only [a,b]; nlinarith only [pos]
  have con : IntegrableOn (fun _ : ℝ => (1:ℝ)) (Ico a b) := integrableOn_const measure_Ico_lt_top.ne
  have reg : IntegrableOn (fun t : ℝ => dickmanRho (t/cutoff f)) (Ico a b) := by
    apply con.mono' ((dickmanRho_analytic.2.2.2.1.comp (measurable_id.div_const _)).aestronglyMeasurable)
    apply ae_of_all
    intro t
    have h := dickmanRho_analytic.2.2.2.2.2.1 (t/cutoff f)
    change ‖dickmanRho (t/cutoff f)‖ ≤ 1
    rw [Real.norm_eq_abs,abs_of_nonneg h.1]
    exact h.2
  have h := setIntegral_mono_on reg con measurableSet_Ico
      (fun t _ => (dickmanRho_analytic.2.2.2.2.2.1 (t/cutoff f)).2)
  rw [setIntegral_const,smul_eq_mul,mul_one,Real.volume_real_Ico_of_le ab] at h
  exact h.trans_eq (by dsimp only [a,b]; ring)

private theorem domain (k m c : ℕ) (hm : 0 < m) (lo : c*m ≤ 2*k+m)
    (hi : 2*(k+1) ≤ (c+1)*m) :
    |coordinate k m c| ≤ 1 ∧ |coordinate (k+1) m c| ≤ 1 := by
  have p : (0:ℚ) < m := by exact_mod_cast hm
  have l : (c:ℚ)*m ≤ 2*(k:ℚ)+m := by exact_mod_cast lo
  have h : 2*((k:ℚ)+1) ≤ ((c:ℚ)+1)*m := by exact_mod_cast hi
  unfold coordinate
  rw [abs_le,abs_le]
  push_cast
  constructor <;> constructor
  all_goals first | (rw [le_sub_iff_add_le,le_div_iff₀ p]; nlinarith only [l]) |
    (rw [sub_le_iff_le_add,div_le_iff₀ p]; nlinarith only [h])

/-- Both integer endpoint bounds for every historical CDF and complete radial cell. -/
theorem physical_ticks (k : ℕ) (hk : k < 130965) (c : DebitNativeClasses.Class) :
    let f := DebitNativeClasses.capAt c
    let B := ticks k (FrozenCaps.index f)
    ((B.1:ℤ):ℝ) ≤ (units:ℝ)*(cdf k f/Native.step) ∧
      (units:ℝ)*(cdf k f/Native.step) ≤ ((B.2:ℤ):ℝ) := by
  let f := DebitNativeClasses.capAt c
  let m := FrozenCaps.index f
  change ((ticks k m).1:ℝ) ≤ _ ∧ _ ≤ ((ticks k m).2:ℝ)
  have actual := historical k hk c
  change ((box k m).1:ℝ) ≤ cdf k f/Native.step ∧ cdf k f/Native.step ≤ ((box k m).2:ℝ) at actual
  have hm : 0 < m := FrozenCaps.positive f
  have range := cdf_range k hk f
  by_cases short : k < m
  · simp only [ticks,if_pos short]
    rw [below_frozen_cutoff k hk f short,div_self (by norm_num [Native.step]),mul_one]
    simp
  have start := Nat.le_of_not_gt short
  by_cases mid : k < 2*m
  · have d := domain k m 3 hm (by omega) (by omega)
    simp only [box,if_neg short,if_pos mid] at actual
    simpa only [ticks,if_neg short,if_pos mid] using
      chart_encloses k m 3 hm p3 r3 _ range actual d.1 d.2
  · have last : k < 3*m := historical_domain c k hk
    have d := domain k m 5 hm (by omega) (by omega)
    simp only [box,if_neg short,if_neg mid] at actual
    simpa only [ticks,if_neg short,if_neg mid] using
      chart_encloses k m 5 hm p5 e5 _ range actual d.1 d.2

#print axioms physical_ticks
end PrimeGap180.IntegerPolynomialCells
