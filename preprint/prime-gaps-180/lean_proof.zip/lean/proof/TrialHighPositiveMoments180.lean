import TrialHighIntegerSites180

/-! The exact integer endpoints used by the compact high-edge quadrature
enclose nonnegative native site moments. -/
noncomputable section
open scoped BigOperators
namespace PrimeGap180.HighPositiveMoments
open HighTailAddresses HighMomentReader HighSiteMoments HighTailTiles
open private positive_integral from TrialExactTagArea180

private theorem edge_order (k : Fin 9) :
    0 < realValue (bandLo k) ∧ realValue (bandLo k) ≤ realValue (bandHi k) := by
  have h : ∀ k : Fin 9, 0 < ratValue (bandLo k) ∧ ratValue (bandLo k) ≤ ratValue (bandHi k) := by
    decide +kernel
  rw [←edge_cast (bandLo k),←edge_cast (bandHi k)]
  exact ⟨by exact_mod_cast (h k).1,by exact_mod_cast (h k).2⟩

private theorem rect {a b c d : ℝ} (ab : a ≤ b) (cd : c ≤ d) (H : ℝ) :
    0 ≤ ExactTagArea.rectangle a b c d H := by
  let f := fun x => max (H-c-x) 0
  let g := fun x => max (H-d-x) 0
  have cf : Continuous f := (continuous_const.sub continuous_id).max continuous_const
  have cg : Continuous g := (continuous_const.sub continuous_id).max continuous_const
  have eq : (∫ x in a..b, f x-g x) = ExactTagArea.rectangle a b c d H := by
    rw [intervalIntegral.integral_sub (cf.intervalIntegrable _ _) (cg.intervalIntegrable _ _)]
    change (∫ x in a..b, max (H-c-x) 0) - (∫ x in a..b, max (H-d-x) 0) = _
    rw [positive_integral a b (H-c) ab,positive_integral a b (H-d) ab]
    unfold ExactTagArea.rectangle
    ring
  rw [←eq]
  apply intervalIntegral.integral_nonneg ab
  intro x _
  exact sub_nonneg.mpr (max_le_max (by linarith only [cd]) le_rfl)

theorem marks (m : Marks) (H : ℝ) : 0 ≤ markWeight m H := by
  cases m with
  | plain => simp [markWeight]
  | single i =>
    change 0 ≤ HighMomentTails.oneWeight (realValue (bandLo i)) (realValue (bandHi i)) H
    rw [HighTailPhysical.one_weight (edge_order i).2]
    exact div_nonneg (le_max_right _ _) (edge_order i).1.le
  | pair i j =>
    change 0 ≤ HighMomentTails.twoWeight (realValue (bandLo i)) (realValue (bandHi i))
      (realValue (bandLo j)) (realValue (bandHi j)) H
    rw [HighTailPhysical.two_weight]
    exact div_nonneg (rect (edge_order i).2 (edge_order j).2 H)
      (mul_nonneg (edge_order i).1.le (edge_order j).1.le)

private theorem step_pos : 0 < Native.step := by norm_num [Native.step]
private theorem mid_pos (j : I) : 0 ≤ mid j := by
  have h := step_pos
  unfold mid FrozenChannels.center
  positivity
private theorem tilt (r : Rate) : 0 ≤ 1-(beta r:ℝ)*Native.step := by
  fin_cases r <;> norm_num [beta,Native.step]

private theorem ordinary (r : Rate) (j : I) : 0 ≤ HighTailPhysical.ordinary r j.val :=
  mul_nonneg (mul_nonneg (pow_nonneg (tilt r) _) step_pos.le) (sq_nonneg _)
private theorem shape (j : I) (a : Fin 3) : 0 ≤ FrozenProfile.shapes (mid j) a := by
  have jpos := mid_pos j
  fin_cases a <;> simp [FrozenProfile.shapes] <;> positivity

theorem core (r : Rate) (m : Marks) (p : Fin 13) :
    0 ≤ physicalCore r m p := by
  unfold physicalCore
  exact Finset.sum_nonneg fun j _ => mul_nonneg (mul_nonneg (ordinary r j) (pow_nonneg (mid_pos j) _)) (marks m _)

theorem endpoint (r : Rate) (m : Marks) (a b : Fin 3) :
    0 ≤ physicalEnd r m a b := by
  unfold physicalEnd
  exact Finset.sum_nonneg fun i _ => mul_nonneg
    (mul_nonneg (mul_nonneg (ordinary r i) (shape i a)) (shape i b)) (marks m _)

theorem core_bounds (r : Rate) (m : Marks) (p : Fin 13) :
    let B := upperCore HighCertifiedMoments.bounds r m p
    0 ≤ HighIntegerSites.lower B ∧ (HighIntegerSites.lower B:ℝ) ≤ (2:ℝ)^224*physicalCore r m p ∧
      (2:ℝ)^224*physicalCore r m p ≤ (HighIntegerSites.upper B:ℝ) :=
  HighIntegerSites.round _ _ (HighClosedSiteMoments.core r m p) (core r m p)

theorem endpoint_bounds (r : Rate) (m : Marks) (a b : Fin 3) :
    let B := upperEndpoint HighCertifiedMoments.bounds r m a b
    0 ≤ HighIntegerSites.lower B ∧ (HighIntegerSites.lower B:ℝ) ≤ (2:ℝ)^224*physicalEnd r m a b ∧
      (2:ℝ)^224*physicalEnd r m a b ≤ (HighIntegerSites.upper B:ℝ) :=
  HighIntegerSites.round _ _ (HighClosedSiteMoments.endpoint r m a b) (endpoint r m a b)

#print axioms marks
#print axioms core_bounds
#print axioms endpoint_bounds
end PrimeGap180.HighPositiveMoments
