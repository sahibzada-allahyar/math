import TrialSourceAffineLane180
import Lean.Elab.Tactic.Omega

namespace PrimeGap180.PriceAffineScatter

/-- Repeat a short bit string in `2^depth` disjoint fixed-width blocks. -/
def copies (span : Nat) : Nat → Nat → Nat
  | 0, w => w
  | k+1,w => let z := copies span k w; z ||| (z <<< (span*2^k))

private theorem clearAbove {w span b : Nat} (hw : w < 2^span) (hb : span≤b) :
    w.testBit b = false := Nat.testBit_lt_two_pow (Nat.lt_of_lt_of_le hw (Nat.pow_le_pow_right (by decide) hb))

theorem copies_bit {w span : Nat} (hw : w < 2^span) (depth i : Nat) :
    (copies span depth w).testBit i = if i < span*2^depth then w.testBit (i%span) else false := by
  induction depth generalizing i with
  | zero =>
    simp only [copies,Nat.pow_zero,Nat.mul_one]
    by_cases h : i<span
    · simp [h,Nat.mod_eq_of_lt h]
    · simp [h,clearAbove hw (by omega : span≤i)]
  | succ n ih =>
    let size := span*2^n
    have twice : span*2^(n+1) = size+size := by
      simp only [Nat.pow_succ,Nat.mul_two,Nat.mul_add,size]
    rw [copies,Nat.testBit_or,Nat.testBit_shiftLeft,ih,ih,twice]
    change ((if i<size then w.testBit (i%span) else false) ||
      (decide (size≤i) && (if i-size<size then w.testBit ((i-size)%span) else false))) = _
    by_cases early : i<size
    · have late : ¬ size≤i := by omega
      have inside : i<size+size := by omega
      simp [early,late,inside]
    · have late : size≤i := by omega
      have idx : (i-size)%span = i%span := by
        calc
          _ = ((i-size)+span*2^n)%span := (Nat.add_mul_mod_self_left _ _ _).symm
          _ = _ := congrArg (fun j => j%span) (Nat.sub_add_cancel late)
      by_cases inside : i<size+size
      · have low : i-size<size := by omega
        simp [early,late,inside,low,idx]
      · have low : ¬ i-size<size := by omega
        simp [early,late,inside,low]

def pack (span : Nat) : List Nat → Nat
  | [] => 0
  | w::ws => w ||| ((pack span ws) <<< span)

theorem pack_bit {span : Nat} (ws : List Nat) (good : ∀ w ∈ ws, w < 2^span)
    (j : Nat) (hj : j<ws.length) (i : Nat) (hi : i<span) :
    (pack span ws).testBit (span*j+i) = ws[j].testBit i := by
  induction ws generalizing j with
  | nil => simp at hj
  | cons w tail ih =>
    cases j with
    | zero => simp [pack,Nat.testBit_or,Nat.testBit_shiftLeft,show ¬ span≤i by omega]
    | succ j =>
      have h : span≤span*(j+1)+i := by rw [Nat.mul_succ];omega
      have rest : span*(j+1)+i-span = span*j+i := by rw [Nat.mul_succ];omega
      have ht : j<tail.length := by simpa using hj
      have later (u : Nat) (hu : u∈tail) : u < 2^span := good u (List.mem_cons_of_mem _ hu)
      simp only [pack,Nat.testBit_or,Nat.testBit_shiftLeft,clearAbove (good w (by simp)) h,
        decide_eq_true h,Bool.true_and,Bool.false_or,rest,ih later j ht,List.getElem_cons_succ]

/-- At each physical coordinate of a 512-wide padded matrix, keep its first 64 bits. -/
def mask : Nat := copies 32768 9 (2^64-1)

def passed (flat row g : Nat) : Prop :=
  ((flat >>> (64*g)) &&& mask) = ((copies 32704 9 row) &&& mask)

instance (flat row g : Nat) : Decidable (passed flat row g) := by unfold passed; infer_instance

theorem extracts {ws : List Nat} (good : ∀ w∈ws,w<2^32704) {g h : Nat}
    (gl : g<445) (hl : h<445) (gi : g<ws.length) (hi : h<ws.length)
    (ok : passed (pack 32768 ws) ws[g] g) :
    SourceAffine.entry ws[h] g = SourceAffine.entry ws[g] h := by
  apply congrArg SourceAffine.signed
  apply Nat.eq_of_testBit_eq
  intro b
  simp only [SourceAffine.lane,SourceAffine.full,Nat.testBit_and,Nat.testBit_shiftRight,Nat.testBit_two_pow_sub_one]
  by_cases small : b<64
  · simp only [decide_eq_true small,Bool.and_true]
    let i := 32768*h+b
    have mh : mask.testBit i = true := by
      have short : 2^64-1 < 2^32768 := Nat.lt_of_lt_of_le (by decide : 2^64-1 < 2^64) (Nat.pow_le_pow_right (by decide) (by decide : 64≤32768))
      rw [mask,copies_bit short]
      have it : i<32768*2^9 := by dsimp [i];omega
      have rem : i%32768=b := by dsimp [i];rw [Nat.add_comm,Nat.add_mul_mod_self_left,Nat.mod_eq_of_lt (by omega)]
      rw [if_pos it,rem,Nat.testBit_two_pow_sub_one,decide_eq_true small]
    have exactBit := congrArg (fun z : Nat => z.testBit i) ok
    simp only [Nat.testBit_and,Nat.testBit_shiftRight,mh,Bool.and_true] at exactBit
    have bound (w : Nat) (mem : w∈ws) : w<2^32768 := Nat.lt_of_lt_of_le (good w mem) (Nat.pow_le_pow_right (by decide) (by decide : 32704≤32768))
    have lhs : 64*g+i = 32768*h+(64*g+b) := by dsimp [i];omega
    rw [lhs,pack_bit ws bound h hi _ (by omega)] at exactBit
    have ri : i<32704*2^9 := by dsimp [i];omega
    have ri' : i%32704 = 64*h+b := by
      have e : i = (64*h+b)+32704*h := by dsimp [i];omega
      rw [e,Nat.add_mul_mod_self_left,Nat.mod_eq_of_lt (by omega)]
    rw [copies_bit (good _ (List.getElem_mem gi)),if_pos ri,ri'] at exactBit
    exact exactBit
  · simp [small]

#print axioms extracts
end PrimeGap180.PriceAffineScatter
