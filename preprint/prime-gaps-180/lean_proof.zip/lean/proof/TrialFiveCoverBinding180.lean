import TrialCoverPacked180
import TrialMarkedBook180

/-! The three literal integer tables cover every sorted five-bin configuration
appearing in the signed physical resource and event theorem. -/
noncomputable section
open scoped BigOperators
open PrimeGap180 PrimeGap180.ClippedPair PrimeGap180.EventBins PrimeGap180.Book
namespace PrimeGap180.FrozenFiveCovers
open CoverEnumeration

set_option maxRecDepth 30000

private theorem weight_eq (row : FiveRow) (i j : Fin 72) (h : i ≤ j) :
    coverWeights row (i,j) = (digit (column (coverId row) j.val) i.val : ℝ)/10^9 := by
  change (if i.val ≤ j.val then (flatTick (coverId row) i.val j.val : ℝ)/10^9 else 0) = _
  rw [ite_eq_left (show i.val ≤ j.val from h),digit_agrees _ _ _ h]

private theorem ten_terms (f : Fin 5 → Fin 5 → ℝ) :
    ∑ ij ∈ pairIndices, f ij.1 ij.2 =
      f 3 4+f 2 3+f 2 4+f 1 2+f 1 3+f 1 4+f 0 1+f 0 2+f 0 3+f 0 4 := by
  have indices : pairIndices = {(3,4),(2,3),(2,4),(1,2),(1,3),(1,4),(0,1),(0,2),(0,3),(0,4)} := by decide +kernel
  rw [indices]
  rw [Finset.sum_insert (show (3,4) ∉ ({(2,3),(2,4),(1,2),(1,3),(1,4),(0,1),(0,2),(0,3),(0,4)} : Finset (Fin 5 × Fin 5)) by decide +kernel)]
  rw [Finset.sum_insert (show (2,3) ∉ ({(2,4),(1,2),(1,3),(1,4),(0,1),(0,2),(0,3),(0,4)} : Finset (Fin 5 × Fin 5)) by decide +kernel)]
  rw [Finset.sum_insert (show (2,4) ∉ ({(1,2),(1,3),(1,4),(0,1),(0,2),(0,3),(0,4)} : Finset (Fin 5 × Fin 5)) by decide +kernel)]
  rw [Finset.sum_insert (show (1,2) ∉ ({(1,3),(1,4),(0,1),(0,2),(0,3),(0,4)} : Finset (Fin 5 × Fin 5)) by decide +kernel)]
  rw [Finset.sum_insert (show (1,3) ∉ ({(1,4),(0,1),(0,2),(0,3),(0,4)} : Finset (Fin 5 × Fin 5)) by decide +kernel)]
  rw [Finset.sum_insert (show (1,4) ∉ ({(0,1),(0,2),(0,3),(0,4)} : Finset (Fin 5 × Fin 5)) by decide +kernel)]
  rw [Finset.sum_insert (show (0,1) ∉ ({(0,2),(0,3),(0,4)} : Finset (Fin 5 × Fin 5)) by decide +kernel)]
  rw [Finset.sum_insert (show (0,2) ∉ ({(0,3),(0,4)} : Finset (Fin 5 × Fin 5)) by decide +kernel)]
  rw [Finset.sum_insert (show (0,3) ∉ ({(0,4)} : Finset (Fin 5 × Fin 5)) by decide +kernel)]
  rw [Finset.sum_singleton]
  ring

theorem of_bands (checks : ∀ (k : Fin 3) (d : ℕ), 35 ≤ d → d ≤ 54 →
    band (k == 2) (column k) d = true) : ValidCovers := by
  intro row v mono lower upper pair incPair
  let k := coverId row
  have ab : (v 0).val ≤ (v 1).val := mono (by decide : (0:Fin 5) ≤ 1)
  have bc : (v 1).val ≤ (v 2).val := mono (by decide : (1:Fin 5) ≤ 2)
  have cd : (v 2).val ≤ (v 3).val := mono (by decide : (2:Fin 5) ≤ 3)
  have de : (v 3).val ≤ (v 4).val := mono (by decide : (3:Fin 5) ≤ 4)
  have be : (v 4).val ≤ 71 := by omega
  have total : (∑ i : Fin 5, (v i).val) = (v 0).val+(v 1).val+(v 2).val+(v 3).val+(v 4).val := by
    simp [Fin.sum_univ_succ,Nat.add_assoc]
  rw [total] at lower upper
  have inc : (k == 2) = row.incremental := by cases row <;> rfl
  have enough := band_sound (checks k (v 3).val (by omega) (by omega)) ab bc cd de be lower upper pair
    (fun h => incPair (inc ▸ h))
  have edge (i j : Fin 5) (h : i ≤ j) := weight_eq row (v i) (v j) (mono h)
  rw [ten_terms (fun i j => coverWeights row (v i,v j))]
  rw [edge 3 4 (by decide),edge 2 3 (by decide),edge 2 4 (by decide),
      edge 1 2 (by decide),edge 1 3 (by decide),edge 1 4 (by decide),
      edge 0 1 (by decide),edge 0 2 (by decide),edge 0 3 (by decide),edge 0 4 (by decide)]
  have z : (24000000000:ℝ) ≤ (digit (column k (v 4).val) (v 3).val:ℝ)+digit (column k (v 3).val) (v 2).val+
      digit (column k (v 4).val) (v 2).val+digit (column k (v 2).val) (v 1).val+
      digit (column k (v 3).val) (v 1).val+digit (column k (v 4).val) (v 1).val+
      digit (column k (v 1).val) (v 0).val+digit (column k (v 2).val) (v 0).val+
      digit (column k (v 3).val) (v 0).val+digit (column k (v 4).val) (v 0).val := by exact_mod_cast enough
  dsimp only [k] at z
  linarith only [z]

#print axioms of_bands
end PrimeGap180.FrozenFiveCovers
