import TrialSourceMatrixTable180
namespace PrimeGap180.SourceMatrixBits.Sharp

set_option maxRecDepth 131072
set_option maxHeartbeats 100000000

theorem verified : row .sharp = true := by decide +kernel

#print axioms verified
end PrimeGap180.SourceMatrixBits.Sharp
