import TrialSingleShift180
import TrialSectorPriceMoments180
import TrialArchivedGap180
import TrialAffineRow180
import WeightMeans182

/-! Apply the 14 signed rows, 49 physical resources, 26 residual events
and the resolved prime mask to one and the same trial. The archive fixes
the group assignment and all 521 final prices. -/
noncomputable section
open scoped BigOperators Classical Topology
open Filter MeasureTheory PrimeGap186 PrimeGap182Analytic PrimeGap180.Distribution
open PrimeGap180.Sector PrimeGap180.Price PrimeGap180.Detection
namespace PrimeGap180.Book

abbrev Label := Fin 521
abbrev Group := Fin 445
abbrev Row := PhysicalPrices.Row
abbrev Event := PriceEvents.Event
abbrev Resource := Resources.Resource
def grouped (s : Label) : Prop := s.val < 170 ∨ 173 < s.val
abbrev SectorId := {s : Label // grouped s}
abbrev Direct := {s : Label // ¬ grouped s}
abbrev Split := SectorId ⊕ Direct
def joinLabel : Split ≃ Label := Equiv.sumCompl grouped

private def decodeGroups (raw : String) : Except String (Array Nat) := do
  let doc ← Lean.Json.parse raw
  let gs ← (← doc.getObjVal? "groups").getArr?
  if gs.size != 445 then throw "expected 445 groups"
  let mut table := Array.replicate 521 445
  for h : g in [:gs.size] do
    let members ← gs[g].getArr?
    if members.isEmpty then throw "empty group"
    for entry in members do
      let s ← entry.getNat?
      if s >= 521 || (170 <= s && s <= 173) then throw "unexpected sector"
      if table[s]! != 445 then throw "duplicate sector"
      table := table.set! s g
  for s in [:521] do
    if (table[s]! == 445) != (170 <= s && s <= 173) then throw "missing sector"
  return table

open Lean Elab Term in
elab "archiveGroups% " t:term : term => do
  let e ← elabTermEnsuringType t (mkConst ``String)
  let .lit (.strVal raw) := e.consumeMData | throwError "expected a literal archive"
  return toExpr (← IO.ofExcept (decodeGroups raw))

private def owners : Array Nat :=
  archiveGroups% (include_str "../data/h1_decoupled_coarsened_1e14.json")

def owner (s : SectorId) : Group := Fin.ofNat 445 (owners[s.val.val]!)

/-- Reproduce the rational producer's upward rounding from the recorded decimal
mantissa and exponent. The 521 radii are independent of the trial energies. -/
private def decodeRadii (raw : String) : Except String (Array Nat) := do
  let doc ← Lean.Json.parse raw
  let bounds ← (← doc.getObjVal? "physical_upper").getArr?
  if bounds.size != 521 then throw "expected 521 sector radii"
  bounds.mapM fun entry => do
    let n ← entry.getNum?
    if n.mantissa < 0 then throw "negative sector radius"
    let den := 10^n.exponent
    let ticks := (10000*n.mantissa.toNat + den-1)/den+1
    if ticks > 2801 then throw "sector radius outside the proved interval"
    return ticks

open Lean Elab Term in
elab "archiveRadii% " t:term : term => do
  let e ← elabTermEnsuringType t (mkConst ``String)
  let .lit (.strVal raw) := e.consumeMData | throwError "expected a literal archive"
  return toExpr (← IO.ofExcept (decodeRadii raw))

private def radiusTicks : Array Nat :=
  archiveRadii% (include_str "../data/h1_priced_168_table.json")

def capR (s : Label) : ℝ := (radiusTicks[s.val]!:ℝ)/10000

set_option maxRecDepth 8192 in
set_option maxHeartbeats 1000000 in
private theorem ticks_le : ∀ s : Label, radiusTicks[s.val]! ≤ 2801 := by decide

theorem capR_bound (s : Label) : capR s ≤ 0.2801 := by
  have h : (radiusTicks[s.val]!:ℝ) ≤ 2801 := by exact_mod_cast ticks_le s
  dsimp only [capR]
  linarith

structure Ledger where
  ref : Group → ℝ
  floors : Group → ℤ
  affine : Row → Group → Group → ℤ
  densityLo : Row → ℝ
  densityHi : Row → ℝ
  count : Resource → Event → ℤ
  rank : Resource → ℕ
  factor : ∀ u, Group → Fin (rank u) → ℤ
  remainder : Event → Group → Group → ℤ
  pos : Event → ℕ
  neg : Event → ℕ
  positive : ∀ e, Group → Fin (pos e) → ℤ
  negative : ∀ e, Group → Fin (neg e) → ℤ
  resourceKernel : Resource → SectorId → ℝ
  eventKernel : Event → SectorId → ℝ

def floorW (b : Ledger) (g : Group) : ℝ := b.floors g
def matrix (b : Ledger) (k : Row) (g h : Group) : ℝ := (b.affine k g h:ℝ)/priceUnit
def earning (b : Ledger) (k : Row) (g : Group) :=
  min (b.densityLo k * matrix b k g g) (b.densityHi k * matrix b k g g)
def resourceCharge (b : Ledger) (u : Resource) (g : Group) : ℝ :=
  (intGram (b.factor u) g g:ℝ)/priceUnit^2
def eventCharge (b : Ledger) (e : Event) (g : Group) : ℝ :=
  ((intGram (b.negative e) g g +
    intDeficit (intRemainder (b.remainder e) (b.positive e) (b.negative e)) g:ℤ):ℝ) /
      (24*(32*priceUnit)^2)
def floorCharge (b : Ledger) (g : Group) := roundingRow (floorW b) g/priceUnit^2

abbrev Entry := Row ⊕ (Resource ⊕ (Event ⊕ Unit))

def weight (b : Ledger) : Entry → Group → ℝ
  | .inl k => earning b k
  | .inr (.inl u) => fun g => -resourceCharge b u g
  | .inr (.inr (.inl e)) => fun g => -eventCharge b e g
  | .inr (.inr (.inr _)) => fun g => -floorCharge b g

def base (b : Ledger) : Entry → SectorId → ℝ
  | .inl _ => fun _ => 1
  | .inr (.inl u) => fun s => if u = .prime then 0 else b.resourceKernel u s
  | .inr (.inr (.inl e)) => fun s => if e = .prime then 0 else b.eventKernel e s
  | .inr (.inr (.inr _)) => fun _ => 0

def slope : Entry → ℝ
  | .inl _ => 0
  | .inr (.inl u) => if u = .prime then 1 else 0
  | .inr (.inr (.inl e)) => if e = .prime then 1 else 0
  | .inr (.inr (.inr _)) => 1

def p0 (s : Label) : ℝ := ((archivedPrice s).1:ℝ)/priceUnit
def p1 (s : Label) : ℝ := ((archivedPrice s).2:ℝ)/priceUnit

def finitePrice (b : Ledger) (s : SectorId) (q : ℝ) : Prop :=
  p0 s.val+p1 s.val*primePrice q ≤
    (∑ j : Entry, weight b j (owner s)*base b j s)/b.ref (owner s) +
    ((∑ j : Entry, weight b j (owner s)*slope j)/b.ref (owner s))*primePrice q

structure FiniteChecks (b : Ledger) : Prop where
  refPos : ∀ g, 0 < b.ref g
  floorNonneg : ∀ g, 0 ≤ floorW b g
  floorLo : ∀ g, floorW b g ≤ priceUnit*Real.sqrt (b.ref g)
  floorHi : ∀ g, priceUnit*Real.sqrt (b.ref g) ≤ floorW b g+1
  symmetric : ∀ e g h, b.remainder e g h = b.remainder e h g
  incidence : ∀ u e, (b.count u e:ℝ)/24 = Resources.coefficient u e
  balance : ∀ e g h, (b.remainder e g h:ℝ)/(24*priceUnit^2) =
    PhysicalPrices.objective (fun k => floorW b k/priceUnit) e g h -
    (∑ k, PhysicalPrices.coefficient k e * matrix b k g h) +
    ∑ u, (b.count u e:ℝ)/24*((intGram (b.factor u) g h:ℝ)/priceUnit^2)
  left : ∀ s, finitePrice b s 0
  right : ∀ s, finitePrice b s (capR s.val)

variable {m : ℕ}
abbrev LabelFn (m : ℕ) := (Fin 38 → Band m) → Label

def splitFn (label : LabelFn m) (t : Fin 38 → Band m) := joinLabel.symm (label t)
def restricted (F : Profile 39 m) (i : Fin 39) (label : LabelFn m) (s : Split) :=
  restrictFace i (fun t => splitFn label t = s) F
def faceValue (a : Fin (m+2) → ℝ) (F : Profile 39 m) (i : Fin 39) (label : LabelFn m) (s : Split) :=
  integralFace a i (restricted F i label s)
def energy (a : Fin (m+2) → ℝ) (F : Profile 39 m) (i : Fin 39) (label : LabelFn m) (s : Split) :=
  ∫ t, (faceValue a F i label s t)^2 ∂Measure.pi (fun _ => bandLaw a)
def inverseEnergy (a : Fin (m+2) → ℝ) (F : Profile 39 m) (i : Fin 39) (label : LabelFn m) (s : Split) :=
  ∫ t, primePrice (retainedRadius t)*(faceValue a F i label s t)^2 ∂Measure.pi (fun _ => bandLaw a)
def eachAmplitude (a : Fin (m+2) → ℝ) (F : Profile 39 m) (i : Fin 39) (label : LabelFn m)
    (x : ℝ) (n : ℕ) (s : Split) :=
  sectorAmplitude (face tuple182 a i (restricted F i label s) x) shifts i n
def groupedAmplitude (b : Ledger) (a : Fin (m+2) → ℝ) (F : Profile 39 m) (i : Fin 39) (label : LabelFn m)
    (x : ℝ) (n : ℕ) := gaugeGroup owner b.ref (fun s => eachAmplitude a F i label x n (.inl s))
private theorem grouped_sample (b : Ledger) (a : Fin (m+2) → ℝ) (F : Profile 39 m) (i : Fin 39)
    (l : LabelFn m) (x : ℝ) : groupedAmplitude b a F i l x =
      fun n => gaugeGroup owner b.ref (fun s => sampledSelbergRoot
        (face tuple182 a i (restricted F i l (.inl s)) x) (fun j => n+shifts (i.succAbove j))) := by
  funext n
  simp only [groupedAmplitude,eachAmplitude,affine_amplitude_eq_marked]

def z (x : ℝ) (n : ℕ) :=
  if Nat.ModEq (presievingModulus tuple182 x) n (PhysicalPrices.progression x) then (markedScale tuple182 x)⁻¹ else 0

def cost (b : Ledger) (a : Fin (m+2) → ℝ) (F : Profile 39 m) (i : Fin 39) (label : LabelFn m)
    (j : Entry) := gaugeCost owner b.ref (fun s =>
      base b j s * energy a F i label (.inl s) + slope j * inverseEnergy a F i label (.inl s))

set_option maxRecDepth 8192 in
private theorem direct_price (t : Direct) : archivedPrice t.val = (10^14,0) := by
  have ht : ¬(t.val.val < 170 ∨ 173 < t.val.val) := t.property
  have values : t.val.val = 170 ∨ t.val.val = 171 ∨ t.val.val = 172 ∨ t.val.val = 173 := by omega
  rcases values with h|h|h|h
  all_goals rw [show t.val = ⟨_,by omega⟩ from Fin.ext h]
  all_goals rfl

private theorem joinFace (i : Fin 39) (label : LabelFn m) (F : Profile 39 m) (s : Split) :
    restrictFace i (fun y => label y = joinLabel s) F = restricted F i label s := by
  simp only [restricted,splitFn,Equiv.symm_apply_eq]

private theorem sum_income (a : Fin (m+2) → ℝ) (F : Profile 39 m) (i : Fin 39) (label : LabelFn m) :
    shiftIncome a F i label =
    (∑ s : SectorId, (p0 s.val*energy a F i label (.inl s)+p1 s.val*inverseEnergy a F i label (.inl s))) +
      ∑ t : Direct, energy a F i label (.inr t) := by
  unfold shiftIncome
  rw [← joinLabel.sum_comp, Fintype.sum_sum_type,add_div,Finset.sum_div,Finset.sum_div]
  apply congrArg₂ (·+·)
  · apply Finset.sum_congr rfl
    intro s _
    simp only [joinFace,energy,inverseEnergy,faceValue,p0,p1]
    change _ = ((archivedPrice (joinLabel (.inl s))).1:ℝ)/priceUnit*_ +
      ((archivedPrice (joinLabel (.inl s))).2:ℝ)/priceUnit*_
    ring
  · apply Finset.sum_congr rfl
    intro t _
    simp only [joinFace,energy,faceValue]
    rw [show archivedPrice (joinLabel (.inr t)) = (10^14,0) from direct_price t]
    push_cast
    ring

def rowGain (b : Ledger) (a : Fin (m+2) → ℝ) (F : Profile 39 m) (i : Fin 39) (l : LabelFn m) (k : Row) :=
  ∑ g, earning b k g * cost b a F i l (.inl k) g

def groupedIncome (b : Ledger) (a : Fin (m+2) → ℝ) (F : Profile 39 m) (i : Fin 39) (l : LabelFn m) :=
  (∑ k, rowGain b a F i l k) -
    (∑ u, ∑ g, cost b a F i l (.inr (.inl u)) g * resourceCharge b u g) -
    ∑ e, ∑ g, cost b a F i l (.inr (.inr (.inl e))) g * eventCharge b e g

private theorem same_prime_cost (b : Ledger) (a : Fin (m+2) → ℝ) (F : Profile 39 m) (i : Fin 39) (l : LabelFn m) :
    ∀ t : Unit, cost b a F i l (.inr (.inr (.inr t))) =
      cost b a F i l (.inr (.inr (.inl .prime))) := by simp [cost,base,slope]

private theorem book_value (b : Ledger) (a : Fin (m+2) → ℝ) (F : Profile 39 m) (i : Fin 39) (l : LabelFn m) :
    (∑ j : Entry, ∑ g, weight b j g * cost b a F i l j g) = groupedIncome b a F i l -
      ∑ g, roundingRow (floorW b) g/priceUnit^2 * cost b a F i l (.inr (.inr (.inl .prime))) g := by
  simp only [Fintype.sum_sum_type,Fintype.sum_unique,weight,neg_mul,Finset.sum_neg_distrib,
    groupedIncome,rowGain,floorCharge,same_prime_cost,mul_comm (resourceCharge b _ _),
    mul_comm (eventCharge b _ _)]
  ring

/-- Pull the signed matrix back along the actual group map. Individual
sector estimates for this matrix carry precisely the reference divisors
appearing in the grouped prime objective. -/
def lifted (b : Ledger) (k : Row) (s t : SectorId) :=
  matrix b k (owner s) (owner t)/(Real.sqrt (b.ref (owner s))*Real.sqrt (b.ref (owner t)))

private theorem quad_groups (b : Ledger) (k : Row) (v : SectorId → ℝ) :
    Dual.quad (matrix b k) (gaugeGroup owner b.ref v) = Dual.quad (lifted b k) v := by
  let V := gaugeGroup owner b.ref v
  have sum (g : Group) : (∑ h, matrix b k g h * V h) =
      ∑ t, (matrix b k g (owner t)/Real.sqrt (b.ref (owner t)))*v t := gauge_root_sum owner b.ref _ v
  calc
    _ = ∑ g, (∑ h, matrix b k g h*V h)*V g := by
      simp only [Dual.quad,Finset.sum_mul,V]
      apply Finset.sum_congr rfl
      intro g _
      exact Finset.sum_congr rfl fun h _ => by ring
    _ = ∑ s, ((∑ h, matrix b k (owner s) h*V h)/Real.sqrt (b.ref (owner s)))*v s :=
      gauge_root_sum owner b.ref _ v
    _ = _ := by
      simp only [sum,Finset.sum_div,Finset.sum_mul,Dual.quad,lifted]
      apply Finset.sum_congr rfl
      intro s _
      exact Finset.sum_congr rfl fun t _ => by ring

/-- Directly accepts the individual signed-row estimate produced by
`Sector.signed_price_row`, on the literal label predicates. -/
theorem grouped_row_of_individual (b : Ledger) (ch : FiniteChecks b) (a : Fin (m+2) → ℝ)
    (F : Profile 39 m) (i : Fin 39) (l : LabelFn m) (k : Row)
    (h : Lower (fun x => pair (lifted b k) (moment (window x)
      (fun n => Literal.value (PhysicalPrices.channel x k) (n+shifts i)*z x n)
      (fun n s => eachAmplitude a F i l x n (.inl s))))
      (∑ s : SectorId, min (b.densityLo k*lifted b k s s) (b.densityHi k*lifted b k s s)*
        energy a F i l (.inl s)) primeScales) :
    Lower (fun x => pair (matrix b k) (moment (window x)
      (fun n => Literal.value (PhysicalPrices.channel x k) (n+shifts i)*z x n)
      (groupedAmplitude b a F i l x))) (rowGain b a F i l k) primeScales := by
  have price : (∑ s : SectorId, min (b.densityLo k*lifted b k s s) (b.densityHi k*lifted b k s s)*
      energy a F i l (.inl s)) = rowGain b a F i l k := by
    unfold rowGain cost
    rw [collect_group_charge]
    apply Finset.sum_congr rfl
    intro s _
    simp only [base,slope,one_mul,zero_mul,add_zero,lifted,earning,
      Real.mul_self_sqrt (ch.refPos (owner s)).le,←mul_div_assoc,
      min_div_div_right (ch.refPos (owner s)).le]
  rw [←price]
  simpa only [pair_moment,groupedAmplitude,quad_groups] using h

/-- Each row and each physical upper kernel is evaluated on its own
literal channel and on the shared grouped divisor amplitudes. The direct
prime mask is evaluated on the ungrouped divisor amplitudes. -/
structure ShiftEstimates (b : Ledger) (a : Fin (m+2) → ℝ) (F : Profile 39 m) (i : Fin 39)
    (label : LabelFn m) : Prop where
  rows : ∀ k, Lower (fun x => pair (matrix b k) (moment (window x)
    (fun n => Literal.value (PhysicalPrices.channel x k) (n+shifts i)*z x n)
    (groupedAmplitude b a F i label x))) (rowGain b a F i label k) primeScales
  resources : ∀ u (c : Group → ℝ), Upper primeScales (fun x => squareCount (window x)
    (fun n => Resources.physical x (n+shifts i) u * z x n)
    (groupedAmplitude b a F i label x) c)
    (∑ g, cost b a F i label (.inr (.inl u)) g * (c g)^2)
  events : ∀ e (c : Group → ℝ), Upper primeScales (fun x => squareCount (window x)
    (fun n => PriceEvents.mass x (n+shifts i) e * z x n)
    (groupedAmplitude b a F i label x) c)
    (∑ g, cost b a F i label (.inr (.inr (.inl e))) g * (c g)^2)
  resolved : Lower (fun x => pair resolvedMask (moment (window x)
    (fun n => primeHit n (shifts i)*z x n) (eachAmplitude a F i label x)))
    (∑ t : Direct, energy a F i label (.inr t)) primeScales

set_option maxHeartbeats 1800000
set_option maxRecDepth 8192

/-- The only pair-dependent question left for an affine row is membership
of the actual presieved common modulus in one of its proved bands. -/
def PairGate {J ι : Type*} (a : Fin (m+2) → ℝ) (F : Profile 39 m) (i : Fin 39) (l : LabelFn m)
    (index : J → Split) (A : J → J → ℝ) (k : Row)
    (bands : ι → ProvedBand (fun x => PhysicalPrices.channel x k)) : Prop :=
  ∀ s t, A s t ≠ 0 → ∀ᶠ x in primeScales, ∀ y v : Fin 38 → ℕ,
    inSector tuple182 a i (fun u => splitFn l u = index s) F x y →
    inSector tuple182 a i (fun u => splitFn l u = index t) F x v →
    (∀ h j : Fin 38, h ≠ j → (y h).Coprime (v j)) →
    ∃ c, (presievingModulus tuple182 x).lcm ((∏ j, y j).lcm (∏ j, v j)) ∈
      (bands c).toSieveBand.moduli x (schedulePrimes tuple182 x)

theorem affine_of_gate {J ι : Type*} [Fintype J] [Fintype ι] [Nonempty ι] [DecidableEq ι]
    (a : Fin (m+2) → ℝ) (inc : StrictMono a) (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (F : Profile 39 m) (i : Fin 39) (l : LabelFn m) (index : J → Split) (injective : Function.Injective index)
    (bf : Bornology.IsBounded (Set.range F)) (mf : ∀ j, Measurable (restricted F i l (index j)))
    (cf : ∀ j, ∀ᵐ t ∂Measure.pi (fun _ => bandLaw a), ContinuousAt (restricted F i l (index j)) t)
    (k : Row) (A : J → J → ℝ) (bands : ι → ProvedBand (fun x => PhysicalPrices.channel x k))
    (d lo hi : ℝ) (bounds : min lo hi ≤ d ∧ d ≤ max lo hi) (gate : PairGate a F i l index A k bands)
    (density : Tendsto (fun x => Real.log x/x * ∑ n ∈ window x,
      Literal.value (PhysicalPrices.channel x k) (n+shifts i)) atTop (𝓝 d)) :
    Lower (fun x => pair A (moment (window x)
      (fun n => Literal.value (PhysicalPrices.channel x k) (n+shifts i)*z x n)
      (fun n j => eachAmplitude a F i l x n (index j))))
      (∑ j, min (lo*A j j) (hi*A j j)*energy a F i l (index j)) primeScales := by
  have raw := signed_price_row primeScales primeScales_cofinal (fun x => PhysicalPrices.channel x k) bands
    (PhysicalPrices.row_cut k) tuple182 tuple182_card i a inc first last
    (fun j y => splitFn l y = index j) (fun _ => F)
    (fun s t ne _ hs ht => ne (injective (hs.symm.trans ht))) (fun _ => bf) mf cf
    PhysicalPrices.progression (schedulePrimes tuple182) A d lo hi bounds
    (fun s t nz => (gate s t nz).mono fun x yes =>
      ⟨PhysicalPrices.progression_coprime x i,schedulePrimes_prime tuple182 x,yes⟩)
    (density.mono_left primeScales_cofinal)
  simpa only [one_div,z,eachAmplitude,energy,faceValue,restricted] using raw

/-- The four resolved sectors have ordinary prime density one. Only the
physical common-modulus gate for the entries of their mask remains. -/
theorem resolved_of_gate (a : Fin (m+2) → ℝ) (inc : StrictMono a) (first : a 0 = 0)
    (last : a (Fin.last (m+1)) = cap) (F : Profile 39 m) (i : Fin 39) (l : LabelFn m)
    (bf : Bornology.IsBounded (Set.range F)) (mf : ∀ s, Measurable (restricted F i l s))
    (cf : ∀ s, ∀ᵐ t ∂Measure.pi (fun _ => bandLaw a), ContinuousAt (restricted F i l s) t)
    (gate : PairGate a F i l id resolvedMask .prime (fun _ : Unit => PhysicalPrices.ordinary_row .prime)) :
    Lower (fun x => pair resolvedMask (moment (window x)
      (fun n => primeHit n (shifts i)*z x n) (eachAmplitude a F i l x)))
      (∑ t : Direct, energy a F i l (.inr t)) primeScales := by
  have density : Tendsto (fun x => Real.log x/x * ∑ n ∈ window x,
      Literal.value (PhysicalPrices.channel x .prime) (n+shifts i)) atTop (𝓝 (1:ℝ)) :=
    selbergWeight182_shifted_mean 0 (shifts i)
  have row := affine_of_gate a inc first last F i l id Function.injective_id bf mf cf
    .prime resolvedMask (fun _ : Unit => PhysicalPrices.ordinary_row .prime) 1 1 1 (by simp)
    gate density
  rw [← resolved_earning (energy a F i l)]
  exact row

/-- Derive the two variable-kernel slots, both of which use the prime
indicator, from the marked estimate on the actual labels. -/
theorem archive_prime_columns (b : Ledger) (ch : FiniteChecks b) (a : Fin (m+2) → ℝ)
    (inc : StrictMono a) (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (F : Profile 39 m) (i : Fin 39) (l : LabelFn m) (bf : Bornology.IsBounded (Set.range F))
    (mf : ∀ s : SectorId, Measurable (restricted F i l (.inl s)))
    (cf : ∀ s : SectorId, ∀ᵐ t ∂Measure.pi (fun _ => bandLaw a),
      ContinuousAt (restricted F i l (.inl s)) t)
    (supported : ∀ t, F t ≠ 0 → 0 ≤ retainedRadius (i.removeNth t) ∧
       retainedRadius (i.removeNth t) ≤ capR (l (i.removeNth t))) (c : Group → ℝ) :
    Upper primeScales (fun x => squareCount (window x)
      (fun n => PriceEvents.mass x (n+shifts i) .prime*z x n) (groupedAmplitude b a F i l x) c)
      (∑ g, cost b a F i l (.inr (.inr (.inl .prime))) g*(c g)^2) ∧
    Upper primeScales (fun x => squareCount (window x)
      (fun n => Resources.physical x (n+shifts i) .prime*z x n) (groupedAmplitude b a F i l x) c)
      (∑ g, cost b a F i l (.inr (.inl .prime)) g*(c g)^2) := by
  let P := fun (s : SectorId) y => l y = s.val ∧ 0 ≤ retainedRadius y ∧ retainedRadius y ≤ capR s.val
  have equal (s : SectorId) : restrictFace i (P s) F = restricted F i l (.inl s) :=
    (cropped_restriction l capR i F supported s.val).trans (joinFace i l F (.inl s))
  have result := gauge_prime_upper tuple182 tuple182_card i a inc first last P F
    (fun s t ne _ hs ht => ne (Subtype.ext (hs.1.symm.trans ht.1))) bf
    (fun s _ h => ⟨h.2.1,h.2.2.trans (capR_bound _)⟩)
    (fun s => (equal s) ▸ mf s) (fun s => (equal s) ▸ cf s)
    owner b.ref c ch.refPos PhysicalPrices.progression primeScales primeScales_cofinal
  dsimp only at result
  have same (x : ℝ) (n : ℕ) : Resources.physical x n .prime = PriceEvents.mass x n .prime := by
    by_cases prime : n.Prime <;> simp [Resources.physical,Rough.hit,PriceEvents.mass,prime]
  constructor <;> simpa only [cost,base,slope,ite_true,zero_mul,one_mul,zero_add,
    grouped_sample,inverseEnergy,faceValue,
    z,same,PriceEvents.mass,window,equal] using result

/-- A fixed physical marked estimate in the units of the marked partition
lemmas. The profile and erasure in every summand are the original trial's
label restrictions, with one arbitrary real scalar for each label. -/
def Marked (a : Fin (m+2) → ℝ) (F : Profile 39 m) (i : Fin 39) (l : LabelFn m)
    (ev : ℝ → ℕ → ℝ) (K : SectorId → ℝ) : Prop :=
  ∀ (d : SectorId → ℝ) ε, 0 < ε → ∀ᶠ x in atTop,
    (∑ n ∈ window x, if Nat.ModEq (presievingModulus tuple182 x) n (PhysicalPrices.progression x) then
      ev x n*(∑ s, sampledSelbergRoot
        (face tuple182 a i (fun t => d s*restricted F i l (.inl s) t) x)
        (fun t => n+shifts (i.succAbove t)))^2 else 0)/markedScale tuple182 x ≤
      (∑ s, (d s)^2 * (K s*energy a F i l (.inl s))) + ε

theorem fixed_columns (b : Ledger) (ch : FiniteChecks b) (a : Fin (m+2) → ℝ)
    (F : Profile 39 m) (i : Fin 39) (l : LabelFn m) (ev : ℝ → ℕ → ℝ) (K : SectorId → ℝ)
    (raw : Marked a F i l ev K) (c : Group → ℝ) :
    Upper primeScales (fun x => squareCount (window x) (fun n => ev x n*z x n)
      (groupedAmplitude b a F i l x) c)
      (∑ g, gaugeCost owner b.ref (fun s => K s*energy a F i l (.inl s)) g*(c g)^2) := by
  let T := fun s : SectorId => restricted F i l (.inl s)
  have ans := gauge_physical_upper tuple182 a i shifts T (fun s _ => K s) owner b.ref c ch.refPos
    ev window PhysicalPrices.progression primeScales primeScales_cofinal
  dsimp only at ans
  have hyp := raw (fun s => c (owner s)/Real.sqrt (b.ref (owner s)))
  have scaleE (s : SectorId) (d : ℝ) :
      (∫ y, K s*(integralFace a i (fun t => d*T s t) y)^2 ∂Measure.pi (fun _ => bandLaw a)) =
        d^2*(K s*energy a F i l (.inl s)) := by
    rw [signed_sector_energy a i (T s) (fun _ => K s) d,integral_const_mul]
    rfl
  have bound := ans (by simpa only [scaleE,T] using hyp)
  simpa only [z,grouped_sample,T,energy,faceValue,
    integral_const_mul] using bound

/-- Suffices to provide the named individual affine rows on the gated
sector pairs and the constant-kernel marked bounds on composite/rough
rows. Both variable prime bounds are supplied by the radial theorem. -/
theorem estimates_of_individual (b : Ledger) (ch : FiniteChecks b) (a : Fin (m+2) → ℝ)
    (inc : StrictMono a) (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (F : Profile 39 m) (i : Fin 39) (l : LabelFn m) (bf : Bornology.IsBounded (Set.range F))
    (mf : ∀ s : SectorId, Measurable (restricted F i l (.inl s)))
    (cf : ∀ s : SectorId, ∀ᵐ t ∂Measure.pi (fun _ => bandLaw a),
      ContinuousAt (restricted F i l (.inl s)) t)
    (supported : ∀ t, F t ≠ 0 → 0 ≤ retainedRadius (i.removeNth t) ∧
       retainedRadius (i.removeNth t) ≤ capR (l (i.removeNth t)))
    (rows : ∀ k, Lower (fun x => pair (lifted b k) (moment (window x)
      (fun n => Literal.value (PhysicalPrices.channel x k) (n+shifts i)*z x n)
      (fun n s => eachAmplitude a F i l x n (.inl s))))
      (∑ s : SectorId, min (b.densityLo k*lifted b k s s) (b.densityHi k*lifted b k s s)*
        energy a F i l (.inl s)) primeScales)
    (resources : ∀ u : Resource, u ≠ .prime → Marked a F i l
      (fun x n => Resources.physical x (n+shifts i) u) (b.resourceKernel u))
    (events : ∀ e : Event, e ≠ .prime → Marked a F i l
      (fun x n => PriceEvents.mass x (n+shifts i) e) (b.eventKernel e))
    (resolved : Lower (fun x => pair resolvedMask (moment (window x)
      (fun n => primeHit n (shifts i)*z x n) (eachAmplitude a F i l x)))
      (∑ t : Direct, energy a F i l (.inr t)) primeScales) : ShiftEstimates b a F i l := by
  have prime := archive_prime_columns b ch a inc first last F i l bf mf cf supported
  refine ⟨fun k => grouped_row_of_individual b ch a F i l k (rows k),?_,?_,resolved⟩
  · intro u c
    by_cases h : u = .prime
    · subst u; exact (prime c).2
    · simpa only [cost,base,slope,ite_eq_right h,zero_mul,add_zero] using
        fixed_columns b ch a F i l _ _ (resources u h) c
  · intro e c
    by_cases h : e = .prime
    · subst e; exact (prime c).1
    · simpa only [cost,base,slope,ite_eq_right h,zero_mul,add_zero] using
        fixed_columns b ch a F i l _ _ (events e h) c

private theorem diagonals (b : Ledger) (a : Fin (m+2) → ℝ) (F : Profile 39 m) (i : Fin 39)
    (l : LabelFn m) (h : ShiftEstimates b a F i l) (e : Event) (g : Group) :
    Upper primeScales (fun x => ∑ n ∈ window x, (PriceEvents.mass x (n+shifts i) e * z x n)*
      (groupedAmplitude b a F i l x n g)^2) (cost b a F i l (.inr (.inr (.inl e))) g) := by
  have h' := h.events e (fun j => if g = j then 1 else 0)
  simpa [squareCount,ite_mul,mul_ite,ite_pow] using h'

set_option maxHeartbeats 1000000 in
private theorem grouped_lower (b : Ledger) (ch : FiniteChecks b) (a : Fin (m+2) → ℝ)
    (F : Profile 39 m) (i : Fin 39) (l : LabelFn m) (h : ShiftEstimates b a F i l) :
    Lower (fun x => squareCount (window x) (fun n => primeHit n (shifts i)*z x n)
      (groupedAmplitude b a F i l x) (fun g => floorW b g/priceUnit))
      (groupedIncome b a F i l) primeScales := by
  have hz : ∀ᶠ x in primeScales, ∀ n ∈ window x, 0 ≤ z x n := by
    filter_upwards [primeScales_cofinal (eventually_gt_atTop (1:ℝ))] with x hx
    intro n _
    dsimp only [z]
    split_ifs <;> positivity [markedScale_pos tuple182 hx]
  have ans := lower_prime_from_columns window (groupedAmplitude b a F i l) z (shifts i) hz
    (fun g => floorW b g/priceUnit) (matrix b) b.count b.rank b.factor b.remainder
    b.pos b.neg b.positive b.negative (fun u => cost b a F i l (.inr (.inl u)))
    (fun e => cost b a F i l (.inr (.inr (.inl e)))) (rowGain b a F i l)
    ch.symmetric ch.balance h.rows
    (fun u k => resource_square primeScales_cofinal window (groupedAmplitude b a F i l)
      z (shifts i) u (b.count u) (fun g => (b.factor u g k:ℝ)/priceUnit) _ (ch.incidence u)
      (h.resources u _))
    (fun e k => h.events e (fun g => (b.negative e g k:ℝ))) (diagonals b a F i l h) primeScales_cofinal
  simpa only [groupedIncome,resourceCharge,eventCharge,primeHit,squareCount,mul_div_assoc] using ans

set_option maxRecDepth 8192 in
/-- The price comparison uses only the two finite endpoint inequalities.
The actual erased profile is unchanged by the radial cut on each sector. -/
private theorem archived_le (b : Ledger) (ch : FiniteChecks b) (a : Fin (m+2) → ℝ)
    (F : Profile 39 m) (i : Fin 39) (l : LabelFn m)
    (bf : Bornology.IsBounded (Set.range F)) (mf : ∀ s : SectorId, Measurable (restricted F i l (.inl s)))
    (supported : ∀ t, F t ≠ 0 → 0 ≤ retainedRadius (i.removeNth t) ∧
       retainedRadius (i.removeNth t) ≤ capR (l (i.removeNth t))) :
    shiftIncome a F i l ≤ groupedIncome b a F i l -
      (∑ g, roundingRow (floorW b) g/priceUnit^2 * cost b a F i l (.inr (.inr (.inl .prime))) g) +
      ∑ t : Direct, energy a F i l (.inr t) := by
  rw [sum_income,←book_value]
  refine add_le_add ?_ le_rfl
  change _ ≤ ∑ j : Entry, ∑ g, weight b j g * gaugeCost owner b.ref
    (fun s => base b j s * energy a F i l (.inl s) + slope j * inverseEnergy a F i l (.inl s)) g
  rw [collect_book]
  apply Finset.sum_le_sum
  intro s _
  let P := fun y => l y = s.val ∧ 0 ≤ retainedRadius y ∧ retainedRadius y ≤ capR s.val
  have equal : restrictFace i P F = restricted F i l (.inl s) :=
    (cropped_restriction l capR i F supported s.val).trans (joinFace i l F (.inl s))
  have mz : Measurable (restrictFace i P F) := equal ▸ mf s
  have bounds := prime_moment_interval a i P F ((capR_bound s.val).trans_lt (by norm_num)) (fun _ hit => hit.2) mz bf
  rw [equal] at bounds
  exact affine_moment_comparison bounds.1 bounds.2.1 bounds.2.2 (ch.left s) (ch.right s)

/-- The precise premise of the terminal prime-gap detection theorem follows
from the literal physical estimates and the finite integer certificate. -/
theorem priced_shift (b : Ledger) (ch : FiniteChecks b) (a : Fin (m+2) → ℝ)
    (F : Profile 39 m) (i : Fin 39) (l : LabelFn m)
    (bf : Bornology.IsBounded (Set.range F)) (mf : ∀ s : SectorId, Measurable (restricted F i l (.inl s)))
    (supported : ∀ t, F t ≠ 0 → 0 ≤ retainedRadius (i.removeNth t) ∧
       retainedRadius (i.removeNth t) ≤ capR (l (i.removeNth t)))
    (h : ShiftEstimates b a F i l) :
    Lower (fun x => ∑ n ∈ window x, (primeHit n (shifts i)*z x n) *
      (sampledSelbergRoot (sample tuple182 a F x) (fun j => n+shifts j))^2)
      (shiftIncome a F i l) primeScales := by
  have full := single_shift_prime tuple182 tuple182_card i a F (splitFn l) owner b.ref (floorW b)
    (cost b a F i l (.inr (.inr (.inl .prime)))) ch.refPos ch.floorNonneg ch.floorLo ch.floorHi
    (fun t : Direct => energy a F i l (.inr t)) (groupedIncome b a F i l)
    PhysicalPrices.progression primeScales primeScales_cofinal
    (diagonals b a F i l h .prime) (grouped_lower b ch a F i l h) h.resolved
  have price := archived_le b ch a F i l bf mf supported
  intro ε he
  filter_upwards [full ε he] with x lower
  exact (sub_le_sub_right price ε).trans lower

/-- The same inputs and the independently evaluated strict trial margin
imply the gap bound. Every sampled square uses this F and the common
progression selected by the admissible tuple. -/
theorem gap_of_book (b : Ledger) (ch : FiniteChecks b) (a : Fin (m+2) → ℝ) (inc : StrictMono a)
    (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (F : Profile 39 m) (mf : Measurable F) (bf : Bornology.IsBounded (Set.range F))
    (cf : ∀ᵐ t ∂Measure.pi (fun _ => bandLaw a), ContinuousAt F t)
    (room : ∀ t, F t ≠ 0 → rho*(∑ i, ∑ j, t i j) ≤ EndpointPhysical.radiusCap)
    (l : Fin 39 → LabelFn m)
    (localMeas : ∀ i (s : SectorId), Measurable (restricted F i (l i) (.inl s)))
    (supported : ∀ i t, F t ≠ 0 → 0 ≤ retainedRadius (i.removeNth t) ∧
       retainedRadius (i.removeNth t) ≤ capR (l i (i.removeNth t)))
    (est : ∀ i, ShiftEstimates b a F i (l i))
    (margin : (∫ t, (F t)^2 ∂Measure.pi (fun _ => bandLaw a)) + endpointCost a F <
      rho * ∑ i : Fin 39, shiftIncome a F i (l i)) : primeGapLiminf ≤ (180 : EReal) :=
  gap_of_archived_prices a inc first last F mf bf cf room l margin
    (fun i => priced_shift b ch a F i (l i) bf (localMeas i) (supported i) (est i))

/-- A terminal statement at the level of the arithmetic and quadrature
inputs. The row estimates, grouped estimates, two prime upper estimates,
resolved allowance, and full single-shift prime bound are consequences. -/
theorem gap_of_arithmetic (b : Ledger) (ch : FiniteChecks b) (a : Fin (m+2) → ℝ)
    (inc : StrictMono a) (first : a 0 = 0) (last : a (Fin.last (m+1)) = cap)
    (F : Profile 39 m) (mf : Measurable F) (bf : Bornology.IsBounded (Set.range F))
    (cf : ∀ᵐ t ∂Measure.pi (fun _ => bandLaw a), ContinuousAt F t)
    (room : ∀ t, F t ≠ 0 → rho*(∑ i, ∑ j, t i j) ≤ EndpointPhysical.radiusCap)
    (l : Fin 39 → LabelFn m)
    (localMeas : ∀ i s, Measurable (restricted F i (l i) s))
    (localCont : ∀ i s, ∀ᵐ t ∂Measure.pi (fun _ => bandLaw a),
      ContinuousAt (restricted F i (l i) s) t)
    (supported : ∀ i t, F t ≠ 0 → 0 ≤ retainedRadius (i.removeNth t) ∧
       retainedRadius (i.removeNth t) ≤ capR (l i (i.removeNth t)))
    (number : Row → ℕ) (bands : ∀ k, Fin (number k+1) → ProvedBand (fun x => PhysicalPrices.channel x k))
    (d : Row → ℝ) (densityBounds : ∀ k, min (b.densityLo k) (b.densityHi k) ≤ d k ∧
       d k ≤ max (b.densityLo k) (b.densityHi k))
    (density : ∀ i k, Tendsto (fun x => Real.log x/x * ∑ n ∈ window x,
      Literal.value (PhysicalPrices.channel x k) (n+shifts i)) atTop (𝓝 (d k)))
    (gates : ∀ i k, PairGate a F i (l i) Sum.inl (lifted b k) k (bands k))
    (directGate : ∀ i, PairGate a F i (l i) id resolvedMask .prime
      (fun _ : Unit => PhysicalPrices.ordinary_row .prime))
    (resources : ∀ i (u : Resource), u ≠ .prime → Marked a F i (l i)
      (fun x n => Resources.physical x (n+shifts i) u) (b.resourceKernel u))
    (events : ∀ i (e : Event), e ≠ .prime → Marked a F i (l i)
      (fun x n => PriceEvents.mass x (n+shifts i) e) (b.eventKernel e))
    (margin : (∫ t, (F t)^2 ∂Measure.pi (fun _ => bandLaw a)) + endpointCost a F <
      rho * ∑ i : Fin 39, shiftIncome a F i (l i)) : primeGapLiminf ≤ (180 : EReal) := by
  apply gap_of_book b ch a inc first last F mf bf cf room l (fun i s => localMeas i (.inl s)) supported _ margin
  intro i
  refine estimates_of_individual b ch a inc first last F i (l i) bf
    (fun s => localMeas i (.inl s)) (fun s => localCont i (.inl s)) (supported i) ?_ (resources i) (events i)
    (resolved_of_gate a inc first last F i (l i) bf (localMeas i) (localCont i) (directGate i))
  intro k
  exact affine_of_gate a inc first last F i (l i) Sum.inl Sum.inl_injective bf
    (fun s => localMeas i (.inl s)) (fun s => localCont i (.inl s)) k (lifted b k) (bands k)
    (d k) _ _ (densityBounds k) (gates i k) (density i k)

#print axioms affine_of_gate
#print axioms resolved_of_gate
#print axioms archive_prime_columns
#print axioms estimates_of_individual
#print axioms priced_shift
#print axioms gap_of_book
#print axioms gap_of_arithmetic
end PrimeGap180.Book
