import TrialRemovedHighMass180
import TrialRestorationField180

/-! Sharp owner multiplicities for the high group's 39 signed single-site fields.
Two distinct tag owners pay twice their square. A site owning both tags pays
only once. The counts come from the actual physical fragment measures. -/
noncomputable section
open scoped Classical BigOperators ENNReal
open MeasureTheory PrimeGap186 PrimeGap180.Sector PrimeGap180.FrozenProfile
open PrimeGap180.GateDeletion PrimeGap180.RemovedHighTags PrimeGap180.RemovedHighMass
namespace PrimeGap180.HighTagEnergy

open private counted scaled meas_charged from TrialRemovedHighMass180

def count (X : FiniteMeasure ℝ) : ℕ :=
  ⌊(physicalSourceCountMeasure (fun _ : Fin 1 => X) (Set.Ioi cutoff)).toReal⌋₊

theorem count_meas : Measurable count :=
  (ENNReal.measurable_toReal.comp ((Measure.measurable_coe measurableSet_Ioi).comp
    ((physicalSourceCountMeasure_regular 1).1.comp
      (measurable_pi_lambda _ fun _ => measurable_id)))).nat_floor

private theorem count_insert (Y : FiniteMeasure ℝ) (n : ℕ) (x : Fin n → ℝ)
    (hY : Y.restrict (Set.Ioc 0 cutoff) = Y) (hx : ∀ a, cutoff < x a ∧ x a ≤ cap) :
    count (Y + weightedEmpirical n x) = n := by
  let X := fun _ : Fin 1 => Y + weightedEmpirical n x
  have h := (trial_finite_tail_mass_and_count 1 cutoff (by norm_num [cutoff,Lookup.ticks])
    (fun _ => Y) (fun _ => n) (fun _ => x) (fun _ => hY) (fun _ a => (hx a).1)).2
  have atom (a : (_ : Fin 1) × Fin n) :
      Measure.dirac (x a.2) (Set.Ioi cutoff) = 1 := Measure.dirac_apply_of_mem (hx _).1
  have atCut : physicalSourceCountMeasure X (Set.Ioi cutoff) = (n : ℝ≥0∞) := by
    rw [←Measure.restrict_eq_self _ (Set.Subset.rfl : Set.Ioi cutoff ⊆ Set.Ioi cutoff),h,Measure.finsetSum_apply]
    simp only [atom,Finset.sum_const,Finset.card_univ,nsmul_eq_mul,mul_one,Fintype.card_sigma,
      Fintype.card_fin,Finset.sum_const,Finset.card_univ,one_smul]
  change ⌊(physicalSourceCountMeasure X (Set.Ioi cutoff)).toReal⌋₊ = n
  simp [atCut]

theorem owners : ∀ᵐ X ∂law, X ∈ charged → ∑ i, count (X i) = 2 := by
  rw [scaled]
  apply Measure.ae_smul_measure
  apply fragmentLaw_ae_finite_tail_elim cap cutoff (by norm_num [cap,physicalCap,rho])
    (by norm_num [cutoff,Lookup.ticks]) 39
  · have cm : Measurable (fun X : Config => ∑ i, count (X i)) :=
      Finset.measurable_fun_sum (Finset.univ : Finset (Fin 39)) (fun i _ => count_meas.comp (measurable_pi_apply i))
    have m := measurableSet_eq_fun cm (measurable_const (a := (2:ℕ)))
    have same : {X : Config | X ∈ charged → ∑ i, count (X i) = 2} =
        chargedᶜ ∪ {X : Config | ∑ i, count (X i) = 2} := by
      ext X
      simp only [Set.mem_setOf_eq,Set.mem_union,Set.mem_compl_iff,imp_iff_not_or]
    rw [same]
    exact meas_charged.compl.union m
  · intro Y n x hY hx h
    have both := h.1
    change physicalSourceCountMeasure _ (Set.Ioi cutoff)=2 at both
    rw [counted Y n x hY hx] at both
    simp_rw [count_insert _ _ _ (hY _) (hx _)]
    exact_mod_cast both

def marked (n : ℕ) (a : ℝ) := if n = 0 then 0 else a
def cost (n : ℕ) (a : ℝ) := if n = 1 then 2*a^2 else if n = 2 then a^2 else 0

/-- Weighted Cauchy--Schwarz with the actual number of tags on each owner. -/
theorem square_owners {d : ℕ} (n : Fin d → ℕ) (a : Fin d → ℝ) (hn : ∑ i, n i = 2) :
    (∑ i, marked (n i) (a i))^2 ≤ ∑ i, cost (n i) (a i) := by
  let S := ∑ i, marked (n i) (a i)
  have one (i : Fin d) : 2*S*marked (n i) (a i) ≤
      (n i:ℝ)*(S^2/2) + cost (n i) (a i) := by
    have small : n i ≤ 2 := hn ▸ Finset.single_le_sum (s := Finset.univ)
      (fun j _ => Nat.zero_le (n j)) (Finset.mem_univ i)
    rcases (show n i = 0 ∨ n i = 1 ∨ n i = 2 by omega) with h|h|h
    · simp [h,marked,cost]
    · simp only [h,marked,cost,ite_false,ite_true,one_ne_zero,Nat.cast_one,one_mul]
      nlinarith only [sq_nonneg (S-2*a i)]
    · norm_num [h,marked,cost]
      nlinarith only [sq_nonneg (S-a i)]
  have h := Finset.sum_le_sum (s := Finset.univ) (fun i _ => one i)
  rw [←Finset.mul_sum,Finset.sum_add_distrib,←Finset.sum_mul,←Nat.cast_sum,hn] at h
  change 2*S*S ≤ ((2:ℕ):ℝ)*(S^2/2) + _ at h
  change S^2 ≤ _
  nlinarith only [h]

/-- Specialization to the price-weighted erasures of the original signed spline. -/
def erased (i : Fin 39) (X : Config) := rho * ∑ s : Fin 521, RestorationField.single i s (bands X)

theorem tagged_energy : ∀ᵐ X ∂law, X ∈ charged →
    (∑ i, marked (count (X i)) (erased i X))^2 ≤ ∑ i, cost (count (X i)) (erased i X) := by
  filter_upwards [owners] with X h hx
  exact square_owners _ _ (h hx)

#print axioms owners
#print axioms tagged_energy
end PrimeGap180.HighTagEnergy
