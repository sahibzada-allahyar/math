import TrialPriceFactorDigits180
import Lean.Elab.Command
import Lean.ToExpr

/-! The 49 resource factors and 52 signed event factors of the frozen book.
Every coefficient uses the original row-major signed-64 input. The archive
reader transposes that input and independently checks its inverse bytewise.
The first input index is a group, and the second is a square-factor column. -/
open Lean
namespace PrimeGap180.PriceFactorData

private def little (bytes : ByteArray) (atIndex width : ℕ) : ℕ := Id.run do
  let mut value := 0
  for i in [:width] do
    value := (value <<< 8) + (bytes[atIndex+width-1-i]!).toNat
  return value

private def readColumn (bytes : ByteArray) (start : ℕ) : ℕ := Id.run do
  let mut word := 0
  for r in [:28] do
    let chunk := 27-r
    let mut part := 0
    for t in [:16] do
      let g := 16*chunk+15-t
      let value := if g < 445 then PriceFactorDigits.biasWord (little bytes (start+8*g) 8) else 0
      part := (part <<< 192)+value
    word := (word <<< (192*16))+part
  return word

open Lean Elab Term in
elab "frozenPriceFactorColumns%" : term => do
  let here := (System.FilePath.mk (← getFileName)).parent.getD "."
  IO.FS.withTempDir fun directory => do
    let binary := directory / "columns"
    let proc ← IO.Process.output {cmd := "python3",args := #[(here/"TrialPriceFactorWords180.py").toString,binary.toString]}
    if proc.exitCode != 0 || proc.stdout.trimAscii.toString !=
        "103048b6552ee9b3e97b1834d10fc7b68a610e8c1526bd0d6f589a2c01028933 9975565" then
      throwError "failed to authenticate frozen factors {proc.stderr}"
    let bytes ← IO.FS.readBinFile binary
    unless bytes.size == 101*4+8*9975565 do throwError "wrong signed factor input size"
    let mut cursor := 0
    let mut rows : Array (Array Nat) := #[]
    for _ in [:101] do
      let rank := little bytes cursor 4
      cursor := cursor+4
      unless rank ≤ 445 && cursor+8*445*rank ≤ bytes.size do throwError "wrong signed factor shape"
      rows := rows.push ((Array.range rank).map fun j => readColumn bytes (cursor+8*445*j))
      cursor := cursor+8*445*rank
    unless cursor == bytes.size do throwError "trailing signed factor bytes"
    return toExpr rows

noncomputable section
set_option maxRecDepth 131072 in
set_option maxHeartbeats 100000000 in
private def matrices : Array (Array ℕ) := frozenPriceFactorColumns%

open Lean Elab Term in
elab "priceFactorMask445%" : term => do
  return toExpr (((2:Nat)^64-1) * (((2:Nat)^(192*445)-1)/((2:Nat)^192-1)))

open Lean Elab Term in
elab "priceFactorBias445%" : term => do
  return toExpr (((2:Nat)^63) * (((2:Nat)^(192*445)-1)/((2:Nat)^192-1)))

def mask445 : Nat := priceFactorMask445%
def bias445 : Nat := priceFactorBias445%

def validWord (w : ℕ) : Bool :=
  decide (w < (2:ℕ)^(192*445) ∧ w &&& mask445 = w)

def columns (m : ℕ) := matrices[m]?.getD #[]
def rank (m : ℕ) := (columns m).size
def word (m j : ℕ) := (columns m)[j]?.getD 0
def factor (m g j : ℕ) : ℤ := PriceFactorDigits.coefficient (word m j) g
def columnAction (m j : ℕ) : ℤ := (word m j:ℤ)-(bias445:ℤ)

def rowCheck (m : ℕ) := (columns m).all validWord

end
end PrimeGap180.PriceFactorData
