import TrialSourceAffineSpanData180
namespace PrimeGap180.SourceAffine.Spans
set_option maxRecDepth 131072
set_option maxHeartbeats 100000000
theorem row06 : spanRow 6 = true := by decide +kernel
#print axioms row06
end PrimeGap180.SourceAffine.Spans
