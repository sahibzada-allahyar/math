import TrialHarmonicTagArea180

/-! Same-band two-tag radial cell, including the unordered-pair factor. -/
noncomputable section
open scoped Classical ENNReal BigOperators
open MeasureTheory Set PrimeGap186 PrimeGap180.JanossyLaw
namespace PrimeGap180.TwoTagCell
open FixedTagIntegral
open private weight_le from TrialOneTagCell180

/-- Keep the ordered harmonic integral explicit so a sharper area enclosure
can be substituted before any signed Gram calculation. -/
theorem section_bound {a b : ℝ} (ha : 0<a) (hb : a≤b) (L H : ℝ) :
    (PoissonSplit.phys b) ({X | markCount a X = 2} ∩
        {X : FiniteMeasure ℝ | (X.mass:ℝ) ∈ Ico L H}) ≤
      (2:ℝ≥0∞)⁻¹ * (ENNReal.ofReal (H-L) *
        ∫⁻ x, PoissonSplit.intensity a b (Iic (H-x)) ∂PoissonSplit.intensity a b) := by
  let ν := PoissonSplit.intensity a b
  let : IsFiniteMeasure ν := (PoissonSplit.jumps ha hb).property
  let K := ENNReal.ofReal (H-L)
  let W := (Iic H).indicator (fun _ => K)
  let P := fun q : ℝ × ℝ => W (q.1 + q.2)
  have mP : Measurable P := (measurable_const.indicator measurableSet_Iic).comp
    (measurable_fst.add measurable_snd)
  have h := FixedTagRadial.cell ha hb 2 L H
  have fact : (2:ℕ).factorial = 2 := by decide
  rw [fact,Nat.cast_ofNat] at h
  apply h.trans
  have site (x : ℝ) : (∫⁻ y, P (x,y) ∂ν) = K * ν (Iic (H-x)) := by
    have eq (y : ℝ) : P (x,y) = (Iic (H-x)).indicator (fun _ => K) y := by
      simp only [P,W,indicator_apply,mem_Iic]
      simp only [le_sub_iff_add_le,add_comm y x]
    simp_rw [eq]
    rw [lintegral_indicator measurableSet_Iic,lintegral_const,Measure.restrict_apply_univ]
  calc
    _ ≤ ∫⁻ u : Fin 2 → ℝ, (2:ℝ≥0∞)⁻¹ * W (total u) ∂prodLaw a b 2 :=
      lintegral_mono (fun u => mul_le_mul_of_nonneg_left (weight_le L H (total u)) zero_le)
    _ = (2:ℝ≥0∞)⁻¹ * ∫⁻ q, P q ∂ν.prod ν := by
      rw [lintegral_const_mul' _ _ (by norm_num)]
      congr 1
      have chart := (measurePreserving_finTwoArrow ν).lintegral_comp mP
      have coordinates (u : Fin 2 → ℝ) : P (MeasurableEquiv.finTwoArrow u) = W (u 0 + u 1) := rfl
      simpa only [prodLaw,total,Fin.sum_univ_two,coordinates,ν] using chart
    _ = (2:ℝ≥0∞)⁻¹ * (K * ∫⁻ x, ν (Iic (H-x)) ∂ν) := by
      rw [lintegral_prod _ mP.aemeasurable]
      simp_rw [site]
      rw [lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]

/-- Positive physical cell bound when two labelled insertion variables range
over one band. No independence between the cell test and the marks is assumed. -/
theorem physical {a b : ℝ} (ha : 0<a) (hb : a≤b) (L H : ℝ) :
    (PoissonSplit.phys b) ({X | markCount a X = 2} ∩
        {X : FiniteMeasure ℝ | (X.mass:ℝ) ∈ Ico L H}) ≤
      (2:ℝ≥0∞)⁻¹ * (ENNReal.ofReal (H-L) *
        (ENNReal.ofReal (1/a) * (ENNReal.ofReal (1/a) *
        ENNReal.ofReal (HarmonicTagArea.cap (b-a) (b-a) (max (H-a-a) 0))))) :=
  (section_bound ha hb L H).trans <| mul_le_mul_of_nonneg_left
    (mul_le_mul_of_nonneg_left (HarmonicTagArea.two ha hb ha hb H) zero_le) zero_le

#print axioms section_bound
#print axioms physical
end PrimeGap180.TwoTagCell
