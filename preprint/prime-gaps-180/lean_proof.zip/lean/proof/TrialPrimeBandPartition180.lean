import PrimeGaps186

noncomputable section
open scoped BigOperators Topology
open Filter PrimeGap186
namespace PrimeGap180.Retained

def primesIn (l u : ℕ) := (Finset.Icc l u).filter Nat.Prime
def bands (l u : ℕ) := (primesIn l u).image (Nat.log 2)
def left (l b : ℕ) := max l (2^b)
def right (u b : ℕ) := min u (2^(b+1)-1)

theorem band_primes (l u b : ℕ) :
    (primesIn l u).filter (fun p => Nat.log 2 p = b) = primesIn (left l b) (right u b) := by
  ext p
  simp only [primesIn,left,right,Finset.mem_filter,Finset.mem_Icc,max_le_iff,le_min_iff]
  by_cases pp : p.Prime
  · have low := Nat.le_log_iff_pow_le (by decide : 1 < 2) pp.ne_zero (x := b)
    have hi := Nat.log_lt_iff_lt_pow (by decide : 1 < 2) pp.ne_zero (x := b+1)
    have powpos : 0 < 2^(b+1) := by positivity
    constructor
    · rintro ⟨⟨⟨hl,hu⟩,_⟩,eq⟩
      have bot := low.mp eq.ge
      have top := hi.mp (by omega)
      exact ⟨⟨⟨hl,bot⟩,hu,by omega⟩,pp⟩
    · rintro ⟨⟨⟨hl,bot⟩,hu,top⟩,_⟩
      have h₁ := low.mpr bot
      have h₂ := hi.mpr (by omega)
      exact ⟨⟨⟨hl,hu⟩,pp⟩,by omega⟩
  · tauto

theorem band_size {l u b : ℕ} (hb : b ∈ bands l u) :
    l ≤ left l b ∧ left l b ≤ right u b ∧ right u b ≤ 2*left l b ∧ right u b ≤ u := by
  obtain ⟨p,hp,eq⟩ := Finset.mem_image.mp hb
  have h : p ∈ (primesIn l u).filter (fun t => Nat.log 2 t = b) := Finset.mem_filter.mpr ⟨hp,eq⟩
  rw [band_primes] at h
  have hpair := Finset.mem_Icc.mp (Finset.mem_filter.mp h).1
  refine ⟨le_max_left _ _,hpair.1.trans hpair.2,?_,min_le_left _ _⟩
  exact (min_le_right _ _).trans ((Nat.sub_le _ 1).trans
    (by rw [pow_succ, Nat.mul_comm]; exact Nat.mul_le_mul_left _ (le_max_right _ _)))

theorem band_count {l u : ℕ} {x : ℝ} (hx : 1 ≤ Real.log x) (hu : (u:ℝ) ≤ x) :
    ((bands l u).card:ℝ) ≤ (1+(Real.log 2)⁻¹)*Real.log x := by
  have mem : bands l u ⊆ Finset.range (⌊Real.logb 2 x⌋₊+1) := by
    intro b hb
    obtain ⟨p,hp,rfl⟩ := Finset.mem_image.mp hb
    obtain ⟨hi,pp⟩ := Finset.mem_filter.mp hp
    have bound := (Nat.cast_le.mpr (Finset.mem_Icc.mp hi).2).trans hu
    have le := (Real.natLog_le_logb p 2).trans (Real.logb_le_logb_of_le
      (by norm_num : (1:ℝ) < (2:ℕ)) (Nat.cast_pos.mpr pp.pos) bound)
    exact Finset.mem_range.mpr (Nat.lt_succ_of_le (Nat.le_floor (by simpa using le)))
  have card : ((bands l u).card:ℝ) ≤ (Finset.range (⌊Real.logb 2 x⌋₊+1)).card := Nat.cast_le.mpr (Finset.card_le_card mem)
  simp only [Finset.card_range,Nat.cast_add,Nat.cast_one] at card
  have pos : 0 ≤ Real.logb 2 x := div_nonneg (by linarith only [hx]) (Real.log_nonneg (by norm_num))
  have fl := Nat.floor_le pos
  rw [Real.logb,div_eq_mul_inv] at fl card
  nlinarith only [card,fl,hx]

theorem band_partition (L U : Fin 3 → ℕ) :
    primeIntervalBoxAlgebra (fun i => (L i:ℝ)) (fun i => (U i:ℝ)) Finset.univ =
    ∑ b ∈ Fintype.piFinset (fun i => bands (L i) (U i)),
      primeIntervalBoxAlgebra (fun i => (left (L i) (b i):ℝ))
        (fun i => (right (U i) (b i):ℝ)) Finset.univ := by
  classical
  let weight := fun p : ℕ => (MonoidAlgebra.single p (1:ℂ) : MonoidAlgebra ℂ ℕ)
  have piece (l u : ℕ) :
      (∑ p ∈ primesIn l u, weight p) =
      ∑ b ∈ bands l u, ∑ p ∈ primesIn (left l b) (right u b), weight p := by
    simp_rw [← band_primes]
    exact (Finset.sum_fiberwise_of_maps_to (s := primesIn l u) (t := bands l u) (g := Nat.log 2)
      (fun p hp => Finset.mem_image_of_mem _ hp) weight).symm
  simp only [primeIntervalBoxAlgebra,Nat.ceil_natCast,Nat.floor_natCast]
  change (∏ i, ∑ p ∈ primesIn (L i) (U i), weight p) = _
  calc
    _ = ∏ i, ∑ b ∈ bands (L i) (U i), ∑ p ∈ primesIn (left (L i) b) (right (U i) b), weight p :=
      Finset.prod_congr rfl fun i _ => piece _ _
    _ = _ := Finset.prod_univ_sum _ _

#print axioms band_partition
end PrimeGap180.Retained
