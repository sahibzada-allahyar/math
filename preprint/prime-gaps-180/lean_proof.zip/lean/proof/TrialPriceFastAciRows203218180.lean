import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G203
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 203

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G203

namespace PrimeGap180.PriceIsolatedGroup.G208
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 208

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G208

namespace PrimeGap180.PriceIsolatedGroup.G213
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 213

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G213

namespace PrimeGap180.PriceIsolatedGroup.G218
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 218

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G218
