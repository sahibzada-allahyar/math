"""Directed products for the unmarked 37-site Gram and its two ordinary endpoints (one cap, default 36)."""
import argparse
from pathlib import Path

from build_historical_site_rows import columns
from cap_bank_names import Names, cap_argument
from check_exact_endpoint_pair import site
from endpoint_pair_arithmetic import COUNT, encode, multiply

# The 37-site bank splits each count at floor(count / 2).
# The two endpoints are multiplied separately before meeting the interior.
POWER_FACTORS = {
    2: (1, 1), 3: (1, 2), 4: (2, 2), 5: (2, 3), 9: (4, 5),
    10: (5, 5), 18: (9, 9), 19: (9, 10), 36: (18, 18), 37: (18, 19), 39: (37, 2),
}


def module(degree, cap=36):
    return Names(cap).module(f"Power{degree:02d}")


def lean_names(degree, cap=36):
    square = Names(cap).ns("Square")
    if degree == 1:
        return f"{square}.lo", f"{square}.hi", "one", "maskOne"
    if degree == 2:
        return f"{square}.resultLo", f"{square}.resultHi", "two", "maskTwo"
    return f"lo{degree}", f"hi{degree}", f"power{degree}", f"masks{degree}"


def generate(destination, cap=36, dry_run=False):
    names = Names(cap)
    destination.mkdir(parents=True, exist_ok=True)
    values = {} if dry_run else {1: site(columns()[cap][:COUNT])}
    kept = "kept" if names.legacy else f"CapBank.keptPow {cap}"
    merge = "merge" if names.legacy else f"CapBank.merge {cap}"
    sources = {}
    for degree, (left, right) in POWER_FACTORS.items():
        if not dry_run:
            value = multiply(values[left], values[right])
            values[degree] = value
        if degree == 2:
            continue  # The physical square already has its own certificate.
        words = []
        for label in ("lo", "hi"):
            filename = f"power-{degree:02d}-{label}.bin"
            if not dry_run:
                integers = value.low if label == "lo" else value.high
                if max(integers).bit_length() > 296:
                    raise ValueError(f"Power {degree} exceeds the checked lane capacity")
                (destination / filename).write_bytes(encode(integers, 80))
            words.append(f'def {label}{degree} := {names.word} "{filename}" 10477200')

        lo_l, hi_l, proof_l, mask_l = lean_names(left, cap)
        lo_r, hi_r, proof_r, mask_r = lean_names(right, cap)
        imports = [f"import {names.unmarked_module}"]
        imports.extend("import " + module(x, cap) for x in sorted({left, right}) if x > 2)
        lines = [
            *imports, "", f"namespace PrimeGap180.{names.ns('Unmarked')}",
            "open CapWordConvolution ParallelConvolution", "set_option maxHeartbeats 0",
            "set_option maxRecDepth 18000", "set_option exponentiation.threshold 100000000",
            *words, "",
            f"theorem masks{degree} : mask 640 296 130965 lo{degree}=true ∧ "
            f"mask 640 296 130965 hi{degree}=true := by decide +kernel",
            f"private theorem values{degree} : wordLow 640 256 130965 {lo_l} {lo_r}=lo{degree} ∧",
            f"    wordHigh 640 256 130965 {hi_l} {hi_r}=hi{degree} := by decide +kernel",
            f"theorem power{degree} : {kept} {degree} lo{degree} hi{degree} :=",
            f"  {merge} {left} {right} _ _ _ _ _ _ {proof_l} {proof_r} {mask_l}.1 {mask_l}.2 "
            f"{mask_r}.1 {mask_r}.2 values{degree}.1 values{degree}.2",
            f"#print axioms power{degree}", f"end PrimeGap180.{names.ns('Unmarked')}", "",
        ]
        name = module(degree, cap)
        path = destination / (name + ".lean")
        path.write_text("\n".join(lines))
        sources[name] = path
    return sources


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    cap_argument(p)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--dry-run", action="store_true", help="write Lean text without words")
    a = p.parse_args()
    for n in generate(a.output_dir, a.cap, a.dry_run):
        print(n)
