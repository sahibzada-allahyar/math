import TrialSourceAffineCompactData180
import TrialSourceGeometryBitmap180

/-! A zero run in the original signed row can be checked by one shift
and modulus, even when several hundred adjacent entries are zero. -/
namespace PrimeGap180.SourceAffine.Spans

abbrev Span := Nat × Nat

def flags (s : Span) := (2^s.2-1) <<< s.1

def chunk (word : Nat) (s : Span) := (word >>> (64*s.1)) % 2^(64*s.2)

def check (p : Nat × Nat) (rs : List Span) :=
  (p.2 == SourceBitmap.union flags rs) && rs.all (fun r => chunk p.1 r == 0)

private theorem component {word : Nat} {r : Span} {j : Nat}
    (on : (flags r).testBit j = true) (zero : chunk word r = 0) : entry word j = 0 := by
  have cond : r.1 ≤ j ∧ j-r.1 < r.2 := by
    simpa only [flags,Nat.testBit_shiftLeft,Nat.testBit_two_pow_sub_one,Bool.and_eq_true_iff,
      decide_eq_true_eq] using on
  have slice : lane word j = 0 := by
    apply Nat.eq_of_testBit_eq
    intro i
    simp only [lane,full,Nat.testBit_and,Nat.testBit_two_pow_sub_one,Nat.testBit_shiftRight,Nat.zero_testBit]
    by_cases small : i < 64
    · have inner : 64*(j-r.1)+i < 64*r.2 := by omega
      have eq : 64*r.1+(64*(j-r.1)+i) = 64*j+i := by omega
      have off := congrArg (fun t : Nat => t.testBit (64*(j-r.1)+i)) zero
      simp only [chunk,Nat.testBit_mod_two_pow,Nat.testBit_shiftRight,decide_eq_true inner,
        Bool.true_and,eq,Nat.zero_testBit] at off
      simp only [off,Bool.false_and]
    · simp only [decide_eq_false small,Bool.and_false]
  rw [entry,slice]
  rfl

theorem zero_of_checked {p : Nat × Nat} {rs : List Span} {j : Nat}
    (checked : check p rs = true) (on : p.2.testBit j = true) : entry p.1 j = 0 := by
  have c := Bool.and_eq_true_iff.mp checked
  have bits : p.2 = SourceBitmap.union flags rs := beq_iff_eq.mp c.1
  rw [bits] at on
  obtain ⟨r,member,hit⟩ := SourceBitmap.witness on
  exact component hit (beq_iff_eq.mp (List.all_eq_true.mp c.2 _ member))

#print axioms zero_of_checked
end PrimeGap180.SourceAffine.Spans
