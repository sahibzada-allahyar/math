import TrialPriceFrozenSourceRows180
namespace PrimeGap180.PriceFactorSourceProof
set_option maxRecDepth 131072
set_option maxHeartbeats 100000000
set_option profiler true in
private theorem m50 : PriceFactorData.sourceCheck 50 = true := by decide +kernel
set_option profiler true in
private theorem m51 : PriceFactorData.sourceCheck 51 = true := by decide +kernel
set_option profiler true in
private theorem m52 : PriceFactorData.sourceCheck 52 = true := by decide +kernel
set_option profiler true in
private theorem m53 : PriceFactorData.sourceCheck 53 = true := by decide +kernel
set_option profiler true in
private theorem m54 : PriceFactorData.sourceCheck 54 = true := by decide +kernel
set_option profiler true in
private theorem m55 : PriceFactorData.sourceCheck 55 = true := by decide +kernel
set_option profiler true in
private theorem m56 : PriceFactorData.sourceCheck 56 = true := by decide +kernel
set_option profiler true in
private theorem m57 : PriceFactorData.sourceCheck 57 = true := by decide +kernel
set_option profiler true in
private theorem m58 : PriceFactorData.sourceCheck 58 = true := by decide +kernel
set_option profiler true in
private theorem m59 : PriceFactorData.sourceCheck 59 = true := by decide +kernel
theorem batch5 : ∀ i : Fin 10, PriceFactorData.sourceCheck (50+i.val) = true :=
  Fin.cases m50 (Fin.cases m51 (Fin.cases m52 (Fin.cases m53 (Fin.cases m54 (Fin.cases m55 (Fin.cases m56 (Fin.cases m57 (Fin.cases m58 (Fin.cases m59 (fun i => Fin.elim0 i))))))))))
#print axioms batch5
end PrimeGap180.PriceFactorSourceProof
