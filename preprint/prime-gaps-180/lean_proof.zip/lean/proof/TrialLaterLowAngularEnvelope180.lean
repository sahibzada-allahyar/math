import TrialSignedEnvelopeDirected180
import TrialSignedEnvelopeReceiver180
import TrialLaterLowFactor180

/-! Absolute Bernstein controls for all 99 physical angular channels and the
positive angular envelope for the original 39-site spline. -/
noncomputable section
open scoped BigOperators
namespace PrimeGap180.LowAngularBernstein
open FrozenProfile EnvelopeKernel EnvelopePanels EnvelopePolynomial EnvelopeCached
open EnvelopeInteger (dot signedScale)
open EnvelopeCachedSource (num den)
open private scale_rat times_qpoly from TrialSignedEnvelopeDirected180

def controls (f : Fin 4→ℤ) : Fin 4→ℤ :=
  ![3*f 0,3*f 0+f 1,3*f 0+2*f 1+f 2,3*(f 0+f 1+f 2+f 3)]

def weights (z : ℚ) : Fin 4→ℚ :=
  ![(1-z)^3,3*z*(1-z)^2,3*z^2*(1-z),z^3]

private theorem weight_nonneg {z : ℚ} (lo : 0≤z) (hi : z≤1) (i : Fin 4) : 0≤weights z i := by
  have nn:=sub_nonneg.mpr hi
  fin_cases i <;> simp [weights] <;> positivity

theorem convex (f : Fin 4→ℤ) (D B : ℕ) (hd : 0<D) {z : ℚ} (hz : 0≤z) (ho : z≤1)
    (h : ∀ k, |controls f k| ≤ (3*(D:ℤ)*B)) :
    |eval z (qpoly f (D:ℚ))| ≤ (B:ℚ) := by
  have den_pos : 0<(3:ℚ)*D := by positivity
  have sw : (∑ k,weights z k)=1 := by simp [Fin.sum_univ_four,weights]; ring
  have eq : ((3:ℚ)*D)*eval z (qpoly f D) =
      ∑ k : Fin 4, weights z k*(controls f k:ℚ) := by
    simp [Fin.sum_univ_four,weights,controls,eval,qpoly]
    field_simp
    ring
  apply (mul_le_mul_iff_right₀ den_pos).mp
  rw [←abs_of_pos den_pos,←abs_mul,eq]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  calc
    _ ≤ ∑ k, weights z k*((3:ℚ)*D*B) := by
      apply Finset.sum_le_sum
      intro k _
      rw [abs_mul,abs_of_nonneg (weight_nonneg hz ho k)]
      apply mul_le_mul_of_nonneg_left _ (weight_nonneg hz ho k)
      exact_mod_cast h k
    _ = _ := by rw [←Finset.sum_mul,sw,one_mul,abs_of_pos den_pos]

def numerators (i : Fin 27) (u : Fin 3) (a b : Fin 3) (s : Fin 11) : Fin 4→ℤ :=
  fun k=>signedScale false s*dot (fun j=>num u a b s (base i+j.val)) (fun j=>nums i j.val) k

def commonDen (i : Fin 27) := den*(entry i).den

private theorem polynomial (i : Fin 27) (u : Fin 3) (a b : Fin 3) (s : Fin 11)
    (mat : EnvelopeDirectedChecks.BasisMatches i) :
    poly (atIndex i) u.val a b s false = qpoly (numerators i u a b s) ((commonDen i):ℚ) := by
  have sp := (spans i).2.1
  have hb (k : ℕ) (lo : k≤(atIndex i).span) (hi : (atIndex i).span≤k+3) :
      cBasis i k=basis (atIndex i) 3 k := by
    let z : Fin 4 := ⟨k-((atIndex i).span-3),by omega⟩
    have eq : (atIndex i).span-3+z.val=k := by dsimp [z]; omega
    simpa only [eq] using mat z
  unfold poly
  rw [←EnvelopeCachedSource.qrow_eq,←cubic_eq _ _ _ hb,EnvelopeInteger.fused_eq,←scale_rat]
  unfold EnvelopeInteger.fused commonDen numerators
  push_cast
  rw [times_qpoly]

def Checked (i : Fin 27) (C : Fin 3→Fin 3→Fin 11→ℕ) :=
  ∀ u a b s k, |controls (numerators i u a b s) k| ≤ 3*(commonDen i:ℤ)*C a b s

theorem channel (C : Fin 3→Fin 3→Fin 11→ℕ) (mat : ∀ i,EnvelopeDirectedChecks.BasisMatches i)
    (checks : ∀ i,Checked i C) (j : ℕ) (lo : 102994≤j) (hi : j≤130964)
    (c : Fine) (a b : Fin 3) (s : Fin 11) :
    |norm s*∑ k : Fin 30,FrozenData.splineQ j k * FrozenData.rowQ c ⟨3*a.val+b.val,by omega⟩ s k| ≤ C a b s := by
  obtain ⟨i,inside⟩:=cover lo hi
  obtain ⟨wide,ls,rs,act⟩:=spans i
  obtain ⟨z,hz,ho,exactBasis⟩:=physical (atIndex i) inside wide ls rs act
  let u : Fin 3:=⟨suffix c,suffix_range c⟩
  have hc:=EnvelopeKernel.channel (atIndex i) c a b s false j z exactBasis
  simp only [EnvelopeKernel.sign,Bool.false_eq_true,↓reduceIte,one_mul] at hc
  rw [←hc,polynomial i u a b s (mat i)]
  exact convex _ _ _ (by have a : 0<den := by decide +kernel
                         have b : ∀ k : Fin 27, 0<(entry k).den := by decide +kernel
                         exact Nat.mul_pos a (b i)) hz ho (checks i u a b s)

#print axioms convex
#print axioms channel
end PrimeGap180.LowAngularBernstein

end

open scoped BigOperators
namespace PrimeGap180.LowAngularBernstein
open EnvelopeDirectedChecks
set_option maxRecDepth 131072
set_option maxHeartbeats 0

def caps : Fin 3→Fin 3→Fin 11→ℕ := ![![![5,111,589,2438,660,7821,10918,6037,8753,10748,27750],![279,14468,97864,589521,268565,3349429,1734974,3374336,9142996,5872833,10392279],![28,1151,532,14119,12311,5723,19808,16561,21843,7507,11719]],![![279,14468,97864,589521,268565,3349429,1734974,3374336,9142996,5872833,10392279],![47635,2554626,14309807,130143781,86410147,1783549025,1037077200,9210401559,14925975971,3621465738,8485806467],![2899,72040,541236,1454388,997167,1720736,5424148,36651058,36027313,6440458,13714394]],![![28,1151,532,14119,12311,5723,19808,16561,21843,7507,11719],![2899,72040,541236,1454388,997167,1720736,5424148,36651058,36027313,6440458,13714394],![40,378,6692,14358,8165,60405,33033,56524,36838,62467,71443]]]

private theorem row00 : BasisMatches 0 ∧ Checked 0 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row01 : BasisMatches 1 ∧ Checked 1 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row02 : BasisMatches 2 ∧ Checked 2 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row03 : BasisMatches 3 ∧ Checked 3 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row04 : BasisMatches 4 ∧ Checked 4 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row05 : BasisMatches 5 ∧ Checked 5 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row06 : BasisMatches 6 ∧ Checked 6 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row07 : BasisMatches 7 ∧ Checked 7 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row08 : BasisMatches 8 ∧ Checked 8 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row09 : BasisMatches 9 ∧ Checked 9 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row10 : BasisMatches 10 ∧ Checked 10 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row11 : BasisMatches 11 ∧ Checked 11 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row12 : BasisMatches 12 ∧ Checked 12 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row13 : BasisMatches 13 ∧ Checked 13 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row14 : BasisMatches 14 ∧ Checked 14 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row15 : BasisMatches 15 ∧ Checked 15 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row16 : BasisMatches 16 ∧ Checked 16 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row17 : BasisMatches 17 ∧ Checked 17 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row18 : BasisMatches 18 ∧ Checked 18 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row19 : BasisMatches 19 ∧ Checked 19 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row20 : BasisMatches 20 ∧ Checked 20 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row21 : BasisMatches 21 ∧ Checked 21 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row22 : BasisMatches 22 ∧ Checked 22 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row23 : BasisMatches 23 ∧ Checked 23 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row24 : BasisMatches 24 ∧ Checked 24 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row25 : BasisMatches 25 ∧ Checked 25 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

private theorem row26 : BasisMatches 26 ∧ Checked 26 caps := by
  constructor
  · change ∀ k : Fin 4, _
    decide +kernel
  · unfold Checked
    decide +kernel

theorem all_rows : ∀ i, BasisMatches i ∧ Checked i caps := by
  intro i
  fin_cases i
  · exact row00
  · exact row01
  · exact row02
  · exact row03
  · exact row04
  · exact row05
  · exact row06
  · exact row07
  · exact row08
  · exact row09
  · exact row10
  · exact row11
  · exact row12
  · exact row13
  · exact row14
  · exact row15
  · exact row16
  · exact row17
  · exact row18
  · exact row19
  · exact row20
  · exact row21
  · exact row22
  · exact row23
  · exact row24
  · exact row25
  · exact row26

theorem cap_channels (j : ℕ) (lo : 102994≤j) (hi : j≤130964)
    (c : FrozenProfile.Fine) (a b : Fin 3) (s : Fin 11) :
    |EnvelopeKernel.norm s*∑ k : Fin 30,FrozenData.splineQ j k *
      FrozenData.rowQ c ⟨3*a.val+b.val,by omega⟩ s k| ≤ caps a b s :=
  channel caps (fun i=>(all_rows i).1) (fun i=>(all_rows i).2) j lo hi c a b s

#print axioms all_rows
#print axioms cap_channels
end PrimeGap180.LowAngularBernstein


noncomputable section
open MeasureTheory Filter Set PrimeGap180.Sector PrimeGap180.FrozenProfile
open scoped BigOperators
namespace PrimeGap180.LowAngularPhysical
open EnvelopeAngular (expAt)
open GateDeletion (T Full)
open LowAngularBernstein (caps cap_channels)
open private center center_nn scalar factors factor_nn from TrialSignedEnvelopeReceiver180
open private site_shape from TrialSignedEnvelopeReceiver180

def endpoint (x : ℝ) (a : Fin 3) := x^(expAt a)/(131072*Native.step)^(expAt a)
def core (t : Fin 37→ℝ) (s : Fin 11) := ((signatures s).map fun e=>∑ i,t i^e).prod
def bound (v : Fin 39→ℝ) := ∑ a : Fin 3,∑ b : Fin 3,∑ s : Fin 11,
  (caps a b s:ℝ)*endpoint (v 0) a*endpoint (v (Fin.last 38)) b*
    core (fun i : Fin 37=>v i.castSucc.succ) s

private theorem core_nonneg (v : Fin 37→ℝ) (hv : ∀ i,0≤v i) (s : Fin 11) : 0≤core v s := by
  apply List.prod_nonneg
  intro q hq
  obtain ⟨j,_,rfl⟩:=List.mem_map.mp hq
  exact Finset.sum_nonneg fun i _=>pow_nonneg (hv i) j

private theorem end_nn {x : ℝ} (hx : 0≤x) (a : Fin 3) : 0≤endpoint x a := by
  unfold endpoint
  exact div_nonneg (pow_nonneg hx _) (pow_nonneg (by norm_num [Native.step]) _)

theorem bound_nonneg (v : Fin 39→ℝ) (hv : ∀ i,0≤v i) : 0≤bound v := by
  apply Finset.sum_nonneg
  intro a _
  apply Finset.sum_nonneg
  intro b _
  apply Finset.sum_nonneg
  intro s _
  exact mul_nonneg (mul_nonneg (mul_nonneg (Nat.cast_nonneg _) (end_nn (hv _) _))
    (end_nn (hv _) _)) (core_nonneg _ (fun i=>hv _) _)

private theorem one (j : Fin 39→ℕ) (c : Fine) (lo : 102994≤∑ i,j i) (hi : (∑ i,j i)≤130964)
    (a b : Fin 3) (s : Fin 11) :
    |EnvelopeAngular.angular (center (j 0)) (center (j (Fin.last 38))) (fun i : Fin 37=>center (j i.castSucc.succ)) a b s *
      ((EnvelopeKernel.norm s:ℝ)*∑ k : Fin 30,T.spline (∑ i,j i) k*T.row c ⟨3*a.val+b.val,by omega⟩ s k)| ≤
    (caps a b s:ℝ)*endpoint (center (j 0)) a*endpoint (center (j (Fin.last 38))) b*
      core (fun i : Fin 37=>center (j i.castSucc.succ)) s := by
  let x:=center (j 0)
  let y:=center (j (Fin.last 38))
  let u:=fun i : Fin 37 =>center (j i.castSucc.succ)
  obtain ⟨xn,xu⟩:=site_shape x (center_nn _) a
  obtain ⟨yn,yu⟩:=site_shape y (center_nn _) b
  have cn:=core_nonneg u (fun i=>center_nn _) s
  have capR := (Rat.cast_le (K:=ℝ)).mpr (cap_channels _ lo hi c a b s)
  push_cast at capR
  have ang : 0 ≤ EnvelopeAngular.angular x y u a b s := mul_nonneg (mul_nonneg xn yn) cn
  rw [abs_mul,abs_of_nonneg ang]
  simp_rw [FrozenData.spline_eq_rat,FrozenData.row_eq_rat]
  have h:=mul_le_mul_of_nonneg_left capR (mul_nonneg (mul_nonneg xn yn) cn)
  apply h.trans
  have e:=mul_le_mul xu yu yn (end_nn (center_nn (j 0)) a)
  exact (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right e cn) (Nat.cast_nonneg _)).trans_eq (by dsimp only [endpoint,x,y,u]; ring)

private theorem ordinary (j : Fin 39→ℕ) (c : Fine) (lo : 102994≤∑ i,j i) (hi : (∑ i,j i)≤130964) :
    |amplitude T j c| ≤ (∏ i,siteFactor (center (j i)))*bound (fun i=>center (j i)) := by
  rw [factors,abs_mul,abs_of_nonneg (Finset.prod_nonneg fun i _=>factor_nn _ (center_nn _))]
  apply mul_le_mul_of_nonneg_left _ (Finset.prod_nonneg fun i _=>factor_nn _ (center_nn _))
  unfold scalar bound
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  apply Finset.sum_le_sum
  intro a _
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  apply Finset.sum_le_sum
  intro b _
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  exact Finset.sum_le_sum fun s _=>one j c lo hi a b s

theorem native (v : Full) (lo : 102994≤Native.cellSum v) :
    |Restoration.original v| ≤ (∏ i,siteFactor (center (Native.cell (v i))))*
      bound (fun i=>center (Native.cell (v i))) := by
  have rn (i : Fin 39) : 0 ≤ siteFactor (center (Native.cell (v i))) := factor_nn _ (center_nn _)
  by_cases zero : Restoration.original v=0
  · rw [zero,abs_zero]
    exact mul_nonneg (Finset.prod_nonneg fun i _=>rn i) (bound_nonneg _ fun i=>center_nn _)
  have high:=Restoration.original_index v zero
  let j:=fun i=>Native.cell (v i)
  have idx : indices (bits T v)=j := by
    funext k
    rw [index_eq]
    exact min_eq_left ((Finset.single_le_sum (f:=j) (fun _ _=>Nat.zero_le _) (Finset.mem_univ k)).trans (high.trans (by decide)))
  change |GateDeletion.originalValue (bits T v)| ≤ _
  change GateDeletion.originalValue (bits T v)≠0 at zero
  unfold GateDeletion.originalValue at zero ⊢
  cases choose : least (fun c=>bits T v (.cap c)) with
  | none => simp [choose] at zero
  | some c =>
    simp only [choose,idx] at zero ⊢
    unfold raw at zero ⊢
    split
    · rename_i bad
      exact False.elim (zero (ite_eq_left bad))
    · exact ordinary j c lo high


private theorem monotone (v w : Fin 39→ℝ) (hv : ∀ i,0≤v i) (vw : ∀ i,v i≤w i) :
    bound v≤bound w := by
  have hw (i : Fin 39) : 0≤w i := (hv i).trans (vw i)
  have en (i : Fin 39) (a : Fin 3) : endpoint (v i) a ≤ endpoint (w i) a :=
    div_le_div_of_nonneg_right (pow_le_pow_left₀ (hv i) (vw i) _) (pow_nonneg (by norm_num [Native.step]) _)
  let sf (z : Fin 39→ℝ) (e : ℕ) := ∑ i : Fin 37,z i.castSucc.succ^e
  have list (L : List ℕ) : 0≤(L.map (sf v)).prod ∧ (L.map (sf v)).prod≤(L.map (sf w)).prod := by
    induction L with
    | nil => simp
    | cons e L ih =>
      simp only [List.map_cons,List.prod_cons]
      have low := Finset.sum_nonneg (s:=(Finset.univ:Finset (Fin 37))) (fun i _=>pow_nonneg (hv i.castSucc.succ) e)
      exact ⟨mul_nonneg low ih.1,mul_le_mul (Finset.sum_le_sum fun i _=>pow_le_pow_left₀ (hv _) (vw _) _) ih.2 ih.1
        (Finset.sum_nonneg fun i _=>pow_nonneg (hw _) _)⟩
  unfold bound
  apply Finset.sum_le_sum
  intro a _
  apply Finset.sum_le_sum
  intro b _
  apply Finset.sum_le_sum
  intro s _
  obtain ⟨c0,c1⟩:=list (signatures s)
  exact mul_le_mul (mul_le_mul (mul_le_mul_of_nonneg_left (en 0 a) (Nat.cast_nonneg _)) (en _ b)
    (end_nn (hv _) _) (mul_nonneg (Nat.cast_nonneg _) (end_nn (hw _) _))) c1 c0
    (mul_nonneg (mul_nonneg (Nat.cast_nonneg _) (end_nn (hw _) _)) (end_nn (hw _) _))

/-- Positive-coordinate polynomial used by the three angular books: midpoint powers are replaced
by radial plus half a physical cell width and each radial factor incurs exactly one bias. -/
theorem physical (v : Full) (lo : 102994≤Native.cellSum v) (nn : ∀ i,0≤NativeSiteLaw.radial (v i)) :
    |Restoration.original v| ≤
      LaterLowFactor.bias^39*(∏ i,LaterLowFactor.g (NativeSiteLaw.radial (v i)))*
      bound (fun i=>NativeSiteLaw.radial (v i)+Native.step/2) := by
  let c (i : Fin 39):=center (Native.cell (v i))
  let t (i : Fin 39):=NativeSiteLaw.radial (v i)
  have width : 0<Native.step := by norm_num [Native.step]
  have le (i : Fin 39) : c i≤t i+Native.step/2 := by
    have lower:=Nat.floor_le (div_nonneg (nn i) width.le)
    change (Native.cell (v i):ℝ) ≤ t i/Native.step at lower
    have m:=(le_div_iff₀ width).mp lower
    change ((Native.cell (v i):ℝ)+1/2)*Native.step ≤ t i+Native.step/2
    linarith only [m]
  have prod := Finset.prod_le_prod (s:=Finset.univ)
    (fun (i:Fin 39) _=>factor_nn (c i) (center_nn _)) (fun i _=>LaterLowFactor.midpoint (v i) (nn i))
  rw [Finset.prod_mul_distrib,Finset.prod_const,Finset.card_univ,Fintype.card_fin] at prod
  have pn : 0≤LaterLowFactor.bias^39*∏ i,LaterLowFactor.g (NativeSiteLaw.radial (v i)) :=
    (Finset.prod_nonneg (s:=Finset.univ) (fun (i : Fin 39) _=>factor_nn (c i) (center_nn _))).trans prod
  exact (native v lo).trans (mul_le_mul prod (monotone c _ (fun i=>center_nn _) le)
    (bound_nonneg _ fun i=>center_nn _) pn)

#print axioms physical

#print axioms native
end PrimeGap180.LowAngularPhysical
