import HarmanSharpOrdinary182
import TrialSharpSequence180
import TrialPrimeDistribution180

/-! Unrestricted distribution below one half for the actual shifted sharp
five-prime minorant, including both endpoints and the trial's coefficient 24. -/
noncomputable section
open scoped BigOperators Classical Topology
open Filter PrimeGap186 PrimeGap182Analytic PrimeGap180.Signed
namespace PrimeGap180.Distribution

def sharpChannel (x : ℝ) := Literal.Channel.sharp (x^((41361:ℝ)/100000))

theorem sharp_ordinary {θ : ℝ} (hθ0 : 0 < θ) (hθ : θ < 1/2) (h : ℕ) :
    RowBound sharpChannel (ordinary θ) h := by
  classical
  apply row_shift (θ := θ) _ h (by linarith)
    (Eventually.of_forall fun x I => Finset.filter_subset _ _)
  intro A hA
  obtain ⟨K,X,hK,_,src⟩ := Harman.sharpMinorant_ordinary_bv_log_saving θ hθ0 hθ A hA
  refine ⟨K,hK,?_⟩
  filter_upwards [eventually_ge_atTop X] with x hx
  intro I Q a hp ha sub
  let b := fun q => if q ∈ Q then a else 1
  have primitive (q : ℕ) : (b q).Coprime q := by
    by_cases hq : q ∈ Q
    · simpa [b,hq] using ha.of_dvd_right (Finset.mem_filter.mp (sub hq)).2
    · simp [b,hq]
  let f := sample (window x) 0 (Literal.value (sharpChannel x))
  have integral : f = ∑ n ∈ Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊,
      Finsupp.single n (sharpMinorant x (41361/100000) n : ℂ) := by
    simp only [f,sample,window,Nat.add_zero,Finset.image_id',sharpChannel,Literal.sharp_value_eq]
  have hb := src x hx b (fun q _ => primitive q)
  rw [← integral] at hb
  calc
    _ = ∑ q ∈ Q, ‖fullDiscrepancy f q (b q)‖ := by
      apply Finset.sum_congr rfl
      intro q hq
      simp only [b,hq,ite_true,f]
    _ ≤ _ := (Finset.sum_le_sum_of_subset_of_nonneg (sub.trans (Finset.filter_subset ..))
      (fun _ _ _ => norm_nonneg _)).trans hb

#print axioms sharp_ordinary
end PrimeGap180.Distribution
