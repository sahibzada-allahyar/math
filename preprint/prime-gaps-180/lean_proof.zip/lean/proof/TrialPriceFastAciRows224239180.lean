import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G224
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 224

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G224

namespace PrimeGap180.PriceIsolatedGroup.G229
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 229

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G229

namespace PrimeGap180.PriceIsolatedGroup.G234
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 234

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G234

namespace PrimeGap180.PriceIsolatedGroup.G239
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 239

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G239
