import TrialFirstEdgeClosedBound180

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace PrimeGap180.JointEdgeLayers
open FirstEdgeProduct FirstEdgeConvolution

def layer (n : Nat) (Q : Measure ℝ) (B m : ℝ) :=
  (Measure.pi (fun _ : Fin (n+1) => Q)).real
    (erased n B ∩ {x : Fin (n+1) → ℝ | ∀ i, x i ≤ m})

private theorem total {n : Nat} {x : Fin (n+1) → ℝ} {B m : ℝ} (hit : x ∈ erased n B)
    (hm : ∀ i, x i ≤ m) : ∑ i, x i ≤ B+m := by
  obtain ⟨i, hi⟩ := hit
  rw [Fin.sum_univ_succAbove _ i]
  linarith only [hi,hm i]

theorem base (n : Nat) (Q : Measure ℝ) [IsFiniteMeasure Q] (B m : ℝ) :
    layer n Q B m ≤ (restricted (n+1) Q m (B+m)).toReal := by
  rw [event]
  apply measureReal_mono _ (measure_ne_top _ _)
  rintro x ⟨hit,hm⟩
  exact ⟨total hit hm,hm⟩

/-- The extra cost of increasing the maximum cutoff is bounded by the
difference of two joint CDFs at the same total budget. -/
theorem next (n : Nat) (Q : Measure ℝ) [IsFiniteMeasure Q] (B l m : ℝ) (lm : l≤m) :
    layer n Q B m ≤ layer n Q B l + (restricted (n+1) Q m (B+m)).toReal
      - (restricted (n+1) Q l (B+m)).toReal := by
  let μ := Measure.pi (fun _ : Fin (n+1) => Q)
  let M := fun u : ℝ => {x : Fin (n+1) → ℝ | ∀ i, x i ≤ u}
  let A := {x : Fin (n+1) → ℝ | (∑ i,x i) ≤ B+m ∧ x∈M m}
  have ms : MeasurableSet (M l) := by
    change MeasurableSet {x : Fin (n+1)→ℝ | ∀ i,x i≤l}
    simp only [Set.ofPred_forall]
    exact MeasurableSet.iInter fun i => measurableSet_le (measurable_pi_apply _) measurable_const
  have eq : A∩M l={x : Fin (n+1)→ℝ | (∑ i,x i) ≤ B+m ∧ x∈M l} := by
    ext x
    exact ⟨fun p => ⟨p.1.1,p.2⟩,fun p => ⟨⟨p.1,fun i => (p.2 i).trans lm⟩,p.2⟩⟩
  have cover : erased n B ∩ M m ⊆ (erased n B ∩ M l) ∪ (A \ M l) := by
    rintro x ⟨hit,hm⟩
    by_cases low : x∈M l
    · exact Or.inl ⟨hit,low⟩
    · exact Or.inr ⟨⟨total hit hm,hm⟩,low⟩
  have bound := (measureReal_mono (μ:=μ) cover).trans (measureReal_union_le _ _)
  have sub := measureReal_sdiff_add_inter (μ:=μ) (s:=A) ms
  rw [eq] at sub
  rw [event,event]
  change μ.real (erased n B∩M m) ≤ μ.real (erased n B∩M l) + μ.real A -
    μ.real {x : Fin (n+1)→ℝ | (∑ i,x i) ≤ B+m ∧ x∈M l}
  linarith only [bound,sub]

#print axioms next
end PrimeGap180.JointEdgeLayers
