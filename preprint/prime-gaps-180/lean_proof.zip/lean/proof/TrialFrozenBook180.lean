import TrialMarkedBook180
import TrialFrozenData180

/-! The full physical price-book application for the named 217-band
splined profile. The profile, crop, label, radius and progression are fixed. -/
noncomputable section
open scoped BigOperators Classical Topology
open MeasureTheory Filter PrimeGap186 PrimeGap182Analytic PrimeGap180.Distribution
open PrimeGap180.Sector PrimeGap180.Price PrimeGap180.Detection
namespace PrimeGap180.Book

private theorem frozen_restriction (i : Fin 39) (s : Split) :
    Measurable (restricted FrozenData.trial i FrozenData.label s) ∧
    ∀ᵐ t ∂Measure.pi (fun _ => bandLaw FrozenData.mesh),
      ContinuousAt (restricted FrozenData.trial i FrozenData.label s) t := by
  have h := FrozenData.signed_regular i (fun _ => 1) (fun t => joinLabel.symm t = s)
  simpa only [restricted,splitFn,one_mul] using And.intro h.1 h.2.2

theorem frozen_marked_profile (i : Fin 39) : MarkedProfile FrozenData.mesh FrozenData.trial i FrozenData.label :=
  ⟨FrozenData.tables.ordered,FrozenData.tables.first,FrozenData.tables.last,FrozenData.trial_bounded,
   fun s => (frozen_restriction i (.inl s)).1,fun s => (frozen_restriction i (.inl s)).2,
   FrozenData.trial_support i⟩

/-- The 73 nonprime event/resource estimates have no arithmetic premise
beyond the separate finite kernel and cover comparisons. -/
theorem frozen_composite_marked (b : Ledger) (checks : KernelChecks b) (i : Fin 39) :
    (∀ u : Resource, u ≠ .prime → Marked FrozenData.mesh FrozenData.trial i FrozenData.label
      (fun x n => Resources.physical x (n+shifts i) u) (b.resourceKernel u)) ∧
    (∀ e : Event, e ≠ .prime → Marked FrozenData.mesh FrozenData.trial i FrozenData.label
      (fun x n => PriceEvents.mass x (n+shifts i) e) (b.eventKernel e)) :=
  composite_marked b checks _ _ i _ (frozen_marked_profile i)

/-- Applying the finite signed certificate to this named input leaves
only the supported affine modulus gates, the row densities and the
strict quadrature margin, alongside the finite data checks. -/
theorem gap_of_frozen_arithmetic (b : Ledger) (balance : FiniteChecks b) (checks : KernelChecks b)
    (number : Row → ℕ) (bands : ∀ k, Fin (number k+1) → ProvedBand (fun x => PhysicalPrices.channel x k))
    (d : Row → ℝ) (densityBounds : ∀ k, min (b.densityLo k) (b.densityHi k) ≤ d k ∧
       d k ≤ max (b.densityLo k) (b.densityHi k))
    (density : ∀ i k, Tendsto (fun x => Real.log x/x * ∑ n ∈ window x,
      Literal.value (PhysicalPrices.channel x k) (n+shifts i)) atTop (𝓝 (d k)))
    (gates : ∀ i k, PairGate FrozenData.mesh FrozenData.trial i FrozenData.label Sum.inl (lifted b k) k (bands k))
    (directGate : ∀ i, PairGate FrozenData.mesh FrozenData.trial i FrozenData.label id resolvedMask .prime
      (fun _ : Unit => PhysicalPrices.ordinary_row .prime))
    (margin : (∫ t, (FrozenData.trial t)^2 ∂Measure.pi (fun _ => bandLaw FrozenData.mesh)) +
      endpointCost FrozenData.mesh FrozenData.trial <
      rho * ∑ i : Fin 39, shiftIncome FrozenData.mesh FrozenData.trial i FrozenData.label) :
    primeGapLiminf ≤ (180 : EReal) :=
  gap_of_arithmetic b balance FrozenData.mesh FrozenData.tables.ordered FrozenData.tables.first FrozenData.tables.last
    FrozenData.trial FrozenData.trial_regular.1 FrozenData.trial_bounded FrozenData.trial_regular.2
    FrozenData.trial_room (fun _ => FrozenData.label) (fun i s => (frozen_restriction i s).1)
    (fun i s => (frozen_restriction i s).2) FrozenData.trial_support number bands d densityBounds density gates
    directGate (fun i => (frozen_composite_marked b checks i).1) (fun i => (frozen_composite_marked b checks i).2) margin

#print axioms frozen_composite_marked
#print axioms gap_of_frozen_arithmetic
end PrimeGap180.Book
