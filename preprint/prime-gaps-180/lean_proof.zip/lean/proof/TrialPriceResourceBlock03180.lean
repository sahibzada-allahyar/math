import TrialPriceResourceRows180
namespace PrimeGap180.PriceResourceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 100000000
private theorem p21 : checkResource 21 = true := by decide +kernel
private theorem p22 : checkResource 22 = true := by decide +kernel
private theorem p23 : checkResource 23 = true := by decide +kernel
private theorem p24 : checkResource 24 = true := by decide +kernel
private theorem p25 : checkResource 25 = true := by decide +kernel
private theorem p26 : checkResource 26 = true := by decide +kernel
private theorem p27 : checkResource 27 = true := by decide +kernel
theorem block3 : ∀ j : Fin 7, checkResource (21+j.val) = true :=
  Fin.cases p21 (Fin.cases p22 (Fin.cases p23 (Fin.cases p24 (Fin.cases p25 (Fin.cases p26 (Fin.cases p27 (fun i => Fin.elim0 i)))))))
#print axioms block3
end PrimeGap180.PriceResourceRows
