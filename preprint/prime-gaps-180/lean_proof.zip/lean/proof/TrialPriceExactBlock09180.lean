import TrialPriceScalar180
namespace PrimeGap180.PriceExactCensus
set_option maxHeartbeats 100000000
set_option maxRecDepth 65536
private theorem c288 : PriceScalar.checked (288 : Book.Label) = true := by decide +kernel
private theorem c289 : PriceScalar.checked (289 : Book.Label) = true := by decide +kernel
private theorem c290 : PriceScalar.checked (290 : Book.Label) = true := by decide +kernel
private theorem c291 : PriceScalar.checked (291 : Book.Label) = true := by decide +kernel
private theorem c292 : PriceScalar.checked (292 : Book.Label) = true := by decide +kernel
private theorem c293 : PriceScalar.checked (293 : Book.Label) = true := by decide +kernel
private theorem c294 : PriceScalar.checked (294 : Book.Label) = true := by decide +kernel
private theorem c295 : PriceScalar.checked (295 : Book.Label) = true := by decide +kernel
private theorem c296 : PriceScalar.checked (296 : Book.Label) = true := by decide +kernel
private theorem c297 : PriceScalar.checked (297 : Book.Label) = true := by decide +kernel
private theorem c298 : PriceScalar.checked (298 : Book.Label) = true := by decide +kernel
private theorem c299 : PriceScalar.checked (299 : Book.Label) = true := by decide +kernel
private theorem c300 : PriceScalar.checked (300 : Book.Label) = true := by decide +kernel
private theorem c301 : PriceScalar.checked (301 : Book.Label) = true := by decide +kernel
private theorem c302 : PriceScalar.checked (302 : Book.Label) = true := by decide +kernel
private theorem c303 : PriceScalar.checked (303 : Book.Label) = true := by decide +kernel
private theorem c304 : PriceScalar.checked (304 : Book.Label) = true := by decide +kernel
private theorem c305 : PriceScalar.checked (305 : Book.Label) = true := by decide +kernel
private theorem c306 : PriceScalar.checked (306 : Book.Label) = true := by decide +kernel
private theorem c307 : PriceScalar.checked (307 : Book.Label) = true := by decide +kernel
private theorem c308 : PriceScalar.checked (308 : Book.Label) = true := by decide +kernel
private theorem c309 : PriceScalar.checked (309 : Book.Label) = true := by decide +kernel
private theorem c310 : PriceScalar.checked (310 : Book.Label) = true := by decide +kernel
private theorem c311 : PriceScalar.checked (311 : Book.Label) = true := by decide +kernel
private theorem c312 : PriceScalar.checked (312 : Book.Label) = true := by decide +kernel
private theorem c313 : PriceScalar.checked (313 : Book.Label) = true := by decide +kernel
private theorem c314 : PriceScalar.checked (314 : Book.Label) = true := by decide +kernel
private theorem c315 : PriceScalar.checked (315 : Book.Label) = true := by decide +kernel
private theorem c316 : PriceScalar.checked (316 : Book.Label) = true := by decide +kernel
private theorem c317 : PriceScalar.checked (317 : Book.Label) = true := by decide +kernel
private theorem c318 : PriceScalar.checked (318 : Book.Label) = true := by decide +kernel
private theorem c319 : PriceScalar.checked (319 : Book.Label) = true := by decide +kernel
theorem block9 : ∀ i : Fin 32, PriceScalar.checked ⟨288+i.val,by omega⟩ = true :=
  Fin.cases c288 (Fin.cases c289 (Fin.cases c290 (Fin.cases c291 (Fin.cases c292 (Fin.cases c293 (Fin.cases c294 (Fin.cases c295 (Fin.cases c296 (Fin.cases c297 (Fin.cases c298 (Fin.cases c299 (Fin.cases c300 (Fin.cases c301 (Fin.cases c302 (Fin.cases c303 (Fin.cases c304 (Fin.cases c305 (Fin.cases c306 (Fin.cases c307 (Fin.cases c308 (Fin.cases c309 (Fin.cases c310 (Fin.cases c311 (Fin.cases c312 (Fin.cases c313 (Fin.cases c314 (Fin.cases c315 (Fin.cases c316 (Fin.cases c317 (Fin.cases c318 (Fin.cases c319 (fun i => Fin.elim0 i))))))))))))))))))))))))))))))))
#print axioms block9
end PrimeGap180.PriceExactCensus
