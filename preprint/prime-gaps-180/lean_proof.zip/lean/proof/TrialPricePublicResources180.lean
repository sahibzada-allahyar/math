import TrialPricePublicMatrix00180
import TrialPricePublicMatrix01180
import TrialPricePublicMatrix02180
import TrialPricePublicMatrix03180
import TrialPricePublicMatrix04180
import TrialPricePublicMatrix05180
import TrialPricePublicMatrix06180
import TrialPricePublicMatrix07180
import TrialPricePublicMatrix08180
import TrialPricePublicMatrix09180
import TrialPricePublicMatrix10180
import TrialPricePublicMatrix11180
import TrialPricePublicMatrix12180
import TrialPricePublicMatrix13180
import TrialPricePublicMatrix14180
import TrialPricePublicMatrix15180
import TrialPricePublicMatrix16180
import TrialPricePublicMatrix17180
import TrialPricePublicMatrix18180
import TrialPricePublicMatrix19180
import TrialPricePublicMatrix20180
import TrialPricePublicMatrix21180
import TrialPricePublicMatrix22180
import TrialPricePublicMatrix23180
import TrialPricePublicMatrix24180
import TrialPricePublicMatrix25180
import TrialPricePublicMatrix26180
import TrialPricePublicMatrix27180
import TrialPricePublicMatrix28180
import TrialPricePublicMatrix29180
import TrialPricePublicMatrix30180
import TrialPricePublicMatrix31180
import TrialPricePublicMatrix32180
import TrialPricePublicMatrix33180
import TrialPricePublicMatrix34180
import TrialPricePublicMatrix35180
import TrialPricePublicMatrix36180
import TrialPricePublicMatrix37180
import TrialPricePublicMatrix38180
import TrialPricePublicMatrix39180
import TrialPricePublicMatrix40180
import TrialPricePublicMatrix41180
import TrialPricePublicMatrix42180
import TrialPricePublicMatrix43180
import TrialPricePublicMatrix44180
import TrialPricePublicMatrix45180
import TrialPricePublicMatrix46180
import TrialPricePublicMatrix47180
import TrialPricePublicMatrix48180
import TrialPriceResourceSlots180
import Mathlib.Tactic.FinCases

noncomputable section
namespace PrimeGap180.PriceBindings
open Book Price

theorem matrices (m : Fin 49) :
    PackedLedger.raw.matrices[14+m.val]! = PriceFactorSource.physical (PriceFactorSource.factorShapes[m.val]!) := by
  fin_cases m
  · exact M00.bound
  · exact M01.bound
  · exact M02.bound
  · exact M03.bound
  · exact M04.bound
  · exact M05.bound
  · exact M06.bound
  · exact M07.bound
  · exact M08.bound
  · exact M09.bound
  · exact M10.bound
  · exact M11.bound
  · exact M12.bound
  · exact M13.bound
  · exact M14.bound
  · exact M15.bound
  · exact M16.bound
  · exact M17.bound
  · exact M18.bound
  · exact M19.bound
  · exact M20.bound
  · exact M21.bound
  · exact M22.bound
  · exact M23.bound
  · exact M24.bound
  · exact M25.bound
  · exact M26.bound
  · exact M27.bound
  · exact M28.bound
  · exact M29.bound
  · exact M30.bound
  · exact M31.bound
  · exact M32.bound
  · exact M33.bound
  · exact M34.bound
  · exact M35.bound
  · exact M36.bound
  · exact M37.bound
  · exact M38.bound
  · exact M39.bound
  · exact M40.bound
  · exact M41.bound
  · exact M42.bound
  · exact M43.bound
  · exact M44.bound
  · exact M45.bound
  · exact M46.bound
  · exact M47.bound
  · exact M48.bound

private theorem resource_index (u : Resource) : PriceScalar.resourceIndex u < 49 := by
  cases u <;> simp only [PriceScalar.resourceIndex] <;> omega

theorem resource_slots : PriceResourceSlots.Bound :=
  fun u => matrices ⟨_,resource_index u⟩

theorem resource (u : Resource) (g : Group) :
    (PriceValues.resource g.val (PriceScalar.resourceIndex u):Int) = intGram (FrozenLedger.ledger.factor u) g g :=
  PriceResourceSlots.resource resource_slots u g

theorem endpoints_of_events
    (event : ∀ (e : Book.Event) (g : Group), (PriceValues.event g.val (PriceScalar.eventIndex e):Int) =
      intGram (FrozenLedger.ledger.negative e) g g + intDeficit (intRemainder (FrozenLedger.ledger.remainder e)
        (FrozenLedger.ledger.positive e) (FrozenLedger.ledger.negative e)) g) : FrozenLedger.Endpoints :=
  PriceResourceSlots.endpoints resource_slots event

#print axioms resource_slots
#print axioms resource
#print axioms endpoints_of_events
end PrimeGap180.PriceBindings
