import TrialSignedGauge180
import TrialPrimeAmplitude180
import TrialResolvedPrime180

/-! Unfloor the 445 group amplitudes and restore the four excluded labels
on the original 521-sector expansion of the prime square. -/
noncomputable section
open scoped Classical BigOperators Topology
open Filter MeasureTheory PrimeGap186 PrimeGap182Analytic PrimeGap180.Distribution PrimeGap180.Price
namespace PrimeGap180.Sector

/-- The affine distribution and marked inequalities evaluate the same
erased divisor sum at a physical integer. -/
theorem affine_amplitude_eq_marked (z : SectorArray) (h : Fin 39 → ℕ) (k : Fin 39) (n : ℕ) :
    sectorAmplitude z h k n = sampledSelbergRoot z (fun j => n+h (k.succAbove j)) := by
  have branch (P : Prop) (d : Decidable P) (u v : ℝ) :
      @ite ℝ P d u v = @ite ℝ P (Classical.propDecidable P) u v := by
    rw [Subsingleton.elim d (Classical.propDecidable P)]
  simp only [sectorAmplitude,descendants,sampledSelbergRoot,finPiFinset_eq_classical,branch]

/-- Cropping an ambient extension at each erasure permits the unbounded
total label function and the uniformly radius-bounded sector predicates
to describe exactly the same full and sampled profiles. -/
theorem cropped_restriction {m : ℕ} {S : Type*} (label : (Fin 38 → Band m) → S)
    (r : S → ℝ) (k : Fin 39) (F : Profile 39 m)
    (supported : ∀ t, F t ≠ 0 → 0 ≤ retainedRadius (k.removeNth t) ∧ retainedRadius (k.removeNth t) ≤ r (label (k.removeNth t))) (s : S) :
    restrictFace k (fun y => label y = s ∧ 0 ≤ retainedRadius y ∧ retainedRadius y ≤ r s) F =
      restrictFace k (fun y => label y = s) F := by
  funext y
  by_cases nz : F y = 0
  · simp [restrictFace,nz]
  · by_cases hs : label (k.removeNth y) = s
    · have inside := supported y nz
      rw [hs] at inside
      simp [restrictFace,hs,inside]
    · simp [restrictFace,hs]

/-- Use the marked bounds on the left 517 sectors normalized in their
445 groups. The prime affine estimate for the four resolved sectors is
applied on the same *individual* sector amplitudes. -/
theorem single_shift_prime {m : ℕ} {S R G : Type*} [Fintype S] [Fintype R] [Fintype G]
    (H : Finset ℕ) (hH : H.card=39) (k : Fin 39) (a : Fin (m+2) → ℝ) (F : Profile 39 m)
    (label : (Fin 38 → Band m) → S ⊕ R) (owner : S → G)
    (ref w D : G → ℝ) (hr : ∀ g, 0 < ref g) (hn : ∀ g, 0 ≤ w g)
    (lo : ∀ g, w g ≤ priceUnit*Real.sqrt (ref g)) (hi : ∀ g, priceUnit*Real.sqrt (ref g) ≤ w g+1)
    (resolvedE : R → ℝ) (earned : ℝ) (b : ℝ → ℕ) (L : Filter ℝ) (cofinal : L ≤ atTop) :
    let h : Fin 39 → ℕ := H.orderEmbOfFin hH
    let U := fun s => restrictFace k (fun y => label y = s) F
    let V := fun x n s => sectorAmplitude (face H a k (U s) x) h k n
    let Z := fun x n => if Nat.ModEq (presievingModulus H x) n (b x) then (markedScale H x)⁻¹ else 0
    let μ := fun x n => (if (n+h k).Prime then (1:ℝ) else 0)*Z x n
    let v := fun x n => gaugeGroup owner ref (fun s => V x n (.inl s))
    (∀ g, Upper L (fun x => ∑ n ∈ window x, μ x n*(v x n g)^2) (D g)) →
    Lower (fun x => squareCount (window x) (μ x) (v x) (fun g => w g/priceUnit)) earned L →
    Lower (fun x => pair resolvedMask (moment (window x) (μ x) (V x))) (∑ t, resolvedE t) L →
    Lower (fun x => ∑ n ∈ window x, μ x n*(sampledSelbergRoot (sample H a F x) (fun j => n+h j))^2)
      (earned - ∑ g, roundingRow w g/priceUnit^2 *D g + ∑ t, resolvedE t) L := by
  intro h U V Z μ v diag grouped resolved
  have unit : 0 < priceUnit := by norm_num [priceUnit]
  have nn : ∀ᶠ x in L, ∀ n ∈ window x, 0 ≤ μ x n := by
    filter_upwards [cofinal (eventually_gt_atTop (1:ℝ))] with x hx
    intro n _
    dsimp only [μ,Z]
    split_ifs <;> positivity [markedScale_pos H hx]
  have undo := unfloor_prime window μ v nn (fun g => priceUnit*Real.sqrt (ref g)) w D unit hn lo hi diag grouped
  have sum (x : ℝ) (n : ℕ) : (∑ g, priceUnit*Real.sqrt (ref g)/priceUnit*v x n g) =
      ∑ s : S, V x n (.inl s) := by
    simp only [v,gauge_root_sum]
    apply Finset.sum_congr rfl
    intro s _
    field_simp [unit.ne',(Real.sqrt_pos.mpr (hr (owner s))).ne']
  intro ε he
  filter_upwards [undo (ε/2) (half_pos he),resolved (ε/2) (half_pos he),
    cofinal (full_prime_amplitude (J := S ⊕ R) H a F h)] with x grouped' resolved' roots
  simp only [squareCount,sum] at grouped'
  have identity := resolved_square (window x) (μ x) (V x)
  have all : (∑ n ∈ window x, μ x n*(∑ t, V x n t)^2) =
      ∑ n ∈ window x, μ x n*(sampledSelbergRoot (sample H a F x) (fun j => n+h j))^2 := by
    apply Finset.sum_congr rfl
    intro n mem
    by_cases pn : (n+h k).Prime
    · have ge : x ≤ (n:ℝ) := (Nat.le_ceil x).trans (Nat.cast_le.mpr (Finset.mem_Icc.mp mem).1)
      rw [show (∑ t, V x n t) = sampledSelbergRoot (sample H a F x) (fun j => n+h j) from roots n ge k pn label]
    · simp [μ,pn]
  rw [←all,←identity]
  linarith

#print axioms single_shift_prime
#print axioms cropped_restriction
end PrimeGap180.Sector
