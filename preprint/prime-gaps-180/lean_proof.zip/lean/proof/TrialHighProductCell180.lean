import TrialHighSiteCellMeasures180
import TrialHighMarkedNativePanel180

/-! Bind the product of harmonic one-site cell laws to the nonnegative
numeric weights used in the signed native Gram. -/
noncomputable section
open scoped Classical ENNReal BigOperators
open MeasureTheory PrimeGap186
namespace PrimeGap180.HighProductCell
open HighMixedCell HighSiteCellMeasures HighMomentReader HighMarkedNativePanel
open HighTailAddresses RemovedHighTags
open private phys_finite measurable_cell from TrialHighSiteCellMeasures180
open private edge_order rect from TrialHighPositiveMoments180
open private pos from TrialRemovedHighTags180

def law (m : Marks) : Measure (FiniteMeasure ℝ) :=
  match m with
  | .plain => PoissonSplit.phys cutoff
  | .single i => one cutoff (realValue (bandLo i)) (realValue (bandHi i))
  | .pair i j => two cutoff (realValue (bandLo i)) (realValue (bandHi i)) (realValue (bandLo j)) (realValue (bandHi j))

theorem finite (m : Marks) : IsFiniteMeasure (law m) := by
  let : IsFiniteMeasure (PoissonSplit.phys cutoff) := phys_finite cutoff
  cases m with
  | plain => exact phys_finite cutoff
  | single i =>
    let : IsFiniteMeasure (PoissonSplit.intensity (realValue (bandLo i)) (realValue (bandHi i))) :=
      (PoissonSplit.jumps (edge_order i).1 (edge_order i).2).property
    unfold law HighSiteCellMeasures.one HighMarkedMeasures.insert
    infer_instance
  | pair i j =>
    let : IsFiniteMeasure (PoissonSplit.intensity (realValue (bandLo i)) (realValue (bandHi i))) :=
      (PoissonSplit.jumps (edge_order i).1 (edge_order i).2).property
    let : IsFiniteMeasure (PoissonSplit.intensity (realValue (bandLo j)) (realValue (bandHi j))) :=
      (PoissonSplit.jumps (edge_order j).1 (edge_order j).2).property
    unfold law two HighMarkedMeasures.insert
    infer_instance

private theorem plain_bound (L H : ℝ) :
    PoissonSplit.phys cutoff (cellSet L H) ≤ ENNReal.ofReal (H-L) := by
  have h := HighMixedCell.residual pos L H 0
  simp only [add_zero] at h
  have eq : (∫⁻ Y, (Set.Ico L H).indicator (fun _ => (1:ℝ≥0∞)) (Y.mass:ℝ)
      ∂PoissonSplit.phys cutoff) = (PoissonSplit.phys cutoff) (cellSet L H) := by
    change (∫⁻ Y, test L H Y ∂PoissonSplit.phys cutoff) = _
    unfold test
    rw [lintegral_indicator (measurable_cell L H),lintegral_const,Measure.restrict_apply_univ,one_mul]
  rw [eq] at h
  apply h.trans
  by_cases hit : (0:ℝ) ∈ Set.Iic H <;> simp [Set.indicator_apply,hit]

theorem one_site (m : Marks) {L H : ℝ} (ordered : L ≤ H) :
    law m (cellSet L H) ≤ ENNReal.ofReal ((H-L)*markWeight m H) := by
  cases m with
  | plain => simpa only [law,markWeight,mul_one] using plain_bound L H
  | single i =>
    let a := realValue (bandLo i)
    let b := realValue (bandHi i)
    have edge := edge_order i
    have h := one_bound pos edge.1 edge.2 L H
    change HighSiteCellMeasures.one cutoff a b (cellSet L H) ≤ _
    apply h.trans_eq
    rw [markWeight,HighTailPhysical.one_weight edge.2,ENNReal.ofReal_mul (sub_nonneg.mpr ordered)]
    congr 1
    by_cases nn : 0 ≤ min b H-a
    · rw [max_eq_left nn,←ENNReal.ofReal_mul (one_div_nonneg.mpr edge.1.le),div_eq_mul_inv]
      dsimp only [a,b]
      ring
    · rw [max_eq_right (le_of_not_ge nn),ENNReal.ofReal_of_nonpos (le_of_not_ge nn),mul_zero,zero_div,ENNReal.ofReal_zero]
  | pair i j =>
    let a := realValue (bandLo i)
    let b := realValue (bandHi i)
    let c := realValue (bandLo j)
    let d := realValue (bandHi j)
    have u := edge_order i
    have v := edge_order j
    change two cutoff a b c d (cellSet L H) ≤ _
    apply (two_bound pos u.1 u.2 v.1 v.2 L H).trans_eq
    rw [markWeight,HighTailPhysical.two_weight,ENNReal.ofReal_mul (sub_nonneg.mpr ordered),
      ←ENNReal.ofReal_mul (one_div_nonneg.mpr u.1.le),
      ←ENNReal.ofReal_mul (one_div_nonneg.mpr v.1.le)]
    congr 2
    field_simp [u.1.ne',v.1.ne']
    <;> ring

theorem native (m : Marks) (j : Fin 131072) :
    law m (cellSet ((j.val:ℝ)*Native.step) (((j.val:ℝ)+1)*Native.step)) ≤
      ENNReal.ofReal (Native.step*markWeight m (mid j+Native.step/2)) := by
  have step : 0 < Native.step := by norm_num [Native.step]
  have h := one_site m (L:=(j.val:ℝ)*Native.step) (H:=((j.val:ℝ)+1)*Native.step)
    (by linarith only [step])
  rw [show ((j.val:ℝ)+1)*Native.step-(j.val:ℝ)*Native.step = Native.step by ring] at h
  have edge : mid j+Native.step/2 = ((j.val:ℝ)+1)*Native.step := by unfold mid FrozenChannels.center; ring
  rw [edge]
  exact h

def box (x : HighAngularProduct.Cube) :=
  Set.univ.pi fun i => cellSet (((x i).val:ℝ)*Native.step) ((((x i).val:ℝ)+1)*Native.step)

/-- A 39-site owner cell is dominated by the product of its actual marked
radial weights. The factorial for double occupancy is external to this cell. -/
theorem box_bound (a b : Fin 9) (q : HighOwnerRoles.Owners) (x : HighAngularProduct.Cube) :
    (Measure.pi (fun i : Fin 39 => law (HighIntegerGram.tags a b q i))) (box x) ≤
      ENNReal.ofReal (∏ i, cell a b q i (x i)) := by
  letI (i : Fin 39) : IsFiniteMeasure (law (HighIntegerGram.tags a b q i)) := finite _
  unfold box
  rw [Measure.pi_pi,ENNReal.ofReal_prod_of_nonneg]
  · exact Finset.prod_le_prod' (fun i _ => native (HighIntegerGram.tags a b q i) (x i))
  · intro i _
    exact mul_nonneg (by norm_num [Native.step]) (HighPositiveMoments.marks _ _)

#print axioms one_site
#print axioms native
#print axioms box_bound
end PrimeGap180.HighProductCell
