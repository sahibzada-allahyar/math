import TrialNoncentralClassification180
/-! Transfer the finite sign classification to the exact products in the
shifted-sieve central correction. -/
noncomputable section
open scoped BigOperators Classical Topology
open Filter PrimeGap186 PrimeGap182Audit PrimeGap180.Distribution
namespace PrimeGap180.Central

private theorem weights_good {n : ℕ} {v : Finset (Keys n)} (h : residualWeight v ≠ 0) :
    Sum.inl (0:Fin 2) ∈ v ∧ Sum.inl (1:Fin 2) ∈ v ∧
    (∀ i, Sum.inr (Sum.inl ((0:Fin 3),i)) ∈ v) ∧
    ∀ i j : Fin n, i < j → ∃ hij : i < j,
      Sum.inr (Sum.inr ((0:Fin 3),⟨(i,j),hij⟩)) ∈ v := by
  by_contra bad
  exact h (by simp only [residualWeight,ite_eq_right bad])

theorem closed_and_ordered {n : ℕ} {x a ζ : ℝ} {p : Fin n → ℕ} (hx : 1 < x)
    (pos : ∀ i, 0 < (p i:ℝ)) (h : residualWeight (trueKeys x a ζ p) ≠ 0) :
    (∏ i, p i) ∈ window x ∧ (∀ i, x^(1-2*a) ≤ (p i:ℝ)) ∧ StrictMono p := by
  obtain ⟨lo,hi,rough,order⟩ := weights_good h
  simp only [trueKeys,Finset.mem_filter,Finset.mem_univ,true_and] at lo hi rough order
  have x0 : 0 < x := by linarith
  simp [keyCut,cutTest,PrimeGap182Analytic.Harman.MinorantSmallMonomialCut.value] at lo hi rough
  refine ⟨Finset.mem_Icc.mpr ⟨Nat.ceil_le.mpr (by exact_mod_cast lo),
    Nat.le_floor (by exact_mod_cast hi)⟩,rough,?_⟩
  intro i j h
  obtain ⟨_,hj⟩ := order i j h
  simpa [keyCut,cutTest,PrimeGap182Analytic.Harman.MinorantSmallMonomialCut.value,
    div_lt_one (pos j)] using hj

def balanced {n : ℕ} (x edge : ℝ) (p : Fin n → ℕ) : Prop :=
  ∃ S : Finset (Fin n), S.Nonempty ∧ S ≠ Finset.univ ∧ x^edge ≤ ((∏ i ∈ S,p i:ℕ):ℝ) ∧
    ((∏ i ∈ S,p i:ℕ):ℝ) ≤ x^(1-edge)

theorem physical_signs {n : ℕ} {x a ζ : ℝ} (hx : 1 < x)
    (cuts : CutParameters a ζ) {p : Fin n → ℕ} (pos : ∀ i, 0 < (p i:ℝ))
    (h : residualWeight (trueKeys x a ζ p) ≠ 0) (no : ¬balanced x (a-collar) p) :
    let u := fun i => Real.logb x (p i:ℝ)
    StrictMono u ∧ (∀ i, 1-2*a ≤ u i) ∧ 1 ≤ ∑ i, u i ∧
      (∀ i, separated a (u i)) ∧ (∀ i j, i < j → separated a (u i+u j)) ∧
      trueKeys x a ζ p = signature (initialFlags u a) (initialFlags u ζ) (pairFlags u a) := by
  classical
  intro u
  obtain ⟨win,rough,order⟩ := closed_and_ordered hx pos h
  have x0 : 0 < x := by linarith
  have prodLog (S : Finset (Fin n)) : Real.logb x ((∏ i ∈ S, p i:ℕ):ℝ) = ∑ i ∈ S, u i := by
    simp only [Nat.cast_prod]
    exact Real.logb_prod S _ (fun i _ => (pos i).ne')
  have posProd (S : Finset (Fin n)) : 0 < ((∏ i ∈ S, p i:ℕ):ℝ) := by
    simp only [Nat.cast_prod]
    exact Finset.prod_pos fun i _ => pos i
  have total : 1 ≤ ∑ i, u i := by
    rw [← prodLog,Real.le_logb_iff_rpow_le hx (posProd _),Real.rpow_one]
    exact Nat.ceil_le.mp (Finset.mem_Icc.mp win).1
  have outside (S : Finset (Fin n)) (ne : S.Nonempty) : separated a (∑ i ∈ S, u i) := by
    by_cases whole : S = Finset.univ
    · rw [whole]
      right
      unfold collar
      linarith only [cuts.low,total]
    · by_contra! inside
      apply no
      refine ⟨S,ne,whole,?_,?_⟩
      · apply (Real.le_logb_iff_rpow_le hx (posProd S)).mp
        rw [prodLog]
        exact le_of_not_gt (fun h => inside (Or.inl h))
      · apply (Real.logb_le_iff_le_rpow hx (posProd S)).mp
        rw [prodLog]
        have hle := le_of_not_gt (fun h => inside (Or.inr h))
        linarith
  have pair (i j : Fin n) (hij : i < j) : separated a (u i+u j) := by
    simpa [hij.ne] using outside {i,j} (by simp)
  refine ⟨fun i j hij => (Real.logb_lt_logb_iff hx (pos i) (pos j)).mpr
    (by exact_mod_cast order hij),fun i => (Real.le_logb_iff_rpow_le hx (pos i)).mpr (rough i),
    total,fun i => (by simpa using outside {i} (by simp)),pair,?_⟩
  ext k
  simp only [trueKeys,Finset.mem_filter,Finset.mem_univ,true_and,mem_signature]
  rcases k with j | ⟨j,i⟩ | ⟨j,ij⟩
  · obtain ⟨low,high⟩ := Finset.mem_Icc.mp win
    fin_cases j
    · simpa [keyCut,cutTest,bitAt,PrimeGap182Analytic.Harman.MinorantSmallMonomialCut.value,
        ← Nat.cast_prod] using (Nat.ceil_le.mp low)
    · simpa [keyCut,cutTest,bitAt,PrimeGap182Analytic.Harman.MinorantSmallMonomialCut.value,
        ← Nat.cast_prod] using (Nat.le_floor_iff (show 0 ≤ 2*x by linarith)).mp high
  · fin_cases j
    · simpa [keyCut,cutTest,bitAt,PrimeGap182Analytic.Harman.MinorantSmallMonomialCut.value]
        using rough i
    all_goals simp [keyCut,cutTest,bitAt,initialFlags,
      PrimeGap182Analytic.Harman.MinorantSmallMonomialCut.value,u,Real.logb_lt_iff_lt_rpow hx (pos i)]
  · obtain ⟨⟨i,l⟩,hil⟩ := ij
    have sumlog : Real.logb x ((p i:ℝ)*p l) = u i+u l := Real.logb_mul (pos i).ne' (pos l).ne'
    have pl := mul_pos (pos i) (pos l)
    have lo := (Real.logb_lt_iff_lt_rpow (y := a) hx pl)
    have hi := (Real.lt_logb_iff_rpow_lt (x := 1-a) hx pl)
    rw [sumlog] at lo hi
    have flip : 1-a < u i+u l ↔ ¬u i+u l<a := by
      have gap : a < 1-a := by linarith only [cuts.high]
      have epos : 0 < collar := by norm_num [collar]
      rcases pair i l hil with sm | lg
      · have small : u i+u l < a := by linarith
        constructor
        · intro big
          exact fun _ => (not_lt_of_ge (small.trans gap).le) big
        · intro noSmall
          exact (noSmall small).elim
      · have big : 1-a < u i+u l := by linarith
        exact ⟨fun _ => not_lt_of_ge (gap.trans big).le,fun _ => big⟩
    fin_cases j
    · simpa [keyCut,cutTest,bitAt,PrimeGap182Analytic.Harman.MinorantSmallMonomialCut.value,
        div_lt_one (pos l)] using order hil
    · simpa [keyCut,cutTest,bitAt,pairFlags,hil,hil.ne,
        PrimeGap182Analytic.Harman.MinorantSmallMonomialCut.value] using lo.symm
    · simpa [keyCut,cutTest,bitAt,pairFlags,hil,hil.ne,
        PrimeGap182Analytic.Harman.MinorantSmallMonomialCut.value] using hi.symm.trans flip


theorem literal_central_support {n : ℕ} (hn : 2 ≤ n) (hn' : n ≤ 5) :
    ∀ᶠ x : ℝ in atTop, ∀ a ζ : ℝ, CutParameters a ζ → ∀ p : Fin n → ℕ,
      (∀ i, 0 < (p i:ℝ)) → residualWeight (trueKeys x a ζ p) ≠ 0 →
      (∏ i, p i) ∈ window x ∧ balanced x (a-collar) p := by
  have δ : (0:ℝ) < collar/4 := by norm_num [collar]
  filter_upwards [eventually_gt_atTop (1:ℝ),
    (tendsto_rpow_atTop δ).eventually (eventually_ge_atTop (2:ℝ))] with x hx hδ
  intro a ζ cuts p pos nonzero
  have win := (closed_and_ordered hx pos nonzero).1
  refine ⟨win,?_⟩
  by_contra no
  let u := fun i => Real.logb x (p i:ℝ)
  obtain ⟨inc,rough,low,single,pair,mask⟩ := physical_signs hx cuts pos nonzero no
  have x0 : 0 < x := by linarith
  have high : ∑ i, u i ≤ 1+collar/4 := by
    rw [← Real.logb_prod Finset.univ (fun i => (p i:ℝ)) (fun i _ => (pos i).ne')]
    apply (Real.logb_le_iff_le_rpow hx (Finset.prod_pos fun i _ => pos i)).mpr
    rw [Real.rpow_add x0, Real.rpow_one]
    have dy := (Nat.cast_le.mpr (Finset.mem_Icc.mp win).2).trans
      (Nat.floor_le (by linarith : 0 ≤ 2*x))
    exact (by exact_mod_cast dy : (∏ i, (p i:ℝ)) ≤ 2*x).trans
      ((mul_comm (2:ℝ) x).le.trans (mul_le_mul_of_nonneg_left hδ x0.le))
  exact nonzero (mask ▸ (residual_signature _ _ _).trans
    (noncentral_weight_zero hn hn' u cuts inc rough low high single pair))

theorem trial_central_distribution {k j : ℕ} (hk : k ≤ 4) (hn : 2 ≤ k+1)
    {w d σ a ζ : ℝ} (cuts : CutParameters a ζ) (gap : 1/2-(a-collar) < σ) (level : w < 1/4)
    (route : BilinearRoute j w d σ) (rank4 : AllIncidenceRankFourBounds)
    (A : ℝ) (hA : 0 < A) :
    ∃ K : ℝ, 0 < K ∧ ∀ᶠ x : ℝ in atTop,
      let P := (Finset.Icc ⌈x^((4:ℝ)/25)⌉₊ ⌊x^((9:ℝ)/10)⌋₊).filter Nat.Prime
      let T := Fintype.piFinset (fun _ : Fin (k+1) => P)
      let g := fun p : Fin (k+1) → ℕ => residualWeight (trueKeys x a ζ p)
      ∀ (I Q : Finset ℕ) (b : ℕ), (∀ p ∈ I, p.Prime) → b.Coprime (∏ p ∈ I, p) →
        Q ⊆ dense j (1/2+2*w) d x I →
        (∑ q ∈ Q, ‖fullDiscrepancy (∑ p ∈ T, Finsupp.single (∏ i, p i) (g p:ℂ)) q b‖)
          ≤ K*x/(Real.log x)^A := by
  classical
  have half : a-collar ≤ 1/2 := by unfold collar; linarith only [cuts.high]
  obtain ⟨K,hK,dist⟩ := central_residual_distribution hk hn half gap level route rank4 A hA
  refine ⟨K,hK,?_⟩
  filter_upwards [dist,literal_central_support hn (by omega : k+1 ≤ 5)] with x dist support
  intro P T g
  apply dist a ζ
  intro p hp nonzero
  have positive (i : Fin (k+1)) : 0 < (p i : ℝ) :=
    Nat.cast_pos.mpr (Finset.mem_filter.mp (Fintype.mem_piFinset.mp hp i)).2.pos
  exact support a ζ cuts p positive nonzero

#print axioms trial_central_distribution
end PrimeGap180.Central
