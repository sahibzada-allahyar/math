import TrialFrozenPairGate180
import TrialMeshKeySemantics180

/-! Recover the actual group and native bucket from a used lookup, including
the offset inside its archived run. These coordinates enter the refined
above-half test. -/
noncomputable section
open PrimeGap180.FrozenProfile PrimeGap180.Sector PrimeGap180.FrozenData.FiniteInput
namespace PrimeGap180.SourceOwners

private def rowFor (c : Fine) (g : Group) : Array ℕ :=
  ((owners c).find? (fun r => field r 0 == g.val)).getD #[]

private def keyFor (r : Array ℕ) (b : Bucket) : Option Key :=
  let u := field r 4+b.val-field r 2
  if h : field r 2 ≤ b.val ∧ b.val < field r 3 ∧ u < 25600 then some ⟨u,h.2.2⟩ else none

theorem fields {c : Fine} {g : Group} {b : Bucket} {k : Key}
    (h : FrozenData.tables.key c g b = some k) :
    ∃ r ∈ (owners c).toList, field r 0 = g.val ∧ field r 2 ≤ b.val ∧ b.val < field r 3 ∧
      field r 4+b.val-field r 2 = k.val ∧ FrozenData.tables.upper c g = min 2798706 (field r 1) := by
  change keyFor (rowFor c g) b = some k at h
  change ∃ r ∈ (owners c).toList, field r 0 = g.val ∧ field r 2 ≤ b.val ∧ b.val < field r 3 ∧
    field r 4+b.val-field r 2 = k.val ∧ min 2798706 (field (rowFor c g) 1) = min 2798706 (field r 1)
  cases f : (owners c).find? (fun r => field r 0 == g.val) with
  | none =>
    have eq : rowFor c g = #[] := by simp [rowFor,f]
    rw [eq] at h
    unfold keyFor at h
    dsimp only at h
    split at h
    next cond => exact (Nat.not_lt_zero _ cond.2.1).elim
    next => exact nomatch h
  | some r =>
    have eq : rowFor c g = r := by simp [rowFor,f]
    have list : (owners c).toList.find? (fun r => field r 0 == g.val) = some r :=
      by simpa only [Array.find?_toList] using f
    have chosen : field r 0 = g.val := by simpa using List.find?_some list
    rw [eq] at h ⊢
    unfold keyFor at h
    dsimp only at h
    split at h
    next cond =>
      exact ⟨r,List.mem_of_find?_eq_some list,chosen,cond.1,cond.2.1,congrArg Fin.val (Option.some.inj h),rfl⟩
    next => exact nomatch h

def capTicks (c : Fine) : ℕ := ⌈(2624990:ℚ)*FrozenData.meshQ (FrozenData.tables.capEdge c).castSucc⌉₊

theorem cap_ticks (r : Receipt) : (FrozenPairGate.k r).capTicks = (capTicks r.fine : ℝ) := by
  change ((⌈Lookup.ticks*FrozenData.mesh (FrozenData.tables.capEdge r.fine).castSucc⌉₊ : ℕ) : ℝ) = (capTicks r.fine : ℝ)
  apply Nat.cast_inj.mpr
  rw [FrozenData.mesh_eq_rat]
  unfold capTicks
  apply eq_of_forall_ge_iff
  intro n
  rw [Nat.ceil_le,Nat.ceil_le]
  change (2624990:ℝ)*_ ≤ (n:ℝ) ↔ _
  norm_cast

#print axioms fields
#print axioms cap_ticks
end PrimeGap180.SourceOwners
