import TrialPriceGainRows180
open scoped BigOperators
namespace PrimeGap180.PriceGainRows
open Book
set_option maxRecDepth 131072
set_option maxHeartbeats 100000000
private theorem g384 : (PriceValues.group 384).gain = ∑ k : Book.Row, row k (384:Group) := by decide +kernel
private theorem g385 : (PriceValues.group 385).gain = ∑ k : Book.Row, row k (385:Group) := by decide +kernel
private theorem g386 : (PriceValues.group 386).gain = ∑ k : Book.Row, row k (386:Group) := by decide +kernel
private theorem g387 : (PriceValues.group 387).gain = ∑ k : Book.Row, row k (387:Group) := by decide +kernel
private theorem g388 : (PriceValues.group 388).gain = ∑ k : Book.Row, row k (388:Group) := by decide +kernel
private theorem g389 : (PriceValues.group 389).gain = ∑ k : Book.Row, row k (389:Group) := by decide +kernel
private theorem g390 : (PriceValues.group 390).gain = ∑ k : Book.Row, row k (390:Group) := by decide +kernel
private theorem g391 : (PriceValues.group 391).gain = ∑ k : Book.Row, row k (391:Group) := by decide +kernel
private theorem g392 : (PriceValues.group 392).gain = ∑ k : Book.Row, row k (392:Group) := by decide +kernel
private theorem g393 : (PriceValues.group 393).gain = ∑ k : Book.Row, row k (393:Group) := by decide +kernel
private theorem g394 : (PriceValues.group 394).gain = ∑ k : Book.Row, row k (394:Group) := by decide +kernel
private theorem g395 : (PriceValues.group 395).gain = ∑ k : Book.Row, row k (395:Group) := by decide +kernel
private theorem g396 : (PriceValues.group 396).gain = ∑ k : Book.Row, row k (396:Group) := by decide +kernel
private theorem g397 : (PriceValues.group 397).gain = ∑ k : Book.Row, row k (397:Group) := by decide +kernel
private theorem g398 : (PriceValues.group 398).gain = ∑ k : Book.Row, row k (398:Group) := by decide +kernel
private theorem g399 : (PriceValues.group 399).gain = ∑ k : Book.Row, row k (399:Group) := by decide +kernel
private theorem g400 : (PriceValues.group 400).gain = ∑ k : Book.Row, row k (400:Group) := by decide +kernel
private theorem g401 : (PriceValues.group 401).gain = ∑ k : Book.Row, row k (401:Group) := by decide +kernel
private theorem g402 : (PriceValues.group 402).gain = ∑ k : Book.Row, row k (402:Group) := by decide +kernel
private theorem g403 : (PriceValues.group 403).gain = ∑ k : Book.Row, row k (403:Group) := by decide +kernel
private theorem g404 : (PriceValues.group 404).gain = ∑ k : Book.Row, row k (404:Group) := by decide +kernel
private theorem g405 : (PriceValues.group 405).gain = ∑ k : Book.Row, row k (405:Group) := by decide +kernel
private theorem g406 : (PriceValues.group 406).gain = ∑ k : Book.Row, row k (406:Group) := by decide +kernel
private theorem g407 : (PriceValues.group 407).gain = ∑ k : Book.Row, row k (407:Group) := by decide +kernel
private theorem g408 : (PriceValues.group 408).gain = ∑ k : Book.Row, row k (408:Group) := by decide +kernel
private theorem g409 : (PriceValues.group 409).gain = ∑ k : Book.Row, row k (409:Group) := by decide +kernel
private theorem g410 : (PriceValues.group 410).gain = ∑ k : Book.Row, row k (410:Group) := by decide +kernel
private theorem g411 : (PriceValues.group 411).gain = ∑ k : Book.Row, row k (411:Group) := by decide +kernel
private theorem g412 : (PriceValues.group 412).gain = ∑ k : Book.Row, row k (412:Group) := by decide +kernel
private theorem g413 : (PriceValues.group 413).gain = ∑ k : Book.Row, row k (413:Group) := by decide +kernel
private theorem g414 : (PriceValues.group 414).gain = ∑ k : Book.Row, row k (414:Group) := by decide +kernel
private theorem g415 : (PriceValues.group 415).gain = ∑ k : Book.Row, row k (415:Group) := by decide +kernel
private theorem g416 : (PriceValues.group 416).gain = ∑ k : Book.Row, row k (416:Group) := by decide +kernel
private theorem g417 : (PriceValues.group 417).gain = ∑ k : Book.Row, row k (417:Group) := by decide +kernel
private theorem g418 : (PriceValues.group 418).gain = ∑ k : Book.Row, row k (418:Group) := by decide +kernel
private theorem g419 : (PriceValues.group 419).gain = ∑ k : Book.Row, row k (419:Group) := by decide +kernel
private theorem g420 : (PriceValues.group 420).gain = ∑ k : Book.Row, row k (420:Group) := by decide +kernel
private theorem g421 : (PriceValues.group 421).gain = ∑ k : Book.Row, row k (421:Group) := by decide +kernel
private theorem g422 : (PriceValues.group 422).gain = ∑ k : Book.Row, row k (422:Group) := by decide +kernel
private theorem g423 : (PriceValues.group 423).gain = ∑ k : Book.Row, row k (423:Group) := by decide +kernel
private theorem g424 : (PriceValues.group 424).gain = ∑ k : Book.Row, row k (424:Group) := by decide +kernel
private theorem g425 : (PriceValues.group 425).gain = ∑ k : Book.Row, row k (425:Group) := by decide +kernel
private theorem g426 : (PriceValues.group 426).gain = ∑ k : Book.Row, row k (426:Group) := by decide +kernel
private theorem g427 : (PriceValues.group 427).gain = ∑ k : Book.Row, row k (427:Group) := by decide +kernel
private theorem g428 : (PriceValues.group 428).gain = ∑ k : Book.Row, row k (428:Group) := by decide +kernel
private theorem g429 : (PriceValues.group 429).gain = ∑ k : Book.Row, row k (429:Group) := by decide +kernel
private theorem g430 : (PriceValues.group 430).gain = ∑ k : Book.Row, row k (430:Group) := by decide +kernel
private theorem g431 : (PriceValues.group 431).gain = ∑ k : Book.Row, row k (431:Group) := by decide +kernel
private theorem g432 : (PriceValues.group 432).gain = ∑ k : Book.Row, row k (432:Group) := by decide +kernel
private theorem g433 : (PriceValues.group 433).gain = ∑ k : Book.Row, row k (433:Group) := by decide +kernel
private theorem g434 : (PriceValues.group 434).gain = ∑ k : Book.Row, row k (434:Group) := by decide +kernel
private theorem g435 : (PriceValues.group 435).gain = ∑ k : Book.Row, row k (435:Group) := by decide +kernel
private theorem g436 : (PriceValues.group 436).gain = ∑ k : Book.Row, row k (436:Group) := by decide +kernel
private theorem g437 : (PriceValues.group 437).gain = ∑ k : Book.Row, row k (437:Group) := by decide +kernel
private theorem g438 : (PriceValues.group 438).gain = ∑ k : Book.Row, row k (438:Group) := by decide +kernel
private theorem g439 : (PriceValues.group 439).gain = ∑ k : Book.Row, row k (439:Group) := by decide +kernel
private theorem g440 : (PriceValues.group 440).gain = ∑ k : Book.Row, row k (440:Group) := by decide +kernel
private theorem g441 : (PriceValues.group 441).gain = ∑ k : Book.Row, row k (441:Group) := by decide +kernel
private theorem g442 : (PriceValues.group 442).gain = ∑ k : Book.Row, row k (442:Group) := by decide +kernel
private theorem g443 : (PriceValues.group 443).gain = ∑ k : Book.Row, row k (443:Group) := by decide +kernel
private theorem g444 : (PriceValues.group 444).gain = ∑ k : Book.Row, row k (444:Group) := by decide +kernel
theorem batch6 : ∀ i : Fin 61, (PriceValues.group (384+i.val)).gain = ∑ k : Book.Row, row k ⟨384+i.val,by omega⟩ :=
  Fin.cases g384 (Fin.cases g385 (Fin.cases g386 (Fin.cases g387 (Fin.cases g388 (Fin.cases g389 (Fin.cases g390 (Fin.cases g391 (Fin.cases g392 (Fin.cases g393 (Fin.cases g394 (Fin.cases g395 (Fin.cases g396 (Fin.cases g397 (Fin.cases g398 (Fin.cases g399 (Fin.cases g400 (Fin.cases g401 (Fin.cases g402 (Fin.cases g403 (Fin.cases g404 (Fin.cases g405 (Fin.cases g406 (Fin.cases g407 (Fin.cases g408 (Fin.cases g409 (Fin.cases g410 (Fin.cases g411 (Fin.cases g412 (Fin.cases g413 (Fin.cases g414 (Fin.cases g415 (Fin.cases g416 (Fin.cases g417 (Fin.cases g418 (Fin.cases g419 (Fin.cases g420 (Fin.cases g421 (Fin.cases g422 (Fin.cases g423 (Fin.cases g424 (Fin.cases g425 (Fin.cases g426 (Fin.cases g427 (Fin.cases g428 (Fin.cases g429 (Fin.cases g430 (Fin.cases g431 (Fin.cases g432 (Fin.cases g433 (Fin.cases g434 (Fin.cases g435 (Fin.cases g436 (Fin.cases g437 (Fin.cases g438 (Fin.cases g439 (Fin.cases g440 (Fin.cases g441 (Fin.cases g442 (Fin.cases g443 (Fin.cases g444 (fun i => Fin.elim0 i)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
#print axioms batch6
end PrimeGap180.PriceGainRows
