import TrialLaterLowProduct180
import TrialLaterLowFactor180

/-! The scalar 39-site theorem with the actual archived root factors. The
remaining spline envelope applies only on the chosen physical event. -/
noncomputable section
open MeasureTheory Set Filter PrimeGap180.Sector PrimeGap180.FrozenProfile
open scoped NNReal BigOperators
namespace PrimeGap180.LaterLowScalar
open LaterLowFactor (a c w g bias)
open LaterLowProduct (weight μ ν totalCap)
open NativeSiteLaw (radial tail)
open private one_nonneg bands_nonneg from TrialFrozenData180
open private radial_meas tail_meas from TrialNativeSiteLaw180
local instance : IsFiniteMeasure ν := bandLaw_finite _

private theorem integrable (edge : Fin 217) (b r : ℝ) (hb : 0≤b) (hr : 0≤r) :
    Integrable (weight (fun t=>g t^2) edge b r) ν := by
  have m : Measurable (weight (fun t=>g t^2) edge b r) := by
    unfold weight g NativeSiteLaw.radial NativeSiteLaw.tail
    fun_prop
  apply (integrable_const (μ:=ν) (1:ℝ)).mono' m.aestronglyMeasurable
  filter_upwards [one_nonneg] with z zn
  have rn : 0≤radial z := Finset.sum_nonneg fun k _=>zn k
  have dn : 0≤radial z-tail edge z := sub_nonneg.mpr (Finset.sum_le_sum_of_subset_of_nonneg
    (Finset.filter_subset _ _) (fun k _ _=>zn k))
  have gn : 0≤g (radial z) := by unfold g a c w; positivity
  have gu : g (radial z) ≤ 1 := by
    have hh : 1≤1+w*radial z := by unfold w; linarith only [rn]
    have h := div_le_self (by norm_num [c] : 0≤c) hh
    unfold g
    linarith only [h,show a+c=1 from by norm_num [a,c]]
  have expu : Real.exp (-(b*radial z+r*(radial z-tail edge z)))≤1 := Real.exp_le_one_iff.mpr
    (neg_nonpos.mpr (add_nonneg (mul_nonneg hb rn) (mul_nonneg hr dn)))
  unfold weight
  rw [Real.norm_eq_abs,abs_of_nonneg (mul_nonneg (sq_nonneg _) (Real.exp_pos _).le)]
  exact (mul_le_mul_of_nonneg_left expu (sq_nonneg _)).trans (by simpa using pow_le_one₀ gn gu (n:=2))

def mid (z : Band 216) := ((Native.cell z:ℝ)+1/2)*Native.step

/-- Uses the genuine original square, every allowed omitted coordinate and
the squared midpoint bias with exponent 78. Only the signed spline envelope
is an input to this reduction. -/
theorem bound (E : Set (Fin 39→Band 216)) (mE : MeasurableSet E)
    (edge : Fin 217) (b r : ℝ≥0) (cut amp : ℝ) (ha : 0≤amp)
    (cover : E ⊆ JointEdgeConditional.erasedSet edge 1 cut)
    (envelope : ∀ᵐ v ∂μ, v∈E → |Restoration.original v| ≤ amp*∏ k,siteFactor (mid (v k))) :
    (∫ v in E,(Restoration.original v)^2 ∂μ) ≤
    39*(amp^2*bias^78)*Real.exp ((b:ℝ)*totalCap+(r:ℝ)*cut) *
      (∫ z,weight (fun t=>g t^2) edge b 0 z ∂ν) * (∫ z,weight (fun t=>g t^2) edge b r z ∂ν)^38 := by
  have hB : 0≤bias := by norm_num [bias,w,Native.step]
  apply LaterLowProduct.bound _ (fun t=>sq_nonneg _) edge b r cut _ (mul_nonneg (sq_nonneg _) (pow_nonneg hB _)) E mE cover
  · filter_upwards [envelope,bands_nonneg 39] with v env nn
    intro hv
    have root (k : Fin 39) : 0 ≤ siteFactor (mid (v k)) := by
      have nonneg : 0 ≤ mid (v k) := by dsimp [mid,Native.step]; positivity
      unfold siteFactor
      positivity
    have p := Finset.prod_le_prod (s:=Finset.univ) (fun k _=>root k)
      (fun k _=>LaterLowFactor.midpoint (v k) (Finset.sum_nonneg fun j _=>nn k j))
    have upper := (env hv).trans (mul_le_mul_of_nonneg_left p ha)
    have h:=pow_le_pow_left₀ (abs_nonneg _) upper 2
    rw [sq_abs,Finset.prod_mul_distrib] at h
    simpa only [Finset.prod_const,Finset.card_univ,Fintype.card_fin,mul_pow,←Finset.prod_pow,
      ←pow_mul,mul_assoc] using h
  · intro s hs
    rcases Finset.mem_insert.mp hs with hz|hr
    · exact integrable edge b s b.2 (by rw [hz])
    · exact integrable edge b s b.2 (by rw [Finset.mem_singleton.mp hr]; exact r.2)

#print axioms bound
end PrimeGap180.LaterLowScalar
