import TrialRemovedLowProjection180
import TrialFirstEdgeRegular180

/-! The one-split first-edge event follows from an actual failed erasure
for any coupled regular-site lower variables, including endpoint erasures. -/
noncomputable section
open scoped Classical BigOperators
open PrimeGap180.FrozenProfile PrimeGap180.Sector PrimeGap180.GateDeletion
namespace PrimeGap180.FirstEdgeSplit

def site (z : Band 216) : ℝ :=
  Lookup.ticks*((((Native.cell z:ℝ)+1)*Native.step - ∑ k,z k) +
    ((∑ k,z k)-∑ k ∈ Finset.univ.filter (fun k=>T.tailEdge 0≤k),z k))

private theorem nonneg (z : Band 216) (nn : ∀ k,0≤z k) : 0≤ site z := by
  have step : 0<Native.step:=by norm_num [Native.step]
  have slack : (∑ k,z k) ≤ ((Native.cell z:ℝ)+1)*Native.step :=
    ((div_lt_iff₀ step).mp (Nat.lt_floor_add_one _)).le
  have dust : ∑ k ∈ Finset.univ.filter (fun k=>T.tailEdge 0≤k),z k ≤ ∑ k,z k :=
    Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _) (fun k _ _=>nn k)
  exact mul_nonneg (by norm_num [Lookup.ticks]) (add_nonneg (sub_nonneg.mpr slack) (sub_nonneg.mpr dust))

set_option maxRecDepth 65536 in
private theorem upper : FrozenData.parentUpperNat 0=100 := by decide +kernel

theorem regular_indices (j : Fin 39→ℕ) (room : (∑ i,j i)≤130964) : ∃ R : Finset (Fin 39), R.card=37 ∧
    ∀ i∈R, j i<45067 := by
  let hi:=Finset.univ.filter (fun i=>45067≤j i)
  have h : hi.card≤2:=SiteLawComparison.at_most_two j room
  have c : 37≤hiᶜ.card := by
    rw [Finset.card_compl]
    simp only [Fintype.card_fin]
    omega
  obtain ⟨r,sub,card⟩:=Finset.exists_subset_card_eq c
  refine ⟨r,card,?_⟩
  intro i ir
  have ih:=sub ir
  simpa [hi] using ih

theorem regular_sites (v : Full) (nz : original v≠0) : ∃ R : Finset (Fin 39), R.card=37 ∧
    ∀ i∈R, Native.cell (v i)<45067 :=
  regular_indices (fun i=>Native.cell (v i)) (Restoration.original_index v nz)

/-- The set R can be fixed from the observed native indices before
sampling any of the residual fragments or choosing the failing site. -/
theorem event_for (v : Full) (nn : ∀ i k,0≤v i k) (i : Fin 39) (r : Receipt)
    (sel : select T (bits T (i.removeNth v))=some r)
    (bad : bits T (i.removeNth v) (.high r.key 0)=true) (R : Finset (Fin 39)) :
    ∀ w : Fin 39→ℝ, (∀ j∈R, w j≤ site (v j)) →
      (∀ j∈R,w j≤Lookup.ticks*Native.step) →
      (∑ j∈R,w j)<200+Lookup.ticks*Native.step ∧
      ((∀ j∈R,w j≤19) → (∑ j∈R,w j)<219) := by
  intro w lower clipped
  have small := RemovedLowProjection.failed_slack (i.removeNth v) r 0 sel bad
  rw [FrozenData.parentUpper_nat,upper] at small
  have room : ∑ j,site (v (i.succAbove j))<200 := by
    change (∑ j,site (v (i.succAbove j))) < 2* (↑(100:ℕ):ℝ) at small
    norm_num at small
    exact small
  let z := fun j=>if j∈R then w j else 0
  have dom (j) : z j≤ site (v j) := by
    by_cases h : j∈R
    · exact (ite_eq_left h).le.trans (lower j h)
    · simpa [z,h] using nonneg _ (nn j)
  have eq : (∑ j∈R,w j) = ∑ j,z j := by classical simp [z]
  have left := Finset.sum_le_sum (s:=Finset.univ) (fun j _=>dom (i.succAbove j))
  have general (t : ℝ) (ht : 0≤t) (bounded : ∀ j∈R,w j≤t) : (∑ j∈R,w j)<200+t := by
    rw [eq,Fin.sum_univ_succAbove z i]
    have zi : z i≤t := by
      by_cases here : i∈R
      · simpa only [z,here,ite_true] using bounded i here
      · simpa only [z,here,ite_false] using ht
    linarith only [left,room,zi]
  refine ⟨general _ (by norm_num [Lookup.ticks,Native.step]) clipped,?_⟩
  intro below
  have claim := general 19 (by norm_num) below
  norm_num at claim
  exact claim

theorem event (v : Full) (nn : ∀ i k,0≤v i k) (nz : original v≠0) (i : Fin 39) (r : Receipt)
    (sel : select T (bits T (i.removeNth v))=some r)
    (bad : bits T (i.removeNth v) (.high r.key 0)=true) :
    ∃ R : Finset (Fin 39), R.card=37 ∧ (∀ j∈R,Native.cell (v j)<45067) ∧
    ∀ w : Fin 39→ℝ, (∀ j∈R, w j≤ site (v j)) →
      (∀ j∈R,w j≤Lookup.ticks*Native.step) →
      (∑ j∈R,w j)<200+Lookup.ticks*Native.step ∧
      ((∀ j∈R,w j≤19) → (∑ j∈R,w j)<219) := by
  obtain ⟨R,card,sm⟩:=regular_sites v nz
  exact ⟨R,card,sm,event_for v nn i r sel bad R⟩

#print axioms regular_indices
#print axioms event_for
#print axioms event
end PrimeGap180.FirstEdgeSplit
