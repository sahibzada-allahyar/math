import TrialSlotSelection180

/-! Geometry of the actual retained Heath–Brown boxes. The cutoff on the
first prime interval survives localization in its parent product. -/
noncomputable section
open scoped BigOperators Topology
open Filter PrimeGap186
namespace PrimeGap180.Retained

abbrev slots (r : Fin 3 → Fin 5) (c : Fin 3) := Fin (2*((r c).val+1))
abbrev Slot (r : Fin 3 → Fin 5) := (c : Fin 3) × slots r c

def parent (r : Fin 3 → Fin 5) (c : Fin 3) : Finset (Slot r) :=
  Finset.univ.map (Function.Embedding.sigmaMk c)

theorem physical_parent_geometry (e : ℝ) (ep : 0 < e) :
    ∀ᶠ x : ℝ in atTop, ∀ (ζ a cut Θ : ℝ) (L U t : Fin 3 → ℝ) (r : Fin 3 → Fin 5)
      (ν : (c : Fin 3) → slots r c → ℕ),
      1 < Θ → Θ ≤ 2 → (∀ c, 0 ≤ t c) →
      (∀ c, x^ζ ≤ L c) → (∀ c, U c ≤ x^a) → U 0 ≤ x^cut →
      ν ∈ Fintype.piFinset (fun c => minorantHBBoxes ((r c).val+1) (L c) (U c) Θ) →
      let N := fun s : Slot r => Θ^(ν s.1 s.2)
      let w := fun s : Slot r => Real.logb x (N s)
      x*Θ^30 ≤ ∏ s, N s → (∏ s, N s)*Θ^30 ≤ 2*x →
      (∏ s : Slot r, minorantHBLocalizedSlot ((r s.1).val+1) (x^(9/100:ℝ))
        Θ (t s.1) (ν s.1) s.2) ≠ 0 →
      (∀ s, 0 ≤ w s) ∧
      (∀ s : Slot r, s.2.val < (r s.1).val+1 → w s ≤ 9/100+e) ∧
      (∀ c, ζ-e ≤ ∑ s ∈ parent r c, w s ∧ (∑ s ∈ parent r c, w s) ≤ a+e) ∧
      (∑ s ∈ parent r 0, w s) ≤ cut+e ∧ |(∑ s, w s)-1| ≤ e := by
  classical
  filter_upwards [(tendsto_rpow_atTop ep).eventually_ge_atTop ((2:ℝ)^10),
    eventually_ge_atTop (2:ℝ)] with x absorbed hx
  intro ζ a cut Θ L U t r ν mesh mesh2 tpos lbound ubound cap boxes N w radialLow radialHigh nonzero
  have x1 : 1 < x := by linarith
  have xp : 0 < x := zero_lt_one.trans x1
  have thetaPos : 0 < Θ := zero_lt_one.trans mesh
  have one (s : Slot r) : 1 ≤ N s := one_le_pow₀ mesh.le
  have pos (s : Slot r) : 0 < N s := zero_lt_one.trans_le (one s)
  have two : 2 ≤ x^e := (by norm_num : (2:ℝ) ≤ 2^10).trans absorbed
  have cover (c : Fin 3) : Θ^(2*((r c).val+1)) ≤ x^e := by
    have ten : 2*((r c).val+1) ≤ 10 := by have := (r c).isLt; omega
    exact ((pow_le_pow_left₀ thetaPos.le mesh2 _).trans (pow_le_pow_right₀ one_le_two ten)).trans absorbed
  have prodLog (c : Fin 3) : (∑ s ∈ parent r c, w s) =
      Real.logb x (∏ i, Θ^(ν c i)) := by
    rw [Real.logb_prod Finset.univ _ (fun i _ => (pow_pos thetaPos _).ne')]
    simp [parent,w,N,Function.Embedding.sigmaMk]
  have ph (c : Fin 3) := (Finset.mem_filter.mp (Fintype.mem_piFinset.mp boxes c)).2
  have upper (c : Fin 3) (v : ℝ) (h : U c ≤ x^v) : (∑ s ∈ parent r c, w s) ≤ v+e := by
    rw [prodLog]
    apply (Real.logb_le_iff_le_rpow x1 (Finset.prod_pos fun _ _ => pow_pos thetaPos _)).mpr
    rw [Real.rpow_add xp]
    exact (ph c).2.trans (mul_le_mul h (cover c) (pow_nonneg thetaPos.le _) (Real.rpow_nonneg xp.le _))
  have total : Real.logb x (∏ s, N s) = ∑ s, w s :=
    Real.logb_prod Finset.univ N (fun i _ => (pos i).ne')
  refine ⟨fun s => Real.logb_nonneg x1 (one s),?_,?_,upper 0 cut cap,?_⟩
  · intro s sm
    let F := minorantHBLocalizedSlot ((r s.1).val+1) (x^(9/100:ℝ)) Θ (t s.1) (ν s.1) s.2
    have ne : F ≠ 0 := fun h => nonzero (Finset.prod_eq_zero (Finset.mem_univ s) h)
    have cn : F.coeff ≠ 0 := by intro h; exact ne (by ext n; exact DFunLike.congr_fun h n)
    obtain ⟨m,hm⟩ := Finsupp.support_nonempty_iff.mpr cn
    have low := ((sourceT3_localized_slot_support_norm _ _ _ _ _ _ mesh mesh2 (tpos s.1)).1 m hm).1
    have hi := (minorantHBLocalizedSlot_moebius_support _ _ _ _ _ _ sm m hm).2
    apply (Real.logb_le_iff_le_rpow x1 (pos s)).mpr
    rw [Real.rpow_add xp]
    have m2 := mul_le_mul_of_nonneg_left two (Real.rpow_nonneg xp.le (9/100))
    change N s / 2 ≤ (m:ℝ) at low
    linarith only [low,hi,m2]
  · intro c
    refine ⟨?_,upper c a (ubound c)⟩
    rw [prodLog]
    apply (Real.le_logb_iff_rpow_le x1 (Finset.prod_pos fun _ _ => pow_pos thetaPos _)).mpr
    rw [Real.rpow_sub xp]
    exact (div_le_div_of_nonneg_left (Real.rpow_nonneg xp.le _) (pow_pos thetaPos _) (cover c)).trans
      ((div_le_div_of_nonneg_right (lbound c) (pow_nonneg thetaPos.le _)).trans (ph c).1)
  · apply abs_le.mpr
    have Ppos := Finset.prod_pos (fun (s : Slot r) (_ : s ∈ Finset.univ) => pos s)
    have thr : 1 ≤ Θ^30 := one_le_pow₀ mesh.le
    have low := (Real.le_logb_iff_rpow_le x1 Ppos).mpr
      (by rw [Real.rpow_one]; exact (le_mul_of_one_le_right xp.le thr).trans radialLow : x^(1:ℝ) ≤ ∏ s, N s)
    have high : (∏ s, N s) ≤ x^(1+e) := by
      rw [Real.rpow_add xp,Real.rpow_one]
      exact ((le_mul_of_one_le_right Ppos.le thr).trans radialHigh).trans
        (by simpa only [mul_comm x] using mul_le_mul_of_nonneg_right two xp.le)
    have last := (Real.logb_le_iff_le_rpow x1 Ppos).mpr high
    rw [total] at low last
    constructor <;> linarith

#print axioms physical_parent_geometry
end PrimeGap180.Retained
