import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G038
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 38

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G038

namespace PrimeGap180.PriceIsolatedGroup.G043
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 43

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G043

namespace PrimeGap180.PriceIsolatedGroup.G048
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 48

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G048

namespace PrimeGap180.PriceIsolatedGroup.G053
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 53

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G053
