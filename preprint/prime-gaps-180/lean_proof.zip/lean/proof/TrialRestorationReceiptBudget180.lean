import TrialRestorationBudget180

/-! The original published-in-the-workspace low and high mass allowances also
fit the signed loss. One common mass floor suffices for the 22 raw middle masses. -/
noncomputable section
open scoped Classical BigOperators
open MeasureTheory PrimeGap180.Sector PrimeGap180.RestorationRows
open PrimeGap180.RestorationCharge PrimeGap180.RestorationBudget
namespace PrimeGap180.RestorationReceiptBudget

structure Bounds : Prop where
  floor : (94.17312 : ℝ) ≤ 100^39 * originalMass
  lowMass : StructuralRun.layerMass 0 ≤ (RemovalReceipts.low : ℝ)*originalMass
  highMass : StructuralRun.layerMass 23 ≤ (RemovalReceipts.high : ℝ)*originalMass
  lowImage : imageSq 0 ≤ ticks 1196124 * originalMass
  highImage : imageSq 23 ≤ ticks 179904296 * originalMass
  middleRaw (i : Fin 22) : (100:ℝ)^39 * StructuralRun.layerMass (middle i) ≤ (RemovalReceipts.middle i : ℝ)
  middlePair (i : Fin 22) : restrictedSq (middle i) negativePair ≤ ticks (rows i).pairImage * originalMass
  middleJoint (i : Fin 22) : joint (middle i) ≤ ticks (rows i).joint * originalMass

private theorem nonnegative : 0 ≤ originalMass := integral_nonneg fun _ => sq_nonneg _

private theorem outer (b : Bounds) : charge 0 + charge 23 ≤ ticks 70243232 * originalMass := by
  have l := uniform_group (0:Fin 24) (3/5) (by norm_num)
  have h := uniform_group (23:Fin 24) (13/2) (by norm_num)
  have lc : (RemovalReceipts.low : ℝ) ≤ ticks 3647432 := by norm_num [RemovalReceipts.low,ticks]
  have hc : (RemovalReceipts.high : ℝ) ≤ ticks 4300316 := by norm_num [RemovalReceipts.high,ticks]
  have lm := b.lowMass.trans (mul_le_mul_of_nonneg_right lc nonnegative)
  have hm := b.highMass.trans (mul_le_mul_of_nonneg_right hc nonnegative)
  have li := b.lowImage
  have hi := b.highImage
  unfold ticks at lm hm li hi ⊢
  norm_num1 at l h
  linarith only [l,h,lm,hm,li,hi,nonnegative]

private theorem pay_row (b : Bounds) (i : Fin 22) : charge (middle i) ≤ ticks (rows i).cost * originalMass := by
  let t : ℝ := (rows i).young/1000000
  obtain ⟨ht,hcap⟩ := terms i
  have raw := middle_of_absolute i b.floor (b.middleRaw i)
  have h := (joint_and_pair (middle i) t ht).trans (add_le_add
    (add_le_add (b.middleJoint i) (mul_le_mul_of_nonneg_left raw ht.le))
    (mul_le_mul_of_nonneg_left (b.middlePair i) (one_div_nonneg.mpr ht.le)))
  calc
    _ ≤ ticks (rows i).joint * originalMass + t * (ticks (rows i).mass * originalMass) +
          (1/t)*(ticks (rows i).pairImage * originalMass) := h
    _ = (ticks (rows i).joint + t*ticks (rows i).mass + (1/t)*ticks (rows i).pairImage)*originalMass := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_right hcap nonnegative

theorem payment (b : Bounds) : NumericalAccount.restoredLoss ≤ ticks 1105574281 * originalMass := by
  have mid := Finset.sum_le_sum (s:=Finset.univ) (fun i _ => pay_row b i)
  rw [←Finset.sum_mul] at mid
  have s : (∑ i : Fin 22, ticks (rows i).cost) = ticks 1035331049 := by
    unfold ticks
    rw [←Finset.sum_div,←Nat.cast_sum,total]
  rw [s] at mid
  have outerCost := outer b
  have h := grouped
  rw [splitGroups] at h
  unfold ticks at mid outerCost ⊢
  linarith only [h,mid,outerCost]

theorem both (b : Bounds) :
    NumericalAccount.restoredLoss ≤ (0.000071406420 + 0.001035091858)*originalMass ∧
    NumericalAccount.mass Restoration.deleted ≤ 0.000160674*originalMass := by
  refine ⟨?_,RemovalReceipts.removed b.floor b.lowMass (fun i => b.middleRaw i) b.highMass⟩
  have h := payment b
  unfold ticks at h
  linarith only [h,nonnegative]

#print axioms payment
#print axioms both
end PrimeGap180.RestorationReceiptBudget
