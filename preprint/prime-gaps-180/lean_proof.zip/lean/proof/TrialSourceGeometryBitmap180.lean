import Mathlib.Data.List.Basic
import Mathlib.Data.Nat.Basic

/-! Exact bitmap semantics for the 465 maximal partner records. The union
is accompanied by a witness for an actual rectangle that covers the chosen
partner. The signed-matrix exclusion is checked on the same partner index. -/
namespace PrimeGap180.SourceBitmap

def bitmap {α} (p : α → Bool) : List α → Nat
  | [] => 0
  | a::xs => 2 * bitmap p xs + (if p a then 1 else 0)

theorem hit {α} (p : α → Bool) {xs : List α} {i : Nat} {a : α}
    (member : xs[i]? = some a) : (bitmap p xs).testBit i = p a := by
  induction xs generalizing i with
  | nil => simp at member
  | cons b tail ih =>
    cases i with
    | zero =>
      have e : b = a := by simpa using member
      subst b
      rw [bitmap,Nat.testBit_zero]
      cases h : p a <;> simp [h] <;> omega
    | succ i =>
      have tailMem : tail[i]? = some a := by simpa using member
      rw [bitmap,Nat.testBit_succ]
      have half : (2*bitmap p tail + (if p b then 1 else 0))/2 = bitmap p tail := by
        cases p b <;> simp <;> omega
      rw [half]
      exact ih tailMem

def union {α} (set : α → Nat) : List α → Nat
  | [] => 0
  | a::xs => set a ||| union set xs

theorem witness {α} {set : α → Nat} {xs : List α} {i : Nat} (on : (union set xs).testBit i = true) :
   ∃ x ∈ xs, (set x).testBit i = true := by
  induction xs with
  | nil => simp [union] at on
  | cons a xs ih =>
    have either : ((set a).testBit i || (union set xs).testBit i) = true := by
      simpa only [union,Nat.testBit_or] using on
    rcases Bool.or_eq_true_iff.mp either with left | right
    · exact ⟨a,by simp,left⟩
    · obtain ⟨b,m,h⟩ := ih right
      exact ⟨b,List.mem_cons_of_mem _ m,h⟩

theorem covered_witness {α} {set : α → Nat} {xs : List α} {above allowed i : Nat}
    (checked : (above &&& allowed) &&& union set xs = above &&& allowed)
    (active : allowed.testBit i = true) (large : above.testBit i = true) :
    ∃ x ∈ xs, (set x).testBit i = true := by
  apply witness
  have e := congrArg (fun w : Nat => w.testBit i) checked
  simpa [Nat.testBit_and,active,large] using e

#print axioms covered_witness
end PrimeGap180.SourceBitmap
