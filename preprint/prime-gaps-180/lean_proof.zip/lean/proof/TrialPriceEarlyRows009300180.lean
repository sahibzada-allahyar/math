import TrialPriceWitnessGroupCommand180
import TrialPriceIsolatedChecks180
import TrialPriceWitnessCharge180
import TrialPriceAffinePhysical180

noncomputable section
namespace PrimeGap180.PriceAssemblyGroup.G009
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyWitnessPriceGroup 9

#print axioms events
end PrimeGap180.PriceAssemblyGroup.G009
namespace PrimeGap180.PriceAssemblyGroup.G200
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyWitnessPriceGroup 200

#print axioms events
end PrimeGap180.PriceAssemblyGroup.G200
namespace PrimeGap180.PriceAssemblyGroup.G222
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyWitnessPriceGroup 222

#print axioms events
end PrimeGap180.PriceAssemblyGroup.G222
namespace PrimeGap180.PriceAssemblyGroup.G300
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyWitnessPriceGroup 300

#print axioms events
end PrimeGap180.PriceAssemblyGroup.G300
