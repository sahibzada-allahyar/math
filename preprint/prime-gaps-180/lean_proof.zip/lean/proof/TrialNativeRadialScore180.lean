import TrialPackedRoleKernels180

/-! The signed radial shell is a difference of exact Gram projections.
This includes the jump of the historical single-prime price. -/
noncomputable section
open scoped Classical BigOperators
open PrimeGap180.DebitNativeClasses PrimeGap180.PackedLaw PrimeGap180.NativeShellErasures
open PrimeGap180.PackedSingleFields
open PrimeGap180.NativePairUpdates PrimeGap180.SignedCapContractions PrimeGap180.PackedRoleKernels
namespace PrimeGap180.NativeRadialScore
set_option maxRecDepth 5000
set_option maxHeartbeats 1800000

private theorem combine {X : Type*} [Fintype X] (J : ℕ) (rad : X → ℕ)
    (selected : X → Hist → Prop) (w F : X → ℝ) (p : ℕ → ℕ → ℝ)
    (D : X → Hist → ℝ) (gram : Hist → ℕ → ℝ)
    (pointwise : ∀ x,F x=∑ c : Hist,if selected x c then update (p (rad x)) (D x) c else 0)
    (squares : ∀ (c : Hist) (k : ℕ),
      (∑ x : X,if rad x=J ∧ selected x c then (bank (D x) k)^2*w x else 0)=gram c k) :
    (∑ x : X,if rad x=J then F x*w x else 0) =
      ∑ c : Hist,(p J c.val*gram c c.val-p J (c.val+1)*gram c (c.val+1)) := by
  let val (x : X) (c : Hist) (k : ℕ) := if rad x=J ∧ selected x c then (bank (D x) k)^2*w x else 0
  let term (x : X) (c : Hist) := p J c.val*val x c c.val-p J (c.val+1)*val x c (c.val+1)
  calc
    _ = ∑ x : X,∑ c : Hist,term x c := by
      apply Finset.sum_congr rfl
      intro x _
      by_cases active : rad x=J
      · rw [if_pos active,pointwise,Finset.sum_mul]
        apply Finset.sum_congr rfl
        intro c _
        by_cases cap : selected x c
        · simp only [active,cap,ite_true,term,val,true_and,jump]; ring
        · simp [term,val,cap]
      · simp [active,term,val]
    _ = ∑ c : Hist,∑ x : X,term x c := Finset.sum_comm
    _ = _ := by
      apply Finset.sum_congr rfl
      intro c _
      unfold term
      rw [Finset.sum_sub_distrib,←Finset.mul_sum,←Finset.mul_sum]
      rw [show (∑ x,val x c c.val)=gram c c.val from squares c c.val,
        show (∑ x,val x c (c.val+1))=gram c (c.val+1) from squares c (c.val+1)]

theorem single (g : Grid) (i : Fin 39) (J : ℕ) :
    (∑ t : Fin 38 → Atom,if retained t=J then
      (NativeContractions.price (sectorAtom t) (retained t)*(singleN (ReferenceRoles.archive (law g)) i t)^2)*
        (∏ j,law g (t j)) else 0) = ∑ c : Hist,
      (keyPrice J c.val*singleGram g i c J c.val-keyPrice J (c.val+1)*singleGram g i c J (c.val+1)) :=
  combine J retained below (fun t => ∏ j,law g (t j))
    (fun t => NativeContractions.price (sectorAtom t) (retained t)*(singleN (ReferenceRoles.archive (law g)) i t)^2)
    keyPrice (fun t => eraseDelta (ReferenceRoles.archive (law g)) i t) (fun c k => singleGram g i c J k)
    (single_face _ i) (fun c k => single_square g i c J k)

/-- At each maximum-mark class select the actual positive price replacement
on the retained sector, with the original clamped inverse denominator. -/
def debitPrice (J k : ℕ) : ℝ :=
  if h : k<37 then
    let c := capAt ⟨k,h⟩
    PhysicalDebit.rate ((if J>CoarseLaw.T.maxIndex c then none else CoarseLaw.T.sector c (J+1)).getD 170) J
  else 0

theorem debit (g : Grid) (i : Fin 39) (J : ℕ) :
    (∑ t : Fin 38 → Atom,if retained t=J then
      (rateAtom t*(singleN (ReferenceRoles.archive (law g)) i t)^2)*
        (∏ j,law g (t j)) else 0) = ∑ c : Hist,
      (debitPrice J c.val*singleGram g i c J c.val-debitPrice J (c.val+1)*singleGram g i c J (c.val+1)) := by
  apply combine J retained below (fun t => ∏ j,law g (t j))
    (fun t => rateAtom t*(singleN (ReferenceRoles.archive (law g)) i t)^2)
    debitPrice (fun t => eraseDelta (ReferenceRoles.archive (law g)) i t) (fun c k => singleGram g i c J k)
  · intro t
    rw [single_updates]
    apply priced (below t) (maximum t) (below_iff t)
    intro m selected
    simp [debitPrice,rateAtom,sectorAtom,selected,m.isLt]
  · exact fun c k => single_square g i c J k

#print axioms debit

theorem pair (g : Grid) (J : ℕ) (p : ℕ → ℝ) :
    (∑ t : Fin 37 → Atom,if retained t=J then
      (p (retained t)*(ReferenceRoles.insertPair (ReferenceRoles.archive (law g)) t)^2)*
        (∏ j,law g (t j)) else 0) = ∑ c : Hist,(p J*pairGram g c J c.val-p J*pairGram g c J (c.val+1)) :=
  combine J retained below (fun t => ∏ j,law g (t j))
    (fun t => p (retained t)*(ReferenceRoles.insertPair (ReferenceRoles.archive (law g)) t)^2)
    (fun j _ => p j) (fun t => addPair (ReferenceRoles.archive (law g)) t) (fun c k => pairGram g c J k)
    (fun t => pair_face _ t (p (retained t))) (fun c k => pair_square g c J k)

#print axioms single
#print axioms pair
end PrimeGap180.NativeRadialScore
