import TrialDensityTriangleInputs180
namespace PrimeGap180.DensitySimplex.Horner.TriangleChecks
private theorem lower_den1 (z : Fin 2 → ℝ) :
    ((L 1).map (factorValue z)).prod/((unit^3:Int):ℝ) = threeDen (lowerMap (r 1) (s 1) z) := by
  have hr : r 1 = 7393999/10000000000 := by decide +kernel
  have hs : s 1 = 601690501/5000000000 := by decide +kernel
  have forms : L 1 = factors 1218169000 14787998 0 2406762004 := rfl
  rw [hr,hs,forms]
  norm_num [factors,unit,factorValue,Fin.sum_univ_two,threeDen,lowerMap] <;> ring
private theorem upper_den1 (z : Fin 2 → ℝ) :
    ((U 1).map (factorValue z)).prod/((unit^3:Int):ℝ) = threeDen (upperMap (r 1) (s 1) z) := by
  have hr : r 1 = 7393999/10000000000 := by decide +kernel
  have hs : s 1 = 601690501/5000000000 := by decide +kernel
  have forms : U 1 = factors 14787998 0 2406762004 2414156003 := rfl
  rw [hr,hs,forms]
  norm_num [factors,unit,factorValue,Fin.sum_univ_two,threeDen,upperMap] <;> ring

set_option maxRecDepth 65536 in
set_option maxHeartbeats 0 in
theorem row01 : triangleQ (r 1) (s 1) = FrozenNumbers.triangles 1 := by
  rw [triangle_from_forms _ _ (L 1) (U 1) (unit^3) (unit^3) (by decide) (by decide)
    lower_den1 upper_den1]
  decide +kernel

#print axioms row01
end PrimeGap180.DensitySimplex.Horner.TriangleChecks
