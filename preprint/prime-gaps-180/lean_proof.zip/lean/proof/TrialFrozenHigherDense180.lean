import TrialHigherDense180
import TrialSiftedFamilies180
import TrialSourceMatrix180

/-! Instantiate the dense higher-row proof with the twelve exact cutoff
triples from the diameter-180 schedule. -/
noncomputable section
open scoped BigOperators Classical
open PrimeGap182Audit PrimeGap182.TypeIII PrimeGap180.Central PrimeGap180.Retained PrimeGap180.Prefix
open PrimeGap180.Sifted PrimeGap180.Distribution
namespace PrimeGap180.Frozen

def parentCut : Fin 12 → ℝ :=
  ![2930517/10000000, 2927277/10000000, 2921877/10000000,
    2911077/10000000, 2900277/10000000, 2889477/10000000,
    2878677/10000000, 2873277/10000000, 2867877/10000000,
    2862477/10000000, 2857/10000, 2852757/10000000]

private theorem cut_data (i : Fin 12) :
    let a := (frozenCutoffs i).a
    let s := (frozenCutoffs i).smooth
    CutParameters a (1-s-a) ∧ 1-s-a ≤ parentCut i ∧ parentCut i < a ∧
      2*parentCut i+a ≤ 1 := by
  fin_cases i <;> refine ⟨⟨?_,?_,?_,?_,?_⟩,?_,?_,?_⟩ <;>
    norm_num [frozenCutoffs,parentCut]

/-- This is a ProvedBand consumed directly by scheduled_minorant_moment.
The local Fourier and incidence estimates are explicit hypotheses. -/
def higherDivisibleOfBlock (i : Fin 12) {j : ℕ} {w v d σb σ σf r τ : ℝ}
    (families : FamilyGuards (frozenCutoffs i) j w d σf r τ)
    (groups : CoefficientGuards j (frozenCutoffs i).a (frozenCutoffs i).smooth
      (parentCut i) w v d σb σ)
    (level : 1/2+2*w ≤ 53/100) (block : Averaged.SelectedBlockEstimate)
    (rank4 : AllIncidenceRankFourBounds) :
    ProvedBand (fun x => .higher (x^(frozenCutoffs i).a) (x^(parentCut i))) := by
  refine ⟨.divisible j w d (by linarith),fun h => ?_⟩
  obtain ⟨cuts,zc,ca,room⟩ := cut_data i
  have src := frozen_family_distribution i families rank4
  have align : (⟨(frozenCutoffs i).a,1-(frozenCutoffs i).a,(frozenCutoffs i).smooth,
      1-2*(frozenCutoffs i).a⟩ : Cutoffs) = frozenCutoffs i := by
    rw [← (frozen_relations i).1,← (frozen_relations i).2]
  exact higher_dense_of_block (align.symm ▸ src) cuts zc ca room groups level block rank4 h

def higherDivisible (i : Fin 12) {j : ℕ} {w v d σb σ σf r τ : ℝ}
    (families : FamilyGuards (frozenCutoffs i) j w d σf r τ)
    (groups : CoefficientGuards j (frozenCutoffs i).a (frozenCutoffs i).smooth
      (parentCut i) w v d σb σ)
    (level : 1/2+2*w ≤ 53/100) {C : ℝ} (hC : 0 ≤ C) {D : ℕ} (hD : 1 ≤ D)
    (base : BaselineLocalInputs) (fourier : PrimeFourierBounds C D) (rank4 : AllIncidenceRankFourBounds) :
    ProvedBand (fun x => .higher (x^(frozenCutoffs i).a) (x^(parentCut i))) :=
  higherDivisibleOfBlock i families groups level
    (Averaged.matrixToBlock (Averaged.cyclesToMatrix (primeBoundsToCycles hC hD base fourier))) rank4

/-- The sharp and higher rows can use the same source Fourier hypothesis. -/
def higherDivisibleOfSource (i : Fin 12) {j : ℕ} {w v d σb σ σf r τ : ℝ}
    (families : FamilyGuards (frozenCutoffs i) j w d σf r τ)
    (groups : CoefficientGuards j (frozenCutoffs i).a (frozenCutoffs i).smooth
      (parentCut i) w v d σb σ)
    (level : 1/2+2*w ≤ 53/100) {C : ℝ} (hC : 0 ≤ C) {D p₀ : ℕ}
    (source : LocalFourierHypothesis C D p₀) (rank4 : AllIncidenceRankFourBounds) :
    ProvedBand (fun x => .higher (x^(frozenCutoffs i).a) (x^(parentCut i))) :=
  higherDivisibleOfBlock i families groups level (Averaged.block_of_source hC source) rank4

#print axioms higherDivisibleOfSource
#print axioms higherDivisible
end PrimeGap180.Frozen
