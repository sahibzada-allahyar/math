import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G385
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 385

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G385

namespace PrimeGap180.PriceIsolatedGroup.G390
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 390

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G390

namespace PrimeGap180.PriceIsolatedGroup.G395
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 395

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G395

namespace PrimeGap180.PriceIsolatedGroup.G400
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 400

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G400
