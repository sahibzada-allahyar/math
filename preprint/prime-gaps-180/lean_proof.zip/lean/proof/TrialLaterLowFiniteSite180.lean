import TrialLaterLowScalar180
import TrialLaterLowQuadrature180
import TrialLaterLowTransformTail180

/-! Physical one-site payments on the deposited finite gamma grid. -/
noncomputable section
open MeasureTheory Set Filter PrimeGap180.Sector PrimeGap180.FrozenProfile
open scoped NNReal BigOperators
namespace PrimeGap180.LaterLowFiniteSite
open NativeSiteLaw (radial tail)
open LaterLowProduct (weight ν)
open LaterLowFactor (a w g panel survival)
open LaterLowTransform (site)
open private one_nonneg from TrialFrozenData180

private def kernel (edge : Fin 217) (b r : ℝ≥0) (z : Band 216) :=
  Real.exp (-((b:ℝ)*radial z+(r:ℝ)*(radial z-tail edge z)))
def step : ℝ := 1/100
def node (k : ℕ) := (k:ℝ)*step
def shift (k : ℕ) : ℝ≥0 := ⟨w*node k, by dsimp [w,node,step]; positivity⟩

local instance : IsFiniteMeasure ν := bandLaw_finite _
private theorem integrable (edge : Fin 217) (b r : ℝ≥0) : Integrable (kernel edge b r) ν := by
  have m : Measurable (kernel edge b r) := by unfold kernel radial tail; fun_prop
  apply (integrable_const (μ:=ν) (1:ℝ)).mono' m.aestronglyMeasurable
  filter_upwards [one_nonneg] with z zn
  have rn : 0≤radial z := Finset.sum_nonneg fun k _=>zn k
  have dn : 0≤radial z-tail edge z := sub_nonneg.mpr (Finset.sum_le_sum_of_subset_of_nonneg
    (Finset.filter_subset _ _) (fun k _ _=>zn k))
  unfold kernel
  rw [Real.norm_eq_abs,abs_of_nonneg (Real.exp_pos _).le]
  exact Real.exp_le_one_iff.mpr (neg_nonpos.mpr (add_nonneg (mul_nonneg b.2 rn) (mul_nonneg r.2 dn)))

def book (n : ℕ) (f : ℕ→ℝ) := a^2*f 0+(∑ k∈Finset.range n,panel step k*f k)+survival (node n)*f n

/-- The squared root-factor transform of the actual band intensity is
bounded by the finite sum of unweighted site transforms at the shifted
rates. Specialize to n=1600 for the archived mesh and tail. -/
theorem finite (edge : Fin 217) (b r : ℝ≥0) (n : ℕ) :
    (∫ z,weight (fun t=>g t^2) edge b r z ∂ν) ≤ book n (fun k=>site edge (b+shift k) r) := by
  let F := fun k=>kernel edge (b+shift k) r
  have fi (k : ℕ) : Integrable (F k) ν := integrable _ _ _
  have p (z : Band 216) (k : ℕ) : Real.exp (-(w*radial z*node k))*kernel edge b r z = F k z := by
    change _ = Real.exp (-(((b+shift k:ℝ≥0):ℝ)*radial z+(r:ℝ)*(radial z-tail edge z)))
    rw [kernel,←Real.exp_add,NNReal.coe_add]
    congr 1
    change _ = -(((b:ℝ)+w*node k)*radial z+(r:ℝ)*(radial z-tail edge z))
    ring
  have z0 (z : Band 216) : kernel edge b r z = F 0 z := by simpa [node] using p z 0
  have term (z : Band 216) (k : ℕ) (C : ℝ) : (C*Real.exp (-(w*radial z*node k)))*kernel edge b r z = C*F k z := by rw [mul_assoc,p]
  have im : Integrable (fun z=>a^2*F 0 z+∑ k∈Finset.range n,panel step k*F k z) ν := ((fi 0).const_mul (a^2)).add (integrable_finsetSum (Finset.range n) fun k _=>(fi k).const_mul (panel step k))
  have it := (fi n).const_mul (survival (node n))
  calc
    _ ≤ ∫ z,book n (fun k=>F k z) ∂ν := by
      apply integral_mono_of_nonneg (Eventually.of_forall fun z=>mul_nonneg (sq_nonneg _) (Real.exp_pos _).le) (im.add it)
      filter_upwards [one_nonneg] with z zn
      have h:=LaterLowFactor.quadrature step (by norm_num [step]) n (radial z) (Finset.sum_nonneg fun k _=>zn k)
      change g (radial z)^2 ≤ a^2+(∑ k∈Finset.range n,panel step k*Real.exp (-(w*radial z*node k)))+
        survival (node n)*Real.exp (-(w*radial z*node n)) at h
      change g (radial z)^2*kernel edge b r z ≤ _
      apply (mul_le_mul_of_nonneg_right h (Real.exp_pos _).le).trans_eq
      change (a^2+(∑ k∈Finset.range n,panel step k*Real.exp (-(w*radial z*node k)))+
        survival (node n)*Real.exp (-(w*radial z*node n)))*kernel edge b r z = book n (fun k=>F k z)
      simp only [add_mul,Finset.sum_mul,term,book]
      rw [z0]
    _ = _ := by
      change (∫ z,(a^2*F 0 z+∑ k∈Finset.range n,panel step k*F k z)+survival (node n)*F n z ∂ν)=_
      rw [integral_add im it,integral_add ((fi 0).const_mul _) (integrable_finsetSum _ fun k _=>(fi k).const_mul _),
        integral_finsetSum _ fun k _=>(fi k).const_mul _]
      simp only [integral_const_mul,book,site,F,kernel]

#print axioms finite
end PrimeGap180.LaterLowFiniteSite
