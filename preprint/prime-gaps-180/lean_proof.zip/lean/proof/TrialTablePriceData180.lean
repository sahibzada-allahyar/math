import TrialTablePriceRational180
import TrialPriceDiagonals180
import TrialMarkedPriceRadii180

namespace PrimeGap180.TablePrices
open ClippedPair PackedLedger

def rowOf (n : Fin 25) : FiveRow :=
  if n.val=0 then .old else if n.val≤12 then .full (Fin.ofNat 12 (n.val-1)) else
  if n.val=13 then .firstExtra else .extras (Fin.ofNat 11 (n.val-14))

def code : FiveRow → Fin 25
  | .old => 0
  | .full i => ⟨1+i.val,by omega⟩
  | .firstExtra => 13
  | .extras i => ⟨14+i.val,by omega⟩

theorem row_code (row : FiveRow) : rowOf (code row) = row := by
  cases row with
  | old => rfl
  | firstExtra => rfl
  | full i => fin_cases i <;> rfl
  | extras i => fin_cases i <;> rfl

def capOf (c : Fin 49) : ℚ := (PriceRadii.classes[c.val]!:ℚ)/10000
noncomputable def ratioQ (row : FiveRow) (c : Fin 49) : ℚ :=
  let v := match row with
    | .old => (raw.eventKernel[1]!)[c.val]!
    | .full j => (raw.resourceKernel[15+j.val]!)[c.val]!
    | .firstExtra => (raw.eventKernel[14]!)[c.val]!
    | .extras j => (raw.resourceKernel[38+j.val]!)[c.val]!
  (v.1:ℚ)/v.2

def scale : ℚ := 10^24

noncomputable def diagonalMass (row : FiveRow) (k : Fin 143) : ℚ :=
  ∑ i : Fin 72, if inDiagonal i k then pairMass row (i,secondIndex i k) else 0

theorem grouped (row : FiveRow) (q : ℚ) :
    table row q = ∑ k : Fin 143, diagonalMass row k / radius (cut row) q k.val := by
  unfold table
  rw [group_diagonals (fun i j => pairMass row (i,j) / radius (cut row) q (i.val+j.val))]
  apply Finset.sum_congr rfl
  intro k _
  rw [diagonalMass,Finset.sum_div]
  apply Finset.sum_congr rfl
  intro i _
  by_cases h : inDiagonal i k
  · simp only [ite_eq_left h,index_sum i k h]
  · simp only [ite_eq_right h,zero_div]

end PrimeGap180.TablePrices
