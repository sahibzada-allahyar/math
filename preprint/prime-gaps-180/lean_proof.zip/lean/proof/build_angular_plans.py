"""Build finite 37-site multiplicity proofs for all 53 frozen angular signatures."""
from collections import Counter
from pathlib import Path

from check_exact_endpoint_pair import SIGNATURES, group_assignments


def collected(sig):
    rows=[]
    def walk(i,occupied,m):
        if i==len(sig):
            rows.append((tuple(sorted(occupied)),m))
            return
        e=sig[i]
        for j in range(len(occupied)):
            changed=list(occupied)
            changed[j]+=e
            walk(i+1,changed,m)
        walk(i+1,(*occupied,e),m*(37-len(occupied)))
    walk(0,(),1)
    out=Counter()
    for key,m in reversed(rows):out[key]+=m
    assert out==group_assignments(sig)
    return list(out.items())


def list_lit(xs):
    return '['+','.join(str(x) for x in xs)+']'


def generate(destination):
    sgs=sorted({tuple(sorted(s+t)) for s in SIGNATURES for t in SIGNATURES})
    assert len(sgs)==53
    src=['import TrialMassAngularPlan180','namespace PrimeGap180.MassAngularPlan',
         'set_option maxRecDepth 20000','set_option maxHeartbeats 0']
    for j,sg in enumerate(sgs):
        plan=collected(sg)
        spec='['+',\n '.join(f'(List.replicate {37-len(es)} 0 ++ {list_lit(es)},{m})' for es,m in plan)+']'
        src.extend([f'def plan{j:02d} : Plan := {spec}',
                    f'theorem check{j:02d} : collect (plan {list_lit(sg)} (fun _ : Fin 37 => 0) 0)=plan{j:02d} := by decide +kernel',
                    f'theorem exact{j:02d} {{I R : Type*}} [Fintype I] [CommSemiring R] (W V : I → R) :',
                    f'    AngularOccupied.marked W V (fun _ : Fin 37 => 0) {list_lit(sg)} = eval (AngularSubset.moment W V) plan{j:02d} := by',
                    f'  rw [physical,check{j:02d}]',f'#print axioms exact{j:02d}'])
    src.extend(['end PrimeGap180.MassAngularPlan',''])
    file = destination/'TrialMassAngularPlans180.lean'
    file.write_text('\n'.join(src))
    return file
