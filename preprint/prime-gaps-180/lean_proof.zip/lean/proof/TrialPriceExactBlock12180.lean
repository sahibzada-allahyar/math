import TrialPriceScalar180
namespace PrimeGap180.PriceExactCensus
set_option maxHeartbeats 100000000
set_option maxRecDepth 65536
private theorem c384 : PriceScalar.checked (384 : Book.Label) = true := by decide +kernel
private theorem c385 : PriceScalar.checked (385 : Book.Label) = true := by decide +kernel
private theorem c386 : PriceScalar.checked (386 : Book.Label) = true := by decide +kernel
private theorem c387 : PriceScalar.checked (387 : Book.Label) = true := by decide +kernel
private theorem c388 : PriceScalar.checked (388 : Book.Label) = true := by decide +kernel
private theorem c389 : PriceScalar.checked (389 : Book.Label) = true := by decide +kernel
private theorem c390 : PriceScalar.checked (390 : Book.Label) = true := by decide +kernel
private theorem c391 : PriceScalar.checked (391 : Book.Label) = true := by decide +kernel
private theorem c392 : PriceScalar.checked (392 : Book.Label) = true := by decide +kernel
private theorem c393 : PriceScalar.checked (393 : Book.Label) = true := by decide +kernel
private theorem c394 : PriceScalar.checked (394 : Book.Label) = true := by decide +kernel
private theorem c395 : PriceScalar.checked (395 : Book.Label) = true := by decide +kernel
private theorem c396 : PriceScalar.checked (396 : Book.Label) = true := by decide +kernel
private theorem c397 : PriceScalar.checked (397 : Book.Label) = true := by decide +kernel
private theorem c398 : PriceScalar.checked (398 : Book.Label) = true := by decide +kernel
private theorem c399 : PriceScalar.checked (399 : Book.Label) = true := by decide +kernel
private theorem c400 : PriceScalar.checked (400 : Book.Label) = true := by decide +kernel
private theorem c401 : PriceScalar.checked (401 : Book.Label) = true := by decide +kernel
private theorem c402 : PriceScalar.checked (402 : Book.Label) = true := by decide +kernel
private theorem c403 : PriceScalar.checked (403 : Book.Label) = true := by decide +kernel
private theorem c404 : PriceScalar.checked (404 : Book.Label) = true := by decide +kernel
private theorem c405 : PriceScalar.checked (405 : Book.Label) = true := by decide +kernel
private theorem c406 : PriceScalar.checked (406 : Book.Label) = true := by decide +kernel
private theorem c407 : PriceScalar.checked (407 : Book.Label) = true := by decide +kernel
private theorem c408 : PriceScalar.checked (408 : Book.Label) = true := by decide +kernel
private theorem c409 : PriceScalar.checked (409 : Book.Label) = true := by decide +kernel
private theorem c410 : PriceScalar.checked (410 : Book.Label) = true := by decide +kernel
private theorem c411 : PriceScalar.checked (411 : Book.Label) = true := by decide +kernel
private theorem c412 : PriceScalar.checked (412 : Book.Label) = true := by decide +kernel
private theorem c413 : PriceScalar.checked (413 : Book.Label) = true := by decide +kernel
private theorem c414 : PriceScalar.checked (414 : Book.Label) = true := by decide +kernel
private theorem c415 : PriceScalar.checked (415 : Book.Label) = true := by decide +kernel
theorem block12 : ∀ i : Fin 32, PriceScalar.checked ⟨384+i.val,by omega⟩ = true :=
  Fin.cases c384 (Fin.cases c385 (Fin.cases c386 (Fin.cases c387 (Fin.cases c388 (Fin.cases c389 (Fin.cases c390 (Fin.cases c391 (Fin.cases c392 (Fin.cases c393 (Fin.cases c394 (Fin.cases c395 (Fin.cases c396 (Fin.cases c397 (Fin.cases c398 (Fin.cases c399 (Fin.cases c400 (Fin.cases c401 (Fin.cases c402 (Fin.cases c403 (Fin.cases c404 (Fin.cases c405 (Fin.cases c406 (Fin.cases c407 (Fin.cases c408 (Fin.cases c409 (Fin.cases c410 (Fin.cases c411 (Fin.cases c412 (Fin.cases c413 (Fin.cases c414 (Fin.cases c415 (fun i => Fin.elim0 i))))))))))))))))))))))))))))))))
#print axioms block12
end PrimeGap180.PriceExactCensus
