import TrialHighMassBands180

/-! On each maximum-mark band the physical 39-site spline is one archived
formula. Its true radial support removes the empty two-mark panels. -/
noncomputable section
open scoped BigOperators Classical
open MeasureTheory PrimeGap186 PrimeGap180.Sector PrimeGap180.FrozenProfile
open PrimeGap180.GateDeletion PrimeGap180.RemovedHighTags PrimeGap180.HighMassBands
namespace PrimeGap180.HighPanelSupport
open private least_spec least_of_pass exact_index from TrialStructuralGate180
open private get archive Archive.suffix from TrialFrozenData180

def bucket (c : Fine) : Fin 9 :=
  if c.val ≤ 11 then 0 else if c.val ≤ 12 then 1 else if c.val ≤ 20 then 2
  else if c.val ≤ 29 then 3 else if c.val ≤ 32 then 4 else if c.val ≤ 36 then 5
  else if c.val ≤ 39 then 6 else if c.val ≤ 40 then 7 else 8

def radius : Fin 9 → ℕ := ![130964,130964,130825,130825,129997,125536,124707,123370,117732]
def lowerIndex : Fin 9 → ℕ := ![44022,46567,47096,58332,60089,61104,63177,64599,65536]
def bottom (k : Fin 9) := if h : k.val=0 then cutoff else top ⟨k.val-1,by omega⟩

set_option maxRecDepth 65536 in
private theorem table : (∀ c j, c ≤ capClass j ↔ bucket c ≤ j) ∧
    (∀ j, bucket (capClass j) = j) ∧ (∀ c, T.maxIndex c = radius (bucket c)) ∧
    (∀ c, get (Archive.suffix archive) c.val = get (Archive.suffix archive) (capClass (bucket c)).val) := by
  decide +kernel

private theorem rows (c : Fine) : T.row c = T.row (capClass (bucket c)) := by
  funext p s k
  rw [FrozenData.row_eq_rat,FrozenData.row_eq_rat]
  simp only [FrozenData.rowQ,table.2.2.2 c]

/-- The original signed spline, including its support truncation, depends on the
nine selected representatives, even though its cap test examines 44 classes. -/
theorem raw (c : Fine) (j : Fin 39 → ℕ) :
    FrozenProfile.raw T j c = FrozenProfile.raw T j (capClass (bucket c)) := by
  have rad := table.2.2.1 (capClass (bucket c))
  rw [table.2.1] at rad
  simp only [FrozenProfile.raw,table.2.2.1 c,rad,amplitude,rows c]

private theorem pass {v : Full} (nn : ∀ i j, 0 ≤ v i j) {c f : Fine} (cf : c ≤ f)
    (h : bits T v (.cap c) = true) : bits T v (.cap f) = true := by
  have ordered : Monotone T.capEdge := Fin.monotone_iff_le_succ.mpr (by decide +kernel)
  let a := FrozenData.mesh (T.capEdge c).castSucc
  let b := FrozenData.mesh (T.capEdge f).castSucc
  have h1 := Lookup.suffix_antitone v nn (ordered cf)
  have h2 : a ≤ b := T.ordered.monotone (Fin.castSucc_le_castSucc_iff.mpr (ordered cf))
  change (if Lookup.suffix v (T.capEdge c) < a/2 then true else false) = true at h
  change (if Lookup.suffix v (T.capEdge f) < b/2 then true else false) = true
  split at h
  next h3 => exact ite_eq_left (by linarith only [h1,h2,h3])
  next => contradiction

private theorem choice_of_fine {v : Full} (nn : ∀ i j, 0 ≤ v i j) {c : Fine}
    (hc : least (fun g => bits T v (.cap g)) = some c) :
    choice (bits T v) = some (bucket c) := by
  have ok := (least_spec hc).1
  have next := pass nn ((table.1 c (bucket c)).mpr le_rfl) ok
  obtain ⟨k,hk,le⟩ := least_of_pass (p:=fun j => bits T v (.cap (capClass j))) next
  have fk := (least_spec hk).1
  obtain ⟨t,ht,below⟩ := least_of_pass (p:=fun g => bits T v (.cap g)) fk
  have tc : t = c := Option.some.inj (ht.symm.trans hc)
  subst t
  exact hk.trans (congrArg some (le_antisymm le ((table.1 c k).mp below)))

/-- A nonzero physical sample selects the archive radius and the archive's
signed angular/radial polynomial, on its exact (untruncated) native indices. -/
theorem physical {v : Full} (nn : ∀ i j, 0 ≤ v i j) (nz : Restoration.original v ≠ 0)
    {k : Fin 9} (hk : choice (bits T v) = some k) :
    Restoration.original v = FrozenProfile.raw T (fun i => Native.cell (v i)) (capClass k) ∧
    Native.cellSum v ≤ radius k := by
  obtain ⟨c,hc,small⟩ := StructuralGate.geometric_of_nonzero nz
  have bk : bucket c = k := Option.some.inj ((choice_of_fine nn hc).symm.trans hk)
  have idx := funext (exact_index v (small.trans (T.maxBound c)))
  constructor
  · change originalValue (bits T v) = _
    rw [originalValue,hc]
    exact (raw c _).trans (by rw [idx,bk])
  · rw [idx,table.2.2.1,bk] at small
    exact small

theorem floor_bottom (k : Fin 9) : ⌊bottom k/Native.step⌋₊ = lowerIndex k := by
  have step : 0 < Native.step := by norm_num [Native.step]
  unfold bottom
  split
  next z =>
    have : k = 0 := Fin.ext z
    subst k
    norm_num [cutoff,Lookup.ticks,Native.step,lowerIndex]
  next nz =>
    rw [capTable,mul_div_cancel_right₀ _ step.ne',Nat.floor_natCast]
    have h : ∀ (k : Fin 9) (_ : k.val ≠ 0), nativeCap ⟨k.val-1,by omega⟩ = lowerIndex k := by
      decide +kernel
    exact h k nz

theorem panel (Y : Fin 39 → FiniteMeasure ℝ) (n : Fin 39 → ℕ)
    (x : (i : Fin 39) → Fin (n i) → ℝ)
    (hY : ∀ i, (Y i).restrict (Set.Ioc 0 cutoff) = Y i) (hx : ∀ i a, cutoff < x i a ∧ x i a ≤ cap)
    (u v : (i : Fin 39) × Fin (n i)) (ne : u ≠ v) (j k : Fin 9)
    (hu : bottom j ≤ x u.1 u.2) (hv : bottom k ≤ x v.1 v.2)
    (chosen : choice (bits T (state Y n x)) = some k)
    (nz : Restoration.original (state Y n x) ≠ 0) :
    lowerIndex j + lowerIndex k ≤ Native.cellSum (state Y n x) ∧
    Native.cellSum (state Y n x) ≤ radius k := by
  have step : 0 < Native.step := by norm_num [Native.step]
  let f := fun w : (i : Fin 39) × Fin (n i) => ⌊x w.1 w.2 / Native.step⌋₊
  have pair : f u + f v ≤ ∑ w, f w := by
    rw [← Finset.sum_pair ne]
    exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) (fun i _ _ => Nat.zero_le _)
  rw [Fintype.sum_sigma] at pair
  have lj : lowerIndex j ≤ f u := (floor_bottom j) ▸ Nat.floor_mono (div_le_div_of_nonneg_right hu step.le)
  have lk : lowerIndex k ≤ f v := (floor_bottom k) ▸ Nat.floor_mono (div_le_div_of_nonneg_right hv step.le)
  exact ⟨((Nat.add_le_add lj lk).trans pair).trans (tag_indices Y n x hY hx),
    (physical (fun _ _ => NNReal.zero_le_coe) nz chosen).2⟩

/-- Of the 45 unordered mark-band pairs, 11 have no radial support at all. -/
theorem census : (Finset.univ.filter (fun p : Fin 9 × Fin 9 =>
    p.1 ≤ p.2 ∧ radius p.2 < lowerIndex p.1 + lowerIndex p.2)).card = 11 := by decide +kernel

#print axioms physical
#print axioms panel
#print axioms census
end PrimeGap180.HighPanelSupport
