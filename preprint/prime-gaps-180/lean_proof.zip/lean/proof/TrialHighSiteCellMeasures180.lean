import TrialHighMarkedMeasures180

/-! The inserted one-site measures have exactly the mixed-band radial
cell bounds used in the positive product before squaring the signed spline. -/
noncomputable section
open scoped Classical ENNReal
open MeasureTheory PrimeGap186
namespace PrimeGap180.HighSiteCellMeasures
open HighMarkedMeasures HighMixedCell
open private measurable_insert from TrialHighMarkedMeasures180
open private mass_meas from TrialFixedTagRadial180

private theorem measurable_cell (L H : ℝ) : MeasurableSet (cellSet L H) :=
  mass_meas measurableSet_Ico

private theorem phys_finite (e : ℝ) : IsFiniteMeasure (PoissonSplit.phys e) := by
  let : IsProbabilityMeasure (fragmentLaw e) := fragmentLaw_isProbabilityMeasure e
  change IsFiniteMeasure (ENNReal.ofReal (Real.exp Real.eulerMascheroniConstant*e) • fragmentLaw e)
  exact (fragmentLaw e).smul_finite ENNReal.ofReal_ne_top

/-- Unlabelled fragment mass is integrated against the actual smaller-cap
measure. The outer coordinate law can fix any legal harmonic mark bands. -/
theorem cell {α : Type*} [MeasurableSpace α] (μ : Measure α) [SFinite μ]
    (e L H : ℝ) (n : ℕ) (marks : α→Fin n→ℝ) (hm : Measurable marks) :
    HighMarkedMeasures.insert e (μ.map marks) (cellSet L H) =
      ∫⁻ z, ∫⁻ Y, test L H (Y+weightedEmpirical n (marks z)) ∂PoissonSplit.phys e ∂μ := by
  have hT : Measurable (test L H) := measurable_const.indicator (measurable_cell L H)
  have m : Measurable (fun p : FiniteMeasure ℝ × (Fin n→ℝ) =>
      test L H (p.1 + weightedEmpirical n p.2)) := hT.comp (measurable_insert n)
  let : IsFiniteMeasure (PoissonSplit.phys e) := phys_finite e
  calc
    _ = ∫⁻ Y, test L H Y ∂HighMarkedMeasures.insert e (μ.map marks) := by
      unfold test
      rw [lintegral_indicator (measurable_cell L H),lintegral_const,Measure.restrict_apply_univ,one_mul]
    _ = ∫⁻ u, ∫⁻ Y, test L H (Y+weightedEmpirical n u) ∂PoissonSplit.phys e ∂(μ.map marks) := by
      unfold HighMarkedMeasures.insert
      rw [lintegral_map hT (measurable_insert n),lintegral_prod_symm _ m.aemeasurable]
    _ = _ := lintegral_map m.lintegral_prod_left' hm

def one (e a b : ℝ) := HighMarkedMeasures.insert e ((PoissonSplit.intensity a b).map (fun x : ℝ => (fun _ : Fin 1 => x)))
def two (e a b c d : ℝ) :=
  HighMarkedMeasures.insert e (((PoissonSplit.intensity a b).prod (PoissonSplit.intensity c d)).map
    (fun q : ℝ × ℝ => (![q.1,q.2] : Fin 2→ℝ)))

theorem one_bound {e a b : ℝ} (he : 0<e) (ha : 0<a) (ab : a≤b) (L H : ℝ) :
    one e a b (cellSet L H) ≤
      ENNReal.ofReal (H-L) * (ENNReal.ofReal (1/a)*ENNReal.ofReal (min b H-a)) := by
  let : IsFiniteMeasure (PoissonSplit.intensity a b) := (PoissonSplit.jumps ha ab).property
  have m : Measurable (fun x : ℝ => (fun _ : Fin 1 => x)) := measurable_pi_lambda _ fun _ => measurable_id
  rw [one,cell _ e L H 1 _ m]
  exact HighMixedCell.one he ha L H

theorem two_bound {e a b c d : ℝ} (he : 0<e) (ha : 0<a) (ab : a≤b)
    (hc : 0<c) (cd : c≤d) (L H : ℝ) :
    two e a b c d (cellSet L H) ≤
      ENNReal.ofReal (H-L) * (ENNReal.ofReal (1/c) * (ENNReal.ofReal (1/a) *
        ENNReal.ofReal (ExactTagArea.rectangle a b c d H))) := by
  let : IsFiniteMeasure (PoissonSplit.intensity a b) := (PoissonSplit.jumps ha ab).property
  let : IsFiniteMeasure (PoissonSplit.intensity c d) := (PoissonSplit.jumps hc cd).property
  let : IsFiniteMeasure (PoissonSplit.phys e) := phys_finite e
  let v : ℝ × ℝ → Fin 2→ℝ := fun q => ![q.1,q.2]
  have mv : Measurable v := measurable_pi_lambda _ fun i => by
    fin_cases i
    · exact measurable_fst
    · exact measurable_snd
  rw [two,cell _ e L H 2 v mv]
  rw [lintegral_prod _]
  · exact HighMixedCell.pair he ha ab hc cd L H
  · have m : Measurable (fun q : (ℝ × ℝ) × FiniteMeasure ℝ =>
        test L H (q.2 + weightedEmpirical 2 (v q.1))) :=
      (measurable_const.indicator (measurable_cell L H)).comp
        ((measurable_insert 2).comp (measurable_snd.prodMk (mv.comp measurable_fst)))
    exact m.lintegral_prod_right'.aemeasurable

#print axioms cell
#print axioms one_bound
#print axioms two_bound
end PrimeGap180.HighSiteCellMeasures
