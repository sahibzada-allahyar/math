import TrialSiftedLabelCount180
import Mathlib.Data.List.Prime
import TrialRoughCollisions180

/-! Support of the actual six arithmetic functions, including their
cofactor weights and the weak ordering in the final family. -/
noncomputable section
open scoped BigOperators Classical Topology
open PrimeGap186 Filter PrimeGap180.Distribution
namespace PrimeGap180.Sifted

theorem labels_rough (cuts : Cutoffs) (x : ℝ) (hx : 1 < x) (j : Fin 6)
    (ps : List ℕ) (hp : ps ∈ families cuts x j) :
    ∀ q ∈ ps, x^cuts.rough ≤ (q:ℝ) := by
  classical
  have primes := named_primes cuts x j ps hp
  fin_cases j <;> simp only [families] at hp
  · simp only [Finset.mem_singleton] at hp
    simp [hp]
  all_goals
    obtain ⟨t,ht,rfl⟩ := Finset.mem_image.mp hp
    intro q hq
    obtain ⟨i,rfl⟩ := List.mem_ofFn.mp hq
    apply (Real.le_logb_iff_rpow_le hx
      (Nat.cast_pos.mpr (primes _ (List.mem_ofFn.mpr ⟨i,rfl⟩)).pos)).mp
    have bounds := (Finset.mem_filter.mp ht).2
    fin_cases i <;> dsimp at * <;> grind

theorem theta_zero_of_small_prime (cuts : Cutoffs) (x : ℝ) (hx : 1 < x) (j : Fin 6)
    (w : List ℕ → ℝ) (N q : ℕ) (pq : q.Prime) (div : q ∣ N) (small : (q:ℝ) < x^cuts.rough) :
    theta cuts x j w N = 0 := by
  classical
  change (∑ ps ∈ families cuts x j, ∑ d ∈ N.divisorsAntidiagonal,
    if d.1 = ps.prod then w ps * roughWeight (x^cuts.rough) d.2 else 0) = 0
  apply Finset.sum_eq_zero
  intro ps hps
  apply Finset.sum_eq_zero
  intro d hd
  split
  · rename_i named
    have free : ¬q ∣ ps.prod := by
      intro h
      obtain ⟨r,hr,qr⟩ := pq.prime.dvd_prod_iff.mp h
      have eq := (Nat.prime_dvd_prime_iff_eq pq (named_primes cuts x j ps hps r hr)).mp qr
      exact small.not_ge (eq.symm ▸ labels_rough cuts x hx j ps hps r hr)
    have pair := Nat.mem_divisorsAntidiagonal.mp hd
    have rem := (pq.dvd_mul.mp (pair.1 ▸ div : q ∣ d.1 * d.2)).resolve_left (named ▸ free)
    have zero : roughWeight (x^cuts.rough) d.2 = 0 := by
      apply ite_eq_right
      rintro ⟨nz,good⟩
      exact small.not_ge (good q (Nat.mem_primeFactors.mpr ⟨pq,rem,nz⟩))
    rw [zero,mul_zero]
  · rfl

#print axioms theta_zero_of_small_prime

private def arity (j : Fin 6) : ℕ :=
  match j.val with
  | 0 => 0
  | 1 => 1
  | 2 | 3 => 2
  | _ => 3

private theorem label_length (cuts : Cutoffs) (x : ℝ) (j : Fin 6) {ps : List ℕ}
    (mem : ps ∈ families cuts x j) : ps.length = arity j := by
  fin_cases j <;> simp only [families] at mem
  · simp_all [arity]
  all_goals obtain ⟨_,_,rfl⟩ := Finset.mem_image.mp mem; simp [arity]

/-- The size bound holds on all positive integers, including repeated
prime factors, as required by the dense-modulus collision estimate. -/
theorem theta_divisor_bound (cuts : Cutoffs) (x : ℝ) (j : Fin 6) (N : ℕ) (nz : N ≠ 0) :
    ‖theta cuts x j (fun _ => 1) N‖ ≤ (N.divisors.card:ℝ)^3 := by
  classical
  let F := families cuts x j
  let D := F.filter (fun ps => ps.prod ∣ N)
  let boxes := Fintype.piFinset (fun _ : Fin (arity j) => N.divisors)
  have subset : D ⊆ boxes.image List.ofFn := by
    intro ps hps
    obtain ⟨hp,hd⟩ := Finset.mem_filter.mp hps
    have len := label_length cuts x j hp
    let t (i : Fin (arity j)) := ps.get (i.cast len.symm)
    have eq : List.ofFn t = ps := by
      apply List.ext_getElem
      · simp [len]
      · intro i hi hj
        simp [t]
    apply Finset.mem_image.mpr
    refine ⟨t,Fintype.mem_piFinset.mpr ?_,eq⟩
    intro i
    exact Nat.mem_divisors.mpr ⟨dvd_trans (List.dvd_prod (List.get_mem ps _)) hd,nz⟩
  have hc : D.card ≤ N.divisors.card^(arity j) := by
    exact (Finset.card_le_card subset).trans
      (Finset.card_image_le.trans (by simp [boxes,Fintype.card_piFinset]))
  have degree : arity j ≤ 3 := by fin_cases j <;> decide
  have one : 1 ≤ N.divisors.card := Finset.card_pos.mpr ⟨1,Nat.mem_divisors.mpr ⟨one_dvd _,nz⟩⟩
  change ‖∑ ps ∈ F, ∑ d ∈ N.divisorsAntidiagonal, if d.1 = ps.prod then
    1 * roughWeight (x^cuts.rough) d.2 else 0‖ ≤ _
  calc
    _ ≤ ∑ ps ∈ F, ‖∑ d ∈ N.divisorsAntidiagonal, if d.1 = ps.prod then
        1 * roughWeight (x^cuts.rough) d.2 else 0‖ := norm_sum_le _ _
    _ ≤ ∑ ps ∈ F, if ps.prod ∣ N then (1:ℝ) else 0 := by
      apply Finset.sum_le_sum
      intro ps hp
      rw [Nat.sum_divisorsAntidiagonal (fun d e => if d = ps.prod then
        1*roughWeight (x^cuts.rough) e else 0),Finset.sum_ite_eq']
      by_cases h : ps.prod ∣ N <;> simp [Nat.mem_divisors,nz,h,roughWeight]
      split <;> norm_num
    _ = (D.card:ℝ) := by simp [D,Finset.sum_boole]
    _ ≤ _ := by exact_mod_cast hc.trans (Nat.pow_le_pow_right one degree)

#print axioms theta_divisor_bound


/-- The collision estimate now applies to the repeated-prime part of each
literal family, with arbitrary fixed divisor weights on the moduli. -/
theorem sifted_repeated_distribution (cuts : Cutoffs) (J j : ℕ) (A θ δ : ℝ) (hA : 0 < A)
    (level : θ ≤ 54/100) (cut : cuts.a ≤ 5/12) (hr : cuts.rough = 1-2*cuts.a) :
    ∃ K : ℝ, 0 < K ∧ ∀ᶠ x : ℝ in atTop, ∀ l : Fin 6, ∀ (I S : Finset ℕ) (b : ℕ),
    (∀ p ∈ I, p.Prime) → b.Coprime (∏ p ∈ I, p) → S ⊆ dense j θ δ x I →
    ∑ q ∈ S, (q.divisors.card:ℝ)^J * ‖fullDiscrepancy (∑ n ∈ window x,
      Finsupp.single n (if Squarefree n then 0 else (theta cuts x l (fun _ => 1) n : ℂ))) q b‖ ≤
        K*x/(Real.log x)^A := by
  classical
  obtain ⟨K,hK,raw⟩ := Collisions.dense_rough_collisions 3 J j A θ δ cuts.a hA level cut
  refine ⟨K,hK,?_⟩
  filter_upwards [raw,eventually_gt_atTop (1:ℝ)] with x raw hx
  intro l I S b prime cop sub
  let e (n : ℕ) : ℂ := if n ∈ window x ∧ ¬Squarefree n then theta cuts x l (fun _ => 1) n else 0
  have size (n : ℕ) (hn : n ∈ Finset.Icc 1 ⌊2*x⌋₊) : ‖e n‖ ≤ (n.divisors.card:ℝ)^3 := by
    simp only [e]
    split
    · simpa using theta_divisor_bound cuts x l n (Nat.ne_of_gt (Finset.mem_Icc.mp hn).1)
    · simp
  have supp (n : ℕ) (_ : n ∈ Finset.Icc 1 ⌊2*x⌋₊) (ne : e n ≠ 0) :
      ¬Squarefree n ∧ ∀ q : ℕ, q.Prime → q ∣ n → x^(1-2*cuts.a) ≤ (q:ℝ) := by
    by_cases hit : n ∈ window x ∧ ¬Squarefree n
    · refine ⟨hit.2,?_⟩
      intro q pq div
      by_contra! small
      rw [← hr] at small
      exact ne (by simp [e,hit,theta_zero_of_small_prime cuts x hx l _ n q pq div small])
    · exact (ne (by simp [e,hit])).elim
  have eq : (∑ n ∈ Finset.Icc 1 ⌊2*x⌋₊, Finsupp.single n (e n)) =
      ∑ n ∈ window x, Finsupp.single n (if Squarefree n then 0 else
        (theta cuts x l (fun _ => 1) n : ℂ)) := by
    ext n
    have cover (h : n ∈ window x) : n ∈ Finset.Icc 1 ⌊2*x⌋₊ :=
      Finset.mem_Icc.mpr ⟨(Nat.ceil_pos.mpr (zero_lt_one.trans hx)).trans_le (Finset.mem_Icc.mp h).1,
        (Finset.mem_Icc.mp h).2⟩
    by_cases hw : n ∈ window x
    · simp [Finsupp.finsetSum_apply,Finsupp.single_apply,Finset.sum_ite_eq',e,hw,cover hw,ite_not]
    · simp [Finsupp.finsetSum_apply,Finsupp.single_apply,Finset.sum_ite_eq',e,hw]
  simpa only [eq] using raw I S b e prime cop sub size supp

#print axioms sifted_repeated_distribution

/-- Restrict all six literal sifted distribution estimates to squarefree
integers on the same dyadic interval and the same set of moduli. -/
theorem sifted_squarefree_distribution (cuts : Cutoffs) (j : ℕ) (w δ : ℝ)
    (src : Distribution cuts j w δ) (level : 1/2+2*w ≤ 54/100)
    (cut : cuts.a ≤ 5/12) (hr : cuts.rough = 1-2*cuts.a) (A : ℝ) (hA : 0 < A) :
    ∃ K : ℝ, 0 < K ∧ ∀ᶠ x : ℝ in atTop, ∀ l : Fin 6, ∀ (I S : Finset ℕ) (b : ℕ),
    (∀ p ∈ I, p.Prime) → b.Coprime (∏ p ∈ I, p) → S ⊆ dense j (1/2+2*w) δ x I →
    ∑ q ∈ S, ‖fullDiscrepancy (∑ n ∈ window x, Finsupp.single n
      (if Squarefree n then (theta cuts x l (fun _ => 1) n : ℂ) else 0)) q b‖ ≤
      K*x/(Real.log x)^A := by
  classical
  obtain ⟨K,hK,full⟩ := src A hA
  obtain ⟨B,hB,rep⟩ := sifted_repeated_distribution cuts 0 j A _ δ hA level cut hr
  refine ⟨K+B,add_pos hK hB,?_⟩
  filter_upwards [full,rep] with x full rep
  intro l I S b primes cop sub
  let θ := fun n => (theta cuts x l (fun _ => 1) n : ℂ)
  let f := ∑ n ∈ window x, Finsupp.single n (θ n)
  let s := ∑ n ∈ window x, Finsupp.single n (if Squarefree n then θ n else 0)
  let r := ∑ n ∈ window x, Finsupp.single n (if Squarefree n then 0 else θ n)
  have eq : s+r=f := by
    dsimp only [s,r,f]
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro n _
    by_cases hn : Squarefree n <;> simp [hn]
  have bound (q : ℕ) : ‖fullDiscrepancy s q b‖ ≤
      ‖fullDiscrepancy f q b‖ + ‖fullDiscrepancy r q b‖ := by
    have split := congrArg (fun g => fullDiscrepancy g q b) eq
    simp only [hbBoundary_fullDiscrepancy_add] at split
    exact (eq_sub_of_add_eq split) ▸ norm_sub_le _ _
  have hb : ∑ q ∈ S, ‖fullDiscrepancy r q b‖ ≤ B*x/(Real.log x)^A := by
    simpa only [pow_zero,one_mul] using rep l I S b primes cop sub
  calc
    _ ≤ _ := Finset.sum_le_sum fun q _ => bound q
    _ = _ := Finset.sum_add_distrib
    _ ≤ _ := (add_le_add (full l I S b primes cop sub) hb).trans_eq (by ring)

#print axioms sifted_squarefree_distribution

end PrimeGap180.Sifted
