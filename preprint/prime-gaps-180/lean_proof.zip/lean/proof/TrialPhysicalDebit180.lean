import TrialNativeContractions180
import TrialGateDeletion180

/-! Direct comparison for the positive replacement debit on the actual single-site law. -/
noncomputable section
open scoped Classical BigOperators Topology
open MeasureTheory Filter PrimeGap186 PrimeGap180.Sector PrimeGap180.FrozenProfile
open PrimeGap180.FrozenData PrimeGap180.EndpointPhysical PrimeGap180.Detection
open PrimeGap180.AdverseScore PrimeGap180.CoarseLaw PrimeGap180.CoarseForms
namespace PrimeGap180.PhysicalDebit

abbrev Full := Fin 39 → B
abbrev Face := Fin 38 → B

def inv (a : ℝ) := 1/(ledger - min 0.2801 (max 0 a))
def diff (s : Fin 521) (q : ℝ) :=
  max 0 ((((oldPrice s).1 : ℝ) + (oldPrice s).2*q)/10^14 -
    (((archivedPrice s).1 : ℝ) + (archivedPrice s).2*q)/10^14)
def rate (s : Fin 521) (j : ℕ) := diff s (inv (Native.adverse (d := 38) j))
def face (F : Full → ℝ) (i : Fin 39) (s : Fin 521) (v : Face) :=
  integralFace mesh i (restrictFace i (fun r => FrozenData.label r = s) F) v
def debit (F : Full → ℝ) :=
  rho * ∑ i : Fin 39, ∑ s : Fin 521, ∫ v : Face, rate s (Native.cellSum v) * (face F i s v)^2 ∂prod 38

theorem actual : NumericalAccount.directDebit = debit trial := rfl

def terms (i : Fin 39) (s : Fin 521) (x : Fin 38 → State) :=
  rate s (NativeContractions.total x) * (if NativeContractions.label x = s then single i x else 0)^2

private theorem actualIndex (i : Fin 39) (v : Face) (ok : ∀ j,good (v j))
    (nz : single i (array v) ≠ 0) : Native.cellSum v = NativeContractions.total (array v) := by
  have hit : ∃ z, Restoration.original (i.insertNth (α := fun _ => B) z v) ≠ 0 := by
    by_contra! empty
    exact nz ((signed_single i v ok).symm.trans (by simp [empty]))
  obtain ⟨z,hz⟩ := hit
  have h := Restoration.original_index _ hz
  apply Finset.sum_congr rfl
  intro j _
  have k := (Finset.single_le_sum (s := Finset.univ)
    (f := fun l => Native.cell ((i.insertNth (α := fun _ => B) z v) l))
    (fun _ _ => Nat.zero_le _) (Finset.mem_univ (i.succAbove j))).trans h
  simp only [Fin.insertNth_apply_succAbove] at k
  change Native.cell (v j) = min (Native.cell (v j)) 130965
  omega

theorem original_finite : debit Restoration.original =
    rho * ∑ i : Fin 39, ∑ s : Fin 521, ∑ x, terms i s x * ∏ j, weight (x j) := by
  unfold debit
  apply congrArg (rho * ·)
  apply Finset.sum_congr rfl
  intro i _
  apply Finset.sum_congr rfl
  intro s _
  apply Eq.trans _ (integral_states (terms i s))
  apply integral_congr_ae
  filter_upwards [good_prod 38] with v ok
  unfold face terms
  rw [integralFace_restrict,NativeContractions.label_eq v ok]
  by_cases active : NativeContractions.label (array v) = s
  · simp only [ite_eq_left active]
    change rate s (Native.cellSum v) * (∫ z,Restoration.original (i.insertNth (α := fun _ => B) z v) ∂μ)^2 = _
    rw [signed_single i v ok]
    by_cases off : single i (array v)=0
    · simp [off]
    · rw [actualIndex i v ok off]
  · simp [active]

#print axioms actual
#print axioms original_finite
def Regular {X : Type*} [MeasurableSpace X] (f : X → ℝ) :=
  Measurable f ∧ Bornology.IsBounded (Set.range f)

local instance finiteLaw : IsFiniteMeasure μ := bandLaw_finite _

private theorem raw_reg : Regular Restoration.original := by
  have reg := coded_regular T (fun c => GateDeletion.originalValue c.1)
  exact ⟨reg.1,reg.2.1⟩

private theorem deleted_reg : Regular Restoration.deleted := by
  refine ⟨raw_reg.1.sub trial_regular.1,?_⟩
  obtain ⟨C,_,hC⟩ := raw_reg.2.exists_pos_norm_le
  obtain ⟨D,_,hD⟩ := trial_bounded.exists_pos_norm_le
  refine isBounded_iff_forall_norm_le.mpr ⟨C+D,?_⟩
  rintro _ ⟨x,rfl⟩
  exact (norm_sub_le _ _).trans (add_le_add (hC _ ⟨x,rfl⟩) (hD _ ⟨x,rfl⟩))

private theorem insert_int {F : Full → ℝ} (reg : Regular F) (i : Fin 39) (v : Face) :
    Integrable (fun z => F (i.insertNth (α := fun _ => B) z v)) μ := by
  have cont : Continuous (fun z : B => i.insertNth (α := fun _ => B) z v) :=
    Continuous.finInsertNth (A := fun _ : Fin 39 => B) (g := fun _ : B => v) i continuous_id continuous_const
  exact integrable_of_measurable_of_bounded_range μ _ (reg.1.comp cont.measurable)
    (reg.2.subset (Set.range_comp_subset_range _ _))

private theorem face_reg {F : Full → ℝ} (reg : Regular F) (i : Fin 39) (s : Fin 521) :
    Regular (face F i s) := by
  let ins := fun p : Face × B => i.insertNth (α := fun _ => B) p.2 p.1
  have mi : Measurable ins := (continuous_snd.finInsertNth i continuous_fst).measurable
  have meas : Measurable (integralFace mesh i F) := (reg.1.comp mi).stronglyMeasurable.integral_prod_right'.measurable
  have lab : MeasurableSet {r : Face | FrozenData.label r=s} :=
    (label_regular T).1 (measurableSet_singleton s)
  change Measurable (fun v : Face => face F i s v) ∧ Bornology.IsBounded (Set.range (fun v : Face => face F i s v))
  simp only [face,integralFace_restrict]
  refine ⟨Measurable.ite lab meas measurable_const,?_⟩
  obtain ⟨C,hC,bound⟩ := reg.2.exists_pos_norm_le
  refine isBounded_iff_forall_norm_le.mpr ⟨C*μ.real Set.univ,?_⟩
  rintro _ ⟨v,rfl⟩
  by_cases yes : FrozenData.label v=s
  · simp only [yes,↓reduceIte]
    exact norm_integral_le_of_norm_le_const (Eventually.of_forall fun z => bound _ ⟨_,rfl⟩)
  · simp only [yes,↓reduceIte,norm_zero]
    positivity

private theorem rate_reg (s : Fin 521) : Regular (fun v : Face => rate s (Native.cellSum v)) := by
  have cells : Measurable (@Native.cellSum 216 38) := by unfold Native.cellSum Native.cell; fun_prop
  refine ⟨(measurable_of_countable (rate s)).comp cells,?_⟩
  have cont : Continuous (diff s) := by unfold diff; fun_prop
  apply ((isCompact_Icc (a := (0:ℝ)) (b := 1/(ledger-0.2801))).image cont).isBounded.subset
  rintro _ ⟨v,rfl⟩
  refine ⟨_,⟨?_,?_⟩,rfl⟩
  · apply one_div_nonneg.mpr
    exact (sub_nonneg.mpr ((min_le_left _ _).trans (by norm_num [ledger])))
  · apply one_div_le_one_div_of_le (by norm_num [ledger])
    exact sub_le_sub_left (min_le_left _ _) _

private theorem term_int {F : Full → ℝ} (reg : Regular F) (i : Fin 39) (s : Fin 521) :
    Integrable (fun v : Face => rate s (Native.cellSum v)*(face F i s v)^2) (prod 38) := by
  obtain ⟨mk,bk⟩ := rate_reg s
  obtain ⟨mf,bf⟩ := face_reg reg i s
  apply integrable_of_measurable_of_bounded_range _ _ (mk.mul (mf.pow_const 2))
  obtain ⟨C,hC,c⟩ := bk.exists_pos_norm_le
  obtain ⟨D,hD,d⟩ := bf.exists_pos_norm_le
  apply isBounded_iff_forall_norm_le.mpr
  refine ⟨C*D^2,?_⟩
  rintro _ ⟨v,rfl⟩
  change ‖rate s (Native.cellSum v)*(face F i s v)^2‖ ≤ _
  rw [norm_mul,norm_pow]
  exact mul_le_mul (c _ ⟨v,rfl⟩) (pow_le_pow_left₀ (norm_nonneg _) (d _ ⟨v,rfl⟩) 2) (by positivity) hC.le

private theorem face_sub (i : Fin 39) (s : Fin 521) (v : Face) :
    face trial i s v = face Restoration.original i s v - face Restoration.deleted i s v := by
  simp only [face,integralFace_restrict]
  by_cases lab : FrozenData.label v=s
  · simp only [ite_eq_left lab,integralFace,Restoration.deleted]
    rw [integral_sub (insert_int raw_reg i v) (insert_int ⟨trial_regular.1,trial_bounded⟩ i v)]
    ring
  · simp [lab]

/-- Weighted Young inequality for the restored physical trial. The fixed
weight 7/20 avoids normalizing the trial or constructing a square-root operator. -/
theorem split : NumericalAccount.directDebit ≤
    (27/20)*debit Restoration.original + (27/7)*debit Restoration.deleted := by
  have bound (i : Fin 39) (s : Fin 521) :
      (∫ v : Face, rate s (Native.cellSum v)*(face trial i s v)^2 ∂prod 38) ≤
      (27/20)*(∫ v : Face, rate s (Native.cellSum v)*(face Restoration.original i s v)^2 ∂prod 38) +
      (27/7)*(∫ v : Face, rate s (Native.cellSum v)*(face Restoration.deleted i s v)^2 ∂prod 38) := by
    rw [←integral_const_mul,←integral_const_mul,←integral_add
      ((term_int raw_reg i s).const_mul (27/20)) ((term_int deleted_reg i s).const_mul (27/7))]
    apply integral_mono (term_int ⟨trial_regular.1,trial_bounded⟩ i s)
      (((term_int raw_reg i s).const_mul (27/20)).add ((term_int deleted_reg i s).const_mul (27/7)))
    intro v
    have young (a b : ℝ) : (a-b)^2 ≤ 27/20*a^2+27/7*b^2 := by
      nlinarith [sq_nonneg (7*a+20*b)]
    have nonneg : 0 ≤ rate s (Native.cellSum v) := le_max_left _ _
    change rate s (Native.cellSum v)*(face trial i s v)^2 ≤ (27/20)*(rate s (Native.cellSum v)*(face Restoration.original i s v)^2) + (27/7)*(rate s (Native.cellSum v)*(face Restoration.deleted i s v)^2)
    rw [face_sub]
    have h := mul_le_mul_of_nonneg_left (young (face Restoration.original i s v) (face Restoration.deleted i s v)) nonneg
    linarith only [h]
  rw [actual]
  unfold debit
  have h := mul_le_mul_of_nonneg_left (Finset.sum_le_sum (s := Finset.univ)
    (fun (i : Fin 39) _ => Finset.sum_le_sum (s := Finset.univ) (fun s _ => bound i s))) (by norm_num [rho] : (0:ℝ) ≤ rho)
  simp only [Finset.sum_add_distrib,←Finset.mul_sum] at h
  linarith only [h]

theorem receiver (raw : debit Restoration.original ≤ 0.000023397302*NumericalAccount.mass Restoration.original)
    (localBound : debit Restoration.deleted ≤ 0.01815*NumericalAccount.mass Restoration.deleted)
    (deletedMass : NumericalAccount.mass Restoration.deleted ≤ 0.000160674*NumericalAccount.mass Restoration.original) :
    NumericalAccount.directDebit ≤ 0.000042838*NumericalAccount.mass Restoration.original := by
  have nonnegative : 0 ≤ NumericalAccount.mass Restoration.original := integral_nonneg fun _ => sq_nonneg _
  linarith only [split,raw,localBound,deletedMass,nonnegative]

#print axioms split
#print axioms receiver

/-- The retained geometric support available to the inserted site of the
uncut physical trial. Deleting a configuration can only shrink this set. -/
def kept (i : Fin 39) (v : Face) := {z : B | Restoration.original (i.insertNth (α := fun _ => B) z v) ≠ 0}
def fibreMass (i : Fin 39) (v : Face) := μ.real (kept i v)
def RowBound := ∀ i : Fin 39, ∀ᵐ v ∂prod 38,
  39*rho*rate (FrozenData.label v) (Native.cellSum v)*fibreMass i v ≤ 0.01815

private theorem integral_cs {ν : Measure B} [IsFiniteMeasure ν] {f : B → ℝ} (hf : MemLp f 2 ν) :
    (∫ t,f t ∂ν)^2 ≤ ν.real Set.univ * (∫ t,(f t)^2 ∂ν) := by
  have ip {a b : B → ℝ} (ha : MemLp a 2 ν) (hb : MemLp b 2 ν) :
      inner ℝ (ha.toLp a) (hb.toLp b) = ∫ t, a t * b t ∂ν := by
    rw [L2.inner_def]
    apply integral_congr_ae
    filter_upwards [ha.coeFn_toLp,hb.coeFn_toLp] with t ah bh
    simp [ah,bh,mul_comm]
  have one : MemLp (fun _ : B => (1:ℝ)) 2 ν := memLp_const 1
  have cs := real_inner_mul_inner_self_le (one.toLp _) (hf.toLp _)
  rw [ip one hf,ip one one,ip hf hf] at cs
  simpa only [one_mul,integral_const,smul_eq_mul,mul_one,←pow_two,one_pow] using cs

private theorem local_cs (i : Fin 39) (v : Face) :
    (integralFace mesh i Restoration.deleted v)^2 ≤ fibreMass i v *
      (∫ z,(Restoration.deleted (i.insertNth (α := fun _ => B) z v))^2 ∂μ) := by
  let f := fun z : B => Restoration.deleted (i.insertNth (α := fun _ => B) z v)
  have off : ∀ z, z ∉ kept i v → f z = 0 := by
    intro z hz
    have zz : Restoration.original (i.insertNth (α := fun _ => B) z v) = 0 := not_ne_iff.mp hz
    rcases Restoration.selected (i.insertNth (α := fun _ => B) z v) with cut|cut <;> simp [f,Restoration.deleted,cut,zz]
  have eq₁ := setIntegral_eq_integral_of_forall_compl_eq_zero (μ := μ) off
  have eq₂ := setIntegral_eq_integral_of_forall_compl_eq_zero (μ := μ) (s := kept i v) (f := fun z => (f z)^2)
    (fun z hz => by simp [off z hz])
  have meas : Measurable f := deleted_reg.1.comp (Continuous.finInsertNth (A := fun _ : Fin 39 => B) (g := fun _ : B => v) i continuous_id continuous_const).measurable
  obtain ⟨C,hC,h⟩ := deleted_reg.2.exists_pos_norm_le
  have lp : MemLp f 2 (μ.restrict (kept i v)) :=
    MemLp.of_bound meas.aestronglyMeasurable C (Eventually.of_forall fun z => h _ ⟨_,rfl⟩)
  have cs := integral_cs lp
  rw [eq₁,eq₂] at cs
  simpa only [Measure.real,Measure.restrict_apply_univ,fibreMass,f,integralFace] using cs

private theorem collapsed (i : Fin 39) (F : Full → ℝ) (hF : Regular F) :
    (∑ s : Fin 521, ∫ v : Face, rate s (Native.cellSum v)*(face F i s v)^2 ∂prod 38) =
     ∫ v : Face, rate (FrozenData.label v) (Native.cellSum v)*(integralFace mesh i F v)^2 ∂prod 38 := by
  rw [←integral_finsetSum _ (fun s _ => term_int hF i s)]
  apply integral_congr_ae
  apply ae_of_all
  intro v
  classical
  simp [face,integralFace_restrict,ite_pow,mul_ite,Finset.sum_ite_eq]

private theorem reinsert (i : Fin 39) :
    (∫ v : Face, ∫ z,(Restoration.deleted (i.insertNth (α := fun _ => B) z v))^2 ∂μ ∂prod 38) =
      NumericalAccount.mass Restoration.deleted := by
  let chart := MeasurableEquiv.piFinSuccAbove (fun _ : Fin 39 => B) i
  have mp := measurePreserving_piFinSuccAbove (fun _ : Fin 39 => μ) i
  let G := fun p : B × Face => (Restoration.deleted (chart.symm p))^2
  have reg : Integrable G (μ.prod (prod 38)) := by
    apply integrable_of_measurable_of_bounded_range _ _ ((deleted_reg.1.comp chart.symm.measurable).pow_const 2)
    obtain ⟨C,_,bound⟩ := deleted_reg.2.exists_pos_norm_le
    refine isBounded_iff_forall_norm_le.mpr ⟨C^2,?_⟩
    rintro _ ⟨p,rfl⟩
    simp only [norm_pow]
    exact pow_le_pow_left₀ (norm_nonneg _) (bound _ ⟨_,rfl⟩) 2
  change (∫ v : Face, ∫ z,G (z,v) ∂μ ∂prod 38) = _
  rw [←integral_prod_symm G reg]
  exact mp.symm.integral_comp' (fun t => (Restoration.deleted t)^2)


private def fiberSquare (i : Fin 39) (v : Face) :=
  ∫ z,(Restoration.deleted (i.insertNth (α := fun _ => B) z v))^2 ∂μ

private theorem fiberSquare_int (i : Fin 39) : Integrable (fiberSquare i) (prod 38) := by
  let ins := fun p : Face × B => i.insertNth (α := fun _ => B) p.2 p.1
  have mi : Measurable ins := (continuous_snd.finInsertNth i continuous_fst).measurable
  have t : Integrable (fun p : Face × B => (Restoration.deleted (ins p))^2) ((prod 38).prod μ) := by
    apply integrable_of_measurable_of_bounded_range _ _ ((deleted_reg.1.comp mi).pow_const 2)
    obtain ⟨C,_,bound⟩ := deleted_reg.2.exists_pos_norm_le
    refine isBounded_iff_forall_norm_le.mpr ⟨C^2,?_⟩
    rintro _ ⟨p,rfl⟩
    rw [norm_pow]
    exact pow_le_pow_left₀ (norm_nonneg _) (bound _ ⟨_,rfl⟩) 2
  exact t.integral_prod_left

theorem deleted_schur (row : RowBound) :
    debit Restoration.deleted ≤ 0.01815*NumericalAccount.mass Restoration.deleted := by
  have each (i : Fin 39) :
      (∑ s : Fin 521,∫ v : Face,rate s (Native.cellSum v)*(face Restoration.deleted i s v)^2 ∂prod 38)
      ≤ (0.01815/(39*rho))*NumericalAccount.mass Restoration.deleted := by
    rw [collapsed i _ deleted_reg,←reinsert i,←integral_const_mul]
    have summable := integrable_finsetSum Finset.univ (fun s _ => term_int deleted_reg i s)
    have fullInt : Integrable (fun v : Face => rate (FrozenData.label v) (Native.cellSum v)*
        (integralFace mesh i Restoration.deleted v)^2) (prod 38) := by
      have eq (v : Face) : rate (FrozenData.label v) (Native.cellSum v) * (integralFace mesh i Restoration.deleted v)^2 =
          ∑ s : Fin 521,rate s (Native.cellSum v)*(face Restoration.deleted i s v)^2 := by
        classical
        simp [face,integralFace_restrict,ite_pow,mul_ite,Finset.sum_ite_eq]
      simp_rw [eq]
      exact summable
    apply integral_mono_ae fullInt ((fiberSquare_int i).const_mul _)
    filter_upwards [row i] with v hv
    let w := rate (FrozenData.label v) (Native.cellSum v)
    let f := integralFace mesh i Restoration.deleted v
    have hw : 0 ≤ w := le_max_left _ _
    have norm : w*fibreMass i v ≤ 0.01815/(39*rho) := by
      apply (le_div_iff₀ (by norm_num [rho] : (0:ℝ) < 39*rho)).mpr
      change 39*rho*w*fibreMass i v ≤ 0.01815 at hv
      linarith only [hv]
    have sq : 0 ≤ fiberSquare i v := integral_nonneg fun _ => sq_nonneg _
    change w*f^2 ≤ _*fiberSquare i v
    calc
      _ ≤ w * (fibreMass i v * fiberSquare i v) :=
        mul_le_mul_of_nonneg_left (local_cs i v) hw
      _ = (w*fibreMass i v)*fiberSquare i v := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_right norm sq
  have h := mul_le_mul_of_nonneg_left (Finset.sum_le_sum (s := Finset.univ) (fun i _ => each i)) (by norm_num [rho] : 0 ≤ rho)
  unfold debit
  exact h.trans_eq (by simp [rho]; ring)

#print axioms deleted_schur

/-- An integer endpoint test valid on the full clamped denominator interval. -/
def inactive (s : Fin 521) : Bool :=
  let a := (oldPrice s).1-(archivedPrice s).1
  let b := (oldPrice s).2-(archivedPrice s).2
  decide (4999*a+10000*b ≤ 0 ∧ 2198*a+10000*b ≤ 0)

theorem inactive_rate (s : Fin 521) (ok : inactive s = true) (j : ℕ) : rate s j = 0 := by
  let a := (oldPrice s).1-(archivedPrice s).1
  let b := (oldPrice s).2-(archivedPrice s).2
  change decide (4999*a+10000*b ≤ 0 ∧ 2198*a+10000*b ≤ 0) = true at ok
  obtain ⟨p,q⟩ := of_decide_eq_true ok
  have P : (4999:ℝ)*(a:ℝ)+10000*(b:ℝ) ≤ 0 := by exact_mod_cast p
  have Q : (2198:ℝ)*(a:ℝ)+10000*(b:ℝ) ≤ 0 := by exact_mod_cast q
  let d := ledger - min 0.2801 (max 0 (Native.adverse (d := 38) j))
  have low : (0.2198:ℝ) ≤ d := by
    dsimp [d,ledger]
    linarith only [min_le_left 0.2801 (max 0 (Native.adverse (d := 38) j))]
  have high : d ≤ 0.4999 := by
    dsimp [d,ledger]
    linarith only [le_min (by norm_num : (0:ℝ) ≤ 0.2801) (le_max_left 0 (Native.adverse (d := 38) j))]
  have pos : 0 < d := by linarith
  have sign : (a:ℝ)*d+(b:ℝ) ≤ 0 := by
    by_cases h : 0 ≤ (a:ℝ)
    · nlinarith only [mul_le_mul_of_nonneg_left high h,P]
    · nlinarith only [mul_le_mul_of_nonpos_left low (le_of_not_ge h),Q]
  have out : (a:ℝ)+(b:ℝ)/d ≤ 0 := by
    apply (le_of_mul_le_mul_right (a := d) _ pos)
    field_simp
    linarith only [sign]
  unfold rate diff
  apply max_eq_left
  change (((oldPrice s).1:ℝ)+(oldPrice s).2*(1/d))/10^14 -
    (((archivedPrice s).1:ℝ)+(archivedPrice s).2*(1/d))/10^14 ≤ 0
  simp only [a,b,Int.cast_sub] at out
  simp only [div_eq_mul_inv] at out ⊢
  linarith only [out]

theorem inactive_term (F : Full → ℝ) (i : Fin 39) (s : Fin 521) (ok : inactive s = true) :
    (∫ v : Face,rate s (Native.cellSum v)*(face F i s v)^2 ∂prod 38) = 0 := by
  simp only [inactive_rate s ok,zero_mul,integral_zero]


#print axioms inactive_rate
private theorem radial_meas : Measurable NativeSiteLaw.radial := by unfold NativeSiteLaw.radial; fun_prop

theorem radial_domination : μ.map NativeSiteLaw.radial ≤ volume.restrict (Set.Ici (0:ℝ)) := by
  have pos : 0 < cap := by norm_num [cap,physicalCap,rho]
  have ae : ∀ᵐ X ∂fragmentLaw cap, (NativeSiteLaw.radial ∘ fragmentBandMasses mesh) X = (X.mass : ℝ) := by
    filter_upwards [ae_restrict_Ioc_fragmentLaw cap] with X hX
    change (∑ j, fragmentBandMasses mesh X j) = (X.mass : ℝ)
    rw [sum_fragmentBandMasses mesh T.ordered.monotone X,show mesh 0=0 from T.first,show mesh (Fin.last 217)=cap from T.last,hX]
  change Measure.map NativeSiteLaw.radial (ENNReal.ofReal (Real.exp Real.eulerMascheroniConstant * cap) •
    Measure.map (fragmentBandMasses mesh) (fragmentLaw cap)) ≤ _
  rw [Measure.map_smul _ radial_meas.aemeasurable,Measure.map_map radial_meas (measurable_fragmentBandMasses mesh),
    Measure.map_congr ae,normalized_fragmentLaw_mass_eq_dickman _ pos]
  have upper : ∀ᵐ t ∂(volume.restrict (Set.Ici (0:ℝ))), ENNReal.ofReal (dickmanRho (t/cap)) ≤ 1 :=
    ae_of_all _ fun t => by simpa using ENNReal.ofReal_le_ofReal (dickmanRho_analytic.2.2.2.2.2.1 (t/cap)).2
  simpa using withDensity_mono upper

theorem initial_cells (n : ℕ) : μ.real {z | Native.cell z ≤ n} ≤ ((n:ℝ)+1)*Native.step := by
  let top := ((n:ℝ)+1)*Native.step
  have step_pos : 0 < Native.step := by norm_num [Native.step]
  have nonnegative : 0 ≤ top := mul_nonneg (by positivity) step_pos.le
  have sub : {z | Native.cell z ≤ n} ⊆ NativeSiteLaw.radial ⁻¹' Set.Iio top := by
    intro z hz
    have val := Nat.lt_floor_add_one (NativeSiteLaw.radial z/Native.step)
    change ⌊NativeSiteLaw.radial z/Native.step⌋₊ ≤ n at hz
    have div : NativeSiteLaw.radial z/Native.step < (n:ℝ)+1 := val.trans_le (by exact_mod_cast Nat.succ_le_succ hz)
    exact (div_lt_iff₀ step_pos).mp div
  have en : μ {z | Native.cell z ≤ n} ≤ ENNReal.ofReal top := calc
    _ ≤ μ (NativeSiteLaw.radial ⁻¹' Set.Iio top) := measure_mono sub
    _ = (μ.map NativeSiteLaw.radial) (Set.Iio top) := (Measure.map_apply radial_meas measurableSet_Iio).symm
    _ ≤ (volume.restrict (Set.Ici (0:ℝ))) (Set.Iio top) := radial_domination _
    _ = _ := by
      rw [Measure.restrict_apply measurableSet_Iio,show Set.Iio top ∩ Set.Ici (0:ℝ)=Set.Ico 0 top by ext x; simp [and_comm],Real.volume_Ico,sub_zero]
  simpa [Measure.real,ENNReal.toReal_ofReal nonnegative] using ENNReal.toReal_mono ENNReal.ofReal_ne_top en

/-- A pointwise integer insertion ceiling suffices for the Schur estimate.
Only retained states of positive physical measure enter this condition. -/
def CellCertificate := ∀ i : Fin 39, ∀ᵐ v ∂prod 38,
  (∀ᵐ z ∂μ, Restoration.original (i.insertNth (α := fun _ => B) z v)=0) ∨
  ∃ n : ℕ, (∀ᵐ z ∂μ, z ∈ kept i v → Native.cell z ≤ n) ∧
    39*rho*rate (FrozenData.label v) (Native.cellSum v)*(((n:ℝ)+1)*Native.step) ≤ 0.01815

theorem row_of_cells (certificate : CellCertificate) : RowBound := by
  intro i
  filter_upwards [certificate i] with v h
  rcases h with off|⟨n,sub,ceiling⟩
  · have zero : μ (kept i v) = 0 := ae_iff.mp off
    norm_num [fibreMass,Measure.real,zero]
  · have massLe : fibreMass i v ≤ ((n:ℝ)+1)*Native.step :=
      (ENNReal.toReal_mono (measure_ne_top μ _) (measure_mono_ae (show kept i v ≤ᵐ[μ] {z | Native.cell z ≤ n} from sub))).trans (initial_cells n)
    have nn : 0 ≤ rate (FrozenData.label v) (Native.cellSum v) := le_max_left _ _
    have hr : 0 ≤ rho := by norm_num [rho]
    exact (mul_le_mul_of_nonneg_left massLe (by positivity)).trans ceiling

#print axioms initial_cells
#print axioms row_of_cells

/-- This bound is a statement about finite site states. It has no integral or
almost-everywhere premise. Values of the signed spline can be replaced by any
larger geometric support when providing the integer insertion ceiling. -/
def FiniteCells := ∀ (i : Fin 39) (x : Fin 38 → State),
  (∀ z : State, rawState (i.insertNth (α := fun _ => State) z x) = 0) ∨
  ∃ n : ℕ, (∀ z : State, rawState (i.insertNth (α := fun _ => State) z x) ≠ 0 → z.1.val ≤ n) ∧
    39*rho*rate (NativeContractions.label x) (NativeContractions.total x)*(((n:ℝ)+1)*Native.step) ≤ 0.01815

private theorem index_on (x : Full) (nz : Restoration.original x ≠ 0) (k : Fin 39) :
    Native.cell (x k) = (state (x k)).1.val := by
  have h := (Finset.single_le_sum (s := Finset.univ) (f := fun l => Native.cell (x l))
    (fun _ _ => Nat.zero_le _) (Finset.mem_univ k)).trans (Restoration.original_index _ nz)
  change Native.cell (x k) = min _ 130965
  omega

private theorem inserted_value (i : Fin 39) (v : Face) (ok : ∀ j, good (v j)) (z : B) (oz : good z) :
    Restoration.original (i.insertNth (α := fun _ => B) z v) =
      rawState (i.insertNth (α := fun _ => State) (state z) (array v)) := by
  have ins : ∀ j, good (i.insertNth (α := fun _ => B) z v j) := fun j =>
    i.succAboveCases (by simpa using oz) (fun k => by simpa using ok k) j
  rw [native_original _ ins]
  apply congrArg rawState
  funext j
  exact i.succAboveCases (by simp [array]) (fun k => by simp [array]) j

theorem cells_of_finite (certificate : FiniteCells) : CellCertificate := by
  intro i
  filter_upwards [good_prod 38] with v ok
  by_cases present : ∃ z, Restoration.original (i.insertNth (α := fun _ => B) z v) ≠ 0
  · obtain ⟨w,hw⟩ := present
    rcases certificate i (array v) with off|⟨n,support,check⟩
    · left
      filter_upwards [good_ae] with z oz
      exact (inserted_value i v ok z oz).trans (off _)
    · right
      refine ⟨n,?_,?_⟩
      · filter_upwards [good_ae] with z oz nz
        have nonzero : Restoration.original (i.insertNth (α := fun _ => B) z v) ≠ 0 := nz
        have ix := index_on _ nonzero i
        simp only [Fin.insertNth_apply_same] at ix
        rw [ix]
        exact support (state z) ((inserted_value i v ok z oz) ▸ nonzero)
      · have idxeq : Native.cellSum v = NativeContractions.total (array v) :=
          Finset.sum_congr rfl fun j _ => by simpa [idx,array] using index_on _ hw (i.succAbove j)
        rwa [NativeContractions.label_eq v ok,idxeq]
  · push Not at present
    exact Or.inl (ae_of_all _ present)

theorem restored_of_finite (certificate : FiniteCells)
    (raw : debit Restoration.original ≤ 0.000023397302*NumericalAccount.mass Restoration.original)
    (deletedMass : NumericalAccount.mass Restoration.deleted ≤ 0.000160674*NumericalAccount.mass Restoration.original) :
    NumericalAccount.directDebit ≤ 0.000042838*NumericalAccount.mass Restoration.original :=
  receiver raw (deleted_schur (row_of_cells (cells_of_finite certificate))) deletedMass

#print axioms cells_of_finite
#print axioms restored_of_finite


end PrimeGap180.PhysicalDebit
