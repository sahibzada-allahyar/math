import TrialPriceResourceGrams180
import TrialPriceGainsCertified180
import Batteries.Tactic.OpenPrivate

noncomputable section
open scoped BigOperators
namespace PrimeGap180.PriceResourceSlots
open Book Price

def matrixGram (p : Nat × String) : Group → Group → Int :=
  intGram (fun (g : Group) (j : Fin p.1) => PackedLedger.integer p g.val j.val)

/-- The 49 original matrix slots must equal the independently reflected resource rows. -/
def Bound : Prop := ∀ u : Resource,
  PackedLedger.raw.matrices[14+PriceScalar.resourceIndex u]! =
    PriceFactorSource.physical (PriceFactorSource.factorShapes[PriceScalar.resourceIndex u]!)

theorem byEntries (r : Nat) (F : Group → Fin r → Int) (p : Nat × String)
    (rank : r=p.1) (entries : ∀ (g : Group) (j : Fin r), F g j = PackedLedger.integer p g.val j.val)
    (g h : Group) : intGram F g h = matrixGram p g h := by
  subst r
  unfold intGram matrixGram
  apply Finset.sum_congr rfl
  intro j _
  exact congrArg₂ (· * ·) (entries g j) (entries h j)

end PrimeGap180.PriceResourceSlots

namespace PrimeGap180.FrozenLedger
open Book Price PriceResourceSlots
open private resourceId part rank factor from TrialFrozenLedger180
attribute [local irreducible] PackedLedger.raw PackedLedger.integer intGram
set_option maxHeartbeats 4000000

theorem resource_gram_slot (u : Resource) (g h : Group) :
    intGram (ledger.factor u) g h = matrixGram PackedLedger.raw.matrices[14+PriceScalar.resourceIndex u]! g h := by
  have idx : resourceId u = PriceScalar.resourceIndex u := by cases u <;> rfl
  calc _ = matrixGram PackedLedger.raw.matrices[14+resourceId u]! g h := by
             apply byEntries
             · rfl
             · intro a j; rfl
       _ = _ := congrArg (fun i : Nat => matrixGram PackedLedger.raw.matrices[14+i]! g h) idx
end PrimeGap180.FrozenLedger

namespace PrimeGap180.PriceResourceSlots
open Book Price
attribute [local irreducible] PackedLedger.raw PackedLedger.integer intGram PriceFactorSource.factorShapes

theorem resource (bound : Bound) (u : Resource) (g : Group) :
    (PriceValues.resource g.val (PriceScalar.resourceIndex u):Int) = intGram (FrozenLedger.ledger.factor u) g g := by
  rw [FrozenLedger.resource_gram_slot, bound u]
  exact PriceResourceRows.resource_grams u g

theorem endpoints (bound : Bound)
    (event : ∀ (e : Book.Event) (g : Group), (PriceValues.event g.val (PriceScalar.eventIndex e):Int) =
      intGram (FrozenLedger.ledger.negative e) g g + intDeficit (intRemainder (FrozenLedger.ledger.remainder e)
        (FrozenLedger.ledger.positive e) (FrozenLedger.ledger.negative e)) g) : FrozenLedger.Endpoints :=
  PriceGainRows.endpoints_of_grams (resource bound) event

#print axioms resource
#print axioms endpoints
end PrimeGap180.PriceResourceSlots
