import TrialPriceAffineScatter180
import TrialPriceFastAffine180
import Lean
import Batteries.Tactic.OpenPrivate

noncomputable section
namespace PrimeGap180.PriceAffineWord
open Book SourceAffine PriceAffineScatter

/-- The original signed machine words in a fixed physical affine channel. -/
def rows (k : Nat) : List Nat := (PriceFastAffine.rows k).map Prod.fst
def word (k g : Nat) := (Compact.pair k g).1

set_option maxRecDepth 131072 in
private theorem sizes : ∀ k : Fin 14, (rows k.val).length = 445 := by decide +kernel

set_option maxRecDepth 131072 in
private theorem widths : ∀ k : Fin 14, ((rows k.val).all (fun w => decide (w < 2^32704))) = true := by decide +kernel

private theorem original {k i : Nat} (inside : i < (rows k).length) : (rows k)[i] = word k i := by
  have h : i < (PriceFastAffine.rows k).length := by simpa only [rows,List.length_map] using inside
  calc
    (rows k)[i] = ((PriceFastAffine.rows k)[i]).1 := List.getElem_map Prod.fst
    _ = (((PriceFastAffine.rows k)[i]?).getD (0,0)).1 := by rw [List.getElem?_eq_getElem h]; rfl
    _ = word k i := rfl

theorem symmetry {flat : Nat} (k : Fin 14) (g h : Group)
    (binding : pack 32768 (rows k.val) = flat) (ok : passed flat (word k.val g.val) g.val) :
    entry (word k.val h.val) g.val = entry (word k.val g.val) h.val := by
  have gi : g.val < (rows k.val).length := by rw [sizes k];exact g.isLt
  have hi : h.val < (rows k.val).length := by rw [sizes k];exact h.isLt
  have bounds (w : Nat) (hw : w∈rows k.val) : w < 2^32704 :=
    of_decide_eq_true ((List.all_eq_true.mp (widths k)) w hw)
  rw [←binding,←original gi] at ok
  simpa only [original gi, original hi] using extracts bounds g.isLt h.isLt gi hi ok

def encode : Nat → Nat → Int
  | 0,_ => 0
  | n+1,w => entry w 0 + PriceRows.base*encode n (w >>> 64)

private theorem next_entry (w i : Nat) : entry (w >>> 64) i = entry w (i+1) := by
  unfold entry lane
  rw [←Nat.shiftRight_add,show 64+64*i=64*(i+1) by omega]

theorem encode_eq (w n : Nat) : PriceRows.horner PriceRows.base (List.ofFn (fun h : Fin n => entry w h.val)) = encode n w := by
  induction n generalizing w with
  | zero => rfl
  | succ n ih =>
    rw [List.ofFn_succ,PriceRows.horner,encode,←ih]
    congr 2
    apply congrArg (PriceRows.horner PriceRows.base)
    apply congrArg List.ofFn
    funext i
    exact (next_entry w i.val).symm

/-- A checked 445-position word identity allows the full signed row to be
calculated from just one original physical row word. -/
theorem affine_eq (g : Group) (k : Book.Row) (flat : Nat)
    (binding : pack 32768 (rows (FrozenGuards.code k)) = flat)
    (ok : passed flat (word (FrozenGuards.code k) g.val) g.val) :
    PriceRows.affine g k = encode 445 (word (FrozenGuards.code k) g.val) := by
  have channel : FrozenGuards.code k < 14 := by cases k <;> simp [FrozenGuards.code] <;> omega
  let index : Fin 14 := ⟨_,channel⟩
  rw [←encode_eq]
  apply congrArg (PriceRows.horner PriceRows.base)
  apply congrArg List.ofFn
  funext h
  change entry (word index.val (min g.val h.val)) (max g.val h.val) = _
  by_cases le : g.val ≤ h.val
  · rw [min_eq_left le,max_eq_right le]
  · have rev : h.val ≤ g.val := by omega
    rw [min_eq_right rev,max_eq_left rev]
    exact symmetry index g h binding ok

open Lean Elab Command
open private words from TrialSourceAffineCompactData180
private def entries (e : Expr) : CommandElabM (Array Expr) := do
  let mut xs := e
  let mut a := #[]
  while xs.isAppOfArity ``List.cons 3 do a := a.push xs.appFn!.appArg!; xs := xs.appArg!
  unless xs.isAppOfArity ``List.nil 1 do throwError "expected a physical list"
  return a

/-- Propose the padded whole matrix. Each channel module separately proves
its equality to `pack` of all original physical rows by kernel reduction. -/
elab "declareAffineFlat" c:num : command => do
  let k := c.getNat
  unless k<14 do throwError "channel outside the physical archive"
  let some (.defnInfo d) := (←getEnv).find? ``words | throwError "missing original affine words"
  let channels ← entries d.value
  let channel ← entries (channels[k]!)
  unless channel.size==445 do throwError "expected 445 original rows"
  let mut flat := 0
  for p in channel.reverse do
    unless p.isAppOfArity ``Prod.mk 4 do throwError "expected original signed word and exclusion mask"
    let some w ← liftTermElabM (Meta.getNatValue? p.getAppArgs[2]!) | throwError "expected original signed numeral"
    flat := w ||| (flat <<< 32768)
  let nm := (←getCurrNamespace) ++ `flat
  liftCoreM <| addDecl (.defnDecl {name:=nm,levelParams:=[],type:=mkConst ``Nat,value:=toExpr flat,hints:=.regular 1,safety:=.safe})

#print axioms symmetry
#print axioms affine_eq
end PrimeGap180.PriceAffineWord
