import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G244
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 244

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G244

namespace PrimeGap180.PriceIsolatedGroup.G249
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 249

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G249

namespace PrimeGap180.PriceIsolatedGroup.G254
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 254

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G254

namespace PrimeGap180.PriceIsolatedGroup.G259
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 259

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G259
