import TrialSignedGauge180

/-! Collect the exact reference-gauge costs in the two physical moments,
then compare an archived price using its two verified endpoints. -/
noncomputable section
open scoped Classical BigOperators Topology
open Filter MeasureTheory PrimeGap186 PrimeGap182Analytic
namespace PrimeGap180.Sector

theorem collect_group_charge {S G : Type*} [Fintype S] [Fintype G]
    (owner : S → G) (ref w : G → ℝ) (v : S → ℝ) :
    (∑ g, w g*gaugeCost owner ref v g) = ∑ s, w (owner s)/ref (owner s)*v s := by
  trans ∑ g, (w g/ref g) * (∑ s with owner s = g, v s)
  · apply Finset.sum_congr rfl
    intro g _
    dsimp only [gaugeCost]
    ring
  · simp only [Finset.mul_sum]
    calc
      _ = ∑ g : G, ∑ s with owner s = g, (w (owner s)/ref (owner s))*v s := by
        apply Finset.sum_congr rfl
        intro g _
        apply Finset.sum_congr rfl
        intro s hs
        rw [(Finset.mem_filter.mp hs).2]
      _ = _ := Finset.sum_fiberwise_of_maps_to (fun _ _ => Finset.mem_univ _) _

/-- R may include signed earnings, nonpositive resource and residual
charges, and the objective-floor charge; the profile's two moments are
arbitrary. Thus this includes all terms of the frozen producer together. -/
theorem collect_book {S G R : Type*} [Fintype S] [Fintype G] [Fintype R]
    (owner : S → G) (ref : G → ℝ) (w : R → G → ℝ)
    (base inv : R → S → ℝ) (E U : S → ℝ) :
    (∑ r, ∑ g, w r g * gaugeCost owner ref (fun s => base r s * E s + inv r s * U s) g) =
    ∑ s : S, (((∑ r, w r (owner s)*base r s)/ref (owner s))*E s +
         ((∑ r, w r (owner s)*inv r s)/ref (owner s))*U s) := by
  simp_rw [collect_group_charge]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro s _
  rw [Finset.sum_div,Finset.sum_div,Finset.sum_mul,Finset.sum_mul,←Finset.sum_add_distrib]
  exact Finset.sum_congr rfl fun r _ => by ring

theorem affine_moment_comparison {E U lo hi a b A B : ℝ} (nn : 0 ≤ E)
    (low : lo*E ≤ U) (high : U ≤ hi*E) (left : a+b*lo ≤ A+B*lo)
    (right : a+b*hi ≤ A+B*hi) : a*E+b*U ≤ A*E+B*U := by
  by_cases sign : 0 ≤ B-b
  · nlinarith only [mul_nonneg sign (sub_nonneg.mpr low),
      mul_nonneg (sub_nonneg.mpr left) nn]
  · have neg : 0 ≤ b-B := by linarith
    nlinarith only [mul_nonneg neg (sub_nonneg.mpr high),
      mul_nonneg (sub_nonneg.mpr right) nn]

private theorem price_integrable {m : ℕ} (a : Fin (m+2) → ℝ) (k : Fin 39)
    (F : Profile 39 m) (P : (Fin 38 → Band m) → Prop)
    (mf : Measurable (restrictFace k P F)) (bf : Bornology.IsBounded (Set.range F))
    (K : (Fin 38 → Band m) → ℝ) (mk : Measurable K) (C : ℝ) (cn : 0 ≤ C)
    (bk : ∀ y, P y → ‖K y‖ ≤ C) :
    Integrable (fun y => K y * (integralFace a k (restrictFace k P F) y)^2)
      (Measure.pi (fun _ => bandLaw a)) := by
  let _ := bandLaw_finite a
  let Z := restrictFace k P F
  let V := integralFace a k Z
  obtain ⟨M,hM,bound⟩ := bf.exists_pos_norm_le
  have z (t) : ‖Z t‖ ≤ M := by
    dsimp only [Z,restrictFace]
    split_ifs
    · exact bound _ ⟨t,rfl⟩
    · simpa using hM.le
  have v (y) : ‖V y‖ ≤ M*(bandLaw a).real Set.univ := norm_integral_le_of_norm_le_const
    (μ := bandLaw a) (Eventually.of_forall fun t => z (k.insertNth t y))
  have ins : Measurable (fun p : (Fin 38 → Band m) × Band m =>
      k.insertNth (α := fun _ => Band m) p.2 p.1) := (continuous_snd.finInsertNth k continuous_fst).measurable
  have vm : Measurable V := ((mf.comp ins).stronglyMeasurable.integral_prod_right').measurable
  apply integrable_of_measurable_of_bounded_range _ _ (mk.mul (vm.pow_const 2))
  refine isBounded_iff_forall_norm_le.mpr ⟨C*(M*(bandLaw a).real Set.univ)^2,?_⟩
  rintro _ ⟨y,rfl⟩
  change ‖K y*(V y)^2‖ ≤ _
  by_cases hit : P y
  · rw [norm_mul,norm_pow]
    exact mul_le_mul (bk y hit) (pow_le_pow_left₀ (norm_nonneg _) (v y) 2) (by positivity) cn
  · have vz : V y = 0 := by simp only [V,Z,integralFace_restrict,hit,ite_false]
    rw [vz,zero_pow (by decide : 2≠0),mul_zero,norm_zero]
    positivity

/-- The two endpoints suffice for the continuum moments of the actual
sector. No division by its energy and no sign condition on the two price
slopes is required, including sectors whose energy vanishes. -/
theorem prime_moment_interval {m : ℕ} (a : Fin (m+2) → ℝ) (k : Fin 39)
    (P : (Fin 38 → Band m) → Prop) (F : Profile 39 m) {r : ℝ}
    (rr : r < 0.4999) (rad : ∀ y, P y → 0 ≤ retainedRadius y ∧ retainedRadius y ≤ r)
    (mf : Measurable (restrictFace k P F)) (bf : Bornology.IsBounded (Set.range F)) :
    let V := integralFace a k (restrictFace k P F)
    let E := ∫ y, (V y)^2 ∂Measure.pi (fun _ => bandLaw a)
    let U := ∫ y, primePrice (retainedRadius y)*(V y)^2 ∂Measure.pi (fun _ => bandLaw a)
    0 ≤ E ∧ primePrice 0*E ≤ U ∧ U ≤ primePrice r*E := by
  intro V E U
  have rp : 0 < 0.4999-r := sub_pos.mpr rr
  have pk : 0 ≤ primePrice r := (one_div_pos.mpr rp).le
  have bounds (y) (hit : P y) : primePrice 0 ≤ primePrice (retainedRadius y) ∧
      primePrice (retainedRadius y) ≤ primePrice r := by
    obtain ⟨qlo,qhi⟩ := rad y hit
    have qp : 0 < 0.4999-retainedRadius y := by linarith
    exact ⟨one_div_le_one_div_of_le qp (by linarith),one_div_le_one_div_of_le rp (by linarith)⟩
  have mrad : Continuous (@retainedRadius m) := by unfold retainedRadius; fun_prop
  have mp : Measurable (fun y : Fin 38 → Band m => primePrice (retainedRadius y)) :=
    measurable_const.div (measurable_const.sub mrad.measurable)
  have wi := price_integrable a k F P mf bf (fun y => primePrice (retainedRadius y)) mp (primePrice r) pk
    (fun y hit => by rw [Real.norm_eq_abs,abs_of_nonneg ((by norm_num [primePrice] : 0 ≤ primePrice 0).trans (bounds y hit).1)]; exact (bounds y hit).2)
  have ei : Integrable (fun y => (V y)^2) (Measure.pi (fun _ => bandLaw a)) := by
    simpa only [one_mul,V] using price_integrable a k F P mf bf (fun _ => 1) measurable_const 1 zero_le_one (fun _ _ => by norm_num)
  have pt (y) :
      primePrice 0*(V y)^2 ≤ primePrice (retainedRadius y)*(V y)^2 ∧
        primePrice (retainedRadius y)*(V y)^2 ≤ primePrice r*(V y)^2 := by
    by_cases hit : P y
    · exact ⟨mul_le_mul_of_nonneg_right (bounds y hit).1 (sq_nonneg _),
        mul_le_mul_of_nonneg_right (bounds y hit).2 (sq_nonneg _)⟩
    · have vz : V y = 0 := by simp only [V,integralFace_restrict,hit,ite_false]
      simp [vz]
  exact ⟨integral_nonneg fun _ => sq_nonneg _,
    by simpa only [integral_const_mul,U,E] using integral_mono (ei.const_mul (primePrice 0)) wi (fun y => (pt y).1),
    by simpa only [integral_const_mul,U,E] using integral_mono wi (ei.const_mul (primePrice r)) (fun y => (pt y).2)⟩

/-- The two exact rational tests at each frozen label suffice for its
integrated price in the 445-group book. R ranges over the signed earnings,
the 75 charges and the reference-rounding term. The only comparisons
between costs and prices in the hypotheses contain no trial energies. -/
theorem archived_sector_book {m : ℕ} {S R : Type*} [Fintype S] [Fintype R]
    (a : Fin (m+2) → ℝ) (k : Fin 39) (P : S → (Fin 38 → Band m) → Prop)
    (F : Profile 39 m) (owner : S → Fin 445) (ref : Fin 445 → ℝ)
    (w : R → Fin 445 → ℝ) (base inv : R → S → ℝ) (p0 p1 capR : S → ℝ)
    (bf : Bornology.IsBounded (Set.range F)) (mf : ∀ s, Measurable (restrictFace k (P s) F))
    (room : ∀ s, capR s < 0.4999)
    (rad : ∀ s y, P s y → 0 ≤ retainedRadius y ∧ retainedRadius y ≤ capR s) :
    let A := fun s => (∑ r, w r (owner s)*base r s)/ref (owner s)
    let B := fun s => (∑ r, w r (owner s)*inv r s)/ref (owner s)
    let V := fun s => integralFace a k (restrictFace k (P s) F)
    let E := fun s => ∫ y, (V s y)^2 ∂Measure.pi (fun _ => bandLaw a)
    let U := fun s => ∫ y, primePrice (retainedRadius y)*(V s y)^2 ∂Measure.pi (fun _ => bandLaw a)
    (∀ s, p0 s+p1 s*primePrice 0 ≤ A s+B s*primePrice 0) →
    (∀ s, p0 s+p1 s*primePrice (capR s) ≤ A s+B s*primePrice (capR s)) →
    (∑ s, (p0 s*E s+p1 s*U s)) ≤
      ∑ r, ∑ g, w r g*gaugeCost owner ref (fun s => base r s*E s + inv r s*U s) g := by
  intro A B V E U left right
  rw [collect_book]
  apply Finset.sum_le_sum
  intro s _
  obtain ⟨pos,lo,hi⟩ := prime_moment_interval a k (P s) F (room s) (rad s) (mf s) bf
  exact affine_moment_comparison pos lo hi (left s) (right s)

#print axioms archived_sector_book
#print axioms prime_moment_interval
#print axioms collect_book
#print axioms affine_moment_comparison
end PrimeGap180.Sector
