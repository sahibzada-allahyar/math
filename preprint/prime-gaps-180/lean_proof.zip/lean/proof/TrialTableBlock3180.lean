import TrialTableRow15180
import TrialTableRow16180
import TrialTableRow17180
import TrialTableRow18180
import TrialTableRow19180
namespace PrimeGap180.TablePrices
theorem block3 (i : Fin 5) : certified (blockIndex 3 i) := by
  fin_cases i
  · exact row15
  · exact row16
  · exact row17
  · exact row18
  · exact row19
#print axioms block3
end PrimeGap180.TablePrices
