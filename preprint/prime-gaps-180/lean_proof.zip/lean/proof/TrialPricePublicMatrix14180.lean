import TrialPriceSlotReflect180

namespace PrimeGap180.PriceBindings.M14
open PrimeGap180.PriceProjection PrimeGap180.PriceWordText
set_option maxRecDepth 24000000
set_option maxHeartbeats 400000000

declareSlotParts 14

theorem selected_public : PackedLedger.raw.matrices[28]! = (rank,whole) := by rfl
theorem selected_rows : PriceFactorSource.factorShapes[14]! = (rank,numerals.toArray) := by rfl
theorem group_count : numerals.length=445 := by decide +kernel

proveWholeText 14
proveSlotRows 14 0 445
collectSlotRows 14

theorem bound : PackedLedger.raw.matrices[28]! = PriceFactorSource.physical (PriceFactorSource.factorShapes[14]!) :=
  slot group_count selected_rows (selected_public.trans (congrArg (fun s : String => (rank,s)) whole_text)) all_rows

#print axioms bound
end PrimeGap180.PriceBindings.M14
