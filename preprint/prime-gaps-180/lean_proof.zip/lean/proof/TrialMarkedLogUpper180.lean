import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Tactic

namespace PrimeGap180.MarkedLogs

def upper (q : ℚ) (n : ℕ) :=
  let x := (q-1)/(q+1)
  2*((∑ i ∈ Finset.range n, x^(2*i+1)/((2*i+1:ℕ):ℚ)) +
        x^(2*n+1)/(1-x^2))

theorem log_upper (q : ℚ) (hq : 1 ≤ q) (n : ℕ) : Real.log (q:ℝ) ≤ (upper q n:ℝ) := by
  have q1 : (1:ℝ) ≤ q := by exact_mod_cast hq
  let x : ℝ := ((q:ℝ)-1)/(q+1)
  have hp : (0:ℝ)<q+1 := by linarith
  have hx : 0 ≤ x := div_nonneg (by linarith) hp.le
  have hx' : x < 1 := (div_lt_one hp).2 (by linarith)
  have eq : (1+x)/(1-x) = (q:ℝ) := by
    apply (div_eq_iff (by linarith : (1:ℝ)-x ≠ 0)).2
    dsimp [x]; field_simp; ring
  have H := Real.log_div_le_sum_range_add hx hx' n
  rw [eq] at H
  unfold upper
  push_cast
  dsimp [x] at H
  linarith only [H]

#print axioms log_upper
end PrimeGap180.MarkedLogs
