import Mathlib.Data.Nat.Basic

/-! Enumerate sorted five-bin configurations with their two largest entries
first. The sum condition leaves at most six final entries. -/
namespace PrimeGap180.CoverEnumeration

def scan (p : ℕ → Bool) : ℕ → ℕ → Bool
  | 0, _ => true
  | n+1, i => p i && scan p n (i+1)

def within (lo hi : ℕ) (p : ℕ → Bool) := scan p (hi+1-lo) lo

private theorem scan_at {p : ℕ → Bool} {n lo i : ℕ}
    (h : scan p n lo = true) (left : lo ≤ i) (right : i < lo+n) : p i = true := by
  induction n generalizing lo with
  | zero => omega
  | succ n ih =>
    have hh := Bool.and_eq_true_iff.mp h
    by_cases e : lo=i
    · simpa only [e] using hh.1
    · exact ih hh.2 (by omega) (by omega)

theorem within_at {p : ℕ → Bool} {lo hi i : ℕ} (h : within lo hi p = true)
    (l : lo ≤ i) (r : i ≤ hi) : p i = true :=
  scan_at h l (by omega)

def digit (col i : ℕ) := (col >>> (36*i)) % 68719476736

def band (inc : Bool) (cols : ℕ → ℕ) (d : ℕ) : Bool :=
  let D := cols d
  within d (min 71 (108-d)) fun e =>
    if inc = true ∧ d+e < 103 then true else
    let E := cols e
    let de := digit E d
    within ((211-d-e+2)/3) d fun c =>
      let C := cols c
      let top := de+digit D c+digit E c
      within ((211-d-e-c+1)/2) c fun b =>
        let B := cols b
        let six := top+digit C b+digit D b+digit E b
        within (211-d-e-c-b) (min b (216-d-e-c-b)) fun a =>
          decide (24000000000 ≤ six+digit B a+digit C a+digit D a+digit E a)

theorem band_sound {inc : Bool} {cols : ℕ → ℕ} {a b c d e : ℕ}
    (check : band inc cols d = true) (ab : a ≤ b) (bc : b ≤ c) (cd : c ≤ d) (de : d ≤ e)
    (be : e ≤ 71) (lower : 211 ≤ a+b+c+d+e) (upper : a+b+c+d+e ≤ 216)
    (pair : d+e ≤ 108) (incPair : inc = true → 103 ≤ d+e) :
    24000000000 ≤ digit (cols e) d+digit (cols d) c+digit (cols e) c+
      digit (cols c) b+digit (cols d) b+digit (cols e) b+
      digit (cols b) a+digit (cols c) a+digit (cols d) a+digit (cols e) a := by
  unfold band at check
  dsimp only at check
  have takeE := within_at check de (show e ≤ min 71 (108-d) by omega)
  have branch : ¬(inc = true ∧ d+e < 103) := by intro h; have := incPair h.1; omega
  simp only [if_neg branch] at takeE
  have takeC := within_at takeE (show (211-d-e+2)/3 ≤ c by omega) cd
  have takeB := within_at takeC (show (211-d-e-c+1)/2 ≤ b by omega) bc
  have takeA := within_at takeB (show 211-d-e-c-b ≤ a by omega) (show a ≤ min b (216-d-e-c-b) by omega)
  exact of_decide_eq_true takeA

#print axioms band_sound
end PrimeGap180.CoverEnumeration
