import TrialDensityRemainder180

noncomputable section
open MeasureTheory Set
open scoped BigOperators ENNReal
namespace PrimeGap180.DensitySimplex

def threeDen (z : Fin 2 → ℝ) : ℝ :=
  (1-2*z 0-z 1)*(1+z 0-z 1)*(1+z 0+2*z 1)

private def threeNumerator (v w u : ℝ) : ℝ :=
  (40*v+34*w+34*u)*(40*v+43*w+34*u)*(40*v+43*w+52*u)

private theorem bounds_three (v w u : ℝ) (hv : 0 ≤ v) (hw : 0 ≤ w) (hu : 0 ≤ u) :
    15*(40*(v+w+u))^3 ≤ 16*threeNumerator v w u ∧
    16*threeNumerator v w u ≤ 17*(40*(v+w+u))^3 := by
  constructor <;> apply sub_nonneg.mp <;> unfold threeNumerator <;> ring_nf <;> positivity

theorem threeDen_error {a c : ℝ} (cap : 1-3*c ≤ 3/20) (z : Fin 2 → ℝ) (hz : polygon3 a c z) :
    |1-threeDen z| ≤ 1/16 := by
  let w := 40*z 0/3
  let u := 20*z 1/3
  let v := 1-w-u
  have hw : 0 ≤ w := by dsimp [w]; linarith [hz.1]
  have hu : 0 ≤ u := by dsimp [u]; linarith [hz.2.1]
  have hv : 0 ≤ v := by dsimp [v,w,u]; linarith [hz.2.2.1]
  obtain ⟨l,h⟩ := bounds_three v w u hv hw hu
  have sum : v+w+u=1 := by dsimp [v]; ring
  rw [sum] at l h
  have convert : threeNumerator v w u=40^3*threeDen z := by
    unfold threeNumerator threeDen
    dsimp [v,w,u]
    ring
  rw [convert] at l h
  rw [abs_le]
  constructor <;> linarith

theorem three_kernel (z : Fin 2 → ℝ) : kernel (sites3 z) = 27*(threeDen z)⁻¹ := by
  have prod : threeDen z = 27*(∏ i, sites3 z i)*LiteralDensity.residual (sites3 z) := by
    unfold threeDen sites3 LiteralDensity.residual
    norm_num [Fin.prod_univ_two, Fin.sum_univ_two]
    ring
  rw [prod]
  simp only [kernel, mul_inv_rev, Finset.prod_inv_distrib]
  ring

def threePolynomial (z : Fin 2 → ℝ) : ℝ := ∑ j ∈ Finset.range 11, (1-threeDen z)^j

theorem three_polynomial_continuous : Continuous threePolynomial := by
  unfold threePolynomial threeDen
  fun_prop

private theorem polygon_in_simplex {a c : ℝ} (h : 1-3*c ≤ 3/20) :
    {z | polygon3 a c z} ⊆ region 2 (3/20) := by
  intro z hz
  refine ⟨?_, ?_⟩
  · simpa [Fin.forall_fin_succ] using And.intro hz.1 hz.2.1
  · rw [Fin.sum_univ_two]
    linarith [hz.1,hz.2.2.1]

def threeApprox (a c : ℝ) : ℝ := 18*∫ z in {z | polygon3 a c z},threePolynomial z

theorem three_loss_error {a c : ℝ} (cap : 1-3*c ≤ 3/20) :
    |2*Terminal.threeIntegral a c-threeApprox a c| ≤ 2/10^14 := by
  let S := {z | polygon3 a c z}
  have subset : S ⊆ region 2 (3/20) := polygon_in_simplex cap
  have box : region 2 (3/20) ⊆ Icc (0 : Fin 2 → ℝ) (fun _ => 3/20) := by
    intro x hx
    exact ⟨fun i => (hx.1 i).le,fun i => (Finset.single_le_sum (f:=x)
      (fun j _ => (hx.1 j).le) (Finset.mem_univ i)).trans hx.2.le⟩
  have fin : volume (region 2 (3/20)) < ∞ := measure_lt_top_mono box isCompact_Icc.measure_lt_top
  have small : volume S < ∞ := measure_lt_top_mono subset fin
  have ms : MeasurableSet S := by unfold S polygon3; measurability
  have cont : Continuous threeDen := by unfold threeDen; fun_prop
  have hi : IntegrableOn (fun z => (threeDen z)⁻¹) S := by
    have hc : IntegrableOn (fun _ : Fin 2 → ℝ => (16/15:ℝ)) S := integrableOn_const small.ne
    apply hc.mono' cont.measurable.inv.aestronglyMeasurable
    filter_upwards [ae_restrict_mem (μ := volume) ms] with z hz
    have low := (abs_le.mp (threeDen_error cap z hz)).2
    have pos : 0 < threeDen z := by linarith
    change ‖(threeDen z)⁻¹‖ ≤ 16/15
    rw [Real.norm_eq_abs,abs_of_pos (inv_pos.mpr pos)]
    apply (inv_anti₀ (by norm_num : (0:ℝ)<15/16) (by linarith : 15/16 ≤ threeDen z)).trans
    norm_num
  have hp : IntegrableOn threePolynomial S :=
    (three_polynomial_continuous.continuousOn.integrableOn_compact isCompact_Icc).mono_set
      (subset.trans box)
  have vol : volume.real S ≤ (3/20:ℝ)^2/2 := by
    have bound := ENNReal.toReal_mono fin.ne (measure_mono subset (μ := volume))
    change volume.real S ≤ volume.real (region 2 (3/20)) at bound
    rw [simplex_volume 2 (3/20) (by norm_num)] at bound
    simpa [Nat.factorial] using bound
  have err : |(∫ z in S, (threeDen z)⁻¹)-(∫ z in S,threePolynomial z)| ≤
      ((1/16:ℝ)^11/(1-1/16))*volume.real S := by
    rw [← integral_sub hi hp,← Real.norm_eq_abs]
    apply norm_setIntegral_le_of_norm_le_const small
    intro z hz
    exact reciprocal_error _ _ 11 (by norm_num) (threeDen_error cap z hz)
  have main : 2*Terminal.threeIntegral a c = 18*(∫ z in S, (threeDen z)⁻¹) := by
    rw [three_integral]; simp_rw [three_kernel]
    rw [integral_const_mul]
    dsimp [S]; ring
  rw [main,threeApprox]
  change |18*(∫ z in S,(threeDen z)⁻¹)-18*(∫ z in S,threePolynomial z)| ≤ _
  rw [← mul_sub,abs_mul,abs_of_pos (by norm_num : (0:ℝ)<18)]
  linarith

#print axioms threeDen_error
#print axioms three_loss_error
end PrimeGap180.DensitySimplex
