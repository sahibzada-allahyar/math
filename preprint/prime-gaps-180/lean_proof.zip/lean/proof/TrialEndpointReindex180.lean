import TrialEndpointPhysical180
import TrialEndpointTriangle180

/-! The legal two-endpoint numerator and the independent triangle
denominator on each retained fibre of the sampled trial. -/
noncomputable section
open scoped BigOperators Classical Topology
open MeasureTheory PrimeGap186 PrimeGap180.Sector PrimeGap180.EndpointPhysical
set_option maxHeartbeats 1600000
namespace PrimeGap180.EndpointReindex

abbrev last := Fin.last 38
def interior {E : Type*} (v : Fin 39 → E) : Fin 37 → E := Fin.init (Fin.tail v)

theorem join_map {E D : Type*} (f : E → D) (r : Fin 37 → E) (a b : E) :
    (fun k => f (join r a b k)) = join (fun k => f (r k)) (f a) (f b) := by
  change f ∘ Fin.cons a (Fin.snoc r b) = _
  rw [Fin.comp_cons,Fin.comp_snoc]
  rfl

@[simp] theorem join_zero {E : Type*} (r : Fin 37 → E) (a b : E) : join r a b 0 = a := by simp [join]
@[simp] theorem join_last {E : Type*} (r : Fin 37 → E) (a b : E) : join r a b last = b := by
  change Fin.cons (α := fun _ => E) a (Fin.snoc (α := fun _ => E) r b) (Fin.last 37).succ = b
  rw [Fin.cons_succ,Fin.snoc_last]

@[simp] theorem interior_join {E : Type*} (r : Fin 37 → E) (a b : E) : interior (join r a b) = r := by
  simp [interior,join]

theorem any_join {E : Type*} (v : Fin 39 → E) : join (interior v) (v 0) (v last) = v := by
  unfold join interior
  change Fin.cons (v 0) (Fin.snoc (Fin.init (Fin.tail v)) (Fin.tail v (Fin.last 37))) = v
  rw [Fin.snoc_init_self,Fin.cons_self_tail]

@[simp] theorem retained_join (r : Fin 37 → ℕ) (a b : ℕ) :
    Endpoint.retained 0 last (join r a b) = join r 1 1 := by
  funext k
  refine Fin.cases (by simp [Endpoint.retained]) (fun j => ?_) k
  cases j using Fin.lastCases with
  | last => change (if last = 0 ∨ last = last then 1 else _) = join r 1 1 last; rw [ite_eq_left (Or.inr rfl),join_last]
  | cast j =>
    have ne : j.castSucc.succ ≠ last := by intro h; have h' := congrArg Fin.val h; simp [last] at h'; omega
    simp [Endpoint.retained,join,ne]

theorem saved_key (v : Fin 39 → ℕ) : Endpoint.retained 0 last v = join (interior v) 1 1 := by
  calc
    _ = Endpoint.retained 0 last (join (interior v) (v 0) (v last)) := by rw [any_join]
    _ = _ := retained_join _ _ _

theorem prod_join (r : Fin 37 → ℕ) (a b : ℕ) :
    (∏ j, join r a b j) = (∏ j, r j)*a*b := by
  unfold join
  rw [Fin.prod_cons,Fin.prod_snoc]
  ring

theorem harmonic_join (r : Fin 37 → ℕ) (a b : ℕ) :
    Endpoint.harmonic (join r a b) = Endpoint.harmonic r*(a.totient:ℝ)⁻¹*(b.totient:ℝ)⁻¹ := by
  unfold Endpoint.harmonic
  rw [Finset.prod_congr rfl (fun k _ => congrFun (join_map (fun n : ℕ => (n.totient:ℝ)) r a b) k)]
  unfold join
  rw [Fin.prod_cons,Fin.prod_snoc]
  simp [div_eq_mul_inv,mul_comm,mul_left_comm]

def domain (d : ℕ) (Q : Finset ℕ) := Fintype.piFinset (fun _ : Fin d => Q)

theorem sum_join (Q : Finset ℕ) (f : (Fin 39 → ℕ) → ℝ) :
    (∑ v ∈ domain 39 Q, f v) = ∑ r ∈ domain 37 Q, ∑ a ∈ Q, ∑ b ∈ Q, f (join r a b) := by
  have hs : domain 39 Q = (Q ×ˢ domain 38 Q).map (Fin.consEquiv (fun _ : Fin 39 => ℕ)).toEmbedding := by
    have ht : Fin.tail (fun _ : Fin 39 => Q) = (fun _ : Fin 38 => Q) := rfl
    simpa only [domain,Finset.filter_true,ht] using Finset.filter_piFinset_eq_map_consEquiv
      (fun _ : Fin 39 => Q) (fun _ : Fin 38 → ℕ => True)
  rw [hs,Finset.sum_map,Finset.sum_product]
  simp only [Equiv.toEmbedding_apply]
  change (∑ a ∈ Q, ∑ v ∈ Fintype.piFinset (fun _ : Fin 38 => Q), f (Fin.cons a v)) = _
  simp_rw [sum_pi_snoc Q (fun v : Fin 38 → ℕ => f (Fin.cons _ v))]
  rw [Finset.sum_comm]
  rfl

private theorem source_fibre {S T : Finset (Fin 39 → ℕ)} (y : (Fin 39 → ℕ) →₀ ℝ)
    (hy : y.support ⊆ T) (hs : y.support ⊆ S) (r : Fin 37 → ℕ) :
    Endpoint.integral T 0 last y (join r 1 1) =
      ∑ t ∈ S, if Endpoint.retained 0 last t = join r 1 1 then y t * Endpoint.harmonic t else 0 := by
  let f := fun t : Fin 39 → ℕ => fun c : ℝ => if Endpoint.retained 0 last t = join r 1 1 then
    c*Endpoint.harmonic t else 0
  have zero (t) : f t 0 = 0 := by simp [f]
  rw [Endpoint.integral,Endpoint.members,Finset.sum_filter]
  exact (y.sum_of_support_subset hy f (fun t _ => zero t)).symm.trans (y.sum_of_support_subset hs f (fun t _ => zero t))

theorem sampled_numerator {m : ℕ} (H : Finset ℕ) {x : ℝ} (a : Fin (m+2) → ℝ) (F : Profile 39 m)
    (T : Finset (Fin 39 → ℕ)) (support : (sample H a F x).support ⊆ T) (r : Fin 37 → ℕ) :
    let Q := (carrier H x).divisors
    Endpoint.integral T 0 last (sample H a F x) (join r 1 1) =
      if r ∈ domain 37 Q then (Endpoint.harmonic r/norm H x^39) * EndpointMoment.twice Q
        (fun rr p q => F (join (fun j => stats a x (rr j)) (stats a x p) (stats a x q))) r else 0 := by
  intro Q
  let y := sample H a F x
  have ins : y.support ⊆ domain 39 Q := fun v hv => (Finset.mem_filter.mp (sample_witness hv).1).1
  rw [source_fibre y support ins r,sum_join]
  have same (t : Fin 37 → ℕ) : join t (1:ℕ) 1 = join r 1 1 ↔ t = r :=
    ⟨fun eq => by simpa using congrArg interior eq,fun eq => congrArg (fun rr => join rr 1 1) eq⟩
  simp_rw [retained_join,same,Finset.sum_ite_irrel,Finset.sum_const_zero,Finset.sum_ite_eq']
  split_ifs with rin
  · unfold EndpointMoment.twice
    change _ = _*(∑ p ∈ Q, (p.totient:ℝ)⁻¹*∑ q ∈ Q,(q.totient:ℝ)⁻¹*
      (if EndpointMoment.legal r p q then _ else 0))
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro p hp
    rw [Finset.mul_sum,Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro q hq
    have mem : join r p q ∈ domain 39 Q := by
      apply Fintype.mem_piFinset.mpr
      intro k
      refine Fin.cases (by simpa using hp) (fun l => ?_) k
      cases l using Fin.lastCases with
      | last => change join r p q last ∈ Q; rwa [join_last]
      | cast l => simpa [join] using Fintype.mem_piFinset.mp rin l
    have sf : Squarefree (∏ j, join r p q j) ↔ EndpointMoment.legal r p q := by rw [prod_join]; rfl
    have root : join r p q ∈ roots 39 H x ↔ EndpointMoment.legal r p q := by
      change join r p q ∈ (domain 39 Q).filter _ ↔ _
      rw [Finset.mem_filter,sf,and_iff_right mem]
    simp only [y,sample,Finsupp.finsetSum_apply,Finsupp.single_apply,Finset.sum_ite_eq',root,join_map,harmonic_join]
    split_ifs <;> ring
  · rfl

private theorem forall_join {E : Type*} {P : E → Prop} {r : Fin 37 → E} {a b : E}
    (hr : ∀ j, P (r j)) (ha : P a) (hb : P b) : ∀ j, P (join r a b j) := by
  intro k
  refine Fin.cases (by simpa using ha) (fun l => ?_) k
  cases l using Fin.lastCases with
  | last => change P (join r a b last); simpa using hb
  | cast l => simpa [join] using hr l

private theorem mem_unrestricted {W L : ℕ} (r : Fin 39 → ℕ)
    (each : ∀ j, Squarefree (r j) ∧ (r j).Coprime W) (cut : (∏ j, r j) ≤ L) :
    r ∈ unrestricted W L := by
  refine Finset.mem_filter.mpr ⟨Fintype.mem_piFinset.mpr (fun j => Finset.mem_Icc.mpr ⟨?_,?_⟩),each,cut⟩
  · exact Nat.one_le_iff_ne_zero.mpr (each j).1.ne_zero
  · exact (Nat.le_of_dvd (Finset.prod_pos fun k _ => Nat.pos_of_ne_zero (each k).1.ne_zero)
      (Finset.dvd_prod_of_mem r (Finset.mem_univ j))).trans cut

/-- Independent endpoint pairs in the triangle inject into this exact
fibre even if the endpoint pair shares a prime with an interior site. -/
theorem triangle_in_fibre (H : Finset ℕ) {x q : ℝ} (hx : 1 < x)
    (r : Fin 37 → ℕ) (each : ∀ j, Squarefree (r j) ∧ (r j).Coprime (presievingModulus H x))
    (radius : ((∏ j, r j : ℕ):ℝ) = x^q) :
    (Endpoint.harmonic r*norm H x^2)*EndpointVolume.triangle H x (wide-q) ≤
      Endpoint.volume (unrestricted (presievingModulus H x) ⌊x^wide⌋₊) 0 last (join r 1 1) := by
  let W := presievingModulus H x
  let U := unrestricted W ⌊x^wide⌋₊
  let D := ((EndpointVolume.members x (wide-q)) ×ˢ (EndpointVolume.members x (wide-q))).filter
    fun ab => (ab.1:ℝ)*ab.2 ≤ x^(wide-q)
  let ok := fun n : ℕ => Squarefree n ∧ n.Coprime W
  let E := D.filter fun ab => ok ab.1 ∧ ok ab.2
  let f := fun ab : ℕ × ℕ => (Endpoint.harmonic r*norm H x^2)*
    (EndpointVolume.weight H x ab.1*EndpointVolume.weight H x ab.2)
  have bp : 0 < norm H x := PrimeGap182.Selberg.fragmentNormalization_pos H x (scale x)
    (Real.one_lt_rpow hx (by norm_num [rho]))
  have inj : Function.Injective (fun ab : ℕ × ℕ => join r ab.1 ab.2) := by
    intro ab cd he
    exact Prod.ext (by simpa using congrFun he 0) (by simpa using congrFun he last)
  unfold EndpointVolume.triangle
  rw [Finset.mul_sum]
  change (∑ ab ∈ D, f ab) ≤ ∑ z ∈ Endpoint.members U 0 last (join r 1 1), Endpoint.harmonic z
  calc
    _ = ∑ ab ∈ E, f ab := by
      symm
      apply Finset.sum_subset (Finset.filter_subset _ _)
      intro ab hD outside
      have bad : ¬ (ok ab.1 ∧ ok ab.2) := fun h => outside (Finset.mem_filter.mpr ⟨hD,h⟩)
      by_cases l : ok ab.1
      · have h : ¬ok ab.2 := fun hh => bad ⟨l,hh⟩
        change ¬ (Squarefree ab.2 ∧ ab.2.Coprime (presievingModulus H x)) at h
        simp [f,EndpointVolume.weight,h]
      · have h : ¬ (Squarefree ab.1 ∧ ab.1.Coprime (presievingModulus H x)) := l
        simp [f,EndpointVolume.weight,h]
    _ ≤ _ := by
      apply Finset.sum_le_sum_of_injOn (fun ab : ℕ × ℕ => join r ab.1 ab.2) inj.injOn
      · rintro z hz
        obtain ⟨ab,mem,rfl⟩ := Finset.mem_image.mp hz
        obtain ⟨hD,hp,hq⟩ := Finset.mem_filter.mp mem
        have fits := (Finset.mem_filter.mp hD).2
        refine Finset.mem_filter.mpr ⟨mem_unrestricted _ (forall_join each hp hq) ?_,retained_join _ _ _⟩
        rw [prod_join]
        apply Nat.le_floor
        push_cast
        rw [Nat.cast_prod] at radius
        rw [mul_assoc,radius]
        apply (mul_le_mul_of_nonneg_left fits (Real.rpow_nonneg (zero_lt_one.trans hx).le _)).trans
        rw [←Real.rpow_add (zero_lt_one.trans hx),show q+(wide-q)=wide by ring]
      · intro ab mem
        obtain ⟨_,hp,hq⟩ := Finset.mem_filter.mp mem
        change Squarefree ab.1 ∧ ab.1.Coprime (presievingModulus H x) at hp
        change Squarefree ab.2 ∧ ab.2.Coprime (presievingModulus H x) at hq
        apply le_of_eq
        simp only [f,EndpointVolume.weight,ite_eq_left hp,ite_eq_left hq,harmonic_join]
        field_simp
      · intro z _ _
        exact one_div_nonneg.mpr (Finset.prod_nonneg fun j _ => Nat.cast_nonneg ((z j).totient))

def doubleRoot {m : ℕ} (H : Finset ℕ) (a : Fin (m+2) → ℝ) (F : Profile 39 m) (x : ℝ) (r : Fin 37 → ℕ) :=
  EndpointMoment.twice (carrier H x).divisors
    (fun rr p q => F (join (fun j => stats a x (rr j)) (stats a x p) (stats a x q))) r

def radius {m : ℕ} (a : Fin (m+2) → ℝ) (x : ℝ) (r : Fin 37 → ℕ) := rho*∑ j, ∑ k, stats a x (r j) k

theorem double_support {m : ℕ} (H : Finset ℕ) (a : Fin (m+2) → ℝ) (F : Profile 39 m)
    (room : ∀ y, F y ≠ 0 → rho*(∑ j, ∑ k, y j k) ≤ radiusCap) {x : ℝ} (r : Fin 37 → ℕ)
    (hit : doubleRoot H a F x r ≠ 0) :
    Squarefree (∏ j, r j) ∧ radius a x r ∈ Set.Icc (0:ℝ) radiusCap := by
  change (∑ p ∈ (carrier H x).divisors, (p.totient:ℝ)⁻¹*∑ q ∈ (carrier H x).divisors, (q.totient:ℝ)⁻¹*
    (if EndpointMoment.legal r p q then F (join (fun j => stats a x (r j)) (stats a x p) (stats a x q)) else 0)) ≠ 0 at hit
  obtain ⟨p,_,hp⟩ := Finset.exists_ne_zero_of_sum_ne_zero hit
  obtain ⟨q,_,hq⟩ := Finset.exists_ne_zero_of_sum_ne_zero (mul_ne_zero_iff.mp hp).2
  obtain ⟨sq,nz⟩ := ite_ne_right_iff.mp (mul_ne_zero_iff.mp hq).2
  have whole := room _ nz
  have s (z : ℕ) : 0 ≤ ∑ k, stats a x z k := Finset.sum_nonneg fun k _ => NNReal.coe_nonneg _
  have p0 := s p
  have q0 := s q
  have v0 := Finset.sum_nonneg (s := Finset.univ) (fun j _ => s (r j))
  rw [Finset.sum_congr rfl (fun j _ => congrFun (join_map (fun v : Band m => ∑ k, v k)
    (fun j => stats a x (r j)) (stats a x p) (stats a x q)) j)] at whole
  change rho*(∑ j, Fin.cons _ (Fin.snoc _ _) j) ≤ radiusCap at whole
  rw [Fin.sum_cons,Fin.sum_snoc] at whole
  refine ⟨sq.squarefree_of_dvd ⟨p*q,by ring⟩,mul_nonneg (by norm_num [rho]) v0,?_⟩
  dsimp only [radius]
  apply le_trans _ whole
  apply mul_le_mul_of_nonneg_left _ (by norm_num [rho])
  linarith only [p0,q0]

private theorem physical_fibre_term {m : ℕ} (H : Finset ℕ) (a : Fin (m+2) → ℝ) (ha : StrictMono a)
    (first : a 0 = 0) (capLast : a (Fin.last (m+1)) = cap) (F : Profile 39 m)
    (room : ∀ y, F y ≠ 0 → rho*(∑ j, ∑ k, y j k) ≤ radiusCap)
    {x : ℝ} (hx : 1 < x) (triangle : ∀ q ∈ Set.Icc (0:ℝ) 0.2801,
      (ledger-q)^2/(2*rho^2) ≤ EndpointVolume.triangle H x (wide-q))
    (r : Fin 37 → ℕ) (rin : r ∈ domain 37 (carrier H x).divisors) :
    let W := presievingModulus H x
    let B := norm H x
    let T := Endpoint.legalRoots (Fin 39) W ⌊x^wide⌋₊
    let U := unrestricted W ⌊x^wide⌋₊
    let t := join r 1 1
    B^39*((Endpoint.integral T 0 last (sample H a F x) t)^2/Endpoint.volume U 0 last t) ≤
      (B^41)⁻¹*(Endpoint.harmonic r*(pairPrice (fun j => stats a x (r j))*(doubleRoot H a F x r)^2)) := by
  intro W B T U t
  have num := sampled_numerator H a F T (sampled_in_legal H hx a ha first capLast F room) r
  dsimp only at num
  rw [ite_eq_left rin] at num
  change Endpoint.integral T 0 last (sample H a F x) t = Endpoint.harmonic r/B^39*doubleRoot H a F x r at num
  rw [num]
  by_cases off : doubleRoot H a F x r = 0
  · simp [off]
  obtain ⟨sq,hq⟩ := double_support H a F room r off
  have actual := retained_product_radius hx a ha.monotone first capLast r sq (Fintype.mem_piFinset.mp rin)
  let q := radius a x r
  have unitPos : 0 < B := PrimeGap182.Selberg.fragmentNormalization_pos H x (scale x)
    (Real.one_lt_rpow hx (by norm_num [rho]))
  have e (j : Fin 37) := Fintype.mem_piFinset.mp rin j
  have hR : 1 ≤ (scale x)^cap := Real.one_le_rpow (Real.one_le_rpow hx.le (by norm_num [rho]))
    (by norm_num [cap,physicalCap,rho])
  have each j := (mem_fragment_divisors_iff W (scale x) cap hR (r j)).mp (e j)
  have hp : 0 < Endpoint.harmonic r := one_div_pos.mpr (Finset.prod_pos fun j _ => by
    exact_mod_cast Nat.totient_pos.mpr (Nat.pos_of_mem_divisors (e j)))
  have vr := triangle_in_fibre H hx r (fun j => ⟨(each j).1,(each j).2.1⟩) actual
  have grid := triangle q ⟨hq.1,hq.2.trans (by norm_num [radiusCap])⟩
  let z := ledger-q
  have hz : 0 < z := sub_pos.mpr (hq.2.trans_lt (by norm_num [radiusCap,ledger]))
  have rhoPos : 0 < rho := by norm_num [rho]
  have price : pairPrice (fun j => stats a x (r j)) = 2*rho^2/z^2 := by
    change 2*rho^2/(ledger-min radiusCap (max 0 q))^2 = _
    rw [max_eq_right hq.1,min_eq_right hq.2]
  have vol : Endpoint.harmonic r*B^2*(z^2/(2*rho^2)) ≤ Endpoint.volume U 0 last t :=
    (mul_le_mul_of_nonneg_left grid (mul_nonneg hp.le (sq_nonneg B))).trans vr
  rw [price]
  apply le_trans (mul_le_mul_of_nonneg_left
    (div_le_div_of_nonneg_left (sq_nonneg _) (by positivity : 0 < Endpoint.harmonic r*B^2*(z^2/(2*rho^2))) vol)
    (pow_pos unitPos 39).le)
  apply le_of_eq
  field_simp [hp.ne',hz.ne',unitPos.ne',rhoPos.ne']

theorem finite_price {m : ℕ} (H : Finset ℕ) (a : Fin (m+2) → ℝ) (ha : StrictMono a)
    (first : a 0 = 0) (capLast : a (Fin.last (m+1)) = cap) (F : Profile 39 m)
    (room : ∀ y, F y ≠ 0 → rho*(∑ j, ∑ k, y j k) ≤ radiusCap) :
    ∀ᶠ x : ℝ in Filter.atTop,
      let W := presievingModulus H x
      let B := norm H x
      let T := Endpoint.legalRoots (Fin 39) W ⌊x^wide⌋₊
      let U := unrestricted W ⌊x^wide⌋₊
      B^39*(∑ t ∈ T.image (Endpoint.retained 0 last), (Endpoint.integral T 0 last (sample H a F x) t)^2/
        Endpoint.volume U 0 last t) ≤ (B^41)⁻¹*EndpointMoment.cube (carrier H x).divisors (fun r =>
        pairPrice (fun j => stats a x (r j))*(doubleRoot H a F x r)^2) := by
  filter_upwards [EndpointVolume.physical_triangle_lower H, Filter.eventually_gt_atTop (1:ℝ)] with x ball hx
  intro W B T U
  let S := T.image (Endpoint.retained 0 last)
  let R := domain 37 (carrier H x).divisors
  let f := fun t => B^39*((Endpoint.integral T 0 last (sample H a F x) t)^2/Endpoint.volume U 0 last t)
  have key (t) (ht : t ∈ S) : join (interior t) 1 1 = t := by
    obtain ⟨v,_,rfl⟩ := Finset.mem_image.mp ht
    rw [saved_key,interior_join]
  rw [Finset.mul_sum,EndpointMoment.cube,Finset.mul_sum]
  change (∑ t ∈ S, f t) ≤ ∑ r ∈ R, (B^41)⁻¹*((∏ j, ((r j).totient:ℝ)⁻¹)*
    (pairPrice (fun j => stats a x (r j))*(doubleRoot H a F x r)^2))
  calc
    _ = ∑ t ∈ S.filter (fun t => interior t ∈ R), f t := by
      symm
      apply Finset.sum_subset (Finset.filter_subset _ _)
      intro t ht out
      have outside : interior t ∉ R := fun h => out (Finset.mem_filter.mpr ⟨ht,h⟩)
      have n := sampled_numerator H a F T (sampled_in_legal H hx a ha first capLast F room) (interior t)
      dsimp only at n
      change interior t ∉ domain 37 (carrier H x).divisors at outside
      rw [ite_eq_right outside,key _ ht] at n
      simp [f,n]
    _ ≤ _ := by
      apply Finset.sum_le_sum_of_injOn interior
      · intro t h u g eq
        exact (key t (Finset.mem_filter.mp h).1).symm.trans ((congrArg (fun v => join v 1 1) eq).trans
          (key u (Finset.mem_filter.mp g).1))
      · rintro r hr
        obtain ⟨t,mem,rfl⟩ := Finset.mem_image.mp hr
        exact (Finset.mem_filter.mp mem).2
      · intro t ht
        obtain ⟨mem,rin⟩ := Finset.mem_filter.mp ht
        have grid : ∀ q ∈ Set.Icc (0:ℝ) 0.2801, (ledger-q)^2/(2*rho^2) ≤ EndpointVolume.triangle H x (wide-q) := by
          simpa only [show ledger=(0.4999:ℝ) by norm_num [ledger], show wide=(0.49995:ℝ) by norm_num [wide]] using ball
        have term := physical_fibre_term H a ha first capLast F room hx grid (interior t) rin
        dsimp only at term
        simpa only [key t mem,Endpoint.harmonic,one_div,Finset.prod_inv_distrib,f,B,T,U,W] using term
      · intro r _ _
        have pp : 0 ≤ pairPrice (fun j => stats a x (r j)) := by unfold pairPrice; positivity
        have pos : 0 < B := PrimeGap182.Selberg.fragmentNormalization_pos H x (scale x)
          (Real.one_lt_rpow hx (by norm_num [rho]))
        exact mul_nonneg (inv_nonneg.mpr (pow_pos pos 41).le) (mul_nonneg (Finset.prod_nonneg fun j _ => inv_nonneg.mpr (Nat.cast_nonneg _)) (mul_nonneg pp (sq_nonneg _)))

/-- The simultaneous endpoint prime penalty in ordinary-mass units, for
the same full sampled weight and every admissible presieved progression. -/
theorem endpoint_same_profile {m : ℕ} (H : Finset ℕ) (hH : H.card = 39)
    (a : Fin (m+2) → ℝ) (ha : StrictMono a) (first : a 0 = 0) (capLast : a (Fin.last (m+1)) = cap)
    (F : Profile 39 m) (mf : Measurable F) (bf : Bornology.IsBounded (Set.range F))
    (cf : ∀ᵐ y ∂Measure.pi (fun _ : Fin 39 => bandLaw a), ContinuousAt F y)
    (room : ∀ y, F y ≠ 0 → rho*(∑ j, ∑ k, y j k) ≤ radiusCap) (ε : ℝ) (he : 0 < ε) :
    ∀ᶠ x : ℝ in Filter.atTop, ∀ b : ℕ,
      let W := presievingModulus H x
      let h := H.orderEmbOfFin hH
      (∑ n ∈ Finset.Icc ⌈x⌉₊ ⌊2*x⌋₊, if Nat.ModEq W n b ∧ (n+h 0).Prime ∧ (n+h last).Prime
        then (PrimeGap182Analytic.sampledSelbergRoot (sample H a F x) (fun k => n+h k))^2 else 0) ≤
        ((∫ r, pairPrice r*(∫ l, ∫ h, F (join r l h) ∂bandLaw a ∂bandLaw a)^2
          ∂Measure.pi fun _ : Fin 37 => bandLaw a) + ε)*(x/(W:ℝ)/norm H x^39) := by
  let E := ∫ r, pairPrice r*(∫ l, ∫ h, F (join r l h) ∂bandLaw a ∂bandLaw a)^2
    ∂Measure.pi fun _ : Fin 37 => bandLaw a
  let K := fun x => (norm H x^41)⁻¹*EndpointMoment.cube (carrier H x).divisors (fun r =>
    pairPrice (fun j => stats a x (r j))*(doubleRoot H a F x r)^2)
  have lim : Filter.Tendsto K Filter.atTop (𝓝 E) := physical_pair_limit H a ha first capLast F mf bf cf
  have conv := lim.eventually_le_const (show E < E+ε/2 by linarith only [he])
  filter_upwards [sampled_pair_unrestricted H hH a ha first capLast F bf room (half_pos he),
    finite_price H a ha first capLast F room,conv,Filter.eventually_gt_atTop (1:ℝ)] with x count bound near hx
  intro b W h
  let B := norm H x
  let C := x/(W:ℝ)/B^39
  let T := Endpoint.legalRoots (Fin 39) W ⌊x^wide⌋₊
  let U := unrestricted W ⌊x^wide⌋₊
  let S := ∑ t ∈ T.image (Endpoint.retained 0 last), (Endpoint.integral T 0 last (sample H a F x) t)^2 /
    Endpoint.volume U 0 last t
  have pos : 0 < B := PrimeGap182.Selberg.fragmentNormalization_pos H x (scale x)
    (Real.one_lt_rpow hx (by norm_num [rho]))
  have cn : 0 ≤ C := by dsimp [C]; positivity
  have factor : C*B^39 = x/(W:ℝ) := div_mul_cancel₀ _ (pow_ne_zero _ pos.ne')
  change B^39*S ≤ K x at bound
  apply (count b).trans
  change x/(W:ℝ)*S+(ε/2)*C ≤ (E+ε)*C
  calc
    _ = C*(B^39*S)+(ε/2)*C := by rw [←mul_assoc,factor]
    _ ≤ C*(E+ε/2)+(ε/2)*C := add_le_add (mul_le_mul_of_nonneg_left (bound.trans near) cn) le_rfl
    _ = _ := by ring

#print axioms endpoint_same_profile
#print axioms finite_price
#print axioms triangle_in_fibre
#print axioms sampled_numerator
end PrimeGap180.EndpointReindex
