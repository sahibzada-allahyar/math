import TrialMarkedBandBounds180
import TrialFrozenLedger180

namespace PrimeGap180.BandPrices
open MarkedLogs Book

noncomputable def classOf (s : Book.SectorId) : Fin 49 := ⟨PriceRadii.id s.val,(PriceRadii.classified _).1⟩

private theorem cast_cap (s : Book.SectorId) :
    (PriceRadii.classes[(classOf s).val]!:ℝ)/10000 = Book.capR s.val := by
  rw [PriceRadii.physical_cap,(PriceRadii.classified _).2]
  rfl

private theorem cast_hi (j : Fin 12) : (hiQ j:ℝ) = FiveMarks.top j := by
  norm_num [hiQ,top,D,FiveMarks.top]

private theorem cast_lo (j : Fin 12) : (loQ j:ℝ) = TripleAdjacent.lo j := by
  simp [loQ,low,D,TripleAdjacent.lo]
  ring

private theorem cast_lower (j : Fin 11) : (lowerQ j:ℝ) = EventBins.lower (FiveMarks.top j.succ) := by
  simp [lowerQ,EventBins.lower,cast_hi]

private theorem cast_z (c m : ℚ) (s : Book.SectorId) :
    (zQ c m (classOf s):ℝ) = min (c:ℝ) ((1-(m:ℝ))/2-Book.capR s.val)-0.0001 := by
  unfold zQ
  push_cast
  rw [cast_cap]
  norm_num

private theorem triple_formula (j : Fin 11) (s : Book.SectorId) :
    Book.tripleBandPrice j s =
    2*Real.log (argument j 0:ℝ)/(zQ (loQ j.succ) (loQ j.castSucc) (classOf s):ℝ) +
    2*Real.log (argument j 1:ℝ)/(zQ (loQ j.succ) (hiQ j.succ) (classOf s):ℝ) := by
  obtain ⟨_,_,aa,bb,_⟩ := ordered j
  rw [aa,bb,Book.tripleBandPrice,Fintype.sum_bool,cast_z,cast_z]
  simp only [Rat.cast_div,cast_lo,cast_hi]
  change 2*Real.log _*(1/_) + 2*Real.log _*(1/_) = _
  rw [add_comm]
  simp only [div_eq_mul_inv,one_mul]
  rfl

theorem triple (j : Fin 11) (s : Book.SectorId) :
    (Book.eventRow (.three j.succ)).price s ≤ FrozenLedger.ledger.eventKernel (.three j.succ) s := by
  change Book.tripleBandPrice j s ≤ _
  rw [triple_formula]
  obtain ⟨p,q,_⟩ := radii_positive j (classOf s)
  have h1 : (0:ℝ) < (zQ (loQ j.succ) (loQ j.castSucc) (classOf s):ℝ) := by exact_mod_cast p
  have h2 : (0:ℝ) < (zQ (loQ j.succ) (hiQ j.succ) (classOf s):ℝ) := by exact_mod_cast q
  apply le_trans (add_le_add (div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left (log_ceiling j 0) (by norm_num)) h1.le)
    (div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left (log_ceiling j 1) (by norm_num)) h2.le))
  have bound := (checked j (classOf s)).1
  unfold tripleQ at bound
  have eqn : (eventRatio (3+j.val) (classOf s):ℝ) = FrozenLedger.ledger.eventKernel (.three j.succ) s := by
    unfold eventRatio
    push_cast
    have idx : 3+j.val = 2+j.succ.val := by change 3+j.val = 2+(j.val+1); omega
    rw [idx]
    rfl
  rw [←eqn]
  exact_mod_cast bound

private theorem five_formula (j : Fin 11) (s : Book.SectorId) :
    Book.fiveBandPrice j s =
    24*(((hiQ j.succ:ℝ)-(hiQ j.castSucc:ℝ))*Real.log (argument j 2:ℝ)/(hiQ j.castSucc:ℝ))/
      (zQ (lowerQ j) (hiQ j.succ) (classOf s):ℝ) := by
  have h := (ordered j).2.2.2.2
  rw [h,cast_z]
  simp only [Rat.cast_div,Rat.cast_sub,cast_lower,cast_hi]
  change 24*((_-_)*Real.log _/_)*(1/_) = _
  simp only [div_eq_mul_inv,one_mul]
  rfl

theorem five (j : Fin 11) (s : Book.SectorId) :
    (Book.eventRow (.newFive j.succ)).price s ≤ FrozenLedger.ledger.eventKernel (.newFive j.succ) s := by
  change Book.fiveBandPrice j s ≤ _
  rw [five_formula]
  have pos : (0:ℝ)<(hiQ j.castSucc:ℝ) := by exact_mod_cast (ordered j).1
  have inc : (hiQ j.castSucc:ℝ) ≤ (hiQ j.succ:ℝ) := by exact_mod_cast (ordered j).2.1
  have zpos : (0:ℝ) < (zQ (lowerQ j) (hiQ j.succ) (classOf s):ℝ) := by
    exact_mod_cast (radii_positive j (classOf s)).2.2
  apply le_trans (div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left
    (div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left (log_ceiling j 2) (sub_nonneg.mpr inc)) pos.le)
    (by norm_num)) zpos.le)
  have eqn : (eventRatio (15+j.val) (classOf s):ℝ) = FrozenLedger.ledger.eventKernel (.newFive j.succ) s := by
    unfold eventRatio
    push_cast
    have idx : 15+j.val = 14+j.succ.val := by change 15+j.val = 14+(j.val+1); omega
    rw [idx]
    rfl
  rw [←eqn]
  have bound := (checked j (classOf s)).2
  unfold fiveQ at bound
  exact_mod_cast bound

#print axioms triple
#print axioms five
end PrimeGap180.BandPrices
