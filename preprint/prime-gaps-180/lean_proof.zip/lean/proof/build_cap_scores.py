"""Generate the Lean modules that discharge `CapMass.GroupScores` for one changing cap.

`build_cap36_scores.py` does this for cap 36 against `MassCap36Assembly`; this
generator does the same for caps 7, 8, 15, 23, 26, 30, 33 and 34 against the
cap-generic `CapMass.capMass` (`TrialCapMassAssembly180`), and delegates
`--cap 36` to `build_cap36_scores` so that the cap-36 modules stay byte-identical.

Module layout for cap `cc` with `n` windows (`n` = 21, 22, 21, 22, 22, 20, 19, 18):

* 74 word carriers `TrialCap{cc}WordEnd<LLLL>180` / `TrialCap{cc}WordAng<SS>180`,
  read with `capWord180%` (`TrialCapWordReader180`) from the bank's `.bin` files.
* `TrialCap{cc}ScoreBase180`: window starts, lengths, spline pieces and field
  flags, and the fine classes and cutoffs of cap `cc` and of the next cap.
* 18 row modules `TrialCap{cc}RowsNow<p>180` / `TrialCap{cc}RowsNext<p>180` and
  `TrialCap{cc}RowTable180`: `FrozenData.rowQ F p s k` for the fine class `F` of
  the cap and of the next cap, one `decide +kernel` per ten-entry chunk (the
  cap-36 design of `build_cap36_scores`, which keeps the kernel below 10 GB).
* `7n` radial modules `TrialCap{cc}Radial<ww><i>180`: the 30 `splineQ` values at
  one collocation tick (one declaration) and the 99 coefficients of each live
  field by literal arithmetic (`CapScoreRules.coeffWith`, one declaration per
  field), then the identity with `MassRadialValues.value` through
  `CapScoreRules.value_on/value_off` and `coefficient_of`. `coefficientQ`
  itself is never evaluated in the kernel.
* `TrialCap{cc}RadialTable180`: the two channel tables `chD` (difference) and
  `chT` (sum), `differences/totals = chD/chT`, and the predicate `Check`.
* 1,113 score modules `TrialCap{cc}Score<ee><ss>180` with `n` kernel checks each.
* `TrialCap{cc}MassScores180`: the `CapMass.Windows`, carrier identities,
  `CapMass.GroupScores` and `mass : CapMass.Target cc`.

The exact scores are recomputed from the bank words as in `build_cap36_scores`
and audited against the 27-bit targets of `TrialCoarseMassTargets180` and the
external per-cap interval of `mass_span_external_intervals.json`.
`--dry-run` writes skeletons with placeholder bounds (not a certificate);
`--crosscheck` compares the exact window weights with `check_span_mass_dots`
(no words needed).
"""
import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction
from functools import lru_cache
import json
from math import lcm
import os
from pathlib import Path
import re
import sys

import build_cap36_scores as base36
from build_cap36_scores import (COUNT, OPTIONS, ROW_CHUNKS, WORD_BYTES, _digest, _rat, _table_def, amplitude,
                                channel_lists, coefficient_q, keys, newton, row_q, spline_row)
from cap_bank_names import CHANGING, LEGACY, Names

HERE = Path(__file__).resolve().parent
END_LABELS = ("0000", "0001", "0002", "0011", "0012", "0022", "0101", "0102", "0111", "0112", "0122",
              "0202", "0211", "0212", "0222", "1111", "1112", "1122", "1212", "1222", "2222")
FIRST_TICK = 18719
RESULT_FILE = "exact-scores.json"


# ---------------------------------------------------------------------------
# Cap data (all exact, from the frozen spline table)

@lru_cache(None)
def spline():
    from check_exact_endpoint_pair import Spline
    return Spline(HERE / "frozen_band_tables.json")


class Cap:
    def __init__(self, cap):
        if cap not in CHANGING or cap == LEGACY:
            raise ValueError(f"build_cap_scores handles caps {CHANGING[:-1]}; cap 36 is build_cap36_scores")
        self.cap = cap
        self.names = Names(cap)
        self.fine, self.cut = spline().state(cap)
        self.next_fine, self.next_cut = spline().state(cap + 1)
        if self.next_fine < 0:
            raise ValueError("Only cap 36 has no next field")
        rows = spline().spans(cap)
        # (piece, start, length, current, later)
        self.windows = tuple((p, a, b - a, now >= 0, old >= 0) for p, a, b, now, old, _ in rows)
        self.check_windows()

    @property
    def n(self):
        return len(self.windows)

    @property
    def edge(self):
        return self.windows[-1][1] + self.windows[-1][2]

    def check_windows(self):
        """The conditions that `CapMass.Windows` and `CapMass.Valid` check again in Lean."""
        step = base36.STEP
        if self.windows[0][1] != FIRST_TICK:
            raise ValueError("The first window must start at 18,719")
        for (p, a, n, cur, lat), nxt in zip(self.windows, list(self.windows[1:]) + [None]):
            if nxt is not None and a + n != nxt[1]:
                raise ValueError("The windows do not tile")
            sample = lambda j: (Fraction(j) + Fraction(39, 2)) * step
            if not (7 <= n and 3 <= p < 33 and a + n <= COUNT and base36.knot(p) <= sample(a)
                    and sample(a + n - 1) < base36.knot(p + 1)):
                raise ValueError(f"Window {(p, a, n)} is not a valid spline span")
            for flag, cut in ((cur, self.cut), (lat, self.next_cut)):
                if (flag and not a + n <= cut + 1) or (not flag and not cut < a):
                    raise ValueError(f"Window {(p, a, n)} straddles a field cutoff")
        if not (self.edge <= COUNT and self.cut < self.edge and self.next_cut < self.edge):
            raise ValueError("Some field survives past the last window")

    @lru_cache(None)
    def radial(self, w, i, nxt):
        """Exact coefficientQ (start w + i) of the cap's (or next cap's) fine class, or None when cut off."""
        _, start, _, cur, lat = self.windows[w]
        if not (lat if nxt else cur):
            return None
        fine = self.next_fine if nxt else self.fine
        vals = [coefficient_q(start + i, fine, u) for u in keys()]
        den = lcm(*(v.denominator for v in vals))
        return den, [v.numerator * (den // v.denominator) for v in vals]

    @lru_cache(None)
    def scaled(self, w, i):
        """Integers D, T and L with chD = 2^64 D / L and chT = 2^64 T / L at tick i of window w."""
        a, b = self.radial(w, i, False), self.radial(w, i, True)
        den = lcm(*(x[0] for x in (a, b) if x is not None))
        A = [0] * 99 if a is None else [v * (den // a[0]) for v in a[1]]
        B = [0] * 99 if b is None else [v * (den // b[0]) for v in b[1]]
        return [x - y for x, y in zip(A, B)], [x + y for x, y in zip(A, B)], den

    def channel(self, w, i, key, total):
        d, t, den = self.scaled(w, i)
        a, b, g = key
        return Fraction((t if total else d)[(a * 3 + b) * 11 + g] << 64, den)

    @lru_cache(None)
    def values(self, w, e, s):
        """CapMass.values cap (span w) e s = newton (contracted chD chT e s), exactly."""
        ends, powers = channel_lists()
        out = []
        for k in range(7):
            d, t, den = self.scaled(w, k)
            total = 0
            for (a, b), (c, dd) in ends[e]:
                for x, y in powers[s]:
                    total += d[(a * 3 + b) * 11 + x] * t[(c * 3 + dd) * 11 + y]
            out.append(Fraction(total << 128, den * den))
        return tuple(newton(out))

    def targets(self):
        text = (HERE / "TrialCoarseMassTargets180.lean").read_text()
        lower = int(re.search(rf"def lower .*?\| {self.cap} => (\d+)", text, re.S)[1])
        upper = int(re.search(rf"def upper .*?\| {self.cap} => (\d+)", text, re.S)[1])
        return lower, upper

    def external(self):
        data = json.loads((HERE / "mass_span_external_intervals.json").read_text())
        row = next(r for r in data["caps"] if r["class"] == self.cap)
        return Fraction(row["lower"]), Fraction(row["upper"])


# ---------------------------------------------------------------------------
# Words and exact scores

def word_files(cap, generated):
    names = Names(cap)
    out = {}
    for e, label in enumerate(END_LABELS):
        if label == "0000":
            out[("end", e)] = [generated / names.directory("square") / f"square-{side}.bin" for side in ("low", "high")]
        else:
            out[("end", e)] = [generated / names.directory("end_pairs") / f"cap-end-pair-{label}-{side}.bin"
                               for side in ("lo", "hi")]
    for s in range(53):
        if s == 0:
            out[("ang", s)] = [generated / names.directory("powers") / f"power-37-{side}.bin" for side in ("lo", "hi")]
        else:
            out[("ang", s)] = [generated / names.directory("gram") / f"weighted-{s:02d}-{side}.bin" for side in ("lo", "hi")]
    return out


def _scores_for_endpoint(task):
    """Exact lowScore/highScore for one endpoint pair, all 53 signatures and all windows of the cap."""
    cap, e, end_paths, ang_paths = task
    sys.path.insert(0, str(HERE))
    from check_cap36_raw_batches import Moments, Word
    data = Cap(cap)
    ends = [Word(p.read_bytes()) for p in end_paths]
    angular, product, extract = Word(), Word(), Moments()
    rows, sums = [], [[Fraction(0), Fraction(0)] for _ in range(data.n)]
    for s in range(53):
        digits = []
        for side in range(2):
            angular.load(ang_paths[s][side].read_bytes())
            product.multiply(ends[side], angular)
            digits.append([extract.seven(product, a, a + n) for _, a, n, _, _ in data.windows])
        row = []
        for w, (_, start, n, _, _) in enumerate(data.windows):
            v = data.values(w, e, s)
            lo, hi = digits[0][w], digits[1][w]
            radius = amplitude(v, n) * (hi[0] - lo[0])
            low = sum(c * m for c, m in zip(v, lo)) - radius
            high = sum(c * m for c, m in zip(v, hi)) + radius
            if low > high:
                raise ArithmeticError(f"Inverted score at {(e, s, w)}")
            row.append([low.__floor__(), -((-high).__floor__())])
            sums[w][0] += low
            sums[w][1] += high
        rows.append(row)
    return e, rows, [[str(a), str(b)] for a, b in sums]


def exact_scores(cap, generated, destination, jobs):
    files = word_files(cap, generated)
    for paths in files.values():
        for p in paths:
            if not p.is_file() or p.stat().st_size != WORD_BYTES:
                raise FileNotFoundError(f"Missing or truncated factor word {p}")
    inputs = {str(p.relative_to(generated)): _digest(p) for ps in files.values() for p in ps}
    stamp = {"cap": cap, "inputs": inputs, "generator": _digest(Path(__file__)),
             "helpers": _digest(Path(base36.__file__)), "table": _digest(HERE / "frozen_band_tables.json")}
    cache = destination / RESULT_FILE
    if cache.is_file():
        old = json.loads(cache.read_text())
        if old.get("stamp") == stamp:
            audit(cap, old["bounds"], old["window_sums"])
            return old["bounds"]
    tasks = [(cap, e, files[("end", e)], [files[("ang", s)] for s in range(53)]) for e in range(21)]
    results = {}
    with ProcessPoolExecutor(max_workers=jobs) as pool:
        for e, rows, sums in pool.map(_scores_for_endpoint, tasks):
            results[e] = (rows, sums)
    bounds = [results[e][0] for e in range(21)]
    sums = [results[e][1] for e in range(21)]
    audit(cap, bounds, sums)
    destination.mkdir(parents=True, exist_ok=True)
    tmp = cache.with_suffix(".tmp")
    tmp.write_text(json.dumps({"stamp": stamp, "bounds": bounds, "window_sums": sums}) + "\n")
    tmp.replace(cache)
    return bounds


def audit(cap, bounds, sums):
    """The rounded totals must meet the 27-bit targets; report the comparison with the external run."""
    data = Cap(cap)
    lower, upper = data.targets()
    total_lo = sum(b[0] for row in bounds for col in row for b in col)
    total_hi = sum(b[1] for row in bounds for col in row for b in col)
    if not (lower * 2**613 <= total_lo <= total_hi <= upper * 2**613):
        raise ArithmeticError(f"Rounded score totals miss the 27-bit cap-{cap} targets")
    exact_lo = sum(Fraction(x[0]) for row in sums for x in row) / 2**640
    exact_hi = sum(Fraction(x[1]) for row in sums for x in row) / 2**640
    ext_lo, ext_hi = data.external()
    same = "identical to" if (exact_lo, exact_hi) == (ext_lo, ext_hi) else "different from"
    print(f"Cap {cap}: exact score interval {same} the external interval "
          f"(lower {float(exact_lo - ext_lo):.3e}, upper {float(exact_hi - ext_hi):.3e} from it)")
    margins = (total_lo - lower * 2**613) >> 568, (upper * 2**613 - total_hi) >> 568
    print(f"Cap {cap}: margins after integer rounding, in units of 2^-72: lower {margins[0]:,d}, upper {margins[1]:,d}")
    return margins


# ---------------------------------------------------------------------------
# Module text

class Text:
    def __init__(self, cap):
        self.data = Cap(cap)
        self.names = self.data.names
        self.c = cap
        self.ns = self.names.ns("Scores")

    def name_end(self, e):
        return self.names.module(f"WordEnd{END_LABELS[e]}")

    def name_ang(self, s):
        return self.names.module(f"WordAng{s:02d}")

    def ns_end(self, e):
        return f"{self.names.ns('Words')}.End{END_LABELS[e]}"

    def ns_ang(self, s):
        return f"{self.names.ns('Words')}.Ang{s:02d}"

    def name_radial(self, w, i):
        return self.names.module(f"Radial{w:02d}{i}")

    def name_score(self, e, s):
        return self.names.module(f"Score{e:02d}{s:02d}")

    @property
    def base_name(self):
        return self.names.module("ScoreBase")

    @property
    def table_name(self):
        return self.names.module("RadialTable")

    @property
    def final_name(self):
        return self.names.module("MassScores")

    def carrier(self, namespace, paths, destination):
        rel = [os.path.relpath(p, destination) for p in paths]
        for r in rel:
            if not re.fullmatch(r"[A-Za-z0-9_./-]+\.bin", r):
                raise ValueError(f"Unsupported word path {r}")
        return "\n".join([
            "import TrialCapWordReader180", "",
            f"/-! One final cap-{self.c} factor word pair. `{self.final_name}` proves it equal to the bank word. -/",
            f"namespace PrimeGap180.{namespace}", "set_option maxRecDepth 16000",
            f'@[irreducible] def lo : Nat := capWord180% "{rel[0]}" {WORD_BYTES}',
            f'@[irreducible] def hi : Nat := capWord180% "{rel[1]}" {WORD_BYTES}',
            f"end PrimeGap180.{namespace}", ""])

    def base(self):
        d = self.data
        vec = lambda xs: "![" + ",".join(xs) + "]"
        n = d.n
        return "\n".join([
            "import TrialCapScoreRules180", "",
            f"/-! The {n} cap-{self.c} windows (`Spline.spans {self.c}`) and the fine classes and",
            "cutoffs of the cap and of the next cap. No factor word is imported below this module. -/",
            f"namespace PrimeGap180.{self.ns}",
            f"def piece : Fin {n} → Nat := " + vec(str(p) for p, *_ in d.windows),
            f"def start : Fin {n} → Nat := " + vec(str(a) for _, a, *_ in d.windows),
            f"def length : Fin {n} → Nat := " + vec(str(m) for _, _, m, *_ in d.windows),
            f"def current : Fin {n} → Bool := " + vec(str(x).lower() for *_, x, _ in d.windows),
            f"def later : Fin {n} → Bool := " + vec(str(x).lower() for *_, x in d.windows),
            f"theorem capNow : DebitNativeClasses.capAt ⟨{self.c},by decide⟩={d.fine} := by decide +kernel",
            f"theorem capNext : DebitNativeClasses.capAt ⟨{self.c + 1},by decide⟩={d.next_fine} := by decide +kernel",
            f"theorem cutNow : min 130964 (CoarseLaw.T.maxIndex {d.fine})={d.cut} := by decide +kernel",
            f"theorem cutNext : min 130964 (CoarseLaw.T.maxIndex {d.next_fine})={d.next_cut} := by decide +kernel",
            "#print axioms cutNext", f"end PrimeGap180.{self.ns}", ""])

    def name_rows(self, nxt, p):
        return self.names.module(f"Rows{'Next' if nxt else 'Now'}{p}")

    @property
    def row_table_name(self):
        return self.names.module("RowTable")

    def rows_module(self, nxt, p, chunks=ROW_CHUNKS):
        """rowQ F p s k for the 11 signatures s, one declaration per k-chunk (as in build_cap36_scores)."""
        fine = self.data.next_fine if nxt else self.data.fine
        tag = f"Rows{'Next' if nxt else 'Now'}{p}"
        lines = ["import TrialMassRadialValues180", "",
                 f"/-! The rational row coefficients `FrozenData.rowQ {fine} {p} s k` (cap {self.c + nxt}), one kernel",
                 "declaration per k-chunk of each (shape, signature) row. -/",
                 f"namespace PrimeGap180.{self.ns}.{tag}", *OPTIONS]
        for s in range(11):
            lines += _table_def(f"r{s:02d}", "Fin 30", [row_q(fine, p, s, k) for k in range(30)])
            for j, (lo, hi) in enumerate(chunks):
                lines.append(f"theorem row{s:02d}c{j} : ∀ k : Fin 30,{lo} ≤ k.val → k.val<{hi} → "
                             f"FrozenData.rowQ {fine} {p} {s} k=r{s:02d} k := by decide +kernel")
            lines.append(f"theorem row{s:02d} (k : Fin 30) : FrozenData.rowQ {fine} {p} {s} k=r{s:02d} k := by")
            for j, (lo, hi) in enumerate(chunks[:-1]):
                lines += [f"  by_cases h{j} : k.val<{hi}", f"  · exact row{s:02d}c{j} k (by omega) h{j}"]
            lines.append(f"  exact row{s:02d}c{len(chunks) - 1} k (by omega) k.isLt")
        lines += ["#print axioms row10", f"end PrimeGap180.{self.ns}.{tag}", ""]
        return "\n".join(lines)

    def row_table(self):
        d = self.data
        lines = [*(f"import {self.name_rows(nxt, p)}" for nxt in (False, True) for p in range(9)),
                 "import TrialCapScoreRules180", "",
                 f"/-! The row tables of the fine classes {d.fine} (cap {self.c}) and {d.next_fine} (cap {self.c + 1}). -/",
                 "noncomputable section", f"namespace PrimeGap180.{self.ns}", *OPTIONS, ""]
        for nxt, fine, name in ((False, d.fine, "Now"), (True, d.next_fine, "Next")):
            table = ",\n  ".join("![" + ",".join(f"Rows{name}{p}.r{s:02d}" for s in range(11)) + "]" for p in range(9))
            cases = ",".join(f"Rows{name}{p}.row{s:02d}" for p in range(9) for s in range(11))
            lines += [f"def row{name} : Fin 9 → Fin 11 → Fin 30 → ℚ := ![\n  " + table + "]",
                      f"theorem rows{name} : ∀ (p : Fin 9) (s : Fin 11) (k : Fin 30),FrozenData.rowQ {fine} p s k=row{name} p s k := by",
                      "  intro p s", "  fin_cases p <;> fin_cases s", f"  exacts [{cases}]", ""]
        lines += ["#print axioms rowsNext", f"end PrimeGap180.{self.ns}", ""]
        return "\n".join(lines)

    def radial(self, w, i):
        d = self.data
        start = d.windows[w][1]
        tick = f"start {w}+(({i} : Fin 7)).val"
        lines = ["import " + self.base_name, "import " + self.row_table_name, "",
                 f"/-! Exact radial coefficients of caps {self.c} and {self.c + 1} at tick `start {w} + {i}` = {start + i}. -/",
                 "noncomputable section", f"namespace PrimeGap180.{self.ns}.Radial{w:02d}{i}",
                 "open MassRadialValues CapScoreRules", "open FullNativeTicks (Key)", *OPTIONS,
                 *_table_def("sp", "Fin 30", list(spline_row(start + i))),
                 f"theorem spline : ∀ k : Fin 30,FrozenData.splineQ ({tick}) k=sp k := by decide +kernel"]
        proofs = []
        for nxt, fn, (m, fine, cut) in ((False, "c", (self.c, d.fine, "Now")), (True, "d", (self.c + 1, d.next_fine, "Next"))):
            row = d.radial(w, i, nxt)
            rule = f"CapScoreRules.value_{'on' if row else 'off'} (m:={m}) (J:={tick}) (by decide) cap{cut} cut{cut} (by decide +kernel) u"
            if row is None:
                lines.append(f"def {fn} (_ : Key) : ℚ := 0")
                proofs.append(rule)
                continue
            den, nums = row
            lines += [f"def den{cut} : Nat := {den}",
                      f"def nums{cut} : Array Int := #[" + ",".join(map(str, nums)) + "]",
                      f"def {fn} (u : Key) : ℚ := ((nums{cut}[(u.1.val*3+u.2.1.val)*11+u.2.2.val]?.getD 0 : Int) : ℚ)/(den{cut} : ℚ)",
                      f"theorem literal{cut} : ∀ u : Key,coeffWith row{cut} sp u={fn} u := by decide +kernel"]
            proofs.append(f"({rule}).trans ((coefficient_of {fine} row{cut} rows{cut} _ sp spline u).trans (literal{cut} u))")
        lines += [f"theorem table (u : Key) : value ({tick}) {self.c} u=c u ∧ value ({tick}) {self.c + 1} u=d u :=",
                  f"  ⟨{proofs[0]},", f"    {proofs[1]}⟩",
                  "#print axioms table", f"end PrimeGap180.{self.ns}.Radial{w:02d}{i}", ""]
        return "\n".join(lines)

    def radial_table(self):
        n, c = self.data.n, self.c
        rows = lambda fn: ",\n  ".join("![" + ",".join(f"Radial{w:02d}{i}.{fn}" for i in range(7)) + "]" for w in range(n))
        cases = ",\n    ".join(f"Radial{w:02d}{i}.table u" for w in range(n) for i in range(7))
        return "\n".join([
            *(f"import {self.name_radial(w, i)}" for w in range(n) for i in range(7)),
            "import TrialMassChannelLists180", "",
            f"/-! The cap-{c} channel tables on the {n} windows and the per-window score predicate. -/",
            "noncomputable section", f"namespace PrimeGap180.{self.ns}",
            "open MassBatchRadial MassRadialValues MassSpanDot", "open FullNativeTicks (Key)", *OPTIONS, "",
            f"def nowTable : Fin {n} → Fin 7 → Key → ℚ := ![\n  " + rows("c") + "]",
            f"def nextTable : Fin {n} → Fin 7 → Key → ℚ := ![\n  " + rows("d") + "]", "",
            f"/-- `differences {c} (start w)`. -/",
            f"def chD (w : Fin {n}) (i : Fin 7) (u : Key) : ℚ := (2^64:ℚ)*(nowTable w i u-nextTable w i u)",
            f"/-- `totals {c} (start w)`. -/",
            f"def chT (w : Fin {n}) (i : Fin 7) (u : Key) : ℚ := (2^64:ℚ)*(nowTable w i u+nextTable w i u)", "",
            f"/-- `CapMass.values {c} (span w) e s`, after `values_eq`. -/",
            f"def vals (w : Fin {n}) (e : Fin 21) (s : Fin 53) : Fin 7 → ℚ :=",
            "  newton (contracted (chD w) (chT w) e s)", "",
            "/-- `lo ≤ lowScore` and `highScore ≤ hi` for words `l`, `h` on window `w`. -/",
            f"def Check (e : Fin 21) (s : Fin 53) (l h : Nat) (lo hi : ℚ) (w : Fin {n}) : Prop :=",
            "  lo ≤ score (vals w e s) (start w) (length w) l-radius (vals w e s) (start w) (length w) l h ∧",
            "  score (vals w e s) (start w) (length w) h+radius (vals w e s) (start w) (length w) l h ≤ hi", "",
            f"instance (e : Fin 21) (s : Fin 53) (l h : Nat) (lo hi : ℚ) (w : Fin {n}) :",
            "    Decidable (Check e s l h lo hi w) := by unfold Check; infer_instance", "",
            f"theorem value_eq (w : Fin {n}) (i : Fin 7) (u : Key) :",
            f"    value (start w+i.val) {c} u=nowTable w i u ∧ value (start w+i.val) {c + 1} u=nextTable w i u := by",
            "  fin_cases w <;> fin_cases i", "  exacts [" + cases + "]", "",
            f"theorem table (w : Fin {n}) (i : Fin 7) (u : Key) :",
            f"    differences {c} (start w) i u=chD w i u ∧ totals {c} (start w) i u=chT w i u :=",
            f"  CapScoreRules.tables {c} (start w) (nowTable w) (nextTable w)",
            "    (fun i u => (value_eq w i u).1) (fun i u => (value_eq w i u).2) i u", "",
            "#print axioms table", f"end PrimeGap180.{self.ns}", ""])

    def score(self, e, s, bounds):
        n = self.data.n
        lo = [b[0] for b in bounds] if bounds else [0] * n
        hi = [b[1] for b in bounds] if bounds else [0] * n
        words = (f"(raw 640 130965 {self.ns_end(e)}.lo {self.ns_ang(s)}.lo) "
                 f"(raw 640 130965 {self.ns_end(e)}.hi {self.ns_ang(s)}.hi)")
        lines = [f"import {self.table_name}", "import TrialMassRawProduct180",
                 f"import {self.name_end(e)}", f"import {self.name_ang(s)}", "",
                 f"/-! Kernel score checks for cap {self.c}, endpoint pair {e} ({END_LABELS[e]}) and angular signature {s}. -/"]
        if bounds is None:
            lines.append("-- DRY RUN: placeholder bounds. This module is not a certificate and will not check.")
        lines += [f"namespace PrimeGap180.{self.ns}.Score{e:02d}{s:02d}", "open MassRawProduct", *OPTIONS,
                  f"def lo : Fin {n} → ℚ := ![" + ",".join(map(_rat, lo)) + "]",
                  f"def hi : Fin {n} → ℚ := ![" + ",".join(map(_rat, hi)) + "]"]
        lines += [f"theorem check{w} : Check {e} {s} {words} (lo {w}) (hi {w}) {w} := by decide +kernel"
                  for w in range(n)]
        lines += [f"theorem check : ∀ w : Fin {n},Check {e} {s} {words} (lo w) (hi w) w := by",
                  "  intro w", "  fin_cases w",
                  "  exacts [" + ",".join(f"check{w}" for w in range(n)) + "]",
                  "#print axioms check", f"end PrimeGap180.{self.ns}.Score{e:02d}{s:02d}", ""]
        return "\n".join(lines)

    def final(self):
        d, c, n = self.data, self.c, self.data.n
        bank = f"{self.names.ns('Bank')}.bank"
        vec = lambda items: "![" + ",".join(items) + "]"
        lines = ["import TrialCapMassAssembly180", f"import {self.names.module('MassBank')}",
                 *(f"import {self.name_score(e, s)}" for e in range(21) for s in range(53)), "",
                 f"/-! Discharge `CapMass.GroupScores` for cap {c} from the 1,113 generated score modules",
                 f"and conclude the cap-{c} case of the 27-bit mass targets. -/",
                 "noncomputable section", "open scoped BigOperators",
                 f"namespace PrimeGap180.{self.names.ns('MassScores')}",
                 f"open {self.ns} MassRawProduct MassBatchRadial CapMass SignedRadialGroup", *OPTIONS, "",
                 "def endLo : Fin 21 → Nat := " + vec(f"{self.ns_end(e)}.lo" for e in range(21)),
                 "def endHi : Fin 21 → Nat := " + vec(f"{self.ns_end(e)}.hi" for e in range(21)),
                 "def angLo : Fin 53 → Nat := " + vec(f"{self.ns_ang(s)}.lo" for s in range(53)),
                 "def angHi : Fin 53 → Nat := " + vec(f"{self.ns_ang(s)}.hi" for s in range(53)), "",
                 "/-- Every carrier word is literally the bank word (148 literal comparisons). -/",
                 "theorem end_words : ∀ e : Fin 21,",
                 f"    ({bank}.ends e).lo=endLo e ∧ ({bank}.ends e).hi=endHi e := by decide +kernel",
                 "theorem ang_words : ∀ s : Fin 53,",
                 f"    ({bank}.angs s).lo=angLo s ∧ ({bank}.angs s).hi=angHi s := by decide +kernel", "",
                 "theorem lowerWord_eq (e : Fin 21) (s : Fin 53) :",
                 f"    lowerWord {bank} e s=raw 640 130965 (endLo e) (angLo s) := by",
                 "  unfold lowerWord", "  rw [(end_words e).1,(ang_words s).1]",
                 "theorem upperWord_eq (e : Fin 21) (s : Fin 53) :",
                 f"    upperWord {bank} e s=raw 640 130965 (endHi e) (angHi s) := by",
                 "  unfold upperWord", "  rw [(end_words e).2,(ang_words s).2]", "",
                 f"def spanOf (w : Fin {n}) : Span := ⟨piece w,start w,length w,current w,later w⟩",
                 f"def edgeAt (k : Nat) : Nat := if h : k<{n} then start ⟨k,h⟩ else {d.edge}",
                 f"theorem winValid : ∀ w : Fin {n},Valid {c} (spanOf w) := by decide +kernel",
                 f"theorem winEdges : ∀ w : Fin {n},edgeAt w.val=(spanOf w).start ∧",
                 "    edgeAt (w.val+1)=(spanOf w).start+(spanOf w).len := by decide +kernel",
                 "theorem winFirst : edgeAt 0=18719 := by decide +kernel",
                 f"theorem winLast : edgeAt {n} ≤ 130965 := by decide +kernel",
                 f"theorem winTail : stable {c} (edgeAt {n}) 0 false=true ∧ stable {c + 1} (edgeAt {n}) 0 false=true := by",
                 "  decide +kernel",
                 f"def windows : Windows {c} {n} := ⟨spanOf,winValid,edgeAt,winEdges,winFirst,winLast,winTail⟩",
                 f"theorem winSpans (w : Fin {n}) : (windows.span w).start=start w ∧ (windows.span w).len=length w :=",
                 "  ⟨rfl,rfl⟩", "",
                 f"def lows : Fin 21 → Fin 53 → Fin {n} → ℚ := ![\n  " +
                 ",\n  ".join(vec(f"Score{e:02d}{s:02d}.lo" for s in range(53)) for e in range(21)) + "]",
                 f"def highs : Fin 21 → Fin 53 → Fin {n} → ℚ := ![\n  " +
                 ",\n  ".join(vec(f"Score{e:02d}{s:02d}.hi" for s in range(53)) for e in range(21)) + "]", ""]
        spec = ("Check {e} s (raw 640 130965 (endLo {e}) (angLo s)) (raw 640 130965 (endHi {e}) (angHi s)) "
                "(lows {e} s w) (highs {e} s w) w")
        for e in range(21):
            lines += [f"theorem row{e:02d} : ∀ (s : Fin 53) (w : Fin {n})," + spec.format(e=e) + " := by",
                      "  intro s", "  fin_cases s",
                      "  exacts [" + ",".join(f"Score{e:02d}{s:02d}.check" for s in range(53)) + "]"]
        lines += ["", f"theorem allChecks : ∀ (e : Fin 21) (s : Fin 53) (w : Fin {n}),",
                  "    Check e s (raw 640 130965 (endLo e) (angLo s)) (raw 640 130965 (endHi e) (angHi s))",
                  "      (lows e s w) (highs e s w) w := by",
                  "  intro e", "  fin_cases e",
                  "  exacts [" + ",".join(f"row{e:02d}" for e in range(21)) + "]", "",
                  f"theorem values_eq (w : Fin {n}) (e : Fin 21) (s : Fin 53) :",
                  f"    values {c} (windows.span w) e s=vals w e s := by",
                  f"  have hd : differences {c} (windows.span w).start=chD w := by",
                  "    funext i u", "    rw [(winSpans w).1]", "    exact (table w i u).1",
                  f"  have ht : totals {c} (windows.span w).start=chT w := by",
                  "    funext i u", "    rw [(winSpans w).1]", "    exact (table w i u).2",
                  "  unfold values vals", "  rw [hd,ht]", "",
                  f"theorem low_bound (e : Fin 21) (s : Fin 53) (w : Fin {n}) : lows e s w ≤",
                  f"    lowScore (values {c} (windows.span w) e s) (windows.span w).start (windows.span w).len",
                  f"      (lowerWord {bank} e s) (upperWord {bank} e s) := by",
                  "  rw [values_eq,(winSpans w).1,(winSpans w).2,lowerWord_eq,upperWord_eq]",
                  "  exact And.left (allChecks e s w)", "",
                  f"theorem high_bound (e : Fin 21) (s : Fin 53) (w : Fin {n}) :",
                  f"    highScore (values {c} (windows.span w) e s) (windows.span w).start (windows.span w).len",
                  f"      (lowerWord {bank} e s) (upperWord {bank} e s) ≤ highs e s w := by",
                  "  rw [values_eq,(winSpans w).1,(winSpans w).2,lowerWord_eq,upperWord_eq]",
                  "  exact And.right (allChecks e s w)", "",
                  f"theorem low_total : (CoarseMassTargets.lower {c}:ℚ)*2^613 ≤",
                  f"    ∑ e : Fin 21,∑ w : Fin {n},∑ s : Fin 53,lows e s w := by decide +kernel",
                  f"theorem high_total : ∑ e : Fin 21,∑ w : Fin {n},∑ s : Fin 53,highs e s w ≤",
                  f"    (CoarseMassTargets.upper {c}:ℚ)*2^613 := by decide +kernel", "",
                  f"def groupScores : GroupScores {bank} windows :=",
                  "  ⟨lows,highs,low_bound,high_bound,low_total,high_total⟩", "",
                  f"theorem mass : Target {c} := capMass_of_groups {c} {bank} windows groupScores", "",
                  "#print axioms mass", f"end PrimeGap180.{self.names.ns('MassScores')}", ""]
        return "\n".join(lines)


def emit(cap, destination, generated, bounds):
    t = Text(cap)
    destination.mkdir(parents=True, exist_ok=True)
    files = word_files(cap, generated)
    texts = {t.base_name: t.base()}
    for nxt in (False, True):
        for p in range(9):
            texts[t.name_rows(nxt, p)] = t.rows_module(nxt, p)
    texts[t.row_table_name] = t.row_table()
    for e in range(21):
        texts[t.name_end(e)] = t.carrier(t.ns_end(e), files[("end", e)], destination)
    for s in range(53):
        texts[t.name_ang(s)] = t.carrier(t.ns_ang(s), files[("ang", s)], destination)
    for w in range(t.data.n):
        for i in range(7):
            texts[t.name_radial(w, i)] = t.radial(w, i)
    texts[t.table_name] = t.radial_table()
    for e in range(21):
        for s in range(53):
            texts[t.name_score(e, s)] = t.score(e, s, None if bounds is None else bounds[e][s])
    texts[t.final_name] = t.final()
    modules = {}
    for name, text in texts.items():
        path = destination / f"{name}.lean"
        if not path.is_file() or path.read_text() != text:
            path.write_text(text)
        modules[name] = path
    return modules


def generate(destination, generated, jobs=4, cap=LEGACY):
    """Entry point for build_conservative_proof.py: all bank .bin files of the cap must already exist."""
    if cap == LEGACY:
        return base36.generate(destination, generated, jobs)
    bounds = exact_scores(cap, generated, destination, jobs)
    return emit(cap, destination, generated, bounds)


def crosscheck(cap):
    """Compare chD/chT and the weights with the independent arithmetic of check_span_mass_dots (no words)."""
    sys.path.insert(0, str(HERE))
    from check_span_mass_dots import groups, spans
    d = Cap(cap)
    catalog = spans(cap)
    if [(a, b - a) for a, b, *_ in catalog] != [(a, n) for _, a, n, _, _ in d.windows]:
        raise ValueError("Python spans differ from the Lean windows")
    assignments = groups()
    sigs = sorted(assignments)
    shapes = sorted(assignments[sigs[0]])
    if ["".join(str(x) for shape in key for x in shape) for key in shapes] != list(END_LABELS):
        raise ValueError("Endpoint order differs")
    for w, (start, stop, den, diff, total) in enumerate(catalog):
        for i in range(7):
            for u in keys():
                a, b, g = u
                if (d.channel(w, i, u, False) != Fraction(diff[9 * g + 3 * a + b][i], den) or
                        d.channel(w, i, u, True) != Fraction(total[9 * g + 3 * a + b][i], den)):
                    raise ArithmeticError(f"Channel mismatch at window {w}, tick {i}, key {u}")
        for s, sig in enumerate(sigs):
            for e, key in enumerate(shapes):
                rows = assignments[sig][key]
                coeff = newton([sum(diff[p][k] * total[q][k] for p, q in rows) for k in range(7)])
                if tuple(Fraction(x, den * den) for x in coeff) != d.values(w, e, s):
                    raise ArithmeticError(f"Weight mismatch at window {w}, endpoint {e}, signature {s}")
    print(f"Cap {cap}: matched {d.n * 7 * 99 * 2:,d} channel values and {d.n * 1113:,d} weight vectors "
          "with check_span_mass_dots.")


KINDS = [("endpoint word carriers", r"WordEnd[012]{4}"), ("angular word carriers", r"WordAng\d{2}"),
         ("window base", r"ScoreBase"), ("row modules", r"Rows(?:Now|Next)\d"), ("row table", r"RowTable"),
         ("radial tick modules", r"Radial\d{3}"), ("radial table", r"RadialTable"),
         ("score modules", r"Score\d{4}"), ("final assembly", r"MassScores")]


def summary(cap, modules):
    t = Text(cap)
    groups, sizes = Counter(), Counter()
    for name, path in modules.items():
        body = name.removeprefix(f"TrialCap{cap:02d}").removesuffix("180")
        kind = next(k for k, pattern in KINDS if re.fullmatch(pattern, body))
        groups[kind] += 1
        sizes[kind] += path.stat().st_size
    print(f"Cap {cap}: {t.data.n} windows; fine classes {t.data.fine}/{t.data.next_fine}, "
          f"cutoffs {t.data.cut}/{t.data.next_cut}; windows end at {t.data.edge}.")
    print("Module kinds (count, total source bytes):")
    for kind, _ in KINDS:
        print(f"  {kind:24s} {groups[kind]:5d} {sizes[kind]:12,d}")
    print(f"  {'total':24s} {sum(groups.values()):5d} {sum(sizes.values()):12,d}")
    print(f"Kernel work: 2 x 9 x 33 rowQ chunks; {t.data.n * 7} x (30 splineQ + 1-2 x 99 literal coefficients); 1,113 x {t.data.n} window checks "
          "(two 84-Mbit products each); 148 literal word identities; "
          f"two sums of {1113 * t.data.n:,d} rationals; then CapMass.capMass.")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--cap", type=int, required=True, choices=CHANGING)
    parser.add_argument("--build-dir", type=Path, help="build directory of build_conservative_proof.py")
    parser.add_argument("--output-dir", type=Path, help="default: <build>/generated/cap<cc>_scores")
    parser.add_argument("--jobs", type=int, default=4)
    parser.add_argument("--dry-run", action="store_true", help="emit skeletons without words or scores")
    parser.add_argument("--crosscheck", action="store_true",
                        help="compare the exact weights with check_span_mass_dots (no words needed)")
    args = parser.parse_args()
    if args.cap == LEGACY:
        argv = [sys.argv[0], "--jobs", str(args.jobs)]
        for flag, value in (("--build-dir", args.build_dir), ("--output-dir", args.output_dir)):
            if value is not None:
                argv += [flag, str(value)]
        argv += ["--dry-run"] * args.dry_run + ["--crosscheck"] * args.crosscheck
        sys.argv = argv
        return base36.main()
    if args.crosscheck:
        crosscheck(args.cap)
    if args.dry_run:
        out = args.output_dir or parser.error("--dry-run needs --output-dir")
        generated = (args.build_dir / "generated") if args.build_dir else out.parent
        summary(args.cap, emit(args.cap, out, generated, None))
        return
    if args.build_dir is None:
        if args.crosscheck:
            return
        parser.error("--build-dir is required unless --dry-run")
    generated = args.build_dir.resolve() / "generated"
    destination = args.output_dir or generated / Names(args.cap).directory("scores")
    summary(args.cap, generate(destination, generated, args.jobs, args.cap))


if __name__ == "__main__":
    main()
