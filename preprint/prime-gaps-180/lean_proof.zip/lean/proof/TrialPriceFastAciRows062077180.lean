import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G062
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 62

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G062

namespace PrimeGap180.PriceIsolatedGroup.G067
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 67

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G067

namespace PrimeGap180.PriceIsolatedGroup.G072
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 72

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G072

namespace PrimeGap180.PriceIsolatedGroup.G077
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 77

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G077
