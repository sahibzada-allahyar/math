import TrialPricePackedRows180

/-! Recover signed entries and their absolute row sum without storing a dense
residual. The coefficient interval has width strictly less than the base. -/
noncomputable section
open scoped BigOperators
open PrimeGap180.Price PrimeGap180.PricePackedRows
namespace PrimeGap180.PriceDigits

def head (B C x : ℤ) := (x+C)%B-C

def tail (B C x : ℤ) := (x-head B C x)/B

def digit (B C : ℤ) : ℕ → ℤ → ℤ
  | 0,x => head B C x
  | j+1,x => digit B C j (tail B C x)

def absoluteSum (B C : ℤ) : ℕ → ℤ → ℤ
  | 0,_ => 0
  | k+1,x => |head B C x| + absoluteSum B C k (tail B C x)

private theorem leading {B C a : ℤ} (v : ℤ) (lo : 0 ≤ a+C) (hi : a+C < B) :
    head B C (a+B*v) = a := by
  unfold head
  rw [show a+B*v+C = (a+C)+B*v by ring,Int.add_mul_emod_self_left,Int.emod_eq_of_lt lo hi]
  ring

private theorem trailing {B C a : ℤ} (v : ℤ) (lo : 0 ≤ a+C) (hi : a+C < B) :
    tail B C (a+B*v) = v := by
  rw [tail,leading v lo hi,show a+B*v-a=B*v by ring,Int.mul_ediv_cancel_left _ (by omega)]

theorem at_index {n : ℕ} {B C : ℤ} (f : Fin n → ℤ)
    (bound : ∀ j, 0 ≤ f j+C ∧ f j+C < B) (j : Fin n) :
    digit B C j.val (pack B f) = f j := by
  induction n with
  | zero => exact Fin.elim0 j
  | succ n ih =>
    rw [pack_succ]
    refine Fin.cases ?_ (fun i => ?_) j
    · exact leading _ (bound 0).1 (bound 0).2
    · change digit B C i.val (tail B C (f 0+B*pack B (fun h : Fin n => f h.succ))) = f i.succ
      rw [trailing _ (bound 0).1 (bound 0).2]
      exact ih (fun h => f h.succ) (fun h => bound h.succ) i

theorem total {n : ℕ} {B C : ℤ} (f : Fin n → ℤ) (bound : ∀ j, 0 ≤ f j+C ∧ f j+C < B) :
    absoluteSum B C n (pack B f) = ∑ j, |f j| := by
  induction n with
  | zero => simp [absoluteSum]
  | succ n ih =>
    rw [pack_succ,absoluteSum,leading _ (bound 0).1 (bound 0).2,
      trailing _ (bound 0).1 (bound 0).2,Fin.sum_univ_succ,ih (fun h => f h.succ) (fun h => bound h.succ)]

theorem deficit {n : ℕ} {B C : ℤ} (T : Fin n → Fin n → ℤ) (g : Fin n)
    (bound : ∀ j, 0 ≤ T g j+C ∧ T g j+C < B) :
    let v := pack B (T g)
    let diag := digit B C g.val v
    intDeficit T g = max 0 (absoluteSum B C n v-|diag|-diag) := by
  dsimp only
  rw [at_index _ bound,total _ bound]
  have h : (∑ j, if g=j then 0 else |T g j|) + |T g g| = ∑ j, |T g j| := by
    have diagonal : ∑ j : Fin n, (if g=j then |T g j| else 0) = |T g g| := by simp
    rw [←diagonal,←Finset.sum_add_distrib]
    exact Finset.sum_congr rfl fun i _ => by by_cases eq : g=i <;> simp [eq]
  have off : (∑ j, if g=j then 0 else |T g j|) = (∑ j, |T g j|)-|T g g| :=
    eq_sub_iff_add_eq.mpr h
  unfold intDeficit
  apply congrArg (max (0:ℤ))
  apply congrArg (fun z : ℤ => z-T g g)
  refine Eq.trans ?_ off
  apply Finset.sum_congr rfl
  intro j _
  by_cases same : g=j <;> simp [same]

#print axioms deficit
end PrimeGap180.PriceDigits
