import TrialSourcePlanBlocks180

namespace PrimeGap180.SourcePlanBlocks.Sharp

set_option maxRecDepth 131072
set_option maxHeartbeats 100000000

private theorem b0 : all .sharp 0 = true := by decide +kernel
private theorem b1 : all .sharp 1 = true := by decide +kernel
private theorem b2 : all .sharp 2 = true := by decide +kernel
private theorem b3 : all .sharp 3 = true := by decide +kernel
private theorem b4 : all .sharp 4 = true := by decide +kernel
private theorem b5 : all .sharp 5 = true := by decide +kernel
private theorem b6 : all .sharp 6 = true := by decide +kernel
private theorem b7 : all .sharp 7 = true := by decide +kernel
private theorem b8 : all .sharp 8 = true := by decide +kernel
private theorem b9 : all .sharp 9 = true := by decide +kernel
private theorem b10 : all .sharp 10 = true := by decide +kernel
private theorem b11 : all .sharp 11 = true := by decide +kernel
private theorem b12 : all .sharp 12 = true := by decide +kernel
private theorem b13 : all .sharp 13 = true := by decide +kernel
private theorem b14 : all .sharp 14 = true := by decide +kernel
private theorem b15 : all .sharp 15 = true := by decide +kernel
private theorem b16 : all .sharp 16 = true := by decide +kernel
private theorem b17 : all .sharp 17 = true := by decide +kernel
private theorem b18 : all .sharp 18 = true := by decide +kernel
private theorem b19 : all .sharp 19 = true := by decide +kernel
private theorem b20 : all .sharp 20 = true := by decide +kernel
private theorem b21 : all .sharp 21 = true := by decide +kernel
private theorem b22 : all .sharp 22 = true := by decide +kernel
private theorem b23 : all .sharp 23 = true := by decide +kernel
private theorem b24 : all .sharp 24 = true := by decide +kernel
private theorem b25 : all .sharp 25 = true := by decide +kernel
private theorem b26 : all .sharp 26 = true := by decide +kernel
private theorem b27 : all .sharp 27 = true := by decide +kernel
private theorem b28 : all .sharp 28 = true := by decide +kernel
private theorem b29 : all .sharp 29 = true := by decide +kernel
private theorem b30 : all .sharp 30 = true := by decide +kernel
private theorem b31 : all .sharp 31 = true := by decide +kernel
private theorem b32 : all .sharp 32 = true := by decide +kernel
private theorem b33 : all .sharp 33 = true := by decide +kernel
private theorem b34 : all .sharp 34 = true := by decide +kernel
private theorem b35 : all .sharp 35 = true := by decide +kernel
private theorem b36 : all .sharp 36 = true := by decide +kernel
private theorem b37 : all .sharp 37 = true := by decide +kernel
private theorem b38 : all .sharp 38 = true := by decide +kernel
private theorem b39 : all .sharp 39 = true := by decide +kernel

private theorem checked : ∀ j : Fin 40, all .sharp j.val = true :=
  (Fin.cases b0
    (Fin.cases b1
    (Fin.cases b2
    (Fin.cases b3
    (Fin.cases b4
    (Fin.cases b5
    (Fin.cases b6
    (Fin.cases b7
    (Fin.cases b8
    (Fin.cases b9
    (Fin.cases b10
    (Fin.cases b11
    (Fin.cases b12
    (Fin.cases b13
    (Fin.cases b14
    (Fin.cases b15
    (Fin.cases b16
    (Fin.cases b17
    (Fin.cases b18
    (Fin.cases b19
    (Fin.cases b20
    (Fin.cases b21
    (Fin.cases b22
    (Fin.cases b23
    (Fin.cases b24
    (Fin.cases b25
    (Fin.cases b26
    (Fin.cases b27
    (Fin.cases b28
    (Fin.cases b29
    (Fin.cases b30
    (Fin.cases b31
    (Fin.cases b32
    (Fin.cases b33
    (Fin.cases b34
    (Fin.cases b35
    (Fin.cases b36
    (Fin.cases b37
    (Fin.cases b38
    (Fin.cases b39
    (fun z => Fin.elim0 z)))))))))))))))))))))))))))))))))))))))))

theorem every : Every .sharp := of_blocks .sharp 40 (by decide +kernel) checked

#print axioms every
end PrimeGap180.SourcePlanBlocks.Sharp
