import TrialDebitRunData180
import TrialNativeContractions180
import TrialSignedCapContractions180

noncomputable section
open scoped Classical
open PrimeGap180.FrozenData PrimeGap180.FrozenProfile PrimeGap180.CoarseLaw PrimeGap180.Sector
open PrimeGap180.DebitRunData PrimeGap180.NativeContractions PrimeGap180.AdverseScore
namespace PrimeGap180.CapPriceRules
set_option maxRecDepth 16000
set_option maxHeartbeats 1500000

def rawLabel (num : ℕ) : Option Label :=
  if h : 0 < num ∧ num ≤ 521 then some ⟨num-1,by omega⟩ else none

def selectLabel (num j : ℕ) : Option Label := do
  let s ← rawLabel num
  if Native.adverse (d:=38) j ≤ Book.capR s then some s else none

theorem decoded (c : Fine) (j : ℕ) : T.sector c (j+1) =
    selectLabel (debitCode (debitSectorRows c) (j+1)) j := by
  unfold debitCode debitSectorRows
  rw [Array.find?_toList]
  rfl

theorem some_of_cap (s : Label) (j : ℕ) (bound : Native.adverse (d:=38) j ≤ Book.capR s) :
    selectLabel (s.val+1) j=some s := by
  have n : s.val+1≤521 := s.isLt
  simp [selectLabel,rawLabel,n,bound]

def amount (code j : ℕ) := price ((selectLabel code j).getD 170) j

theorem amount_eq (s : Label) (j : ℕ) (bound : Native.adverse (d:=38) j ≤ Book.capR s) :
    amount (s.val+1) j = price s j := by rw [amount,some_of_cap _ _ bound];rfl

theorem labels (c : DebitNativeClasses.Class) (j : ℕ) (inside : j ≤ T.maxIndex (DebitNativeClasses.capAt c)) :
    SignedCapContractions.keyPrice j c.val =
    amount (debitCode (debitSectorRows (DebitNativeClasses.capAt c)) (j+1)) j := by
  simp only [SignedCapContractions.keyPrice,dite_eq_left c.isLt,not_lt.mpr inside,ite_false,decoded,amount]

private theorem adverse_bounds (j l u : ℕ) (low : l ≤ j) (high : j ≤ u) :
    Native.adverse (d:=38) l ≤ Native.adverse (d:=38) j ∧
    Native.adverse (d:=38) j ≤ Native.adverse (d:=38) u := by
  have a : (l:ℝ) ≤ j := by exact_mod_cast low
  have b : (j:ℝ) ≤ u := by exact_mod_cast high
  norm_num [Native.adverse,Native.step,rho]
  constructor <;> linarith

theorem order0 (j : ℕ) (lo : 108887≤j) (hi : j≤110018) : amount 181 j ≤ amount 183 j := by
  obtain ⟨left,right⟩ := adverse_bounds j 108887 110018 lo hi
  have capA : Book.capR 180 = (2351:ℝ)/10000 := rfl
  have boundA : Native.adverse (d:=38) j ≤ Book.capR 180 := right.trans (by rw [capA]; norm_num [Native.adverse,Native.step,rho])
  have priceA : oldPrice 180 = (99999728460596,-42998421) := by decide +kernel
  have capB : Book.capR 182 = (2351:ℝ)/10000 := rfl
  have boundB : Native.adverse (d:=38) j ≤ Book.capR 182 := right.trans (by rw [capB]; norm_num [Native.adverse,Native.step,rho])
  have priceB : oldPrice 182 = (99999728460596,-42998421) := by decide +kernel
  change amount ((180:Label).val+1) j ≤ amount ((182:Label).val+1) j
  rw [amount_eq _ _ boundA,amount_eq _ _ boundB]
  simp only [price,priceA,priceB]
  exact le_rfl

theorem order1 (j : ℕ) (lo : 110019≤j) (hi : j≤112359) : amount 186 j ≤ amount 187 j := by
  obtain ⟨left,right⟩ := adverse_bounds j 110019 112359 lo hi
  have capA : Book.capR 185 = (2401:ℝ)/10000 := rfl
  have boundA : Native.adverse (d:=38) j ≤ Book.capR 185 := right.trans (by rw [capA]; norm_num [Native.adverse,Native.step,rho])
  have priceA : oldPrice 185 = (99999718965264,-40478340) := by decide +kernel
  have capB : Book.capR 186 = (2401:ℝ)/10000 := rfl
  have boundB : Native.adverse (d:=38) j ≤ Book.capR 186 := right.trans (by rw [capB]; norm_num [Native.adverse,Native.step,rho])
  have priceB : oldPrice 186 = (99999718965264,-40478340) := by decide +kernel
  change amount ((185:Label).val+1) j ≤ amount ((186:Label).val+1) j
  rw [amount_eq _ _ boundA,amount_eq _ _ boundB]
  simp only [price,priceA,priceB]
  exact le_rfl

theorem order2 (j : ℕ) (lo : 112360≤j) (hi : j≤112788) : amount 191 j ≤ amount 193 j := by
  obtain ⟨left,right⟩ := adverse_bounds j 112360 112788 lo hi
  have capA : Book.capR 190 = (2451:ℝ)/10000 := rfl
  have boundA : Native.adverse (d:=38) j ≤ Book.capR 190 := right.trans (by rw [capA]; norm_num [Native.adverse,Native.step,rho])
  have priceA : oldPrice 190 = (99999705290357,-38432286) := by decide +kernel
  have capB : Book.capR 192 = (2411:ℝ)/10000 := rfl
  have boundB : Native.adverse (d:=38) j ≤ Book.capR 192 := right.trans (by rw [capB]; norm_num [Native.adverse,Native.step,rho])
  have priceB : oldPrice 192 = (99999718964217,-40478340) := by decide +kernel
  change amount ((190:Label).val+1) j ≤ amount ((192:Label).val+1) j
  rw [amount_eq _ _ boundA,amount_eq _ _ boundB]
  simp only [price,priceA,priceB]
  apply div_le_div_of_nonneg_right _ (by norm_num)
  let d : ℝ := 0.4999-Native.adverse (d:=38) j
  have hd : 0<d := by
    dsimp [d]; norm_num [Native.adverse,Native.step,rho] at right ⊢; linarith
  unfold primePrice
  change _ + _ * (1/d) ≤ _ + _ * (1/d)
  apply (mul_le_mul_iff_of_pos_right hd).mp
  field_simp [ne_of_gt hd]
  dsimp [d]
  norm_num [Native.adverse,Native.step,rho] at left right ⊢ <;> linarith

theorem order3 (j : ℕ) (lo : 112789≤j) (hi : j≤114382) : amount 191 j ≤ amount 192 j := by
  obtain ⟨left,right⟩ := adverse_bounds j 112789 114382 lo hi
  have capA : Book.capR 190 = (2451:ℝ)/10000 := rfl
  have boundA : Native.adverse (d:=38) j ≤ Book.capR 190 := right.trans (by rw [capA]; norm_num [Native.adverse,Native.step,rho])
  have priceA : oldPrice 190 = (99999705290357,-38432286) := by decide +kernel
  have capB : Book.capR 191 = (2445:ℝ)/10000 := rfl
  have boundB : Native.adverse (d:=38) j ≤ Book.capR 191 := right.trans (by rw [capB]; norm_num [Native.adverse,Native.step,rho])
  have priceB : oldPrice 191 = (99999707717088,-39039719) := by decide +kernel
  change amount ((190:Label).val+1) j ≤ amount ((191:Label).val+1) j
  rw [amount_eq _ _ boundA,amount_eq _ _ boundB]
  simp only [price,priceA,priceB]
  apply div_le_div_of_nonneg_right _ (by norm_num)
  let d : ℝ := 0.4999-Native.adverse (d:=38) j
  have hd : 0<d := by
    dsimp [d]; norm_num [Native.adverse,Native.step,rho] at right ⊢; linarith
  unfold primePrice
  change _ + _ * (1/d) ≤ _ + _ * (1/d)
  apply (mul_le_mul_iff_of_pos_right hd).mp
  field_simp [ne_of_gt hd]
  dsimp [d]
  norm_num [Native.adverse,Native.step,rho] at left right ⊢ <;> linarith

theorem order4 (j : ℕ) (lo : 110818≤j) (hi : j≤110818) : amount 185 j ≤ amount 186 j := by
  obtain ⟨left,right⟩ := adverse_bounds j 110818 110818 lo hi
  have capA : Book.capR 184 = (2369:ℝ)/10000 := rfl
  have boundA : Native.adverse (d:=38) j ≤ Book.capR 184 := right.trans (by rw [capA]; norm_num [Native.adverse,Native.step,rho])
  have priceA : oldPrice 184 = (99999728459061,-42998421) := by decide +kernel
  have capB : Book.capR 185 = (2401:ℝ)/10000 := rfl
  have boundB : Native.adverse (d:=38) j ≤ Book.capR 185 := right.trans (by rw [capB]; norm_num [Native.adverse,Native.step,rho])
  have priceB : oldPrice 185 = (99999718965264,-40478340) := by decide +kernel
  change amount ((184:Label).val+1) j ≤ amount ((185:Label).val+1) j
  rw [amount_eq _ _ boundA,amount_eq _ _ boundB]
  simp only [price,priceA,priceB]
  apply div_le_div_of_nonneg_right _ (by norm_num)
  let d : ℝ := 0.4999-Native.adverse (d:=38) j
  have hd : 0<d := by
    dsimp [d]; norm_num [Native.adverse,Native.step,rho] at right ⊢; linarith
  unfold primePrice
  change _ + _ * (1/d) ≤ _ + _ * (1/d)
  apply (mul_le_mul_iff_of_pos_right hd).mp
  field_simp [ne_of_gt hd]
  dsimp [d]
  norm_num [Native.adverse,Native.step,rho] at left right ⊢ <;> linarith
end PrimeGap180.CapPriceRules
