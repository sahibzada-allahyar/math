import TrialLaterLowScalarRow00180
import TrialLaterLowScalarRow01180
import TrialLaterLowScalarRow02180
import TrialLaterLowScalarRow03180
import TrialLaterLowScalarRow04180
import TrialLaterLowScalarRow05180
import TrialLaterLowScalarRow06180
import TrialLaterLowScalarRow07180
import TrialLaterLowScalarRow08180
import TrialLaterLowScalarSettings180

/-! The nine exact fixed-point gamma books and their raw scalar charge ceilings. -/
namespace PrimeGap180.LaterLowFixed
set_option maxHeartbeats 0 in
set_option maxRecDepth 131072 in
theorem numbers : ∀ i : Fin 9,
    bookU (row i).edge (row i).beta 0 = (row i).erased ∧
    bookU (row i).edge (row i).beta (row i).rate = (row i).retained ∧
    rawQ (row i).nextEdge (row i).beta (row i).rate (row i).erased (row i).retained *
      100^39 / (94.17312:ℚ) ≤ ((row i).charge:ℚ)/10^18 := by
  intro i
  fin_cases i
  · exact scalar_row_00
  · exact scalar_row_01
  · exact scalar_row_02
  · exact scalar_row_03
  · exact scalar_row_04
  · exact scalar_row_05
  · exact scalar_row_06
  · exact scalar_row_07
  · exact scalar_row_08

#print axioms numbers
end PrimeGap180.LaterLowFixed
