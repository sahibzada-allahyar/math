import TrialPackedChannelGram180
import TrialFrozenChannels180

/-! Erasing a specific prime coordinate on the original signed spline
gives an explicit one-dimensional correlation in the packed 57-bit law.
The retained 38-dimensional channel product is kept outside that sum. -/
noncomputable section
open scoped Classical BigOperators
open PrimeGap180.DebitNativeClasses PrimeGap180.CoarseLaw PrimeGap180.FrozenProfile
open PrimeGap180.PackedLaw PrimeGap180.FrozenChannels PrimeGap180.NativeShellErasures
namespace PrimeGap180.PackedSingleFields
set_option maxRecDepth 5500
set_option maxHeartbeats 2000000
abbrev Hist := DebitNativeClasses.Class

def radialCoeff (J n : ℕ) (z : Term) : ℝ :=
  if h:n<37 then
    let c := capAt ⟨n,h⟩
    if J>min 130964 (T.maxIndex c) then 0 else coefficient T J c z
  else 0

def coefficientChange (J : ℕ) (c : Hist) (z : Term) :=
  radialCoeff J c.val z-radialCoeff J (c.val+1) z
def fullProduct (x : Fin 39 → Atom) (z : Term) := ∏ i,siteChannel z i (x i).1.val

theorem radial_value (x : Fin 39 → Atom) (n : ℕ) :
    radial x n=∑ z : Term,radialCoeff (retained x) n z*fullProduct x z := by
  unfold radial radialCoeff
  split
  next yes =>
    simp only [dite_eq_left yes]
    unfold raw
    change (if retained x>min 130964 (T.maxIndex (capAt ⟨n,yes⟩)) then 0 else _)=_
    by_cases cut : retained x>min 130964 (T.maxIndex (capAt ⟨n,yes⟩))
    · simp only [cut,ite_true,zero_mul,Finset.sum_const_zero]
    · simp only [cut,ite_false]
      exact amplitude_expansion T (fun i => (x i).1.val) (capAt ⟨n,yes⟩)
  next no => simp [no]

theorem delta_value (x : Fin 39 → Atom) (c : Hist) :
    delta x c=∑ z : Term,coefficientChange (retained x) c z*fullProduct x z := by
  rw [delta,radial_value,radial_value,←Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro z _
  exact (sub_mul _ _ _).symm

def retainedProduct (i : Fin 39) (t : Fin 38 → Atom) (z : Term) :=
  ∏ k,siteChannel z (i.succAbove k) (t k).1.val

theorem insertTotal (i : Fin 39) (t : Fin 38 → Atom) (a : Atom) :
    retained (i.insertNth (α := fun _ => Atom) a t)=a.1.val+retained t := by
  unfold retained; rw [Fin.sum_univ_succAbove _ i]; simp only [Fin.insertNth_apply_same,Fin.insertNth_apply_succAbove]

private theorem insertProduct (i : Fin 39) (t : Fin 38 → Atom) (z : Term) (a : Atom) :
    fullProduct (i.insertNth (α := fun _ => Atom) a t) z=
      siteChannel z i a.1.val*retainedProduct i t z := by
  unfold fullProduct retainedProduct
  rw [Fin.prod_univ_succAbove _ i]; simp only [Fin.insertNth_apply_same,Fin.insertNth_apply_succAbove]

def pointFactor (i : Fin 39) (J : ℕ) (c : Hist) (z : Term) (j : ℕ) :=
  100*coefficientChange (j+J) c z*siteChannel z i j

def erasedCoefficient (g : Grid) (i : Fin 39) (J : ℕ) (c : Hist) (z : Term) : ℝ :=
  ∑ j : Tick,Native.step*((g j c:ℝ)/(base:ℝ))*pointFactor i J c z j.val

theorem packed_erasure (g : Grid) (i : Fin 39) (t : Fin 38 → Atom) (c : Hist) :
    eraseDelta (ReferenceRoles.archive (law g)) i t c =
    ∑ z : Term,erasedCoefficient g i (retained t) c z*retainedProduct i t z := by
  let B (z : Term) (a : Atom) := if accepts a.2 c then law g a*pointFactor i (retained t) c z a.1.val else 0
  calc
    _ = ∑ a : Atom,∑ z : Term,B z a*retainedProduct i t z := by
      unfold eraseDelta
      apply Finset.sum_congr rfl
      intro a _
      by_cases on : accepts a.2 c=true
      · simp only [on,ite_true,B,delta_value,insertTotal,insertProduct,Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro z _
        unfold ReferenceRoles.archive pointFactor
        ring
      · simp [on,B]
    _ = ∑ z : Term,(∑ a : Atom,B z a)*retainedProduct i t z := by
      rw [Finset.sum_comm]
      exact Finset.sum_congr rfl fun _ _ => (Finset.sum_mul ..).symm
    _ = _ := by
      apply Finset.sum_congr rfl
      intro z _
      exact congrArg (·*retainedProduct i t z) (PackedMoments.site g c (pointFactor i (retained t) c z))

#print axioms packed_erasure
end PrimeGap180.PackedSingleFields
