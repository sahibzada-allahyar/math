import TrialDensityJoinedTriangles180
import TrialDensityFiveNumbers180

namespace PrimeGap180.DensitySimplex
open Horner

/-- One integer polynomial computation supplies all thirteen physical density
enclosures, including the already evaluated higher-row triangle terms. -/
theorem densities_of_five_coefficients
    (coefficients : degrees 4 (geometricTable 4 (12^5) fiveForms 10) = FiveChecks.common) :
    Terminal.DensityIntegrals := by
  apply FrozenNumbers.densities_of_values
  intro k hk
  cases k with
  | prime => exact (hk rfl).elim
  | sharp =>
    exact (fiveRun_correct _ (by norm_num)).trans
      ((FiveChecks.from_polynomial coefficients _).trans FiveChecks.sharp)
  | higher i =>
    have pos : 0 < 5*cutoffQ i-2 := by
      fin_cases i <;> norm_num [cutoffQ,PriceEvents.topTicks]
    change fiveQ (cutoffQ i) + triangleQ (TriangleChecks.r i) (TriangleChecks.s i) =
      FrozenNumbers.five (cutoffQ i) + FrozenNumbers.triangles i
    exact congrArg₂ (·+·) ((fiveRun_correct _ pos).trans
      ((FiveChecks.from_polynomial coefficients _).trans (FiveChecks.higher i))) (TriangleChecks.values i)

#print axioms densities_of_five_coefficients
end PrimeGap180.DensitySimplex
