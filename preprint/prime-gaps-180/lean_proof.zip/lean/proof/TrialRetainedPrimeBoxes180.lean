import TrialRetainedBoxSum180
import HarmanT3Distribution182
/-! Mellin and boundary transfer adapted from HarmanT3Distribution182, romyar1/prime-gaps-lean b77bf175bdedc5123027b3fcf0abc38427975770. Upstream adaptation credits Apache-2.0 PrimeGaps186. -/
noncomputable section
open scoped BigOperators Topology
open Filter PrimeGap186 PrimeGap182Audit PrimeGap182Analytic.Harman
open PrimeGap180.Distribution PrimeGap180.Central
namespace PrimeGap180.Retained
open Classical in
theorem closed_prime_boxes
    {density : ℕ} {a intensity cut «ω» v δ σb σ : ℝ}
    (g : CoefficientGuards density a intensity cut «ω» v δ σb σ)
    (block : Averaged.SelectedBlockEstimate) (rank4 : AllIncidenceRankFourBounds)
    (zpos : 23/100 ≤ 1-a-intensity) (ahi : a ≤ 42/100) (hθ : 1/2+2*«ω» ≤ 53/100) :
      ∀ A : ℝ, 0 < A → ∃ K X : ℝ, 0 < K ∧ Real.exp 1 ≤ X ∧
        ∀ x : ℝ, X ≤ x → ∀ L U : Fin 3 → ℝ,
          (∀ c, x ^ (1-a-intensity) ≤ L c) →
          (∀ c, L c ≤ U c ∧ U c ≤ 2 * L c) →
          (∀ c, U c ≤ x ^ a) →
        U 0 ≤ x^cut →
        ∀ I : Finset ℕ, (∀ p ∈ I, Nat.Prime p) →
        ∀ a₀ : ℕ, Nat.Coprime a₀ (∏ p ∈ I, p) →
          let Q := (Finset.Icc 1 ⌊x ^ (1 / 2 + 2 * «ω»)⌋₊).filter (fun q =>
            q ∣ (∏ p ∈ I, p) ∧
              Nonempty (DenseDivisibilityWitness
                ⟨max 1 (x ^ δ), by exact le_max_left (1 : ℝ) (x ^ δ)⟩ density q))
          (∑ q ∈ Q, ‖PrimeGap186.fullDiscrepancy
            ((primeIntervalBoxAlgebra L U Finset.univ).coeff.filter
              (fun n : ℕ => n ∈ Finset.Icc ⌈x⌉₊ ⌊2 * x⌋₊)) q a₀‖) ≤
            K * x / (Real.log x) ^ A := by
  intro A hA
  obtain ⟨Dr, hDr, Kr, Xr, hKr, hXr, hradial⟩ :=
    minorantHB_three_radial_error_moduli_log_saving A hA 0
  obtain ⟨Do, hDo, Ko, Xo, hKo, hXo, horiginal⟩ :=
    PrimeGap182Analytic.Harman.minorantHB_three_original_boundary_moduli_log_saving 0 A hA
  let D : ℕ := max Dr Do
  have hD : 1 ≤ D := hDr.trans (le_max_left _ _)
  obtain ⟨Ks, Xs, hKs, hXs, hselected⟩ :=
    selected_box_sum g block rank4 zpos ahi D hD A hA
  obtain ⟨Km, Xm, hKm, hXm, hmellin⟩ :=
    three_closed_prime_box_mellin_transfer (23 / 100) (42 / 100) (53 / 100)
      (by norm_num) (by norm_num) (by norm_num) (by norm_num) 0 A hA
  let Kraw : ℝ := Ks + Kr + Ko
  let X : ℝ := max (max Xr Xo) (max Xs Xm)
  refine ⟨1000 * Kraw + Km, X, ?_, ?_, ?_⟩
  · dsimp only [Kraw]
    positivity
  · exact hXr.trans ((le_max_left Xr Xo).trans (le_max_left _ _))
  intro x hx L U hLwide hLU hUwide hcap I hI a₀ ha₀ Q
  have hxr : Xr ≤ x := ((le_max_left Xr Xo).trans (le_max_left _ _)).trans hx
  have hxo : Xo ≤ x := ((le_max_right Xr Xo).trans (le_max_left _ _)).trans hx
  have hxs : Xs ≤ x := ((le_max_left Xs Xm).trans (le_max_right _ _)).trans hx
  have hxm : Xm ≤ x := ((le_max_right Xs Xm).trans (le_max_right _ _)).trans hx
  have hxexp : Real.exp 1 ≤ x := hXr.trans hxr
  have hxone : 1 < x := (Real.one_lt_exp_iff.mpr zero_lt_one).trans_le hxexp
  have hxpos : 0 < x := zero_lt_one.trans hxone
  have hlogpos : 0 < Real.log x := Real.log_pos hxone
  have hscale (c : Fin 3) :
      x ^ ((23 : ℝ) / 100) ≤ L c ∧ L c ≤ x ^ ((42 : ℝ) / 100) := by
    refine ⟨?_, (hLU c).1.trans ((hUwide c).trans ?_)⟩
    · exact (Real.rpow_le_rpow_of_exponent_le hxone.le
        zpos).trans (hLwide c)
    · exact Real.rpow_le_rpow_of_exponent_le hxone.le ahi
  have hLone (c : Fin 3) : 1 ≤ L c :=
    (Real.one_le_rpow hxone.le (by norm_num : (0 : ℝ) ≤ 23 / 100)).trans (hscale c).1
  have hQ : Q ⊆ Finset.Icc 1 ⌊x ^ ((53 : ℝ) / 100)⌋₊ := by
    intro q hq
    obtain ⟨hrange, _hdvd, _hdd⟩ := Finset.mem_filter.mp hq
    obtain ⟨hqone, hqhi⟩ := Finset.mem_Icc.mp hrange
    exact Finset.mem_Icc.mpr ⟨hqone, hqhi.trans
      (Nat.floor_mono (Real.rpow_le_rpow_of_exponent_le hxone.le hθ))⟩
  have hcop (q : ℕ) (hq : q ∈ Q) : Nat.Coprime a₀ q :=
    Nat.Coprime.of_dvd_right (Finset.mem_filter.mp hq).2.1 ha₀
  have hmask (n : ℕ) :
      (x ≤ (n : ℝ) ∧ (n : ℝ) ≤ 2 * x) ↔ n ∈ Finset.Icc ⌈x⌉₊ ⌊2 * x⌋₊ := by
    rw [Finset.mem_Icc, Nat.ceil_le, Nat.le_floor_iff (by positivity : (0 : ℝ) ≤ 2 * x)]
  have hfilter (f : ℕ →₀ ℂ) :
      f.filter (fun n : ℕ => x ≤ (n : ℝ) ∧ (n : ℝ) ≤ 2 * x) =
        f.filter (fun n : ℕ => n ∈ Finset.Icc ⌈x⌉₊ ⌊2 * x⌋₊) := by
    ext n
    simp only [Finsupp.filter_apply, hmask]
  have hraw (t : Fin 3 → ℝ) (ht : ∀ c, 0 ≤ t c) (htten : ∀ c, t c ≤ 10) :
      (∑ q ∈ Q, (q.divisors.card : ℝ) ^ 0 * ‖fullDiscrepancy
        (((∏ c : Fin 3, (MonoidAlgebra.ofCoeff
          (minorantHBClosedMangoldt (L c) (U c) (t c)) : MonoidAlgebra ℂ ℕ)).coeff).filter
            (fun n : ℕ => n ∈ Finset.Icc ⌈x⌉₊ ⌊2 * x⌋₊)) q a₀‖) ≤
          Kraw * x / (Real.log x) ^ A := by
    let Θ : ℝ := 1 + (Real.log x) ^ (-(D : ℝ))
    let Uhb : ℝ := x ^ ((9 : ℝ) / 100)
    let boxes (r : Fin 3 → Fin 5) :=
      Fintype.piFinset (fun c : Fin 3 => minorantHBBoxes ((r c).val + 1) (L c) (U c) Θ)
    let β (r : Fin 3 → Fin 5)
        (ν : (c : Fin 3) → Fin (2 * ((r c).val + 1)) → ℕ) : ℕ →₀ ℂ :=
      (∏ s : Σ c : Fin 3, Fin (2 * ((r c).val + 1)),
        minorantHBLocalizedSlot ((r s.1).val + 1) Uhb Θ (t s.1) (ν s.1) s.2).coeff
    let P (r : Fin 3 → Fin 5)
        (ν : (c : Fin 3) → Fin (2 * ((r c).val + 1)) → ℕ) : ℝ :=
      ∏ s : Σ c : Fin 3, Fin (2 * ((r c).val + 1)), Θ ^ ν s.1 s.2
    let selected : ℕ →₀ ℂ :=
      ∑ r : Fin 3 → Fin 5,
        (∏ c : Fin 3,
          (((-1 : ℝ) ^ (r c).val * ((5 : ℕ).choose ((r c).val + 1) : ℝ) : ℝ) : ℂ)) •
            ∑ ν ∈ (boxes r).filter
              (fun ν => x * Θ ^ 30 ≤ P r ν ∧ P r ν * Θ ^ 30 ≤ 2 * x), β r ν
    let G : ℕ →₀ ℂ :=
      (∏ c : Fin 3, (MonoidAlgebra.ofCoeff
        (minorantHBUnmaskedFive (L c) (U c) Uhb Θ (t c)) : MonoidAlgebra ℂ ℕ)).coeff
    let F : ℕ →₀ ℂ :=
      (∏ c : Fin 3, (MonoidAlgebra.ofCoeff
        (minorantHBClosedMangoldt (L c) (U c) (t c)) : MonoidAlgebra ℂ ℕ)).coeff
    let R : ℕ →₀ ℂ :=
      G.filter (fun n : ℕ => x ≤ (n : ℝ) ∧ (n : ℝ) ≤ 2 * x) - selected
    let E : ℕ →₀ ℂ :=
      (G - F).filter (fun n : ℕ => x ≤ (n : ℝ) ∧ (n : ℝ) ≤ 2 * x)
    have hs : (∑ q ∈ Q, ‖fullDiscrepancy selected q a₀‖) ≤
        Ks * x / (Real.log x) ^ A :=
      hselected x hxs t ht htten L U hLwide (fun c => (hLU c).1) hUwide hcap I hI a₀ ha₀
    have hr : (∑ q ∈ Q, ‖fullDiscrepancy R q a₀‖) ≤
        Kr * x / (Real.log x) ^ A := by
      simpa only [pow_zero, one_mul] using
        hradial x hxr D (le_max_left Dr Do) L U t Uhb hLone
          (fun c => (hLU c).1) ht htten Q hQ (fun _ => a₀) hcop
    have he : (∑ q ∈ Q, ‖fullDiscrepancy E q a₀‖) ≤
        Ko * x / (Real.log x) ^ A := by
      simpa only [pow_zero, one_mul] using
        horiginal x hxo D (le_max_right Dr Do) L L U t hscale
          (fun c => ⟨le_rfl, (hLU c).1, (hLU c).2⟩)
          (fun c => ⟨ht c, htten c⟩) Q hQ (fun _ => a₀) hcop
    have hF : F.filter (fun n : ℕ => n ∈ Finset.Icc ⌈x⌉₊ ⌊2 * x⌋₊) =
        selected + R - E := by
      rw [← hfilter F]
      dsimp only [R, E]
      rw [Finsupp.filter_sub]
      abel
    let kernel : ℕ → ℕ → ℂ := fun q n =>
      (if n % q = a₀ % q then 1 else 0) -
        (if Nat.Coprime n q then 1 else 0) / (q.totient : ℂ)
    have hfull (f : ℕ →₀ ℂ) (q : ℕ) :
        fullDiscrepancy f q a₀ = f.sum (fun n z => z * kernel q n) := by
      change fullDiscrepancy f q a₀ = ∑ n ∈ f.support, f n * kernel q n
      simp only [fullDiscrepancy, progressionMass, reducedMass, kernel,
        div_eq_mul_inv, mul_sub, mul_ite, ite_mul, one_mul, mul_one,
        zero_mul, mul_zero, Finset.sum_sub_distrib, Finset.sum_mul]
    have hlinear (q : ℕ) :
        fullDiscrepancy (F.filter (fun n : ℕ => n ∈ Finset.Icc ⌈x⌉₊ ⌊2 * x⌋₊)) q a₀ =
          fullDiscrepancy selected q a₀ + fullDiscrepancy R q a₀ -
            fullDiscrepancy E q a₀ := by
      rw [hF]
      simp only [hfull]
      rw [Finsupp.sum_sub_index (fun _ _ _ => sub_mul _ _ _),
        Finsupp.sum_add_index' (fun _ => zero_mul _) (fun _ _ _ => add_mul _ _ _)]
    simp only [pow_zero, one_mul]
    change (∑ q ∈ Q, ‖fullDiscrepancy
      (F.filter (fun n : ℕ => n ∈ Finset.Icc ⌈x⌉₊ ⌊2 * x⌋₊)) q a₀‖) ≤ _
    calc
      _ ≤ ∑ q ∈ Q, (‖fullDiscrepancy selected q a₀‖ +
          ‖fullDiscrepancy R q a₀‖ + ‖fullDiscrepancy E q a₀‖) := by
        apply Finset.sum_le_sum
        intro q _hq
        rw [hlinear]
        exact (norm_sub_le _ _).trans (add_le_add (norm_add_le _ _) le_rfl)
      _ ≤ Ks * x / (Real.log x) ^ A + Kr * x / (Real.log x) ^ A +
          Ko * x / (Real.log x) ^ A := by
        rw [Finset.sum_add_distrib, Finset.sum_add_distrib]
        exact add_le_add (add_le_add hs hr) he
      _ = Kraw * x / (Real.log x) ^ A := by dsimp only [Kraw]; ring
  have hprime := hmellin x hxm L U hscale hLU Q hQ (fun _ => a₀) hcop
    (Kraw * x / (Real.log x) ^ A) hraw
  simp only [pow_zero, one_mul] at hprime
  calc
    _ ≤ 1000 * (Kraw * x / (Real.log x) ^ A) + Km * x / (Real.log x) ^ A := hprime
    _ = (1000 * Kraw + Km) * x / (Real.log x) ^ A := by ring


#print axioms closed_prime_boxes
end PrimeGap180.Retained
