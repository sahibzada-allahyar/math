import TrialRestorationCharge180
import TrialRestorationMassBudget180

/-! Physical integrals that suffice for the restoration hypothesis in the diameter-180
theorem. All signs and all 24 group allocations are carried by the actual spline. -/
noncomputable section
open scoped Classical BigOperators
open MeasureTheory PrimeGap186 PrimeGap180.Sector PrimeGap180.CoarseLaw PrimeGap180.SignedErasure
open PrimeGap180.RestorationCharge PrimeGap180.RestorationRows
namespace PrimeGap180.RestorationBudget

local instance : IsFiniteMeasure μ := bandLaw_finite _
open private intg whole_sum pair_regular from TrialRestorationField180
open private layer_regular from TrialGateDeletion180

def negativePair (x : Full) := -RestorationField.pair x
def singles (x : Full) := rho*(∑ i : Fin 39, ∑ s : Fin 521,RestorationField.single i s x)
def joint (g : Fin 24) := 2*(∫ x : Full,GateDeletion.layer (.group g) x * singles x ∂prod 39) +
  weightGroup g - 0.6865*StructuralRun.layerMass g

private theorem pair_reg' : PhysicalDebit.Regular negativePair :=
  continuous_reg pair_regular (fun t => -t) (by fun_prop)
private theorem singles_reg : PhysicalDebit.Regular singles :=
  continuous_reg whole_sum (fun t => rho*t) (by fun_prop)

theorem joint_and_pair (g : Fin 24) (t : ℝ) (ht : 0 < t) : charge g ≤ joint g +
    t*StructuralRun.layerMass g + (1/t)*restrictedSq g negativePair := by
  let f := GateDeletion.layer (.group g)
  have fr : PhysicalDebit.Regular f := layer_regular _
  have h := young g negativePair pair_reg' t ht
  have mixed : RestorationField.groupMixed g =
      (∫ x : Full,f x*singles x ∂prod 39) + (∫ x : Full,f x*negativePair x ∂prod 39) := by
    rw [←integral_add (intg _ (prod_reg fr singles_reg)) (intg _ (prod_reg fr pair_reg'))]
    apply integral_congr_ae
    apply ae_of_all
    intro x
    change f x*(singles x+negativePair x) = _
    ring
  unfold charge joint
  rw [mixed]
  linarith only [h]

/-- Low and high group energies, followed by the three physical measurements for each
middle group. The image terms are squared norms on the support of the deleted group. -/
structure PhysicalBounds : Prop where
  lowMass : StructuralRun.layerMass 0 ≤ ticks 3509670 * originalMass
  lowImage : imageSq 0 ≤ ticks 1196124 * originalMass
  highMass : StructuralRun.layerMass 23 ≤ ticks 4135470 * originalMass
  highImage : imageSq 23 ≤ ticks 179904296 * originalMass
  middleMass (i : Fin 22) : StructuralRun.layerMass (middle i) ≤ ticks (rows i).mass * originalMass
  middlePair (i : Fin 22) : restrictedSq (middle i) negativePair ≤ ticks (rows i).pairImage * originalMass
  middleJoint (i : Fin 22) : joint (middle i) ≤ ticks (rows i).joint * originalMass

private theorem middle_paid (b : PhysicalBounds) (i : Fin 22) :
    charge (middle i) ≤ ticks (rows i).cost * originalMass := by
  let t : ℝ := (rows i).young/1000000
  obtain ⟨ht,cap⟩ := terms i
  have one :=  joint_and_pair (middle i) t ht
  have upper := add_le_add (add_le_add (b.middleJoint i)
    (mul_le_mul_of_nonneg_left (b.middleMass i) ht.le))
    (mul_le_mul_of_nonneg_left (b.middlePair i) (one_div_nonneg.mpr ht.le))
  have M : 0 ≤ originalMass := integral_nonneg fun _ => sq_nonneg _
  calc
    _ ≤ ticks (rows i).joint*originalMass + t*(ticks (rows i).mass*originalMass) +
          (1/t)*(ticks (rows i).pairImage*originalMass) := one.trans upper
    _ = (ticks (rows i).joint + t*ticks (rows i).mass + (1/t)*ticks (rows i).pairImage)*originalMass := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_right cap M

private theorem outer_paid (b : PhysicalBounds) : charge 0 + charge 23 ≤ ticks 68691896 * originalMass := by
  have lo := uniform_group (0:Fin 24) (3/5) (by norm_num)
  have hi := uniform_group (23:Fin 24) (13/2) (by norm_num)
  have a := b.lowMass
  have c := b.lowImage
  have d := b.highMass
  have f := b.highImage
  have M : 0 ≤ originalMass := integral_nonneg fun _ => sq_nonneg _
  unfold ticks at a c d f ⊢
  norm_num1 at lo hi
  linarith only [lo,hi,a,c,d,f,M]

theorem payment (b : PhysicalBounds) : NumericalAccount.restoredLoss ≤ ticks 1104022945 * originalMass := by
  have outer := outer_paid b
  have mid := Finset.sum_le_sum (s := Finset.univ) (fun i _ => middle_paid b i)
  rw [←Finset.sum_mul] at mid
  have sum : (∑ i : Fin 22, ticks (rows i).cost) = ticks 1035331049 := by
    unfold ticks
    rw [←Finset.sum_div,←Nat.cast_sum,total]
  rw [sum] at mid
  have h := grouped
  rw [splitGroups] at h
  unfold ticks at mid outer ⊢
  linarith only [h,outer,mid]

theorem removed (b : PhysicalBounds) : NumericalAccount.restoredLoss ≤
    (0.000071406420 + 0.001035091858) * NumericalAccount.mass Restoration.original := by
  have h := payment b
  have M : 0 ≤ originalMass := integral_nonneg fun _ => sq_nonneg _
  change _ ≤ _ * originalMass
  unfold ticks at h
  linarith only [h,M]

/-- The same mass rows also give the second deletion input in the final 180 theorem. -/
theorem removed_mass (b : PhysicalBounds) :
    NumericalAccount.mass Restoration.deleted ≤ 0.000160674 * originalMass := by
  have h := deleted_bound b.lowMass b.middleMass b.highMass
  have M : 0 ≤ originalMass := integral_nonneg fun _ => sq_nonneg _
  unfold ticks at h
  linarith only [h,M]

#print axioms removed_mass
#print axioms payment
#print axioms removed
end PrimeGap180.RestorationBudget
