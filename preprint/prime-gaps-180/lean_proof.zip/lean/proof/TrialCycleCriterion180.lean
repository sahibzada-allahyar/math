import TrialMatrixBlock180

/-! Pass the punctured completion bound on actual signed interval cycles
to the matrix hypothesis consumed by the sampled distribution theorem. -/
noncomputable section
open scoped BigOperators Classical Matrix.Norms.L2Operator
open PrimeGap182.TypeIII
namespace PrimeGap180.Averaged

def cycleScale (M R P : ℝ) :=
  R^2 * M^3 * P^2 + R^2 * M^4 * P * Real.sqrt P +
  R * M^4 * P^2 + M^4 * P^3 + M^3 * P^(7/2 : ℝ)

def IntervalCycleEstimate : Prop :=
  ∀ {ε : ℝ}, 0 < ε → ∃ K : ℝ, 0 < K ∧
    ∀ {ι : Type} [Fintype ι] [DecidableEq ι] (q : ι → ℕ)
      [∀ i, Fact (q i).Prime] [NeZero (∏ i, q i)],
      Pairwise (fun i j => (q i).Coprime (q j)) →
      ∀ (α : ∀ i, ZMod (q i)), (∀ i, α i ≠ 0) →
      ∀ (A B Ah Ak : ℤ) (M R : ℕ), 0 < R →
      (∑ i ∈ Finset.Ico A (A+M), ∑ i' ∈ Finset.Ico A (A+M),
        ∑ j ∈ Finset.Ico B (B+M), ∑ j' ∈ Finset.Ico B (B+M),
          ‖intervalRectangleSum (∏ i, q i) Ah Ak R R (integerFourCycle q α i i' j j')‖) ≤
        K * ((∏ i, q i : ℕ) : ℝ)^ε * cycleScale M R (∏ i, q i : ℕ)

theorem cycleScale_quarter_root {M R P : ℝ} (hm : 0 ≤ M) (hr : 0 < R) (hp : 1 ≤ P) :
    (cycleScale M R P / R^2)^(1/4 : ℝ) ≤ (2:ℝ)^(1/4 : ℝ)*matrixFourScale M R P := by
  have hp0 := zero_lt_one.trans_le hp
  let old := M^3 * P^2 + M^4 * P^3 / R^2 + M^4 * P * Real.sqrt P
  let extra := M^3 * P^(7/2 : ℝ) / R^2
  have ho : 0 ≤ old := by dsimp [old]; positivity
  have he : 0 ≤ extra := by dsimp [extra]; positivity
  have hmix : R*M^4*P^2 ≤ M^4*P^3 + R^2*M^4*P*Real.sqrt P := by
    rcases le_total R P with h | h
    · calc
        _ ≤ P*M^4*P^2 := by gcongr
        _ = M^4*P^3 := by ring
        _ ≤ _ := le_add_of_nonneg_right (by positivity)
    · have hroot : 1 ≤ Real.sqrt P := by simpa using Real.sqrt_le_sqrt hp
      calc
        _ = R*M^4*P*P := by ring
        _ ≤ R*M^4*P*R := by gcongr
        _ = R^2*M^4*P := by ring
        _ ≤ R^2*M^4*P*Real.sqrt P := le_mul_of_one_le_right (by positivity) hroot
        _ ≤ _ := le_add_of_nonneg_left (by positivity)
  have hdiv : cycleScale M R P / R^2 ≤ 2*(old+extra) := by
    apply (div_le_iff₀ (sq_pos_of_pos hr)).mpr
    dsimp [old, extra, cycleScale]
    field_simp [hr.ne']
    nlinarith only [hmix, mul_nonneg (mul_nonneg (sq_nonneg R) (pow_nonneg hm 3)) (sq_nonneg P),
      mul_nonneg (pow_nonneg hm 3) (Real.rpow_nonneg hp0.le (7/2 : ℝ))]
  have heq : extra^(1/4 : ℝ) = matrixExtra M R P := by
    dsimp [extra, matrixExtra]
    rw [Real.div_rpow (by positivity) (by positivity), Real.mul_rpow (by positivity) (by positivity),
      ← Real.rpow_natCast_mul hm, ← Real.rpow_mul hp0.le, ← Real.rpow_natCast_mul hr.le]
    norm_num
  apply (Real.rpow_le_rpow (by dsimp [cycleScale]; positivity) hdiv (by norm_num : 0 ≤ (1/4 : ℝ))).trans
  rw [Real.mul_rpow (by norm_num) (add_nonneg ho he)]
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  exact (Real.rpow_add_le_add_rpow ho he (by norm_num) (by norm_num)).trans
    (add_le_add (matrix_three_monomials_quarter_root hm hr hp0.le) heq.le)

theorem cyclesToMatrix (hc : IntervalCycleEstimate) : MatrixEstimate := by
  intro ε he
  obtain ⟨K,hk,bound⟩ := hc (show 0 < 4*ε by positivity)
  refine ⟨K^(1/4 : ℝ)*2^(1/4 : ℝ), by positivity, ?_⟩
  intro ι _ _ q _ _ cp α ha A B Ah Ak M R hr
  let P : ℝ := (∏ i, q i : ℕ)
  have hp : 1 ≤ P := by dsimp only [P]; exact_mod_cast (NeZero.one_le : 1 ≤ ∏ i, q i)
  have hp0 := zero_lt_one.trans_le hp
  have hR : (0:ℝ) < R := Nat.cast_pos.mpr hr
  have hh := (integerKernelMatrix_sum_fourth_le_cycles q α A B Ah Ak M M R R).trans
    (bound q cp α ha A B Ah Ak M R hr)
  have h := Real.rpow_le_rpow (div_nonneg
    (Finset.sum_nonneg (fun _ _ => Finset.sum_nonneg (fun _ _ => by positivity))) (sq_nonneg (R:ℝ)))
    (div_le_div_of_nonneg_right hh (sq_nonneg (R:ℝ))) (by norm_num : 0 ≤ (1/4 : ℝ))
  apply h.trans
  change (K * P^(4*ε) * cycleScale M R P / (R:ℝ)^2) ^ (1/4 : ℝ) ≤ _
  rw [mul_div_assoc, Real.mul_rpow (by positivity) (by unfold cycleScale; positivity),
      Real.mul_rpow hk.le (Real.rpow_nonneg hp0.le _), ← Real.rpow_mul hp0.le,
      show 4*ε*(1/4 : ℝ) = ε by ring]
  calc
    _ ≤ (K^(1/4 : ℝ)*P^ε) * ((2:ℝ)^(1/4 : ℝ) * matrixFourScale M R P) :=
      mul_le_mul_of_nonneg_left (cycleScale_quarter_root (Nat.cast_nonneg M) hR hp) (by positivity)
    _ = _ := by dsimp only [P]; ring

#print axioms cyclesToMatrix
end PrimeGap180.Averaged
