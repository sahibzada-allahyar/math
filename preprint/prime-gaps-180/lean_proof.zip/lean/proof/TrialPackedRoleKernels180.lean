import TrialPackedPairFields180
import TrialSignedCapContractions180

/-! Exact coefficients of the retained Gram polynomials used by the five
native forms. The lower and upper cap rows differ by a signed price jump. -/
noncomputable section
open scoped Classical BigOperators Polynomial
open Polynomial PrimeGap180.DebitNativeClasses PrimeGap180.PackedLaw PrimeGap180.NativeShellErasures
open PrimeGap180.FrozenChannels PrimeGap180.SignedCapContractions PrimeGap180.PackedSingleFields
namespace PrimeGap180.PackedRoleKernels
set_option maxRecDepth 5500
set_option maxHeartbeats 1600000

private theorem bank_linear {I : Type*} [Fintype I] (A : Hist → I → ℝ) (v : I → ℝ) (k : ℕ) :
    bank (fun c => ∑ z,A c z * v z) k = ∑ z,bank (fun c => A c z) k * v z := by
  calc
    _ = ∑ c : Hist,∑ z,(if k ≤ c.val then A c z else 0)*v z := by
      unfold bank
      apply Finset.sum_congr rfl
      intro c _
      by_cases used : k ≤ c.val <;> simp [used]
    _ = ∑ z,∑ c : Hist,(if k ≤ c.val then A c z else 0)*v z := Finset.sum_comm
    _ = _ := by simp only [bank,Finset.sum_mul]

def singleField (g : Grid) (i : Fin 39) (J k : ℕ) (z : Term) :=
  bank (fun c => erasedCoefficient g i J c z) k

def pairField (g : Grid) (J k : ℕ) (z : Term) :=
  bank (fun c => PackedPairFields.pairCoefficient g J c z) k

theorem single_bank (g : Grid) (i : Fin 39) (t : Fin 38 → Atom) (k : ℕ) :
    bank (eraseDelta (ReferenceRoles.archive (law g)) i t) k =
      ∑ z : Term,singleField g i (retained t) k z * retainedProduct i t z := by
  have eq : eraseDelta (ReferenceRoles.archive (law g)) i t =
      (fun c => ∑ z : Term,erasedCoefficient g i (retained t) c z*retainedProduct i t z) := by
    funext c
    exact PackedSingleFields.packed_erasure g i t c
  rw [eq]
  exact bank_linear (fun c z => erasedCoefficient g i (retained t) c z) (retainedProduct i t) k

theorem pair_bank (g : Grid) (t : Fin 37 → Atom) (k : ℕ) :
    bank (NativePairUpdates.addPair (ReferenceRoles.archive (law g)) t) k =
      ∑ z : Term,pairField g (retained t) k z * PackedPairFields.features t z := by
  have eq : NativePairUpdates.addPair (ReferenceRoles.archive (law g)) t =
      (fun c => ∑ z : Term,PackedPairFields.pairCoefficient g (retained t) c z*PackedPairFields.features t z) := by
    funext c
    exact PackedPairFields.packed_erasure g t c
  rw [eq]
  exact bank_linear (fun c z => PackedPairFields.pairCoefficient g (retained t) c z) (PackedPairFields.features t) k

def singleGram (g : Grid) (i : Fin 39) (c : Hist) (J k : ℕ) :=
  ∑ u : Term,∑ v : Term,singleField g i J k u*singleField g i J k v*
    (∏ q : Fin 38,PackedChannelGram.moment g c (fun j => siteChannel u (i.succAbove q) j*
      siteChannel v (i.succAbove q) j)).coeff J

def pairGram (g : Grid) (c : Hist) (J k : ℕ) :=
  ∑ u : Term,∑ v : Term,pairField g J k u*pairField g J k v*
    (∏ q : Fin 37,PackedChannelGram.moment g c (fun j => siteChannel u q.castSucc.succ j*
      siteChannel v q.castSucc.succ j)).coeff J

theorem single_square (g : Grid) (i : Fin 39) (c : Hist) (J k : ℕ) :
    (∑ t : Fin 38 → Atom,if retained t=J ∧ below t c then
      (bank (eraseDelta (ReferenceRoles.archive (law g)) i t) k)^2 * ∏ j,law g (t j) else 0) =
    singleGram g i c J k := by
  rw [singleGram,←PackedChannelGram.gram g c J (singleField g i J k) (fun z q j => siteChannel z (i.succAbove q) j)]
  apply Finset.sum_congr rfl
  intro t _
  by_cases ok : retained t=J ∧ below t c
  · rw [if_pos ok,if_pos ok,single_bank,ok.1]
    rfl
  · simp [ok]

theorem pair_square (g : Grid) (c : Hist) (J k : ℕ) :
    (∑ t : Fin 37 → Atom,if retained t=J ∧ below t c then
      (bank (NativePairUpdates.addPair (ReferenceRoles.archive (law g)) t) k)^2 * ∏ j,law g (t j) else 0) =
    pairGram g c J k := by
  rw [pairGram,←PackedChannelGram.gram g c J (pairField g J k) (fun z q j => siteChannel z q.castSucc.succ j)]
  apply Finset.sum_congr rfl
  intro t _
  by_cases ok : retained t=J ∧ below t c
  · rw [if_pos ok,if_pos ok,pair_bank,ok.1]
    rfl
  · simp [ok]

#print axioms single_square
#print axioms pair_square
end PrimeGap180.PackedRoleKernels
