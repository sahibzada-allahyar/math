import TrialMarkEligibility180
import TrialAdjacentTriple180
import TrialAdjacentPartition180
import TrialRoughPartition180

/-! The archived radius, counting margin and one carrier work for every
remaining roughness and adjacent band row across all 521 sector bounds. -/
noncomputable section
namespace PrimeGap180.Marked

inductive AdjacentOrRough
  | rough (resource : Rough.Resource)
  | five (row : Fin 11)
  | triple (row : Fin 11) (band : Bool)

def AdjacentOrRough.threshold : AdjacentOrRough → ℝ
  | .rough u => Rough.exponent u
  | .five row => EventBins.lower (FiveMarks.top row.succ)
  | .triple row _ => TripleAdjacent.lo row.succ

def AdjacentOrRough.markTop : AdjacentOrRough → ℝ
  | .rough _ => 0
  | .five row => FiveMarks.top row.succ
  | .triple row b => TripleAdjacent.U row b

private theorem frozen_lows (row : Fin 12) :
    (28:ℝ)/100 ≤ TripleAdjacent.lo row ∧ TripleAdjacent.lo row ≤ 3/10 := by
  fin_cases row <;> norm_num [TripleAdjacent.lo,PriceEvents.lowTicks]

private theorem frozen_highs (row : Fin 12) : FiveMarks.top row ≤ 0.41657 := by
  fin_cases row <;> norm_num [FiveMarks.top,PriceEvents.topTicks]

theorem AdjacentOrRough.range (e : AdjacentOrRough) :
    Sector.physicalCap < e.threshold ∧ e.markTop ≤ 0.41657 := by
  cases e with
  | five row =>
    exact ⟨by dsimp [threshold,Sector.physicalCap,EventBins.lower]; linarith only [frozen_highs row.succ],
      frozen_highs row.succ⟩
  | triple row t =>
    constructor
    · dsimp only [threshold,Sector.physicalCap]
      linarith only [(frozen_lows row.succ).1]
    · cases t
      · change TripleAdjacent.lo row.castSucc ≤ _
        linarith only [(frozen_lows row.castSucc).2]
      · exact frozen_highs row.succ
  | rough e =>
    refine ⟨?_,by norm_num [markTop]⟩
    cases e with
    | prime => norm_num [threshold,Rough.exponent,Sector.physicalCap]
    | old => norm_num [threshold,Rough.exponent,Sector.physicalCap]
    | all =>
      dsimp only [threshold,Rough.exponent,Sector.physicalCap]
      linarith only [frozen_highs 11]
    | primeThree i =>
      change Sector.physicalCap < TripleAdjacent.lo i
      dsimp only [Sector.physicalCap]
      linarith only [(frozen_lows i).1]

/-- At the same frozen sector cap, a mark-weight allowance of one
ten-thousandth still leaves strictly positive counting margin. -/
theorem frozen_mark_radii (row : AdjacentOrRough) {q : ℝ} (hq : q ≤ 0.2801) :
    let ξ := row.threshold
    let s := row.markTop
    let ζ := min ξ ((1-s)/2-q)-0.0001
    let κ := max Sector.physicalCap (ξ-0.0001)/Sector.rho
    0 < ζ ∧ ζ < ξ ∧ Sector.cap ≤ κ ∧ ζ/Sector.rho ≤ κ ∧ Sector.rho*κ < ξ ∧
      s+0.0001+2*(q+ζ) < 1 := by
  intro ξ s ζ κ
  have span := row.range
  have ξlo : 0.0001 < ξ := by
    change 0.0001 < row.threshold
    exact lt_trans (by norm_num [Sector.physicalCap] : (0.0001:ℝ) < Sector.physicalCap) span.1
  have room : 0.0001 < (1-s)/2-q := by
    dsimp only [s]
    linarith only [span.2,hq]
  obtain ⟨p,u,c,z,b,r⟩ := price_radius (by norm_num : (0:ℝ) < 0.0001) ξlo room span.1
  exact ⟨p,u,c,z,b,lt_of_le_of_lt r (by norm_num)⟩

#print axioms frozen_mark_radii
end PrimeGap180.Marked
