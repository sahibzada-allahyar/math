import PrimeGaps186

/-! From the inclusive fragment tails of two retained roots to the
dense-divisibility witness on a descendant coefficient modulus, with presieve. -/
noncomputable section
open scoped BigOperators NNReal
open PrimeGap186
namespace PrimeGap180.Gate

def tail (R : ℝ) (n p : ℕ) : ℝ≥0 :=
  (n.primeFactors.filter (fun q => p ≤ q)).sum (logFragment R)

theorem tail_mono {R : ℝ} {d X p : ℕ} (hd : d ∣ X) (hx : X ≠ 0) :
    tail R d p ≤ tail R X p :=
  Finset.sum_le_sum_of_subset (Finset.filter_subset_filter _ (Nat.primeFactors_mono hd hx))

private theorem factors_lcm {d e : ℕ} (hd : d ≠ 0) (he : e ≠ 0) :
    (d.lcm e).primeFactors = d.primeFactors ∪ e.primeFactors := by
  simpa only [Finsupp.support_sup, Nat.support_factorization] using
    congrArg Finsupp.support (Nat.factorization_lcm hd he)

theorem tail_lcm_le (R : ℝ) {d e p : ℕ} (hd : d ≠ 0) (he : e ≠ 0) :
    tail R (d.lcm e) p ≤ tail R d p + tail R e p := by
  simp only [tail, factors_lcm hd he, Finset.filter_union]
  have h := Finset.sum_union_inter (s₁ := d.primeFactors.filter (fun q => p ≤ q))
    (s₂ := e.primeFactors.filter (fun q => p ≤ q)) (f := logFragment R)
  exact (le_add_of_nonneg_right (by positivity)).trans h.le

private theorem tail_at_factor (R : ℝ) {n p : ℕ} (hp : p ∈ n.primeFactors) :
    tail R n p = primeFragmentSuffix R n p + logFragment R p := by
  have eq : n.primeFactors.filter (fun q => p ≤ q) =
      insert p (n.primeFactors.filter (fun q => p < q)) := by
    ext q
    simp only [Finset.mem_filter, Finset.mem_insert]
    constructor
    · rintro ⟨hq, h⟩
      rcases h.eq_or_lt with he|hl
      · exact Or.inl he.symm
      · exact Or.inr ⟨hq,hl⟩
    · rintro (rfl|⟨hq,hl⟩)
      · exact ⟨hp, le_rfl⟩
      · exact ⟨hq,hl.le⟩
  simp [tail, eq, primeFragmentSuffix, add_comm]

private theorem owner_le {R ξ U : ℝ} {d X : ℕ}
    (hR : 1 < R) (hU : 0 ≤ U) (hd : d ∣ X) (hX : X ≠ 0)
    (bound : ∀ p ∈ activatedPrimeFactors R ξ X,
      (tail R X p : ℝ) + logSize R p ≤ U) : (primeFragmentOwner id R ξ d : ℝ) ≤ U := by
  let u : ℝ≥0 := ⟨U,hU⟩
  change (↑(primeFragmentOwner id R ξ d) : ℝ) ≤ (u : ℝ)
  apply NNReal.coe_le_coe.mpr
  apply Finset.sup_le
  intro p hp
  obtain ⟨hpd, hact⟩ := Finset.mem_filter.mp hp
  have hpx := Nat.primeFactors_mono hd hX hpd
  have hh := bound p (Finset.mem_filter.mpr ⟨hpx,hact⟩)
  have ht : (tail R d p : ℝ) ≤ tail R X p := by exact_mod_cast tail_mono hd hX
  apply NNReal.coe_le_coe.mp
  change ((primeFragmentSuffix R d p + logFragment R p + logFragment R p : ℝ≥0) : ℝ) ≤ U
  rw [← tail_at_factor R hpd, NNReal.coe_add, coe_logFragment R hR
    (Nat.pos_of_mem_primeFactors hpd)]
  exact (add_le_add_left ht (logSize R p)).trans hh

/-- A test at every activated prime of either physical root gives the
increasing-prime criterion at every activated prime of the descendant lcm. -/
theorem dense_of_joint {R ξ B : ℝ} {r X Y d e : ℕ} (hR : 1 < R) (hξ : 0 ≤ ξ)
    (hX : Squarefree X) (hY : Squarefree Y) (hd : d ∣ X) (he : e ∣ Y)
    (hband : R^B < (d.lcm e : ℝ))
    (joint : ∀ p ∈ X.primeFactors ∪ Y.primeFactors, R^ξ < (p : ℝ) →
      (tail R X p : ℝ) + tail R Y p + r*logSize R p ≤ B+ξ) :
    Nonempty (DenseDivisibilityWitness ⟨R^ξ, Real.one_le_rpow hR.le hξ⟩ r (d.lcm e)) := by
  let q := d.lcm e
  have dSq := hX.squarefree_of_dvd hd
  have eSq := hY.squarefree_of_dvd he
  have qSq : Squarefree q := squarefree_lcm_nat dSq eSq
  apply increasing_prime_criterion _ qSq
  intro p hp hpq hrough
  have hm := hp.mem_primeFactors hpq qSq.ne_zero
  have hun : p ∈ X.primeFactors ∪ Y.primeFactors :=
    (factors_lcm dSq.ne_zero eSq.ne_zero ▸ hm :
      p ∈ d.primeFactors ∪ e.primeFactors) |> Finset.union_subset_union
        (Nat.primeFactors_mono hd hX.ne_zero) (Nat.primeFactors_mono he hY.ne_zero)
  have htail : (tail R q p : ℝ) ≤ (tail R X p : ℝ) + tail R Y p := by
    exact_mod_cast (tail_lcm_le R dSq.ne_zero eSq.ne_zero).trans
      (add_le_add (tail_mono hd hX.ne_zero) (tail_mono he hY.ne_zero))
  have split := primeFragmentPrefix_add_logSize_add_suffix R hR qSq hm
  rw [tail_at_factor R hm, NNReal.coe_add, coe_logFragment R hR hp.pos] at htail
  have lo : B < logSize R q := (Real.lt_logb_iff_rpow_lt hR (Nat.cast_pos.mpr
    (Nat.pos_of_ne_zero qSq.ne_zero))).mpr hband
  have hj := joint p hun hrough
  have hh : (r:ℝ)*logSize R p ≤ ξ + (primeFragmentPrefix R q p : ℝ) := by linarith
  let t := (q.primeFactors.filter (fun a => a < p)).prod id
  have ht : 0 < (t:ℝ) := Nat.cast_pos.mpr (Finset.prod_pos (fun a ha =>
    Nat.pos_of_mem_primeFactors (Finset.mem_filter.mp ha).1))
  rw [← logSize_primeFactors_prefix R hR q p] at hh
  have hlog : Real.logb R ((p:ℝ)^r) ≤ ξ+logSize R t := by
    simpa only [Real.logb_pow, logSize] using hh
  simpa only [Real.rpow_add (zero_lt_one.trans hR), logSize,
    Real.rpow_logb (zero_lt_one.trans hR) hR.ne' ht] using
    (Real.logb_le_iff_le_rpow hR (pow_pos (Nat.cast_pos.mpr hp.pos) r)).mp hlog

/-- The three alternatives used by the frozen gate. X and Y are the
original retained roots; bounds are imposed before choosing descendants. -/
def tailTest (R B ξ S T : ℝ) (r X Y : ℕ) : Prop :=
  let own := fun n U => ∀ p ∈ activatedPrimeFactors R ξ n,
    (tail R n p : ℝ) + logSize R p ≤ U
  (∀ p ∈ X.primeFactors ∪ Y.primeFactors, R^ξ < (p:ℝ) →
    (tail R X p : ℝ) + tail R Y p + r*logSize R p ≤ B+ξ) ∨
  (r=1 ∧ ((2*T ≤ B+ξ ∧ own X (B+ξ-T)) ∨ (2*S ≤ B+ξ ∧ own Y (B+ξ-S)))) ∨
  (r=2 ∧ 2*S-T ≤ B+ξ ∧ 2*T-S ≤ B+ξ ∧ own X (B+ξ-T) ∧ own Y (B+ξ-S))

theorem dense_presieved_descendant {R ξ B S T : ℝ} {r X Y d e W : ℕ} (hR : 1 < R)
    (hξ : 0 ≤ ξ) (hX : Squarefree X) (hY : Squarefree Y) (hd : d ∣ X) (he : e ∣ Y)
    (hS : logSize R X ≤ S) (hT : logSize R Y ≤ T) (hband : R^B < (d.lcm e : ℝ))
    (hw : 0 < W) (hwY : (W:ℝ) ≤ R^ξ) (hdW : d.Coprime W) (heW : e.Coprime W)
    (gate : tailTest R B ξ S T r X Y) :
    Nonempty (DenseDivisibilityWitness ⟨R^ξ, Real.one_le_rpow hR.le hξ⟩ r (W.lcm (d.lcm e))) := by
  apply denseDivisibility_presieve_lcm _ hw hwY hdW heW
  have sd := hX.squarefree_of_dvd hd
  have se := hY.squarefree_of_dvd he
  have size {v z : ℕ} (hv : v ∣ z) (hz : Squarefree z) :
      logSize R v ≤ logSize R z := by
    exact Real.logb_le_logb_of_le hR (Nat.cast_pos.mpr (Nat.pos_of_ne_zero (hz.squarefree_of_dvd hv).ne_zero))
      (Nat.cast_le.mpr (Nat.le_of_dvd (Nat.pos_of_ne_zero hz.ne_zero) hv))
  have s0 : 0 ≤ S := (Real.logb_nonneg hR (by exact_mod_cast Nat.one_le_iff_ne_zero.mpr hX.ne_zero)).trans hS
  have t0 : 0 ≤ T := (Real.logb_nonneg hR (by exact_mod_cast Nat.one_le_iff_ne_zero.mpr hY.ne_zero)).trans hT
  have dS := (size hd hX).trans hS
  have eT := (size he hY).trans hT
  rcases gate with joint | ⟨rfl, (⟨ht, hx⟩ | ⟨hs, hy⟩)⟩ | ⟨rfl, hs, ht, hx, hy⟩
  · exact dense_of_joint hR hξ hX hY hd he hband joint
  · apply denseDivisibility_lcm_one_of_owner_bound hR hξ sd se dS eT ht (Or.inr ?_) hband
    linarith [owner_le hR (show 0 ≤ B+ξ-T by linarith) hd hX.ne_zero hx]
  · rw [Nat.lcm_comm] at hband ⊢
    apply denseDivisibility_lcm_one_of_owner_bound hR hξ se sd eT dS hs (Or.inr ?_) hband
    linarith [owner_le hR (show 0 ≤ B+ξ-S by linarith) he hY.ne_zero hy]
  · apply denseDivisibility_lcm_two_of_owner_bounds hR hξ sd se dS eT hs ht
      (Or.inr ?_) (Or.inr ?_) hband
    · linarith [owner_le hR (show 0 ≤ B+ξ-T by linarith) hd hX.ne_zero hx]
    · linarith [owner_le hR (show 0 ≤ B+ξ-S by linarith) he hY.ne_zero hy]

#print axioms dense_presieved_descendant
end PrimeGap180.Gate
