"""Transpose the canonical signed-64 factor bytes for Lean's positional columns.

Input words come from the same reader used by PackedLedger.raw. Every output
coefficient is decoded in row-major order and hashed against that exact input.
"""

import array
from hashlib import sha256
import json
from pathlib import Path
import struct
import sys
from tempfile import TemporaryDirectory

from read_frozen_ledger import unpack

if not __debug__:
    raise RuntimeError("Run the certificate checker with Python assertions enabled")

GROUPS = 445
ROW_BYTES_HASH = "103048b6552ee9b3e97b1834d10fc7b68a610e8c1526bd0d6f589a2c01028933"
COLUMN_STREAM_HASH = "5fbd57ff63971e3db1a3f864458e8ab2f7427b9ad1decd9d985c987b5d48c492"


def write(target):
    digest = sha256()
    version = b"PrimeGap180/factors/signed64/v1\0"
    digest.update(version)
    count = 0
    with TemporaryDirectory() as temporary, Path(target).open("wb") as output:
        extracted = Path(temporary)
        unpack(extracted)
        shapes = json.loads((extracted / "meta.json").read_bytes())["shapes"]
        if len(shapes) != 115:
            raise ValueError("expected 14 affine matrices and 101 factors")
        for index, rank in enumerate(shapes[14:], 14):
            if not 0 <= rank <= GROUPS:
                raise ValueError(f"invalid rank at matrix {index}")
            raw = bytes.fromhex((extracted / str(index)).read_text())
            shape = struct.pack("<II", index, rank)
            digest.update(shape)
            digest.update(raw)
            output.write(struct.pack("<I", rank))
            source = array.array("Q")
            source.frombytes(raw)
            if sys.byteorder != "little":
                source.byteswap()
            if source.itemsize != 8 or len(source) != GROUPS * rank:
                raise ValueError(f"incorrect signed-64 dimensions at matrix {index}")
            columns = bytearray(8 * len(source))
            for g in range(GROUPS):
                for j in range(rank):
                    value = source[g * rank + j]
                    struct.pack_into("<Q", columns, 8 * (j * GROUPS + g), value)
            # Check the transpose, lane content and endianness independently
            # of the reassignment above.
            recovered = bytearray(len(raw))
            for j in range(rank):
                for g in range(GROUPS):
                    word = int.from_bytes(
                        columns[8 * (j * GROUPS + g) : 8 * (j * GROUPS + g + 1)],
                        "little",
                    )
                    recovered[8 * (g * rank + j) : 8 * (g * rank + j + 1)] = (
                        word.to_bytes(8, "little")
                    )
            if recovered != raw:
                raise ValueError(f"transposition changed coefficient bytes at matrix {index}")
            output.write(columns)
            count += GROUPS * rank
    if digest.hexdigest() != ROW_BYTES_HASH or count != 9_975_565:
        raise ValueError("original signed-64 factor digest or census changed")
    columns_digest = sha256()
    with Path(target).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            columns_digest.update(chunk)
    if columns_digest.hexdigest() != COLUMN_STREAM_HASH:
        raise ValueError("transposed column stream digest changed")
    print(f"{digest.hexdigest()} {count}")


if __name__ == "__main__":
    write(Path(sys.argv[1]))
