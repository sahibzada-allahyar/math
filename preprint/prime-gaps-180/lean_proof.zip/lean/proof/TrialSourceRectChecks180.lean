import TrialSourceFrontierApply180
open PrimeGap180.SourceRectValidation PrimeGap180.SourceFrontier PrimeGap180.Book
namespace PrimeGap180.SourceRectChecks

def row (k : Row) := (List.finRange 445).all (fun g => (owners g.val).all (check k g.val))

theorem sound (yes : ∀ k, row k = true) : SourceFrontierApply.Rectangles := by
  intro k g o m
  exact List.all_eq_true.mp (List.all_eq_true.mp (yes k) g (by simp)) o m

end PrimeGap180.SourceRectChecks
