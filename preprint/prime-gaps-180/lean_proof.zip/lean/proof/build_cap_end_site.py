"""Generate the rounded endpoint shape of one cap (default 36) and its physical source theorem."""
import argparse
from pathlib import Path

from build_cap_square import input_tree
from build_historical_site_rows import columns
from cap_bank_names import Names, cap_argument
from check_span_mass_dots import endpoint
from endpoint_pair_arithmetic import encode

HERE = Path(__file__).resolve().parent
PAIR_CODES = {"01", "02", "11", "12", "22"}


def generate(destination, pair, cap=36, dry_run=False):
    if pair not in PAIR_CODES:
        raise ValueError(f"Unknown marked endpoint pair {pair!r}")
    names = Names(cap)
    destination.mkdir(parents=True, exist_ok=True)
    a, b = map(int, pair)
    if not dry_run:
        coefficients = endpoint(columns()[cap], a, b)
        for bound, values in [("lo", coefficients.low), ("hi", coefficients.high)]:
            (destination / f"cap-end-{pair}-{bound}.bin").write_bytes(encode(values, 80))
    modules = {}
    for stem in ["TrialCapEndSiteData", "TrialCapEndSite"]:
        source = names.template(f"{stem}180")
        source = source.replace("__A__", str(a)).replace("__B__", str(b)).replace("__TAG__", pair)
        source = source.replace("__INPUT_TREE__", input_tree())
        module = names.module(stem.removeprefix("TrialCap") + pair)
        path = destination / f"{module}.lean"
        path.write_text(source)
        modules[module] = path
    return modules


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    cap_argument(p)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--dry-run", action="store_true", help="write Lean text without words")
    args = p.parse_args()
    for pair in sorted(PAIR_CODES):
        for n in generate(args.output_dir, pair, args.cap, args.dry_run):
            print(n)
