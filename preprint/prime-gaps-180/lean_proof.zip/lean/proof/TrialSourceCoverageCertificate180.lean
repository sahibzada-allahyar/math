import TrialSourceMatrixBits180
import TrialSourcePlansChecked180
import TrialSourceRectAll180
import TrialSourceMatrixAll180
import TrialFrozenLedger180

/-! Exhaustive source coverage for every pair of actual physical receipts
on the fourteen signed affine rows. -/
namespace PrimeGap180.SourceCoverageCertificate

theorem checked : Terminal.SourceCoverage FrozenLedger.ledger :=
  SourceFrontierApply.covered FrozenLedger.ledger
    SourcePlanBlocks.checked
    (SourceRectChecks.sound SourceRectChecks.checked)
    (SourceMatrixBits.sound FrozenLedger.affine_entry SourceMatrixBits.checked)

#print axioms checked
end PrimeGap180.SourceCoverageCertificate
