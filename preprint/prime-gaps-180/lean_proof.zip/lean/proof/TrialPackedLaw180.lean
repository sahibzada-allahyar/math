import TrialReferenceLaw180

/-! Fixed dyadic site measures for the 37 historical maximum observations.
One packed integer is read per cumulative observation. The initial exact
zone and last-column ceiling are built into the reference grid. -/
noncomputable section
open scoped Classical BigOperators
open PrimeGap180.DebitNativeClasses
namespace PrimeGap180.PackedLaw
abbrev Tick := Fin 130965
abbrev Cap := DebitNativeClasses.Class
abbrev Grid := Tick → Cap → ℤ

def base : ℤ := 2^57
def value (g : Grid) (j : Tick) (c : Cap) := g j c
def preceding (g : Grid) (j : Tick) (v : ℕ) : ℤ :=
  if v=0 then 0 else value g j (Fin.ofNat 37 (v-1))
def mark (g : Grid) (j : Tick) (c : Cap) := value g j c-preceding g j c.val

theorem prefix_succ (g : Grid) (j : Tick) (c : Cap) : preceding g j (c.val+1)=value g j c := by
  simp [preceding]
theorem prefix_succ_fin (g : Grid) (j : Tick) (c : Fin 36) : preceding g j c.succ.val=value g j c.castSucc := prefix_succ g j c.castSucc

def probability (g : Grid) (b : Atom) : ℚ :=
  if h : b.1.val < 130965 then b.2.elim 0 (fun c => (mark g ⟨b.1.val,h⟩ c:ℚ)/base) else 0
def law (g : Grid) (b : Atom) : ℝ := Native.step*(probability g b:ℝ)

theorem at_point (g : Grid) (j : Tick) (c : Cap) : probability g (j.castSucc,some c)=(mark g j c:ℚ)/base := by
  simp [probability,j.isLt]

theorem small_initial (g : Grid) (j : Tick) (small : ∀ c,g j c=base) :
    probability g (j.castSucc,some (0:Cap)) = 1 := by
  rw [at_point]; norm_num [mark,value,preceding,small,base]

theorem small_successor (g : Grid) (j : Tick) (small : ∀ c,g j c=base) (c : Fin 36) :
    probability g (j.castSucc,some c.succ) = 0 := by
  rw [at_point,mark,prefix_succ_fin]; simp [value,small]

private theorem telescope (f : ℕ → ℤ) (n : ℕ) :
    (∑ j ∈ Finset.range n,(f (j+1)-f j)) = f n-f 0 := by
  induction n with
  | zero => simp
  | succ k ih => rw [Finset.sum_range_succ,ih]; ring

theorem total (g : Grid) (j : Tick) (ceiling : g j (Fin.last 36) ≤ base) : (∑ c : Cap, mark g j c) ≤ base := by
  have e : (∑ c : Cap,mark g j c)=∑ c : Cap,(preceding g j (c.val+1)-preceding g j c.val) := by
    simp only [mark,prefix_succ]
  rw [e,Fin.sum_univ_eq_sum_range (fun k => preceding g j (k+1)-preceding g j k),telescope]
  simpa [preceding,value] using ceiling

theorem surviving (g : Grid) (j : Tick) (ceiling : g j (Fin.last 36) ≤ base) : (∑ c : Cap, law g (j.castSucc,some c)) ≤ Native.step := by
  simp only [law,at_point,Rat.cast_div,Rat.cast_intCast,←Finset.mul_sum,←Finset.sum_div]
  have n : 0 ≤ Native.step := by norm_num [Native.step]
  suffices h : (∑ c : Cap, (mark g j c:ℝ))/(base:ℝ) ≤ 1 by
    simpa using (mul_le_mul_of_nonneg_left h n)
  apply (div_le_one (by norm_num [base] : (0:ℝ) < (base:ℝ))).mpr
  exact_mod_cast total g j ceiling

#print axioms surviving
end PrimeGap180.PackedLaw
