import TrialSourceAffineLane180
import Mathlib.Data.Nat.Basic

/-! A single exclusion bit for a group expands to all 64 bits in its
signed integer lane. This allows partner membership to use compact masks. -/
namespace PrimeGap180.SourceAffine

def expand : Nat → Nat → Nat
  | 0, _ => 0
  | n+1, bits => (if bits.testBit 0 then full else 0) + 2^64 * expand n (bits/2)

private theorem lane0 (head tail : Nat) (lt : head < 2^64) : lane (head+2^64*tail) 0 = head := by
  change (head+2^64*tail) &&& (2^64-1) = head
  rw [Nat.and_two_pow_sub_one_eq_mod,Nat.add_mul_mod_self_left,Nat.mod_eq_of_lt lt]

private theorem laneSucc (head tail j : Nat) (lt : head < 2^64) :
    lane (head+2^64*tail) (j+1) = lane tail j := by
  have split : 64*(j+1) = 64+64*j := by omega
  have cutoff : (head+2^64*tail) >>> 64 = tail := by
    rw [Nat.shiftRight_eq_div_pow,Nat.add_mul_div_left _ _ (by decide),Nat.div_eq_of_lt lt,Nat.zero_add]
  unfold lane
  rw [split,Nat.shiftRight_add,cutoff]

theorem expand_at {n j : Nat} (bits : Nat) (lt : j < n) :
    lane (expand n bits) j = (if bits.testBit j then full else 0) := by
  induction n generalizing j bits with
  | zero => omega
  | succ n ih =>
    have bound : (if bits.testBit 0 then full else 0) < 2^64 := by cases bits.testBit 0 <;> decide
    cases j with
    | zero => exact lane0 _ _ bound
    | succ j =>
      rw [expand,laneSucc _ _ _ bound,ih (bits/2) (by omega),Nat.testBit_div_two]

theorem zero_of_bit {word bits groups h : Nat} (clear : word &&& expand groups bits = 0)
    (below : h < groups) (excluded : bits.testBit h = true) : entry word h = 0 := by
  apply entry_eq_zero clear
  rw [expand_at bits below,excluded]
  rfl

#print axioms zero_of_bit
end PrimeGap180.SourceAffine
