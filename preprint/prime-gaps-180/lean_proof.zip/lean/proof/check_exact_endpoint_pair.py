"""Check the original 37-site simultaneous-endpoint charge with directed integers.

Run from the certificate directory. A complete replay uses GMP, Python's
standard library, and transient disk space for reusable interior polynomials.
"""
import argparse
from collections import Counter, defaultdict
from fractions import Fraction
from functools import lru_cache
from hashlib import sha256
import json
import math
from pathlib import Path
import tempfile
import time

from build_historical_site_rows import columns
from check_refined_site_bins import receipt, TRANSFER_SHA
from endpoint_pair_arithmetic import COUNT, DENOMINATOR, FRACTION_BITS, Interval
from endpoint_pair_arithmetic import audit, correlate, decode, encode, multiply

HERE = Path(__file__).resolve().parent
TABLE_SHA = "785527884ca340d8ca12909f3076b422fddf4922e234cdd3a574f74bc70de6ef"
STEP = Fraction(1399373467, 172031279104000)
RHO = Fraction(2624989, 10000000)
TICKS = 1 << 17
CLASS_MAP = tuple(i for i in range(44) if i not in (0, 1, 2, 3, 14, 22, 42))
SIGNATURES = ((), (2,), (3,), (4,), (2, 2), (5,), (2, 3), (6,), (2, 4), (3, 3), (2, 2, 2))
FIELD_BITS = 64
PRICE_BITS = 96
PAIR_LIMIT = Fraction(577, 4000)
# These are the nine nonzero entries of column 4 in TrialRoundedNumbers180.
CAP_LIMITS = {46567: 33331, 47096: 3, 58332: 43288, 60089: 156, 61104: 3778,
              63177: 1676, 64599: 2671, 65536: 11790, 78116: 54559}


def digest(path):
    h = sha256()
    with path.open("rb") as stream:
        while block := stream.read(1 << 20):
            h.update(block)
    return h.hexdigest()


def site(column, power=0, degree=2, shape=0):
    """Enclose each signed-erasure input or nonnegative Gram moment directly."""
    step_n, step_d = STEP.as_integer_ratio()
    td = 2 * step_d
    low, high = [], []
    for j, n57 in enumerate(column[:COUNT]):
        tn = (2 * j + 1) * step_n
        d1, d2 = 100 * td + tn, 5 * td + 907 * tn
        gn, gd = 2100 * td * d2 + 895 * td * d1, 200 * d1 * d2
        shape_n, shape_d = ((1, 1), ((2 * j + 1)**2, (2 * TICKS)**2), (td, td + 300 * tn))[shape]
        numerator = DENOMINATOR * 100 * step_n * n57 * gn**degree * tn**power * shape_n
        denominator = step_d * (1 << 57) * gd**degree * td**power * shape_d
        value, remainder = divmod(numerator, denominator)
        low.append(value)
        high.append(value + bool(remainder))
    return Interval(low, high)


def price(j):
    """Dyadic endpoints of 2*(rho/100)^2/(0.4999-rho*(j+37)*step)^2."""
    a, b = RHO.as_integer_ratio()
    p, q = STEP.as_integer_ratio()
    gap = 4999 * b * q - 10000 * a * (j + 37) * p
    if gap <= 0:
        raise ArithmeticError("The endpoint price denominator is nonpositive.")
    v, r = divmod((1 << PRICE_BITS) * 2 * (100 * a * q)**2, gap**2)
    return v, v + bool(r)


class Spline:
    def __init__(self, path):
        if digest(path) != TABLE_SHA:
            raise ValueError("The frozen table digest changed.")
        self.table = json.loads(path.read_text())
        self.knots = [Fraction(*pair) for pair in self.table["knots"]]
        if len(self.knots) != 34:
            raise ValueError("Expected 34 cubic knots.")

    def state(self, cap_class):
        if cap_class == len(CLASS_MAP):
            return -1, -1
        row = CLASS_MAP[cap_class]
        return row, min(COUNT - 1, self.table["maxIndex"][row])

    def changes(self, cap_class):
        row, limit = self.state(cap_class)
        previous, old_limit = self.state(cap_class + 1)
        return previous < 0 or (self.table["suffix"][row], limit) != (self.table["suffix"][previous], old_limit)

    def coefficient(self, fine, shapes, signature, k):
        if fine < 0:
            return 0
        data = self.table["coeff"]
        return sum(data[((shapes * 3 + l) * 11 + signature) * 30 + k]
                   for l in range(self.table["suffix"][fine], 3))

    def weights(self, span, start):
        """Four consecutive values of the span's cubic polynomial continuation."""
        knots = self.knots
        def basis(x):
            @lru_cache(None)
            def value(d, i):
                if d == 0:
                    return int(i == span)
                ld, rd = knots[i + d] - knots[i], knots[i + d + 1] - knots[i + 1]
                left = (x - knots[i]) * value(d - 1, i) / ld if ld else 0
                right = (knots[i + d + 1] - x) * value(d - 1, i + 1) / rd if rd else 0
                return left + right
            return [value(3, k) for k in range(span - 3, span + 1)]
        return [basis((Fraction(j) + Fraction(39, 2)) * STEP) for j in range(start, start + 4)]

    @lru_cache(None)
    def spans(self, cap_class):
        current, last = self.state(cap_class)
        previous, old_last = self.state(cap_class + 1)
        result = []
        for span in range(3, 33):
            lo = max(0, math.ceil(self.knots[span] / STEP - Fraction(39, 2)))
            hi = min(COUNT, math.ceil(self.knots[span + 1] / STEP - Fraction(39, 2)))
            if hi <= lo:
                continue
            cuts = sorted({lo, hi, *(a for a in (last + 1, old_last + 1) if lo < a < hi)})
            for start, end in zip(cuts, cuts[1:]):
                new = current if start <= last else -1
                old = previous if start <= old_last else -1
                if new >= 0 or old >= 0:
                    result.append((span, start, end, new, old, self.weights(span, start)))
        return result

    def difference(self, cap_class, a, b, signature):
        """Signed radial increment, including both orders of unequal endpoint shapes."""
        low, high = [0] * COUNT, [0] * COUNT
        exponents = SIGNATURES[signature]
        scale = Fraction((1 << FIELD_BITS) * 39**(sum(exponents) - len(exponents)), self.table["coeffDen"])
        shapes = [3 * a + b] if a == b else [3 * a + b, 3 * b + a]
        for span, start, end, current, old, weights in self.spans(cap_class):
            coefficients = [sum(self.coefficient(current, sh, signature, k) -
                                self.coefficient(old, sh, signature, k) for sh in shapes)
                            for k in range(span - 3, span + 1)]
            if not any(coefficients):
                continue
            f = [scale * sum(z * w for z, w in zip(coefficients, row, strict=True)) for row in weights]
            delta = [f[0], f[1] - f[0], f[2] - 2 * f[1] + f[0], f[3] - 3 * f[2] + 3 * f[1] - f[0]]
            common = math.lcm(*(z.denominator for z in delta))
            y, first, second, third = [int(z * common) for z in delta]
            for j in range(start, end):
                quotient, remainder = divmod(y, common)
                low[j], high[j] = quotient, quotient + bool(remainder)
                y += first
                first += second
                second += third
        return Interval(low, high)


def field_bank(spline, cap_class, column, prior):
    slots = [site(column, degree=1, shape=i) for i in range(3)]
    kernels = {(a, b): multiply(slots[a], slots[b]) for a in range(3) for b in range(a, 3)}
    out = []
    for sigma in range(11):
        if prior is None:
            low, high = [0] * COUNT, [0] * COUNT
        else:
            low, high = prior[sigma].low.copy(), prior[sigma].high.copy()
        for (a, b), kernel in kernels.items():
            inc = correlate(spline.difference(cap_class, a, b, sigma), kernel)
            low = [x + y for x, y in zip(low, inc.low, strict=True)]
            high = [x + y for x, y in zip(high, inc.high, strict=True)]
        if any(l > h for l, h in zip(low, high, strict=True)):
            raise ArithmeticError("Inverted endpoint field interval.")
        out.append(Interval(low, high))
    return out


@lru_cache(None)
def group_assignments(signature):
    """Every fresh occupied site has 37 minus the current block count choices."""
    result = Counter()
    def add(index, blocks, multiplicity):
        if index == len(signature):
            result[tuple(sorted(blocks))] += multiplicity
            return
        e = signature[index]
        for selected in range(len(blocks)):
            updated = tuple(x + e if j == selected else x for j, x in enumerate(blocks))
            add(index + 1, updated, multiplicity)
        add(index + 1, blocks + (e,), multiplicity * (37 - len(blocks)))
    add(0, (), 1)
    if sum(result.values()) != 37**len(signature):
        raise ArithmeticError("Incomplete angular assignment grouping.")
    return result


class Gram:
    def __init__(self, column, temporary):
        self.column = column
        self.temporary = temporary

    @lru_cache(maxsize=9)
    def term(self, kind, args):
        path = self.temporary / (kind + "-" + ".".join(map(str, args)) + ".bin")
        if path.exists():
            data = path.read_bytes()
            if len(data) != COUNT * 80:
                raise ValueError("Incomplete intermediate coefficient file.")
            return Interval(decode(data[:COUNT * 40], 40), decode(data[COUNT * 40:], 40))
        if kind == "atom":
            value = site(self.column, args[0])
        elif kind == "count":
            d, = args
            value = (self.term("atom", (0,)) if d == 1 else
                     multiply(self.term("count", (d // 2,)), self.term("count", (d - d // 2,))))
        elif kind == "occupied":
            value = (self.term("atom", args) if len(args) == 1 else
                     multiply(self.term("occupied", args[:-1]), self.term("atom", (args[-1],))))
        elif kind == "all":
            value = (self.term("count", (37,)) if not args else
                     multiply(self.term("count", (37 - len(args),)), self.term("occupied", args)))
        else:
            raise ValueError(kind)
        path.write_bytes(encode(value.low, 40) + encode(value.high, 40))
        return value

    def polynomial(self, signature):
        low, high = [0] * COUNT, [0] * COUNT
        for blocks, count in group_assignments(signature).items():
            part = self.term("all", blocks)
            low = [x + count * y for x, y in zip(low, part.low, strict=True)]
            high = [x + count * y for x, y in zip(high, part.high, strict=True)]
        return Interval(low, high)


def combine_fields(now, old):
    if old is None:
        return now, now
    inc, both = [], []
    for x, y in zip(now, old, strict=True):
        inc.append(Interval([a - b for a, b in zip(x.low, y.high, strict=True)],
                            [a - b for a, b in zip(x.high, y.low, strict=True)]))
        both.append(Interval([a + b for a, b in zip(x.low, y.low, strict=True)],
                             [a + b for a, b in zip(x.high, y.high, strict=True)]))
    return inc, both


def contribution(spline, cap_class, column, now, old, temporary):
    new, both = combine_fields(now, old)
    _, last = spline.state(cap_class)
    prices = [price(j) for j in range(last + 1)]
    groups = defaultdict(list)
    for i, s in enumerate(SIGNATURES):
        for j, t in enumerate(SIGNATURES):
            groups[tuple(sorted(s + t))].append((i, j))
    if len(groups) != 53 or sum(map(len, groups.values())) != 121:
        raise ArithmeticError("Unexpected number of angular products.")
    lo = hi = 0
    gram = Gram(column, temporary)
    for sig, pairs in sorted(groups.items()):
        kernel = gram.polynomial(sig)
        lower = [x * v[0] for x, v in zip(kernel.low, prices)]
        upper = [x * v[1] for x, v in zip(kernel.high, prices)]
        for i, j in pairs:
            a, b = new[i], both[j]
            for x, y, z, t, l, h in zip(a.low, a.high, b.low, b.high, lower, upper):
                products = (x * z, x * t, y * z, y * t)
                p, q = min(products), max(products)
                lo += p * (h if p < 0 else l)
                hi += q * (l if q < 0 else h)
    gram.term.cache_clear()
    denominator = 1 << (2 * FIELD_BITS + FRACTION_BITS + PRICE_BITS)
    if lo > hi:
        raise ArithmeticError("Inverted signed cap enclosure.")
    return Fraction(lo, denominator), Fraction(hi, denominator)


def run(output, workspace, stop_at):
    audit()
    spline = Spline(HERE / "frozen_band_tables.json")
    cap_data = receipt("cap_law_transfer.json", TRANSFER_SHA)
    cap_keys = [row["cap"] for row in cap_data["bins"]]
    grid = columns()
    selected = [i for i in reversed(range(37)) if spline.changes(i)]
    if {cap_keys[i] for i in selected} != set(CAP_LIMITS):
        raise ValueError("Active geometry caps do not match the directed target table.")
    if stop_at is not None and stop_at not in CAP_LIMITS:
        raise ValueError("--stop-at must name a geometry-changing cap.")
    result = {"table_sha256": TABLE_SHA, "site_grid_manifest_sha256": TRANSFER_SHA,
              "field_fraction_bits": FIELD_BITS, "gram_fraction_bits": FRACTION_BITS,
              "price_fraction_bits": PRICE_BITS, "zero_caps": 37 - len(selected), "caps": []}
    previous = None
    low = high = Fraction(0)
    for index in selected:
        cap = cap_keys[index]
        start = time.monotonic()
        now = field_bank(spline, index, grid[index], previous)
        with tempfile.TemporaryDirectory(prefix="endpoint-pair-", dir=workspace) as folder:
            lo, hi = contribution(spline, index, grid[index], now, previous, Path(folder))
        target = Fraction(CAP_LIMITS[cap], 1 << 20)
        if hi > target:
            raise ArithmeticError(f"Cap {cap} exceeds its directed target.")
        result["caps"].append({"cap": cap, "class": index, "lower": str(lo), "upper": str(hi),
                               "cap_upper": str(target)})
        low += lo
        high += hi
        previous = now
        print(f"Cap {cap} passed in {time.monotonic() - start:.1f}s", flush=True)
        if cap == stop_at:
            break
    result["complete"] = len(result["caps"]) == len(selected)
    result["lower"] = str(low)
    result["upper"] = str(high)
    if result["complete"]:
        if high > PAIR_LIMIT:
            raise ArithmeticError("The endpoint-pair bound exceeds 0.14425.")
        result["pair_upper"] = str(PAIR_LIMIT)
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(f"Enclosure [{float(low):.16g}, {float(high):.16g}]", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--workdir", type=Path, help="existing directory for temporary polynomials")
    parser.add_argument("--stop-at", type=int, help="stop after this cap and label the output as partial")
    args = parser.parse_args()
    run(args.output, args.workdir, args.stop_at)
