import TrialActiveGridGap180
import TrialReducedActiveCaps180
import TrialSlackMargin180

/-! The slack route with a lower relaxed uncut target. Lowering the uncut target from
1.00117224 to 1.0011666 keeps a terminal excess of
0.0011666 - 0.001121271547 - 0.0000443013 > 0.000001 times the original mass, and frees
room in the five role bounds for per-cap slack in the core, first and last single-site
targets. The mass and pair columns of the per-cap table are those of `RoundedCaps.target`,
and so are the rows of the settled caps 0, 3 and 35. `check_slack_uncut.py` recomputes the
table and every inequality used here. -/
noncomputable section
namespace PrimeGap180.SlackUncut

/-- The lower relaxed uncut target. -/
def uncutTarget : ℝ := 1.0011666

/-! ## Role bounds -/

def mBound' : ℝ := 98747690/1048576
def cBound' : ℝ := 2597671/1048576
def aBound' : ℝ := 1452218/1048576
def bBound' : ℝ := 1452218/1048576
def pBound' : ℝ := 151252/1048576

section roles
open PrimeGap180.PackedLaw

/-- The five role bounds of the lower target, as `RelaxedFive.Bounds`. -/
structure RoleBounds' (g : Grid) : Prop where
  mass : NativeRoleTotals.ordinary g ≤ mBound'
  core : cBound' ≤ NativeRoleTotals.single g 1
  first : aBound' ≤ NativeRoleTotals.single g 0
  last : bBound' ≤ NativeRoleTotals.single g (Fin.last 38)
  pair : NativeRoleTotals.pair g ≤ pBound'

end roles

section native
open scoped BigOperators Classical
open PrimeGap186 PrimeGap180.DebitNativeClasses PrimeGap180.PackedSiteAudit
open PrimeGap180.Sector PrimeGap180.PackedLaw PrimeGap180.ReferenceRoles
open PrimeGap180.UncutDrift PrimeGap180.NumericalAccount

/-- The native quotient lowered by `1.00119224 - uncutTarget`. -/
def nQ' : ℝ := nativeQ-0.00002564

theorem weighted' : nQ'*mBound' ≤ 37*cBound'+aBound'+bBound'-pBound' := by
  norm_num [nQ',nativeQ,mBound',cBound',aBound',bBound',pBound']

theorem drift' : uncutTarget ≤ nQ'-(2*K+4*P)*H-2*(K+P)*δ := by
  unfold uncutTarget nQ'
  linarith only [closed_constants]

theorem native' (g : Grid) (b : RoleBounds' g) : nQ'*massN (law g) ≤ LiftedScore.scoreN (law g) := by
  let u := law g
  have m : massN (archive u) ≤ mBound' := (NativeRoleTotals.mass_eq g).le.trans b.mass
  have c : ∀ i : Fin 37,cBound' ≤ single (rho/100) (archive u) i.castSucc.succ :=
    interior_lower _ _ _ (b.core.trans (NativeRoleTotals.single_eq g 1).ge)
  have first := b.first.trans (NativeRoleTotals.single_eq g 0).ge
  have last := b.last.trans (NativeRoleTotals.single_eq g (Fin.last 38)).ge
  have pair := (NativeRoleTotals.pair_eq g).le.trans b.pair
  have interiors : 37*cBound' ≤ ∑ i : Fin 37,single (rho/100) (archive u) i.castSucc.succ := by
    simpa using (Finset.sum_le_sum (s:=Finset.univ) (fun i _ => c i))
  have total : 37*cBound'+aBound'+bBound' ≤ ∑ i : Fin 39,single (rho/100) (archive u) i := by
    rw [Fin.sum_univ_succ,Fin.sum_univ_castSucc]
    rw [show (Fin.last 37).succ = Fin.last 38 by rfl]
    dsimp only [u] at *
    linarith only [interiors,first,last]
  have pos : 0 ≤ nQ' := by norm_num [nQ',nativeQ]
  have top := (mul_le_mul_of_nonneg_left m pos).trans weighted'
  have scaled : nQ'*massN (archive u) ≤ (∑ i : Fin 39,single (rho/100) (archive u) i)-ReferenceRoles.pair (rho/100) (archive u) :=
    top.trans (sub_le_sub total pair)
  rw [mass_scale,pair_scale] at scaled
  simp only [single_scale,←Finset.mul_sum] at scaled
  rw [score]
  change nQ'*massN u ≤ (∑ i : Fin 39,single rho u i)-ReferenceRoles.pair rho u
  linarith only [scaled]

theorem physicalOf (a : Array Chunk) (schema_ok : schema a=true) (b : RoleBounds' (PolynomialUncut.data a)) :
    uncutTarget*mass Restoration.original ≤ numerator Restoration.original := by
  apply PackedMetrics.uncut_at (PolynomialUncut.data a) nQ' uncutTarget drift' _ _
    (ShardScore.shard_boxes a schema_ok)
  exact native' _ b

end native

/-! ## Per-cap targets -/

section caps
open scoped Classical BigOperators
open PrimeGap180.PackedLaw PrimeGap180.Sector PrimeGap180.DebitNativeClasses
open PrimeGap180.NativeShellErasures PrimeGap180.SignedCapContractions
open PrimeGap180.PackedSingleFields PrimeGap180.PackedRoleKernels

/-- Columns 0 (mass) and 4 (pair) are those of `RoundedCaps.target`. Columns 1-3 (core,
first, last) lie below the 256-bit receipt lower ends of
`parallel_quotient_debit.json` by at least 8 units of 2^-20 for first and last,
2 units for the core at the nine changing caps and 1/4 unit for the core elsewhere,
except at the settled caps 0, 3 and 35, whose rows are unchanged. -/
def target' : Fin 37 → Fin 5 → ℤ := ![
  ![0,0,0,0,0],
  ![0,-1,-9,-9,0],
  ![0,18,3,3,0],
  ![0,0,0,0,0],
  ![0,3172,2052,2052,0],
  ![0,727,555,555,0],
  ![0,28375,18542,18542,0],
  ![31564580,845489,432554,432554,33331],
  ![3347,7005,4537,4537,3],
  ![0,-6676,-4534,-4534,0],
  ![0,49,24,24,0],
  ![0,200,125,125,0],
  ![0,9406,6247,6247,0],
  ![0,1096,842,842,0],
  ![0,1396,936,936,0],
  ![36235525,965390,512362,512362,43288],
  ![0,2077,1288,1288,0],
  ![0,880,559,559,0],
  ![0,1424,1102,1102,0],
  ![0,1262,788,788,0],
  ![0,1225,776,776,0],
  ![0,1871,1175,1175,0],
  ![0,7,-4,-4,0],
  ![36178,2540,1702,1702,156],
  ![0,110,60,60,0],
  ![0,2813,1814,1814,0],
  ![1005407,31358,21637,21637,3778],
  ![0,79,121,121,0],
  ![0,-3548,-1666,-1666,0],
  ![0,3335,3136,3136,0],
  ![164185,12302,11296,11296,1676],
  ![0,45,22,22,0],
  ![0,5425,4947,4947,0],
  ![485160,6732,2152,2152,2671],
  ![2922024,87538,52838,52838,11790],
  ![0,0,0,0,0],
  ![26331284,584550,374239,374239,54559]]

theorem sum_mass' : (∑ c : Fin 37,target' c 0) = 98747690 := by decide +kernel
theorem sum_core' : (∑ c : Fin 37,target' c 1) = 2597671 := by decide +kernel
theorem sum_first' : (∑ c : Fin 37,target' c 2) = 1452218 := by decide +kernel
theorem sum_last' : (∑ c : Fin 37,target' c 3) = 1452218 := by decide +kernel
theorem sum_pair' : (∑ c : Fin 37,target' c 4) = 151252 := by decide +kernel

theorem outer_cols : ∀ c : Hist,target' c 0=RoundedCaps.target c 0 ∧ target' c 4=RoundedCaps.target c 4 := by
  decide +kernel

theorem settled_rows : ∀ r : Fin 5,target' (0:Hist) r=RoundedCaps.target (0:Hist) r ∧
    target' (3:Hist) r=RoundedCaps.target (3:Hist) r ∧ target' (35:Hist) r=RoundedCaps.target (35:Hist) r := by
  decide +kernel

def dyad' (c : Hist) (r : Fin 5) : ℝ := (target' c r : ℝ)/RoundedCaps.scale

theorem dyad_outer (c : Hist) : dyad' c 0=RoundedCaps.dyad c 0 ∧ dyad' c 4=RoundedCaps.dyad c 4 := by
  have h := outer_cols c
  exact ⟨by simp only [dyad',RoundedCaps.dyad,h.1],by simp only [dyad',RoundedCaps.dyad,h.2]⟩

theorem settled_same (c : Hist) (hc : PositiveCap.settled c) (r : Fin 5) : dyad' c r=RoundedCaps.dyad c r := by
  unfold dyad' RoundedCaps.dyad
  rcases hc with rfl|rfl|rfl
  · rw [(settled_rows r).1]
  · rw [(settled_rows r).2.1]
  · rw [(settled_rows r).2.2]

private theorem aggregate (r : Fin 5) (v : ℤ) (h : (∑ c : Fin 37,target' c r)=v) :
    ∑ c : Hist,dyad' c r=(v : ℝ)/RoundedCaps.scale := by
  calc
    _ = ((∑ c : Hist,target' c r : ℤ):ℝ)/RoundedCaps.scale := by
      simp only [dyad',Int.cast_sum,Finset.sum_div]
    _ = _ := by rw [h]

private theorem transpose {I J : Type*} [Fintype I] [Fintype J]
    (k : ℝ) (f : I → J → ℝ) : k*(∑ i,∑ j,f i j)=∑ j,k*∑ i,f i j := by
  calc
    _ = k*(∑ j,∑ i,f i j) := congrArg (k*·) Finset.sum_comm
    _ = _ := Finset.mul_sum _ _ _

/-- Per-cap comparisons against `target'`, as `RoundedCaps.Bounds`. -/
structure Bounds' (g : Grid) : Prop where
  mass (c : Hist) : RoundedCaps.m g c ≤ dyad' c 0
  core (c : Hist) : dyad' c 1 ≤ RoundedCaps.s g 1 c
  first (c : Hist) : dyad' c 2 ≤ RoundedCaps.s g 0 c
  last (c : Hist) : dyad' c 3 ≤ RoundedCaps.s g (Fin.last 38) c
  pair (c : Hist) : RoundedCaps.p g c ≤ dyad' c 4

theorem five' (g : Grid) (b : Bounds' g) : RoleBounds' g := by
  have mass : NativeRoleTotals.ordinary g = ∑ c : Hist,RoundedCaps.m g c :=
    transpose _ (fun j : Tick => fun c : Hist =>
      NativeRadialMass.fullGram g c j.val c.val-NativeRadialMass.fullGram g c j.val (c.val+1))
  have single (i : Fin 39) : NativeRoleTotals.single g i = ∑ c : Hist,RoundedCaps.s g i c :=
    transpose _ (fun j : Tick => fun c : Hist =>
      keyPrice j.val c.val*singleGram g i c j.val c.val-keyPrice j.val (c.val+1)*singleGram g i c j.val (c.val+1))
  have pair : NativeRoleTotals.pair g = ∑ c : Hist,RoundedCaps.p g c :=
    transpose _ (fun j : Tick => fun c : Hist =>
      NativeRoleTotals.q j.val*pairGram g c j.val c.val-NativeRoleTotals.q j.val*pairGram g c j.val (c.val+1))
  have r0 := Finset.sum_le_sum (s:=Finset.univ) (fun c _ => b.mass c)
  have r1 := Finset.sum_le_sum (s:=Finset.univ) (fun c _ => b.core c)
  have r2 := Finset.sum_le_sum (s:=Finset.univ) (fun c _ => b.first c)
  have r3 := Finset.sum_le_sum (s:=Finset.univ) (fun c _ => b.last c)
  have r4 := Finset.sum_le_sum (s:=Finset.univ) (fun c _ => b.pair c)
  rw [aggregate 0 98747690 sum_mass'] at r0
  rw [aggregate 1 2597671 sum_core'] at r1
  rw [aggregate 2 1452218 sum_first'] at r2
  rw [aggregate 3 1452218 sum_last'] at r3
  rw [aggregate 4 151252 sum_pair'] at r4
  refine ⟨?_,?_,?_,?_,?_⟩
  · rw [mass]; exact r0.trans (le_of_eq (by norm_num [RoundedCaps.scale,mBound']))
  · rw [single]; exact le_trans (le_of_eq (by norm_num [RoundedCaps.scale,cBound'])) r1
  · rw [single]; exact le_trans (le_of_eq (by norm_num [RoundedCaps.scale,aBound'])) r2
  · rw [single]; exact le_trans (le_of_eq (by norm_num [RoundedCaps.scale,bBound'])) r3
  · rw [pair]; exact r4.trans (le_of_eq (by norm_num [RoundedCaps.scale,pBound']))

private theorem zero_targets' : ∀ c : Hist,InactiveCaps.changes c=false → target' c 0=0 ∧ target' c 4=0 := by
  decide +kernel

/-- As `RoundedCaps.ActiveBounds`: the mass and pair comparisons only at the nine changing caps. -/
structure ActiveBounds' (g : Grid) : Prop where
  mass (c : Hist) : InactiveCaps.changes c=true → RoundedCaps.m g c ≤ dyad' c 0
  core (c : Hist) : dyad' c 1 ≤ RoundedCaps.s g 1 c
  first (c : Hist) : dyad' c 2 ≤ RoundedCaps.s g 0 c
  last (c : Hist) : dyad' c 3 ≤ RoundedCaps.s g (Fin.last 38) c
  pair (c : Hist) : InactiveCaps.changes c=true → RoundedCaps.p g c ≤ dyad' c 4

/-- As `RoundedCaps.active`. -/
theorem activeFive' (g : Grid) (b : ActiveBounds' g) : RoleBounds' g := by
  apply five' g
  refine ⟨?_,b.core,b.first,b.last,?_⟩
  · intro c
    cases h : InactiveCaps.changes c with
    | true => exact b.mass c h
    | false =>
      simp only [RoundedCaps.m,InactiveCaps.full g c h,sub_self,Finset.sum_const_zero,mul_zero,dyad',(zero_targets' c h).1,Int.cast_zero,zero_div,le_refl]
  · intro c
    cases h : InactiveCaps.changes c with
    | true => exact b.pair c h
    | false =>
      simp only [RoundedCaps.p,InactiveCaps.pair g c h,sub_self,Finset.sum_const_zero,mul_zero,dyad',(zero_targets' c h).2,Int.cast_zero,zero_div,le_refl]

/-- As `PositiveCap.Remaining`: the mass and pair comparisons against the unchanged
`RoundedCaps.dyad`, and 34 per-site single comparisons for each erased coordinate. -/
structure Remaining' (g : Grid) : Prop where
  mass (c : Hist) : InactiveCaps.changes c = true → RoundedCaps.m g c ≤ RoundedCaps.dyad c 0
  pair (c : Hist) : InactiveCaps.changes c = true → RoundedCaps.p g c ≤ RoundedCaps.dyad c 4
  core (c : Hist) : ¬PositiveCap.settled c → dyad' c 1 ≤ RoundedCaps.s g 1 c
  first (c : Hist) : ¬PositiveCap.settled c → dyad' c 2 ≤ RoundedCaps.s g 0 c
  last (c : Hist) : ¬PositiveCap.settled c → dyad' c 3 ≤ RoundedCaps.s g (Fin.last 38) c

/-- As `PositiveCap.active`. The settled caps keep their targets, so `PositiveCap.bound` applies. -/
theorem active' (g : Grid) (marks : ∀ j c,0 ≤ mark g j c) (h : Remaining' g) : ActiveBounds' g := by
  have hit (c : Hist) (hc : PositiveCap.settled c) :=
    PositiveCap.bound g (PositiveCap.law_nonnegative g marks) c hc
  refine ⟨?_,?_,?_,?_,?_⟩
  · intro c e
    rw [(dyad_outer c).1]
    exact h.mass c e
  · intro c
    by_cases hc : PositiveCap.settled c
    · rw [settled_same c hc]; exact (hit c hc).1
    · exact h.core c hc
  · intro c
    by_cases hc : PositiveCap.settled c
    · rw [settled_same c hc]; exact (hit c hc).2.1
    · exact h.first c hc
  · intro c
    by_cases hc : PositiveCap.settled c
    · rw [settled_same c hc]; exact (hit c hc).2.2
    · exact h.last c hc
  · intro c e
    rw [(dyad_outer c).2]
    exact h.pair c e

end caps

section grid
open PrimeGap186 PrimeGap180.NumericalAccount PrimeGap180.PackedSiteAudit

/-- As `ActiveGridGap.physical`, with the lower target. -/
theorem physical' (caps : ActiveBounds' ActiveGridGap.grid) :
    uncutTarget * mass Restoration.original ≤ numerator Restoration.original :=
  physicalOf gridChunks gridSchema (activeFive' ActiveGridGap.grid caps)

end grid

/-! ## Terminal deduction -/

section terminal
open scoped BigOperators
open PrimeGap186 PrimeGap180.Sector PrimeGap180.FrozenData PrimeGap180.NumericalAccount
open PrimeGap180.AdverseScore

/-- As `SlackMargin.margin`, with the lower uncut target and a gain of 0.000001. -/
theorem margin (uncut : uncutTarget*mass Restoration.original ≤ numerator Restoration.original)
    (removed : restoredLoss ≤ 0.001121271547*mass Restoration.original)
    (debit : directDebit ≤ 0.0000443013*mass Restoration.original) : Terminal.Margin := by
  have pos := PositiveMass.positive
  have eq := Restoration.ordinary_split
  change mass Restoration.original = mass trial + mass Restoration.deleted at eq
  unfold restoredLoss at removed
  unfold uncutTarget at uncut
  have gain : 0.000001*mass Restoration.original <
      numerator trial-mass trial-directDebit := by linarith only [pos,uncut,removed,debit,eq]
  have strict := (mul_pos (by norm_num : (0:ℝ)<0.000001) pos).trans gain
  apply historical_margin
  unfold numerator at strict
  have hist : historical trial = rho*∑ i : Fin 39,historicalIncome i := by
    simp only [historical,historical_exact]
  rw [hist] at strict
  change mass trial + pairFor trial + directDebit < _
  linarith only [strict]

theorem gap (input : SourceSchedule.Inputs) (prices : FrozenLedger.Endpoints)
    (resource : ∀ u : Resources.Resource,u ≠ .prime → ∀ s,
      (Book.resourceRow u).price s ≤ FrozenLedger.ledger.resourceKernel u s)
    (event : ∀ e : PriceEvents.Event,e ≠ .prime → ∀ s,
      (Book.eventRow e).price s ≤ FrozenLedger.ledger.eventKernel e s)
    (densities : Terminal.DensityIntegrals)
    (uncut : uncutTarget*mass Restoration.original ≤ numerator Restoration.original)
    (removed : restoredLoss ≤ 0.001121271547*mass Restoration.original)
    (uncutDebit : PhysicalDebit.debit Restoration.original ≤ 0.000024*mass Restoration.original)
    (removedMass : mass Restoration.deleted ≤ 0.00017*mass Restoration.original) :
    primeGapLiminf ≤ (180 : EReal) :=
  Terminal.gap_of_frozen_margin input FrozenLedger.ledger (FrozenLedger.finiteChecks prices)
    ⟨FrozenFiveCovers.checked,resource,event⟩ FrozenLedger.slots densities
    FrozenMesh.checked SourceCoverageCertificate.checked ResolvedCertificate.checked
    (margin uncut removed (SlackMargin.direct uncutDebit removedMass))

end terminal

#print axioms weighted'
#print axioms physicalOf
#print axioms five'
#print axioms activeFive'
#print axioms active'
#print axioms physical'
#print axioms margin
#print axioms gap
end PrimeGap180.SlackUncut
