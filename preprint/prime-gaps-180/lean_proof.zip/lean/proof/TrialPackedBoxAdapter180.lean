import TrialPackedMetrics180
import TrialPackedCharge180
import TrialPolynomialBinSemantics180

/-! The row scanner's concrete integer inequalities imply the ratio and
Hellinger budgets for exactly the same dyadic law used by the five signed
native roles. The polynomial enclosure theorem supplies the physical side. -/
noncomputable section
open scoped Classical BigOperators
open PrimeGap180.PackedLaw PrimeGap180.LiftedBins PrimeGap180.DebitNativeClasses
namespace PrimeGap180.PackedBoxAdapter
set_option maxRecDepth 5500
set_option maxHeartbeats 1500000
attribute [local irreducible] group

def lift (g : Grid) (b : Atom) : ℚ := if h:b.1.val<130965
  then b.2.elim 0 (fun c => (g ⟨b.1.val,h⟩ c:ℚ)/PackedCharge.U) else 0

def n (g : Grid) (j : Tick) (c : Cap) : ℤ := 2^54*mark g j c

private theorem lift_at (f : Grid) (j : Tick) (c : Cap) :
    lift f (j.castSucc,some c)=(f j c:ℚ)/PackedCharge.U := by simp [lift,j.isLt]

private theorem law_at (g : Grid) (j : Tick) (c : Cap) :
    probability g (j.castSucc,some c) = (n g j c:ℚ)/PackedCharge.U := by
  rw [at_point]
  norm_num [n,base,PackedCharge.U]
  ring

private theorem live_at (b : Atom) (h : live b) :
    ∃ (j : Tick) (c : Cap), (j.castSucc,some c)=b := by
  obtain ⟨i,o⟩ := b
  have inside : i.val<130965 := lt_of_le_of_lt h.1 (by decide)
  cases o with
  | none => exact (by simpa [live] using h : False).elim
  | some c => exact ⟨⟨i.val,inside⟩,c,rfl⟩

private theorem group_sum (j : Tick) (f : Atom → ℚ) :
    (∑ b ∈ group j.val,f b) = ∑ c : Cap,f (j.castSucc,some c) := by
  let emb : Cap ↪ Atom := ⟨fun c => (j.castSucc,some c),fun a b h => Option.some.inj (congrArg Prod.snd h)⟩
  have eq : group j.val=Finset.univ.map emb := by
    ext b
    rw [mem_group,Finset.mem_map]
    obtain ⟨i,o⟩ := b
    cases o with
    | none =>
      constructor
      · rintro ⟨_,h⟩; cases h
      · rintro ⟨x,_,eq⟩
        have clash : (some x : Option Cap) = none := congrArg (fun z : Atom => z.2) eq
        cases clash
    | some c =>
      constructor
      · rintro ⟨key,_⟩
        exact ⟨c,Finset.mem_univ _,Prod.ext (Fin.ext key.symm) rfl⟩
      · rintro ⟨q,_,key⟩
        exact ⟨congrArg (fun b : Atom => b.1.val) key.symm,rfl⟩
  rw [eq,Finset.sum_map]
  rfl

abbrev L := IntegerPolynomialCells.binLow
abbrev R := IntegerPolynomialCells.binHigh

theorem boxes (g : Grid) (early : ∀ j : Tick,j.val<45067 → ∀ c,g j c=base)
    (upper : ∀ j : Tick,g j (Fin.last 36)≤base)
    (bins : ∀ j c,PackedSiteAudit.validBin (n g j c) (L j c) (R j c)=true)
    (energy : ∀ j,(∑ c : Cap,PackedSiteAudit.charge (n g j c) (L j c) (R j c))*10^50 ≤
      (2:ℤ)^128*6159^2*19999999996734^2) :
    PackedMetrics.Boxes g (lift L) (lift R) where
  early := early
  upper := upper
  nonnegative j c := by
    have ok := (of_decide_eq_true (bins j c)).1
    change 0≤2^54*mark g j c at ok
    exact nonneg_of_mul_nonneg_right ok (by norm_num)
  actual b hb := by
    obtain ⟨j,c,rfl⟩ := live_at b hb
    rw [lift_at,lift_at]
    push_cast
    exact IntegerPolynomialCells.actual_bin j c
  ratios b hb := by
    obtain ⟨j,c,rfl⟩ := live_at b hb
    rw [law_at,lift_at,lift_at]
    have rr := PackedCharge.rates (bins j c)
    norm_num [PackedMetrics.lr,PackedMetrics.ur] at rr ⊢
    exact rr
  energy j hj := by
    let k : Tick := ⟨j,by omega⟩
    rw [show j=k.val from rfl,group_sum]
    calc
      _ ≤ ∑ c : Cap,(PackedSiteAudit.charge (n g k c) (L k c) (R k c):ℚ)/PackedCharge.E := by
        apply Finset.sum_le_sum
        intro c _
        simp only [PackedMetrics.residual,lift_at,law_at]
        exact PackedCharge.energy (bins k c)
      _ ≤ _ := by
        rw [←Finset.sum_div]
        have bound : (∑ c : Cap,(PackedSiteAudit.charge (n g k c) (L k c) (R k c):ℚ))*10^50 ≤
          (2:ℚ)^128*6159^2*19999999996734^2 := by exact_mod_cast energy k
        norm_num [PackedCharge.E,PackedMetrics.hr,PackedMetrics.lr] at bound ⊢
        linarith only [bound]

#print axioms boxes
end PrimeGap180.PackedBoxAdapter
