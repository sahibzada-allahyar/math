import TrialFirstEdgeBinomial180
import TrialFirstEdgeCappedCDF180
import TrialFirstEdgeArithmetic180
import Mathlib.Data.Nat.Cast.Field
import Batteries.Tactic.OpenPrivate

/-! Direct identification with the previously kernel-evaluated multinomial.
This alternative avoids a second 37-level integer-array reduction. -/
noncomputable section
open scoped BigOperators
open MeasureTheory Set
namespace PrimeGap180.FirstEdgeClosed
open FirstEdgeBinomial FirstEdgeKernels FirstEdgeArithmetic
open private powerTerm inner from TrialFirstEdgeArithmetic180

theorem iter (m A : ℝ) (N d : ℕ) (t : ℝ) :
    ((cap m A+unit)^N) P d t = recurrence m A N d t := by
  induction N generalizing d t with
  | zero=>rfl
  | succ N ih=>
    rw [pow_succ',Module.End.mul_apply,recurrence]
    change ((-1)*(((cap m A+unit)^N) P (d+1) (t-m))+A*(((cap m A+unit)^N) P (d+0) (t-m)))+
      ((-1)*(((cap m A+unit)^N) P (d+2) (t-1))+1*(((cap m A+unit)^N) P (d+2) (t-0)))=_
    simp only [ih,Nat.add_zero,sub_zero]
    ring

private theorem fold (N : ℕ) (f : ℕ→ℤ) (z : ℤ) :
    (List.range N).foldl (fun x i=>x+f i) z=z+∑ i∈Finset.range N,f i := by
  induction N with
  | zero=>simp
  | succ N ih=>rw [List.range_succ,List.foldl_append,Finset.sum_range_succ];simp [ih,add_assoc]

private def coeff (m B k j a : ℕ) (A : ℝ) :=
  (n.choose k:ℝ)*(k.choose j:ℝ)*((n-k).choose a:ℝ)*(-1:ℝ)^j*(-1:ℝ)^a*A^(k-j)*
    P (2*(n-k)+j) ((B:ℝ)/q-k*((m:ℝ)/q)-a)

def D : ℝ:=2^n*(q:ℝ)^(2*n)*(2*n).factorial

private theorem term (B m k j a : ℕ) (kn : k≤n) (jk : j≤k) :
    (powerTerm B m k j a:ℝ)=D*coeff m B k j a (1/2) := by
  let d:=2*(n-k)+j
  let s:=k*m+a*q
  have dn : d≤2*n:=by dsimp [d];omega
  have POS : 0<(q:ℝ):=by norm_num [q]
  have arg : (B:ℝ)/q-k*((m:ℝ)/q)-a=((B:ℝ)-(s:ℝ))/q := by
    unfold s;push_cast;field_simp;ring
  have dQ : (q:ℝ)^(2*n)=(q:ℝ)^(2*n-d)*(q:ℝ)^d:=by rw [←pow_add,Nat.sub_add_cancel dn]
  have scal : (2:ℝ)^n*(1/2:ℝ)^(k-j)=(2:ℝ)^(n-k+j) := by
    rw [one_div,inv_pow,←div_eq_mul_inv,div_eq_iff (by positivity),←pow_add]
    congr 1
    omega
  have sign : (-1:ℝ)^j * (-1:ℝ)^a = if (a+j)%2=0 then 1 else -1 := by
    rw [←pow_add,Nat.add_comm,neg_one_pow_eq_ite]
    simp only [Nat.even_iff]
  by_cases less : B<s
  · have off : ¬0≤((B:ℝ)-(s:ℝ))/q := not_le.mpr <| div_neg_of_neg_of_pos (sub_neg.mpr (by exact_mod_cast less)) POS
    simp [powerTerm,show B<k*m+a*q from less,coeff,arg,P,off]
  · have le:=Nat.le_of_not_gt less
    have yes : 0≤((B:ℝ)-(s:ℝ))/q:=div_nonneg (sub_nonneg.mpr (by exact_mod_cast le)) POS.le
    let v : ℝ:=(n.choose k:ℝ)*(k.choose j:ℝ)*((n-k).choose a:ℝ)*
        2^(n-k+j)*(((2*n).factorial:ℝ)/(d.factorial:ℝ))*
        (q:ℝ)^(2*n-d)*((B:ℝ)-(s:ℝ))^d
    have raw : (powerTerm B m k j a:ℝ)=(if (a+j)%2=0 then 1 else -1)*v := by
      unfold powerTerm
      simp only [show ¬ B<k*m+a*q from less,ite_false]
      have dv := Nat.factorial_dvd_factorial dn
      change (d.factorial ∣ (2*n).factorial) at dv
      have subeq : ((B - s : ℕ) : ℝ) = (B:ℝ)-(s:ℝ) := Nat.cast_sub le
      have diveq : ((((2*n).factorial / d.factorial : ℕ) : ℝ)) =
          ((2*n).factorial:ℝ) / (d.factorial:ℝ) := Nat.cast_div_charZero dv
      by_cases parity : (a+j)%2=0 <;>
        simp only [parity,ite_true,ite_false,Int.cast_neg,Int.cast_natCast,Nat.cast_mul,Nat.cast_pow,Nat.cast_ofNat,
          Int.cast_mul,Int.cast_pow,Int.cast_ofNat,Int.cast_natCast,
          one_mul,neg_one_mul,v] <;> try (rw [diveq,subeq])
    rw [raw,←sign,coeff,arg,P,ite_eq_left yes,D,dQ]
    change ((-1:ℝ)^j*(-1:ℝ)^a)*v=_
    unfold v
    have qd : (q:ℝ)^d≠0:=pow_ne_zero _ POS.ne'
    have fac : (d.factorial:ℝ)≠0:=by positivity
    change _ = 2^n * ((q:ℝ)^(2*n-d) * (q:ℝ)^d) * ((2*n).factorial:ℝ) *
      ((n.choose k:ℝ)*(k.choose j:ℝ)*((n-k).choose a:ℝ)*(-1:ℝ)^j*(-1:ℝ)^a*
        (1/2:ℝ)^(k-j)*((((B:ℝ)-(s:ℝ))/(q:ℝ))^d/(d.factorial:ℝ)))
    rw [←scal,div_pow ((B:ℝ)-(s:ℝ)) (q:ℝ) d]
    generalize ((1/2:ℝ)^(k-j)) = weight
    field_simp [qd,fac] <;> ring

private theorem uncut (m B : ℕ) (A : ℝ) :
    recurrence ((m:ℝ)/q) A n 0 ((B:ℝ)/q) =
      ∑ k∈Finset.range (n+1),∑ j∈Finset.range (k+1),∑ a∈Finset.range (n-k+1),coeff m B k j a A := by
  rw [←iter,expanded]
  simp only [Nat.zero_add]
  apply Finset.sum_congr rfl
  intro k _
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro j _
  rw [←mul_assoc,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro a _
  unfold coeff
  rw [Nat.add_comm j (2*(n-k))]
  ring

private theorem short (m B k j a : ℕ) (skip : B<k*m) : powerTerm B m k j a=0 := by
  have h : B<k*m+a*q:=by omega
  simp [powerTerm,h]

/-- The producer's original fold, including its early skip for cap shifts
above the budget, equals the full integer sum at the half-atom cutoff. -/
private theorem expanded_int (m B : ℕ) (on : Bool) :
    cdfNumerator m B on=∑ k∈Finset.range (n+1),if on then
      ∑ j∈Finset.range (k+1),∑ a∈Finset.range (n-k+1),powerTerm B m k j a
      else ∑ a∈Finset.range (n-k+1),powerTerm B m k k a := by
  let row:=fun k=>if on then (List.range (k+1)).foldl (fun z j=>z+inner B m k j) 0 else inner B m k k
  have repr : cdfNumerator m B on=(List.range (n+1)).foldl (fun z k=>z+(if B<k*m then 0 else row k)) 0 := by
    unfold cdfNumerator
    congr 1
    funext z k
    by_cases h : B<k*m <;> simp [h,row]
  rw [repr,fold,zero_add]
  apply Finset.sum_congr rfl
  intro k _
  by_cases skip : B<k*m
  · simp [skip,short _ _ _ _ _ skip]
  · have inner_eq (j : Nat) : inner B m k j = ∑ a∈Finset.range (n-k+1), powerTerm B m k j a :=
      (fold (n-k+1) (fun a => powerTerm B m k j a) 0).trans (zero_add _)
    simp [skip,row,fold,inner_eq]

theorem scaled (m B : ℕ) (on : Bool) :
    (cdfNumerator m B on:ℝ)=D*recurrence ((m:ℝ)/q) (if on then 1/2 else 0) n 0 ((B:ℝ)/q) := by
  rw [expanded_int,Int.cast_sum,uncut,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro k hk
  have kn : k≤n:=by simpa using Finset.mem_range.mp hk
  rw [Finset.mul_sum]
  cases on with
  | true=>
    simp only [ite_true,Int.cast_sum]
    apply Finset.sum_congr rfl
    intro j hj
    rw [Finset.mul_sum]
    exact Finset.sum_congr rfl fun a _=>term B m k j a kn (by simpa using Finset.mem_range.mp hj)
  | false=>
    simp only [Bool.false_eq_true,ite_false,Int.cast_sum]
    have remove : (∑ j∈Finset.range (k+1), D*∑ a∈Finset.range (n-k+1), coeff m B k j a 0) =
        D*∑ a∈Finset.range (n-k+1), coeff m B k k a 0 := by
      apply Finset.sum_eq_single k
      · intro j hj ne
        have jk : j<k:=by have:=Finset.mem_range.mp hj;omega
        simp [coeff,zero_pow (Nat.sub_ne_zero_of_lt jk)]
      · simp
    rw [remove,Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro a _
    simpa [coeff] using term B m k k a kn le_rfl

#print axioms scaled
end PrimeGap180.FirstEdgeClosed
