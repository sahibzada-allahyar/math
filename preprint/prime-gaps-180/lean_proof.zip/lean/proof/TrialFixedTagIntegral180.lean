import TrialJanossyRadial180

/-! Exact positive one-site law on the event of a specified number of marks.
The case k = 2 keeps the unordered-pair factor before the signed spline is squared. -/
noncomputable section
open scoped BigOperators ENNReal Classical
open MeasureTheory PrimeGap186 PrimeGap180.JanossyLaw
namespace PrimeGap180.FixedTagIntegral

open private marks from TrialJanossyRadial180

def markCount (e : ℝ) (X : FiniteMeasure ℝ) := physicalSourceCountMeasure (fun _ : Fin 1 => X) (Set.Ioi e)

theorem count_meas (e : ℝ) : Measurable (markCount e) :=
  (Measure.measurable_coe measurableSet_Ioi).comp ((physicalSourceCountMeasure_regular 1).1.comp
    (measurable_pi_lambda _ fun _ => measurable_id))

theorem after_insert {e : ℝ} (he : 0 < e) (Y : FiniteMeasure ℝ) (n : ℕ) (x : Fin n → ℝ)
    (hY : Y.restrict (Set.Ioc 0 e) = Y) (hx : ∀ a, e < x a) :
    markCount e (Y + weightedEmpirical n x) = n := by
  have h := (trial_finite_tail_mass_and_count 1 e he (fun _ => Y) (fun _ => n) (fun _ => x)
    (fun _ => hY) (fun _ => hx)).2
  have atom (a : (_ : Fin 1) × Fin n) : Measure.dirac (x a.2) (Set.Ioi e) = 1 :=
    Measure.dirac_apply_of_mem (hx a.2)
  unfold markCount
  rw [←Measure.restrict_eq_self _ (Set.Subset.rfl : Set.Ioi e ⊆ Set.Ioi e),h,Measure.finsetSum_apply]
  simp only [atom,Finset.sum_const,Finset.card_univ,nsmul_eq_mul,mul_one,Fintype.card_sigma,
    Fintype.card_fin,Finset.sum_const,Finset.card_univ,one_smul]

/-- A measurable nonnegative function may depend on the entire fragment
configuration, including the angular spline coefficients on a native cell. -/
theorem fixed {e b : ℝ} (he : 0 < e) (hb : e ≤ b) (k : ℕ)
    (F : FiniteMeasure ℝ → ℝ≥0∞) (hf : Measurable F) :
    (∫⁻ X in {X | markCount e X = k}, F X ∂PoissonSplit.phys b) =
       ∫⁻ Y, (k.factorial:ℝ≥0∞)⁻¹ * ∫⁻ u : Fin k → ℝ, F (Y + weightedEmpirical k u)
         ∂prodLaw e b k ∂PoissonSplit.phys e := by
  let A := {X | markCount e X = k}
  have hm : MeasurableSet A := measurableSet_eq_fun (count_meas e) measurable_const
  change (∫⁻ X in A, F X ∂PoissonSplit.phys b) = _
  rw [←lintegral_indicator hm,PoissonSplit.physical_marks he hb _ (hf.indicator hm)]
  have small : ∀ᵐ Y ∂PoissonSplit.phys e, Y.restrict (Set.Ioc 0 e) = Y :=
    Measure.ae_smul_measure (ae_restrict_Ioc_fragmentLaw e)
      (ENNReal.ofReal (Real.exp Real.eulerMascheroniConstant*e))
  apply lintegral_congr_ae
  filter_upwards [small] with Y hY
  change (∑' n : ℕ, (n.factorial:ℝ≥0∞)⁻¹ * ∫⁻ u : Fin n → ℝ,
     A.indicator F (Y + weightedEmpirical n u) ∂prodLaw e b n) = _
  have agrees (n : ℕ) : (∫⁻ u : Fin n → ℝ, A.indicator F (Y + weightedEmpirical n u) ∂prodLaw e b n) =
    ∫⁻ u : Fin n → ℝ, (if n = k then F (Y + weightedEmpirical n u) else 0) ∂prodLaw e b n := by
    apply lintegral_congr_ae
    filter_upwards [marks he hb n] with u hu
    have c := after_insert he Y n u hY (fun j => (hu j).1)
    by_cases on : n = k
    · have mem : Y + weightedEmpirical n u ∈ A := c.trans (congrArg (fun j : ℕ => (j:ℝ≥0∞)) on)
      simp only [Set.indicator_of_mem mem,ite_eq_left on]
    · have off : Y + weightedEmpirical n u ∉ A := by
        intro h
        change markCount e (Y + weightedEmpirical n u) = (k:ℝ≥0∞) at h
        exact on (by exact_mod_cast c.symm.trans h)
      simp only [Set.indicator_of_notMem off,ite_eq_right on]
  rw [tsum_eq_single k]
  · rw [agrees]
    simp only [ite_true]
  · intro n h
    rw [agrees]
    simp [h]

#print axioms after_insert
#print axioms fixed
end PrimeGap180.FixedTagIntegral
