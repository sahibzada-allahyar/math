import TrialJointEdgeFull180
import TrialFirstEdgeSplit180

/-! The ordinary-debit integral for the first two of the fourteen physical low rows. -/
noncomputable section
open MeasureTheory Set PrimeGap180.FrozenProfile PrimeGap180.Sector PrimeGap180.GateDeletion
open scoped Classical ENNReal BigOperators
namespace PrimeGap180.JointEdgeLowRows
open JointEdgeConditional JointEdgeSecondNumbers
open private upper from TrialFirstEdgeSplit180

/-- Physical failed-erasure envelope used by `RemovedLowProjection.lowEvent`. -/
def row (a : Active) : Set Full := {v | ∃ i : Fin 39,
  (∑ j, RemovedLowProjection.slackDust (i.removeNth v) j a) < 2*FrozenData.parentUpper a}

private theorem row_scale (a : Active) {scale : ℝ} (hs : 0 < scale) :
    row a = erasedSet (T.tailEdge a) scale ((scale/Lookup.ticks)*(2*FrozenData.parentUpper a)) := by
  ext v
  change (∃ i : Fin 39, _) ↔ ∃ i : Fin 39, _
  apply exists_congr
  intro i
  have tt : 0 < Lookup.ticks := by norm_num [Lookup.ticks]
  have per (j : Fin 38) : JointEdgeFailure.slack (T.tailEdge a) scale (v (i.succAbove j)) =
      (scale/Lookup.ticks)*RemovedLowProjection.slackDust (i.removeNth v) j a := by
    unfold RemovedLowProjection.slackDust JointEdgeFailure.slack NativeSiteLaw.tail
    change scale*(_-_) = (scale/Lookup.ticks)*(Lookup.ticks*((_-_)+(_-_)))
    simp only [Fin.removeNth_apply]
    field_simp
    ring
  simp_rw [per]
  rw [←Finset.mul_sum, mul_lt_mul_iff_right₀ (div_pos hs tt)]

set_option maxRecDepth 65536 in
private theorem u1 : FrozenData.parentUpperNat 1 = 300 := by decide +kernel
private theorem first_row : row 0 = erasedSet FirstEdgeProbability.j Lookup.ticks 200 := by
  rw [row_scale 0 (show 0<Lookup.ticks by norm_num [Lookup.ticks]), FrozenData.parentUpper_nat,upper]
  norm_num [Lookup.ticks,FirstEdgeProbability.j]

private theorem second_row : row 1 = erasedSet JointEdgeSecond.j (JointEdgeSecond.h)⁻¹ (600/(JointEdgeSecondNumbers.w:ℝ)) := by
  rw [row_scale 1 (show 0<JointEdgeSecond.h⁻¹ by norm_num [JointEdgeSecond.h,Native.step]),
    FrozenData.parentUpper_nat,u1]
  norm_num [JointEdgeSecond.j,T,JointEdgeSecond.h,Native.step,Lookup.ticks,JointEdgeSecondNumbers.w]

/-- This bounds the uncut original 39-site square, uniformly over all 39 possible erasures. -/
theorem ordinary :
    (∫ v in row 0 ∪ row 1, (Restoration.original v)^2 ∂CoarseLaw.prod 39) ≤
      (53209245/(10:ℝ)^15)*(∫ v, (Restoration.original v)^2 ∂CoarseLaw.prod 39) := by
  rw [first_row,second_row]
  exact JointEdgeFull.ordinary

#print axioms ordinary
end PrimeGap180.JointEdgeLowRows
