import TrialUncutForms180
import TrialSiteLawComparison180
/-! Absolute product bounds with at most two changed site indices on the original support. -/
noncomputable section
open scoped Classical BigOperators
open MeasureTheory PrimeGap180.CoarseLaw PrimeGap180.CoarseForms PrimeGap180.FrozenProfile
open PrimeGap180.UncutForms
namespace PrimeGap180.RootRatios

private theorem weights_nonneg (s : State) : 0 ≤ weight s := measureReal_nonneg

private theorem raw_room_index (t : Tables) (j : Fin 39 → ℕ) (c : Fine) (nz : raw t j c ≠ 0) :
    (∑ i,j i) ≤ 130964 := by
  by_contra! gt
  exact nz (ite_eq_left ((min_le_left 130964 (t.maxIndex c)).trans_lt gt))

attribute [local irreducible] CoarseForms.maxClass CoarseLaw.weight FrozenData.tables
set_option maxHeartbeats 1200000 in
theorem room (x : Root) (nz : rawState x ≠ 0) : (∑ i,(x i).1.val) ≤ 130964 := by
  cases c : maxClass x with
  | none =>
    have e : rawState x = 0 := by unfold rawState; rw [c]
    exact (nz e).elim
  | some k =>
    have e : rawState x = raw T (idx x) k := by unfold rawState; rw [c]
    exact raw_room_index T (idx x) k (fun zero => nz (e.trans zero))

private theorem prod_bound (j : Fin 39 → ℕ) (p q : Fin 39 → ℝ) {l : ℝ}
    (l0 : 0 ≤ l) (l1 : l ≤ 1) (nn : ∀ i,0 ≤ p i)
    (ok : (∑ i,j i) ≤ 130964) (ratio : ∀ i,(if 45067 ≤ j i then l else 1)*p i ≤ q i) :
    l^2*∏ i,p i ≤ ∏ i,q i := by
  let highs := Finset.univ.filter (fun i => 45067 ≤ j i)
  have ct : l^2 ≤ l^highs.card := pow_le_pow_of_le_one l0 l1 (SiteLawComparison.at_most_two j ok)
  have values : (∏ i,if 45067 ≤ j i then l else 1) = l^highs.card := by
    simpa [highs] using (Finset.prod_ite_mem_eq highs (fun _ => l))
  calc
    _ ≤ l^highs.card*∏ i,p i := mul_le_mul_of_nonneg_right ct (Finset.prod_nonneg fun i _ => nn i)
    _ = ∏ i,(if 45067 ≤ j i then l else 1)*p i := by rw [Finset.prod_mul_distrib,values]
    _ ≤ _ := Finset.prod_le_prod (fun i _ => mul_nonneg (by split_ifs <;> positivity) (nn i)) (fun i _ => ratio i)

private theorem root_sq (w : State → ℝ) (nn : ∀ s,0 ≤ w s) (x : Root) :
    (roots w x)^2 = ∏ i,w (x i) := by
  unfold roots; rw [←Finset.prod_pow]
  exact Finset.prod_congr rfl fun i _ => Real.sq_sqrt (nn _)

theorem vector_ratio (w : State → ℝ) (nn : ∀ s,0 ≤ w s) {l u : ℝ}
    (l0 : 0 ≤ l) (l1 : l ≤ 1) (u1 : 1 ≤ u)
    (same : ∀ s : State,s.1.val<45067 → weight s=w s)
    (inc : ∀ s : State,45067 ≤ s.1.val → s.1.val≤130964 → l*w s ≤ weight s ∧ weight s ≤ u*w s)
    (x : Root) : ∃ r : ℝ,l ≤ r ∧ r ≤ u ∧ vector weight x = r*vector w x := by
  by_cases alive : rawState x ≠ 0
  · have ok := room x alive
    have small (i : Fin 39) : (x i).1.val ≤ 130964 :=
      (Finset.single_le_sum (f := fun j => (x j).1.val) (fun _ _ => Nat.zero_le _) (Finset.mem_univ i)).trans ok
    have wp : 0 ≤ roots w x := Finset.prod_nonneg (fun _ _ => Real.sqrt_nonneg _)
    have tp : 0 ≤ roots weight x := Finset.prod_nonneg (fun _ _ => Real.sqrt_nonneg _)
    have up : 0 < u := zero_lt_one.trans_le u1
    have low : l*roots w x ≤ roots weight x := by
      apply (sq_le_sq₀ (mul_nonneg l0 wp) tp).mp
      rw [mul_pow,root_sq w nn,roots_sq]
      apply prod_bound (fun i => (x i).1.val) (fun i => w (x i)) (fun i => weight (x i)) l0 l1 (fun i => nn (x i)) ok
      intro i
      by_cases h : 45067 ≤ (x i).1.val
      · simpa only [ite_eq_left h] using (inc _ h (small i)).1
      · simp [h,same (x i) (lt_of_not_ge h)]
    have high : roots weight x ≤ u*roots w x := by
      apply (sq_le_sq₀ tp (mul_nonneg up.le wp)).mp
      rw [mul_pow,roots_sq,root_sq w nn]
      have bb := prod_bound (fun i => (x i).1.val) (fun i => weight (x i)) (fun i => w (x i))
        (inv_nonneg.mpr up.le) ((inv_le_one₀ up).mpr u1) (fun i => weights_nonneg (x i)) ok (fun i => by
          by_cases h : 45067 ≤ (x i).1.val
          · rw [ite_eq_left h,←div_eq_inv_mul]
            exact (div_le_iff₀ up).mpr ((inc _ h (small i)).2.trans_eq (mul_comm _ _))
          · simp [h,same (x i) (lt_of_not_ge h)])
      rw [inv_pow,←div_eq_inv_mul] at bb
      exact ((div_le_iff₀ (sq_pos_of_pos up)).mp bb).trans_eq (mul_comm _ _)
    by_cases empty : roots w x=0
    · have z : roots weight x=0 := le_antisymm (by simpa [empty] using high) tp
      exact ⟨1,l1,u1,by simp [vector,empty,z]⟩
    · have pp : 0 < roots w x := lt_of_le_of_ne wp (fun h => empty h.symm)
      refine ⟨roots weight x/roots w x,(le_div_iff₀ pp).mpr low,(div_le_iff₀ pp).mpr high,?_⟩
      unfold vector; field_simp
  · exact ⟨1,l1,u1,by simp [vector,not_ne_iff.mp alive]⟩

#print axioms room
#print axioms vector_ratio
end PrimeGap180.RootRatios
