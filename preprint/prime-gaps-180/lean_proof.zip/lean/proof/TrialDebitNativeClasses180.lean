import TrialDebitCapMap180
import TrialPhysicalDebit180
import TrialCapDifferences180

/-! The original 37 price classes as observations on the 44 physical cap
thresholds. The extra thresholds affect restoration and have the same
original spline and prices as their first historical owner. -/
noncomputable section
open scoped Classical BigOperators
open PrimeGap180.FrozenProfile PrimeGap180.CoarseLaw PrimeGap180.CoarseForms
namespace PrimeGap180.DebitNativeClasses

private theorem adj : ∀ (c : Fine) (k : Class), cover c ≤ k ↔ c ≤ capAt k := by
  decide +kernel

private theorem cap_mono : Monotone capAt := Fin.monotone_iff_le_succ.mpr (by decide +kernel)

private theorem owner_fixed : ∀ c : Fine, ¬(c=0 ∨ c=1 ∨ c=2 ∨ c=3 ∨ c=14 ∨ c=22 ∨ c=42) →
    capAt (cover c)=c := by decide +kernel

set_option maxRecDepth 65000 in
private theorem edge_mono : Monotone T.capEdge :=
  Fin.monotone_iff_le_succ.mpr (by decide +kernel)

private theorem owner_data (c : Fine) :
    T.maxIndex c = T.maxIndex (capAt (cover c)) ∧
    T.row c = T.row (capAt (cover c)) ∧
    T.sector c = T.sector (capAt (cover c)) := by
  by_cases exceptional : c=0 ∨ c=1 ∨ c=2 ∨ c=3 ∨ c=14 ∨ c=22 ∨ c=42
  · rcases exceptional with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> exact ⟨rfl,rfl,rfl⟩
  · simp [owner_fixed c exceptional]

private theorem raw_owner (j : Fin 39 → ℕ) (c : Fine) :
    raw T j c = raw T j (capAt (cover c)) := by
  simp only [raw,amplitude,(owner_data c).1,(owner_data c).2.1]

private theorem chosen {n : ℕ} {p : Fin n → Bool} {c : Fin n} (h : least p=some c) :
    p c = true ∧ ∀ z, p z=true → c ≤ z := by
  let S := Finset.univ.filter (fun k => p k=true)
  change (if e : S.Nonempty then some (S.min' e) else none)=some c at h
  split at h
  next e =>
    obtain rfl := Option.some.inj h
    exact ⟨(Finset.mem_filter.mp (S.min'_mem e)).2,fun z hz => S.min'_le _ (Finset.mem_filter.mpr ⟨Finset.mem_univ _,hz⟩)⟩
  next => contradiction

private theorem choose {n : ℕ} {p : Fin n → Bool} (c : Fin n) (on : p c=true)
    (minimal : ∀ k,p k=true → c ≤ k) : least p=some c := by
  let S := Finset.univ.filter (fun k => p k=true)
  have a : c ∈ S := Finset.mem_filter.mpr ⟨Finset.mem_univ _,on⟩
  have e : S.Nonempty := ⟨c,a⟩
  change (if h : S.Nonempty then some (S.min' h) else none)=some c
  rw [dite_eq_left e]
  exact congrArg some (le_antisymm (S.min'_le _ a) (minimal _ (Finset.mem_filter.mp (S.min'_mem e)).2))

private theorem empty {n : ℕ} {p : Fin n → Bool} (h : least p=none) (c : Fin n) : p c=false := by
  by_contra! on
  let S := Finset.univ.filter (fun k => p k=true)
  have e : S.Nonempty := ⟨c,Finset.mem_filter.mpr ⟨Finset.mem_univ _,by simpa using on⟩⟩
  change (if h : S.Nonempty then some (S.min' h) else none)=none at h
  rw [dite_eq_left e] at h
  contradiction

private theorem map_least (p : Fine → Bool) (mono : ∀ a b,a≤b → p a=true → p b=true) :
    least (p ∘ capAt) = (least p).map cover := by
  cases e : least p with
  | none =>
    cases q : least (p ∘ capAt) with
    | none => rfl
    | some k =>
      have yes : p (capAt k)=true := (chosen q).1
      rw [empty e _] at yes
      contradiction
  | some c =>
    have on := chosen e
    exact choose (cover c) (mono _ _ ((adj c (cover c)).mp le_rfl) on.1)
      (fun k hk => (adj c k).mpr (on.2 _ hk))

def atom (z : State) : Atom := (z.1,least (fun k => z.2 (capAt k)))
def accepts (o : Option Class) (k : Class) := match o with
  | none => false
  | some b => decide (b ≤ k)
def maximum {d : ℕ} (x : Fin d → Atom) := least (fun k => decide (∀ i,accepts (x i).2 k=true))

private theorem observes (z : State) (nz : weight z ≠ 0) (k : Class) :
    accepts (atom z).2 k = z.2 (capAt k) := by
  let p := fun a => z.2 (capAt a)
  change accepts (least p) k=p k
  cases e : least p with
  | none => exact (empty e k).symm
  | some b =>
    have on := chosen e
    change decide (b ≤ k) = p k
    by_cases le : b≤k
    · rw [decide_eq_true le]
      exact (CellQuadrature.nested _ _ (edge_mono (cap_mono le)) z nz on.1).symm
    · rw [decide_eq_false le]
      cases pk : p k with
      | false => rfl
      | true => exact (le (on.2 k pk)).elim

theorem atom_has_class (z : State) (nz : weight z ≠ 0) :
    (∃ c : Fine,z.2 c=true) ↔ (atom z).2.isSome=true := by
  constructor
  · rintro ⟨c,hc⟩
    have tested := CellQuadrature.nested c (capAt (cover c))
      (edge_mono ((adj c (cover c)).mp le_rfl)) z nz hc
    have on := (observes z nz (cover c)).trans tested
    cases e : (atom z).2 with
    | none => rw [e] at on; cases on
    | some k => rfl
  · intro present
    cases e : (atom z).2 with
    | none => simp [e] at present
    | some k =>
      refine ⟨capAt k,?_⟩
      rw [←observes z nz k,e]
      simp [accepts]

theorem observes_public (z : State) (nz : weight z ≠ 0) (k : Class) :
    accepts (atom z).2 k = z.2 (capAt k) := observes z nz k

theorem edge_mono_public : Monotone T.capEdge := edge_mono

theorem first_atom (z : State) (nz : weight z ≠ 0) :
    (atom z).2=some 0 ↔ z.2 (capAt 0)=true := by
  rw [←observes z nz 0]
  cases h : (atom z).2 with
  | none => simp [accepts]
  | some b => simp [accepts]

theorem next_atom (z : State) (nz : weight z ≠ 0) (k : Fin 36) :
    (atom z).2=some k.succ ↔ z.2 (capAt k.succ)=true ∧ z.2 (capAt k.castSucc)=false := by
  rw [←observes z nz k.succ,←observes z nz k.castSucc]
  cases h : (atom z).2 with
  | none => simp [accepts]
  | some b =>
    have numeric : b=k.succ ↔ b≤k.succ ∧ ¬b≤k.castSucc := by
      rw [Fin.ext_iff]
      change b.val=k.val+1 ↔ b.val≤k.val+1 ∧ ¬b.val≤k.val
      omega
    simpa [accepts] using numeric

theorem maximum_eq {d : ℕ} (x : Fin d → State) (nz : ∀ i,weight (x i) ≠ 0) :
    maximum (atom ∘ x) = (maxClass x).map cover := by
  let p := fun c : Fine => decide (∀ i,(x i).2 c=true)
  have eq (k : Class) : decide (∀ i,accepts ((atom ∘ x) i).2 k=true) = p (capAt k) := by
    simp only [Function.comp_apply,fun i => observes (x i) (nz i) k,p]
  change least _ = (least p).map cover
  rw [show (fun k => decide (∀ i,accepts ((atom ∘ x) i).2 k=true)) = p ∘ capAt from funext eq]
  apply map_least
  intro a b le on
  exact decide_eq_true fun i => CellQuadrature.nested _ _ (edge_mono le) _ (nz i) ((of_decide_eq_true on) i)

def rawAtom (x : Fin 39 → Atom) : ℝ :=
  match maximum x with
  | none => 0
  | some k => raw T (fun i => (x i).1.val) (capAt k)
def retained {d : ℕ} (x : Fin d → Atom) := ∑ i,(x i).1.val
def sectorAtom (x : Fin 38 → Atom) : Label := (do
  let k ← maximum x
  let c := capAt k
  if retained x > T.maxIndex c then none else T.sector c (retained x+1)).getD 170
def rateAtom (x : Fin 38 → Atom) := PhysicalDebit.rate (sectorAtom x) (retained x)

def live (b : Atom) : Prop := b.1.val ≤ 130964 ∧ b.2.isSome=true

theorem live_of_raw (x : Fin 39 → Atom) (nz : rawAtom x ≠ 0) (i : Fin 39) : live (x i) := by
  unfold rawAtom at nz
  split at nz
  next => exact (nz rfl).elim
  next k e =>
    have enabled := (of_decide_eq_true (chosen e).1) i
    have cap : (∑ j,(x j).1.val) ≤ 130964 := by
      by_contra! large
      exact nz (ite_eq_left ((min_le_left 130964 _).trans_lt large))
    refine ⟨(Finset.single_le_sum (f := fun j => (x j).1.val) (fun _ _ => Nat.zero_le _) (Finset.mem_univ i)).trans cap,?_⟩
    cases h : (x i).2 <;> simp_all [accepts]

theorem original_eq (x : Fin 39 → State) (nz : ∀ i,weight (x i) ≠ 0) : rawState x=rawAtom (atom ∘ x) := by
  unfold rawAtom rawState
  rw [maximum_eq x nz]
  cases e : maxClass x with
  | none => rfl
  | some c => exact raw_owner (idx x) c

theorem label_eq (x : Fin 38 → State) (nz : ∀ i,weight (x i) ≠ 0) :
    NativeContractions.label x = sectorAtom (atom ∘ x) := by
  unfold sectorAtom NativeContractions.label NativeContractions.retained
  rw [maximum_eq x nz]
  have index : retained (atom ∘ x)=NativeContractions.total x := rfl
  rw [index]
  cases e : maxClass x with
  | none => rfl
  | some c =>
    have mc := (owner_data c).1.symm
    have sc := (owner_data c).2.2.symm
    by_cases big : NativeContractions.total x > T.maxIndex c
    · simp [mc,sc,big]
    · cases q : T.sector c (NativeContractions.total x+1) <;> simp [mc,sc,big,q]

#print axioms original_eq
#print axioms label_eq
end PrimeGap180.DebitNativeClasses
