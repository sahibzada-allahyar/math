import TrialPriceIsolatedChecks180
import TrialPriceTransposeGroupCommand180
import TrialPriceBalancedCharge180
import TrialPriceAffinePhysical180

noncomputable section

namespace PrimeGap180.PriceIsolatedGroup.G403
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 403

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G403

namespace PrimeGap180.PriceIsolatedGroup.G408
open Book PriceRows
set_option maxRecDepth 131072
set_option maxHeartbeats 400000000

verifyTransposedPriceGroup 408

#print axioms events
end PrimeGap180.PriceIsolatedGroup.G408
