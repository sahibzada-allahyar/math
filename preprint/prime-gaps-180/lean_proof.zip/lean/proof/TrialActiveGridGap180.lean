import TrialHistoricalSiteGrid180
import TrialActiveCapGoals180
import TrialRelaxedFive180

/-! The concrete, kernel-verified historical site grid with the 129 active
role comparisons, the original deletion/debit estimates and the source inputs. -/
noncomputable section
open PrimeGap186 PrimeGap180.NumericalAccount PrimeGap180.PackedSiteAudit
namespace PrimeGap180.ActiveGridGap

abbrev grid := PolynomialUncut.data gridChunks

theorem physical (caps : RoundedCaps.ActiveBounds grid) :
    RelaxedMargin.target * mass Restoration.original ≤ numerator Restoration.original :=
  RelaxedFive.physical gridChunks gridSchema (RoundedCaps.active grid caps)

theorem gap (input : SourceSchedule.Inputs) (prices : FrozenLedger.Endpoints)
    (resource : ∀ u : Resources.Resource,u ≠ .prime → ∀ s,
      (Book.resourceRow u).price s ≤ FrozenLedger.ledger.resourceKernel u s)
    (event : ∀ e : PriceEvents.Event,e ≠ .prime → ∀ s,
      (Book.eventRow e).price s ≤ FrozenLedger.ledger.eventKernel e s)
    (densities : Terminal.DensityIntegrals) (caps : RoundedCaps.ActiveBounds grid)
    (removed : restoredLoss ≤ (0.000071406420+0.001035091858)*mass Restoration.original)
    (uncutDebit : PhysicalDebit.debit Restoration.original ≤ 0.000023399*mass Restoration.original)
    (removedMass : mass Restoration.deleted ≤ 0.000160674*mass Restoration.original) :
    primeGapLiminf ≤ (180 : EReal) :=
  RelaxedMargin.gap input prices resource event densities (physical caps) removed uncutDebit removedMass

#print axioms physical
#print axioms gap
end PrimeGap180.ActiveGridGap
