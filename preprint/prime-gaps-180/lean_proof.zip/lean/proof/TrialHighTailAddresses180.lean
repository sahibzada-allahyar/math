import TrialHighMassBands180
import TrialHighTailPhysical180

/-! Locate every native cutoff used by a single marked band or a pair of
marked bands, including clipping above the allowed site radius. -/
noncomputable section
namespace PrimeGap180.HighTailAddresses
open HighMassBands RemovedHighTags HighTailTiles
open scoped BigOperators

abbrev Edge := Option (Fin 10)
def coordinate : Fin 10 → ℝ := Fin.cases cutoff top
def rational : Fin 10 → ℚ :=
  Fin.cases ((940000:ℚ)/2624990) fun k => (nativeCap k:ℚ)*HighTailSweep.step

def realValue (e : Edge) := e.elim 0 coordinate
def ratValue (e : Edge) := e.elim 0 rational

private theorem step_eq : (HighTailSweep.step : ℝ) = Native.step := by
  norm_num [HighTailSweep.step,HighTailSweep.num,HighTailSweep.den,Native.step]

theorem edge_cast (e : Edge) : (ratValue e : ℝ) = realValue e := by
  cases e with
  | none => simp [ratValue,realValue]
  | some t =>
    induction t using Fin.cases with
    | zero => norm_num [ratValue,realValue,rational,coordinate,cutoff,Sector.Lookup.ticks]
    | succ k => simp [ratValue,realValue,rational,coordinate,capTable,step_eq]

def native (a b : Edge) := min ⌊(ratValue a + ratValue b)/HighTailSweep.step⌋₊ 131072
def indices : Array ℕ := #[0, 44022, 46567, 47096, 58332, 60089, 61104, 63177, 64599, 65536, 78116, 88044, 90589, 91118, 93134, 93663, 94192, 102354, 104111, 104899, 105126, 105428, 106656, 107185, 107199, 107671, 108200, 108621, 109558, 109744, 110273, 111166, 111695, 112103, 112632, 116664, 118421, 119436, 120178, 121193, 121509, 122138, 122208, 122931, 123266, 123868, 124281, 124683, 124688, 125212, 125625, 125703, 126354, 126640, 127776, 128713, 129198, 130135, 131072]
private def addr (a b : Edge) := indices.idxOf (native a b)

private theorem checked : ∀ (a b : Edge),
    0 ≤ (ratValue a + ratValue b)/HighTailSweep.step ∧ addr a b < 59 ∧ indices[addr a b]! = native a b := by
  decide +kernel

def address (a b : Edge) : Fin 59 := ⟨addr a b,(checked a b).2.1⟩

theorem physical (a b : Edge) :
    indices[(address a b).val]! = min ⌊(realValue a+realValue b)/Native.step⌋₊ 131072 := by
  let q := (ratValue a+ratValue b)/HighTailSweep.step
  have pos : 0 ≤ q := (checked a b).1
  have cast : (q:ℝ) = (realValue a+realValue b)/Native.step := by
    simp only [q,Rat.cast_div,Rat.cast_add,edge_cast,step_eq]
  have eq : ⌊(q:ℝ)⌋₊ = ⌊q⌋₊ := by
    apply (Nat.floor_eq_iff (by exact_mod_cast pos)).mpr
    constructor
    · exact_mod_cast Nat.floor_le pos
    · exact_mod_cast Nat.lt_floor_add_one q
  rw [←cast,eq]
  exact (checked a b).2.2

#print axioms edge_cast
#print axioms physical
end PrimeGap180.HighTailAddresses
