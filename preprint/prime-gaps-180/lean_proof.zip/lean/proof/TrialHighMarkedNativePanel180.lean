import TrialHighGroupedPayment180
import TrialHighFrozenPanel180

/-! For any panel of actual frozen spline samples, the finite native
product of harmonic cell bounds is payable by the corresponding grouped
integer dot. -/
noncomputable section
open scoped Classical BigOperators
namespace PrimeGap180.HighMarkedNativePanel
set_option maxRecDepth 8192
set_option maxHeartbeats 4000000
open HighAngularProduct HighAngularGram HighPanelGram HighFrozenPanel
open HighIntegerGram HighTailTiles HighGroupedPayment HighMomentReader
open PrimeGap180.FrozenProfile (Fine amplitude)
open PrimeGap180.GateDeletion (T)
open private weighted from TrialHighAngularGram180
open private energies young from TrialHighRationalPanel180

def ratio (r : Rate) : ℝ := 1-(beta r:ℝ)*Native.step
theorem ratio_pos (r : Rate) : 0 < ratio r := by
  fin_cases r <;> norm_num [ratio,beta,Native.step]
theorem ratio_le_one (r : Rate) : ratio r ≤ 1 := by
  fin_cases r <;> norm_num [ratio,beta,Native.step]

def cell (a b : Fin 9) (q : HighOwnerRoles.Owners) (i : Fin 39) (j : Index) : ℝ :=
  Native.step * markWeight (tags a b q i) (mid j+Native.step/2)

def sampleMass (a b : Fin 9) (x : Cube) := ∑ q : HighOwnerRoles.Owners, ∏ i, cell a b q i (x i)

theorem nonnegative (a b : Fin 9) (x : Cube) : 0 ≤ sampleMass a b x := by
  have step : 0 ≤ Native.step := by norm_num [Native.step]
  exact Finset.sum_nonneg fun q _ => Finset.prod_nonneg fun i _ =>
    mul_nonneg step (HighPositiveMoments.marks (tags a b q i) _)

def indices (x : Cube) (i : Fin 39) := (x i).val
def radial (x : Cube) := ∑ i, indices x i

private theorem moment_sum {α β : Type*} [Fintype α] [Fintype β]
    (m : β→α→ℝ) (v : α→ℝ) (A : Channels→α→ℝ) (p q : Channels) :
    moment (fun x => (∑ t : β,m t x)*v x) A p q =
      ∑ t : β,moment (fun x => m t x*v x) A p q := by
  unfold moment
  simp only [Finset.sum_mul]
  exact Finset.sum_comm

theorem actual_gram (r : Rate) (a b : Fin 9) (p q : Channels) :
    moment (fun x : Cube => sampleMass a b x * (ratio r)^(radial x))
      (fun k x => field k (indices x)) p q = HighGroupedPayment.gram r a b p q := by
  unfold sampleMass
  rw [moment_sum]
  unfold HighGroupedPayment.gram
  apply Finset.sum_congr rfl
  intro owner _
  have tilted : tiltedSite (cell a b owner) (ratio r) = W r a b owner := by
    funext i j
    unfold tiltedSite cell ratio W weightAt HighTailPhysical.ordinary mid
    ring
  have h := HighAngularProduct.original (cell a b owner) (ratio r) (chart.symm p) (chart.symm q)
  rw [tilted] at h
  change moment (fun x : Cube => (∏ i,cell a b owner i (x i)) * (ratio r)^(∑ i,(x i).val))
    (fun k x => field k (fun i => (x i).val)) p q = _
  simpa only [Equiv.apply_symm_apply] using h

inductive Method where
  | trace
  | center (w : Fin 4→ℝ) (q : ℝ) (positive : 0 < q)

def matrixOf : Method → HighRationalPanel.Controls
  | .trace => HighRationalPanel.diagonal
  | .center w q _ => HighRationalPanel.centered w q

private theorem use_panel {α : Type*} [Fintype α]
    (m : α→ℝ) (hm : ∀ x, 0 ≤ m x) (C : Fin 4→Channels→ℝ) (A : Channels→α→ℝ)
    (method : Method) :
    ∃ w, let B := matrix C (moment m A)
      min (trace B) ((Real.sqrt (centerSq B w)+Real.sqrt (HighPanelGram.residual B w))^2) ≤
      HighRationalPanel.pairing (matrixOf method) B := by
  cases method with
  | trace =>
    refine ⟨fun _=>0,?_⟩
    dsimp only [matrixOf]
    rw [HighRationalPanel.pairing_diagonal]
    exact min_le_left _ _
  | center w q pos =>
    refine ⟨w,?_⟩
    have e := energies (weighted m C A) w
    rw [gram_matrix m hm C A] at e
    dsimp only [matrixOf]
    rw [HighRationalPanel.pairing_centered]
    exact (min_le_right _ _).trans (young e.1 e.2 pos)

theorem bound (r : Rate) (a b : Fin 9) (selected : Finset Cube)
    (c : Fine) (s : ℕ) (l h : ℚ) (t : Cube→ℚ) (stop : ℕ)
    (start : 3 ≤ s) (last : s < 33)
    (active : ∀ x ∈ selected, MassSplineSpan.knot s ≤ MassSplineSpan.sample (radial x) ∧
      MassSplineSpan.sample (radial x) < MassSplineSpan.knot (s+1))
    (place : ∀ x ∈ selected, MassSplineSpan.sample (radial x) = l+(h-l)*t x)
    (inside : ∀ x ∈ selected, 0 ≤ t x ∧ t x ≤ 1)
    (range : ∀ x ∈ selected, radial x ≤ stop)
    (method : Method) (paid : ℝ)
    (budget : HighRationalPanel.pairing (matrixOf method)
      (matrix (control s c l h) (HighGroupedPayment.gram r a b)) / (symmetry a b:ℝ) ≤ paid*(ratio r)^stop) :
    (∑ x ∈ selected, sampleMass a b x * (amplitude T (indices x) c)^2) / (symmetry a b:ℝ) ≤ paid := by
  have pos := ratio_pos r
  have positive (x : Cube) : 0 ≤ sampleMass a b x * (ratio r)^radial x :=
    mul_nonneg (nonnegative a b x) (pow_nonneg pos.le _)
  obtain ⟨w,fit⟩ := use_panel _ positive (control s c l h) (fun p x => field p (indices x)) method
  have bound := HighFrozenPanel.bound selected indices c s l h t start last active place inside
    (sampleMass a b) (nonnegative a b) stop range (ratio r) pos (ratio_le_one r) w
  have eq : moment (fun x => sampleMass a b x * (ratio r)^radial x)
      (fun k x => field k (indices x)) = HighGroupedPayment.gram r a b := by
    funext p q
    exact actual_gram r a b p q
  change _ ≤ _ / (ratio r)^stop at bound
  dsimp only at fit
  simp only [radial] at eq fit bound
  rw [eq] at fit bound
  have move := div_le_div_of_nonneg_right fit (pow_nonneg pos.le stop)
  have result := bound.trans move
  have sym : 0 < (symmetry a b:ℝ) := by unfold symmetry; split <;> positivity
  have scaled := div_le_div_of_nonneg_right result sym.le
  rw [div_div,mul_comm ((ratio r)^stop),←div_div] at scaled
  exact scaled.trans ((div_le_iff₀ (pow_pos pos _)).mpr budget)

#print axioms actual_gram
#print axioms bound
end PrimeGap180.HighMarkedNativePanel
