import TrialDensityShape180
import TrialDensityDegreeSums180
import TrialDensityOuterWords180

namespace PrimeGap180.DensitySimplex.Horner

private theorem zip_length {A : Type} (op : A → A → A) (l r : List A) :
    (together op l r).length = max l.length r.length := by
  induction l generalizing r with
  | nil => simp [together]
  | cons v l ih => cases r <;> simp [together,ih,Nat.succ_max_succ]

/-- At offset i, only n-i degrees remain. Each factorial-weighted
coefficient contributes at most n! times its original absolute value. -/
private theorem collect_bounds {A : Type} (child : A → List Int) (w : A → Nat)
    (n i : Nat) (l : List A) (hlen : i+l.length ≤ n+1)
    (hh : ∀ (j : Nat) (hj : j < l.length),
      (child l[j]).length ≤ (n-(i+j))+1 ∧
      size 1 (child l[j]) ≤ (n-(i+j)).factorial*w l[j]) :
    l.length ≤ (collect child i l).length ∧
    (collect child i l).length ≤ n+1-i ∧
    size 1 (collect child i l) ≤ n.factorial*(l.map w).sum := by
  induction l generalizing i with
  | nil => simp [collect,size]
  | cons a l ih =>
    simp only [List.length_cons] at hlen
    have hi : i ≤ n := by omega
    have ha := hh 0 (by simp)
    simp only [List.getElem_cons_zero,Nat.add_zero] at ha
    have ht := ih (i+1) (by omega) (by
      intro j hj
      rw [show i+1+j = i+(j+1) by omega]
      exact hh (j+1) (by simpa only [List.length_cons,Nat.add_lt_add_iff_right] using hj))
    have hfac : i.factorial * (n-i).factorial ≤ n.factorial := by
      simpa only [Nat.add_sub_of_le hi] using
        Nat.le_of_dvd (Nat.factorial_pos (i+(n-i))) (Nat.factorial_mul_factorial_dvd_factorial_add i (n-i))
    let H := (child a).map (fun b => (i.factorial : Int)*b)
    let T := (0:Int)::collect child (i+1) l
    have hhead : size 1 H ≤ n.factorial*w a := by
      have scaled := size_scale 1 (i.factorial:Int) (child a)
      change size 1 H ≤ _ at scaled
      rw [Int.natAbs_natCast] at scaled
      exact scaled.trans ((Nat.mul_le_mul_left _ ha.2).trans
        (by rw [← Nat.mul_assoc]; exact Nat.mul_le_mul_right _ hfac))
    have htail : size 1 T ≤ n.factorial*(l.map w).sum := by
      simpa [T,size] using ht.2.2
    have hsize := size_add 1 H T
    refine ⟨?_,?_,?_⟩
    · simp only [collect,zip_length,List.length_cons,List.length_map]
      omega
    · simp only [collect,zip_length,List.length_cons,List.length_map]
      omega
    · exact hsize.trans ((Nat.add_le_add hhead htail).trans_eq
        (by simp [List.map_cons,List.sum_cons,Nat.mul_add]))

theorem degree_vector_bounds (d n : Nat) (a : Table d) (ha : fits d n a) :
    (degrees d a).length ≤ n+1 ∧ size 1 (degrees d a) ≤ n.factorial*size d a := by
  induction d generalizing n with
  | zero =>
    simp [degrees,size]
    simpa using (Nat.mul_le_mul_right (Int.natAbs a) (Nat.factorial_pos n))
  | succ d ih =>
    have h := collect_bounds (degrees d) (size d) n 0 a (by simpa using ha.1) (by
      intro j hj
      simpa using ih (n-j) a[j] (ha.2 j hj))
    simpa [degrees,size] using h.2

theorem physical_degree_length :
    (degrees 4 (geometricTable 4 (12^5) fiveForms 10)).length = 51 := by
  let a := geometricTable 4 (12^5) fiveForms 10
  have physical : fits 4 50 a := physical_shape
  have h := collect_bounds (degrees 3) (size 3) 50 0 a (by simpa using physical.1) (by
    intro j hj
    simpa using degree_vector_bounds 3 (50-j) a[j] (physical.2 j hj))
  have len : a.length = 51 := len_geometric 3 _ _ _
  change (collect (degrees 3) 0 a).length = 51
  omega

theorem physical_degree_norm :
    size 1 (degrees 4 (geometricTable 4 (12^5) fiveForms 10)) < 2^511 := by
  have hh := (degree_vector_bounds _ _ _ physical_shape).2
  exact hh.trans_lt ((Nat.mul_le_mul_left _ five_size.le).trans_lt (by decide +kernel))

private theorem mem_bound (l : List Int) (a : Int) (ha : a ∈ l) : a.natAbs ≤ size 1 l := by
  induction l with
  | nil => simp at ha
  | cons b l ih =>
    simp only [List.mem_cons] at ha
    change a.natAbs ≤ b.natAbs + (l.map (size 0)).sum
    rcases ha with rfl | h
    · omega
    · exact (ih h).trans (Nat.le_add_left _ _)

theorem physical_degree_digits (a : Int) (ha : a ∈ degrees 4 (geometricTable 4 (12^5) fiveForms 10)) :
    0 ≤ a+2^511 ∧ a+2^511 < 2^512 := by
  have h := (mem_bound _ a ha).trans_lt physical_degree_norm
  have hi : |a| < (2:ℤ)^511 := by
    rw [← Int.natCast_natAbs]
    exact_mod_cast h
  have hm := abs_lt.mp hi
  rw [show (2:ℤ)^512 = 2^511 + 2^511 from (pow_succ 2 511).trans (mul_two _)]
  omega

#print axioms physical_degree_digits
#print axioms physical_degree_length
end PrimeGap180.DensitySimplex.Horner
