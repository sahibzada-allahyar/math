import TrialDensityTriangleInputs180
namespace PrimeGap180.DensitySimplex.Horner.TriangleChecks
private theorem lower_den11 (z : Fin 2 → ℝ) :
    ((L 11).map (factorValue z)).prod/((unit^3:Int):ℝ) = threeDen (lowerMap (r 11) (s 11) z) := by
  have hr : r 11 = 128833999/10000000000 := by decide +kernel
  have hs : s 11 = 592030501/5000000000 := by decide +kernel
  have forms : L 11 = factors 1441729000 257667998 0 2368122004 := rfl
  rw [hr,hs,forms]
  norm_num [factors,unit,factorValue,Fin.sum_univ_two,threeDen,lowerMap] <;> ring
private theorem upper_den11 (z : Fin 2 → ℝ) :
    ((U 11).map (factorValue z)).prod/((unit^3:Int):ℝ) = threeDen (upperMap (r 11) (s 11) z) := by
  have hr : r 11 = 128833999/10000000000 := by decide +kernel
  have hs : s 11 = 592030501/5000000000 := by decide +kernel
  have forms : U 11 = factors 257667998 0 2368122004 2496956003 := rfl
  rw [hr,hs,forms]
  norm_num [factors,unit,factorValue,Fin.sum_univ_two,threeDen,upperMap] <;> ring

set_option maxRecDepth 65536 in
set_option maxHeartbeats 0 in
theorem row11 : triangleQ (r 11) (s 11) = FrozenNumbers.triangles 11 := by
  rw [triangle_from_forms _ _ (L 11) (U 11) (unit^3) (unit^3) (by decide) (by decide)
    lower_den11 upper_den11]
  decide +kernel

#print axioms row11
end PrimeGap180.DensitySimplex.Horner.TriangleChecks
