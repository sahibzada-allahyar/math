Lean source package: 12/5

12/5 finite certificate: SatLowerBound.main_lower_bound_125; full parameter range: main_lower_bound_125_full_range.

Pinned Lean: v4.35.0. Mathlib revision is pinned in lakefile.toml and lake-manifest.json.
Extract this archive and run from this directory:

lake exe cache get
lake build SatLowerBound Credit
lake env lean Credit/Audit125.lean

Source snapshot from P_vs_NP on 2026-11-02. The 12/5 package includes its 7/3 source dependencies.
The TwoLevel/17/7 work is deliberately excluded. These archives do not constitute a Lean verification of the 17/7 paper.
Historical verification records remain in the source repository. This distribution contains the proof sources and build instructions, without development diaries or historical logs. Packaging checks cover archive integrity and local imports. A fresh build of this distribution has not been run; use the commands above to verify it with the pinned toolchain.
