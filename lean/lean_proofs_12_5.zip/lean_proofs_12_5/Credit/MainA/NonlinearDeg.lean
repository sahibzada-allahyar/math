import Credit.MainA.Toolkit

/-!
# Credit.MainA.NonlinearDeg — Main Lemma A, case II, first part

Manuscript, proof of Lemma 4.6, case II.  `C = gate t i j rest`, `t` nonlinear, first gate
`T` = index `n`.  The `v`-step fixes `v ∈ {i, j}` to its blocking value for `T` (left side:
`Table.nonlinear_exists_blocksLeft`, right side: `..._blocksRight`); then `T` resolves to a
constant (`resAt_gate`, `resAt_single_input`, `Res.step_blocked_left/right`).
* `degrees_of_nonlinear`: if `refCount j = 1` then `users j = {n}` (`refCount_input`,
  `Finset.card_eq_one`); the `i`-step makes `T` constant, so every reader of `j` is constant,
  contradicting `MAContext.connected` (E1).  Symmetrically for `i`.
* `case_nonlinear_three` (`refCount v ≥ 3`): `v`-step.  `E = {T, Q₁, Q₂, R₁}` with `Q₁, Q₂`
  two further readers of `v` (they read the constant `v`: `isAliased_of_const`; uncharged by F1
  `not_dGate_of_multi`), `R₁ ∈ users T` (`const_users` F5; uncharged by F2
  `not_dGate_of_primary_pred`; `R₁ ∉ users v` by F4 `no_triangle`).  All `psiW ≥ 3`
  (`psiW_ge`): drop `≥ 12`.  Conclude with `MAContext.drops`.
-/

namespace SatLowerBound
namespace MAContext

open OpenCircuit

/-- An input `z` read by the first gate `T = n` has at least two readers as soon as fixing some
other input `x` to some value makes `T` constant: otherwise `T` would be the only reader of `z`
and every reader of `z` would become constant, contradicting `connected` (E1). -/
private theorem two_le_refCount_of_const {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x z : Fin n) (b : Bool) (hzx : z ≠ x)
    (hTz : n ∈ C.users z.val) (hc : (C.resAt (singleRes x b) n).isConst = true) :
    2 ≤ C.refCount z.val := by
  by_contra hlt
  have hle : (C.users z.val).card ≤ 1 := by
    rw [← h.refCount_input z]
    omega
  have hpos : 0 < C.refCount z.val := by
    rw [h.refCount_input z]
    exact Finset.card_pos.mpr ⟨n, hTz⟩
  obtain ⟨k, hk, hnc⟩ := h.connected x b z hzx hpos
  have hkn : k = n := Finset.card_le_one.mp hle k hk n hTz
  rw [hkn, hc] at hnc
  exact Bool.false_ne_true hnc.symm

theorem degrees_of_nonlinear {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) {t : Table} {i j : Fin n} {rest : OpenCircuit (n + 1)}
    (hC : C = .gate t i j rest) (hnl : t.nonlinear = true) :
    2 ≤ C.refCount i.val ∧ 2 ≤ C.refCount j.val := by
  have hT : C.gateAt n = some (t, i.val, j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hij : i ≠ j := fun he => (h.gate_facts hT).2.1 (congrArg Fin.val he)
  have hTi : n ∈ C.users i.val := C.mem_users.mpr ⟨t, i.val, j.val, hT, Or.inl rfl⟩
  have hTj : n ∈ C.users j.val := C.mem_users.mpr ⟨t, i.val, j.val, hT, Or.inr rfl⟩
  have hires : ∀ b : Bool, C.resAt (singleRes i b) i.val = .const b := by
    intro b
    rw [C.resAt_single_input i b i]
    simp
  have hjres : ∀ b : Bool, C.resAt (singleRes j b) j.val = .const b := by
    intro b
    rw [C.resAt_single_input j b j]
    simp
  constructor
  · -- the `j`-step makes `T` constant, so `i` needs a second reader
    obtain ⟨b, hb, -⟩ := t.nonlinear_exists_blocksRight hnl
    apply two_le_refCount_of_const h j i b hij hTi
    rw [C.resAt_gate _ hT, hjres b, Res.step_blocked_right t _ b hb]
    rfl
  · -- the `i`-step makes `T` constant, so `j` needs a second reader
    obtain ⟨b, hb, -⟩ := t.nonlinear_exists_blocksLeft hnl
    apply two_le_refCount_of_const h i j b (fun he => hij he.symm) hTj
    rw [C.resAt_gate _ hT, hires b, Res.step_blocked_left t b _ hb]
    rfl

/-- Case II with an operand of `T` read at least three times. -/
theorem case_nonlinear_three {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) {t : Table} {i j : Fin n} {rest : OpenCircuit (n + 1)}
    (hC : C = .gate t i j rest) (hnl : t.nonlinear = true) (v : Fin n) (hv : v = i ∨ v = j)
    (h3 : 3 ≤ C.refCount v.val) : ∃ b, C.DropsAt v b 10 := by
  -- the first gate `T = n` reads `v`
  have hT : C.gateAt n = some (t, i.val, j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hTv : n ∈ C.users v.val := by
    rw [C.mem_users]
    refine ⟨t, i.val, j.val, hT, ?_⟩
    rcases hv with hv | hv
    · rw [hv]
      exact Or.inl rfl
    · rw [hv]
      exact Or.inr rfl
  have h2 : 2 ≤ C.refCount v.val := by omega
  -- `v` itself resolves to the constant `b`, so every reader of `v` is eliminated
  have hvres : ∀ b : Bool, C.resAt (singleRes v b) v.val = .const b := by
    intro b
    rw [C.resAt_single_input v b v]
    simp
  have halias : ∀ b : Bool, ∀ k ∈ C.users v.val, C.isAliased (singleRes v b) k = true := by
    intro b k hk
    obtain ⟨g, a, a', hg, hav⟩ := C.mem_users.mp hk
    apply C.isAliased_of_const _ hg
    rcases hav with hav | hav
    · left
      rw [hav, hvres b]
      rfl
    · right
      rw [hav, hvres b]
      rfl
  -- the `v`-step: fix `v` to its blocking value for `T`, which becomes constant
  obtain ⟨b, hbc⟩ : ∃ b, (C.resAt (singleRes v b) n).isConst = true := by
    rcases hv with hv | hv
    · obtain ⟨b, hb, -⟩ := t.nonlinear_exists_blocksLeft hnl
      refine ⟨b, ?_⟩
      rw [C.resAt_gate _ hT, ← hv, hvres b, Res.step_blocked_left t b _ hb]
      rfl
    · obtain ⟨b, hb, -⟩ := t.nonlinear_exists_blocksRight hnl
      refine ⟨b, ?_⟩
      rw [C.resAt_gate _ hT, ← hv, hvres b, Res.step_blocked_right t _ b hb]
      rfl
  -- two further readers `Q₁ ≠ Q₂` of `v`, both different from `T`
  have hcard : 3 ≤ (C.users v.val).card := by
    rw [← h.refCount_input v]
    exact h3
  have hcard' : 1 < ((C.users v.val).erase n).card := by
    rw [Finset.card_erase_of_mem hTv]
    omega
  obtain ⟨Q₁, hQ₁, Q₂, hQ₂, hQ⟩ := Finset.one_lt_card.mp hcard'
  have hQ₁n : Q₁ ≠ n := Finset.ne_of_mem_erase hQ₁
  have hQ₂n : Q₂ ≠ n := Finset.ne_of_mem_erase hQ₂
  have hQ₁v : Q₁ ∈ C.users v.val := Finset.mem_of_mem_erase hQ₁
  have hQ₂v : Q₂ ∈ C.users v.val := Finset.mem_of_mem_erase hQ₂
  -- a reader `R₁` of the constant `T`, eliminated (F5) and not a reader of `v` (F4)
  have hTb := C.gateAt_bounds hT
  obtain ⟨⟨R₁, hR₁⟩, hR₁al⟩ := h.const_users v b (Nat.le_refl n) hTb.2.1 hbc
  have hR₁v : R₁ ∉ C.users v.val := h.no_triangle v.isLt hTv hR₁
  have hR₁n : R₁ ≠ n := fun he => hR₁v (he ▸ hTv)
  have hR₁Q₁ : R₁ ≠ Q₁ := fun he => hR₁v (he ▸ hQ₁v)
  have hR₁Q₂ : R₁ ≠ Q₂ := fun he => hR₁v (he ▸ hQ₂v)
  -- `E = {T, Q₁, Q₂, R₁}`, four distinct uncharged eliminated gates of weight `≥ 3`
  have hnE : n ∉ ({Q₁, Q₂, R₁} : Finset Nat) := by
    simp only [Finset.mem_insert, Finset.mem_singleton]
    omega
  have hQ₁E : Q₁ ∉ ({Q₂, R₁} : Finset Nat) := by
    simp only [Finset.mem_insert, Finset.mem_singleton]
    omega
  have hQ₂E : Q₂ ∉ ({R₁} : Finset Nat) := by
    simp only [Finset.mem_singleton]
    omega
  refine ⟨b, h.drops v b {n, Q₁, Q₂, R₁} ?_ 0 (Nat.zero_le _) 10 ?_⟩
  · intro k hk
    simp only [Finset.mem_insert, Finset.mem_singleton] at hk
    rcases hk with hk | hk | hk | hk
    · rw [hk]
      exact halias b n hTv
    · rw [hk]
      exact halias b Q₁ hQ₁v
    · rw [hk]
      exact halias b Q₂ hQ₂v
    · rw [hk]
      exact hR₁al R₁ hR₁
  · have hsum : ∑ k ∈ ({n, Q₁, Q₂, R₁} : Finset Nat), C.gatePsiW k =
        C.gatePsiW n + (C.gatePsiW Q₁ + (C.gatePsiW Q₂ + C.gatePsiW R₁)) := by
      rw [Finset.sum_insert hnE, Finset.sum_insert hQ₁E, Finset.sum_insert hQ₂E,
        Finset.sum_singleton]
    have hfil : (({n, Q₁, Q₂, R₁} : Finset Nat).filter
        (fun k => C.isDGate k = true)).card = 0 := by
      rw [Finset.card_eq_zero]
      apply Finset.filter_false_of_mem
      intro k hk
      simp only [Finset.mem_insert, Finset.mem_singleton] at hk
      rcases hk with hk | hk | hk | hk
      · rw [hk, h.not_dGate_of_multi v h2 hTv]
        exact Bool.false_ne_true
      · rw [hk, h.not_dGate_of_multi v h2 hQ₁v]
        exact Bool.false_ne_true
      · rw [hk, h.not_dGate_of_multi v h2 hQ₂v]
        exact Bool.false_ne_true
      · rw [hk, h.not_dGate_of_primary_pred hT i.isLt j.isLt hR₁]
        exact Bool.false_ne_true
    obtain ⟨g₁, a₁, a₁', hg₁, -⟩ := C.mem_users.mp hQ₁v
    obtain ⟨g₂, a₂, a₂', hg₂, -⟩ := C.mem_users.mp hQ₂v
    obtain ⟨g₃, a₃, a₃', hg₃, -⟩ := C.mem_users.mp hR₁
    have w₀ := (h.psiW_ge hT).1
    have w₁ := (h.psiW_ge hg₁).1
    have w₂ := (h.psiW_ge hg₂).1
    have w₃ := (h.psiW_ge hg₃).1
    rw [hsum, hfil]
    omega

end MAContext
end SatLowerBound
