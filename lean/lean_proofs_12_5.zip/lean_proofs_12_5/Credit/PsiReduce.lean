import Credit.Charging

/-!
# Credit.PsiReduce — reduction steps do not increase `Ψ`

The `Ψ` analogue of `OpenCircuit.smaller_of_not_reduced` (MinimalNormal.lean).  A circuit that
is not `Reduced` has a gate with a non-essential table, a gate with equal operands, or a gate
without readers.  The proof distinguishes two cases.

* Some gate is *degenerate* (non-essential table or equal operands; `¬ Proper`).  Then the
  identity restriction `C.restrict (fixSubst (fun _ => false) _)` eliminates it (a degenerate
  gate is bypassed under every resolution, `one_le_aliasedCount`), so the size drops
  (`size_split`, `fix_transfer`), and `Ψ` does not increase by the charging lemma
  `psi_restrict_le` (package C).
* Every gate is essential with distinct operands (`Proper`) and some gate is dead.  The dead
  gate is deleted as in `smaller_of_not_reduced` (`restrict (dropLast _)` on its tail, a pure
  deletion: every tail gate is kept, `all_kept`, via `restrict_transfer`).  Because the
  D-status of an input depends on the references before the deleted gate, the induction is run
  for a *contextual potential* `ctxPsi R S pre`: `psiWeight R` minus the number of `z ∈ S` that
  are D-variables when a prefix with profile `pre z = (number of prefix references of z, first
  prefix reader nonlinear?)` is put in front of `R` (`ctxD`).  Pushing a gate into the prefix is
  `prePush` (`ctxPsi_gate`), and `Ψ(C) = ctxPsi C (range n) (fun _ => (0, false))`
  (`psi_eq_ctxPsi`).  The deleted gate loses `psiW ≥ 3` and changes the D-status of at most its
  two operands.

All helpers are private and live in `OpenCircuit.PsiReduceAux` (no name clashes with other
packages).  Do not change the statement without updating `STATUS.txt`.
-/

namespace SatLowerBound
namespace OpenCircuit
namespace PsiReduceAux

/-! ### Degenerate gates -/

/-- Every gate has an essential table and two distinct operands. -/
private def Proper : {n : Nat} → OpenCircuit n → Prop
  | _, .output _ => True
  | _, .gate g i j rest => g.essential = true ∧ i ≠ j ∧ Proper rest

private theorem not_essential_degenerate (g : Table) (h : g.essential = false) :
    (g.ff = g.tf ∧ g.ft = g.tt) ∨ (g.ff = g.ft ∧ g.tf = g.tt) := by
  revert h
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

private theorem step_isSome_of_not_essential (g : Table) (hg : g.essential = false)
    (r₁ r₂ : Res) : (Res.step g r₁ r₂).isSome = true := by
  cases r₁ with
  | const a => exact Res.step_const_left_isSome g a r₂
  | lit s na =>
    cases r₂ with
    | const b => exact Res.step_const_right_isSome g _ b
    | lit t nb =>
      have hd := not_essential_degenerate (twist g na nb) (by rw [twist_essential]; exact hg)
      simp only [Res.step]
      split_ifs with _ h₂ h₃
      · rfl
      · rfl
      · rfl
      · exact (hd.elim h₂ h₃).elim

/-- A degenerate gate is bypassed under every resolution of its operands. -/
private theorem step_isSome_of_degenerate {n : Nat} (g : Table) (i j : Fin n) (ρ : Fin n → Res)
    (hh : ¬ (g.essential = true ∧ i ≠ j)) : (Res.step g (ρ i) (ρ j)).isSome = true := by
  by_cases hg : g.essential = true
  · have hij : i = j := by
      by_cases hne : i = j
      · exact hne
      · exact absurd ⟨hg, hne⟩ hh
    rw [hij]
    cases ρ j with
    | const a => exact Res.step_const_left_isSome g a _
    | lit s neg => exact Res.step_same_isSome g s neg neg
  · exact step_isSome_of_not_essential g (by simpa using hg) _ _

private theorem one_le_aliasedCount {n : Nat} (C : OpenCircuit n) (hp : ¬ Proper C)
    (ρ : Fin n → Res) : 1 ≤ C.aliasedCount ρ := by
  induction C with
  | output o => exact (hp True.intro).elim
  | @gate n g i j rest ih =>
    by_cases hh : g.essential = true ∧ i ≠ j
    · have hr : ¬ Proper rest := fun hr => hp ⟨hh.1, hh.2, hr⟩
      simp only [aliasedCount]
      cases Res.step g (ρ i) (ρ j) with
      | some r =>
        have := ih hr (appendValue ρ r)
        simp only
        omega
      | none => exact ih hr _
    · obtain ⟨r, hr⟩ := Option.isSome_iff_exists.mp (step_isSome_of_degenerate g i j ρ hh)
      simp only [aliasedCount, hr]
      omega

/-! ### Deleting a dead gate: the tail is copied unchanged -/

private theorem lastUses_eq_refCount {n : Nat} (R : OpenCircuit (n + 1)) :
    R.lastUses = R.refCount n := by
  have h : (appendValue (fun _ => 0) 1 : Fin (n + 1) → Nat) = singleUse (Fin.last n) := by
    funext k
    unfold appendValue singleUse
    by_cases hk : k.val < n
    · have hne : k ≠ Fin.last n := by
        intro he
        rw [he, Fin.val_last] at hk
        omega
      simp [hk, hne]
    · have heq : k = Fin.last n := by
        apply Fin.ext
        rw [Fin.val_last]
        have := k.isLt
        omega
      simp [heq]
  unfold lastUses
  rw [h, usage_singleUse, Fin.val_last]

/-- The abstract resolution matching `dropLast n`. -/
private def dropRes (n : Nat) : Fin (n + 1) → Res :=
  fun k => if k.val < n then .lit k.val false else .const false

private theorem dropLast_rel (n : Nat) (k : Fin (n + 1)) :
    ResRel (Fin.val : Fin n → Nat) (dropLast n k) (dropRes n k) := by
  by_cases hk : k.val < n
  · simp [dropLast, extendSubst, identitySubst, dropRes, hk, ResRel]
  · simp [dropLast, extendSubst, dropRes, hk, ResRel]

private theorem dropRes_lit (n : Nat) (k : Fin (n + 1)) (hk : k.val ≠ n) :
    dropRes n k = .lit k.val false := by
  have hlt : k.val < n := by
    have := k.isLt
    omega
  simp [dropRes, hlt]

/-- If every signal other than the unreferenced `d` resolves to itself, every gate of a
`Proper` circuit is kept and all kept-level quantities are the original ones. -/
private theorem all_kept {p : Nat} (R : OpenCircuit p) (ρ : Fin p → Res) (d : Nat)
    (hρ : ∀ k : Fin p, k.val ≠ d → ρ k = .lit k.val false) (hd : R.refCount d = 0)
    (hp : Proper R) :
    R.keptPsiWeight ρ = R.psiWeight ∧
      ∀ s, s ≠ d → R.keptRefs ρ s = R.refCount s ∧ R.keptFirstNL ρ s = R.firstUserNL s := by
  induction R with
  | output o =>
    refine ⟨rfl, ?_⟩
    intro s _
    cases o with
    | constant b => exact ⟨rfl, rfl⟩
    | wire i neg =>
      have hi : i.val ≠ d := by
        intro he
        simp [refCount, he] at hd
      refine ⟨?_, rfl⟩
      simp only [keptRefs, refCount, hρ i hi, Res.hits, indicator]
      by_cases he : i.val = s <;> simp [he]
  | @gate p g i j rest ih =>
    simp only [refCount] at hd
    have hi : i.val ≠ d := by
      intro he
      simp [he] at hd
    have hj : j.val ≠ d := by
      intro he
      simp [he] at hd
    have hrd : rest.refCount d = 0 := by omega
    obtain ⟨hg, hij, hp'⟩ := hp
    have hstep : Res.step g (.lit i.val false) (.lit j.val false) = none :=
      Res.step_kept g hg i.val j.val (fun h => hij (Fin.ext h)) false false
    have hρ' : ∀ k : Fin (p + 1), k.val ≠ d →
        appendValue ρ (.lit p false) k = .lit k.val false := by
      intro k hk
      unfold appendValue
      by_cases hkp : k.val < p
      · simp only [hkp, ↓reduceDIte]
        exact hρ ⟨k.val, hkp⟩ hk
      · have hkv : k.val = p := by
          have := k.isLt
          omega
        simp only [hkp, ↓reduceDIte]
        rw [hkv]
    obtain ⟨ihw, ihr⟩ := ih (appendValue ρ (.lit p false)) hρ' hrd hp'
    refine ⟨?_, ?_⟩
    · simp only [keptPsiWeight, psiWeight, hρ i hi, hρ j hj, hstep, ihw]
    · intro s hs
      obtain ⟨h₁, h₂⟩ := ihr s hs
      refine ⟨?_, ?_⟩
      · simp only [keptRefs, refCount, hρ i hi, hρ j hj, hstep, h₁, Res.hits, indicator]
        by_cases hsi : i.val = s <;> by_cases hsj : j.val = s <;> simp [hsi, hsj]
      · simp only [keptFirstNL, firstUserNL, hρ i hi, hρ j hj, hstep, h₂, Res.hits]
        by_cases hsi : i.val = s <;> by_cases hsj : j.val = s <;> simp [hsi, hsj]

/-! ### The contextual potential -/

/-- D-status of the input `z` of `R` when a prefix with `c` references to `z`, whose first
reader of `z` is nonlinear iff `b`, is put in front of `R`. -/
private def ctxD {n : Nat} (R : OpenCircuit n) (c : Nat) (b : Bool) (z : Nat) : Bool :=
  decide (c + R.refCount z = 1) && (if c = 0 then R.firstUserNL z else b)

/-- Contextual potential: `psiWeight` minus the contextual D-variables in `S`. -/
private def ctxPsi {n : Nat} (R : OpenCircuit n) (S : Finset Nat) (pre : Nat → Nat × Bool) :
    Int :=
  (R.psiWeight : Int) - ((S.filter (fun z => ctxD R (pre z).1 (pre z).2 z = true)).card : Int)

/-- The prefix profile after appending the gate `g(i, j)` to the prefix. -/
private def prePush {n : Nat} (g : Table) (i j : Fin n) (pre : Nat → Nat × Bool) :
    Nat → Nat × Bool :=
  fun z => ((pre z).1 + (if i.val = z then 1 else 0) + (if j.val = z then 1 else 0),
    if (pre z).1 = 0 then g.nonlinear else (pre z).2)

private theorem ctxD_gate {n : Nat} (g : Table) (i j : Fin n) (R : OpenCircuit (n + 1))
    (c : Nat) (b : Bool) (z : Nat) :
    ctxD (gate g i j R) c b z =
      ctxD R (c + (if i.val = z then 1 else 0) + (if j.val = z then 1 else 0))
        (if c = 0 then g.nonlinear else b) z := by
  unfold ctxD
  simp only [refCount, firstUserNL]
  have harith : c + ((if i.val = z then 1 else 0) + (if j.val = z then 1 else 0) + R.refCount z)
      = c + (if i.val = z then 1 else 0) + (if j.val = z then 1 else 0) + R.refCount z := by
    omega
  simp only [harith]
  by_cases hc : c = 0 <;> by_cases hi : i.val = z <;> by_cases hj : j.val = z <;>
    simp [hc, hi, hj]

private theorem ctxD_gate_of_ne {n : Nat} (g : Table) (i j : Fin n) (R : OpenCircuit (n + 1))
    (c : Nat) (b : Bool) (z : Nat) (hi : i.val ≠ z) (hj : j.val ≠ z) :
    ctxD (gate g i j R) c b z = ctxD R c b z := by
  simp [ctxD, refCount, firstUserNL, hi, hj]

private theorem ctxPsi_gate {n : Nat} (g : Table) (i j : Fin n) (R : OpenCircuit (n + 1))
    (S : Finset Nat) (pre : Nat → Nat × Bool) :
    ctxPsi (gate g i j R) S pre = (g.psiW : Int) + ctxPsi R S (prePush g i j pre) := by
  have hf : S.filter (fun z => ctxD (gate g i j R) (pre z).1 (pre z).2 z = true) =
      S.filter (fun z => ctxD R (prePush g i j pre z).1 (prePush g i j pre z).2 z = true) :=
    Finset.filter_congr (fun z _ => by rw [ctxD_gate]; rfl)
  unfold ctxPsi
  rw [hf]
  simp only [psiWeight]
  push_cast
  ring

private theorem psi_eq_ctxPsi {n : Nat} (C : OpenCircuit n) :
    C.psi = ctxPsi C (Finset.range n) (fun _ => (0, false)) := by
  have hd : C.dCount = ((Finset.range n).filter (fun z => ctxD C 0 false z = true)).card := by
    unfold dCount
    rw [Finset.card_filter, Fin.sum_univ_eq_sum_range (fun z => indicator (C.isD z)) n]
    apply Finset.sum_congr rfl
    intro z _
    simp [ctxD, isD, indicator]
  unfold psi ctxPsi
  rw [hd]

/-- The contextual form of `psi_smaller_of_not_reduced` for `Proper` circuits. -/
private theorem ctx_reduce {n : Nat} (C : OpenCircuit n) (hp : Proper C) (h : ¬ C.Reduced) :
    ∃ D : OpenCircuit n, D.size < C.size ∧ (∀ x, D.eval x = C.eval x) ∧
      ∀ (S : Finset Nat) (pre : Nat → Nat × Bool), (∀ z ∈ S, z < n) →
        ctxPsi D S pre ≤ ctxPsi C S pre := by
  induction C with
  | output s => exact (h True.intro).elim
  | @gate n g i j rest ih =>
    obtain ⟨hg, hij, hrest⟩ := hp
    by_cases hu : 0 < rest.lastUses
    · have hr : ¬ rest.Reduced := fun hh => h ⟨hg, hij, hu, hh⟩
      obtain ⟨R, hs, he, hpsi⟩ := ih hrest hr
      refine ⟨.gate g i j R, ?_, fun x => he _, ?_⟩
      · simp only [size]
        omega
      · intro S pre hS
        rw [ctxPsi_gate, ctxPsi_gate]
        have := hpsi S (prePush g i j pre) (fun z hz => Nat.lt_succ_of_lt (hS z hz))
        omega
    · have hu0 : rest.lastUses = 0 := by omega
      have hd0 : rest.refCount n = 0 := by
        rw [← lastUses_eq_refCount]
        exact hu0
      obtain ⟨_, hw, hr, hf⟩ := rest.restrict_transfer (dropLast n) (dropRes n) Fin.val
        Fin.val_injective (fun w => Nat.lt_succ_of_lt w.isLt) (dropLast_rel n)
      obtain ⟨hallw, hallr⟩ := all_kept rest (dropRes n) n (dropRes_lit n) hd0 hrest
      refine ⟨rest.restrict (dropLast n), Nat.lt_succ_of_le (restrict_size_le rest _), ?_, ?_⟩
      · intro x
        rw [dropLast_eval, eval_unused_last rest hu0 x false (g.eval (x i) (x j))]
        rfl
      · intro S pre hS
        have hDz : ∀ z ∈ S, ctxD (rest.restrict (dropLast n)) (pre z).1 (pre z).2 z =
            ctxD rest (pre z).1 (pre z).2 z := by
          intro z hz
          have hzn := hS z hz
          obtain ⟨h₁, h₂⟩ := hallr z (by omega)
          have hr' : (rest.restrict (dropLast n)).refCount z = rest.keptRefs (dropRes n) z :=
            hr ⟨z, hzn⟩
          have hf' : (rest.restrict (dropLast n)).firstUserNL z =
              rest.keptFirstNL (dropRes n) z := hf ⟨z, hzn⟩
          unfold ctxD
          rw [hr', hf', h₁, h₂]
        have hfilt : S.filter (fun z => ctxD (rest.restrict (dropLast n)) (pre z).1 (pre z).2 z
              = true) = S.filter (fun z => ctxD rest (pre z).1 (pre z).2 z = true) :=
          Finset.filter_congr (fun z hz => by rw [hDz z hz])
        have hsub : S.filter (fun z => ctxD (gate g i j rest) (pre z).1 (pre z).2 z = true) ⊆
            S.filter (fun z => ctxD rest (pre z).1 (pre z).2 z = true) ∪ {i.val, j.val} := by
          intro z hz
          rw [Finset.mem_filter] at hz
          rw [Finset.mem_union]
          by_cases hzi : i.val = z
          · right
            rw [← hzi]
            exact Finset.mem_insert_self _ _
          · by_cases hzj : j.val = z
            · right
              rw [← hzj]
              exact Finset.mem_insert_of_mem (Finset.mem_singleton_self _)
            · left
              rw [Finset.mem_filter]
              refine ⟨hz.1, ?_⟩
              rw [← ctxD_gate_of_ne g i j rest _ _ z hzi hzj]
              exact hz.2
        have hcard := Finset.card_le_card hsub
        have hunion := Finset.card_union_le
          (S.filter (fun z => ctxD rest (pre z).1 (pre z).2 z = true)) {i.val, j.val}
        have hpair : ({i.val, j.val} : Finset Nat).card ≤ 2 := Finset.card_le_two
        have hpsiW : 3 ≤ g.psiW := by
          have := Table.psiW_essential g hg
          omega
        unfold ctxPsi
        rw [hfilt, hw, hallw]
        simp only [psiWeight]
        push_cast
        omega

end PsiReduceAux

theorem psi_smaller_of_not_reduced {n : Nat} (C : OpenCircuit n) (h : ¬ C.Reduced) :
    ∃ D : OpenCircuit n, D.size < C.size ∧ D.psi ≤ C.psi ∧ ∀ x, D.eval x = C.eval x := by
  by_cases hp : PsiReduceAux.Proper C
  · obtain ⟨D, hs, he, hpsi⟩ := PsiReduceAux.ctx_reduce C hp h
    refine ⟨D, hs, ?_, he⟩
    rw [PsiReduceAux.psi_eq_ctxPsi D, PsiReduceAux.psi_eq_ctxPsi C]
    exact hpsi (Finset.range n) (fun _ => (0, false)) (fun z hz => Finset.mem_range.mp hz)
  · refine ⟨C.restrict (fixSubst (fun _ => false) (fun _ => false)), ?_,
      psi_restrict_le C _ _, ?_⟩
    · have hs := (C.fix_transfer (fun _ => false) (fun _ => false)).1
      have hsplit := C.size_split (fixRes (fun _ => false) (fun _ => false))
      have h1 := PsiReduceAux.one_le_aliasedCount C hp (fixRes (fun _ => false) (fun _ => false))
      omega
    · intro x
      rw [restrict_eval]
      congr 1
      funext z
      simp [fixSubst, Signal.eval]

end OpenCircuit
end SatLowerBound
