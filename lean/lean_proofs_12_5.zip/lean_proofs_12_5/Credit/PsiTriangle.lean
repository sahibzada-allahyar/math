import Credit.Charging

/-!
# Credit.PsiTriangle — input-triangle rewriting does not increase `Ψ`

The `Ψ` analogue of `OpenCircuit.triangle_improvement` (TriangleNormalization.lean) with the
empty history.  The rewrite replaces one gate `Q = q(x, P)` with `P = p(x, u)`, `x` primary,
by `Q = (triangle p q)(x, u)` (`History.rewrite_triangle`), leaving every other gate unchanged.
* `psiWeight` does not increase: `Table.triangle_weight` and `Table.psiW_mono`.
* No D-variable is lost: only the references of `P` (a gate) and `u` change; `x` is read by
  `P` and `Q` so it is not a D-variable before or after; if `u` is primary, it is not a
  D-variable of `C`, because its only reader would be `P`, whose operands `x, u` are both
  primary (`DGateSafe`).  First users of all other inputs are unchanged.
* Size is unchanged and `predecessorSum` strictly decreases (as in `triangle_improvement`).

Do not change the statement without updating `STATUS.txt`.

## Proof structure (all helpers in `PsiTriangleAux`)

* `exists_flat_triangle`: `¬ NoInputTriangles (fun _ => none) C` yields, in global indices, a
  gate `q = g(i, j)` such that one operand is a primary input `x` and the other one is a gate
  `P` reading `x` (proved for an arbitrary history `Γ` by the induction of
  `triangle_improvement`, with `HPrim`/`HReads` describing "primary" and "reads" relative to `Γ`).
* `replaceAt C q f a b`: the circuit `C` with the gate of global index `q` replaced by
  `f(a, b)`.  Its size, `predecessorSum`, `psiWeight`, `refCount`, `firstUserNL` and `eval` are
  computed by structural induction (`replaceAt_*`), without any sorried lemma.
* `core`: the rewrite `Q := f(x, u)` with `f(x, u) = g(i, j)` on all inputs and
  `f.weight ≤ g.weight` gives the required circuit; the D-variable bookkeeping is done input by
  input (`u` is excluded by `DGateSafe` at `P`, `x` keeps its references and its first reader
  `P < Q`, every other input is untouched).
* `psi_triangle_step`: the four orientations of the triangle (`Table.swap` for the operand
  orders of `P` and `Q`).
-/

namespace SatLowerBound
namespace OpenCircuit

namespace PsiTriangleAux

/-! ### Replacing one gate -/

/-- Replace the gate with global index `q` by `f(a, b)` (operands given by global index). -/
def replaceAt : {n : Nat} → OpenCircuit n → Nat → Table → Nat → Nat → OpenCircuit n
  | _, .output s, _, _, _, _ => .output s
  | n, .gate g i j rest, q, f, a, b =>
      if hab : q = n ∧ a < n ∧ b < n then .gate f ⟨a, hab.2.1⟩ ⟨b, hab.2.2⟩ rest
      else .gate g i j (replaceAt rest q f a b)

theorem replaceAt_head {n : Nat} (g f : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    {a b : Nat} (ha : a < n) (hb : b < n) :
    replaceAt (gate g i j rest) n f a b = gate f ⟨a, ha⟩ ⟨b, hb⟩ rest :=
  dite_eq_left ⟨rfl, ha, hb⟩

theorem replaceAt_tail {n : Nat} (g f : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    {q a b : Nat} (hq : q ≠ n) :
    replaceAt (gate g i j rest) q f a b = gate g i j (replaceAt rest q f a b) :=
  dite_eq_right (fun hab => hq hab.1)

theorem replaceAt_size {n : Nat} (C : OpenCircuit n) (q : Nat) (f : Table) (a b : Nat) :
    (replaceAt C q f a b).size = C.size := by
  induction C with
  | output s => rfl
  | @gate n g i j rest ih =>
    by_cases hqn : q = n ∧ a < n ∧ b < n
    · rw [hqn.1, replaceAt_head g f i j rest hqn.2.1 hqn.2.2]
      rfl
    · have hrep : replaceAt (gate g i j rest) q f a b = gate g i j (replaceAt rest q f a b) :=
        dite_eq_right hqn
      rw [hrep]
      exact congrArg (· + 1) ih

theorem replaceAt_predecessorSum {n : Nat} (C : OpenCircuit n) {q : Nat} {g f : Table}
    {i j a b : Nat} (hq : C.gateAt q = some (g, i, j)) (ha : a < q) (hb : b < q) :
    (replaceAt C q f a b).predecessorSum + (i + j) = C.predecessorSum + (a + b) := by
  induction C with
  | output s => simp [gateAt] at hq
  | @gate n g' i' j' rest ih =>
    by_cases hqn : q = n
    · rw [hqn] at hq ha hb
      rw [hqn, replaceAt_head g' f i' j' rest ha hb]
      simp only [gateAt_head, Option.some.injEq, Prod.mk.injEq] at hq
      obtain ⟨-, hi, hj⟩ := hq
      have e1 : (gate f ⟨a, ha⟩ ⟨b, hb⟩ rest).predecessorSum =
          a + b + rest.predecessorSum := rfl
      have e2 : (gate g' i' j' rest).predecessorSum =
          i'.val + j'.val + rest.predecessorSum := rfl
      rw [e1, e2]
      omega
    · rw [replaceAt_tail g' f i' j' rest hqn]
      rw [gateAt_tail g' i' j' rest hqn] at hq
      have h1 := ih hq
      have e1 : (gate g' i' j' (replaceAt rest q f a b)).predecessorSum =
          i'.val + j'.val + (replaceAt rest q f a b).predecessorSum := rfl
      have e2 : (gate g' i' j' rest).predecessorSum =
          i'.val + j'.val + rest.predecessorSum := rfl
      rw [e1, e2]
      omega

theorem replaceAt_psiWeight {n : Nat} (C : OpenCircuit n) {q : Nat} {g f : Table}
    {i j a b : Nat} (hq : C.gateAt q = some (g, i, j)) (ha : a < q) (hb : b < q) :
    (replaceAt C q f a b).psiWeight + g.psiW = C.psiWeight + f.psiW := by
  induction C with
  | output s => simp [gateAt] at hq
  | @gate n g' i' j' rest ih =>
    by_cases hqn : q = n
    · rw [hqn] at hq ha hb
      rw [hqn, replaceAt_head g' f i' j' rest ha hb]
      simp only [gateAt_head, Option.some.injEq, Prod.mk.injEq] at hq
      obtain ⟨hg, -, -⟩ := hq
      have e1 : (gate f ⟨a, ha⟩ ⟨b, hb⟩ rest).psiWeight = f.psiW + rest.psiWeight := rfl
      have e2 : (gate g' i' j' rest).psiWeight = g'.psiW + rest.psiWeight := rfl
      rw [e1, e2, hg]
      omega
    · rw [replaceAt_tail g' f i' j' rest hqn]
      rw [gateAt_tail g' i' j' rest hqn] at hq
      have h1 := ih hq
      have e1 : (gate g' i' j' (replaceAt rest q f a b)).psiWeight =
          g'.psiW + (replaceAt rest q f a b).psiWeight := rfl
      have e2 : (gate g' i' j' rest).psiWeight = g'.psiW + rest.psiWeight := rfl
      rw [e1, e2]
      omega

theorem replaceAt_refCount {n : Nat} (C : OpenCircuit n) {q : Nat} {g f : Table}
    {i j a b : Nat} (hq : C.gateAt q = some (g, i, j)) (ha : a < q) (hb : b < q) (s : Nat) :
    (replaceAt C q f a b).refCount s + ((if i = s then 1 else 0) + (if j = s then 1 else 0)) =
      C.refCount s + ((if a = s then 1 else 0) + (if b = s then 1 else 0)) := by
  induction C with
  | output s' => simp [gateAt] at hq
  | @gate n g' i' j' rest ih =>
    by_cases hqn : q = n
    · rw [hqn] at hq ha hb
      rw [hqn, replaceAt_head g' f i' j' rest ha hb]
      simp only [gateAt_head, Option.some.injEq, Prod.mk.injEq] at hq
      obtain ⟨-, hi, hj⟩ := hq
      have e1 : (gate f ⟨a, ha⟩ ⟨b, hb⟩ rest).refCount s =
          (if a = s then 1 else 0) + (if b = s then 1 else 0) + rest.refCount s := rfl
      have e2 : (gate g' i' j' rest).refCount s =
          (if i'.val = s then 1 else 0) + (if j'.val = s then 1 else 0) + rest.refCount s := rfl
      rw [e1, e2, hi, hj]
      omega
    · rw [replaceAt_tail g' f i' j' rest hqn]
      rw [gateAt_tail g' i' j' rest hqn] at hq
      have h1 := ih hq
      have e1 : (gate g' i' j' (replaceAt rest q f a b)).refCount s =
          (if i'.val = s then 1 else 0) + (if j'.val = s then 1 else 0) +
            (replaceAt rest q f a b).refCount s := rfl
      have e2 : (gate g' i' j' rest).refCount s =
          (if i'.val = s then 1 else 0) + (if j'.val = s then 1 else 0) + rest.refCount s := rfl
      rw [e1, e2]
      omega

/-- The first reader of `s` is unchanged if `s` is not an operand of the old or new gate. -/
theorem replaceAt_firstUserNL_of_ne {n : Nat} (C : OpenCircuit n) {q : Nat} {g f : Table}
    {i j a b : Nat} (hq : C.gateAt q = some (g, i, j)) (ha : a < q) (hb : b < q) {s : Nat}
    (his : i ≠ s) (hjs : j ≠ s) (has : a ≠ s) (hbs : b ≠ s) :
    (replaceAt C q f a b).firstUserNL s = C.firstUserNL s := by
  induction C with
  | output s' => simp [gateAt] at hq
  | @gate n g' i' j' rest ih =>
    by_cases hqn : q = n
    · rw [hqn] at hq ha hb
      rw [hqn, replaceAt_head g' f i' j' rest ha hb]
      simp only [gateAt_head, Option.some.injEq, Prod.mk.injEq] at hq
      obtain ⟨-, hi, hj⟩ := hq
      have h1 : ¬ (a = s ∨ b = s) := by
        rintro (h' | h')
        · exact has h'
        · exact hbs h'
      have h2 : ¬ (i'.val = s ∨ j'.val = s) := by
        rintro (h' | h')
        · exact his (hi.symm.trans h')
        · exact hjs (hj.symm.trans h')
      have e1 : (gate f ⟨a, ha⟩ ⟨b, hb⟩ rest).firstUserNL s =
          if a = s ∨ b = s then f.nonlinear else rest.firstUserNL s := rfl
      have e2 : (gate g' i' j' rest).firstUserNL s =
          if i'.val = s ∨ j'.val = s then g'.nonlinear else rest.firstUserNL s := rfl
      rw [e1, e2, ite_eq_right h1, ite_eq_right h2]
    · rw [replaceAt_tail g' f i' j' rest hqn]
      rw [gateAt_tail g' i' j' rest hqn] at hq
      have e1 : (gate g' i' j' (replaceAt rest q f a b)).firstUserNL s =
          if i'.val = s ∨ j'.val = s then g'.nonlinear
          else (replaceAt rest q f a b).firstUserNL s := rfl
      have e2 : (gate g' i' j' rest).firstUserNL s =
          if i'.val = s ∨ j'.val = s then g'.nonlinear else rest.firstUserNL s := rfl
      rw [e1, e2, ih hq]

/-- The first reader of `s` is unchanged if some gate before `q` already reads `s`. -/
theorem replaceAt_firstUserNL_of_early {n : Nat} (C : OpenCircuit n) {q : Nat} (f : Table)
    (a b : Nat) {s k : Nat} {t : Table} {c d : Nat} (hk : C.gateAt k = some (t, c, d))
    (hkq : k < q) (hcd : c = s ∨ d = s) :
    (replaceAt C q f a b).firstUserNL s = C.firstUserNL s := by
  induction C with
  | output s' => simp [gateAt] at hk
  | @gate n g' i' j' rest ih =>
    have hnk : n ≤ k := (gateAt_bounds _ hk).1
    have hqn : q ≠ n := by omega
    rw [replaceAt_tail g' f i' j' rest hqn]
    have e1 : (gate g' i' j' (replaceAt rest q f a b)).firstUserNL s =
        if i'.val = s ∨ j'.val = s then g'.nonlinear
        else (replaceAt rest q f a b).firstUserNL s := rfl
    have e2 : (gate g' i' j' rest).firstUserNL s =
        if i'.val = s ∨ j'.val = s then g'.nonlinear else rest.firstUserNL s := rfl
    rw [e1, e2]
    by_cases hs : i'.val = s ∨ j'.val = s
    · rw [ite_eq_left hs, ite_eq_left hs]
    · rw [ite_eq_right hs, ite_eq_right hs]
      have hkn : k ≠ n := by
        intro hkn
        rw [hkn] at hk
        simp only [gateAt_head, Option.some.injEq, Prod.mk.injEq] at hk
        obtain ⟨-, hc, hd⟩ := hk
        apply hs
        rw [hc, hd]
        exact hcd
      rw [gateAt_tail g' i' j' rest hkn] at hk
      exact ih hk

theorem replaceAt_eval {n : Nat} (C : OpenCircuit n) {q : Nat} {g f : Table}
    {i j a b : Nat} (hq : C.gateAt q = some (g, i, j)) (ha : a < q) (hb : b < q)
    (v : Fin n → Bool)
    (hv : f.eval (C.valueAt v a) (C.valueAt v b) = g.eval (C.valueAt v i) (C.valueAt v j)) :
    (replaceAt C q f a b).eval v = C.eval v := by
  induction C with
  | output s => simp [gateAt] at hq
  | @gate n g' i' j' rest ih =>
    by_cases hqn : q = n
    · rw [hqn] at hq ha hb
      rw [hqn, replaceAt_head g' f i' j' rest ha hb]
      simp only [gateAt_head, Option.some.injEq, Prod.mk.injEq] at hq
      obtain ⟨hg, hi, hj⟩ := hq
      have e1 : (gate g' i' j' rest).valueAt v a = v ⟨a, ha⟩ := valueAt_input _ v ⟨a, ha⟩
      have e2 : (gate g' i' j' rest).valueAt v b = v ⟨b, hb⟩ := valueAt_input _ v ⟨b, hb⟩
      have e3 : (gate g' i' j' rest).valueAt v i = v i' := by
        rw [← hi]
        exact valueAt_input _ v i'
      have e4 : (gate g' i' j' rest).valueAt v j = v j' := by
        rw [← hj]
        exact valueAt_input _ v j'
      rw [e1, e2, e3, e4, ← hg] at hv
      show rest.eval (extend v (f.eval (v ⟨a, ha⟩) (v ⟨b, hb⟩))) =
        rest.eval (extend v (g'.eval (v i') (v j')))
      rw [hv]
    · rw [replaceAt_tail g' f i' j' rest hqn]
      rw [gateAt_tail g' i' j' rest hqn] at hq
      show (replaceAt rest q f a b).eval (extend v (g'.eval (v i') (v j'))) =
        rest.eval (extend v (g'.eval (v i') (v j')))
      exact ih hq (extend v (g'.eval (v i') (v j'))) hv

/-! ### Locating an input triangle in global indices -/

/-- `k` is a primary input with respect to the history `Γ`. -/
def HPrim {m : Nat} (Γ : History m) (k : Nat) : Prop := ∃ z : Fin m, z.val = k ∧ Γ z = none

/-- `k` is a gate reading `s`: either recorded in the history `Γ`, or a gate of `T`. -/
def HReads {m : Nat} (Γ : History m) (T : OpenCircuit m) (k s : Nat) : Prop :=
  (∃ z : Fin m, z.val = k ∧ ∃ p : GateRecipe m, Γ z = some p ∧
      (p.left.val = s ∨ p.right.val = s)) ∨
    ∃ t c d, T.gateAt k = some (t, c, d) ∧ (c = s ∨ d = s)

theorem hprim_extend {m : Nat} (Γ : History m) (g : Table) (i j : Fin m) {k : Nat}
    (h : HPrim (Γ.extend g i j) k) : HPrim Γ k := by
  obtain ⟨z, hz, hnone⟩ := h
  induction z using Fin.lastCases with
  | last =>
    rw [History.extend_last] at hnone
    simp at hnone
  | cast z =>
    rw [History.extend_old] at hnone
    refine ⟨z, (Fin.val_castSucc z).symm.trans hz, ?_⟩
    cases hΓ : Γ z with
    | none => rfl
    | some p =>
      rw [hΓ] at hnone
      simp at hnone

theorem hreads_extend {m : Nat} (Γ : History m) (g : Table) (i j : Fin m)
    (rest : OpenCircuit (m + 1)) {k s : Nat} (h : HReads (Γ.extend g i j) rest k s) :
    HReads Γ (gate g i j rest) k s := by
  rcases h with ⟨z, hz, p, hp, hps⟩ | ⟨t, c, d, hk, hcd⟩
  · induction z using Fin.lastCases with
    | last =>
      rw [History.extend_last] at hp
      have hpe : (⟨g, i.castSucc, j.castSucc⟩ : GateRecipe (m + 1)) = p := Option.some.inj hp
      subst hpe
      right
      refine ⟨g, i.val, j.val, ?_, ?_⟩
      · rw [← hz, Fin.val_last]
        exact gateAt_head g i j rest
      · simpa only [Fin.val_castSucc] using hps
    | cast z =>
      rw [History.extend_old] at hp
      left
      cases hΓ : Γ z with
      | none =>
        rw [hΓ] at hp
        simp at hp
      | some p₀ =>
        rw [hΓ] at hp
        have hpe : GateRecipe.lift p₀ = p := Option.some.inj hp
        subst hpe
        refine ⟨z, (Fin.val_castSucc z).symm.trans hz, p₀, hΓ, ?_⟩
        simpa only [GateRecipe.lift, Fin.val_castSucc] using hps
  · right
    have hkm : k ≠ m := by
      have := (gateAt_bounds rest hk).1
      omega
    exact ⟨t, c, d, by rw [gateAt_tail g i j rest hkm]; exact hk, hcd⟩

theorem exists_flat_triangle_aux {m : Nat} (T : OpenCircuit m) (Γ : History m)
    (ht : ¬ T.NoInputTriangles Γ) :
    ∃ q g i j, T.gateAt q = some (g, i, j) ∧
      ((HPrim Γ i ∧ HReads Γ T j i) ∨ (HPrim Γ j ∧ HReads Γ T i j)) := by
  induction T with
  | output s => exact False.elim (ht True.intro)
  | @gate m g i j rest ih =>
    by_cases htri : Γ.TriangleAt i j
    · refine ⟨m, g, i.val, j.val, gateAt_head g i j rest, ?_⟩
      rcases htri with ⟨hi, p, hp, hpi⟩ | ⟨hj, p, hp, hpj⟩
      · refine Or.inl ⟨⟨i, rfl, hi⟩, Or.inl ⟨j, rfl, p, hp, ?_⟩⟩
        rcases hpi with h | h
        · exact Or.inl (congrArg Fin.val h)
        · exact Or.inr (congrArg Fin.val h)
      · refine Or.inr ⟨⟨j, rfl, hj⟩, Or.inl ⟨i, rfl, p, hp, ?_⟩⟩
        rcases hpj with h | h
        · exact Or.inl (congrArg Fin.val h)
        · exact Or.inr (congrArg Fin.val h)
    · have hr : ¬ rest.NoInputTriangles (Γ.extend g i j) := fun h => ht ⟨htri, h⟩
      obtain ⟨q, g', i', j', hq, htr⟩ := ih (Γ.extend g i j) hr
      have hqm : q ≠ m := by
        have := (gateAt_bounds rest hq).1
        omega
      refine ⟨q, g', i', j', ?_, ?_⟩
      · rw [gateAt_tail g i j rest hqm]
        exact hq
      · rcases htr with ⟨h1, h2⟩ | ⟨h1, h2⟩
        · exact Or.inl ⟨hprim_extend Γ g i j h1, hreads_extend Γ g i j rest h2⟩
        · exact Or.inr ⟨hprim_extend Γ g i j h1, hreads_extend Γ g i j rest h2⟩

/-- An input triangle in global indices: a gate `q = g(i, j)` one of whose operands is a
primary input read by the other operand, which is a gate. -/
theorem exists_flat_triangle {n : Nat} (C : OpenCircuit n)
    (ht : ¬ C.NoInputTriangles (fun _ => none)) :
    ∃ q g i j, C.gateAt q = some (g, i, j) ∧
      ((i < n ∧ ∃ t c d, C.gateAt j = some (t, c, d) ∧ (c = i ∨ d = i)) ∨
       (j < n ∧ ∃ t c d, C.gateAt i = some (t, c, d) ∧ (c = j ∨ d = j))) := by
  obtain ⟨q, g, i, j, hq, htr⟩ := exists_flat_triangle_aux C (fun _ => none) ht
  have hP : ∀ k, HPrim (fun _ : Fin n => (none : Option (GateRecipe n))) k → k < n := by
    rintro k ⟨z, hz, -⟩
    rw [← hz]
    exact z.isLt
  have hR : ∀ k s, HReads (fun _ : Fin n => (none : Option (GateRecipe n))) C k s →
      ∃ t c d, C.gateAt k = some (t, c, d) ∧ (c = s ∨ d = s) := by
    rintro k s (⟨z, -, p, hp, -⟩ | hk)
    · simp at hp
    · exact hk
  refine ⟨q, g, i, j, hq, ?_⟩
  rcases htr with ⟨h1, h2⟩ | ⟨h1, h2⟩
  · exact Or.inl ⟨hP i h1, hR j i h2⟩
  · exact Or.inr ⟨hP j h1, hR i j h2⟩

/-! ### D-variables and the rewrite -/

theorem dCount_mono {n : Nat} (C D : OpenCircuit n)
    (h : ∀ z : Fin n, C.isD z.val = true → D.isD z.val = true) : C.dCount ≤ D.dCount := by
  unfold dCount
  refine Finset.sum_le_sum fun z _ => ?_
  show indicator (C.isD z.val) ≤ indicator (D.isD z.val)
  cases hz : C.isD z.val with
  | false => exact Nat.zero_le _
  | true => exact Nat.le_of_eq (by rw [h z hz])

/-- The rewrite of one input triangle `q = g(i, j)`, `{i, j} = {x, P}`, `P = p(c, d)`,
`{c, d} = {x, u}`, by `q := f(x, u)`. -/
theorem core {n : Nat} (C : OpenCircuit n) (hsafe : C.DGateSafe)
    {q x P u : Nat} {g p f : Table} {i j c d : Nat}
    (hq : C.gateAt q = some (g, i, j)) (hij : (i = x ∧ j = P) ∨ (i = P ∧ j = x))
    (hx : x < n) (hP : C.gateAt P = some (p, c, d))
    (hcd : (c = x ∧ d = u) ∨ (c = u ∧ d = x)) (hw : f.weight ≤ g.weight)
    (hv : ∀ v, f.eval (C.valueAt v x) (C.valueAt v u) =
      g.eval (C.valueAt v i) (C.valueAt v j)) :
    ∃ D : OpenCircuit n, D.size = C.size ∧ D.predecessorSum < C.predecessorSum ∧
      D.psi ≤ C.psi ∧ ∀ v, D.eval v = C.eval v := by
  obtain ⟨-, -, hiq, hjq⟩ := gateAt_bounds C hq
  obtain ⟨hnP, -, hcP, hdP⟩ := gateAt_bounds C hP
  have hPq : P < q := by rcases hij with ⟨h1, h2⟩ | ⟨h1, h2⟩ <;> omega
  have hxq : x < q := by rcases hij with ⟨h1, h2⟩ | ⟨h1, h2⟩ <;> omega
  have huP : u < P := by rcases hcd with ⟨h1, h2⟩ | ⟨h1, h2⟩ <;> omega
  have huq : u < q := by omega
  refine ⟨replaceAt C q f x u, replaceAt_size C q f x u, ?_, ?_,
    fun v => replaceAt_eval C hq hxq huq v (hv v)⟩
  · have h1 := replaceAt_predecessorSum C (f := f) hq hxq huq
    rcases hij with ⟨h2, h3⟩ | ⟨h2, h3⟩ <;> omega
  · have hpw := replaceAt_psiWeight C (f := f) hq hxq huq
    have hmono := Table.psiW_mono f g hw
    have hdc : C.dCount ≤ (replaceAt C q f x u).dCount := by
      apply dCount_mono
      intro z hCz
      have hzn := z.isLt
      by_cases hzu : z.val = u
      · exfalso
        have hcn : c < n := by rcases hcd with ⟨h1, h2⟩ | ⟨h1, h2⟩ <;> omega
        have hdn : d < n := by rcases hcd with ⟨h1, h2⟩ | ⟨h1, h2⟩ <;> omega
        obtain ⟨hc', hd'⟩ := hsafe P p c d hP hcn hdn
        rcases hcd with ⟨-, h2⟩ | ⟨h1, -⟩
        · rw [h2, ← hzu, hCz] at hd'
          exact Bool.noConfusion hd'
        · rw [h1, ← hzu, hCz] at hc'
          exact Bool.noConfusion hc'
      · have hzP : z.val ≠ P := by omega
        have href : (replaceAt C q f x u).refCount z.val = C.refCount z.val := by
          have hr' := replaceAt_refCount C (f := f) hq hxq huq z.val
          rcases hij with ⟨h1, h2⟩ | ⟨h1, h2⟩ <;> split_ifs at hr' <;> omega
        have hfirst : (replaceAt C q f x u).firstUserNL z.val = C.firstUserNL z.val := by
          by_cases hzx : z.val = x
          · rw [hzx]
            apply replaceAt_firstUserNL_of_early C f x u hP hPq
            rcases hcd with ⟨h1, -⟩ | ⟨-, h2⟩
            · exact Or.inl h1
            · exact Or.inr h2
          · apply replaceAt_firstUserNL_of_ne C hq hxq huq
            · rcases hij with ⟨h1, h2⟩ | ⟨h1, h2⟩ <;> omega
            · rcases hij with ⟨h1, h2⟩ | ⟨h1, h2⟩ <;> omega
            · omega
            · omega
        unfold isD at hCz ⊢
        rw [href, hfirst]
        exact hCz
    unfold psi
    omega

end PsiTriangleAux

theorem psi_triangle_step {n : Nat} (C : OpenCircuit n) (hr : C.Reduced) (hsafe : C.DGateSafe)
    (ht : ¬ C.NoInputTriangles (fun _ => none)) :
    ∃ D : OpenCircuit n, D.size = C.size ∧ D.predecessorSum < C.predecessorSum ∧
      D.psi ≤ C.psi ∧ ∀ x, D.eval x = C.eval x := by
  obtain ⟨q, g, i, j, hq, htr⟩ := PsiTriangleAux.exists_flat_triangle C ht
  have hg : g.essential = true := C.essentialGates_gate (C.reduced_essential hr) hq
  have hgs : g.swap.essential = true := by rw [Table.swap_essential]; exact hg
  rcases htr with ⟨hin, t, c, d, hjP, hcd⟩ | ⟨hjn, t, c, d, hiP, hcd⟩
  · -- `q = g(x, P)` with `x = i` primary and `P = j = t(c, d)`
    rcases hcd with hc | hd
    · refine PsiTriangleAux.core C hsafe (x := i) (P := j) (u := d)
        (f := Table.triangle t g) hq (Or.inl ⟨rfl, rfl⟩) hin hjP (Or.inl ⟨hc, rfl⟩)
        (Table.triangle_weight t g hg) ?_
      intro v
      rw [Table.triangle_eval, valueAt_gate C v hjP, hc]
    · refine PsiTriangleAux.core C hsafe (x := i) (P := j) (u := c)
        (f := Table.triangle t.swap g) hq (Or.inl ⟨rfl, rfl⟩) hin hjP (Or.inr ⟨rfl, hd⟩)
        (Table.triangle_weight t.swap g hg) ?_
      intro v
      rw [Table.triangle_eval, Table.swap_eval, valueAt_gate C v hjP, hd]
  · -- `q = g(P, x)` with `x = j` primary and `P = i = t(c, d)`
    rcases hcd with hc | hd
    · refine PsiTriangleAux.core C hsafe (x := j) (P := i) (u := d)
        (f := Table.triangle t g.swap) hq (Or.inr ⟨rfl, rfl⟩) hjn hiP (Or.inl ⟨hc, rfl⟩)
        (Nat.le_trans (Table.triangle_weight t g.swap hgs) (Nat.le_of_eq (Table.swap_weight g)))
        ?_
      intro v
      rw [Table.triangle_eval, Table.swap_eval, valueAt_gate C v hiP, hc]
    · refine PsiTriangleAux.core C hsafe (x := j) (P := i) (u := c)
        (f := Table.triangle t.swap g.swap) hq (Or.inr ⟨rfl, rfl⟩) hjn hiP (Or.inr ⟨rfl, hd⟩)
        (Nat.le_trans (Table.triangle_weight t.swap g.swap hgs)
          (Nat.le_of_eq (Table.swap_weight g))) ?_
      intro v
      rw [Table.triangle_eval, Table.swap_eval, Table.swap_eval, valueAt_gate C v hiP, hd]

end OpenCircuit
end SatLowerBound
