import Credit.Flat

/-!
# Credit.Transfer — the restriction compiler versus the abstract trace

`restrict_transfer` identifies size, `psiWeight`, references and first-user types of the
restricted circuit `C.restrict σ` with the kept-level quantities of `Credit.Basic`, computed on
the original circuit from an abstract resolution `ρ` that matches `σ`.

`φ : Fin m → Nat` sends each signal of the target space to the *original* global index of its
source (a free input or a kept gate).  When the compiler keeps the gate of global index `n`
(the head of `gate g i j rest : OpenCircuit n`) it creates the target signal `m`, and `φ` is
extended by `m ↦ n`; this keeps `φ` injective because `φ < n` (hypothesis `hφn`).

The remaining statements of this file (all proved here from `restrict_transfer`) are the
specializations used by the rest of the development.
-/

namespace SatLowerBound
namespace OpenCircuit

/-- `σ k` and `ρ k` describe the same resolved signal, via the source map `φ`. -/
def ResRel {m : Nat} (φ : Fin m → Nat) : Signal m → Res → Prop
  | .constant b, r => r = .const b
  | .wire w neg, r => r = .lit (φ w) neg

/-! ### The gate step: `simplifyGate` versus `Res.step`

Helper lemmas for `restrict_transfer`: the compiler's alias steps are exactly the `some`
steps of the abstract trace (`step_of_alias`), its binary steps are the `none` steps
(`step_of_binary`), and the substitutions built by `extendSubst`/`liftSubst` stay related
to `appendValue` of the trace (`rel_extend`, `rel_lift`; for a kept gate the source map is
extended by `appendValue φ n`, which stays injective because `φ < n`). -/

namespace TransferAux

theorem rel_const {m : Nat} {φ : Fin m → Nat} {b : Bool} {r : Res}
    (h : ResRel φ (.constant b) r) : r = .const b := h

theorem rel_wire {m : Nat} {φ : Fin m → Nat} {w : Fin m} {neg : Bool} {r : Res}
    (h : ResRel φ (.wire w neg) r) : r = .lit (φ w) neg := h

theorem appendValue_castSucc {α : Type} {n : Nat} (x : Fin n → α) (v : α) (k : Fin n) :
    appendValue x v k.castSucc = x k := by
  simp [appendValue]

theorem appendValue_last {α : Type} {n : Nat} (x : Fin n → α) (v : α) :
    appendValue x v (Fin.last n) = v := by
  simp [appendValue]

theorem extendSubst_castSucc {n m : Nat} (σ : Fin n → Signal m) (s : Signal m) (k : Fin n) :
    extendSubst σ s k.castSucc = σ k := by
  simp [extendSubst]

theorem extendSubst_last {n m : Nat} (σ : Fin n → Signal m) (s : Signal m) :
    extendSubst σ s (Fin.last n) = s := by
  simp [extendSubst]

theorem unary_rel {m : Nat} (φ : Fin m → Nat) (f : Bool → Bool) (i : Fin m) :
    ResRel φ (Signal.unary f i) (Res.unary f (φ i)) := by
  unfold Signal.unary Res.unary
  by_cases h : f false = f true
  · rw [ite_eq_left h, ite_eq_left h]
    rfl
  · rw [ite_eq_right h, ite_eq_right h]
    rfl

theorem hits_rel {m : Nat} {φ : Fin m → Nat} (hφ : Function.Injective φ) (k w : Fin m)
    (a : Bool) : (Res.lit (φ k) a).hits (φ w) = decide (k.val = w.val) := by
  by_cases h : k = w
  · subst h
    simp [Res.hits]
  · have h1 : φ k ≠ φ w := fun e => h (hφ e)
    have h2 : k.val ≠ w.val := fun e => h (Fin.ext e)
    simp [Res.hits, h1, h2]

theorem indicator_hits_rel {m : Nat} {φ : Fin m → Nat} (hφ : Function.Injective φ)
    (k w : Fin m) (a : Bool) :
    indicator ((Res.lit (φ k) a).hits (φ w)) = if k.val = w.val then 1 else 0 := by
  rw [hits_rel hφ]
  by_cases h : k.val = w.val
  · simp [indicator, h]
  · simp [indicator, h]

/-- Alias steps of the compiler correspond to `some` steps of the trace. -/
theorem step_of_alias {m : Nat} (φ : Fin m → Nat) (hφ : Function.Injective φ) (g : Table)
    {s₁ s₂ : Signal m} {r₁ r₂ : Res} (h₁ : ResRel φ s₁ r₁) (h₂ : ResRel φ s₂ r₂)
    {s : Signal m} (hs : simplifyGate g s₁ s₂ = .alias s) :
    ∃ r, Res.step g r₁ r₂ = some r ∧ ResRel φ s r := by
  cases s₁ with
  | constant a =>
    rw [rel_const h₁]
    cases s₂ with
    | constant b =>
      rw [rel_const h₂]
      simp only [simplifyGate, GateStep.alias.injEq] at hs
      subst hs
      exact ⟨_, rfl, rfl⟩
    | wire j b =>
      rw [rel_wire h₂]
      simp only [simplifyGate, GateStep.alias.injEq] at hs
      subst hs
      exact ⟨_, rfl, unary_rel φ _ j⟩
  | wire i a =>
    rw [rel_wire h₁]
    cases s₂ with
    | constant b =>
      rw [rel_const h₂]
      simp only [simplifyGate, GateStep.alias.injEq] at hs
      subst hs
      exact ⟨_, rfl, unary_rel φ _ i⟩
    | wire j b =>
      rw [rel_wire h₂]
      by_cases hij : i = j
      · subst hij
        simp only [simplifyGate] at hs
        rw [ite_eq_left trivial] at hs
        simp only [GateStep.alias.injEq] at hs
        subst hs
        refine ⟨_, ?_, unary_rel φ _ i⟩
        simp only [Res.step]
        rw [ite_eq_left trivial]
      · have hφij : φ i ≠ φ j := fun e => hij (hφ e)
        simp only [simplifyGate] at hs
        rw [ite_eq_right hij] at hs
        simp only [GateStep.classify] at hs
        by_cases hd1 : (twist g a b).ff = (twist g a b).tf ∧ (twist g a b).ft = (twist g a b).tt
        · rw [ite_eq_left hd1] at hs
          simp only [GateStep.alias.injEq] at hs
          subst hs
          refine ⟨_, ?_, unary_rel φ _ j⟩
          simp only [Res.step]
          rw [ite_eq_right hφij, ite_eq_left hd1]
        · rw [ite_eq_right hd1] at hs
          by_cases hd2 : (twist g a b).ff = (twist g a b).ft ∧ (twist g a b).tf = (twist g a b).tt
          · rw [ite_eq_left hd2] at hs
            simp only [GateStep.alias.injEq] at hs
            subst hs
            refine ⟨_, ?_, unary_rel φ _ i⟩
            simp only [Res.step]
            rw [ite_eq_right hφij, ite_eq_right hd1, ite_eq_left hd2]
          · rw [ite_eq_right hd2] at hs
            cases hs

/-- Binary steps of the compiler correspond to `none` steps of the trace. -/
theorem step_of_binary {m : Nat} (φ : Fin m → Nat) (hφ : Function.Injective φ) (g : Table)
    {s₁ s₂ : Signal m} {r₁ r₂ : Res} (h₁ : ResRel φ s₁ r₁) (h₂ : ResRel φ s₂ r₂)
    {t : Table} {k l : Fin m} (hs : simplifyGate g s₁ s₂ = .binary t k l) :
    Res.step g r₁ r₂ = none ∧
      ∃ a b, t = twist g a b ∧ r₁ = .lit (φ k) a ∧ r₂ = .lit (φ l) b := by
  cases s₁ with
  | constant a =>
    cases s₂ with
    | constant b => simp [simplifyGate] at hs
    | wire j b => simp [simplifyGate] at hs
  | wire i a =>
    rw [rel_wire h₁]
    cases s₂ with
    | constant b => simp [simplifyGate] at hs
    | wire j b =>
      rw [rel_wire h₂]
      by_cases hij : i = j
      · subst hij
        simp only [simplifyGate] at hs
        rw [ite_eq_left trivial] at hs
        cases hs
      · have hφij : φ i ≠ φ j := fun e => hij (hφ e)
        simp only [simplifyGate] at hs
        rw [ite_eq_right hij] at hs
        simp only [GateStep.classify] at hs
        by_cases hd1 : (twist g a b).ff = (twist g a b).tf ∧ (twist g a b).ft = (twist g a b).tt
        · rw [ite_eq_left hd1] at hs
          cases hs
        · rw [ite_eq_right hd1] at hs
          by_cases hd2 : (twist g a b).ff = (twist g a b).ft ∧ (twist g a b).tf = (twist g a b).tt
          · rw [ite_eq_left hd2] at hs
            cases hs
          · rw [ite_eq_right hd2] at hs
            simp only [GateStep.binary.injEq] at hs
            obtain ⟨rfl, rfl, rfl⟩ := hs
            refine ⟨?_, a, b, rfl, rfl, rfl⟩
            simp only [Res.step]
            rw [ite_eq_right hφij, ite_eq_right hd1, ite_eq_right hd2]

theorem rel_extend {n m : Nat} {φ : Fin m → Nat} {σ : Fin n → Signal m} {ρ : Fin n → Res}
    (hrel : ∀ k, ResRel φ (σ k) (ρ k)) {s : Signal m} {r : Res} (hsr : ResRel φ s r) :
    ∀ k, ResRel φ (extendSubst σ s k) (appendValue ρ r k) := by
  intro k
  induction k using Fin.lastCases with
  | last =>
    rw [extendSubst_last, appendValue_last]
    exact hsr
  | cast k =>
    rw [extendSubst_castSucc, appendValue_castSucc]
    exact hrel k

theorem rel_rename {m : Nat} {φ : Fin m → Nat} (v : Nat) {t : Signal m} {r : Res}
    (h : ResRel φ t r) : ResRel (appendValue φ v) (t.rename Fin.castSucc) r := by
  cases t with
  | constant b => exact h
  | wire w neg =>
    show r = .lit (appendValue φ v w.castSucc) neg
    rw [appendValue_castSucc]
    exact h

theorem rel_lift {n m : Nat} {φ : Fin m → Nat} {σ : Fin n → Signal m} {ρ : Fin n → Res}
    (hrel : ∀ k, ResRel φ (σ k) (ρ k)) :
    ∀ k, ResRel (appendValue φ n) (liftSubst σ k) (appendValue ρ (.lit n false) k) := by
  intro k
  induction k using Fin.lastCases with
  | last =>
    rw [liftSubst, extendSubst_last, appendValue_last]
    show Res.lit n false = .lit (appendValue φ n (Fin.last m)) false
    rw [appendValue_last]
  | cast k =>
    rw [liftSubst, extendSubst_castSucc, appendValue_castSucc]
    exact rel_rename n (hrel k)

theorem appendValue_injective {n m : Nat} {φ : Fin m → Nat} (hφ : Function.Injective φ)
    (hφn : ∀ w, φ w < n) : Function.Injective (appendValue φ n) := by
  intro w₁ w₂ h
  induction w₁ using Fin.lastCases with
  | last =>
    induction w₂ using Fin.lastCases with
    | last => rfl
    | cast w₂ =>
      rw [appendValue_last, appendValue_castSucc] at h
      exact absurd h.symm (Nat.ne_of_lt (hφn w₂))
  | cast w₁ =>
    induction w₂ using Fin.lastCases with
    | last =>
      rw [appendValue_last, appendValue_castSucc] at h
      exact absurd h (Nat.ne_of_lt (hφn w₁))
    | cast w₂ =>
      rw [appendValue_castSucc, appendValue_castSucc] at h
      rw [hφ h]

theorem appendValue_lt {n m : Nat} {φ : Fin m → Nat} (hφn : ∀ w, φ w < n) :
    ∀ w, appendValue φ n w < n + 1 := by
  intro w
  induction w using Fin.lastCases with
  | last =>
    rw [appendValue_last]
    exact Nat.lt_succ_self n
  | cast w =>
    rw [appendValue_castSucc]
    exact Nat.lt_succ_of_lt (hφn w)

theorem refCount_output_subst {m : Nat} {φ : Fin m → Nat} (hφ : Function.Injective φ)
    (t : Signal m) (r : Res) (h : ResRel φ t r) (neg : Bool) (w : Fin m) :
    (OpenCircuit.output (if neg then t.negate else t)).refCount w.val =
      indicator (r.hits (φ w)) := by
  cases t with
  | constant c =>
    rw [rel_const h]
    cases neg <;> rfl
  | wire k b =>
    rw [rel_wire h, indicator_hits_rel hφ]
    cases neg <;> rfl

end TransferAux

/-- The transfer theorem (proved by induction on `C`, generalizing `m`, `σ`, `ρ`, `φ`; the
gate step compares `simplifyGate`/`GateStep.classify` with `Res.step` and needs `hφ` for the
`i = j` test). -/
theorem restrict_transfer {n m : Nat} (C : OpenCircuit n) (σ : Fin n → Signal m)
    (ρ : Fin n → Res) (φ : Fin m → Nat) (hφ : Function.Injective φ) (hφn : ∀ w, φ w < n)
    (hrel : ∀ k, ResRel φ (σ k) (ρ k)) :
    (C.restrict σ).size = C.keptCount ρ ∧
    (C.restrict σ).psiWeight = C.keptPsiWeight ρ ∧
    (∀ w : Fin m, (C.restrict σ).refCount w.val = C.keptRefs ρ (φ w)) ∧
    (∀ w : Fin m, (C.restrict σ).firstUserNL w.val = C.keptFirstNL ρ (φ w)) := by
  induction C generalizing m with
  | output s =>
    refine ⟨rfl, rfl, ?_, fun _ => rfl⟩
    intro w
    cases s with
    | constant b => rfl
    | wire i neg => exact TransferAux.refCount_output_subst hφ (σ i) (ρ i) (hrel i) neg w
  | @gate n g i j rest ih =>
    rcases hsg : simplifyGate g (σ i) (σ j) with s | ⟨t, k, l⟩
    · obtain ⟨r, hstep, hsr⟩ := TransferAux.step_of_alias φ hφ g (hrel i) (hrel j) hsg
      have hres : (gate g i j rest).restrict σ = rest.restrict (extendSubst σ s) := by
        simp only [restrict, hsg]
      obtain ⟨h1, h2, h3, h4⟩ := ih (extendSubst σ s) (appendValue ρ r) φ hφ
        (fun w => Nat.lt_succ_of_lt (hφn w)) (TransferAux.rel_extend hrel hsr)
      rw [hres]
      simp only [keptCount, keptPsiWeight, keptRefs, keptFirstNL, hstep]
      exact ⟨h1, h2, h3, h4⟩
    · obtain ⟨hstep, a, b, ht, hk, hl⟩ :=
        TransferAux.step_of_binary φ hφ g (hrel i) (hrel j) hsg
      subst ht
      have hres : (gate g i j rest).restrict σ =
          .gate (twist g a b) k l (rest.restrict (liftSubst σ)) := by
        simp only [restrict, hsg]
      obtain ⟨h1, h2, h3, h4⟩ := ih (liftSubst σ) (appendValue ρ (.lit n false))
        (appendValue φ n) (TransferAux.appendValue_injective hφ hφn)
        (TransferAux.appendValue_lt hφn) (TransferAux.rel_lift hrel)
      rw [hres]
      simp only [keptCount, keptPsiWeight, keptRefs, keptFirstNL, hstep]
      refine ⟨?_, ?_, ?_, ?_⟩
      · simp only [size, h1]
      · simp only [psiWeight, h2, twist_psiW]
      · intro w
        have h3w := h3 w.castSucc
        rw [TransferAux.appendValue_castSucc, Fin.val_castSucc] at h3w
        simp only [refCount]
        rw [h3w, hk, hl, TransferAux.indicator_hits_rel hφ, TransferAux.indicator_hits_rel hφ]
      · intro w
        have h4w := h4 w.castSucc
        rw [TransferAux.appendValue_castSucc, Fin.val_castSucc] at h4w
        simp only [firstUserNL]
        rw [h4w, hk, hl, TransferAux.hits_rel hφ, TransferAux.hits_rel hφ, twist_nonlinear]
        apply ite_cond_congr
        apply propext
        simp

/-! ### Proved consequences -/

theorem psiWeight_split {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) :
    C.psiWeight = C.keptPsiWeight ρ + C.aliasedPsiWeight ρ := by
  induction C with
  | output => rfl
  | @gate n g i j rest ih =>
    simp only [psiWeight, keptPsiWeight, aliasedPsiWeight]
    cases Res.step g (ρ i) (ρ j) with
    | some r =>
      have h := ih (appendValue ρ r)
      simp only
      omega
    | none =>
      have h := ih (appendValue ρ (.lit n false))
      simp only
      omega

theorem size_split {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) :
    C.size = C.keptCount ρ + C.aliasedCount ρ := by
  induction C with
  | output => rfl
  | @gate n g i j rest ih =>
    simp only [size, keptCount, aliasedCount]
    cases Res.step g (ρ i) (ρ j) with
    | some r =>
      have h := ih (appendValue ρ r)
      simp only
      omega
    | none =>
      have h := ih (appendValue ρ (.lit n false))
      simp only
      omega

theorem fixSubst_rel {n : Nat} (P c : Fin n → Bool) (k : Fin n) :
    ResRel Fin.val (fixSubst P c k) (fixRes P c k) := by
  by_cases h : P k = true
  · simp [fixSubst, fixRes, h, ResRel]
  · simp [fixSubst, fixRes, h, ResRel]

theorem fix_transfer {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool) :
    (C.restrict (fixSubst P c)).size = C.keptCount (fixRes P c) ∧
    (C.restrict (fixSubst P c)).psiWeight = C.keptPsiWeight (fixRes P c) ∧
    (∀ z : Fin n, (C.restrict (fixSubst P c)).refCount z.val = C.keptRefs (fixRes P c) z.val) ∧
    (∀ z : Fin n, (C.restrict (fixSubst P c)).isD z.val = C.keptIsD (fixRes P c) z.val) := by
  obtain ⟨hs, hw, hr, hf⟩ := C.restrict_transfer (fixSubst P c) (fixRes P c)
    Fin.val Fin.val_injective (fun w => w.isLt) (fixSubst_rel P c)
  refine ⟨hs, hw, hr, ?_⟩
  intro z
  unfold isD keptIsD
  rw [hr z, hf z]

theorem psi_restrict_fix {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool) :
    (C.restrict (fixSubst P c)).psi =
      (C.keptPsiWeight (fixRes P c) : Int) -
        ((∑ z : Fin n, indicator (C.keptIsD (fixRes P c) z.val) : Nat) : Int) := by
  obtain ⟨_, hw, _, hd⟩ := C.fix_transfer P c
  have hsum : (∑ z : Fin n, indicator ((C.restrict (fixSubst P c)).isD z.val)) =
      ∑ z : Fin n, indicator (C.keptIsD (fixRes P c) z.val) :=
    Finset.sum_congr rfl (fun z _ => by rw [hd z])
  unfold psi dCount
  rw [hw, hsum]

theorem usage_restrict_fix {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool) (z : Fin n) :
    (C.restrict (fixSubst P c)).usage (singleUse z) = C.keptRefs (fixRes P c) z.val := by
  rw [usage_singleUse]
  exact (C.fix_transfer P c).2.2.1 z

/-- An input that the restricted circuit never reads is inessential for it. -/
theorem not_essential_of_keptRefs_zero {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool)
    (z : Fin n) (h : C.keptRefs (fixRes P c) z.val = 0) :
    ¬ Essential (C.restrict (fixSubst P c)).eval z := by
  rintro ⟨u, v, huv, hne⟩
  apply hne
  apply eval_eq_of_zero_usage _ (singleUse z)
  · rw [usage_restrict_fix]
    exact h
  · intro j hj
    apply huv
    intro he
    subst he
    simp [singleUse] at hj

end OpenCircuit
end SatLowerBound
