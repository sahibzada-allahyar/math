import Credit.Flat

/-!
# Credit.FlatKept — kept-level quantities in flat form

The recursive kept-level quantities of `Credit.Basic` (`keptCount`, `keptPsiWeight`,
`keptRefs`, `keptFirstNL`, …) are sums over global gate indices of local data computed from
`gateAt`, `resAt`, `isKept`.  This file also contains the "passing" analysis: which gates of
the original circuit become literals of a given free input after the restriction.

Do not change any statement in this file without updating `STATUS.txt`.

Implementation notes (package A2).  All proofs are self-contained: they use only the proved
lemmas of `Credit.Flat` (`gateAt_*`, `resAt_input`, `resAt_gate`, `resAt_kept`), not the open
ones.  The helpers live in the namespace `OpenCircuit.FlatKeptAux`:
* `tailRes g i j ρ` is the resolution of the inputs of `rest` inside `gate g i j rest`, so that
  `(gate g i j rest).resAt ρ k = rest.resAt (tailRes g i j ρ) k` holds by `rfl` (`resAt_cons`);
* `*_cons_head` / `*_cons_tail` / `*_rest_head` compute the flat quantities of the head gate
  `n`, of the later gates, and show that `rest` has no gate `n`;
* `*_cons` rewrite each recursive kept-level quantity as "head term + tail quantity";
* `sum_split` peels the head gate off a sum over `Finset.range`;
* `hits_cases` is a self-contained version of `resAt_hits_cases`.
-/

namespace SatLowerBound
namespace OpenCircuit

namespace FlatKeptAux

theorem indicator_true : indicator true = 1 := rfl

theorem indicator_false : indicator false = 0 := rfl

theorem indicator_add_pos :
    ∀ x y : Bool, (x = true ∨ y = true) → 1 ≤ indicator x + indicator y := by
  decide

theorem or_of_indicator_add_eq_one :
    ∀ x y : Bool, indicator x + indicator y = 1 → (x = true ∨ y = true) := by
  decide

theorem indicator_add_eq_zero {x y : Bool} (hx : x = false) (hy : y = false) :
    indicator x + indicator y = 0 := by
  subst hx
  subst hy
  rfl

theorem headTerm_eq_zero : ∀ a x y : Bool, ¬ ((a && (x || y)) = true) →
    (if a = true then indicator x + indicator y else 0) = 0 := by
  decide

theorem one_le_headTerm : ∀ a x y : Bool, (a && (x || y)) = true →
    1 ≤ (if a = true then indicator x + indicator y else 0) := by
  decide

theorem ite_eq_zero_of_false {b : Bool} (hb : b = false) (x : Nat) :
    (if b = true then x else 0) = 0 := by
  subst hb
  rfl

/-- Peel the term at index `n` off a sum over `range N`. -/
theorem sum_split (N n : Nat) (hn : n < N) (F G : Nat → Nat)
    (hFG : ∀ k, k ≠ n → F k = G k) (hG : G n = 0) :
    (Finset.range N).sum F = F n + (Finset.range N).sum G := by
  have hmem : n ∈ Finset.range N := Finset.mem_range.mpr hn
  rw [← Finset.add_sum_erase (Finset.range N) F hmem,
    ← Finset.add_sum_erase (Finset.range N) G hmem, hG, Nat.zero_add]
  congr 1
  exact Finset.sum_congr rfl (fun k hk => hFG k (Finset.ne_of_mem_erase hk))

/-- Resolution of the inputs of `rest` inside `gate g i j rest`. -/
def tailRes {n : Nat} (g : Table) (i j : Fin n) (ρ : Fin n → Res) : Fin (n + 1) → Res :=
  appendValue ρ ((Res.step g (ρ i) (ρ j)).getD (.lit n false))

theorem resAt_cons {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (ρ : Fin n → Res) (k : Nat) :
    (gate g i j rest).resAt ρ k = rest.resAt (tailRes g i j ρ) k := rfl

theorem size_cons {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1)) :
    n + (gate g i j rest).size = n + 1 + rest.size := by
  show n + (rest.size + 1) = n + 1 + rest.size
  omega

theorem gateAt_rest_head {n : Nat} (rest : OpenCircuit (n + 1)) : rest.gateAt n = none :=
  rest.gateAt_of_lt (Nat.lt_succ_self n)

/-! #### Output circuits have no gates -/

theorem isKept_output {n : Nat} (o : Signal n) (ρ : Fin n → Res) (k : Nat) :
    (OpenCircuit.output o : OpenCircuit n).isKept ρ k = false := rfl

theorem isAliased_output {n : Nat} (o : Signal n) (ρ : Fin n → Res) (k : Nat) :
    (OpenCircuit.output o : OpenCircuit n).isAliased ρ k = false := rfl

theorem keptSlotHits_output {n : Nat} (o : Signal n) (ρ : Fin n → Res) (k s : Nat) :
    (OpenCircuit.output o : OpenCircuit n).keptSlotHits ρ k s = 0 := rfl

/-! #### Head gate, later gates, and the absent gate `n` of `rest` -/

theorem isKept_cons_head {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (ρ : Fin n → Res) :
    (gate g i j rest).isKept ρ n = (Res.step g (ρ i) (ρ j)).isNone := by
  simp only [isKept, gateAt_head, resAt_input]

theorem isKept_cons_tail {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (ρ : Fin n → Res) {k : Nat} (hk : k ≠ n) :
    (gate g i j rest).isKept ρ k = rest.isKept (tailRes g i j ρ) k := by
  simp only [isKept, gateAt_tail g i j rest hk, resAt_cons]

theorem isKept_rest_head {n : Nat} (rest : OpenCircuit (n + 1)) (ρ : Fin (n + 1) → Res) :
    rest.isKept ρ n = false := by
  simp only [isKept, gateAt_rest_head]

theorem isAliased_cons_head {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (ρ : Fin n → Res) :
    (gate g i j rest).isAliased ρ n = (Res.step g (ρ i) (ρ j)).isSome := by
  simp only [isAliased, gateAt_head, resAt_input]

theorem isAliased_cons_tail {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (ρ : Fin n → Res) {k : Nat} (hk : k ≠ n) :
    (gate g i j rest).isAliased ρ k = rest.isAliased (tailRes g i j ρ) k := by
  simp only [isAliased, gateAt_tail g i j rest hk, resAt_cons]

theorem isAliased_rest_head {n : Nat} (rest : OpenCircuit (n + 1)) (ρ : Fin (n + 1) → Res) :
    rest.isAliased ρ n = false := by
  simp only [isAliased, gateAt_rest_head]

theorem gatePsiW_cons_head {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1)) :
    (gate g i j rest).gatePsiW n = g.psiW := by
  simp only [gatePsiW, gateAt_head]

theorem gatePsiW_cons_tail {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    {k : Nat} (hk : k ≠ n) : (gate g i j rest).gatePsiW k = rest.gatePsiW k := by
  simp only [gatePsiW, gateAt_tail g i j rest hk]

theorem keptSlotHits_eq {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) (s : Nat) {k : Nat}
    {g : Table} {a b : Nat} (hk : C.gateAt k = some (g, a, b)) :
    C.keptSlotHits ρ k s = if C.isKept ρ k = true then
      indicator ((C.resAt ρ a).hits s) + indicator ((C.resAt ρ b).hits s) else 0 := by
  simp only [keptSlotHits, hk]

theorem keptSlotHits_none {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) (s : Nat) {k : Nat}
    (hk : C.gateAt k = none) : C.keptSlotHits ρ k s = 0 := by
  simp only [keptSlotHits, hk]

theorem keptSlotHits_cons_head {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (ρ : Fin n → Res) (s : Nat) :
    (gate g i j rest).keptSlotHits ρ n s =
      if (Res.step g (ρ i) (ρ j)).isNone = true then
        indicator ((ρ i).hits s) + indicator ((ρ j).hits s) else 0 := by
  rw [keptSlotHits_eq _ ρ s (gateAt_head g i j rest), isKept_cons_head]
  simp only [resAt_input]

theorem keptSlotHits_cons_tail {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (ρ : Fin n → Res) (s : Nat) {k : Nat} (hk : k ≠ n) :
    (gate g i j rest).keptSlotHits ρ k s = rest.keptSlotHits (tailRes g i j ρ) k s := by
  simp only [keptSlotHits, gateAt_tail g i j rest hk, isKept_cons_tail g i j rest ρ hk,
    resAt_cons]

theorem keptSlotHits_rest_head {n : Nat} (rest : OpenCircuit (n + 1)) (ρ : Fin (n + 1) → Res)
    (s : Nat) : rest.keptSlotHits ρ n s = 0 :=
  keptSlotHits_none rest ρ s (gateAt_rest_head rest)

theorem outHits_cons {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (ρ : Fin n → Res) (s : Nat) :
    (gate g i j rest).outHits ρ s = rest.outHits (tailRes g i j ρ) s := by
  simp only [outHits, outWire, resAt_cons]

/-! #### The recursive kept-level quantities: head term + tail -/

theorem keptCount_cons {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (ρ : Fin n → Res) :
    (gate g i j rest).keptCount ρ =
      rest.keptCount (tailRes g i j ρ) + indicator (Res.step g (ρ i) (ρ j)).isNone := by
  simp only [keptCount, tailRes]
  cases Res.step g (ρ i) (ρ j) with
  | none => rfl
  | some r => rfl

theorem aliasedCount_cons {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (ρ : Fin n → Res) :
    (gate g i j rest).aliasedCount ρ =
      rest.aliasedCount (tailRes g i j ρ) + indicator (Res.step g (ρ i) (ρ j)).isSome := by
  simp only [aliasedCount, tailRes]
  cases Res.step g (ρ i) (ρ j) with
  | none => rfl
  | some r => rfl

theorem keptPsiWeight_cons {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (ρ : Fin n → Res) :
    (gate g i j rest).keptPsiWeight ρ =
      (if (Res.step g (ρ i) (ρ j)).isNone = true then g.psiW else 0) +
        rest.keptPsiWeight (tailRes g i j ρ) := by
  simp only [keptPsiWeight, tailRes]
  cases Res.step g (ρ i) (ρ j) with
  | none => rfl
  | some r => exact (Nat.zero_add _).symm

theorem aliasedPsiWeight_cons {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (ρ : Fin n → Res) :
    (gate g i j rest).aliasedPsiWeight ρ =
      (if (Res.step g (ρ i) (ρ j)).isSome = true then g.psiW else 0) +
        rest.aliasedPsiWeight (tailRes g i j ρ) := by
  simp only [aliasedPsiWeight, tailRes]
  cases Res.step g (ρ i) (ρ j) with
  | none => exact (Nat.zero_add _).symm
  | some r => rfl

theorem keptRefs_cons {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (ρ : Fin n → Res) (s : Nat) :
    (gate g i j rest).keptRefs ρ s =
      (if (Res.step g (ρ i) (ρ j)).isNone = true then
        indicator ((ρ i).hits s) + indicator ((ρ j).hits s) else 0) +
        rest.keptRefs (tailRes g i j ρ) s := by
  simp only [keptRefs, tailRes]
  cases Res.step g (ρ i) (ρ j) with
  | none => rfl
  | some r => exact (Nat.zero_add _).symm

theorem keptFirstNL_cons {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (ρ : Fin n → Res) (s : Nat) :
    (gate g i j rest).keptFirstNL ρ s =
      if ((Res.step g (ρ i) (ρ j)).isNone && ((ρ i).hits s || (ρ j).hits s)) = true then
        g.nonlinear
      else rest.keptFirstNL (tailRes g i j ρ) s := by
  simp only [keptFirstNL, tailRes]
  cases Res.step g (ρ i) (ρ j) with
  | none => rfl
  | some r => rfl

/-! #### Resolutions -/

theorem resAt_of_ge {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) {k : Nat}
    (hk : n + C.size ≤ k) : C.resAt ρ k = .const false := by
  induction C with
  | @output n o =>
    have h0 : (OpenCircuit.output o : OpenCircuit n).size = 0 := rfl
    have hk' : ¬ k < n := by omega
    show (if h : k < n then ρ ⟨k, h⟩ else Res.const false) = Res.const false
    exact dite_eq_right hk'
  | @gate n g i j rest ih =>
    rw [resAt_cons]
    apply ih
    have h0 : (gate g i j rest).size = rest.size + 1 := rfl
    omega

/-- Self-contained version of `resAt_hits_cases`. -/
theorem hits_cases {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) {k s : Nat}
    (h : (C.resAt ρ k).hits s = true) :
    (∃ hk : k < n, (ρ ⟨k, hk⟩).hits s = true) ∨
    (∃ g a b, C.gateAt k = some (g, a, b) ∧
      ((C.isKept ρ k = true ∧ s = k) ∨
        ((C.resAt ρ a).hits s = true ∨ (C.resAt ρ b).hits s = true))) := by
  by_cases hkn : k < n
  · left
    have hres : C.resAt ρ k = ρ ⟨k, hkn⟩ := C.resAt_input ρ ⟨k, hkn⟩
    rw [hres] at h
    exact ⟨hkn, h⟩
  · by_cases hks : k < n + C.size
    · right
      obtain ⟨g, a, b, hgk⟩ := C.gateAt_exists (Nat.le_of_not_lt hkn) hks
      refine ⟨g, a, b, hgk, ?_⟩
      rw [C.resAt_gate ρ hgk] at h
      cases hst : Res.step g (C.resAt ρ a) (C.resAt ρ b) with
      | none =>
        rw [hst] at h
        left
        refine ⟨?_, ?_⟩
        · simp only [isKept, hgk, hst, Option.isNone_none]
        · exact ((Res.hits_lit k s false).mp h).symm
      | some r =>
        rw [hst] at h
        right
        exact Res.step_hits g _ _ s r hst h
    · exfalso
      rw [resAt_of_ge C ρ (Nat.le_of_not_lt hks)] at h
      exact Bool.false_ne_true h

/-- A gate reading `s` is a user of `s`. -/
theorem mem_users_of {n : Nat} (C : OpenCircuit n) {s k : Nat} {g : Table} {a b : Nat}
    (hk : C.gateAt k = some (g, a, b)) (h : a = s ∨ b = s) : k ∈ C.users s := by
  unfold users
  rw [Finset.mem_filter, Finset.mem_range]
  refine ⟨(C.gateAt_bounds hk).2.1, ?_⟩
  unfold usesAt
  rw [hk]
  rcases h with h | h
  · simp [h]
  · simp [h]

end FlatKeptAux

theorem keptCount_eq_sum {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) :
    C.keptCount ρ = ∑ k ∈ Finset.range (n + C.size), indicator (C.isKept ρ k) := by
  induction C with
  | output o =>
    refine (Finset.sum_eq_zero (fun k _ => ?_)).symm
    rw [FlatKeptAux.isKept_output, FlatKeptAux.indicator_false]
  | @gate n g i j rest ih =>
    have hFG : ∀ k, k ≠ n → indicator ((gate g i j rest).isKept ρ k) =
        indicator (rest.isKept (FlatKeptAux.tailRes g i j ρ) k) :=
      fun k hk => by rw [FlatKeptAux.isKept_cons_tail g i j rest ρ hk]
    have hG : indicator (rest.isKept (FlatKeptAux.tailRes g i j ρ) n) = 0 := by
      rw [FlatKeptAux.isKept_rest_head, FlatKeptAux.indicator_false]
    rw [FlatKeptAux.size_cons,
      FlatKeptAux.sum_split (n + 1 + rest.size) n (by omega) _ _ hFG hG,
      FlatKeptAux.isKept_cons_head, FlatKeptAux.keptCount_cons, ih]
    omega

theorem aliasedCount_eq_sum {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) :
    C.aliasedCount ρ = ∑ k ∈ Finset.range (n + C.size), indicator (C.isAliased ρ k) := by
  induction C with
  | output o =>
    refine (Finset.sum_eq_zero (fun k _ => ?_)).symm
    rw [FlatKeptAux.isAliased_output, FlatKeptAux.indicator_false]
  | @gate n g i j rest ih =>
    have hFG : ∀ k, k ≠ n → indicator ((gate g i j rest).isAliased ρ k) =
        indicator (rest.isAliased (FlatKeptAux.tailRes g i j ρ) k) :=
      fun k hk => by rw [FlatKeptAux.isAliased_cons_tail g i j rest ρ hk]
    have hG : indicator (rest.isAliased (FlatKeptAux.tailRes g i j ρ) n) = 0 := by
      rw [FlatKeptAux.isAliased_rest_head, FlatKeptAux.indicator_false]
    rw [FlatKeptAux.size_cons,
      FlatKeptAux.sum_split (n + 1 + rest.size) n (by omega) _ _ hFG hG,
      FlatKeptAux.isAliased_cons_head, FlatKeptAux.aliasedCount_cons, ih]
    omega

theorem keptPsiWeight_eq_sum {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) :
    C.keptPsiWeight ρ =
      ∑ k ∈ Finset.range (n + C.size), if C.isKept ρ k = true then C.gatePsiW k else 0 := by
  induction C with
  | output o =>
    refine (Finset.sum_eq_zero (fun k _ => ?_)).symm
    rw [FlatKeptAux.isKept_output]
    rfl
  | @gate n g i j rest ih =>
    have hFG : ∀ k, k ≠ n →
        (if (gate g i j rest).isKept ρ k = true then (gate g i j rest).gatePsiW k else 0) =
        (if rest.isKept (FlatKeptAux.tailRes g i j ρ) k = true then rest.gatePsiW k else 0) :=
      fun k hk => by
        rw [FlatKeptAux.isKept_cons_tail g i j rest ρ hk,
          FlatKeptAux.gatePsiW_cons_tail g i j rest hk]
    have hG :
        (if rest.isKept (FlatKeptAux.tailRes g i j ρ) n = true then rest.gatePsiW n else 0) = 0 :=
      FlatKeptAux.ite_eq_zero_of_false (FlatKeptAux.isKept_rest_head rest _) _
    rw [FlatKeptAux.size_cons,
      FlatKeptAux.sum_split (n + 1 + rest.size) n (by omega) _ _ hFG hG,
      FlatKeptAux.isKept_cons_head, FlatKeptAux.gatePsiW_cons_head,
      FlatKeptAux.keptPsiWeight_cons, ih]

theorem aliasedPsiWeight_eq_sum {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) :
    C.aliasedPsiWeight ρ =
      ∑ k ∈ Finset.range (n + C.size), if C.isAliased ρ k = true then C.gatePsiW k else 0 := by
  induction C with
  | output o =>
    refine (Finset.sum_eq_zero (fun k _ => ?_)).symm
    rw [FlatKeptAux.isAliased_output]
    rfl
  | @gate n g i j rest ih =>
    have hFG : ∀ k, k ≠ n →
        (if (gate g i j rest).isAliased ρ k = true then (gate g i j rest).gatePsiW k else 0) =
        (if rest.isAliased (FlatKeptAux.tailRes g i j ρ) k = true then rest.gatePsiW k else 0) :=
      fun k hk => by
        rw [FlatKeptAux.isAliased_cons_tail g i j rest ρ hk,
          FlatKeptAux.gatePsiW_cons_tail g i j rest hk]
    have hG : (if rest.isAliased (FlatKeptAux.tailRes g i j ρ) n = true
        then rest.gatePsiW n else 0) = 0 :=
      FlatKeptAux.ite_eq_zero_of_false (FlatKeptAux.isAliased_rest_head rest _) _
    rw [FlatKeptAux.size_cons,
      FlatKeptAux.sum_split (n + 1 + rest.size) n (by omega) _ _ hFG hG,
      FlatKeptAux.isAliased_cons_head, FlatKeptAux.gatePsiW_cons_head,
      FlatKeptAux.aliasedPsiWeight_cons, ih]

theorem keptRefs_eq_sum {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) (s : Nat) :
    C.keptRefs ρ s = (∑ k ∈ Finset.range (n + C.size), C.keptSlotHits ρ k s) + C.outHits ρ s := by
  induction C with
  | output o =>
    rw [Finset.sum_eq_zero (fun k _ => FlatKeptAux.keptSlotHits_output o ρ k s), Nat.zero_add]
    cases o with
    | constant c => rfl
    | wire w neg => simp only [keptRefs, outHits, outWire, resAt_input]
  | @gate n g i j rest ih =>
    have hFG : ∀ k, k ≠ n → (gate g i j rest).keptSlotHits ρ k s =
        rest.keptSlotHits (FlatKeptAux.tailRes g i j ρ) k s :=
      fun k hk => FlatKeptAux.keptSlotHits_cons_tail g i j rest ρ s hk
    rw [FlatKeptAux.size_cons,
      FlatKeptAux.sum_split (n + 1 + rest.size) n (by omega) _ _ hFG
        (FlatKeptAux.keptSlotHits_rest_head rest _ s),
      FlatKeptAux.keptSlotHits_cons_head, FlatKeptAux.outHits_cons, FlatKeptAux.keptRefs_cons, ih]
    omega

namespace FlatKeptAux

/-- A kept gate reading `s` gives `s` a reference after restriction. -/
theorem one_le_keptRefs {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) (s : Nat) {k : Nat}
    {g : Table} {a b : Nat} (hk : C.gateAt k = some (g, a, b)) (hkept : C.isKept ρ k = true)
    (hhit : (C.resAt ρ a).hits s = true ∨ (C.resAt ρ b).hits s = true) :
    1 ≤ C.keptRefs ρ s := by
  have hsum := C.keptRefs_eq_sum ρ s
  have hmem : k ∈ Finset.range (n + C.size) := Finset.mem_range.mpr (C.gateAt_bounds hk).2.1
  have hslot : 1 ≤ C.keptSlotHits ρ k s := by
    rw [keptSlotHits_eq C ρ s hk, ite_eq_left hkept]
    exact indicator_add_pos _ _ hhit
  have hle : C.keptSlotHits ρ k s ≤ ∑ k ∈ Finset.range (n + C.size), C.keptSlotHits ρ k s :=
    Finset.single_le_sum (f := fun k => C.keptSlotHits ρ k s) (fun _ _ => Nat.zero_le _) hmem
  omega

/-- The kept reader witnessed by `keptFirstNL`. -/
theorem firstNL_reader {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) (s : Nat)
    (h : C.keptFirstNL ρ s = true) :
    ∃ k g a b, C.gateAt k = some (g, a, b) ∧ C.isKept ρ k = true ∧
      ((C.resAt ρ a).hits s = true ∨ (C.resAt ρ b).hits s = true) ∧ g.nonlinear = true := by
  induction C with
  | output o => simp [keptFirstNL] at h
  | @gate n g i j rest ih =>
    rw [keptFirstNL_cons] at h
    by_cases hc : ((Res.step g (ρ i) (ρ j)).isNone && ((ρ i).hits s || (ρ j).hits s)) = true
    · rw [ite_eq_left hc] at h
      rw [Bool.and_eq_true, Bool.or_eq_true] at hc
      refine ⟨n, g, i.val, j.val, gateAt_head g i j rest, ?_, ?_, h⟩
      · rw [isKept_cons_head]
        exact hc.1
      · simp only [resAt_input]
        exact hc.2
    · rw [ite_eq_right hc] at h
      obtain ⟨k, g', a, b, hk, hkept, hhit, hnl⟩ := ih (tailRes g i j ρ) h
      have hkn : k ≠ n := by
        have := (rest.gateAt_bounds hk).1
        omega
      refine ⟨k, g', a, b, ?_, ?_, hhit, hnl⟩
      · rw [gateAt_tail g i j rest hkn]
        exact hk
      · rw [isKept_cons_tail g i j rest ρ hkn]
        exact hkept

/-- With a unique kept reference, a kept nonlinear reader makes `keptFirstNL` true. -/
theorem firstNL_of_reader {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) (s : Nat)
    (h1 : C.keptRefs ρ s = 1)
    (h2 : ∃ k g a b, C.gateAt k = some (g, a, b) ∧ C.isKept ρ k = true ∧
      ((C.resAt ρ a).hits s = true ∨ (C.resAt ρ b).hits s = true) ∧ g.nonlinear = true) :
    C.keptFirstNL ρ s = true := by
  induction C with
  | output o =>
    obtain ⟨k, g, a, b, hk, -⟩ := h2
    simp [gateAt] at hk
  | @gate n g i j rest ih =>
    obtain ⟨k, g', a, b, hk, hkept, hhit, hnl⟩ := h2
    rw [keptRefs_cons] at h1
    rw [keptFirstNL_cons]
    by_cases hc : ((Res.step g (ρ i) (ρ j)).isNone && ((ρ i).hits s || (ρ j).hits s)) = true
    · rw [ite_eq_left hc]
      by_cases hkn : k = n
      · rw [hkn, gateAt_head] at hk
        simp only [Option.some.injEq, Prod.mk.injEq] at hk
        rw [hk.1]
        exact hnl
      · exfalso
        have hk' : rest.gateAt k = some (g', a, b) := by
          rw [← gateAt_tail g i j rest hkn]
          exact hk
        have hkept' : rest.isKept (tailRes g i j ρ) k = true := by
          rw [← isKept_cons_tail g i j rest ρ hkn]
          exact hkept
        have hge := one_le_keptRefs rest (tailRes g i j ρ) s hk' hkept' hhit
        have hhead := one_le_headTerm _ _ _ hc
        omega
    · rw [ite_eq_right hc]
      have hkn : k ≠ n := by
        intro hkn
        rw [hkn, gateAt_head] at hk
        simp only [Option.some.injEq, Prod.mk.injEq] at hk
        obtain ⟨-, ha, hb⟩ := hk
        rw [hkn, isKept_cons_head] at hkept
        rw [← ha, ← hb] at hhit
        simp only [resAt_input] at hhit
        apply hc
        rw [Bool.and_eq_true, Bool.or_eq_true]
        exact ⟨hkept, hhit⟩
      have hk' : rest.gateAt k = some (g', a, b) := by
        rw [← gateAt_tail g i j rest hkn]
        exact hk
      have hkept' : rest.isKept (tailRes g i j ρ) k = true := by
        rw [← isKept_cons_tail g i j rest ρ hkn]
        exact hkept
      have h0 := headTerm_eq_zero _ _ _ hc
      apply ih (tailRes g i j ρ)
      · omega
      · exact ⟨k, g', a, b, hk', hkept', hhit, hnl⟩

end FlatKeptAux

/-- After restriction, `s` is a D-variable iff it has exactly one reference and some kept
nonlinear gate reads it. -/
theorem keptIsD_iff {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) (s : Nat) :
    C.keptIsD ρ s = true ↔ C.keptRefs ρ s = 1 ∧
      ∃ k g a b, C.gateAt k = some (g, a, b) ∧ C.isKept ρ k = true ∧
        ((C.resAt ρ a).hits s = true ∨ (C.resAt ρ b).hits s = true) ∧ g.nonlinear = true := by
  unfold keptIsD
  rw [Bool.and_eq_true, decide_eq_true_iff]
  constructor
  · rintro ⟨h1, h2⟩
    exact ⟨h1, FlatKeptAux.firstNL_reader C ρ s h2⟩
  · rintro ⟨h1, h2⟩
    exact ⟨h1, FlatKeptAux.firstNL_of_reader C ρ s h1 h2⟩

/-- Gain criterion: exactly one operand slot of one kept nonlinear gate resolves to `z`,
no other kept slot and not the output does. -/
theorem keptIsD_of_unique_slot {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) (z : Nat)
    (W : Nat) (g : Table) (a b : Nat) (hW : C.gateAt W = some (g, a, b))
    (hkept : C.isKept ρ W = true) (hnl : g.nonlinear = true)
    (hslot : indicator ((C.resAt ρ a).hits z) + indicator ((C.resAt ρ b).hits z) = 1)
    (hothers : ∀ k g' a' b', k ≠ W → C.gateAt k = some (g', a', b') → C.isKept ρ k = true →
        (C.resAt ρ a').hits z = false ∧ (C.resAt ρ b').hits z = false)
    (hout : ∀ k neg, C.outWire = some (k, neg) → (C.resAt ρ k).hits z = false) :
    C.keptIsD ρ z = true := by
  rw [keptIsD_iff]
  refine ⟨?_, W, g, a, b, hW, hkept, FlatKeptAux.or_of_indicator_add_eq_one _ _ hslot, hnl⟩
  have hW' : W ∈ Finset.range (n + C.size) := Finset.mem_range.mpr (C.gateAt_bounds hW).2.1
  have hsum : ∑ k ∈ Finset.range (n + C.size), C.keptSlotHits ρ k z = 1 := by
    rw [Finset.sum_eq_single W, FlatKeptAux.keptSlotHits_eq C ρ z hW, ite_eq_left hkept, hslot]
    · intro k _ hkW
      cases hk : C.gateAt k with
      | none => exact FlatKeptAux.keptSlotHits_none C ρ z hk
      | some p =>
        obtain ⟨g', a', b'⟩ := p
        rw [FlatKeptAux.keptSlotHits_eq C ρ z hk]
        by_cases hkk : C.isKept ρ k = true
        · rw [ite_eq_left hkk]
          obtain ⟨h1, h2⟩ := hothers k g' a' b' hkW hk hkk
          exact FlatKeptAux.indicator_add_eq_zero h1 h2
        · rw [ite_eq_right hkk]
    · intro hn
      exact absurd hW' hn
  have hout0 : C.outHits ρ z = 0 := by
    unfold outHits
    cases ho : C.outWire with
    | none => rfl
    | some p =>
      obtain ⟨k, neg⟩ := p
      simp only [hout k neg ho, FlatKeptAux.indicator_false]
  have := C.keptRefs_eq_sum ρ z
  omega

/-- Passers below `K`: if every gate `k < K` outside `A` that reads `z` or a member of `A` does
not resolve to a literal of `z`, then every gate `k < K` resolving to a literal of `z` lies in
`A`.  (Strong induction on `k`: an eliminated gate resolving to `z` has an operand resolving to
`z`, which is `z` itself or an earlier such gate; a kept gate resolves to itself, `≥ n > z`.)
Use `K = n + C.size` for all gates. -/
theorem passers_subset {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) (z : Nat) (hzn : z < n)
    (hz : ∀ w : Fin n, (ρ w).hits z = true → w.val = z) (A : Finset Nat) (K : Nat)
    (hA : ∀ k g a b, k < K → C.gateAt k = some (g, a, b) → k ∉ A →
        (a = z ∨ a ∈ A ∨ b = z ∨ b ∈ A) → (C.resAt ρ k).hits z = false) :
    ∀ k, n ≤ k → k < K → (C.resAt ρ k).hits z = true → k ∈ A := by
  intro k
  induction k using Nat.strong_induction_on with
  | h k ih =>
    intro hnk hkK hhit
    rcases FlatKeptAux.hits_cases C ρ hhit with ⟨hkn, -⟩ | ⟨g, a, b, hk, hcase⟩
    · omega
    · rcases hcase with ⟨-, hzk⟩ | hab
      · omega
      · have hbounds := C.gateAt_bounds hk
        have key : ∀ o, o < k → (C.resAt ρ o).hits z = true → o = z ∨ o ∈ A := by
          intro o hok ho
          by_cases hon : o < n
          · left
            have hres : C.resAt ρ o = ρ ⟨o, hon⟩ := C.resAt_input ρ ⟨o, hon⟩
            rw [hres] at ho
            exact hz ⟨o, hon⟩ ho
          · right
            exact ih o hok (Nat.le_of_not_lt hon) (by omega) ho
        by_cases hkA : k ∈ A
        · exact hkA
        · exfalso
          have hpre : a = z ∨ a ∈ A ∨ b = z ∨ b ∈ A := by
            rcases hab with ha | hb
            · rcases key a hbounds.2.2.1 ha with h | h
              · exact Or.inl h
              · exact Or.inr (Or.inl h)
            · rcases key b hbounds.2.2.2 hb with h | h
              · exact Or.inr (Or.inr (Or.inl h))
              · exact Or.inr (Or.inr (Or.inr h))
          have hfalse := hA k g a b hkK hk hkA hpre
          rw [hfalse] at hhit
          exact Bool.false_ne_true hhit

/-- Disconnection: if every direct successor of the free input `z` resolves to a constant and
the output is not `z`, nothing in the restricted circuit reads `z`. -/
theorem keptRefs_eq_zero {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) (z : Nat) (hzn : z < n)
    (hz : ∀ w : Fin n, (ρ w).hits z = true → w.val = z)
    (hu : ∀ k ∈ C.users z, (C.resAt ρ k).isConst = true)
    (hout : ∀ k neg, C.outWire = some (k, neg) → k ≠ z) :
    C.keptRefs ρ z = 0 := by
  -- no gate passes `z`
  have hpass := C.passers_subset ρ z hzn hz ∅ (n + C.size) (by
    intro k _g a b _ hk _ hab
    have hmem : k ∈ C.users z := by
      apply FlatKeptAux.mem_users_of C hk
      rcases hab with h | h | h | h
      · exact Or.inl h
      · exact absurd h (Finset.notMem_empty a)
      · exact Or.inr h
      · exact absurd h (Finset.notMem_empty b)
    have hc := hu k hmem
    cases hr : C.resAt ρ k with
    | const c => rfl
    | lit t neg =>
      rw [hr] at hc
      exact absurd hc Bool.false_ne_true)
  -- hence only `z` itself resolves to a literal of `z`
  have honly : ∀ k, (C.resAt ρ k).hits z = true → k = z := by
    intro k hk
    rcases FlatKeptAux.hits_cases C ρ hk with ⟨hkn, hρk⟩ | ⟨g, a, b, hgk, -⟩
    · exact hz ⟨k, hkn⟩ hρk
    · have hb := C.gateAt_bounds hgk
      exact absurd (hpass k hb.1 hb.2.1 hk) (Finset.notMem_empty k)
  have hsum : ∑ k ∈ Finset.range (n + C.size), C.keptSlotHits ρ k z = 0 := by
    apply Finset.sum_eq_zero
    intro k _
    cases hk : C.gateAt k with
    | none => exact FlatKeptAux.keptSlotHits_none C ρ z hk
    | some p =>
      obtain ⟨g, a, b⟩ := p
      rw [FlatKeptAux.keptSlotHits_eq C ρ z hk]
      by_cases hkept : C.isKept ρ k = true
      · rw [ite_eq_left hkept]
        have hnc : (C.resAt ρ k).isConst = false := by
          rw [C.resAt_kept ρ hkept]
          rfl
        have hfa : ∀ o, (o = a ∨ o = b) → (C.resAt ρ o).hits z = false := by
          intro o ho
          cases hh : (C.resAt ρ o).hits z with
          | false => rfl
          | true =>
            exfalso
            have hoz := honly o hh
            have hmem : k ∈ C.users z := by
              apply FlatKeptAux.mem_users_of C hk
              rcases ho with ho | ho
              · left
                rw [← ho]
                exact hoz
              · right
                rw [← ho]
                exact hoz
            rw [hu k hmem] at hnc
            cases hnc
        exact FlatKeptAux.indicator_add_eq_zero (hfa a (Or.inl rfl)) (hfa b (Or.inr rfl))
      · rw [ite_eq_right hkept]
  have hout0 : C.outHits ρ z = 0 := by
    unfold outHits
    cases ho : C.outWire with
    | none => rfl
    | some p =>
      obtain ⟨k, neg⟩ := p
      have hf : (C.resAt ρ k).hits z = false := by
        cases hh : (C.resAt ρ k).hits z with
        | false => rfl
        | true => exact absurd (honly k hh) (hout k neg ho)
      simp only [hf, FlatKeptAux.indicator_false]
  have := C.keptRefs_eq_sum ρ z
  omega

theorem fixRes_hits {n : Nat} (P c : Fin n → Bool) (z : Nat) (w : Fin n)
    (h : (fixRes P c w).hits z = true) : w.val = z := by
  unfold fixRes at h
  split at h
  · simp [Res.hits] at h
  · simpa [Res.hits] using h

theorem singleRes_hits {n : Nat} (x : Fin n) (b : Bool) (z : Nat) (w : Fin n)
    (h : (singleRes x b w).hits z = true) : w.val = z :=
  fixRes_hits _ _ z w h

theorem resAt_single_input {n : Nat} (C : OpenCircuit n) (x : Fin n) (b : Bool) (z : Fin n) :
    C.resAt (singleRes x b) z.val = if z = x then .const b else .lit z.val false := by
  rw [C.resAt_input]
  by_cases h : z = x <;> simp [singleRes, fixRes, h]

end OpenCircuit
end SatLowerBound
