import Credit.TwoLevel.RobustContext

/-! The blockwise potential budget and its behavior under fixing inputs. -/
namespace SatLowerBound
namespace RobustTree

/-- Number of fourteen-unit elimination steps remaining across all blocks. -/
def surplus {n : Nat} (k : Nat) (ρ : Fin n → Option Bool) : RobustTree n → Nat
  | .leaf _ S => (freeOn S ρ).card - (k+1)
  | .branch _ a b => a.surplus k ρ + b.surplus k ρ

/-- A partial fix outside a tree's support leaves its valid blocks and their
surplus unchanged. -/
theorem valid_partialFix_outside {n k : Nat} (T : RobustTree n) (ρ : Fin n → Option Bool)
    (x : Fin n) (b : Bool) (hx : x ∉ T.support) (h : T.Valid k ρ) :
    T.Valid k (partialFix ρ x b) := by
  induction T with
  | leaf f S =>
    have hxS : x ∉ S := hx
    have hxF : x ∉ freeOn S ρ := fun hm => hxS (freeOn_subset S ρ hm)
    have hf : freeOn S (partialFix ρ x b) = freeOn S ρ := by
      rw [freeOn_partialFix,Finset.erase_eq_of_notMem hxF]
    exact ⟨h.1,by rw [hf]; exact h.2⟩
  | branch p a d iha ihd =>
    have ha : x ∉ a.support := fun hh => hx (Finset.mem_union_left _ hh)
    have hb : x ∉ d.support := fun hh => hx (Finset.mem_union_right _ hh)
    exact ⟨iha ha h.1,ihd hb h.2.1,h.2.2⟩

theorem surplus_partialFix_outside {n k : Nat} (T : RobustTree n) (ρ : Fin n → Option Bool)
    (x : Fin n) (b : Bool) (hx : x ∉ T.support) :
    T.surplus k (partialFix ρ x b) = T.surplus k ρ := by
  induction T with
  | leaf f S =>
    have hxF : x ∉ freeOn S ρ := fun hm => hx (freeOn_subset S ρ hm)
    simp only [surplus,freeOn_partialFix,Finset.erase_eq_of_notMem hxF]
  | branch p a d iha ihd =>
    have ha : x ∉ a.support := fun hh => hx (Finset.mem_union_left _ hh)
    have hb : x ∉ d.support := fun hh => hx (Finset.mem_union_right _ hh)
    simp only [surplus,iha ha,ihd hb]

/-- For valid blocks, surplus is exactly total free inputs less `k+1`
per block, with no truncation loss. -/
theorem surplus_add_retired {n k : Nat} (T : RobustTree n) (ρ : Fin n → Option Bool)
    (h : T.Valid k ρ) :
    T.surplus k ρ + (k+1) * T.blocks = (freeOn T.support ρ).card := by
  induction T with
  | leaf f S =>
    change (freeOn S ρ).card - (k+1) + (k+1) * 1 = (freeOn S ρ).card
    have hh : k+2 ≤ (freeOn S ρ).card := h.2
    omega
  | branch p a b iha ihb =>
    have ha := iha h.1
    have hb := ihb h.2.1
    have hd : Disjoint (freeOn a.support ρ) (freeOn b.support ρ) := by
      apply Finset.disjoint_left.mpr
      intro z hz₁ hz₂
      exact Finset.disjoint_left.mp h.2.2 (freeOn_subset a.support ρ hz₁)
        (freeOn_subset b.support ρ hz₂)
    change a.surplus k ρ + b.surplus k ρ + (k+1) * (a.blocks + b.blocks) =
      (freeOn (a.support ∪ b.support) ρ).card
    rw [freeOn_union,Finset.card_union_of_disjoint hd,Nat.mul_add]
    omega

/-- Every valid composition has enough remaining inputs for elimination. -/
theorem valid_free_card_ge {n k : Nat} (T : RobustTree n) (ρ : Fin n → Option Bool)
    (h : T.Valid k ρ) : k+2 ≤ (freeOn T.support ρ).card := by
  induction T with
  | leaf f S => exact h.2
  | branch p a b iha ihb =>
    have ha := iha h.1
    have hsub : freeOn a.support ρ ⊆ freeOn (a.support ∪ b.support) ρ := by
      intro z hz
      obtain ⟨hzS,hzρ⟩ := Finset.mem_filter.mp hz
      exact Finset.mem_filter.mpr ⟨Finset.mem_union_left _ hzS,hzρ⟩
    have hh := Finset.card_le_card hsub
    change k+2 ≤ (freeOn (a.support ∪ b.support) ρ).card
    omega

end RobustTree
namespace RobustContext

def surplus {n : Nat} (k : Nat) (ρ : Fin n → Option Bool) : RobustContext n → Nat
  | .hole => 0
  | .left _ K R => K.surplus k ρ + R.surplus k ρ
  | .right _ L K => L.surplus k ρ + K.surplus k ρ

theorem plug_surplus {n k : Nat} (ρ : Fin n → Option Bool) (K : RobustContext n) (T : RobustTree n) :
    (K.plug T).surplus k ρ = T.surplus k ρ + K.surplus k ρ := by
  induction K with
  | hole => simp [plug,surplus]
  | left p K R ih => simp only [plug,surplus,RobustTree.surplus,ih]; omega
  | right p L K ih => simp only [plug,surplus,RobustTree.surplus,ih]; omega

/-- Fixing a bit of the selected block leaves every sibling's state unchanged. -/
theorem fits_partialFix {n k : Nat} (ρ : Fin n → Option Bool) (K : RobustContext n)
    (S : Finset (Fin n)) (h : K.Fits k ρ S) (x : Fin n) (hx : x ∈ S) (b : Bool) :
    K.Fits k (partialFix ρ x b) S := by
  induction K with
  | hole => trivial
  | left p K R ih =>
    have hxR : x ∉ R.support := fun hh =>
      Finset.disjoint_left.mp h.2.2 (Finset.mem_union_left _ hx) hh
    exact ⟨ih h.1,R.valid_partialFix_outside ρ x b hxR h.2.1,h.2.2⟩
  | right p L K ih =>
    have hxL : x ∉ L.support := fun hh =>
      Finset.disjoint_left.mp h.2.2 hh (Finset.mem_union_left _ hx)
    exact ⟨L.valid_partialFix_outside ρ x b hxL h.1,ih h.2.1,h.2.2⟩

theorem surplus_partialFix_inside {n k : Nat} (ρ : Fin n → Option Bool) (K : RobustContext n)
    (S : Finset (Fin n)) (h : K.Fits k ρ S) (x : Fin n) (hx : x ∈ S) (b : Bool) :
    K.surplus k (partialFix ρ x b) = K.surplus k ρ := by
  induction K with
  | hole => rfl
  | left p K R ih =>
    have hxR : x ∉ R.support := fun hh =>
      Finset.disjoint_left.mp h.2.2 (Finset.mem_union_left _ hx) hh
    simp only [surplus,ih h.1,R.surplus_partialFix_outside ρ x b hxR]
  | right p L K ih =>
    have hxL : x ∉ L.support := fun hh =>
      Finset.disjoint_left.mp h.2.2 hh (Finset.mem_union_left _ hx)
    simp only [surplus,ih h.2.1,L.surplus_partialFix_outside ρ x b hxL]

/-- Replacing a selected leaf by another valid leaf with the same support
preserves the validity of the whole composition. -/
theorem plug_valid {n k : Nat} (ρ : Fin n → Option Bool) (K : RobustContext n)
    (S : Finset (Fin n)) (h : K.Fits k ρ S) (T : RobustTree n)
    (hT : T.Valid k ρ) (hS : T.support = S) : (K.plug T).Valid k ρ := by
  induction K with
  | hole => exact hT
  | left p K R ih =>
    refine ⟨ih h.1,h.2.1,?_⟩
    simpa only [plug_support,hS] using h.2.2
  | right p L K ih =>
    refine ⟨h.1,ih h.2.1,?_⟩
    simpa only [plug_support,hS] using h.2.2

/-- A valid selected block contributes exactly one less unit of surplus
when one of its free bits is fixed. -/
theorem plug_surplus_partialFix {n k : Nat} (ρ : Fin n → Option Bool) (K : RobustContext n)
    (S : Finset (Fin n)) (f : (Fin n → Bool) → Bool) (h : K.Fits k ρ S)
    (x : Fin n) (hx : x ∈ freeOn S ρ) (b : Bool) (hsize : k+2 ≤ (freeOn S ρ).card) :
    (K.plug (.leaf f S)).surplus k (partialFix ρ x b) + 1 =
      (K.plug (.leaf f S)).surplus k ρ := by
  have hxS := (Finset.mem_filter.mp hx).1
  have hc := Finset.card_erase_add_one hx
  have hs := K.surplus_partialFix_inside ρ S h x hxS b
  rw [K.plug_surplus (partialFix ρ x b),K.plug_surplus ρ]
  simp only [RobustTree.surplus,freeOn_partialFix,hs]
  omega

theorem retire_surplus {n k : Nat} (ρ : Fin n → Option Bool) (K : RobustContext n)
    (R : RobustTree n) (hr : K.retire = some R) : R.surplus k ρ = K.surplus k ρ := by
  induction K generalizing R with
  | hole => contradiction
  | left p K U ih =>
    cases hk : K.retire with
    | none =>
      have he := K.retire_none.mp hk
      subst K
      simp only [retire,Option.some.injEq] at hr
      subst R
      simp [surplus]
    | some V =>
      simp only [retire,hk,Option.some.injEq] at hr
      subst R
      simp only [surplus,RobustTree.surplus,ih V hk]
  | right p U K ih =>
    cases hk : K.retire with
    | none =>
      have he := K.retire_none.mp hk
      subst K
      simp only [retire,Option.some.injEq] at hr
      subst R
      simp [surplus]
    | some V =>
      simp only [retire,hk,Option.some.injEq] at hr
      subst R
      simp only [surplus,RobustTree.surplus,ih V hk]

end RobustContext
end SatLowerBound
