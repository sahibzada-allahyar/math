import Credit.TwoLevel.BalandraudProductRatio

namespace SatLowerBound

/-- Cancellation of the common odd-column product gives the integer form
of Balandraud's dimension recurrence. -/
theorem balandraudDet_normalized_recurrence {n : Nat} (g : Fin n) :
    ((n + g.val : Nat) : ℤ) * ((n + g.val + 1 : Nat) : ℤ) *
      balandraudDet (n + 1) (g.val + 1) =
    (2 : ℤ)^n * (n : ℤ) *
      (((n + g.val + 1 : Nat) : ℤ) * balandraudDet n g.val +
       ((n + g.val : Nat) : ℤ) * balandraudDet n (g.val + 1)) := by
  have hp : (∏ i : Fin (n + 1), ((n + i.val : Nat) : ℤ)) =
      (n : ℤ) * (2 : ℤ)^n * (∏ j : Fin n, ((2 * j.val + 1 : Nat) : ℤ)) := by
    rw [Fin.prod_univ_succ]
    simp only [Fin.val_zero, Nat.add_zero, Fin.val_succ]
    simp only [← Nat.add_assoc]
    rw [balandraud_product_ratio]
    ring
  have h := balandraudDet_full_product_recurrence g
  rw [hp] at h
  apply mul_left_cancel₀ (balandraud_odd_product_ne_zero n)
  linear_combination h

/-- The last-cut boundary also has an unconditional closed evaluation. -/
theorem balandraudDet_last_closed (n : Nat) :
    balandraudDet (n + 1) (n + 1) = (2 : ℤ) ^ Nat.choose n 2 := by
  rw [balandraudDet_last_dimension_recurrence, balandraudDet_zero_closed]

/-- Boundary values and the interior recurrence uniquely determine all
these determinants. A candidate closed formula can therefore be checked by
algebra, independently of the matrix operations. -/
theorem balandraudDet_eq_of_recurrence (F : Nat → Nat → ℤ)
    (hzero : ∀ n, F n 0 = (2 : ℤ) ^ Nat.choose n 2)
    (hlast : ∀ n, F (n + 1) (n + 1) = (2 : ℤ) ^ Nat.choose n 2)
    (hstep : ∀ n (g : Fin n),
      ((n + g.val : Nat) : ℤ) * ((n + g.val + 1 : Nat) : ℤ) * F (n + 1) (g.val + 1) =
      (2 : ℤ)^n * (n : ℤ) *
        (((n + g.val + 1 : Nat) : ℤ) * F n g.val +
         ((n + g.val : Nat) : ℤ) * F n (g.val + 1))) :
    ∀ n k, k ≤ n → balandraudDet n k = F n k := by
  intro n
  induction n with
  | zero =>
    intro k hk
    have : k = 0 := by omega
    subst k
    rw [balandraudDet_zero_closed, hzero]
  | succ n ih =>
    intro k hk
    by_cases hz : k = 0
    · subst k
      rw [balandraudDet_zero_closed, hzero]
    by_cases hl : k = n + 1
    · subst k
      rw [balandraudDet_last_closed, hlast]
    obtain ⟨s, rfl⟩ := Nat.exists_eq_succ_of_ne_zero hz
    have hs : s < n := by omega
    let g : Fin n := ⟨s, hs⟩
    have hd := balandraudDet_normalized_recurrence g
    have hf := hstep n g
    rw [ih g.val (Nat.le_of_lt g.isLt), ih (g.val + 1) (by omega)] at hd
    have hn : 0 < n := by omega
    have hc : ((n + g.val : Nat) : ℤ) * ((n + g.val + 1 : Nat) : ℤ) ≠ 0 := by
      apply mul_ne_zero <;> positivity
    exact mul_left_cancel₀ hc (hd.trans hf.symm)

end SatLowerBound
