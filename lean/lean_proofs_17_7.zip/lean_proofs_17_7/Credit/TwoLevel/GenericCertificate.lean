import Credit.TwoLevel.RobustDegree
import Credit.TwoLevel.GenericSatTransfer

/-! Connect the verified composition bound to the actual 3-SAT circuit transfer. -/
namespace SatLowerBound

/-- The explicit finite 3-SAT bound, conditional only on supplying a
full-degree robust tree representing the sparse target. -/
theorem generic_sat_tree_certificate (w r k : Nat) (hw : 2 ≤ w) (hr : r < w) (hr0 : 0 < r)
    (hk : 2 ≤ k) {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g)
    (hfit : B.count ≤ variableCount w) (hM : 0 < genericRemainingClauses w B)
    (hblock : Nonconstant g) (T : RobustTree (genericFreeBits w B))
    (hT : T.Valid k (fun _ => none)) (hs : T.support = Finset.univ) (hfull : T.FullLeaves)
    (hblocks : T.blocks = 3 * genericRemainingClauses w B)
    (htarget : ∀ v, T.eval v = genericSparseFunction w B v)
    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    7 * (inputBits w : Int) + 10 * (genericFreeBits w B : Int) -
      42 * ((k : Int)+1) * genericRemainingClauses w B - 3 ≤ 7 * (C.size : Int) := by
  obtain ⟨D,hDe,htransfer⟩ := generic_sat_sparse_transfer w r hw hr hr0 B hfit hM hblock C hc
  have hbound := T.full_leaves_size hk hT hs hfull D (fun v => (hDe v).trans (htarget v).symm)
  rw [hblocks] at hbound
  have hle : genericFreeBits w B ≤ inputBits w := by
    have hh := Fintype.card_le_of_injective (genericFreeEmbedding w r hr hr0 B)
      (genericFreeEmbedding_injective w r hr hr0 B)
    simpa only [Fintype.card_fin] using hh
  have ht : (D.size : Int) + ((inputBits w : Int) - genericFreeBits w B) ≤ C.size := by
    exact_mod_cast htransfer
  have hL : (genericFreeBits w B : Int) = 3 * (genericRemainingClauses w B : Int) * r := by
    simp only [genericFreeBits,Nat.cast_mul,Nat.cast_ofNat]
    ring
  simp only [genericFreeBits,Nat.cast_mul,Nat.cast_ofNat] at ht
  push_cast at hbound
  ring_nf at hbound ht hL ⊢
  omega

end SatLowerBound
