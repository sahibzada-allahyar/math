import Credit.TwoLevel.WeightedSubsetSums
import Credit.TwoLevel.CoordinateDegree
import Mathlib.RingTheory.RootsOfUnity.PrimitiveRoots
import Mathlib.RingTheory.RootsOfUnity.AlgebraicallyClosed
import Mathlib.Algebra.BigOperators.Ring.Finset

/-! Characteristic-two product argument for the weighted block's degree. -/
namespace SatLowerBound

/-- The ordinary integer weighted sum before reduction modulo `p`. -/
def weightedNatSum {n : Nat} (v : Fin n → Bool) : Nat :=
  ∑ i : Fin n, if v i then i.val + 1 else 0

theorem weightedSum_eq_natCast {n p : Nat} (v : Fin n → Bool) :
    weightedSum (p := p) v = (weightedNatSum v : ZMod p) := by
  simp [weightedSum,weightedNatSum, Nat.cast_sum, Nat.cast_ite]

/-- The product in Proposition 5.10 expands to the weighted truth-table sum. -/
theorem weighted_product_expansion {R : Type*} [CommRing R] (n : Nat) (z : R) :
    (∏ i : Fin n, (1 + z ^ (i.val + 1))) = ∑ v : Fin n → Bool, z ^ weightedNatSum v := by
  classical
  have h := Fintype.prod_sum (R := R) (ι := Fin n)
    (κ := fun _ => Bool) (fun i b => if b then z ^ (i.val + 1) else 1)
  simp only [Fintype.sum_bool, Bool.false_eq_true, ↓reduceIte] at h
  have h' : (∏ i : Fin n, (1 + z ^ (i.val + 1))) =
      ∑ v : Fin n → Bool, ∏ i : Fin n, if v i then z ^ (i.val + 1) else 1 := by
    convert h using 1
    apply Finset.prod_congr rfl
    intro i _
    ring
  rw [h']
  apply Finset.sum_congr rfl
  intro v _
  rw [weightedNatSum, ← Finset.prod_pow_eq_pow_sum]
  apply Finset.prod_congr rfl
  intro i _
  cases v i <;> simp

/-- The top coefficients of the residue blocks are the characteristic-two
parities of their truth tables, and their weighted sum groups the same cube
assignments by residue. -/
theorem weighted_top_sum {R : Type*} [CommRing R] [CharP R 2]
    (n p : Nat) [NeZero p] (z : R) (hz : z ^ p = 1) :
    (∑ t : ZMod p, fieldBit (R := R) (BPoly.ofFunction n (weightedModularBlock n p t)).topCoefficient * z ^ t.val) =
      ∑ v : Fin n → Bool, z ^ weightedNatSum v := by
  classical
  simp_rw [topCoefficient_field_sum, lastCubeSum_eq_sum, Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro v _
  have hpow : z ^ weightedNatSum v = z ^ (weightedSum (p := p) v).val := by
    rw [weightedSum_eq_natCast, ZMod.val_natCast]
    exact pow_eq_pow_mod _ hz
  rw [hpow]
  simp [weightedModularBlock,fieldBit]

/-- If a field of characteristic two contains a primitive `p`th root, the
paper's product argument yields a residue with full degree. -/
theorem weighted_block_full_degree_of_root {R : Type*} [Field R] [CharP R 2]
    (n p : Nat) [NeZero p] (hnp : n < p) (z : R) (hz : IsPrimitiveRoot z p) :
    ∃ t : ZMod p, (BPoly.ofFunction n (weightedModularBlock n p t)).topCoefficient = true := by
  classical
  by_contra hnone
  have hall : ∀ t : ZMod p, (BPoly.ofFunction n (weightedModularBlock n p t)).topCoefficient = false := by
    intro t
    cases h : (BPoly.ofFunction n (weightedModularBlock n p t)).topCoefficient with
    | false => rfl
    | true => exact False.elim (hnone ⟨t,h⟩)
  have hsum := weighted_top_sum (R := R) n p z hz.pow_eq_one
  simp only [hall, fieldBit, Bool.false_eq_true, ↓reduceIte, zero_mul, Finset.sum_const_zero] at hsum
  rw [← weighted_product_expansion] at hsum
  have hprod : (∏ i : Fin n, (1 + z ^ (i.val + 1))) ≠ 0 := by
    apply Finset.prod_ne_zero_iff.mpr
    intro i _
    have hpow := hz.pow_ne_one_of_pos_of_lt (by omega : i.val + 1 ≠ 0) (by have := i.isLt; omega)
    intro he
    have hneg : z ^ (i.val + 1) = -1 := eq_neg_of_add_eq_zero_left (by simpa [add_comm] using he)
    have ht : (-1 : R) = 1 := CharTwo.neg_eq 1
    exact hpow (hneg.trans ht)
  exact hprod hsum.symm

/-- For every odd prime modulus larger than the block, at least one of the
paper's weighted modular tests has full degree. -/
theorem weighted_block_full_degree_of_prime (n p : Nat) (hp : p.Prime)
    (hpodd : p ≠ 2) (hnp : n < p) :
    ∃ t : ZMod p, (BPoly.ofFunction n (weightedModularBlock n p t)).topCoefficient = true := by
  classical
  let _ : NeZero p := ⟨hp.ne_zero⟩
  have hodd : p % 2 = 1 := Nat.odd_iff.mp (hp.odd_of_ne_two hpodd)
  let _ : NeZero (p : ZMod 2) := ⟨by
    intro hz
    have hd : 2 ∣ p := (ZMod.natCast_eq_zero_iff p 2).mp hz
    have hm := Nat.mod_eq_zero_of_dvd hd
    omega⟩
  obtain ⟨z,hz⟩ := HasEnoughRootsOfUnity.exists_isPrimitiveRoot (AlgebraicClosure (ZMod 2)) p
  exact weighted_block_full_degree_of_root n p hnp z hz

/-- The explicit weighted block meets both properties required by the
certificate, once the paper's subset-sum cardinality bound is supplied. -/
theorem exists_weighted_robust_full_degree_of_subsetSumBound (n p m k : Nat)
    (hp : p.Prime) (hpodd : p ≠ 2) (hlarge : 2 * n < p) (hk : m + 2 ≤ k)
    (hthreshold : p ≤ 1 + m * (m + 1) / 2)
    (hbound : ∀ A : Finset (ZMod p), (∀ x ∈ A, -x ∉ A) →
      min p (1 + A.card * (A.card + 1) / 2) ≤ A.subsetSum.card) :
    ∃ t : ZMod p, Robust k (weightedModularBlock n p t) ∧
      (BPoly.ofFunction n (weightedModularBlock n p t)).topCoefficient = true := by
  let _ : NeZero p := ⟨hp.ne_zero⟩
  obtain ⟨t,ht⟩ := weighted_block_full_degree_of_prime n p hp hpodd (by omega)
  exact ⟨t,weightedModularBlock_robust_of_subsetSumBound n p m k hlarge hk hthreshold hbound t,ht⟩

end SatLowerBound
