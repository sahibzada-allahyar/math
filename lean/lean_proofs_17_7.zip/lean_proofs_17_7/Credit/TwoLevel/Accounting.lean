import Credit.TwoLevel.Basic
import Credit.Transfer

/-! Exact per-input gain/loss accounting from the two-level charging lemma.
This module does not claim that the losses can yet be charged to eliminated gates. -/
namespace SatLowerBound
namespace OpenCircuit

/-- Original two-level gate weights for gates retained by a restriction. -/
def keptPsi2Weight : {n : Nat} → OpenCircuit n → (Fin n → Res) → Nat
  | _, .output _, _ => 0
  | n, .gate g i j rest, ρ =>
    match Res.step g (ρ i) (ρ j) with
    | some r => rest.keptPsi2Weight (appendValue ρ r)
    | none => g.psi2W + rest.keptPsi2Weight (appendValue ρ (.lit n false))

/-- Original two-level gate weights for gates eliminated by a restriction. -/
def aliasedPsi2Weight : {n : Nat} → OpenCircuit n → (Fin n → Res) → Nat
  | _, .output _, _ => 0
  | n, .gate g i j rest, ρ =>
    match Res.step g (ρ i) (ρ j) with
    | some r => g.psi2W + rest.aliasedPsi2Weight (appendValue ρ r)
    | none => rest.aliasedPsi2Weight (appendValue ρ (.lit n false))

theorem psi2Weight_split {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) :
    C.psi2Weight = C.keptPsi2Weight ρ + C.aliasedPsi2Weight ρ := by
  induction C with
  | output => rfl
  | @gate n g i j rest ih =>
    simp only [psi2Weight, keptPsi2Weight, aliasedPsi2Weight]
    cases Res.step g (ρ i) (ρ j) with
    | some r => have h := ih (appendValue ρ r); simp only; omega
    | none => have h := ih (appendValue ρ (.lit n false)); simp only; omega

/-- Restriction preserves the 7/4 weights of kept gates, including sign twists. -/
theorem restrict_psi2Weight_transfer {n m : Nat} (C : OpenCircuit n)
    (σ : Fin n → Signal m) (ρ : Fin n → Res) (φ : Fin m → Nat)
    (hφ : Function.Injective φ) (hφn : ∀ w, φ w < n)
    (hrel : ∀ k, ResRel φ (σ k) (ρ k)) :
    (C.restrict σ).psi2Weight = C.keptPsi2Weight ρ := by
  induction C generalizing m with
  | output s => rfl
  | @gate n g i j rest ih =>
    rcases hsg : simplifyGate g (σ i) (σ j) with s | ⟨t, k, l⟩
    · obtain ⟨r, hstep, hsr⟩ := TransferAux.step_of_alias φ hφ g (hrel i) (hrel j) hsg
      have hres : (gate g i j rest).restrict σ = rest.restrict (extendSubst σ s) := by
        simp only [restrict, hsg]
      have h := ih (extendSubst σ s) (appendValue ρ r) φ hφ
        (fun w => Nat.lt_succ_of_lt (hφn w)) (TransferAux.rel_extend hrel hsr)
      rw [hres]
      simp only [keptPsi2Weight, hstep]
      exact h
    · obtain ⟨hstep, a, b, ht, _, _⟩ :=
        TransferAux.step_of_binary φ hφ g (hrel i) (hrel j) hsg
      subst ht
      have hres : (gate g i j rest).restrict σ =
          .gate (twist g a b) k l (rest.restrict (liftSubst σ)) := by
        simp only [restrict, hsg]
      have h := ih (liftSubst σ) (appendValue ρ (.lit n false))
        (appendValue φ n) (TransferAux.appendValue_injective hφ hφn)
        (TransferAux.appendValue_lt hφn) (TransferAux.rel_lift hrel)
      rw [hres]
      simp only [keptPsi2Weight, hstep, psi2Weight, h, Table.twist_psi2W]

/-- The eliminated weight equals the drop in 7/4 gate weight under restriction. -/
theorem fix_psi2Weight_drop {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool) :
    C.psi2Weight = (C.restrict (fixSubst P c)).psi2Weight +
      C.aliasedPsi2Weight (fixRes P c) := by
  have ht := C.restrict_psi2Weight_transfer (fixSubst P c) (fixRes P c)
    Fin.val Fin.val_injective (fun w => w.isLt) (fixSubst_rel P c)
  rw [ht]
  exact C.psi2Weight_split (fixRes P c)

/-- Number of one- and two-level credits carried by a primary input. -/
def credit2 {n : Nat} (C : OpenCircuit n) (z : Fin n) : Nat :=
  indicator (C.isD z.val) + indicator (C.isDStar z.val)

/-- The positive part of the change in a single input's credit. -/
def credit2Gained {n : Nat} (C D : OpenCircuit n) : Nat :=
  ∑ z : Fin n, (D.credit2 z - C.credit2 z)

/-- The positive part of the decrease in a single input's credit. -/
def credit2Lost {n : Nat} (C D : OpenCircuit n) : Nat :=
  ∑ z : Fin n, (C.credit2 z - D.credit2 z)

theorem credit2_sum {n : Nat} (C : OpenCircuit n) :
    (∑ z : Fin n, C.credit2 z) = C.dCount + C.dStarCount := by
  simp only [credit2, dCount, dStarCount, Finset.sum_add_distrib]

/-- `old + gained = new + lost`, exactly as in the paper's definition
of `Λ` and `Γ`, including simultaneous changes in both credit levels. -/
theorem credit2_balance {n : Nat} (C D : OpenCircuit n) :
    C.dCount + C.dStarCount + credit2Gained C D =
      D.dCount + D.dStarCount + credit2Lost C D := by
  unfold credit2Gained credit2Lost
  rw [← C.credit2_sum, ← D.credit2_sum, ← Finset.sum_add_distrib,
    ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro z _
  omega

/-- Exact change of the two-level potential before bounding or distributing
losses over eliminated gates. The integer weight difference is intentionally
left explicit until the restriction-weight correspondence is established. -/
theorem psi2_gain_loss_identity {n : Nat} (C D : OpenCircuit n) :
    C.psi2 - D.psi2 =
      ((C.psi2Weight : Int) - D.psi2Weight) - credit2Lost C D + credit2Gained C D := by
  have hb : (C.dCount : Int) + C.dStarCount + credit2Gained C D =
      (D.dCount : Int) + D.dStarCount + credit2Lost C D := by
    exact_mod_cast C.credit2_balance D
  unfold psi2
  omega

/-- The exact gain/loss identity for a restriction: the first term is precisely
 the sum of original weights of the eliminated gates. -/
theorem psi2_restriction_gain_loss {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) :
    C.psi2 - (C.restrict (fixSubst P c)).psi2 =
      (C.aliasedPsi2Weight (fixRes P c) : Int) -
        credit2Lost C (C.restrict (fixSubst P c)) +
        credit2Gained C (C.restrict (fixSubst P c)) := by
  have hweight := C.fix_psi2Weight_drop P c
  have hbalance := C.psi2_gain_loss_identity (C.restrict (fixSubst P c))
  omega

end OpenCircuit
end SatLowerBound
