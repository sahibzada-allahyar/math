import Credit.TwoLevel.BalandraudRecurrence

/-! Removing omitted factors from the dimension recurrence. -/
namespace SatLowerBound

/-- Multiplying a product with one position omitted by that position's
factor recovers the full product. -/
theorem balandraud_omitted_product (n : Nat) (c : Fin (n + 1)) :
    ((n + c.val : Nat) : ℤ) *
      (∏ i : Fin n, ((n + (c.succAbove i).val : Nat) : ℤ)) =
    ∏ i : Fin (n + 1), ((n + i.val : Nat) : ℤ) := by
  exact (Fin.prod_univ_succAbove (fun i : Fin (n + 1) => ((n + i.val : Nat) : ℤ)) c).symm

/-- The odd-column factor is nonzero, so its later cancellation is valid. -/
theorem balandraud_odd_product_ne_zero (n : Nat) :
    (∏ j : Fin n, ((2 * j.val + 1 : Nat) : ℤ)) ≠ 0 := by
  apply Finset.prod_ne_zero_iff.mpr
  intro j _
  positivity

/-- The interior recurrence with the two omitted row factors restored.
Both terms now use the same full product. -/
theorem balandraudDet_full_product_recurrence {n : Nat} (g : Fin n) :
    (∏ j : Fin n, ((2 * j.val + 1 : Nat) : ℤ)) *
      ((n + g.val : Nat) : ℤ) * ((n + g.val + 1 : Nat) : ℤ) *
      balandraudDet (n + 1) (g.val + 1) =
    (∏ i : Fin (n + 1), ((n + i.val : Nat) : ℤ)) *
      (((n + g.val + 1 : Nat) : ℤ) * balandraudDet n g.val +
       ((n + g.val : Nat) : ℤ) * balandraudDet n (g.val + 1)) := by
  have h := balandraudDet_dimension_recurrence g
  have h₁ := balandraud_omitted_product n g.castSucc
  have h₂ := balandraud_omitted_product n g.succ
  simp only [Fin.val_castSucc, Fin.val_succ, ← Nat.add_assoc] at h₁ h₂
  linear_combination
    ((n + g.val : Nat) : ℤ) * ((n + g.val + 1 : Nat) : ℤ) * h +
    ((n + g.val + 1 : Nat) : ℤ) * balandraudDet n g.val * h₁ +
    ((n + g.val : Nat) : ℤ) * balandraudDet n (g.val + 1) * h₂

end SatLowerBound
