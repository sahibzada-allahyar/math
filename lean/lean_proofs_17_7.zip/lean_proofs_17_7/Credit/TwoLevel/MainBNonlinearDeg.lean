import Credit.TwoLevel.MainBParity
import Credit.MainA.NonlinearDeg

/-! Main Lemma B when an operand of the nonlinear first gate has at least three readers. -/
namespace SatLowerBound
namespace MAContext
open OpenCircuit

theorem case_nonlinear_three_twoLevel {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) {t : Table} {i j : Fin n} {rest : OpenCircuit (n + 1)}
    (hC : C = .gate t i j rest) (hnl : t.nonlinear = true) (v : Fin n) (hv : v = i ∨ v = j)
    (h3 : 3 ≤ C.refCount v.val) : ∃ b, (C.restrict (singleSubst v b)).psi2 + 14 ≤ C.psi2 := by
  -- the first gate `T = n` reads `v`
  have hT : C.gateAt n = some (t, i.val, j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hTv : n ∈ C.users v.val := by
    rw [C.mem_users]
    refine ⟨t, i.val, j.val, hT, ?_⟩
    rcases hv with hv | hv
    · rw [hv]
      exact Or.inl rfl
    · rw [hv]
      exact Or.inr rfl
  have h2 : 2 ≤ C.refCount v.val := by omega
  -- `v` itself resolves to the constant `b`, so every reader of `v` is eliminated
  have hvres : ∀ b : Bool, C.resAt (singleRes v b) v.val = .const b := by
    intro b
    rw [C.resAt_single_input v b v]
    simp
  have halias : ∀ b : Bool, ∀ k ∈ C.users v.val, C.isAliased (singleRes v b) k = true := by
    intro b k hk
    obtain ⟨g, a, a', hg, hav⟩ := C.mem_users.mp hk
    apply C.isAliased_of_const _ hg
    rcases hav with hav | hav
    · left
      rw [hav, hvres b]
      rfl
    · right
      rw [hav, hvres b]
      rfl
  -- the `v`-step: fix `v` to its blocking value for `T`, which becomes constant
  obtain ⟨b, hbc⟩ : ∃ b, (C.resAt (singleRes v b) n).isConst = true := by
    rcases hv with hv | hv
    · obtain ⟨b, hb, -⟩ := t.nonlinear_exists_blocksLeft hnl
      refine ⟨b, ?_⟩
      rw [C.resAt_gate _ hT, ← hv, hvres b, Res.step_blocked_left t b _ hb]
      rfl
    · obtain ⟨b, hb, -⟩ := t.nonlinear_exists_blocksRight hnl
      refine ⟨b, ?_⟩
      rw [C.resAt_gate _ hT, ← hv, hvres b, Res.step_blocked_right t _ b hb]
      rfl
  -- two further readers `Q₁ ≠ Q₂` of `v`, both different from `T`
  have hcard : 3 ≤ (C.users v.val).card := by
    rw [← h.refCount_input v]
    exact h3
  have hcard' : 1 < ((C.users v.val).erase n).card := by
    rw [Finset.card_erase_of_mem hTv]
    omega
  obtain ⟨Q₁, hQ₁, Q₂, hQ₂, hQ⟩ := Finset.one_lt_card.mp hcard'
  have hQ₁n : Q₁ ≠ n := Finset.ne_of_mem_erase hQ₁
  have hQ₂n : Q₂ ≠ n := Finset.ne_of_mem_erase hQ₂
  have hQ₁v : Q₁ ∈ C.users v.val := Finset.mem_of_mem_erase hQ₁
  have hQ₂v : Q₂ ∈ C.users v.val := Finset.mem_of_mem_erase hQ₂
  -- a reader `R₁` of the constant `T`, eliminated (F5) and not a reader of `v` (F4)
  have hTb := C.gateAt_bounds hT
  obtain ⟨⟨R₁, hR₁⟩, hR₁al⟩ := h.const_users v b (Nat.le_refl n) hTb.2.1 hbc
  have hR₁v : R₁ ∉ C.users v.val := h.no_triangle v.isLt hTv hR₁
  have hR₁n : R₁ ≠ n := fun he => hR₁v (he ▸ hTv)
  have hR₁Q₁ : R₁ ≠ Q₁ := fun he => hR₁v (he ▸ hQ₁v)
  have hR₁Q₂ : R₁ ≠ Q₂ := fun he => hR₁v (he ▸ hQ₂v)
  -- All four gates are distinct and eliminated.
  let F : Finset Nat := {n, Q₁, Q₂, R₁}
  have hFsub : F ⊆ Finset.range (n + C.size) := by
    intro k hk
    simp only [F, Finset.mem_insert, Finset.mem_singleton] at hk
    have hbound : ∀ q ∈ C.users v.val, q < n + C.size := by
      intro q hq
      obtain ⟨g,a,d,hg,_⟩ := C.mem_users.mp hq
      exact (C.gateAt_bounds hg).2.1
    have hRbound : R₁ < n + C.size := by
      obtain ⟨g,a,d,hg,_⟩ := C.mem_users.mp hR₁
      exact (C.gateAt_bounds hg).2.1
    rcases hk with he | he | he | he
    · rw [he]; exact Finset.mem_range.mpr (hbound n hTv)
    · rw [he]; exact Finset.mem_range.mpr (hbound Q₁ hQ₁v)
    · rw [he]; exact Finset.mem_range.mpr (hbound Q₂ hQ₂v)
    · rw [he]; exact Finset.mem_range.mpr hRbound
  have hFal : ∀ k ∈ F, C.isAliased (singleRes v b) k = true := by
    intro k hk
    simp only [F, Finset.mem_insert, Finset.mem_singleton] at hk
    rcases hk with he | he | he | he
    · simpa [he] using halias b n hTv
    · simpa [he] using halias b Q₁ hQ₁v
    · simpa [he] using halias b Q₂ hQ₂v
    · simpa [he] using hR₁al R₁ hR₁
  have hcount := C.aliasedCount_ge_card (singleRes v b) F hFsub hFal
  have hFcard : F.card = 4 := by
    simp [F, hQ, Ne.symm hQ₁n, Ne.symm hQ₂n, Ne.symm hR₁n,
      Ne.symm hR₁Q₁, Ne.symm hR₁Q₂]
  rw [hFcard] at hcount
  let E : Finset Nat := {n,Q₁,Q₂}
  have hEread : ∀ k ∈ E, k ∈ C.users v.val := by
    intro k hk
    simp only [E, Finset.mem_insert, Finset.mem_singleton] at hk
    rcases hk with he | he | he
    · simpa [he] using hTv
    · simpa [he] using hQ₁v
    · simpa [he] using hQ₂v
  have hEsubF : E ⊆ F := by
    intro k hk
    simp only [E, F, Finset.mem_insert, Finset.mem_singleton] at hk ⊢
    rcases hk with he | he | he <;> simp [he]
  by_cases hp : ∃ k ∈ E, (C.tableAt k).parity = true
  · obtain ⟨k,hk,hkp⟩ := hp
    have hsub : ({k} : Finset Nat) ⊆ Finset.range (n + C.size) := by
      intro j hj
      have hj' : j = k := Finset.mem_singleton.mp hj
      rw [hj']
      exact hFsub (hEsubF hk)
    have hpc := C.aliasedParityCount_ge_card (singleRes v b) {k} hsub (by
      intro j hj
      rw [Finset.mem_singleton.mp hj]
      exact ⟨hFal k (hEsubF hk),hkp⟩)
    simp at hpc
    have hd := h.twoLevel_single_drop v b h2
    exact ⟨b, by omega⟩
  · have hE : ∀ k ∈ E, k ∈ C.users v.val ∧
        C.isAliased (singleRes v b) k = true ∧ (C.tableAt k).parity = false := by
      intro k hk
      refine ⟨hEread k hk, halias b k (hEread k hk), ?_⟩
      apply Bool.eq_false_iff.mpr
      intro ht
      exact hp ⟨k,hk,ht⟩
    have hd := h.twoLevel_single_drop_with_readers v b h2 E hE
    have hEcard : E.card = 3 := by
      simp [E, hQ, Ne.symm hQ₁n, Ne.symm hQ₂n]
    rw [hEcard] at hd
    exact ⟨b, by omega⟩

end MAContext
end SatLowerBound
