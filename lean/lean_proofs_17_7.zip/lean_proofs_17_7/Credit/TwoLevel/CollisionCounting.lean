import Credit.TwoLevel.Robust

/-! Finite counting step for the manuscript's probabilistic robust-block
construction. -/
namespace SatLowerBound

/-- Functions agreeing on two disjoint copies of an index set. -/
def CoincidentFunctions {α β : Type} (a b : β → α) :=
  { f : α → Bool // ∀ x, f (a x) = f (b x) }

/-- A function with a prescribed cofactor collision is determined by its
values outside the first subcube. -/
theorem coincident_restrict_injective {α β : Type} (a b : β → α)
    (_ha : Function.Injective a) (hdis : ∀ x y, a x ≠ b y) :
    Function.Injective (fun f : CoincidentFunctions a b =>
      fun z : {z : α // z ∉ Set.range a} => f.val z.val) := by
  classical
  intro f g hfg
  apply Subtype.ext
  funext z
  by_cases hz : z ∈ Set.range a
  · obtain ⟨x,rfl⟩ := hz
    have hb : b x ∉ Set.range a := by
      rintro ⟨y,hy⟩
      exact hdis y x hy
    have h := congrFun hfg ⟨b x,hb⟩
    exact (f.property x).trans (h.trans (g.property x).symm)
  · exact congrFun hfg ⟨z,hz⟩

noncomputable def coincidentCard {α β : Type} [Fintype α] [Fintype β] (a b : β → α) : Nat := by
  classical
  letI : Fintype (CoincidentFunctions a b) := by unfold CoincidentFunctions; infer_instance
  exact Fintype.card (CoincidentFunctions a b)

noncomputable def complementCard {α β : Type} [Fintype α] [Fintype β] (a : β → α) : Nat := by
  classical
  exact Fintype.card {z : α // z ∉ Set.range a}

/-- At most one Boolean function on the complement can correspond to each
function with the prescribed collision. -/
theorem coincidentFunctions_card_le {α β : Type} [Fintype α] [Fintype β]
    (a b : β → α) (ha : Function.Injective a) (hdis : ∀ x y, a x ≠ b y) :
    coincidentCard a b ≤ 2 ^ complementCard a := by
  classical
  let _ : Fintype (CoincidentFunctions a b) := by unfold CoincidentFunctions; infer_instance
  have h := Fintype.card_le_of_injective
    (fun f : CoincidentFunctions a b => fun z : {z : α // z ∉ Set.range a} => f.val z.val)
    (coincident_restrict_injective a b ha hdis)
  simpa [coincidentCard,complementCard,Fintype.card_fun] using h

/-- The complement has exactly `|α| - |β|` elements because the first
subcube embedding is injective. -/
theorem complementCard_eq {α β : Type} [Fintype α] [Fintype β]
    (a : β → α) (ha : Function.Injective a) :
    complementCard a = Fintype.card α - Fintype.card β := by
  classical
  let e : β ≃ {z : α // z ∈ Set.range a} := Equiv.ofBijective (fun x => ⟨a x,⟨x,rfl⟩⟩) (by
    constructor
    · intro x y h
      exact ha (congrArg Subtype.val h)
    · rintro ⟨z,⟨x,rfl⟩⟩
      exact ⟨x,rfl⟩)
  have he := Fintype.card_congr e
  have hc := Fintype.card_subtype_compl (fun z : α => z ∈ Set.range a)
  unfold complementCard
  omega

/-- Quantitative form of the cofactor-collision counting bound. -/
theorem coincidentFunctions_card_le_pow {α β : Type} [Fintype α] [Fintype β]
    (a b : β → α) (ha : Function.Injective a) (hdis : ∀ x y, a x ≠ b y) :
    coincidentCard a b ≤ 2 ^ (Fintype.card α - Fintype.card β) := by
  rw [← complementCard_eq a ha]
  exact coincidentFunctions_card_le a b ha hdis

end SatLowerBound
