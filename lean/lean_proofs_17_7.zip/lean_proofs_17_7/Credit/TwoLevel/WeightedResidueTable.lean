import Credit.TwoLevel.WeightedResidueAlgorithm
import Credit.TwoLevel.WeightedParameters

namespace SatLowerBound

/-- Materialized residue table. Each round reuses the previous table rather
than expanding the two recursive calls in `weightedResidueParity`. -/
def weightedResidueTable (p : Nat) [NeZero p] : Nat → Vector Bool p
  | 0 => Vector.ofFn (fun i => decide ((i.val : ZMod p) = 0))
  | n + 1 =>
    let previous := weightedResidueTable p n
    Vector.ofFn (fun i => Bool.xor previous[i]
      previous[(⟨((i.val : ZMod p) - (n + 1 : Nat)).val, ZMod.val_lt _⟩ : Fin p)])

/-- Every entry in the materialized table is the actual residue parity. -/
theorem weightedResidueTable_correct (p : Nat) [NeZero p] (n : Nat) (i : Fin p) :
    (weightedResidueTable p n)[i] = weightedResidueParity p n (i.val : ZMod p) := by
  induction n generalizing i with
  | zero => simp [weightedResidueTable, weightedResidueParity]
  | succ n ih =>
    simp [weightedResidueTable, weightedResidueParity, ih]

/-- The table's entries equal the true top coefficients of the blocks. -/
theorem weightedResidueTable_topCoefficient (p : Nat) [NeZero p] (n : Nat) (i : Fin p) :
    (weightedResidueTable p n)[i] =
      (BPoly.ofFunction n (weightedModularBlock n p (i.val : ZMod p))).topCoefficient := by
  rw [weightedResidueTable_correct, weightedResidueParity_correct]

/-- Number of XOR evaluations in the table construction: each round calls
the vector callback exactly once for each of its p entries. This counts XORs,
not the machine cost of modular arithmetic, indexing, or allocation. -/
def weightedResidueTableXors (p : Nat) : Nat → Nat
  | 0 => 0
  | n + 1 => weightedResidueTableXors p n + p

theorem weightedResidueTableXors_exact (p n : Nat) :
    weightedResidueTableXors p n = n * p := by
  induction n with
  | zero => simp [weightedResidueTableXors]
  | succ n ih => simp [weightedResidueTableXors, ih, Nat.add_mul]

/-- At the manuscript's chosen prime, the table construction uses at most
4 r² XOR evaluations. -/
theorem weightedResidueTableXors_quadratic (r : Nat) (hr : 1 ≤ r) :
    weightedResidueTableXors (weightedPrime r) r ≤ 4 * r * r := by
  rw [weightedResidueTableXors_exact]
  have h := weightedPrime_le_four r hr
  nlinarith

end SatLowerBound
