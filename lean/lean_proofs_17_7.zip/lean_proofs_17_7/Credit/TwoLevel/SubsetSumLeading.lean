import Credit.TwoLevel.SubsetSumDegree

/-! Leading terms of the sum-avoiding polynomial. -/
namespace SatLowerBound
open MvPolynomial

/-- The top-degree part of a product of translated linear forms is the
corresponding power of the common linear form. -/
theorem shiftedLinearProduct_sub_power_degree {R : Type} [CommRing R] [Nontrivial R]
    {σ : Type} [DecidableEq σ] (L : MvPolynomial σ R) (hL : L.totalDegree ≤ 1)
    (S : Finset R) (hS : S.Nonempty) :
    ((∏ c ∈ S, (L - MvPolynomial.C c)) - L ^ S.card).totalDegree < S.card := by
  classical
  induction S using Finset.induction_on with
  | empty => simp at hS
  | @insert c S hc ih =>
    by_cases hS0 : S = ∅
    · subst S
      simp only [Finset.prod_insert (Finset.notMem_empty c), Finset.card_insert_of_notMem (Finset.notMem_empty c),
        Finset.prod_empty, Finset.card_empty, Nat.zero_add, pow_one, mul_one]
      have he : (L - MvPolynomial.C c) - L = -MvPolynomial.C c := by ring
      rw [he, MvPolynomial.totalDegree_neg, MvPolynomial.totalDegree_C]
      decide
    · have hne : S.Nonempty := Finset.nonempty_iff_ne_empty.mpr hS0
      have ih' := ih hne
      let Q : MvPolynomial σ R := ∏ c ∈ S, (L - MvPolynomial.C c)
      have hQ : Q.totalDegree ≤ S.card := by
        calc
          _ ≤ ∑ c ∈ S, (L - MvPolynomial.C c).totalDegree :=
            MvPolynomial.totalDegree_finsetProd _ _
          _ ≤ ∑ _c ∈ S, 1 := by
            apply Finset.sum_le_sum
            intro c _
            exact (MvPolynomial.totalDegree_sub_C_le _ _).trans hL
          _ = S.card := by simp
      have hD : (Q - L ^ S.card).totalDegree < S.card := ih'
      have hmul1 := MvPolynomial.totalDegree_mul L (Q - L ^ S.card)
      have hmul2 := MvPolynomial.totalDegree_mul (MvPolynomial.C c) Q
      have hsub := MvPolynomial.totalDegree_sub (L * (Q - L ^ S.card)) (MvPolynomial.C c * Q)
      have hbound : (L * (Q - L ^ S.card) - MvPolynomial.C c * Q).totalDegree ≤ S.card := by
        simp only [MvPolynomial.totalDegree_C,zero_add] at hmul2
        omega
      simp only [Finset.prod_insert hc, Finset.card_insert_of_notMem hc, pow_succ]
      have he : (L - MvPolynomial.C c) * Q - L ^ S.card * L =
          L * (Q - L ^ S.card) - MvPolynomial.C c * Q := by ring
      change ((L - MvPolynomial.C c) * Q - L ^ S.card * L).totalDegree < S.card + 1
      rw [he]
      omega

/-- The homogeneous leading expression used for the coefficient calculation. -/
noncomputable def signedLeadingPolynomial (R : Type) [CommRing R] (d k : Nat) :
    MvPolynomial (Fin d) R := signedVandermonde R d * (∑ i : Fin d, X i) ^ k

/-- At the maximal possible degree, the coefficient does not depend on the
individual excluded sums, only on how many of them there are. -/
theorem signedSumAvoidingPolynomial_top_coefficient {R : Type} [CommRing R] [Nontrivial R]
    (d : Nat) (S : Finset R) (t : Fin d →₀ Nat)
    (ht : t.degree = 2 * Nat.choose d 2 + S.card) :
    (signedSumAvoidingPolynomial R d S).coeff t =
      (signedLeadingPolynomial R d S.card).coeff t := by
  classical
  by_cases hS : S.Nonempty
  · let L : MvPolynomial (Fin d) R := ∑ i : Fin d, X i
    let V : MvPolynomial (Fin d) R := signedVandermonde R d
    let Q : MvPolynomial (Fin d) R := ∏ c ∈ S, (L - MvPolynomial.C c)
    have hL : L.totalDegree ≤ 1 := by
      apply MvPolynomial.totalDegree_finsetSum_le
      intro i _
      simp
    have hV : V.totalDegree ≤ 2 * Nat.choose d 2 := signedVandermonde_degree_le d
    have hQ : (Q - L ^ S.card).totalDegree < S.card :=
      shiftedLinearProduct_sub_power_degree L hL S hS
    have hd : (V * (Q - L ^ S.card)).totalDegree < t.degree := by
      have hm := MvPolynomial.totalDegree_mul V (Q - L ^ S.card)
      rw [ht]
      omega
    have he : signedSumAvoidingPolynomial R d S - signedLeadingPolynomial R d S.card =
        V * (Q - L ^ S.card) := by
      dsimp [signedSumAvoidingPolynomial,signedLeadingPolynomial,V,Q,L]
      ring
    have hzero : (signedSumAvoidingPolynomial R d S - signedLeadingPolynomial R d S.card).coeff t = 0 := by
      rw [he]
      apply MvPolynomial.coeff_eq_zero_of_totalDegree_lt
      simpa [Finsupp.degree_apply] using hd
    simpa only [MvPolynomial.coeff_sub, sub_eq_zero] using hzero
  · have hempty : S = ∅ := Finset.not_nonempty_iff_eq_empty.mp hS
    subst S
    simp [signedSumAvoidingPolynomial,signedLeadingPolynomial]

/-- The avoiding polynomial vanishes when its root set contains every
restricted tuple sum, including when that set has been padded. -/
theorem signedSumAvoidingPolynomial_vanishes_of_cover {R : Type} [Field R] [DecidableEq R] [Fintype R]
    {d : Nat} (a : Fin d → R) (domains : Fin d → Finset R)
    (hdom : ∀ i x, x ∈ domains i → ∃ j, x = a j ∨ x = -a j)
    (S : Finset R) (hcover : signedRestrictedSums a domains ⊆ S)
    (x : Fin d → R) (hx : ∀ i, x i ∈ domains i) :
    eval x (signedSumAvoidingPolynomial R d S) = 0 := by
  classical
  by_cases hV : eval x (signedVandermonde R d) = 0
  · simp [signedSumAvoidingPolynomial,hV]
  · have hsep := signedVandermonde_separated x hV
    have hmem : (∑ i, x i) ∈ signedRestrictedSums a domains := by
      apply Finset.mem_image.mpr
      refine ⟨x,?_,rfl⟩
      apply Finset.mem_filter.mpr
      exact ⟨Finset.mem_univ x,hx,(fun i => hdom i (x i) (hx i)),hsep⟩
    have hzero : (∏ c ∈ S, ((∑ i, x i) - c)) = 0 := by
      apply Finset.prod_eq_zero (hcover hmem)
      simp
    simp [signedSumAvoidingPolynomial,hzero]

/-- A nonzero coefficient of the homogeneous polynomial forces more than
`k` restricted sums. This is the reduction used before the determinant is
computed in the cited proof. -/
theorem restrictedSums_gt_of_leading_coefficient
    {R : Type} [Field R] [DecidableEq R] [Fintype R]
    {d k : Nat} (a : Fin d → R) (domains : Fin d → Finset R)
    (hdom : ∀ i x, x ∈ domains i → ∃ j, x = a j ∨ x = -a j)
    (t : Fin d →₀ Nat) (hsize : ∀ i, t i < (domains i).card)
    (hdegree : t.degree = 2 * Nat.choose d 2 + k)
    (hk : k ≤ Fintype.card R)
    (hcoef : (signedLeadingPolynomial R d k).coeff t ≠ 0) :
    k < (signedRestrictedSums a domains).card := by
  classical
  by_contra hn
  have hle : (signedRestrictedSums a domains).card ≤ k := by omega
  obtain ⟨S,hcover,hcard⟩ := Finset.exists_superset_card_eq hle hk
  have ht : t.degree = 2 * Nat.choose d 2 + S.card := by rw [hcard]; exact hdegree
  have htop := signedSumAvoidingPolynomial_top_coefficient d S t ht
  rw [hcard] at htop
  have hnonzero : (signedSumAvoidingPolynomial R d S).coeff t ≠ 0 := by
    rw [htop]
    exact hcoef
  have hV := signedVandermonde_degree_le (R := R) d
  have hQ := sumAvoidingFactor_degree_le (R := R) d S
  have hupper : (signedSumAvoidingPolynomial R d S).totalDegree ≤ t.degree := by
    unfold signedSumAvoidingPolynomial
    have hm := MvPolynomial.totalDegree_mul (signedVandermonde R d)
      (∏ c ∈ S, ((∑ i : Fin d, X i) - MvPolynomial.C c))
    rw [hcard] at hQ
    rw [hdegree]
    omega
  have heq : (signedSumAvoidingPolynomial R d S).totalDegree = t.degree :=
    le_antisymm hupper (MvPolynomial.le_totalDegree (MvPolynomial.mem_support_iff.mpr hnonzero))
  obtain ⟨x,hx,hxne⟩ := combinatorial_nullstellensatz_exists_eval_nonzero
    _ t hnonzero heq domains hsize
  exact hxne (signedSumAvoidingPolynomial_vanishes_of_cover a domains hdom S hcover x hx)

end SatLowerBound
