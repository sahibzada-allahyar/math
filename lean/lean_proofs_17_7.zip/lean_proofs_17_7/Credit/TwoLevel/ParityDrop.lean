import Credit.TwoLevel.Aggregate

/-! Separate parity and nonlinear contributions to the free-input drop bound. -/
namespace SatLowerBound
namespace OpenCircuit

/-- Number of parity gates eliminated by the restriction trace. -/
def aliasedParityCount : {n : Nat} → OpenCircuit n → (Fin n → Res) → Nat
  | _, .output _, _ => 0
  | n, .gate g i j rest, ρ =>
    match Res.step g (ρ i) (ρ j) with
    | some r => g.parityCount + rest.aliasedParityCount (appendValue ρ r)
    | none => rest.aliasedParityCount (appendValue ρ (.lit n false))

/-- Any reader of a D-signal is its unique nonlinear reader. -/
theorem nonlinear_of_D_reader {n : Nat} (C : OpenCircuit n) (s k : Nat)
    (hD : C.isD s = true) (hk : k ∈ C.users s) : (C.tableAt k).nonlinear = true := by
  obtain ⟨_, W, g, a, b, hgate, hab, hnl⟩ := (C.isD_iff s).mp hD
  have hm : W ∈ C.users s := C.mem_users.mpr ⟨g,a,b,hgate,hab⟩
  have hu := C.users_singleton_of_isD s W hD hm
  rw [hu, Finset.mem_singleton] at hk
  rw [hk]
  simp [tableAt, hgate, hnl]

/-- An original gate that is not nonlinear receives no first-role charge. -/
theorem first_charge_zero_of_not_nonlinear {n : Nat} (C D : OpenCircuit n)
    (ρ : Fin n → Res) (W : Fin n → Nat)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (k : Nat) (hnl : (C.tableAt k).nonlinear = false) :
    C.gateFirstCharge D ρ W k = 0 := by
  unfold gateFirstCharge
  apply Finset.sum_eq_zero
  intro z hz
  have he := (Finset.mem_filter.mp hz).2
  have hd : C.isD z.val = false := by
    apply Bool.eq_false_iff.mpr
    intro h
    have hh := C.nonlinear_of_D_reader z.val (W z) h (hw z h)
    rw [he, hnl] at hh
    contradiction
  have hb := C.first_charge_bound D ρ W z
  simp [indicator, hd] at hb
  exact hb

/-- An original gate that is not nonlinear receives no second-role charge. -/
theorem second_charge_zero_of_not_nonlinear {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (k : Nat) (hnl : (C.tableAt k).nonlinear = false) :
    C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V k = 0 := by
  unfold gateSecondCharge
  apply Finset.sum_eq_zero
  intro z hz
  have he := (Finset.mem_filter.mp hz).2
  have hs : C.isDStar z.val = false := by
    apply Bool.eq_false_iff.mpr
    intro h
    have hDz := C.isD_of_isDStar z.val h
    have hu := C.users_singleton_of_isD z.val (W z) hDz (hw z hDz)
    have hDW : C.isD (W z) = true := by
      obtain ⟨_,w,hw',hd⟩ := (C.isDStar_iff z.val).mp h
      rw [hu, Finset.mem_singleton] at hw'
      simpa [hw'] using hd
    have hh := C.nonlinear_of_D_reader (W z) (V z) hDW (hv z h)
    rw [he, hnl] at hh
    contradiction
  have hb := C.free_second_charge_bound P c hr W V hfree hw hv hess z
  simp [indicator, hs] at hb
  exact hb

private theorem psi2W_essential (g : Table) (h : g.essential = true) :
    g.psi2W = 4 + 3 * g.parityCount := by
  revert h
  rcases g with ⟨a,b,c,d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

/-- Exact 7/4 accounting: each eliminated essential gate has a baseline
weight four, plus three additional units precisely when it is parity. -/
theorem aliasedPsi2Weight_eq_count_parity {n : Nat} (C : OpenCircuit n)
    (ρ : Fin n → Res) (he : C.EssentialGates) :
    C.aliasedPsi2Weight ρ = 4 * C.aliasedCount ρ + 3 * C.aliasedParityCount ρ := by
  induction C with
  | output o => simp [aliasedCount, aliasedPsi2Weight, aliasedParityCount]
  | @gate n g i j rest ih =>
    simp only [aliasedCount, aliasedPsi2Weight, aliasedParityCount]
    cases hs : Res.step g (ρ i) (ρ j) with
    | none =>
      exact ih (appendValue ρ (.lit n false)) he.2
    | some r =>
      have h := ih (appendValue ρ r) he.2
      have hg := psi2W_essential g he.1
      simp only
      omega

/-- Eliminated parity count as a sum over original gate indices. -/
theorem aliasedParityCount_eq_sum {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) :
    C.aliasedParityCount ρ = ∑ k ∈ Finset.range (n + C.size),
      if C.isAliased ρ k = true then (C.tableAt k).parityCount else 0 := by
  induction C with
  | output o =>
    refine (Finset.sum_eq_zero (fun k _ => ?_)).symm
    rw [FlatKeptAux.isAliased_output]
    rfl
  | @gate n g i j rest ih =>
    have hFG : ∀ k, k ≠ n →
        (if (gate g i j rest).isAliased ρ k = true then ((gate g i j rest).tableAt k).parityCount else 0) =
        (if rest.isAliased (FlatKeptAux.tailRes g i j ρ) k = true then (rest.tableAt k).parityCount else 0) := by
      intro k hk
      rw [FlatKeptAux.isAliased_cons_tail g i j rest ρ hk]
      simp only [tableAt, gateAt_tail g i j rest hk]
    have hG : (if rest.isAliased (FlatKeptAux.tailRes g i j ρ) n = true
        then (rest.tableAt n).parityCount else 0) = 0 :=
      FlatKeptAux.ite_eq_zero_of_false (FlatKeptAux.isAliased_rest_head rest _) _
    rw [FlatKeptAux.size_cons,
      FlatKeptAux.sum_split (n + 1 + rest.size) n (by omega) _ _ hFG hG,
      FlatKeptAux.isAliased_cons_head]
    simp only [tableAt, gateAt_head]
    cases hs : Res.step g (ρ i) (ρ j) with
    | none => simp [aliasedParityCount, FlatKeptAux.tailRes, hs, ih, tableAt]
    | some r => simp [aliasedParityCount, FlatKeptAux.tailRes, hs, ih, tableAt]

/-- Parity gates receive no charges; consequently loss plus the number of
eliminated parity gates is at most the total number of eliminated gates. -/
theorem free_loss_add_parity_le_aliased {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (hsafe : C.DGateSafe)
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (horig : ∀ z, C.isDStar z.val = true → Essential f z) :
    C.credit2Lost (C.restrict (fixSubst P c)) + C.aliasedParityCount (fixRes P c) ≤
      C.aliasedCount (fixRes P c) := by
  rw [C.free_credit_loss_eq_gate_charges P c hr W V hfree hw hv hess,
    C.aliasedParityCount_eq_sum, C.aliasedCount_eq_sum, ← Finset.sum_add_distrib]
  apply Finset.sum_le_sum
  intro k _
  have hcharge := C.free_gate_charge_le_alias P c hr hsafe f hc hE1 W V hfree hw hv hess horig k
  cases ha : C.isAliased (fixRes P c) k with
  | false => simp [ha, indicator] at hcharge ⊢; omega
  | true =>
    cases hp : (C.tableAt k).parity with
    | false => simpa [ha, hp, indicator, Table.parityCount] using hcharge
    | true =>
      have hnl : (C.tableAt k).nonlinear = false := by simp [Table.nonlinear, hp]
      have hfirst := C.first_charge_zero_of_not_nonlinear (C.restrict (fixSubst P c))
        (fixRes P c) W hw k hnl
      have hsecond := C.second_charge_zero_of_not_nonlinear P c hr W V hfree hw hv hess k hnl
      simp [hp, indicator, Table.parityCount, hfirst, hsecond]

/-- Exact 7/4 weights with charges restricted to nonlinear gates: every
eliminated parity gate contributes all seven units, and every eliminated
nonlinear gate contributes at least three, in addition to gains. -/
theorem psi2_free_drop_full_parity {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (hsafe : C.DGateSafe)
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (horig : ∀ z, C.isDStar z.val = true → Essential f z) :
    (C.restrict (fixSubst P c)).psi2 +
      3 * (C.aliasedCount (fixRes P c) : Int) +
      4 * (C.aliasedParityCount (fixRes P c) : Int) +
        C.credit2Gained (C.restrict (fixSubst P c)) ≤ C.psi2 := by
  have hlost := C.free_loss_add_parity_le_aliased P c hr hsafe f hc hE1 W V hfree hw hv hess horig
  have hweight := C.aliasedPsi2Weight_eq_count_parity (fixRes P c) (C.reduced_essential hr)
  have hbalance := C.psi2_restriction_gain_loss P c
  omega

/-- Refined aggregate free-input drop: nonlinear gates contribute at least
three, parity gates at least six, and credit gains contribute one each. -/
theorem psi2_free_drop_with_parity {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (hsafe : C.DGateSafe)
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (horig : ∀ z, C.isDStar z.val = true → Essential f z) :
    (C.restrict (fixSubst P c)).psi2 +
      3 * (C.aliasedCount (fixRes P c) : Int) +
      3 * (C.aliasedParityCount (fixRes P c) : Int) +
        C.credit2Gained (C.restrict (fixSubst P c)) ≤ C.psi2 := by
  have hlost := C.free_credit_loss_le_aliasedCount P c hr hsafe f hc hE1 W V hfree hw hv hess horig
  have hweight := C.aliasedPsi2Weight_eq_count_parity (fixRes P c) (C.reduced_essential hr)
  have hbalance := C.psi2_restriction_gain_loss P c
  omega

end OpenCircuit
end SatLowerBound
