import Credit.TwoLevel.OppositeChain

/-! Reduction of the nonlinear-first case to the manuscript's tight branch. -/
namespace SatLowerBound
namespace MAContext
open OpenCircuit

/-- The exact local configuration left after the checked non-tight cases. -/
def TightFirstOperand {n : Nat} (C : OpenCircuit n) (x : Fin n) : Prop :=
  ∃ other successor : Nat, ∃ block : Bool,
    other ≠ n ∧ C.users x.val = {n,other} ∧ C.users n = {successor} ∧
    (C.resAt (singleRes x block) n).isConst = true ∧
    (C.resAt (singleRes x block) other).isConst = false ∧
    (C.resAt (singleRes x block) successor).isConst = false ∧
    (C.tableAt other).parity = false ∧ (C.tableAt successor).parity = false

/-- If neither bit gives a fourteen-unit drop on the first input of a
nonlinear first gate, and that input has exactly two readers, all the paper's
non-tight alternatives fail and the tight configuration follows. -/
theorem nonlinear_first_operand_tight_of_no_drop {n : Nat}
    {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) {t : Table} {i j : Fin n} {rest : OpenCircuit (n+1)}
    (hC : C = .gate t i j rest) (hnl : t.nonlinear = true)
    (hi : C.refCount i.val = 2)
    (hno : ∀ b, ¬ ((C.restrict (singleSubst i b)).psi2 + 14 ≤ C.psi2)) :
    TightFirstOperand C i := by
  have hT : C.gateAt n = some (t,i.val,j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hTi : n ∈ C.users i.val := C.mem_users.mpr ⟨t,i.val,j.val,hT,Or.inl rfl⟩
  obtain ⟨U,hUn,hUi⟩ := h.users_two i hi hTi
  have hU : U ∈ C.users i.val := by rw [hUi]; simp
  have hi2 : 2 ≤ C.refCount i.val := by omega
  have hTpar : (C.tableAt n).parity = false := by
    have ht : t.parity = false := by
      unfold Table.nonlinear at hnl
      cases hp : t.parity <;> simp [hp] at hnl ⊢
    simp [tableAt,hT,ht]
  obtain ⟨ε,hε,_⟩ := t.nonlinear_exists_blocksLeft hnl
  have hTc : (C.resAt (singleRes i ε) n).isConst = true := by
    rw [C.resAt_gate _ hT, C.resAt_single_input i ε i]
    simp only [ite_true]
    rw [Res.step_blocked_left t ε _ hε]
    rfl
  have hUpar : (C.tableAt U).parity = false := by
    apply Bool.eq_false_iff.mpr
    intro hp
    exact hno ε (h.case_blocked_with_parity_twoLevel i ε hi2 (Ne.symm hUn)
      hTi hU hTpar hTc (Or.inl hp))
  have hUconst : (C.resAt (singleRes i ε) U).isConst = false := by
    apply Bool.eq_false_iff.mpr
    intro hc
    exact hno ε (h.case_both_constant_twoLevel i ε hi2 (Ne.symm hUn) hTi hU hTc hc)
  have hTbounds := C.gateAt_bounds hT
  obtain ⟨hne,_⟩ := h.const_users i ε hTbounds.1 hTbounds.2.1 hTc
  have hle : (C.users n).card ≤ 1 := by
    by_contra hn
    have h2 : 1 < (C.users n).card := by omega
    exact hno ε (h.case_blocked_two_successors_twoLevel i ε hi2 (Ne.symm hUn)
      hTi hU hTpar hTc h2)
  have hcard : (C.users n).card = 1 := by
    have hp := Finset.card_pos.mpr hne
    omega
  obtain ⟨R,hR⟩ := Finset.card_eq_one.mp hcard
  have hRT : R ∈ C.users n := by rw [hR]; simp
  have hRpar : (C.tableAt R).parity = false := by
    apply Bool.eq_false_iff.mpr
    intro hp
    exact hno ε (h.case_blocked_with_parity_twoLevel i ε hi2 (Ne.symm hUn)
      hTi hU hTpar hTc (Or.inr ⟨R,hRT,hp⟩))
  have hRconst : (C.resAt (singleRes i ε) R).isConst = false := by
    apply Bool.eq_false_iff.mpr
    intro hc
    exact hno ε (h.case_successor_constant_twoLevel i ε hi2 (Ne.symm hUn)
      hTi hU hTc hRT hc)
  exact ⟨U,R,ε,hUn,hUi,hR,hTc,hUconst,hRconst,hUpar,hRpar⟩

/-- If no restriction of either first-gate input achieves the desired drop,
both inputs have exactly two readers and the first input has the tight local
configuration. -/
theorem nonlinear_no_drop_reduces_to_tight {n : Nat}
    {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) {t : Table} {i j : Fin n} {rest : OpenCircuit (n+1)}
    (hC : C = .gate t i j rest) (hnl : t.nonlinear = true)
    (hno : ∀ x, (x = i ∨ x = j) → ∀ b,
      ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2)) :
    C.refCount i.val = 2 ∧ C.refCount j.val = 2 ∧ TightFirstOperand C i := by
  obtain ⟨hi,hj⟩ := h.degrees_of_nonlinear hC hnl
  have hi' : C.refCount i.val = 2 := by
    by_contra hn
    have h3 : 3 ≤ C.refCount i.val := by omega
    obtain ⟨b,hb⟩ := h.case_nonlinear_three_twoLevel hC hnl i (Or.inl rfl) h3
    exact hno i (Or.inl rfl) b hb
  have hj' : C.refCount j.val = 2 := by
    by_contra hn
    have h3 : 3 ≤ C.refCount j.val := by omega
    obtain ⟨b,hb⟩ := h.case_nonlinear_three_twoLevel hC hnl j (Or.inr rfl) h3
    exact hno j (Or.inr rfl) b hb
  exact ⟨hi',hj',h.nonlinear_first_operand_tight_of_no_drop hC hnl hi'
    (fun b => hno i (Or.inl rfl) b)⟩

end MAContext
end SatLowerBound
