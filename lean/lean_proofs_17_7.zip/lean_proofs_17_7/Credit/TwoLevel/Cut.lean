import Credit.TwoLevel.Correspondence
import Credit.TwoLevel.Corner

/-! Two-gate cut lemma for nonconsecutive readers, based on topological signal
values. This permits the intermediate gates in the paper's corner case. -/
namespace SatLowerBound
namespace OpenCircuit

/-- If all readers of two primary inputs are among two gate indices, agreeing
on the remaining inputs and on the values at those gates forces the outputs
to agree. The output wire must not be either primary input. -/
theorem eval_eq_of_two_gate_cut {n : Nat} (C : OpenCircuit n)
    (i j : Fin n) (t u : Nat) (x y : Fin n → Bool)
    (hinput : ∀ z, z ≠ i → z ≠ j → x z = y z)
    (hreadi : ∀ k ∈ C.users i.val, k = t ∨ k = u)
    (hreadj : ∀ k ∈ C.users j.val, k = t ∨ k = u)
    (ht : C.valueAt x t = C.valueAt y t)
    (hu : C.valueAt x u = C.valueAt y u)
    (hout : ∀ k b, C.outWire = some (k,b) → k ≠ i.val ∧ k ≠ j.val) :
    C.eval x = C.eval y := by
  have hsig : ∀ k, k < n + C.size → k ≠ i.val → k ≠ j.val →
      C.valueAt x k = C.valueAt y k := by
    intro k
    induction k using Nat.strong_induction_on with
    | h k ih =>
      intro hk hki hkj
      by_cases hkn : k < n
      · let z : Fin n := ⟨k,hkn⟩
        have hzi : z ≠ i := fun he => hki (congrArg Fin.val he)
        have hzj : z ≠ j := fun he => hkj (congrArg Fin.val he)
        change C.valueAt x z.val = C.valueAt y z.val
        exact (C.valueAt_input x z).trans ((hinput z hzi hzj).trans (C.valueAt_input y z).symm)
      · by_cases hkt : k = t
        · simpa [hkt] using ht
        · by_cases hku : k = u
          · simpa [hku] using hu
          · obtain ⟨g,a,b,hgate⟩ := C.gateAt_exists (by omega) hk
            have hb := C.gateAt_bounds hgate
            have hai : a ≠ i.val := by
              intro ha
              have hr : k ∈ C.users i.val := C.mem_users.mpr ⟨g,a,b,hgate,Or.inl ha⟩
              rcases hreadi k hr with he | he <;> contradiction
            have haj : a ≠ j.val := by
              intro ha
              have hr : k ∈ C.users j.val := C.mem_users.mpr ⟨g,a,b,hgate,Or.inl ha⟩
              rcases hreadj k hr with he | he <;> contradiction
            have hbi : b ≠ i.val := by
              intro hb'
              have hr : k ∈ C.users i.val := C.mem_users.mpr ⟨g,a,b,hgate,Or.inr hb'⟩
              rcases hreadi k hr with he | he <;> contradiction
            have hbj : b ≠ j.val := by
              intro hb'
              have hr : k ∈ C.users j.val := C.mem_users.mpr ⟨g,a,b,hgate,Or.inr hb'⟩
              rcases hreadj k hr with he | he <;> contradiction
            rw [C.valueAt_gate x hgate, C.valueAt_gate y hgate,
              ih a hb.2.2.1 (by omega) hai haj, ih b hb.2.2.2 (by omega) hbi hbj]
  cases hw : C.outWire with
  | none => exact C.eval_const_of_outWire_none hw x y
  | some pair =>
    obtain ⟨k, neg⟩ := pair
    have hk := C.outWire_bound hw
    obtain ⟨hki,hkj⟩ := hout k neg hw
    rw [C.eval_of_outWire x hw, C.eval_of_outWire y hw, hsig k hk hki hkj]

/-- Swapping operand order preserves the gate kind and maps a right-input
blocking value to a left-input blocking value. -/
theorem table_swap_swap (T : Table) : T.swap.swap = T := by
  rcases T with ⟨a,b,c,d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem table_swap_nonlinear (T : Table) : T.swap.nonlinear = T.nonlinear := by
  rcases T with ⟨a,b,c,d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem table_swap_blocksLeft (T : Table) (b : Bool) :
    T.swap.blocksLeft b = T.blocksRight b := by
  rcases T with ⟨a,c,d,e⟩
  cases a <;> cases c <;> cases d <;> cases e <;> cases b <;> decide

/-- A physical gate reading the two inputs in either order, with `T`
always oriented as a function of `(i,j)`. -/
def OrientedPairGate {n : Nat} (C : OpenCircuit n) (k : Nat)
    (i j : Fin n) (T : Table) : Prop :=
  C.gateAt k = some (T, i.val, j.val) ∨
  C.gateAt k = some (T.swap, j.val, i.val)

/-- A gate with reversed physical operands is represented by its swapped table. -/
theorem orientedPairGate_of_reversed {n : Nat} (C : OpenCircuit n) (k : Nat)
    (i j : Fin n) (g : Table) (h : C.gateAt k = some (g, j.val, i.val)) :
    C.OrientedPairGate k i j g.swap := by
  right
  simpa only [table_swap_swap] using h

theorem orientedPairGate_value {n : Nat} (C : OpenCircuit n) (k : Nat)
    (i j : Fin n) (T : Table) (h : C.OrientedPairGate k i j T)
    (x : Fin n → Bool) : C.valueAt x k = T.eval (x i) (x j) := by
  rcases h with h | h
  · rw [C.valueAt_gate x h, C.valueAt_input, C.valueAt_input]
  · rw [C.valueAt_gate x h, C.valueAt_input, C.valueAt_input, Table.swap_eval]

theorem orientedPairGate_users {n : Nat} (C : OpenCircuit n) (k : Nat)
    (i j : Fin n) (T : Table) (h : C.OrientedPairGate k i j T) :
    k ∈ C.users i.val ∧ k ∈ C.users j.val := by
  rcases h with h | h
  · exact ⟨C.mem_users.mpr ⟨T, _, _, h, Or.inl rfl⟩,
      C.mem_users.mpr ⟨T, _, _, h, Or.inr rfl⟩⟩
  · exact ⟨C.mem_users.mpr ⟨T.swap, _, _, h, Or.inr rfl⟩,
      C.mem_users.mpr ⟨T.swap, _, _, h, Or.inl rfl⟩⟩

/-- S4 forces the joint state of two readers to be injective for all operand
orientations, even when arbitrary other gates occur between them. -/
theorem pairFour_oriented_gate_state_injective {n : Nat} (C : OpenCircuit n)
    (i j : Fin n) (hij : i ≠ j) (t u : Nat) (T U : Table)
    (ht : C.OrientedPairGate t i j T) (hu : C.OrientedPairGate u i j U)
    (hreadi : ∀ k ∈ C.users i.val, k = t ∨ k = u)
    (hreadj : ∀ k ∈ C.users j.val, k = t ∨ k = u)
    (hout : ∀ k b, C.outWire = some (k,b) → k ≠ i.val ∧ k ≠ j.val)
    (hfour : PairFour C.eval i j) :
    Function.Injective (fun p : Bool × Bool => (T.eval p.1 p.2, U.eval p.1 p.2)) := by
  intro p q hpq
  apply hfour
  funext x
  apply C.eval_eq_of_two_gate_cut i j t u (setPair x i j p.1 p.2) (setPair x i j q.1 q.2)
  · intro z hzi hzj; simp [setPair, hzi, hzj]
  · exact hreadi
  · exact hreadj
  · rw [C.orientedPairGate_value t i j T ht, C.orientedPairGate_value t i j T ht]
    simp only [setPair, ↓reduceIte, Ne.symm hij]
    exact congrArg Prod.fst hpq
  · rw [C.orientedPairGate_value u i j U hu, C.orientedPairGate_value u i j U hu]
    simp only [setPair, ↓reduceIte, Ne.symm hij]
    exact congrArg Prod.snd hpq
  · exact hout

/-- The corner case is excluded for all operand orientations in a reduced
circuit. The two-gate reader-set assumptions are the paper's tight branch. -/
theorem no_opposite_blocking_oriented_reduced {n : Nat} (C : OpenCircuit n)
    (hC : C.Reduced) (i j : Fin n) (hij : i ≠ j) (t u : Nat) (T U : Table) (ε : Bool)
    (ht : C.OrientedPairGate t i j T) (hu : C.OrientedPairGate u i j U)
    (hreadi : ∀ k ∈ C.users i.val, k = t ∨ k = u)
    (hreadj : ∀ k ∈ C.users j.val, k = t ∨ k = u)
    (hfour : PairFour C.eval i j)
    (hT : T.nonlinear = true) (hU : U.nonlinear = true)
    (hTb : T.blocksLeft ε = true) (hUb : U.blocksLeft (!ε) = true) : False := by
  obtain ⟨hti, htj⟩ := C.orientedPairGate_users t i j T ht
  have hi0 := C.reduced_outIs_zero_of_user hC i.val (Finset.ne_empty_of_mem hti)
  have hj0 := C.reduced_outIs_zero_of_user hC j.val (Finset.ne_empty_of_mem htj)
  have hout : ∀ k b, C.outWire = some (k,b) → k ≠ i.val ∧ k ≠ j.val := by
    intro k b hk
    constructor <;> intro he
    · simp [outIs, hk, he] at hi0
    · simp [outIs, hk, he] at hj0
  exact opposite_blocking_gate_state_not_injective T U ε hT hU hTb hUb
    (C.pairFour_oriented_gate_state_injective i j hij t u T U ht hu hreadi hreadj hout hfour)

/-- The S4 pair cofactors force the two reader gates' joint state map to be
injective, even when other gates occur between the readers. -/
theorem pairFour_two_gate_state_injective {n : Nat} (C : OpenCircuit n)
    (i j : Fin n) (hij : i ≠ j) (t u : Nat) (T U : Table)
    (htgate : C.gateAt t = some (T, i.val, j.val))
    (hugate : C.gateAt u = some (U, i.val, j.val))
    (hreadi : ∀ k ∈ C.users i.val, k = t ∨ k = u)
    (hreadj : ∀ k ∈ C.users j.val, k = t ∨ k = u)
    (hout : ∀ k b, C.outWire = some (k,b) → k ≠ i.val ∧ k ≠ j.val)
    (hfour : PairFour C.eval i j) :
    Function.Injective (fun p : Bool × Bool => (T.eval p.1 p.2, U.eval p.1 p.2)) := by
  intro p q hpq
  apply hfour
  funext x
  apply C.eval_eq_of_two_gate_cut i j t u (setPair x i j p.1 p.2) (setPair x i j q.1 q.2)
  · intro z hzi hzj
    simp [setPair, hzi, hzj]
  · exact hreadi
  · exact hreadj
  · rw [C.valueAt_gate _ htgate, C.valueAt_gate _ htgate]
    simp only [C.valueAt_input, setPair, ↓reduceIte, Ne.symm hij]
    exact congrArg Prod.fst hpq
  · rw [C.valueAt_gate _ hugate, C.valueAt_gate _ hugate]
    simp only [C.valueAt_input, setPair, ↓reduceIte, Ne.symm hij]
    exact congrArg Prod.snd hpq
  · exact hout

/-- The paper's corner exclusion for arbitrary spacing of the two common
reader gates, under its explicit reader and output conditions. -/
theorem no_opposite_blocking_two_gate_cut {n : Nat} (C : OpenCircuit n)
    (i j : Fin n) (hij : i ≠ j) (t u : Nat) (T U : Table) (ε : Bool)
    (htgate : C.gateAt t = some (T, i.val, j.val))
    (hugate : C.gateAt u = some (U, i.val, j.val))
    (hreadi : ∀ k ∈ C.users i.val, k = t ∨ k = u)
    (hreadj : ∀ k ∈ C.users j.val, k = t ∨ k = u)
    (hout : ∀ k b, C.outWire = some (k,b) → k ≠ i.val ∧ k ≠ j.val)
    (hfour : PairFour C.eval i j)
    (hT : T.nonlinear = true) (hU : U.nonlinear = true)
    (hTb : T.blocksLeft ε = true) (hUb : U.blocksLeft (!ε) = true) : False := by
  exact opposite_blocking_gate_state_not_injective T U ε hT hU hTb hUb
    (C.pairFour_two_gate_state_injective i j hij t u T U htgate hugate hreadi hreadj hout hfour)

/-- In a reduced circuit, the paper's common-reader case is excluded without
an independent output-wire assumption. -/
theorem no_opposite_blocking_two_gate_cut_reduced {n : Nat} (C : OpenCircuit n)
    (hC : C.Reduced) (i j : Fin n) (hij : i ≠ j) (t u : Nat) (T U : Table) (ε : Bool)
    (htgate : C.gateAt t = some (T, i.val, j.val))
    (hugate : C.gateAt u = some (U, i.val, j.val))
    (hreadi : ∀ k ∈ C.users i.val, k = t ∨ k = u)
    (hreadj : ∀ k ∈ C.users j.val, k = t ∨ k = u)
    (hfour : PairFour C.eval i j)
    (hT : T.nonlinear = true) (hU : U.nonlinear = true)
    (hTb : T.blocksLeft ε = true) (hUb : U.blocksLeft (!ε) = true) : False := by
  have hti : t ∈ C.users i.val := C.mem_users.mpr ⟨T, _, _, htgate, Or.inl rfl⟩
  have htj : t ∈ C.users j.val := C.mem_users.mpr ⟨T, _, _, htgate, Or.inr rfl⟩
  have hi0 := C.reduced_outIs_zero_of_user hC i.val (Finset.ne_empty_of_mem hti)
  have hj0 := C.reduced_outIs_zero_of_user hC j.val (Finset.ne_empty_of_mem htj)
  have hout : ∀ k b, C.outWire = some (k,b) → k ≠ i.val ∧ k ≠ j.val := by
    intro k b hk
    constructor <;> intro he
    · simp [outIs, hk, he] at hi0
    · simp [outIs, hk, he] at hj0
  exact C.no_opposite_blocking_two_gate_cut i j hij t u T U ε htgate hugate
    hreadi hreadj hout hfour hT hU hTb hUb

end OpenCircuit
end SatLowerBound
