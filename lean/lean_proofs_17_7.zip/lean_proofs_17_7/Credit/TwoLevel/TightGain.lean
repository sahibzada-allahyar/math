import Credit.TwoLevel.GainedChain

/-! The surviving-chain gain in the tight branch of Main Lemma B. -/
namespace SatLowerBound
namespace MAContext
open OpenCircuit

/-- If `y` originally has exactly the two readers `T,V`, the restriction
makes `T` constant, and the nonlinear chain `V → V₂` survives, then `y`
gains both credits. -/
theorem tight_surviving_chain_gain {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x y : Fin n) (hxy : x ≠ y) (b : Bool)
    (T V V₂ : Nat) (hTV : T ≠ V) (husersY : C.users y.val = {T,V})
    (hTc : (C.resAt (singleRes x b) T).isConst = true)
    {gV : Table} {aV dV : Nat} (hgV : C.gateAt V = some (gV,aV,dV))
    (hVnl : gV.nonlinear = true) (hVkept : C.isKept (singleRes x b) V = true)
    (husersV : C.users V = {V₂})
    {g₂ : Table} {a₂ d₂ : Nat} (hg₂ : C.gateAt V₂ = some (g₂,a₂,d₂))
    (hg₂nl : g₂.nonlinear = true) (hV₂kept : C.isKept (singleRes x b) V₂ = true) :
    2 ≤ C.credit2Gained (C.restrict (singleSubst x b)) := by
  have hVy : V ∈ C.users y.val := by rw [husersY]; simp
  have hV₂ : V₂ ∈ C.users V := by rw [husersV]; simp
  obtain ⟨g',a',d',hg',habV⟩ := C.mem_users.mp hVy
  rw [hgV] at hg'
  cases hg'
  have hVbound := C.gateAt_bounds hgV
  have hVres : C.resAt (singleRes x b) V = .lit V false := C.resAt_kept _ hVkept
  have hyres : C.resAt (singleRes x b) y.val = .lit y.val false := by
    rw [C.resAt_single_input x b y]
    simp [Ne.symm hxy]
  have hyhit : (C.resAt (singleRes x b) y.val).hits y.val = true := by
    rw [hyres]
    exact (Res.hits_lit _ _ _).mpr rfl
  have hnopass : ∀ k, n ≤ k → k < n + C.size →
      (C.resAt (singleRes x b) k).hits y.val = true → k ∈ (∅ : Finset Nat) := by
    apply C.passers_subset (singleRes x b) y.val y.isLt (singleRes_hits x b y.val) ∅
      (n + C.size)
    intro k g a d _ hk _ hread
    have hky : k ∈ C.users y.val := by
      rcases hread with hr | hr | hr | hr
      · exact C.mem_users.mpr ⟨g,a,d,hk,Or.inl hr⟩
      · simp at hr
      · exact C.mem_users.mpr ⟨g,a,d,hk,Or.inr hr⟩
      · simp at hr
    rw [husersY, Finset.mem_insert, Finset.mem_singleton] at hky
    rcases hky with he | he
    · rw [he]
      cases hres : C.resAt (singleRes x b) T with
      | const c => rfl
      | lit s neg => rw [hres] at hTc; simp [Res.isConst] at hTc
    · rw [he, hVres, Bool.eq_false_iff]
      intro hh
      rw [Res.hits_lit] at hh
      have := y.isLt
      omega
  have hother : ∀ o, o < n + C.size → o ≠ y.val →
      (C.resAt (singleRes x b) o).hits y.val = false := by
    intro o ho hne
    rw [Bool.eq_false_iff]
    intro hh
    by_cases hon : o < n
    · have hin : C.resAt (singleRes x b) o = singleRes x b ⟨o,hon⟩ :=
        C.resAt_input (singleRes x b) ⟨o,hon⟩
      rw [hin] at hh
      exact hne (singleRes_hits x b y.val ⟨o,hon⟩ hh)
    · have := hnopass o (by omega) ho hh
      simp at this
  have hyD : C.keptIsD (singleRes x b) y.val = true := by
    obtain ⟨_,hne,_⟩ := h.gate_facts hgV
    apply C.keptIsD_of_unique_slot (singleRes x b) y.val V gV aV dV hgV hVkept hVnl
    · rcases habV with ha | hd
      · have hdne : dV ≠ y.val := by rw [← ha]; exact Ne.symm hne
        rw [ha, hyhit, hother dV (by omega) hdne]
        rfl
      · have hane : aV ≠ y.val := by rw [← hd]; exact hne
        rw [hd, hyhit, hother aV (by omega) hane]
        rfl
    · intro k g a d hkV hk hkk
      have hkT : k ≠ T := by
        intro he
        rw [he] at hkk
        rw [C.resAt_kept _ hkk] at hTc
        simp [Res.isConst] at hTc
      obtain ⟨_,_,ha,hd⟩ := C.gateAt_bounds hk
      have hnot : ∀ o, (a = o ∨ d = o) → o ≠ y.val := by
        intro o ho he
        rw [he] at ho
        have hm : k ∈ C.users y.val := C.mem_users.mpr ⟨g,a,d,hk,ho⟩
        rw [husersY, Finset.mem_insert, Finset.mem_singleton] at hm
        rcases hm with hm | hm
        · exact hkT hm
        · exact hkV hm
      exact ⟨hother a (by omega) (hnot a (Or.inl rfl)),
        hother d (by omega) (hnot d (Or.inr rfl))⟩
    · intro k neg hk
      obtain ⟨k₀,neg₀,hw,hk₀⟩ := h.out_gate
      have hkk : k₀ = k := by
        rw [hw] at hk
        simp only [Option.some.injEq, Prod.mk.injEq] at hk
        exact hk.1
      exact hother k (C.outWire_bound hk) (by have := y.isLt; omega)
  have hVout : C.outIs V = 0 :=
    C.reduced_outIs_zero_of_user h.reduced V (Finset.ne_empty_of_mem hV₂)
  have hVrefs : C.refCount V = 1 := by
    rw [C.refCount_eq h.distinct, husersV, Finset.card_singleton, hVout]
  obtain ⟨g'',a'',d'',hg'',hab₂⟩ := C.mem_users.mp hV₂
  rw [hg₂] at hg''
  cases hg''
  have hVD : C.isD V = true := (C.isD_iff V).mpr ⟨hVrefs,V₂,g₂,a₂,d₂,hg₂,hab₂,hg₂nl⟩
  have hVkD : C.keptIsD (singleRes x b) V = true := by
    apply C.keptIsD_of_kept_gate (fun z => decide (z = x)) (fun _ => b)
      h.reduced V hVbound.1 hVD hVkept
    intro k hk
    rw [husersV, Finset.mem_singleton] at hk
    rw [hk]
    exact hV₂kept
  have hyold : C.isD y.val = false := by
    cases hd : C.isD y.val with
    | false => rfl
    | true =>
      have hc : C.refCount y.val = 2 := by
        rw [h.refCount_input y, husersY, Finset.card_pair hTV]
      have hd' := ((C.isD_iff y.val).mp hd).1
      omega
  have hhit : (C.resAt (singleRes x b) aV).hits y.val = true ∨
      (C.resAt (singleRes x b) dV).hits y.val = true := by
    rcases habV with he | he
    · left; rw [he]; exact hyhit
    · right; rw [he]; exact hyhit
  have hgain := C.fix_gain_two_of_kept_chain (fun z => decide (z = x)) (fun _ => b)
    y V gV aV dV hyold hgV hVkept hyD hVkD hhit
  simpa [← singleSubst_eq_fixSubst, singleRes] using hgain

/-- The surviving-chain configuration and three role-free nonlinear
eliminations yield the fourteen-unit tight-branch drop. -/
theorem tight_surviving_chain_drop {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x y : Fin n) (hxy : x ≠ y) (b : Bool)
    (hx2 : 2 ≤ C.refCount x.val) (E : Finset Nat) (hcard : 3 ≤ E.card)
    (hE : ∀ k ∈ E, C.isAliased (singleRes x b) k = true ∧
      (C.tableAt k).parity = false ∧
      (k ∈ C.users x.val ∨ ∃ P g a d, C.gateAt P = some (g,a,d) ∧
        a < n ∧ d < n ∧ k ∈ C.users P))
    (T V V₂ : Nat) (hTV : T ≠ V) (husersY : C.users y.val = {T,V})
    (hTc : (C.resAt (singleRes x b) T).isConst = true)
    {gV : Table} {aV dV : Nat} (hgV : C.gateAt V = some (gV,aV,dV))
    (hVnl : gV.nonlinear = true) (hVkept : C.isKept (singleRes x b) V = true)
    (husersV : C.users V = {V₂})
    {g₂ : Table} {a₂ d₂ : Nat} (hg₂ : C.gateAt V₂ = some (g₂,a₂,d₂))
    (hg₂nl : g₂.nonlinear = true) (hV₂kept : C.isKept (singleRes x b) V₂ = true) :
    (C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2 := by
  have hgain := h.tight_surviving_chain_gain x y hxy b T V V₂ hTV husersY hTc
    hgV hVnl hVkept husersV hg₂ hg₂nl hV₂kept
  exact h.tight_drop_of_three_rolefree_and_two_gains x b hx2 E hcard hE hgain

end MAContext
end SatLowerBound
