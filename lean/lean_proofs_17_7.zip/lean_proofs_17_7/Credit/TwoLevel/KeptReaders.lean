import Credit.TwoLevel.KeptGate

/-! Correspondence between reader counts of an original retained gate and its
reindexed counterpart after restriction. -/
namespace SatLowerBound
namespace OpenCircuit

private theorem rel_hits_false_of_ge {n m : Nat} (σ : Fin n → Signal m)
    (ρ : Fin n → Res) (φ : Fin m → Nat) (hφn : ∀ w, φ w < n)
    (hrel : ∀ k, ResRel φ (σ k) (ρ k)) (s : Nat) (hs : n ≤ s) (i : Fin n) :
    (ρ i).hits s = false := by
  cases hσ : σ i with
  | constant v =>
    have he := TransferAux.rel_const (hσ ▸ hrel i)
    rw [he]
    rfl
  | wire w neg =>
    have he := TransferAux.rel_wire (hσ ▸ hrel i)
    rw [he, Bool.eq_false_iff]
    intro hh
    have heq := (Res.hits_lit _ _ _).mp hh
    have hlt := hφn w
    omega

/-- A retained gate's new index has the same number and type of readers as
its original signal in the restriction trace. -/
theorem restrict_kept_readers {n m : Nat} (C : OpenCircuit n)
    (σ : Fin n → Signal m) (ρ : Fin n → Res) (φ : Fin m → Nat)
    (hφ : Function.Injective φ) (hφn : ∀ w, φ w < n)
    (hrel : ∀ k, ResRel φ (σ k) (ρ k))
    (s : Nat) (g : Table) (a b : Nat) (hgate : C.gateAt s = some (g,a,b))
    (hkept : C.isKept ρ s = true) :
    ∃ k g' a' b', (C.restrict σ).gateAt k = some (g',a',b') ∧
      (C.restrict σ).refCount k = C.keptRefs ρ s ∧
      (C.restrict σ).firstUserNL k = C.keptFirstNL ρ s ∧
      (∀ w : Fin m, (a' = w.val ∨ b' = w.val) ↔
        ((C.resAt ρ a).hits (φ w) = true ∨ (C.resAt ρ b).hits (φ w) = true)) := by
  induction C generalizing m with
  | output o => simp [gateAt] at hgate
  | @gate n h i j rest ih =>
    have hsn : n ≤ s := (gate h i j rest).gateAt_bounds hgate |>.1
    have hhi := rel_hits_false_of_ge σ ρ φ hφn hrel s hsn i
    have hhj := rel_hits_false_of_ge σ ρ φ hφn hrel s hsn j
    have hrefs : (gate h i j rest).keptRefs ρ s =
        rest.keptRefs (FlatKeptAux.tailRes h i j ρ) s := by
      rw [FlatKeptAux.keptRefs_cons]
      simp [hhi, hhj, indicator]
    have hfirst : (gate h i j rest).keptFirstNL ρ s =
        rest.keptFirstNL (FlatKeptAux.tailRes h i j ρ) s := by
      rw [FlatKeptAux.keptFirstNL_cons]
      simp [hhi, hhj]
    rcases hsg : simplifyGate h (σ i) (σ j) with sig | ⟨q, k, l⟩
    · obtain ⟨r, hstep, hsr⟩ := TransferAux.step_of_alias φ hφ h (hrel i) (hrel j) hsg
      have hsne : s ≠ n := by
        intro he; subst s
        rw [FlatKeptAux.isKept_cons_head, hstep] at hkept
        contradiction
      have htail : rest.gateAt s = some (g,a,b) := by
        rw [← gateAt_tail h i j rest hsne]; exact hgate
      have hkeepTail : rest.isKept (appendValue ρ r) s = true := by
        rw [FlatKeptAux.isKept_cons_tail h i j rest ρ hsne] at hkept
        simpa [FlatKeptAux.tailRes, hstep] using hkept
      obtain ⟨k',g',a',b',hk',hr,hf,hread⟩ := ih (extendSubst σ sig) (appendValue ρ r) φ hφ
        (fun w => Nat.lt_succ_of_lt (hφn w)) (TransferAux.rel_extend hrel hsr)
        htail hkeepTail
      refine ⟨k',g',a',b', ?_, ?_, ?_, ?_⟩
      · simpa only [restrict, hsg] using hk'
      · simpa only [restrict, hsg, hrefs, FlatKeptAux.tailRes, hstep, Option.getD_some] using hr
      · simpa only [restrict, hsg, hfirst, FlatKeptAux.tailRes, hstep, Option.getD_some] using hf
      · intro w
        simpa only [FlatKeptAux.resAt_cons, FlatKeptAux.tailRes, hstep, Option.getD_some] using hread w
    · obtain ⟨hstep, x, y, hq, hρi, hρj⟩ :=
        TransferAux.step_of_binary φ hφ h (hrel i) (hrel j) hsg
      subst hq
      by_cases hs : s = n
      · subst s
        have htrans := rest.restrict_transfer (liftSubst σ) (appendValue ρ (.lit n false))
          (appendValue φ n) (TransferAux.appendValue_injective hφ hφn)
          (TransferAux.appendValue_lt hφn) (TransferAux.rel_lift hrel)
        have hr := htrans.2.2.1 (Fin.last m)
        have hf := htrans.2.2.2 (Fin.last m)
        rw [Fin.val_last, TransferAux.appendValue_last] at hr hf
        refine ⟨m, twist h x y, k.val, l.val, ?_, ?_, ?_, ?_⟩
        · simp only [restrict, hsg, gateAt_head]
        · simp only [restrict, hsg, refCount]
          have hk : k.val ≠ m := by have := k.isLt; omega
          have hl : l.val ≠ m := by have := l.isLt; omega
          simp only [hk, hl, ↓reduceIte, Nat.zero_add]
          rw [hrefs]
          simpa [FlatKeptAux.tailRes, hstep] using hr
        · simp only [restrict, hsg, firstUserNL]
          have hk : k.val ≠ m := by have := k.isLt; omega
          have hl : l.val ≠ m := by have := l.isLt; omega
          simp only [hk, hl, or_self, ↓reduceIte]
          rw [hfirst]
          simpa [FlatKeptAux.tailRes, hstep] using hf
        · intro w
          rw [gateAt_head] at hgate
          simp only [Option.some.injEq, Prod.mk.injEq] at hgate
          obtain ⟨rfl, rfl, rfl⟩ := hgate
          rw [(gate h i j rest).resAt_input ρ i, (gate h i j rest).resAt_input ρ j,
            hρi, hρj, TransferAux.hits_rel hφ, TransferAux.hits_rel hφ]
          simp only [decide_eq_true_eq]
      · have htail : rest.gateAt s = some (g,a,b) := by
          rw [← gateAt_tail h i j rest hs]; exact hgate
        have hkeepTail : rest.isKept (appendValue ρ (.lit n false)) s = true := by
          rw [FlatKeptAux.isKept_cons_tail h i j rest ρ hs] at hkept
          simpa [FlatKeptAux.tailRes, hstep] using hkept
        obtain ⟨k', g', a', b', hk', hr, hf, hread⟩ :=
          ih (liftSubst σ) (appendValue ρ (.lit n false)) (appendValue φ n)
            (TransferAux.appendValue_injective hφ hφn) (TransferAux.appendValue_lt hφn)
            (TransferAux.rel_lift hrel) htail hkeepTail
        have hkge : m + 1 ≤ k' := ((rest.restrict (liftSubst σ)).gateAt_bounds hk').1
        have hkne : k' ≠ m := by omega
        have hki : k.val ≠ k' := by have := k.isLt; omega
        have hli : l.val ≠ k' := by have := l.isLt; omega
        refine ⟨k', g', a', b', ?_, ?_, ?_, ?_⟩
        · simp only [restrict, hsg]; rw [gateAt_tail _ _ _ _ hkne]; exact hk'
        · simp only [restrict, hsg, refCount, hki, hli, ↓reduceIte, Nat.zero_add]
          rw [hrefs]
          simpa [FlatKeptAux.tailRes, hstep] using hr
        · simp only [restrict, hsg, firstUserNL, hki, hli, or_self, ↓reduceIte]
          rw [hfirst]
          simpa [FlatKeptAux.tailRes, hstep] using hf
        · intro w
          have hh := hread w.castSucc
          rw [Fin.val_castSucc, TransferAux.appendValue_castSucc] at hh
          simpa only [FlatKeptAux.resAt_cons, FlatKeptAux.tailRes, hstep, Option.getD_none] using hh

/-- Under fixed-input restrictions the retained gate has a target index whose
D-status agrees exactly with the original-index restriction trace. -/
theorem fix_kept_reader_status {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool)
    (s : Nat) (g : Table) (a b : Nat) (hgate : C.gateAt s = some (g,a,b))
    (hkept : C.isKept (fixRes P c) s = true) :
    ∃ k g' a' b', (C.restrict (fixSubst P c)).gateAt k = some (g',a',b') ∧
      (C.restrict (fixSubst P c)).isD k = C.keptIsD (fixRes P c) s := by
  obtain ⟨k,g',a',b',hgate',href,hfirst,_⟩ :=
    C.restrict_kept_readers (fixSubst P c) (fixRes P c) Fin.val
      Fin.val_injective (fun w => w.isLt) (fixSubst_rel P c) s g a b hgate hkept
  refine ⟨k,g',a',b',hgate',?_⟩
  simp only [isD, keptIsD, href, hfirst]

end OpenCircuit
end SatLowerBound
