import Credit.TwoLevel.UnreducedAccounting
import Credit.TwoLevel.NormalizeTriangle

/-! Credit allocation for restrictions that may fix credited inputs, as in
the block-retirement step of Theorem 8.1. -/
namespace SatLowerBound
namespace OpenCircuit

/-- Fixed inputs charge their remaining second credit to the first gate;
free inputs charge their second gate. -/
def retirementSecondTarget {n : Nat} (P : Fin n → Bool) (W V : Fin n → Nat) : Fin n → Nat :=
  fun z => if P z then W z else V z

/-- A second charge is at most one, reaches an eliminated gate, and only
arises from an original D-star input, including when that input is fixed. -/
theorem retirement_second_charge_bound {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (W V : Fin n → Nat)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → P z = false →
      Essential (C.restrict (fixSubst P c)).eval z) (z : Fin n) :
    C.secondGateCharge (C.restrict (fixSubst P c)) (fixRes P c) W z ≤
      indicator (C.isDStar z.val) *
        indicator (C.isAliased (fixRes P c) (retirementSecondTarget P W V z)) := by
  have hloss : C.credit2 z - (C.restrict (fixSubst P c)).credit2 z ≤
      indicator (C.isAliased (fixRes P c) (W z)) +
      indicator (C.isDStar z.val) *
        indicator (C.isAliased (fixRes P c) (retirementSecondTarget P W V z)) := by
    cases hd : C.isD z.val with
    | false =>
      have hs : C.isDStar z.val = false := by simp [isDStar,hd]
      simp [credit2,indicator,hd,hs]
    | true =>
      cases hp : P z with
      | true =>
        have ⟨hal,_⟩ := C.fixed_input_credit_removed P c z hp (W z) (hw z hd)
        cases hs : C.isDStar z.val <;>
          simp [credit2,indicator,hd,hs,hal,retirementSecondTarget,hp]
      | false =>
        cases hs : C.isDStar z.val with
        | false =>
          have h := C.free_one_credit_loss_le_eliminated P c z hp (W z) hd hs (hw z hd)
          simpa [indicator,hs,retirementSecondTarget,hp] using h
        | true =>
          have h := C.free_two_credit_loss_le_eliminated_distinct P c hDistinct z hp (W z) (V z)
            hs (hw z hd) (hv z hs) (hess z hs hp)
          simpa [indicator,hs,retirementSecondTarget,hp] using h
  simp only [secondGateCharge,firstGateCharge,Nat.min_def]
  split <;> omega

/-- The exact credit loss is the sum of the retirement allocation over gates. -/
theorem retirement_loss_eq_charges {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (W V : Fin n → Nat)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → P z = false →
      Essential (C.restrict (fixSubst P c)).eval z) :
    C.credit2Lost (C.restrict (fixSubst P c)) =
      ∑ k ∈ Finset.range (n+C.size),
        (C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k +
         C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W (retirementSecondTarget P W V) k) := by
  let D := C.restrict (fixSubst P c)
  let ρ := fixRes P c
  let Q := retirementSecondTarget P W V
  let R := Finset.range (n+C.size)
  have hf : (∑ z : Fin n, C.firstGateCharge D ρ W z) =
      ∑ k ∈ R, C.gateFirstCharge D ρ W k := by
    unfold gateFirstCharge
    rw [Finset.sum_fiberwise_eq_sum_filter]
    symm
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro z _ hz
    have hnot : W z ∉ R := by simpa using hz
    have hd : C.isD z.val = false := by
      apply Bool.eq_false_iff.mpr
      intro hd
      exact hnot (Finset.mem_range.mpr (C.reader_index_lt (hw z hd)))
    have hbound := C.first_charge_bound D ρ W z
    simp [indicator,hd] at hbound
    exact hbound
  have hs : (∑ z : Fin n, C.secondGateCharge D ρ W z) =
      ∑ k ∈ R, C.gateSecondCharge D ρ W Q k := by
    unfold gateSecondCharge
    rw [Finset.sum_fiberwise_eq_sum_filter]
    symm
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro z _ hz
    have hnot : Q z ∉ R := by simpa using hz
    have hd : C.isDStar z.val = false := by
      apply Bool.eq_false_iff.mpr
      intro hd
      have hq : Q z ∈ R := by
        cases hp : P z with
        | false =>
          have hb := C.reader_index_lt (hv z hd)
          simpa [Q,R,retirementSecondTarget,hp] using (Finset.mem_range.mpr hb)
        | true =>
          have hb := C.reader_index_lt (hw z (C.isD_of_isDStar z.val hd))
          simpa [Q,R,retirementSecondTarget,hp] using (Finset.mem_range.mpr hb)
      exact hnot hq
    have hbound := C.retirement_second_charge_bound P c hDistinct W V hw hv hess z
    change C.secondGateCharge D ρ W z ≤ indicator (C.isDStar z.val) * indicator (C.isAliased ρ (Q z)) at hbound
    simp [indicator,hd] at hbound
    exact hbound
  have htotal := C.credit2Lost_eq_allocated D ρ W
  rw [Finset.sum_add_distrib,hf,hs,← Finset.sum_add_distrib] at htotal
  exact htotal

/-- A second charge sharing a first-role gate must belong to that same input;
all other possibilities are excluded by the manuscript's role lemma. -/
theorem retirement_second_role_eq_first {n : Nat} (C : OpenCircuit n)
    (P : Fin n → Bool) (hsafe : C.DGateSafe)
    (f : (Fin n → Bool) → Bool) (hc : ∀ v, C.eval v = f v) (hE1 : E1 f)
    (W V : Fin n → Nat)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (horig : ∀ z, C.isDStar z.val = true → Essential f z)
    (z₀ z : Fin n) (k : Nat) (hD : C.isD z₀.val = true) (hW : W z₀ = k)
    (hstar : C.isDStar z.val = true) (hQ : retirementSecondTarget P W V z = k) : z = z₀ := by
  have hd := C.isD_of_isDStar z.val hstar
  cases hp : P z with
  | true =>
    have hwk : W z = k := by simpa [retirementSecondTarget,hp] using hQ
    apply C.first_reader_unique hsafe hd hD (hw z hd)
    simpa [← hwk,hW] using hw z₀ hD
  | false =>
    have hvk : V z = k := by simpa [retirementSecondTarget,hp] using hQ
    have hfirst : k ∈ C.users z₀.val := by simpa [hW] using hw z₀ hD
    have hsecond : k ∈ C.users (W z) := by simpa [hvk] using hv z hstar
    obtain ⟨g,a,b,hgate,hab⟩ := C.mem_users.mp hfirst
    exact False.elim (C.second_role_has_no_primary_unreduced f hc hE1 z (horig z hstar)
      (W z) k hstar (hw z hd) hsecond g a b hgate z₀ hab)

/-- The total second charge at a gate is bounded by the number of credit
chains assigned to that gate. -/
theorem retirement_second_charge_le_card {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (W V : Fin n → Nat)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → P z = false →
      Essential (C.restrict (fixSubst P c)).eval z) (k : Nat) :
    C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W (retirementSecondTarget P W V) k ≤
      ((Finset.univ : Finset (Fin n)).filter
        (fun z => C.isDStar z.val = true ∧ retirementSecondTarget P W V z = k)).card := by
  let D := C.restrict (fixSubst P c)
  let ρ := fixRes P c
  let Q := retirementSecondTarget P W V
  let A := (Finset.univ : Finset (Fin n)).filter (fun z => Q z = k)
  let B := (Finset.univ : Finset (Fin n)).filter (fun z => C.isDStar z.val = true ∧ Q z = k)
  have hsub : B ⊆ A := by
    intro z hz
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,(Finset.mem_filter.mp hz).2.2⟩
  have heq : (∑ z ∈ B, C.secondGateCharge D ρ W z) =
      ∑ z ∈ A, C.secondGateCharge D ρ W z := by
    apply Finset.sum_subset hsub
    intro z hzA hzB
    have hQ := (Finset.mem_filter.mp hzA).2
    have hstar : C.isDStar z.val = false := by
      apply Bool.eq_false_iff.mpr
      intro hs
      exact hzB (Finset.mem_filter.mpr ⟨Finset.mem_univ _,hs,hQ⟩)
    have hh := C.retirement_second_charge_bound P c hDistinct W V hw hv hess z
    change C.secondGateCharge D ρ W z ≤ indicator (C.isDStar z.val) * indicator (C.isAliased ρ (Q z)) at hh
    simp [indicator,hstar] at hh
    omega
  have hsum : (∑ z ∈ B, C.secondGateCharge D ρ W z) ≤ B.card := by
    have hh := Finset.sum_le_card_nsmul B (fun z => C.secondGateCharge D ρ W z) 1 (by
      intro z _
      have hb := C.retirement_second_charge_bound P c hDistinct W V hw hv hess z
      change C.secondGateCharge D ρ W z ≤ indicator (C.isDStar z.val) * indicator (C.isAliased ρ (Q z)) at hb
      have hp : indicator (C.isDStar z.val) * indicator (C.isAliased ρ (Q z)) ≤ 1 := by
        cases C.isDStar z.val <;> cases C.isAliased ρ (Q z) <;> decide
      exact le_trans hb hp)
    simpa using hh
  change (∑ z ∈ A, C.secondGateCharge D ρ W z) ≤ B.card
  rw [← heq]
  exact hsum

/-- At most two units of retirement credit can be charged to one gate. -/
theorem retirement_gate_charge_le_two {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (hsafe : C.DGateSafe)
    (f : (Fin n → Bool) → Bool) (hc : ∀ v, C.eval v = f v) (hE1 : E1 f)
    (W V : Fin n → Nat)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → P z = false →
      Essential (C.restrict (fixSubst P c)).eval z)
    (horig : ∀ z, C.isDStar z.val = true → Essential f z)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b)) :
    C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k +
      C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W (retirementSecondTarget P W V) k ≤ 2 := by
  let D := C.restrict (fixSubst P c)
  let ρ := fixRes P c
  let Q := retirementSecondTarget P W V
  let B := (Finset.univ : Finset (Fin n)).filter (fun z => C.isDStar z.val = true ∧ Q z = k)
  have hsecond : C.gateSecondCharge D ρ W Q k ≤ B.card :=
    C.retirement_second_charge_le_card P c hDistinct W V hw hv hess k
  change C.gateFirstCharge D ρ W k + C.gateSecondCharge D ρ W Q k ≤ 2
  by_cases hfirst : ∃ z, C.isD z.val = true ∧ W z = k
  · obtain ⟨z₀,hD,hW⟩ := hfirst
    have hcard : B.card ≤ 1 := by
      apply Finset.card_le_one.mpr
      intro z₁ hz₁ z₂ hz₂
      have h₁ := (Finset.mem_filter.mp hz₁).2
      have h₂ := (Finset.mem_filter.mp hz₂).2
      have he₁ := C.retirement_second_role_eq_first P hsafe f hc hE1 W V hw hv horig
        z₀ z₁ k hD hW h₁.1 h₁.2
      have he₂ := C.retirement_second_role_eq_first P hsafe f hc hE1 W V hw hv horig
        z₀ z₂ k hD hW h₂.1 h₂.2
      exact he₁.trans he₂.symm
    have hfirst := C.gateFirstCharge_le_one D ρ hsafe W hw k
    omega
  · have hfirstzero : C.gateFirstCharge D ρ W k = 0 := by
      unfold gateFirstCharge
      apply Finset.sum_eq_zero
      intro z hz
      have hWk := (Finset.mem_filter.mp hz).2
      have hd : C.isD z.val = false := by
        apply Bool.eq_false_iff.mpr
        intro hd
        exact hfirst ⟨z,hd,hWk⟩
      have hh := C.first_charge_bound D ρ W z
      simp [indicator,hd] at hh
      omega
    have hsubset : B ⊆ (Finset.univ : Finset (Fin n)).filter
        (fun z => C.isDStar z.val = true ∧ V z = k) := by
      intro z hz
      have hz' := (Finset.mem_filter.mp hz).2
      have hp : P z = false := by
        cases he : P z with
        | false => rfl
        | true =>
          have hwk : W z = k := by simpa [Q,retirementSecondTarget,he] using hz'.2
          exact False.elim (hfirst ⟨z,C.isD_of_isDStar z.val hz'.1,hwk⟩)
      have hvk : V z = k := by simpa [Q,retirementSecondTarget,hp] using hz'.2
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,hz'.1,hvk⟩
    have hcard := C.second_role_card_le_two hsafe W V hw hv k g a b hk
    have hle := Finset.card_le_card hsubset
    omega

/-- A gate that survives resolution receives no retirement charge. -/
theorem retirement_gate_charge_zero_of_kept {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (W V : Fin n → Nat)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → P z = false →
      Essential (C.restrict (fixSubst P c)).eval z)
    (k : Nat) (halias : C.isAliased (fixRes P c) k = false) :
    C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k +
      C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W (retirementSecondTarget P W V) k = 0 := by
  have hf : C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k = 0 := by
    unfold gateFirstCharge
    apply Finset.sum_eq_zero
    intro z hz
    have he := (Finset.mem_filter.mp hz).2
    have hb := C.first_charge_bound (C.restrict (fixSubst P c)) (fixRes P c) W z
    rw [he,halias] at hb
    simp [indicator] at hb
    exact hb
  have hs : C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W (retirementSecondTarget P W V) k = 0 := by
    unfold gateSecondCharge
    apply Finset.sum_eq_zero
    intro z hz
    have he := (Finset.mem_filter.mp hz).2
    have hb := C.retirement_second_charge_bound P c hDistinct W V hw hv hess z
    rw [he,halias] at hb
    simp [indicator] at hb
    exact hb
  omega

/-- A degenerate gate carries no first or second retirement role. -/
theorem retirement_gate_charge_zero_of_degenerate {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (W V : Fin n → Nat)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → P z = false →
      Essential (C.restrict (fixSubst P c)).eval z)
    (k : Nat) (g : Table) (a b : Nat) (hgate : C.gateAt k = some (g,a,b))
    (hdeg : g.essential = false) :
    C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k +
      C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W (retirementSecondTarget P W V) k = 0 := by
  let D := C.restrict (fixSubst P c)
  let ρ := fixRes P c
  let Q := retirementSecondTarget P W V
  change C.gateFirstCharge D ρ W k + C.gateSecondCharge D ρ W Q k = 0
  have hnl : g.nonlinear = false := by simp [Table.nonlinear,hdeg]
  have hf : C.gateFirstCharge D ρ W k = 0 := by
    unfold gateFirstCharge
    apply Finset.sum_eq_zero
    intro z hz
    have hW := (Finset.mem_filter.mp hz).2
    have hd : C.isD z.val = false := by
      apply Bool.eq_false_iff.mpr
      intro hd
      have hm : k ∈ C.users z.val := by simpa [hW] using hw z hd
      have hn := C.isD_reader_nonlinear z.val k hd hm g a b hgate
      rw [hnl] at hn
      contradiction
    have hb := C.first_charge_bound D ρ W z
    simp [indicator,hd] at hb
    omega
  have hs : C.gateSecondCharge D ρ W Q k = 0 := by
    unfold gateSecondCharge
    apply Finset.sum_eq_zero
    intro z hz
    have hQ : Q z = k := (Finset.mem_filter.mp hz).2
    have hstar : C.isDStar z.val = false := by
      apply Bool.eq_false_iff.mpr
      intro hstar
      have hd := C.isD_of_isDStar z.val hstar
      cases hp : P z with
      | true =>
        have he : W z = k := by simpa [Q,retirementSecondTarget,hp] using hQ
        have hm : k ∈ C.users z.val := by simpa [he] using hw z hd
        have hn := C.isD_reader_nonlinear z.val k hd hm g a b hgate
        rw [hnl] at hn
        contradiction
      | false =>
        have he : V z = k := by simpa [Q,retirementSecondTarget,hp] using hQ
        have huz := C.users_singleton_of_isD z.val (W z) hd (hw z hd)
        have hDW : C.isD (W z) = true := by
          obtain ⟨_,w,hmem,hdw⟩ := (C.isDStar_iff z.val).mp hstar
          rw [huz,Finset.mem_singleton] at hmem
          simpa [hmem] using hdw
        have hm : k ∈ C.users (W z) := by simpa [he] using hv z hstar
        have hn := C.isD_reader_nonlinear (W z) k hDW hm g a b hgate
        rw [hnl] at hn
        contradiction
    have hb := C.retirement_second_charge_bound P c hDistinct W V hw hv hess z
    change C.secondGateCharge D ρ W z ≤ indicator (C.isDStar z.val) * indicator (C.isAliased ρ (Q z)) at hb
    simp [indicator,hstar] at hb
    omega
  omega

/-- Arbitrary block retirement does not increase potential when every
surviving credited input remains essential. -/
theorem psi2_retirement_restriction_le {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (hsafe : C.DGateSafe)
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (W V : Fin n → Nat)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → P z = false → Essential (C.restrict (fixSubst P c)).eval z)
    (horig : ∀ z, C.isDStar z.val = true → Essential f z) :
    (C.restrict (fixSubst P c)).psi2 ≤ C.psi2 := by
  have hloss : C.credit2Lost (C.restrict (fixSubst P c)) ≤ C.aliasedPsi2Weight (fixRes P c) := by
    rw [C.retirement_loss_eq_charges P c hDistinct W V hw hv hess,
      C.aliasedPsi2Weight_eq_sum]
    apply Finset.sum_le_sum
    intro k _
    cases ha : C.isAliased (fixRes P c) k with
    | false =>
      rw [C.retirement_gate_charge_zero_of_kept P c hDistinct W V hw hv hess k ha]
      simp
    | true =>
      cases hk : C.gateAt k with
      | none => simp [isAliased,hk] at ha
      | some p =>
        obtain ⟨g,a,b⟩ := p
        cases he : g.essential with
        | false =>
          have hz := C.retirement_gate_charge_zero_of_degenerate P c hDistinct W V hw hv hess k g a b hk he
          rw [hz]
          simp
        | true =>
          have hcap := C.retirement_gate_charge_le_two P c hDistinct hsafe f hc hE1
            W V hw hv hess horig k g a b hk
          have hweight : 4 ≤ g.psi2W := by
            revert he
            rcases g with ⟨a,b,c,d⟩
            cases a <;> cases b <;> cases c <;> cases d <;> decide
          simp only [↓reduceIte,gatePsi2W,hk]
          omega
  have hbalance := C.psi2_restriction_gain_loss P c
  omega


/-- Restricting an arbitrary block cannot increase the potential if every
unfixed essential input remains essential in the resulting function. -/
theorem psi2_restrict_preserving_essential {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z)
    (hpres : ∀ z, P z = false → Essential C.eval z →
      Essential (C.restrict (fixSubst P c)).eval z) :
    (C.restrict (fixSubst P c)).psi2 ≤ C.psi2 := by
  classical
  have existsW : ∀ z : Fin n, C.isD z.val = true → ∃ w, w ∈ C.users z.val := by
    intro z hd
    obtain ⟨_,w,g,a,b,hgate,hab,_⟩ := (C.isD_iff z.val).mp hd
    exact ⟨w,C.mem_users.mpr ⟨g,a,b,hgate,hab⟩⟩
  let W : Fin n → Nat := fun z => if h : C.isD z.val = true then Classical.choose (existsW z h) else 0
  have hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val := by
    intro z hz
    simp only [W,hz,↓reduceDIte]
    exact Classical.choose_spec (existsW z hz)
  have existsV : ∀ z : Fin n, C.isDStar z.val = true → ∃ v, v ∈ C.users (W z) := by
    intro z hz
    have hd := C.isD_of_isDStar z.val hz
    obtain ⟨_,w,hmem,hDW⟩ := (C.isDStar_iff z.val).mp hz
    have hu := C.users_singleton_of_isD z.val (W z) hd (hw z hd)
    rw [hu,Finset.mem_singleton] at hmem
    subst w
    obtain ⟨_,v,g,a,b,hgate,hab,_⟩ := (C.isD_iff (W z)).mp hDW
    exact ⟨v,C.mem_users.mpr ⟨g,a,b,hgate,hab⟩⟩
  let V : Fin n → Nat := fun z => if h : C.isDStar z.val = true then Classical.choose (existsV z h) else 0
  have hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z) := by
    intro z hz
    simp only [V,hz,↓reduceDIte]
    exact Classical.choose_spec (existsV z hz)
  have horig : ∀ z, C.isDStar z.val = true → Essential C.eval z := by
    intro z hz
    have hd := C.isD_of_isDStar z.val hz
    apply hused z
    rw [C.usage_singleUse]
    have hh := ((C.isD_iff z.val).mp hd).1
    omega
  have hess : ∀ z, C.isDStar z.val = true → P z = false →
      Essential (C.restrict (fixSubst P c)).eval z := by
    intro z hz hp
    exact hpres z hp (horig z hz)
  have hs := forbid_a_of_distinct C.eval C hDistinct (fun _ => rfl) hE1 hused
  exact C.psi2_retirement_restriction_le P c hDistinct hs C.eval (fun _ => rfl)
    hE1 W V hw hv hess horig

/-- A coordinate fixed by an arbitrary restriction does not remain in the
compiled circuit's syntactic support. -/
theorem fixed_coordinate_unused {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (x : Fin n) (hx : P x = true) :
    (C.restrict (fixSubst P c)).usage (singleUse x) = 0 := by
  let ρ := fixRes P c
  have hinit : ∀ w, (ρ w).hits x.val = false := by
    intro w
    by_cases he : w = x
    · subst w
      simp [ρ,fixRes,hx,Res.hits]
    · cases hp : P w <;> simp [ρ,fixRes,hp,Res.hits,he,Fin.val_inj]
  have hnone := C.resAt_no_hit_of_no_initial_hit ρ x.val x.isLt hinit
  have hsum : ∑ k ∈ Finset.range (n+C.size), C.keptSlotHits ρ k x.val = 0 := by
    apply Finset.sum_eq_zero
    intro k _
    cases hg : C.gateAt k with
    | none => exact FlatKeptAux.keptSlotHits_none C ρ x.val hg
    | some p =>
      obtain ⟨g,a,d⟩ := p
      rw [FlatKeptAux.keptSlotHits_eq C ρ x.val hg]
      simp [hnone,indicator]
  have hout : C.outHits ρ x.val = 0 := by
    unfold outHits
    cases hw : C.outWire with
    | none => rfl
    | some p =>
      obtain ⟨k,neg⟩ := p
      simp [hnone,indicator]
  have hzero : C.keptRefs ρ x.val = 0 := by
    have he := C.keptRefs_eq_sum ρ x.val
    omega
  have hu := C.usage_restrict_fix P c x
  change (C.restrict (fixSubst P c)).usage (singleUse x) = 0
  simpa [ρ,hzero] using hu

/-- Complete potential-preserving retirement restriction followed by
normalization, with support tracking for the remaining composition. -/
theorem psi2_retirement_normalized {n : Nat} (hn : 2 ≤ n) (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z)
    (hpres : ∀ z, P z = false → Essential C.eval z →
      Essential (C.restrict (fixSubst P c)).eval z)
    (hresE1 : E1 (C.restrict (fixSubst P c)).eval) :
    ∃ D : OpenCircuit n, D.Reduced ∧ D.NoInputTriangles (fun _ => none) ∧
      (∀ v, D.eval v = (C.restrict (fixSubst P c)).eval v) ∧ D.psi2 ≤ C.psi2 ∧
      (∀ z, 0 < D.usage (singleUse z) → 0 < C.usage (singleUse z) ∧ P z = false) := by
  let R := C.restrict (fixSubst P c)
  have hp : R.GateProper := C.restrict_gateProper (fixSubst P c)
  have hdrop : R.psi2 ≤ C.psi2 := C.psi2_restrict_preserving_essential P c hDistinct hE1 hused hpres
  have hsupport : ∀ z, 0 < R.usage (singleUse z) → 0 < C.usage (singleUse z) ∧ P z = false := by
    intro z hz
    refine ⟨C.usage_pos_of_fix_usage_pos P c z hz,?_⟩
    cases hP : P z with
    | false => rfl
    | true =>
      have hh := C.fixed_coordinate_unused P c z hP
      change R.usage (singleUse z) = 0 at hh
      omega
  have husedR : ∀ z, 0 < R.usage (singleUse z) → Essential R.eval z := by
    intro z hz
    obtain ⟨hzC,hzP⟩ := hsupport z hz
    exact hpres z hzP (hused z hzC)
  obtain ⟨D,hD,htri,he,hpsi,_,hDs⟩ := R.psi2_normalize_proper_support hn hp hresE1 husedR
  exact ⟨D,hD,htri,he,le_trans hpsi hdrop,fun z hz => hsupport z (hDs z hz)⟩

end OpenCircuit
end SatLowerBound
