import Credit.TwoLevel.SubsetSumMultinomial
import Mathlib.Order.Interval.Finset.Fin
import Mathlib.Data.Nat.Factorial.NatCast

/-! Coordinate domains used in the signed-sum proof. -/
namespace SatLowerBound

/-- The signed coordinates used by the subset-sum proof.  The cut indicates
where the sequence of negative prefixes skips one size. -/
noncomputable def balandraudDomain {G : Type} [DecidableEq G] [AddGroup G]
    {d : Nat} (a : Fin d → G) (cut : Nat) (i : Fin d) : Finset G :=
  Finset.univ.image a ∪
    ((if i.val < cut then Finset.Iio i else Finset.Iic i).image fun j => -a j)

/-- All domain entries are signed original elements. -/
theorem balandraudDomain_rep {G : Type} [DecidableEq G] [AddGroup G]
    {d : Nat} (a : Fin d → G) (cut : Nat) (i : Fin d) (x : G)
    (hx : x ∈ balandraudDomain a cut i) : ∃ j, x = a j ∨ x = -a j := by
  classical
  simp only [balandraudDomain, Finset.mem_union, Finset.mem_image, Finset.mem_univ,
    true_and] at hx
  rcases hx with ⟨j, rfl⟩ | ⟨j, _, rfl⟩
  · exact ⟨j, Or.inl rfl⟩
  · exact ⟨j, Or.inr rfl⟩

/-- The domain size is the size claimed in Balandraud's construction. -/
theorem balandraudDomain_card {G : Type} [DecidableEq G] [AddGroup G]
    {d : Nat} (a : Fin d → G) (ha : Function.Injective a)
    (hopp : ∀ i j, a i ≠ -a j) (cut : Nat) (i : Fin d) :
    (balandraudDomain a cut i).card =
      d + i.val + if i.val < cut then 0 else 1 := by
  classical
  let S : Finset (Fin d) := if i.val < cut then Finset.Iio i else Finset.Iic i
  have hd : Disjoint (Finset.univ.image a) (S.image fun j => -a j) := by
    rw [Finset.disjoint_left]
    intro x hx hy
    obtain ⟨j, _, rfl⟩ := Finset.mem_image.mp hy
    obtain ⟨k, _, hk⟩ := Finset.mem_image.mp hx
    exact hopp k j hk
  have hn : Function.Injective (fun j => -a j) := fun _ _ h => ha (neg_injective h)
  rw [balandraudDomain, Finset.card_union_of_disjoint hd,
    Finset.card_image_of_injective _ ha, Finset.card_image_of_injective _ hn]
  simp only [Finset.card_univ, Fintype.card_fin]
  dsimp [S]
  split_ifs <;> simp [Fin.card_Iio, Fin.card_Iic, Nat.add_assoc]

/-- The exponents are one less than the coordinate-domain sizes. -/
noncomputable def balandraudExponent (d cut : Nat) : Fin d →₀ Nat :=
  Finsupp.indicator Finset.univ fun i _ =>
    d - 1 + i.val + if i.val < cut then 0 else 1

@[simp] theorem balandraudExponent_apply {d cut : Nat} (i : Fin d) :
    balandraudExponent d cut i = d - 1 + i.val + if i.val < cut then 0 else 1 := by
  simp [balandraudExponent, Finsupp.indicator_apply]

/-- The exponents match the grid sizes required by the polynomial lemma. -/
theorem balandraudExponent_domain_card {G : Type} [DecidableEq G] [AddGroup G]
    {d : Nat} (a : Fin d → G) (ha : Function.Injective a)
    (hopp : ∀ i j, a i ≠ -a j) (cut : Nat) (i : Fin d) :
    balandraudExponent d cut i + 1 = (balandraudDomain a cut i).card := by
  rw [balandraudExponent_apply, balandraudDomain_card a ha hopp]
  have hd : 0 < d := Nat.zero_lt_of_lt i.isLt
  split_ifs <;> omega

/-- Every chosen exponent is strictly below twice the number of elements. -/
theorem balandraudExponent_lt_twice {d cut : Nat} (i : Fin d) :
    balandraudExponent d cut i < 2 * d := by
  rw [balandraudExponent_apply]
  have hd : 0 < d := Nat.zero_lt_of_lt i.isLt
  split_ifs <;> omega

/-- In prime characteristic, the general determinant criterion needs only
natural-number inequalities ensuring the relevant factorials are nonzero. -/
theorem restrictedSums_gt_of_binomial_det_charP
    {R : Type} [Field R] [DecidableEq R] [Fintype R]
    (p : Nat) [Fact p.Prime] [CharP R p]
    {d k : Nat} (a : Fin d → R) (domains : Fin d → Finset R)
    (hdom : ∀ i x, x ∈ domains i → ∃ j, x = a j ∨ x = -a j)
    (t : Fin d →₀ Nat) (hsize : ∀ i, t i < (domains i).card)
    (ht : t.degree = 2 * Nat.choose d 2 + k)
    (hcard : k ≤ Fintype.card R)
    (htp : ∀ i, t i < p) (hdp : 2 * d ≤ p) (hkp : k < p)
    (hdet : (binomialCoefficientMatrix (R := R) t).det ≠ 0) :
    k < (signedRestrictedSums a domains).card := by
  apply restrictedSums_gt_of_binomial_det a domains hdom t hsize ht hcard
  · intro i m hm
    exact (IsUnit.natCast_factorial_iff_of_charP (A := R) p).mpr
      (lt_of_le_of_lt hm (htp i)) |>.ne_zero
  · intro j
    refine ((IsUnit.natCast_factorial_iff_of_charP (A := R) p).mpr ?_).ne_zero
    have hj := j.isLt
    omega
  · exact ((IsUnit.natCast_factorial_iff_of_charP (A := R) p).mpr hkp).ne_zero
  · exact hdet

/-- For the paper's actual grid, the only remaining algebraic hypothesis is
nonvanishing of the corresponding binomial determinant. -/
theorem balandraudDomains_restrictedSums_gt
    {p d k cut : Nat} [Fact p.Prime] (a : Fin d → ZMod p)
    (ha : Function.Injective a) (hopp : ∀ i j, a i ≠ -a j)
    (hdp : 2 * d ≤ p) (hkp : k < p)
    (ht : (balandraudExponent d cut).degree = 2 * Nat.choose d 2 + k)
    (hdet : (binomialCoefficientMatrix (R := ZMod p) (balandraudExponent d cut)).det ≠ 0) :
    k < (signedRestrictedSums a (balandraudDomain a cut)).card := by
  apply restrictedSums_gt_of_binomial_det_charP p a (balandraudDomain a cut)
    (fun i x hx => balandraudDomain_rep a cut i x hx) (balandraudExponent d cut)
  · intro i
    have h := balandraudExponent_domain_card a ha hopp cut i
    omega
  · exact ht
  · simpa using Nat.le_of_lt hkp
  · intro i
    exact lt_of_lt_of_le (balandraudExponent_lt_twice i) hdp
  · exact hdp
  · exact hkp
  · exact hdet

/-- The determinant criterion transfers to ordinary subset sums for the
paper's chosen signed grid. -/
theorem balandraudDomains_subsetSum_gt
    {p d k cut : Nat} [Fact p.Prime] (hpodd : p ≠ 2) (a : Fin d → ZMod p)
    (ha : Function.Injective a) (hopp : ∀ i j, a i ≠ -a j)
    (hdp : 2 * d ≤ p) (hkp : k < p)
    (ht : (balandraudExponent d cut).degree = 2 * Nat.choose d 2 + k)
    (hdet : (binomialCoefficientMatrix (R := ZMod p) (balandraudExponent d cut)).det ≠ 0) :
    k < (Finset.univ.image a).subsetSum.card := by
  have hs := balandraudDomains_restrictedSums_gt a ha hopp hdp hkp ht hdet
  have hb := signedRestrictedSums_card_le_subsetSum p Fact.out hpodd a ha (balandraudDomain a cut)
  exact lt_of_lt_of_le hs hb

/-- Number of indices at or after the omitted position. -/
theorem balandraud_cut_count (d cut : Nat) :
    (∑ i : Fin d, if i.val < cut then 0 else 1) = d - cut := by
  have hs : (∑ i : Fin d, if i.val < cut then 0 else 1) =
      ∑ i ∈ Finset.range d, if i < cut then 0 else 1 :=
    Fin.sum_univ_eq_sum_range (fun i => if i < cut then 0 else 1) d
  rw [hs]
  have he : (Finset.range d).filter (fun i => ¬ i < cut) = Finset.Ico cut d := by
    ext i
    simp only [Finset.mem_filter, Finset.mem_range, Finset.mem_Ico, not_lt]
    omega
  rw [Finset.sum_ite]
  simp only [Finset.sum_const_zero, zero_add, Finset.sum_const, nsmul_eq_mul, mul_one]
  rw [he, Nat.card_Ico]
  rfl

/-- The exponent sum in the determinant argument is the base Vandermonde
degree plus the triangular bound reduced by the omitted position. -/
theorem balandraudExponent_degree (d cut : Nat) (hcut : cut ≤ d) :
    (balandraudExponent d cut).degree =
      2 * Nat.choose d 2 + (Nat.choose (d + 1) 2 - cut) := by
  classical
  rw [Finsupp.degree_eq_sum]
  simp only [balandraudExponent_apply, Finset.sum_add_distrib, Finset.sum_const,
    Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  have hv : (∑ i : Fin d, i.val) = Nat.choose d 2 := by
    have h := Fin.sum_univ_eq_sum_range id d
    simpa [Finset.sum_range_id, Nat.choose_two_right] using h
  rw [hv, balandraud_cut_count]
  have hdouble : 2 * Nat.choose d 2 = d * (d - 1) := by
    have h := Finset.sum_range_id_mul_two d
    rw [Finset.sum_range_id, ← Nat.choose_two_right] at h
    omega
  have htri : Nat.choose (d + 1) 2 = Nat.choose d 2 + d := by
    rw [Nat.choose_succ_succ]
    simp [Nat.add_comm]
  rw [htri]
  change d * (d - 1) + Nat.choose d 2 + (d - cut) =
    2 * Nat.choose d 2 + (Nat.choose d 2 + d - cut)
  rw [← hdouble]
  omega

/-- For the paper's domains, determinant nonvanishing gives the triangular
subset-sum lower bound with exactly the omitted-position adjustment. -/
theorem balandraudDomains_subsetSum_triangular
    {p d cut : Nat} [Fact p.Prime] (hpodd : p ≠ 2) (a : Fin d → ZMod p)
    (ha : Function.Injective a) (hopp : ∀ i j, a i ≠ -a j)
    (hdp : 2 * d ≤ p) (hcut : cut ≤ d)
    (hkp : Nat.choose (d + 1) 2 - cut < p)
    (hdet : (binomialCoefficientMatrix (R := ZMod p) (balandraudExponent d cut)).det ≠ 0) :
    Nat.choose (d + 1) 2 - cut < (Finset.univ.image a).subsetSum.card := by
  exact balandraudDomains_subsetSum_gt hpodd a ha hopp hdp hkp
    (balandraudExponent_degree d cut hcut) hdet

end SatLowerBound
