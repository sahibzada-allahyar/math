import Credit.TwoLevel.Basic
import Credit.Flat

/-! The paper counts distinct successor gates. The existing implementation counts
operand slots and the output. These agree for signals that are not the output in
circuits with distinct operands. The output condition is explicit: it must later be
established from the paper's normalization assumptions. -/

namespace SatLowerBound
namespace OpenCircuit

/-- The paper's condition `succ(s) = {w}` with nonlinear `w`. -/
def paperD {n : Nat} (C : OpenCircuit n) (s : Nat) : Prop :=
  ∃ w g a b, C.users s = {w} ∧ C.gateAt w = some (g, a, b) ∧ g.nonlinear = true

theorem isD_iff_paperD {n : Nat} (C : OpenCircuit n) (s : Nat)
    (hd : C.DistinctOperands) (hout : C.outIs s = 0) :
    C.isD s = true ↔ C.paperD s := by
  rw [C.isD_iff]
  constructor
  · rintro ⟨href, w, g, a, b, hw, hab, hnl⟩
    have hmem : w ∈ C.users s := C.mem_users.mpr ⟨g, a, b, hw, hab⟩
    have hc : (C.users s).card = 1 := by
      rw [C.refCount_eq hd, hout, Nat.add_zero] at href
      exact href
    have hs : C.users s = {w} := Finset.card_eq_one.mp hc |>.elim fun x hx => by
      have : w = x := by simpa [hx] using hmem
      simpa [this] using hx
    exact ⟨w, g, a, b, hs, hw, hnl⟩
  · rintro ⟨w, g, a, b, hs, hw, hnl⟩
    have hmem : w ∈ C.users s := by rw [hs]; simp
    obtain ⟨g', a', b', hw', hab⟩ := C.mem_users.mp hmem
    have : g' = g := by rw [hw] at hw'; simpa using (congrArg (Option.map Prod.fst) hw').symm
    subst g'
    refine ⟨?_, w, g, a', b', hw', hab, hnl⟩
    rw [C.refCount_eq hd, hs, Finset.card_singleton, hout, Nat.add_zero]

/-- A reduced nonempty circuit outputs its last gate. -/
theorem reduced_outWire_last {n : Nat} (C : OpenCircuit n) (hC : C.Reduced)
    (hpos : 0 < C.size) : ∃ b, C.outWire = some (n + C.size - 1, b) := by
  induction C with
  | output s => simp [size] at hpos
  | @gate n g i j rest ih =>
    cases rest with
    | output o =>
      have hu := hC.2.2.1
      cases o with
      | constant b => simp [lastUses, usage] at hu
      | wire z b =>
        have hz : z.val = n := by
          have hlt := z.isLt
          by_contra hne
          have hzn : z.val < n := by omega
          simp [lastUses, usage, appendValue, hzn] at hu
        refine ⟨b, ?_⟩
        simp [outWire, size, hz]
    | gate g' i' j' rest' =>
      obtain ⟨b, hb⟩ := ih hC.2.2.2 (by simp [size])
      refine ⟨b, ?_⟩
      simp only [outWire, size] at hb ⊢
      have heq : n + 1 + (rest'.size + 1) - 1 = n + (rest'.size + 1 + 1) - 1 := by omega
      rw [heq] at hb
      exact hb

/-- In a reduced circuit the output cannot also feed a later gate. -/
theorem reduced_outIs_zero_of_user {n : Nat} (C : OpenCircuit n) (hC : C.Reduced)
    (v : Nat) (hne : C.users v ≠ ∅) : C.outIs v = 0 := by
  obtain ⟨w, hw⟩ := Finset.nonempty_iff_ne_empty.mpr hne
  obtain ⟨g, a, b, hgate, hab⟩ := C.mem_users.mp hw
  have hbound := C.gateAt_bounds hgate
  have hv : v < n + C.size - 1 := by
    rcases hab with ha | hb <;> omega
  have hpos : 0 < C.size := by omega
  obtain ⟨neg, hout⟩ := C.reduced_outWire_last hC hpos
  simp [outIs, hout, Ne.symm hv.ne]

/-- The paper's two consecutive nonlinear single-successor conditions. -/
def paperDStar {n : Nat} (C : OpenCircuit n) (s : Nat) : Prop :=
  ∃ w, C.paperD s ∧ C.users s = {w} ∧ C.paperD w

/-- Correspondence of two-level credits, assuming the designated output signal
has no successor. This assumption is exposed until derived for normalized circuits. -/
theorem isDStar_iff_paperDStar {n : Nat} (C : OpenCircuit n) (s : Nat)
    (hd : C.DistinctOperands)
    (hout : ∀ v, C.users v ≠ ∅ → C.outIs v = 0) :
    C.isDStar s = true ↔ C.paperDStar s := by
  rw [C.isDStar_iff]
  constructor
  · rintro ⟨hs, w, hw, hstar⟩
    have hns : C.users s ≠ ∅ := Finset.ne_empty_of_mem hw
    have hpaper := (C.isD_iff_paperD s hd (hout s hns)).mp hs
    obtain ⟨w', g, a, b, hsingle, hg, hnl⟩ := hpaper
    have hww : w = w' := by simpa [hsingle] using hw
    subst w'
    have ⟨_, w2, g2, a2, b2, hgate, hab, hnl2⟩ := (C.isD_iff w).mp hstar
    have hw2 : w2 ∈ C.users w := C.mem_users.mpr ⟨g2, a2, b2, hgate, hab⟩
    exact ⟨w, ⟨w, g, a, b, hsingle, hg, hnl⟩, hsingle,
      (C.isD_iff_paperD w hd (hout w (Finset.ne_empty_of_mem hw2))).mp hstar⟩
  · rintro ⟨w, hps, hsingle, hpw⟩
    have hw : w ∈ C.users s := by rw [hsingle]; simp
    have hns : C.users s ≠ ∅ := Finset.ne_empty_of_mem hw
    obtain ⟨w2, g2, a2, b2, hwusers, hgate, hnl⟩ := hpw
    have hw2 : w2 ∈ C.users w := by rw [hwusers]; simp
    exact ⟨(C.isD_iff_paperD s hd (hout s hns)).mpr hps, w, hw,
      (C.isD_iff_paperD w hd (hout w (Finset.ne_empty_of_mem hw2))).mpr
        ⟨w2, g2, a2, b2, hwusers, hgate, hnl⟩⟩

/-- For normalized (reduced) circuits, Lean's two-level credit is exactly
 the manuscript's successor-based credit; no extra correspondence hypothesis remains. -/
theorem isDStar_iff_paperDStar_of_reduced {n : Nat} (C : OpenCircuit n)
    (hC : C.Reduced) (s : Nat) : C.isDStar s = true ↔ C.paperDStar s := by
  exact C.isDStar_iff_paperDStar s (C.reduced_distinct hC)
    (fun v hv => C.reduced_outIs_zero_of_user hC v hv)

/-- First credits agree with the distinct-successor definition in every
reduced circuit, including signals with no successor. -/
theorem isD_iff_paperD_of_reduced {n : Nat} (C : OpenCircuit n)
    (hC : C.Reduced) (s : Nat) : C.isD s = true ↔ C.paperD s := by
  by_cases hu : C.users s = ∅
  · constructor
    · intro h
      obtain ⟨_,w,g,a,b,hg,hab,_⟩ := (C.isD_iff s).mp h
      have hm := C.mem_users.mpr ⟨g,a,b,hg,hab⟩
      simp [hu] at hm
    · rintro ⟨w,g,a,b,hs,_,_⟩
      rw [hu] at hs
      have : w ∈ (∅ : Finset Nat) := by rw [hs]; simp
      simp at this
  · exact C.isD_iff_paperD s (C.reduced_distinct hC)
      (C.reduced_outIs_zero_of_user hC s hu)

/-- The manuscript's first-credit set cardinality. -/
noncomputable def paperDCount {n : Nat} (C : OpenCircuit n) : Nat := by
  classical
  exact (Finset.univ.filter (fun z : Fin n => C.paperD z.val)).card

/-- The manuscript's second-credit set cardinality. -/
noncomputable def paperDStarCount {n : Nat} (C : OpenCircuit n) : Nat := by
  classical
  exact (Finset.univ.filter (fun z : Fin n => C.paperDStar z.val)).card

/-- Definition 6.9 using distinct-successor credits directly. -/
noncomputable def paperPsi2 {n : Nat} (C : OpenCircuit n) : Int :=
  7 * (C.parityCount : Int) + 4 * (C.nonlinearCount : Int) -
    C.paperDCount - C.paperDStarCount

theorem dCount_eq_paperDCount {n : Nat} (C : OpenCircuit n) (hC : C.Reduced) :
    C.dCount = C.paperDCount := by
  classical
  simp only [dCount,paperDCount,Finset.card_filter,indicator,
    C.isD_iff_paperD_of_reduced hC]

theorem dStarCount_eq_paperDStarCount {n : Nat} (C : OpenCircuit n) (hC : C.Reduced) :
    C.dStarCount = C.paperDStarCount := by
  classical
  simp only [dStarCount,paperDStarCount,Finset.card_filter,indicator,
    C.isDStar_iff_paperDStar_of_reduced hC]

/-- Exact agreement of the potential used by the elimination proof with
Definition 6.9, without an extra output-signal hypothesis. -/
theorem psi2_eq_paperPsi2 {n : Nat} (C : OpenCircuit n) (hC : C.Reduced) :
    C.psi2 = C.paperPsi2 := by
  simp only [psi2,paperPsi2,C.psi2Weight_eq,C.dCount_eq_paperDCount hC,
    C.dStarCount_eq_paperDStarCount hC,Nat.cast_add,Nat.cast_mul,Nat.cast_ofNat]

end OpenCircuit
end SatLowerBound
