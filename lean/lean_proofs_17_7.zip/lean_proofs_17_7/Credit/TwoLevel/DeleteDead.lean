import Credit.TwoLevel.CofactorRoles
import Credit.TwoLevel.PruningBranch

/-! Explicit deletion of a chosen dead gate. This file proves semantic and
weight preservation; it does not assume the desired credit comparison. -/
namespace SatLowerBound
namespace OpenCircuit

/-- Proper gates have essential tables and distinct operands, independent
of whether every gate is live. -/
def GateProper : {n : Nat} → OpenCircuit n → Prop
  | _, .output _ => True
  | _, .gate g i j rest => g.essential = true ∧ i ≠ j ∧ GateProper rest

/-- Delete the gate with global index `k`, replacing its unused output by a
constant in the tail and reindexing that tail. -/
def deleteDead : {n : Nat} → OpenCircuit n → Nat → OpenCircuit n
  | _, .output s, _ => .output s
  | n, .gate g i j rest, k =>
    if k = n then rest.restrict (dropLast n) else .gate g i j (deleteDead rest k)

/-- Essential tables and distinct operands give the recursive properness
needed to delete a dead gate. -/
theorem gateProper_of_essential_distinct {n : Nat} (C : OpenCircuit n)
    (he : C.EssentialGates) (hd : C.DistinctOperands) : C.GateProper := by
  induction C with
  | output s => trivial
  | @gate n g i j rest ih =>
    have hij : i ≠ j := by
      intro heq
      exact hd n g i.val j.val (gateAt_head g i j rest) (congrArg Fin.val heq)
    have hrest : rest.DistinctOperands := by
      intro k t a b hk
      have hkge := (rest.gateAt_bounds hk).1
      have hkne : k ≠ n := by omega
      exact hd k t a b ((gateAt_tail g i j rest hkne).trans hk)
    exact ⟨he.1,hij,ih he.2 hrest⟩

/-- Every raw restriction is proper, even when it still contains dead
gates. -/
theorem restrict_gateProper {n m : Nat} (C : OpenCircuit n) (σ : Fin n → Signal m) :
    (C.restrict σ).GateProper :=
  (C.restrict σ).gateProper_of_essential_distinct (C.restrict_essential σ)
    (C.restrict_distinct_operands σ)

private def dropRes (n : Nat) : Fin (n+1) → Res :=
  fun k => if k.val < n then .lit k.val false else .const false

private theorem dropLast_rel (n : Nat) (k : Fin (n+1)) :
    ResRel (Fin.val : Fin n → Nat) (dropLast n k) (dropRes n k) := by
  by_cases hk : k.val < n
  · simp [dropLast,extendSubst,identitySubst,dropRes,hk,ResRel]
  · simp [dropLast,extendSubst,dropRes,hk,ResRel]

private theorem dropRes_lit (n : Nat) (k : Fin (n+1)) (hk : k.val ≠ n) :
    dropRes n k = .lit k.val false := by
  have hlt : k.val < n := by have := k.isLt; omega
  simp [dropRes,hlt]

/-- When a signal has no references, substituting it away leaves every
proper remaining gate intact, with all two-level weights unchanged. -/
private theorem all_kept_weight2 {p : Nat} (C : OpenCircuit p) (ρ : Fin p → Res) (d : Nat)
    (hρ : ∀ k : Fin p, k.val ≠ d → ρ k = .lit k.val false)
    (hd : C.refCount d = 0) (hp : C.GateProper) :
    C.keptCount ρ = C.size ∧ C.keptPsi2Weight ρ = C.psi2Weight := by
  induction C with
  | output s => simp [keptCount,size,keptPsi2Weight,psi2Weight]
  | @gate p g i j rest ih =>
    simp only [refCount] at hd
    have hi : i.val ≠ d := by intro he; simp [he] at hd
    have hj : j.val ≠ d := by intro he; simp [he] at hd
    have hd' : rest.refCount d = 0 := by omega
    obtain ⟨hg,hij,hproper⟩ := hp
    have hstep : Res.step g (.lit i.val false) (.lit j.val false) = none :=
      Res.step_kept g hg i.val j.val (fun he => hij (Fin.ext he)) false false
    have hρ' : ∀ k : Fin (p+1), k.val ≠ d →
        appendValue ρ (.lit p false) k = .lit k.val false := by
      intro k hk
      unfold appendValue
      by_cases hkp : k.val < p
      · simp only [hkp, ↓reduceDIte]
        exact hρ ⟨k.val,hkp⟩ hk
      · have hkv : k.val = p := by have := k.isLt; omega
        simp only [hkp, ↓reduceDIte]
        rw [hkv]
    obtain ⟨hc,hw⟩ := ih (appendValue ρ (.lit p false)) hρ' hd' hproper
    simp [keptCount,size,keptPsi2Weight,psi2Weight,hρ i hi,hρ j hj,hstep,hc,hw]

private theorem all_kept_refs_first {p : Nat} (R : OpenCircuit p) (ρ : Fin p → Res) (d : Nat)
    (hρ : ∀ k : Fin p, k.val ≠ d → ρ k = .lit k.val false) (hd : R.refCount d = 0)
    (hp : R.GateProper) :
    R.keptPsiWeight ρ = R.psiWeight ∧
      ∀ s, s ≠ d → R.keptRefs ρ s = R.refCount s ∧ R.keptFirstNL ρ s = R.firstUserNL s := by
  induction R with
  | output o =>
    refine ⟨rfl, ?_⟩
    intro s _
    cases o with
    | constant b => exact ⟨rfl, rfl⟩
    | wire i neg =>
      have hi : i.val ≠ d := by
        intro he
        simp [refCount, he] at hd
      refine ⟨?_, rfl⟩
      simp only [keptRefs, refCount, hρ i hi, Res.hits, indicator]
      by_cases he : i.val = s <;> simp [he]
  | @gate p g i j rest ih =>
    simp only [refCount] at hd
    have hi : i.val ≠ d := by
      intro he
      simp [he] at hd
    have hj : j.val ≠ d := by
      intro he
      simp [he] at hd
    have hrd : rest.refCount d = 0 := by omega
    obtain ⟨hg, hij, hp'⟩ := hp
    have hstep : Res.step g (.lit i.val false) (.lit j.val false) = none :=
      Res.step_kept g hg i.val j.val (fun h => hij (Fin.ext h)) false false
    have hρ' : ∀ k : Fin (p + 1), k.val ≠ d →
        appendValue ρ (.lit p false) k = .lit k.val false := by
      intro k hk
      unfold appendValue
      by_cases hkp : k.val < p
      · simp only [hkp, ↓reduceDIte]
        exact hρ ⟨k.val, hkp⟩ hk
      · have hkv : k.val = p := by
          have := k.isLt
          omega
        simp only [hkp, ↓reduceDIte]
        rw [hkv]
    obtain ⟨ihw, ihr⟩ := ih (appendValue ρ (.lit p false)) hρ' hrd hp'
    refine ⟨?_, ?_⟩
    · simp only [keptPsiWeight, psiWeight, hρ i hi, hρ j hj, hstep, ihw]
    · intro s hs
      obtain ⟨h₁, h₂⟩ := ihr s hs
      refine ⟨?_, ?_⟩
      · simp only [keptRefs, refCount, hρ i hi, hρ j hj, hstep, h₁, Res.hits, indicator]
        by_cases hsi : i.val = s <;> by_cases hsj : j.val = s <;> simp [hsi, hsj]
      · simp only [keptFirstNL, firstUserNL, hρ i hi, hρ j hj, hstep, h₂, Res.hits]
        by_cases hsi : i.val = s <;> by_cases hsj : j.val = s <;> simp [hsi, hsj]

/-- Under the same deletion conditions every original remaining gate is
kept by the restriction compiler. -/
private theorem all_gates_kept {p : Nat} (C : OpenCircuit p) (ρ : Fin p → Res) (d : Nat)
    (hρ : ∀ k : Fin p, k.val ≠ d → ρ k = .lit k.val false)
    (hd : C.refCount d = 0) (hp : C.GateProper)
    {k : Nat} {g : Table} {a b : Nat} (hk : C.gateAt k = some (g,a,b)) :
    C.isKept ρ k = true := by
  have hcount := (all_kept_weight2 C ρ d hρ hd hp).1
  have hsplit := C.size_split ρ
  have hzero : C.aliasedCount ρ = 0 := by omega
  have hnot : C.isAliased ρ k = false := by
    apply Bool.eq_false_iff.mpr
    intro ha
    have hsub : ({k} : Finset Nat) ⊆ Finset.range (p + C.size) := by
      intro q hq
      rw [Finset.mem_singleton.mp hq]
      exact Finset.mem_range.mpr (C.gateAt_bounds hk).2.1
    have hle := C.aliasedCount_ge_card ρ {k} hsub (by
      intro q hq
      rw [Finset.mem_singleton.mp hq]
      exact ha)
    simp at hle
    omega
  rw [C.isKept_eq_not_isAliased ρ hk,hnot]
  rfl

/-- All surviving signal indices resolve to themselves when an unused
signal is removed from a proper circuit. -/
private theorem all_kept_resAt {p : Nat} (C : OpenCircuit p) (ρ : Fin p → Res) (d : Nat)
    (hρ : ∀ k : Fin p, k.val ≠ d → ρ k = .lit k.val false)
    (hd : C.refCount d = 0) (hp : C.GateProper)
    (s : Nat) (hs : s < p + C.size) (hne : s ≠ d) :
    C.resAt ρ s = .lit s false := by
  by_cases hsp : s < p
  · have hh := C.resAt_input ρ ⟨s,hsp⟩
    simpa [hρ ⟨s,hsp⟩ hne] using hh
  · obtain ⟨g,a,b,hg⟩ := C.gateAt_exists (by omega) hs
    exact C.resAt_kept ρ (all_gates_kept C ρ d hρ hd hp hg)

/-- A signal preceding the deleted dead gate keeps its reference count and
first-reader status when that gate does not read the signal. -/
theorem deleteDead_profile_before {n : Nat} (C : OpenCircuit n) (hp : C.GateProper)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b))
    (hdead : C.refCount k = 0) (s : Nat) (hs : s < k) (ha : a ≠ s) (hb : b ≠ s) :
    (C.deleteDead k).refCount s = C.refCount s ∧
      (C.deleteDead k).firstUserNL s = C.firstUserNL s := by
  induction C generalizing k g a b s with
  | output o => simp [gateAt] at hk
  | @gate n t i j rest ih =>
    obtain ⟨_,_,hp'⟩ := hp
    by_cases he : k = n
    · subst k
      rw [gateAt_head] at hk
      simp only [Option.some.injEq, Prod.mk.injEq] at hk
      obtain ⟨rfl,rfl,rfl⟩ := hk
      have hd0 : rest.refCount n = 0 := by
        simp only [refCount] at hdead
        omega
      have hstats := (all_kept_refs_first rest (dropRes n) n (dropRes_lit n) hd0 hp').2 s (by omega)
      have htr := rest.restrict_transfer (dropLast n) (dropRes n) Fin.val
        Fin.val_injective (fun w => Nat.lt_succ_of_lt w.isLt) (dropLast_rel n)
      have hr := htr.2.2.1 ⟨s,hs⟩
      have hf := htr.2.2.2 ⟨s,hs⟩
      simp only at hr hf
      simp only [deleteDead, ↓reduceIte, refCount,firstUserNL,ha,hb,↓reduceIte,zero_add]
      exact ⟨hr.trans hstats.1,hf.trans hstats.2⟩
    · have hk' : rest.gateAt k = some (g,a,b) := by
        rw [← gateAt_tail t i j rest he]
        exact hk
      have hd' : rest.refCount k = 0 := by simp only [refCount] at hdead; omega
      obtain ⟨hr,hf⟩ := ih hp' k g a b hk' hd' s hs ha hb
      simp only [deleteDead, he, ↓reduceIte,refCount,firstUserNL,hr,hf]
      exact ⟨True.intro,True.intro⟩

/-- Deleting a dead gate preserves the D-status of every earlier signal
that it does not read. -/
theorem deleteDead_isD_before {n : Nat} (C : OpenCircuit n) (hp : C.GateProper)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b))
    (hdead : C.refCount k = 0) (s : Nat) (hs : s < k) (ha : a ≠ s) (hb : b ≠ s) :
    (C.deleteDead k).isD s = C.isD s := by
  obtain ⟨href,hfirst⟩ := C.deleteDead_profile_before hp k g a b hk hdead s hs ha hb
  simp only [isD,href,hfirst]

/-- A dead gate that is not a first-credit gate can be removed without
losing any existing primary-input D credit, irrespective of its position. -/
theorem deleteDead_preserves_primary_D {n : Nat} (C : OpenCircuit n) (hp : C.GateProper)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b))
    (hdead : C.refCount k = 0) (hrole : C.isDGate k = false) :
    ∀ z : Fin n, C.isD z.val = true → (C.deleteDead k).isD z.val = true := by
  intro z hz
  have hkbound := C.gateAt_bounds hk
  have ha : a ≠ z.val := by
    intro he
    have hh : C.isDGate k = true := (C.isDGate_iff k).mpr
      ⟨g,a,b,hk,Or.inl ⟨by rw [he]; exact z.isLt,by rw [he]; exact hz⟩⟩
    rw [hrole] at hh
    contradiction
  have hb : b ≠ z.val := by
    intro he
    have hh : C.isDGate k = true := (C.isDGate_iff k).mpr
      ⟨g,a,b,hk,Or.inr ⟨by rw [he]; exact z.isLt,by rw [he]; exact hz⟩⟩
    rw [hrole] at hh
    contradiction
  have he := C.deleteDead_isD_before hp k g a b hk hdead z.val (by have := z.isLt; omega) ha hb
  rw [he,hz]

/-- Gates before a deleted gate retain their exact global indices and
tables. -/
theorem deleteDead_gateAt_before {n : Nat} (C : OpenCircuit n)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b))
    (s : Nat) (hs : s < k) : (C.deleteDead k).gateAt s = C.gateAt s := by
  induction C generalizing k g a b s with
  | output o => simp [gateAt] at hk
  | @gate n t i j rest ih =>
    by_cases he : k = n
    · subst k
      have hs' : s < n := hs
      simp only [deleteDead, ↓reduceIte]
      rw [gateAt_of_lt _ hs',gateAt_of_lt _ hs']
    · have hk' : rest.gateAt k = some (g,a,b) := by
        rw [← gateAt_tail t i j rest he]
        exact hk
      simp only [deleteDead, he, ↓reduceIte]
      by_cases hsn : s = n
      · subst s
        simp
      · rw [gateAt_tail _ _ _ _ hsn, gateAt_tail _ _ _ _ hsn]
        exact ih k g a b hk' s hs

/-- A gate after the deleted dead gate has a corresponding reindexed gate
with identical reference profile and identical primary-input operands. -/
theorem deleteDead_transport_later_gate {n : Nat} (C : OpenCircuit n) (hp : C.GateProper)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b))
    (hdead : C.refCount k = 0) (W : Nat) (t : Table) (u v : Nat)
    (hW : C.gateAt W = some (t,u,v)) (hafter : k < W) :
    ∃ W' t' u' v', (C.deleteDead k).gateAt W' = some (t',u',v') ∧
      (C.deleteDead k).refCount W' = C.refCount W ∧
      (C.deleteDead k).firstUserNL W' = C.firstUserNL W ∧
      ∀ z : Fin n, (u' = z.val ∨ v' = z.val) ↔ (u = z.val ∨ v = z.val) := by
  induction C generalizing k g a b W t u v with
  | output o => simp [gateAt] at hk
  | @gate n g₀ i j rest ih =>
    obtain ⟨_,_,hp'⟩ := hp
    by_cases he : k = n
    · subst k
      have hWne : W ≠ n := by omega
      have htail : rest.gateAt W = some (t,u,v) := by
        rw [← gateAt_tail g₀ i j rest hWne]
        exact hW
      have hd0 : rest.refCount n = 0 := by simp only [refCount] at hdead; omega
      have hkept := all_gates_kept rest (dropRes n) n (dropRes_lit n) hd0 hp' htail
      obtain ⟨W',t',u',v',hgate,href,hfirst,hread⟩ := rest.restrict_kept_readers
        (dropLast n) (dropRes n) Fin.val Fin.val_injective
        (fun z => Nat.lt_succ_of_lt z.isLt) (dropLast_rel n) W t u v htail hkept
      have hstats := (all_kept_refs_first rest (dropRes n) n (dropRes_lit n) hd0 hp').2 W hWne
      have hu : u ≠ n := by
        intro he'
        have hm : W ∈ rest.users n := rest.mem_users.mpr ⟨t,u,v,htail,Or.inl he'⟩
        have hge := rest.refCount_ge n
        have hp := Finset.card_pos.mpr ⟨W,hm⟩
        omega
      have hv : v ≠ n := by
        intro he'
        have hm : W ∈ rest.users n := rest.mem_users.mpr ⟨t,u,v,htail,Or.inr he'⟩
        have hge := rest.refCount_ge n
        have hp := Finset.card_pos.mpr ⟨W,hm⟩
        omega
      have hWbounds := rest.gateAt_bounds htail
      have hures := all_kept_resAt rest (dropRes n) n (dropRes_lit n) hd0 hp' u (by omega) hu
      have hvres := all_kept_resAt rest (dropRes n) n (dropRes_lit n) hd0 hp' v (by omega) hv
      have hiW : i.val ≠ W := by have := i.isLt; omega
      have hjW : j.val ≠ W := by have := j.isLt; omega
      refine ⟨W',t',u',v',?_,?_,?_,?_⟩
      · simpa [deleteDead] using hgate
      · simpa [deleteDead,refCount,hiW,hjW] using href.trans hstats.1
      · simpa [deleteDead,firstUserNL,hiW,hjW] using hfirst.trans hstats.2
      · intro z
        have hh := hread z
        rw [hures,hvres] at hh
        simpa [Res.hits] using hh
    · have hk' : rest.gateAt k = some (g,a,b) := by
        rw [← gateAt_tail g₀ i j rest he]
        exact hk
      have hWne : W ≠ n := by have := (rest.gateAt_bounds hk').1; omega
      have hW' : rest.gateAt W = some (t,u,v) := by
        rw [← gateAt_tail g₀ i j rest hWne]
        exact hW
      have hd' : rest.refCount k = 0 := by simp only [refCount] at hdead; omega
      obtain ⟨W',t',u',v',hgate,href,hfirst,hread⟩ := ih hp' k g a b hk' hd' W t u v hW' hafter
      have hWge := (rest.gateAt_bounds hW').1
      have hW'ge := ((rest.deleteDead k).gateAt_bounds hgate).1
      have hW'ne : W' ≠ n := by
        omega
      have hiW : i.val ≠ W := by have := i.isLt; omega
      have hjW : j.val ≠ W := by have := j.isLt; omega
      have hiW' : i.val ≠ W' := by have := i.isLt; omega
      have hjW' : j.val ≠ W' := by have := j.isLt; omega
      refine ⟨W',t',u',v',?_,?_,?_,?_⟩
      · simp only [deleteDead,he,↓reduceIte]
        rw [gateAt_tail _ _ _ _ hW'ne]
        exact hgate
      · simpa [deleteDead,he,refCount,hiW,hjW,hiW',hjW'] using href
      · simpa [deleteDead,he,firstUserNL,hiW,hjW,hiW',hjW'] using hfirst
      · intro z
        simpa using hread z.castSucc

/-- A role-free dead gate does not decrease the number of D credits. -/
theorem deleteDead_dCount_mono {n : Nat} (C : OpenCircuit n) (hp : C.GateProper)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b))
    (hdead : C.refCount k = 0) (hrole : C.isDGate k = false) :
    C.dCount ≤ (C.deleteDead k).dCount := by
  unfold dCount
  apply Finset.sum_le_sum
  intro z _
  cases hz : C.isD z.val with
  | false => simp [indicator]
  | true =>
    have hh := C.deleteDead_preserves_primary_D hp k g a b hk hdead hrole z hz
    simp [hh,indicator]

/-- D-star credits whose first gate precedes the removed gate survive, if
the removed gate is not their second-credit gate. -/
theorem deleteDead_preserves_DStar_first_before {n : Nat} (C : OpenCircuit n)
    (hp : C.GateProper) (k : Nat) (g : Table) (a b : Nat)
    (hk : C.gateAt k = some (g,a,b)) (hdead : C.refCount k = 0)
    (hrole : C.isDGate k = false) (z : Fin n) (hz : C.isDStar z.val = true)
    (W : Nat) (hW : W ∈ C.users z.val) (hWD : C.isD W = true)
    (hWlt : W < k) (hsecond : k ∉ C.users W) :
    (C.deleteDead k).isDStar z.val = true := by
  have hzD := C.isD_of_isDStar z.val hz
  have hznew := C.deleteDead_preserves_primary_D hp k g a b hk hdead hrole z hzD
  have ha : a ≠ W := by
    intro he
    exact hsecond (C.mem_users.mpr ⟨g,a,b,hk,Or.inl he⟩)
  have hb : b ≠ W := by
    intro he
    exact hsecond (C.mem_users.mpr ⟨g,a,b,hk,Or.inr he⟩)
  have hWnew : (C.deleteDead k).isD W = true := by
    rw [C.deleteDead_isD_before hp k g a b hk hdead W hWlt ha hb,hWD]
  obtain ⟨gW,aW,bW,hgW,habW⟩ := C.mem_users.mp hW
  have hgW' : (C.deleteDead k).gateAt W = some (gW,aW,bW) := by
    rw [C.deleteDead_gateAt_before k g a b hk W hWlt]
    exact hgW
  have hWread : W ∈ (C.deleteDead k).users z.val :=
    (C.deleteDead k).mem_users.mpr ⟨gW,aW,bW,hgW',habW⟩
  exact ((C.deleteDead k).isDStar_iff z.val).mpr ⟨hznew,W,hWread,hWnew⟩

/-- A role-free dead gate can be deleted without losing any D-star credit,
including when the credit's first gate must be reindexed. -/
theorem deleteDead_preserves_primary_DStar {n : Nat} (C : OpenCircuit n)
    (hp : C.GateProper) (k : Nat) (g : Table) (a b : Nat)
    (hk : C.gateAt k = some (g,a,b)) (hdead : C.refCount k = 0)
    (hrole : C.isDGate k = false)
    (hsecond : ∀ z : Fin n, C.isDStar z.val = true → ∀ W,
      W ∈ C.users z.val → k ∉ C.users W) :
    ∀ z : Fin n, C.isDStar z.val = true → (C.deleteDead k).isDStar z.val = true := by
  intro z hz
  obtain ⟨hzD,W,hW,hWD⟩ := (C.isDStar_iff z.val).mp hz
  have hWne : W ≠ k := by
    intro he
    have hh := ((C.isD_iff W).mp hWD).1
    rw [he,hdead] at hh
    contradiction
  by_cases hlt : W < k
  · exact C.deleteDead_preserves_DStar_first_before hp k g a b hk hdead hrole z hz
      W hW hWD hlt (hsecond z hz W hW)
  · have hgt : k < W := by omega
    obtain ⟨t,u,v,hgate,hab⟩ := C.mem_users.mp hW
    obtain ⟨W',t',u',v',hgate',href,hfirst,hread⟩ :=
      C.deleteDead_transport_later_gate hp k g a b hk hdead W t u v hgate hgt
    have hWnew : (C.deleteDead k).isD W' = true := by
      simpa [isD,href,hfirst] using hWD
    have hWread : W' ∈ (C.deleteDead k).users z.val :=
      (C.deleteDead k).mem_users.mpr ⟨t',u',v',hgate',(hread z).mpr hab⟩
    have hznew := C.deleteDead_preserves_primary_D hp k g a b hk hdead hrole z hzD
    exact ((C.deleteDead k).isDStar_iff z.val).mpr ⟨hznew,W',hWread,hWnew⟩

/-- If the dead first gate is not a first-credit gate, deleting it
preserves both kinds of existing primary-input credit. -/
theorem deleteDead_head_preserves_credits {n : Nat} (g : Table) (i j : Fin n)
    (rest : OpenCircuit (n+1)) (hp : (OpenCircuit.gate g i j rest).GateProper)
    (hdead : (OpenCircuit.gate g i j rest).refCount n = 0)
    (hrole : (OpenCircuit.gate g i j rest).isDGate n = false) :
    (∀ z : Fin n, (OpenCircuit.gate g i j rest).isD z.val = true →
      ((OpenCircuit.gate g i j rest).deleteDead n).isD z.val = true) ∧
    (∀ z : Fin n, (OpenCircuit.gate g i j rest).isDStar z.val = true →
      ((OpenCircuit.gate g i j rest).deleteDead n).isDStar z.val = true) := by
  let C : OpenCircuit n := .gate g i j rest
  let D : OpenCircuit n := rest.restrict (dropLast n)
  have hdel : C.deleteDead n = D := by simp [C,D,deleteDead]
  have hd0 : rest.refCount n = 0 := by
    change (OpenCircuit.gate g i j rest).refCount n = 0 at hdead
    simp only [refCount] at hdead
    omega
  have hp' : rest.GateProper := hp.2.2
  have hstats := (all_kept_refs_first rest (dropRes n) n (dropRes_lit n) hd0 hp').2
  have htr := rest.restrict_transfer (dropLast n) (dropRes n) Fin.val
    Fin.val_injective (fun w => Nat.lt_succ_of_lt w.isLt) (dropLast_rel n)
  have hinput : ∀ z : Fin n, D.isD z.val = rest.isD z.val := by
    intro z
    obtain ⟨hr,hf⟩ := hstats z.val (by have := z.isLt; omega)
    have hrd := htr.2.2.1 z
    have hfd := htr.2.2.2 z
    change D.refCount z.val = rest.keptRefs (dropRes n) z.val at hrd
    change D.firstUserNL z.val = rest.keptFirstNL (dropRes n) z.val at hfd
    simp only [isD, hrd,hfd,hr,hf]
  have hfirst : ∀ z : Fin n, C.isD z.val = true → D.isD z.val = true := by
    intro z hz
    have hi : i.val ≠ z.val := by
      intro he
      have hn : C.isDGate n = true := (C.isDGate_iff n).mpr
        ⟨g,i.val,j.val,gateAt_head g i j rest,Or.inl ⟨i.isLt,by rw [he]; exact hz⟩⟩
      rw [hrole] at hn
      contradiction
    have hj : j.val ≠ z.val := by
      intro he
      have hn : C.isDGate n = true := (C.isDGate_iff n).mpr
        ⟨g,i.val,j.val,gateAt_head g i j rest,Or.inr ⟨j.isLt,by rw [he]; exact hz⟩⟩
      rw [hrole] at hn
      contradiction
    have hrD : rest.isD z.val = true := by
      change (OpenCircuit.gate g i j rest).isD z.val = true at hz
      simpa [isD,refCount,firstUserNL,hi,hj] using hz
    rw [hinput z]
    exact hrD
  constructor
  · intro z hz
    rw [hdel]
    exact hfirst z hz
  · intro z hz
    rw [hdel]
    obtain ⟨hzD,W,hW,hWD⟩ := (C.isDStar_iff z.val).mp hz
    have hznew := hfirst z hzD
    have hWne : W ≠ n := by
      intro he
      have hcard := (C.isD_iff n).mp (by simpa [he] using hWD)
      have href : C.refCount n = 0 := hdead
      omega
    obtain ⟨gW,a,b,hgW,hab⟩ := C.mem_users.mp hW
    have htail : rest.gateAt W = some (gW,a,b) := by
      rw [← gateAt_tail g i j rest hWne]
      exact hgW
    have hWbound := rest.gateAt_bounds htail
    have hDtail : rest.isD W = true := by
      change (OpenCircuit.gate g i j rest).isD W = true at hWD
      have hiW : i.val ≠ W := by have := i.isLt; omega
      have hjW : j.val ≠ W := by have := j.isLt; omega
      simpa [isD,refCount,firstUserNL,hiW,hjW] using hWD
    have hkept := all_gates_kept rest (dropRes n) n (dropRes_lit n) hd0 hp' htail
    obtain ⟨W',g',a',b',hg',href,hf,hread⟩ := rest.restrict_kept_readers
      (dropLast n) (dropRes n) Fin.val Fin.val_injective
      (fun w => Nat.lt_succ_of_lt w.isLt) (dropLast_rel n) W gW a b htail hkept
    have hWnew : D.isD W' = true := by
      obtain ⟨hr,hfirstNL⟩ := hstats W (by omega)
      change D.refCount W' = rest.keptRefs (dropRes n) W at href
      change D.firstUserNL W' = rest.keptFirstNL (dropRes n) W at hf
      simpa [isD,href,hf,hr,hfirstNL] using hDtail
    have hzres : rest.resAt (dropRes n) z.val = .lit z.val false := by
      have hh := rest.resAt_input (dropRes n) z.castSucc
      simpa [dropRes,z.isLt] using hh
    have hzhit : (rest.resAt (dropRes n) z.val).hits z.val = true := by
      rw [hzres]
      exact (Res.hits_lit _ _ _).mpr rfl
    have hhit : (rest.resAt (dropRes n) a).hits z.val = true ∨
        (rest.resAt (dropRes n) b).hits z.val = true := by
      rcases hab with he | he
      · left; rw [he]; exact hzhit
      · right; rw [he]; exact hzhit
    have hnewread : W' ∈ D.users z.val := by
      apply D.mem_users.mpr
      exact ⟨g',a',b',hg',(hread z).mpr hhit⟩
    exact (D.isDStar_iff z.val).mpr ⟨hznew,W',hnewread,hWnew⟩

/-- Deleting the specified dead gate preserves the computed function and
removes exactly that gate's 7/4 weight, provided the gates are proper. -/
theorem deleteDead_spec {n : Nat} (C : OpenCircuit n) (hp : C.GateProper)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b))
    (hdead : C.refCount k = 0) :
    (∀ x, (C.deleteDead k).eval x = C.eval x) ∧
    (C.deleteDead k).size + 1 = C.size ∧
    (C.deleteDead k).psi2Weight + g.psi2W = C.psi2Weight := by
  induction C with
  | output s => simp [gateAt] at hk
  | @gate n t i j rest ih =>
    obtain ⟨ht,hij,hproper⟩ := hp
    by_cases he : k = n
    · subst k
      rw [gateAt_head] at hk
      simp only [Option.some.injEq, Prod.mk.injEq] at hk
      obtain ⟨rfl,_,_⟩ := hk
      have hd0 : rest.refCount n = 0 := by
        simp only [refCount] at hdead
        omega
      have hlast : rest.lastUses = 0 := by rw [FlatA.lastUses_eq,hd0]
      obtain ⟨hcount,hweight⟩ := all_kept_weight2 rest (dropRes n) n (dropRes_lit n) hd0 hproper
      have hsize := (rest.restrict_transfer (dropLast n) (dropRes n) Fin.val
        Fin.val_injective (fun w => Nat.lt_succ_of_lt w.isLt) (dropLast_rel n)).1
      have hw := rest.restrict_psi2Weight_transfer (dropLast n) (dropRes n) Fin.val
        Fin.val_injective (fun w => Nat.lt_succ_of_lt w.isLt) (dropLast_rel n)
      refine ⟨?_,?_,?_⟩
      · intro x
        simp only [deleteDead, ↓reduceIte, eval]
        rw [dropLast_eval, eval_unused_last rest hlast x false (t.eval (x i) (x j))]
      · simp only [deleteDead, ↓reduceIte, size]
        omega
      · simp only [deleteDead, ↓reduceIte, psi2Weight]
        omega
    · have hk' : rest.gateAt k = some (g,a,b) := by
        rw [← gateAt_tail t i j rest he]
        exact hk
      have hd' : rest.refCount k = 0 := by
        simp only [refCount] at hdead
        omega
      obtain ⟨hval,hs,hw⟩ := ih hproper hk' hd'
      refine ⟨?_,?_,?_⟩
      · intro x
        simp only [deleteDead, he, ↓reduceIte, eval]
        exact hval _
      · simp only [deleteDead, he, ↓reduceIte, size]
        omega
      · simp only [deleteDead, he, ↓reduceIte, psi2Weight]
        omega

/-- Deletion cannot introduce references to an earlier signal. -/
theorem deleteDead_refCount_before_le {n : Nat} (C : OpenCircuit n) (hp : C.GateProper)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b))
    (hdead : C.refCount k = 0) (s : Nat) (hs : s < k) :
    (C.deleteDead k).refCount s ≤ C.refCount s := by
  induction C generalizing k g a b s with
  | output o => simp [gateAt] at hk
  | @gate n t i j rest ih =>
    obtain ⟨_,_,hp'⟩ := hp
    by_cases he : k = n
    · subst k
      have hd0 : rest.refCount n = 0 := by simp only [refCount] at hdead; omega
      have hstats := (all_kept_refs_first rest (dropRes n) n (dropRes_lit n) hd0 hp').2 s (by omega)
      have htr := rest.restrict_transfer (dropLast n) (dropRes n) Fin.val
        Fin.val_injective (fun w => Nat.lt_succ_of_lt w.isLt) (dropLast_rel n)
      have hr := htr.2.2.1 ⟨s,hs⟩
      simp only [deleteDead, ↓reduceIte, refCount]
      have hh := hr.trans hstats.1
      change (rest.restrict (dropLast n)).refCount s = rest.refCount s at hh
      omega
    · have hk' : rest.gateAt k = some (g,a,b) := by
        rw [← gateAt_tail t i j rest he]
        exact hk
      have hd' : rest.refCount k = 0 := by simp only [refCount] at hdead; omega
      have hh := ih hp' k g a b hk' hd' s hs
      simp only [deleteDead, he, ↓reduceIte, refCount]
      omega

/-- Removing a gate preserves properness of all remaining gates. -/
theorem deleteDead_preserves_proper {n : Nat} (C : OpenCircuit n) (hp : C.GateProper)
    (k : Nat) : (C.deleteDead k).GateProper := by
  induction C with
  | output o => trivial
  | @gate n t i j rest ih =>
    by_cases he : k = n
    · simp only [deleteDead, he, ↓reduceIte]
      exact rest.restrict_gateProper (dropLast n)
    · simp only [deleteDead, he, ↓reduceIte, GateProper]
      exact ⟨hp.1,hp.2.1,ih hp.2.2⟩

/-- Deleting a dead gate with neither credit role lowers the two-level
potential by at least its complete gate weight. -/
theorem deleteDead_role_free_potential_drop {n : Nat} (C : OpenCircuit n)
    (hp : C.GateProper) (k : Nat) (g : Table) (a b : Nat)
    (hk : C.gateAt k = some (g,a,b)) (hdead : C.refCount k = 0)
    (hrole : C.isDGate k = false)
    (hsecond : ∀ z : Fin n, C.isDStar z.val = true → ∀ W,
      W ∈ C.users z.val → k ∉ C.users W) :
    (C.deleteDead k).psi2 + (g.psi2W : Int) ≤ C.psi2 := by
  have hD := C.deleteDead_dCount_mono hp k g a b hk hdead hrole
  have hStar : C.dStarCount ≤ (C.deleteDead k).dStarCount := by
    unfold dStarCount
    apply Finset.sum_le_sum
    intro z _
    cases hz : C.isDStar z.val with
    | false => simp [indicator]
    | true =>
      have hh := C.deleteDead_preserves_primary_DStar hp k g a b hk hdead hrole hsecond z hz
      simp [hh,indicator]
  have hw := (C.deleteDead_spec hp k g a b hk hdead).2.2
  unfold psi2
  omega

/-- Deleting a role-free dead first gate lowers the two-level potential by
at least its entire gate weight; existing D and D-star credits survive. -/
theorem deleteDead_head_potential_drop {n : Nat} (g : Table) (i j : Fin n)
    (rest : OpenCircuit (n+1)) (hp : (OpenCircuit.gate g i j rest).GateProper)
    (hdead : (OpenCircuit.gate g i j rest).refCount n = 0)
    (hrole : (OpenCircuit.gate g i j rest).isDGate n = false) :
    ((OpenCircuit.gate g i j rest).deleteDead n).psi2 + (g.psi2W : Int) ≤
      (OpenCircuit.gate g i j rest).psi2 := by
  let C : OpenCircuit n := .gate g i j rest
  let D : OpenCircuit n := C.deleteDead n
  have hpres := deleteDead_head_preserves_credits g i j rest hp hdead hrole
  have hD : C.dCount ≤ D.dCount := by
    unfold dCount
    apply Finset.sum_le_sum
    intro z _
    cases hz : C.isD z.val with
    | false => simp [indicator]
    | true =>
      have hh : D.isD z.val = true := hpres.1 z hz
      simp [hh,indicator]
  have hStar : C.dStarCount ≤ D.dStarCount := by
    unfold dStarCount
    apply Finset.sum_le_sum
    intro z _
    cases hz : C.isDStar z.val with
    | false => simp [indicator]
    | true =>
      have hh : D.isDStar z.val = true := hpres.2 z hz
      simp [hh,indicator]
  have hw := (C.deleteDead_spec hp n g i.val j.val (gateAt_head g i j rest) hdead).2.2
  change D.psi2Weight + g.psi2W = C.psi2Weight at hw
  change D.psi2 + (g.psi2W : Int) ≤ C.psi2
  unfold psi2
  omega

/-- The explicit deletion applies to every dead gate produced by the
restriction compiler. -/
theorem deleteDead_restriction_spec {n m : Nat} (C : OpenCircuit n)
    (σ : Fin n → Signal m) (k : Nat) (g : Table) (a b : Nat)
    (hk : (C.restrict σ).gateAt k = some (g,a,b))
    (hdead : (C.restrict σ).refCount k = 0) :
    (∀ x, ((C.restrict σ).deleteDead k).eval x = (C.restrict σ).eval x) ∧
    ((C.restrict σ).deleteDead k).size + 1 = (C.restrict σ).size ∧
    ((C.restrict σ).deleteDead k).psi2Weight + g.psi2W = (C.restrict σ).psi2Weight :=
  (C.restrict σ).deleteDead_spec (C.restrict_gateProper σ) k g a b hk hdead

end OpenCircuit

namespace MAContext
open OpenCircuit

/-- The paper's surviving dead reader can be explicitly deleted while
preserving the restricted function and lowering the two-level potential by
at least the gate's full weight. -/
theorem cofactor_dead_reader_pruning_drop {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (hS4 : S4Essential f)
    (x y : Fin n) (hxy : x ≠ y) (b : Bool) (V U : Nat) (g : Table) (a d : Nat)
    (hgate : C.gateAt V = some (g,a,d)) (hVy : V ∈ C.users y.val)
    (hkept : C.isKept (singleRes x b) V = true) (husers : C.users V = {U})
    (hUc : (C.resAt (singleRes x b) U).isConst = true) :
    ∃ (k : Nat) (g' : Table) (a' d' : Nat),
      (C.restrict (singleSubst x b)).gateAt k = some (g',a',d') ∧
      (C.restrict (singleSubst x b)).refCount k = 0 ∧
      (∀ v, ((C.restrict (singleSubst x b)).deleteDead k).eval v =
        (C.restrict (singleSubst x b)).eval v) ∧
      ((C.restrict (singleSubst x b)).deleteDead k).psi2 + (g'.psi2W : Int) ≤
        (C.restrict (singleSubst x b)).psi2 := by
  obtain ⟨k,g',a',d',hk,hdead,hky⟩ := C.single_dead_gate_retains_input_reader
    h.reduced x y hxy b V U g a d hgate hVy hkept husers hUc
  let D := C.restrict (singleSubst x b)
  let F : (Fin n → Bool) → Bool := fun v => f (fixBit x b v)
  have hD : ∀ v, D.eval v = F v := by
    intro v
    rw [show D = C.restrict (singleSubst x b) from rfl, restrict_single_eval, h.computes]
  have hFE : E1 F := h.good.e2.single_cofactor_e1 x b
  have hused : ∀ z : Fin n, 0 < D.usage (singleUse z) → Essential F z := by
    intro z hz
    exact h.cofactor_used_essential hS4 x y hxy b z hz
  have hyorig : Essential f y := h.usedEssential y (by
    rw [C.usage_singleUse]
    have hp := Finset.card_pos.mpr ⟨V,hVy⟩
    have hg := C.refCount_ge y.val
    omega)
  have hyessF : Essential F y := h.good.e1 x b y (Ne.symm hxy) hyorig
  have hyess : Essential D.eval y := by
    have he : D.eval = F := funext hD
    rwa [he]
  have hy2 := D.essential_input_with_dead_reader_has_two_refs y x hxy k hky hdead hyess
  have hsafe := h.cofactor_dGateSafe hS4 x y hxy b
  have hrole := D.not_dGate_of_multi_of_safe hsafe y hy2 hky
  have hsecond : ∀ z : Fin n, D.isDStar z.val = true → ∀ W,
      W ∈ D.users z.val → k ∉ D.users W := by
    intro z hz W hW hkW
    have hd := D.isD_of_isDStar z.val hz
    have href := ((D.isD_iff z.val).mp hd).1
    have hzEss : Essential F z := hused z (by rw [D.usage_singleUse]; omega)
    obtain ⟨g₁,a₁,d₁,hg₁,hab⟩ := D.mem_users.mp hky
    rw [hk] at hg₁
    cases hg₁
    exact D.second_role_has_no_primary_unreduced F hD hFE z hzEss W k hz hW hkW
      g' a' d' hk y hab
  have hp := C.restrict_gateProper (singleSubst x b)
  have hs := D.deleteDead_spec hp k g' a' d' hk hdead
  have hdrop := D.deleteDead_role_free_potential_drop hp k g' a' d' hk hdead hrole hsecond
  exact ⟨k,g',a',d',hk,hdead,hs.1,hdrop⟩

/-- The remaining no-drop overlap is discharged by an explicit pruning
step: the resulting circuit computes the cofactor and achieves the paper's
fourteen-unit potential decrease. -/
theorem pruning_branch_main_drop {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (hS4 : S4Essential f) {t : Table} {i j : Fin n}
    {rest : OpenCircuit (n+1)} (hC : C = .gate t i j rest) (hnl : t.nonlinear = true)
    (hno : ∀ x, (x = i ∨ x = j) → ∀ b,
      ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2)) :
    ∃ (b : Bool) (D : OpenCircuit n), (∀ v, D.eval v = f (fixBit i b v)) ∧
      D.psi2 + 14 ≤ C.psi2 := by
  obtain ⟨U,V,R,b,hUi,hVj,hR,hUR,hVU,hUc,hUpar,hRpar,hTa,hUa,hRa,hVk,
    k₀,g₀,a₀,d₀,hg₀,hdead₀⟩ :=
    h.no_drop_forces_dead_gate_after_three_eliminations hS4 hC hnl hno
  have hT : C.gateAt n = some (t,i.val,j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hij : i ≠ j := fun he => (h.gate_facts hT).2.1 (congrArg Fin.val he)
  have hTi : n ∈ C.users i.val := C.mem_users.mpr ⟨t,i.val,j.val,hT,Or.inl rfl⟩
  have hU : U ∈ C.users i.val := by rw [hUi]; simp
  have hV : V ∈ C.users j.val := by rw [hVj]; simp
  have hRT : R ∈ C.users n := by rw [hR]; simp
  have hRU : R ∈ C.users U := by rw [hUR]; simp
  have hUV : U ∈ C.users V := by rw [hVU]; simp
  obtain ⟨gV,aV,dV,hgV,_⟩ := C.mem_users.mp hV
  obtain ⟨gU,aU,dU,hgU,habU⟩ := C.mem_users.mp hUV
  obtain ⟨gR,aR,dR,hgR,habR⟩ := C.mem_users.mp hRU
  have hVUgt : V < U := by have hb := C.gateAt_bounds hgU; rcases habU with he | he <;> omega
  have hURgt : U < R := by have hb := C.gateAt_bounds hgR; rcases habR with he | he <;> omega
  have hVge := (C.gateAt_bounds hgV).1
  have hUn : n ≠ U := by omega
  have hRn : n ≠ R := by omega
  have hURne : U ≠ R := by omega
  have hTpar : (C.tableAt n).parity = false := by
    have ht : t.parity = false := by
      unfold Table.nonlinear at hnl
      cases hp : t.parity <;> simp [hp] at hnl ⊢
    simp [tableAt,hT,ht]
  let E : Finset Nat := {n,U,R}
  have hEcard : E.card = 3 := by simp [E,hUn,hRn,hURne]
  have hE : ∀ k ∈ E, C.isAliased (singleRes i b) k = true ∧
      (C.tableAt k).parity = false ∧
      (k ∈ C.users i.val ∨ ∃ P g a d, C.gateAt P = some (g,a,d) ∧
        a < n ∧ d < n ∧ k ∈ C.users P) := by
    intro k hk
    simp only [E,Finset.mem_insert,Finset.mem_singleton] at hk
    rcases hk with he | he | he
    · rw [he]; exact ⟨hTa,hTpar,Or.inl hTi⟩
    · rw [he]; exact ⟨hUa,hUpar,Or.inl hU⟩
    · rw [he]; exact ⟨hRa,hRpar,Or.inr ⟨n,t,i.val,j.val,hT,i.isLt,j.isLt,hRT⟩⟩
  have hsub : E ⊆ Finset.range (n + C.size) := by
    intro k hk
    have ha := (hE k hk).1
    cases hg : C.gateAt k with
    | none => simp [OpenCircuit.isAliased,hg] at ha
    | some p =>
      obtain ⟨g,a,d⟩ := p
      exact Finset.mem_range.mpr (C.gateAt_bounds hg).2.1
  have hcount := C.aliasedCount_ge_card (singleRes i b) E hsub (fun k hk => (hE k hk).1)
  rw [hEcard] at hcount
  have hi2 := (h.degrees_of_nonlinear hC hnl).1
  have hraw := h.twoLevel_single_drop_with_primary_successors i b hi2 E hE
  rw [hEcard] at hraw
  have hraw12 : (C.restrict (singleSubst i b)).psi2 + 12 ≤ C.psi2 := by omega
  obtain ⟨k,g,a,d,hg,hdead,heval,hprune⟩ := h.cofactor_dead_reader_pruning_drop hS4
    i j hij b V U gV aV dV hgV hV hVk hVU hUc
  have hess := (C.restrict (singleSubst i b)).essentialGates_gate
    (C.restrict_essential (singleSubst i b)) hg
  have hw : 4 ≤ g.psi2W := by
    revert hess
    rcases g with ⟨a,b,c,d⟩
    cases a <;> cases b <;> cases c <;> cases d <;> decide
  refine ⟨b,(C.restrict (singleSubst i b)).deleteDead k,?_,?_⟩
  · intro v
    rw [heval,restrict_single_eval,h.computes]
  · omega

/-- Main Lemma B through the explicit restriction and pruning operations:
some input with at least two readers has a cofactor circuit whose two-level
potential is at least fourteen lower. The cofactor circuit may still require
further normalization. -/
theorem main_lemma_B_explicit {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (hS4 : S4Essential f) :
    ∃ (x : Fin n) (b : Bool) (D : OpenCircuit n),
      2 ≤ C.refCount x.val ∧ Essential f x ∧
      (∀ v, D.eval v = f (fixBit x b v)) ∧ D.psi2 + 14 ≤ C.psi2 := by
  obtain ⟨t,i,j,rest,hC⟩ := h.exists_first_gate
  have hr := h.reduced
  rw [hC] at hr
  have hij : i ≠ j := hr.2.1
  have hte : t.essential = true := hr.1
  have hiu : 0 < C.usage (singleUse i) := by
    rw [C.usage_singleUse,hC]
    simp only [refCount,↓reduceIte]
    omega
  have hju : 0 < C.usage (singleUse j) := by
    rw [C.usage_singleUse,hC]
    simp only [refCount,↓reduceIte]
    omega
  have hie := h.usedEssential i hiu
  have hje := h.usedEssential j hju
  rcases t.essential_parity_or_nonlinear hte with hpar | hnl
  · have hfun : (OpenCircuit.gate t i j rest).eval = f := by
      rw [← hC]
      exact funext h.computes
    have hsep : PairSeparated (OpenCircuit.gate t i j rest).eval i j := by
      rw [hfun]
      exact h.good.s3 i j hij hie hje
    rcases OpenCircuit.first_gate_multiple_use t i j rest hij hsep with hu | hu
    · have h2 : 2 ≤ C.refCount i.val := by rw [← C.usage_singleUse,hC]; exact hu
      obtain ⟨b,hb⟩ := h.case_parity_first hC hpar i (Or.inl rfl) h2
      refine ⟨i,b,C.restrict (singleSubst i b),h2,hie,?_,hb⟩
      intro v
      rw [restrict_single_eval,h.computes]
    · have h2 : 2 ≤ C.refCount j.val := by rw [← C.usage_singleUse,hC]; exact hu
      obtain ⟨b,hb⟩ := h.case_parity_first hC hpar j (Or.inr rfl) h2
      refine ⟨j,b,C.restrict (singleSubst j b),h2,hje,?_,hb⟩
      intro v
      rw [restrict_single_eval,h.computes]
  · have hdegrees := h.degrees_of_nonlinear hC hnl
    by_cases hraw : ∃ x, (x = i ∨ x = j) ∧ ∃ b,
        (C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2
    · obtain ⟨x,hx,b,hb⟩ := hraw
      have hx2 : 2 ≤ C.refCount x.val := by
        rcases hx with rfl | rfl
        · exact hdegrees.1
        · exact hdegrees.2
      have hxe : Essential f x := by rcases hx with rfl | rfl <;> assumption
      refine ⟨x,b,C.restrict (singleSubst x b),hx2,hxe,?_,hb⟩
      intro v
      rw [restrict_single_eval,h.computes]
    · have hno : ∀ x, (x = i ∨ x = j) → ∀ b,
          ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2) := by
        intro x hx b hb
        exact hraw ⟨x,hx,b,hb⟩
      obtain ⟨b,D,hD,hdrop⟩ := h.pruning_branch_main_drop hS4 hC hnl hno
      exact ⟨i,b,D,hdegrees.1,hie,hD,hdrop⟩

/-- In the last no-drop configuration, a concrete dead-gate deletion
preserves the restricted function and removes at least four gate-weight units.
The separate comparison of credits is not assumed here. -/
theorem pruning_branch_explicit_deletion {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (hS4 : S4Essential f) {t : Table} {i j : Fin n}
    {rest : OpenCircuit (n+1)} (hC : C = .gate t i j rest) (hnl : t.nonlinear = true)
    (hno : ∀ x, (x = i ∨ x = j) → ∀ b,
      ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2)) :
    ∃ (b : Bool) (D : OpenCircuit n),
      (∀ x, D.eval x = (C.restrict (singleSubst i b)).eval x) ∧
      D.size + 1 = (C.restrict (singleSubst i b)).size ∧
      D.psi2Weight + 4 ≤ (C.restrict (singleSubst i b)).psi2Weight := by
  obtain ⟨U,V,R,b,hUi,hVj,hR,hUR,hVU,hUc,hUpar,hRpar,hTa,hUa,hRa,hVk,k,g,a,d,hg,hdead⟩ :=
    h.no_drop_forces_dead_gate_after_three_eliminations hS4 hC hnl hno
  have hs := C.deleteDead_restriction_spec (singleSubst i b) k g a d hg hdead
  have he := (C.restrict (singleSubst i b)).essentialGates_gate
    (C.restrict_essential (singleSubst i b)) hg
  have hw : 4 ≤ g.psi2W := by
    revert he
    rcases g with ⟨a,b,c,d⟩
    cases a <;> cases b <;> cases c <;> cases d <;> decide
  exact ⟨b,(C.restrict (singleSubst i b)).deleteDead k,hs.1,hs.2.1,by omega⟩

end MAContext
end SatLowerBound
