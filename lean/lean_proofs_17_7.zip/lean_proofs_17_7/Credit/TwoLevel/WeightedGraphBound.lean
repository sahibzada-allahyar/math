import Credit.TwoLevel.WeightedUnconditional
import Credit.TwoLevel.NetworkSemantics

namespace SatLowerBound

/-- The explicit weighted bound for arbitrary labelled acyclic networks,
stated using their original gate equations rather than a compilation order. -/
theorem paper_weighted_log_bound_graph_equations (w : Nat) (hw : 32 ≤ w)
    (s : Nat) (N : AcyclicNetwork (inputBits w) s)
    (hN : ∀ v, ∃ gates, N.GateConsistent v gates ∧
      AcyclicNetwork.wireValue v gates N.output = satFunction w v) :
    (17 / 7 : ℝ) * inputBits w -
      50 * inputBits w / Real.sqrt (Real.logb 2 (inputBits w)) ≤ (s : ℝ) := by
  have hc : N.toOrdered.toCircuit.Computes (satFunction w) := by
    intro v
    rw [N.compiled_eval]
    obtain ⟨gates, hg, hout⟩ := hN v
    exact (N.graphEval_eq_of_consistent v gates hg).trans hout
  simpa [N.compiled_size] using paper_weighted_log_bound w hw N.toOrdered.toCircuit hc

end SatLowerBound
