import Credit.TwoLevel.BalandraudClosedStep

namespace SatLowerBound

/-- The subset-sum bound for a distinct signed family at or below the first
triangular threshold. All determinant hypotheses are discharged. -/
theorem balandraud_subsetSum_min_of_previous_triangle
    {p d : Nat} [Fact p.Prime] (hpodd : p ≠ 2) (a : Fin d → ZMod p)
    (ha : Function.Injective a) (hopp : ∀ i j, a i ≠ -a j)
    (hd : 0 < d) (hdp : 2 * d < p) (hprev : Nat.choose d 2 < p) :
    min p (1 + Nat.choose (d + 1) 2) ≤ (Finset.univ.image a).subsetSum.card := by
  let cut := Nat.choose (d + 1) 2 - (p - 1)
  have hp : 0 < p := (Fact.out : p.Prime).pos
  have htri : Nat.choose (d + 1) 2 = Nat.choose d 2 + d := by
    rw [Nat.choose_succ_succ]
    simp [Nat.add_comm]
  have hcut : cut ≤ d := by dsimp [cut]; omega
  have hkp : Nat.choose (d + 1) 2 - cut < p := by dsimp [cut]; omega
  have h := balandraud_subsetSum_of_det_identity hpodd a ha hopp hd hdp hcut hkp
    (balandraud_determinant_identity d cut hcut)
  dsimp [cut] at h
  omega

/-- At the first triangular threshold, the subset sums cover the field. -/
theorem balandraud_subsetSum_eq_univ_at_threshold
    {p d : Nat} [Fact p.Prime] (hpodd : p ≠ 2) (a : Fin d → ZMod p)
    (ha : Function.Injective a) (hopp : ∀ i j, a i ≠ -a j)
    (hd : 0 < d) (hdp : 2 * d < p) (hprev : Nat.choose d 2 < p)
    (hthreshold : p ≤ 1 + Nat.choose (d + 1) 2) :
    (Finset.univ.image a).subsetSum = Finset.univ := by
  have h := balandraud_subsetSum_min_of_previous_triangle hpodd a ha hopp hd hdp hprev
  rw [Nat.min_eq_left hthreshold] at h
  apply Finset.eq_univ_of_card
  have hu := Finset.card_le_univ (Finset.univ.image a).subsetSum
  simp only [ZMod.card] at hu ⊢
  omega

/-- The full cardinality bound for an enumerated set of distinct elements
with no opposite pair, below half the prime modulus. -/
theorem balandraud_subsetSum_min_enumerated
    {p : Nat} [Fact p.Prime] (hpodd : p ≠ 2) (d : Nat) (a : Fin d → ZMod p)
    (ha : Function.Injective a) (hopp : ∀ i j, a i ≠ -a j) (hdp : 2 * d < p) :
    min p (1 + Nat.choose (d + 1) 2) ≤ (Finset.univ.image a).subsetSum.card := by
  induction d with
  | zero => simp
  | succ n ih =>
    by_cases hprev : Nat.choose (n + 1) 2 < p
    · exact balandraud_subsetSum_min_of_previous_triangle hpodd a ha hopp
        (by omega) hdp hprev
    · let b : Fin n → ZMod p := fun i => a i.castSucc
      have hb : Function.Injective b := ha.comp (Fin.castSucc_injective n)
      have hbo : ∀ i j, b i ≠ -b j := fun i j => hopp i.castSucc j.castSucc
      have hsmall := ih b hb hbo (by omega)
      have hlarge : p ≤ 1 + Nat.choose (n + 1) 2 := by omega
      rw [Nat.min_eq_left hlarge] at hsmall
      have him : Finset.univ.image b ⊆ Finset.univ.image a := by
        intro x hx
        obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hx
        exact Finset.mem_image.mpr ⟨i.castSucc, Finset.mem_univ _, rfl⟩
      have hc := Finset.card_le_card (Finset.subsetSum_mono him)
      exact (Nat.min_le_left _ _).trans (hsmall.trans hc)

end SatLowerBound
