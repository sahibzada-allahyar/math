import Credit.TwoLevel.RestrictedProper
import Credit.TwoLevel.Robust

/-! Credit safety of the unreduced restricted circuit. -/
namespace SatLowerBound
namespace MAContext
open OpenCircuit

/-- In the S4 setting, every syntactically used coordinate of the restricted
circuit is essential for the corresponding cofactor. -/
theorem cofactor_used_essential {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (_hS4 : S4Essential f)
    (x y : Fin n) (_hxy : x ≠ y) (b : Bool) (z : Fin n)
    (hu : 0 < (C.restrict (singleSubst x b)).usage (singleUse z)) :
    Essential (fun v => f (fixBit x b v)) z := by
  have hzx : z ≠ x := by
    intro he
    subst z
    have hz := C.fixed_input_unused_after_restriction x b
    omega
  have hzC : 0 < C.usage (singleUse z) := by
    have hh := C.usage_pos_of_fix_usage_pos (fun w => decide (w = x)) (fun _ => b) z
    rw [← singleSubst_eq_fixSubst] at hh
    exact hh hu
  have hzorig : Essential f z := h.usedEssential z hzC
  exact h.good.e1 x b z hzx hzorig

/-- The raw one-input restriction has the D-gate safety property required
for credit accounting, although it may have dead gates. -/
theorem cofactor_dGateSafe {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (hS4 : S4Essential f)
    (x y : Fin n) (hxy : x ≠ y) (b : Bool) :
    (C.restrict (singleSubst x b)).DGateSafe := by
  let D := C.restrict (singleSubst x b)
  let F : (Fin n → Bool) → Bool := fun v => f (fixBit x b v)
  have hD : ∀ v, D.eval v = F v := by
    intro v
    rw [show D = C.restrict (singleSubst x b) from rfl, restrict_single_eval, h.computes]
  have hE : E1 F := h.good.e2.single_cofactor_e1 x b
  have hused : ∀ z : Fin n, 0 < D.usage (singleUse z) → Essential F z := by
    intro z hz
    exact h.cofactor_used_essential hS4 x y hxy b z hz
  exact D.forbid_a_of_distinct F (C.restrict_distinct_operands _) hD hE hused

/-- In the pruning case, the actual surviving dead gate reads an essential
input and carries neither credit role in the unreduced restricted circuit. -/
theorem cofactor_dead_reader_no_role {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (hS4 : S4Essential f)
    (x y : Fin n) (hxy : x ≠ y) (b : Bool) (V U : Nat) (g : Table) (a d : Nat)
    (hgate : C.gateAt V = some (g,a,d)) (hVy : V ∈ C.users y.val)
    (hkept : C.isKept (singleRes x b) V = true) (husers : C.users V = {U})
    (hUc : (C.resAt (singleRes x b) U).isConst = true) :
    ∃ k g' a' d', (C.restrict (singleSubst x b)).gateAt k = some (g',a',d') ∧
      (C.restrict (singleSubst x b)).refCount k = 0 ∧
      k ∈ (C.restrict (singleSubst x b)).users y.val ∧
      ∀ W Z : Fin n → Nat,
        (∀ z, (C.restrict (singleSubst x b)).isD z.val = true →
          W z ∈ (C.restrict (singleSubst x b)).users z.val) →
        (∀ z, (C.restrict (singleSubst x b)).isDStar z.val = true →
          Z z ∈ (C.restrict (singleSubst x b)).users (W z)) →
        (∀ z, (C.restrict (singleSubst x b)).isD z.val = true → W z ≠ k) ∧
        (∀ z, (C.restrict (singleSubst x b)).isDStar z.val = true → Z z ≠ k) := by
  obtain ⟨k,g',a',d',hk,hdead,hky⟩ := C.single_dead_gate_retains_input_reader
    h.reduced x y hxy b V U g a d hgate hVy hkept husers hUc
  refine ⟨k,g',a',d',hk,hdead,hky,?_⟩
  intro W Z hW hZ
  let D := C.restrict (singleSubst x b)
  let F : (Fin n → Bool) → Bool := fun v => f (fixBit x b v)
  have hD : ∀ v, D.eval v = F v := by
    intro v
    rw [show D = C.restrict (singleSubst x b) from rfl, restrict_single_eval, h.computes]
  have hFE : E1 F := h.good.e2.single_cofactor_e1 x b
  have hused : ∀ z : Fin n, 0 < D.usage (singleUse z) → Essential F z := by
    intro z hz
    exact h.cofactor_used_essential hS4 x y hxy b z hz
  have hyorig : Essential f y := h.usedEssential y (by
    rw [C.usage_singleUse]
    have hp := Finset.card_pos.mpr ⟨V,hVy⟩
    have hg := C.refCount_ge y.val
    omega)
  have hyessF : Essential F y := h.good.e1 x b y (Ne.symm hxy) hyorig
  have hyess : Essential D.eval y := by
    have he : D.eval = F := funext hD
    rwa [he]
  have hstars : ∀ z : Fin n, D.isDStar z.val = true → Essential F z := by
    intro z hz
    have hd := D.isD_of_isDStar z.val hz
    have href := ((D.isD_iff z.val).mp hd).1
    apply hused z
    rw [D.usage_singleUse]
    omega
  exact D.dead_essential_reader_no_role F hD hFE (h.cofactor_dGateSafe hS4 x y hxy b)
    hstars y x hxy k hky hdead hyess W Z hW hZ

end MAContext
end SatLowerBound
