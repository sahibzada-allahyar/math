import Credit.TwoLevel.Eliminated

/-! Charge allocation for the free-input branch of the two-level charging lemma. -/
namespace SatLowerBound
namespace OpenCircuit

/-- Assign as much of one input's loss as possible to its first credited gate. -/
def firstGateCharge {n : Nat} (C D : OpenCircuit n) (ρ : Fin n → Res)
    (W : Fin n → Nat) (z : Fin n) : Nat :=
  min (C.credit2 z - D.credit2 z) (indicator (C.isAliased ρ (W z)))

/-- Assign the remainder to its second credited gate. -/
def secondGateCharge {n : Nat} (C D : OpenCircuit n) (ρ : Fin n → Res)
    (W : Fin n → Nat) (z : Fin n) : Nat :=
  (C.credit2 z - D.credit2 z) - C.firstGateCharge D ρ W z

/-- Allocation is exact and never charges more than one unit to the first gate. -/
theorem charge_allocation_exact {n : Nat} (C D : OpenCircuit n) (ρ : Fin n → Res)
    (W : Fin n → Nat) (z : Fin n) :
    C.firstGateCharge D ρ W z + C.secondGateCharge D ρ W z =
      C.credit2 z - D.credit2 z ∧
    C.firstGateCharge D ρ W z ≤ indicator (C.isAliased ρ (W z)) := by
  simp only [secondGateCharge, firstGateCharge]
  constructor
  · have h := Nat.min_le_left (C.credit2 z - D.credit2 z) (indicator (C.isAliased ρ (W z)))
    omega
  · exact Nat.min_le_right _ _

/-- Under the free-input hypotheses, the second charge is at most one, and can
only be positive if the input had a second credit and its second gate was
eliminated. -/
theorem free_second_charge_bound {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (z : Fin n) :
    C.secondGateCharge (C.restrict (fixSubst P c)) (fixRes P c) W z ≤
      indicator (C.isDStar z.val) * indicator (C.isAliased (fixRes P c) (V z)) := by
  have hloss : C.credit2 z - (C.restrict (fixSubst P c)).credit2 z ≤
      indicator (C.isAliased (fixRes P c) (W z)) +
      indicator (C.isDStar z.val) * indicator (C.isAliased (fixRes P c) (V z)) := by
    cases hd : C.isD z.val with
    | false =>
      have hs : C.isDStar z.val = false := by simp [isDStar, hd]
      simp [credit2, indicator, hd, hs]
    | true =>
      cases hs : C.isDStar z.val with
      | false =>
        have h := C.free_one_credit_loss_le_eliminated P c z (hfree z hd) (W z) hd hs (hw z hd)
        simpa [indicator, hs] using h
      | true =>
        have h := C.free_two_credit_loss_le_eliminated P c hr z (hfree z hd) (W z) (V z)
          hs (hw z hd) (hv z hs) (hess z hs)
        simpa [indicator, hs] using h
  simp only [secondGateCharge, firstGateCharge, Nat.min_def]
  split <;> omega

/-- A first-gate charge can occur only for an original D-input and an
eliminated first gate. -/
theorem first_charge_bound {n : Nat} (C D : OpenCircuit n) (ρ : Fin n → Res)
    (W : Fin n → Nat) (z : Fin n) :
    C.firstGateCharge D ρ W z ≤
      indicator (C.isD z.val) * indicator (C.isAliased ρ (W z)) := by
  cases hd : C.isD z.val with
  | false =>
    have hs : C.isDStar z.val = false := by simp [isDStar, hd]
    simp [firstGateCharge, credit2, indicator, hd, hs]
  | true =>
    simpa [indicator, hd] using (C.charge_allocation_exact D ρ W z).2

/-- The aggregate of allocated charges equals the exact total credit loss. -/
theorem credit2Lost_eq_allocated {n : Nat} (C D : OpenCircuit n)
    (ρ : Fin n → Res) (W : Fin n → Nat) :
    C.credit2Lost D =
      (∑ z : Fin n, (C.firstGateCharge D ρ W z + C.secondGateCharge D ρ W z)) := by
  unfold credit2Lost
  apply Finset.sum_congr rfl
  intro z _
  exact (C.charge_allocation_exact D ρ W z).1.symm

end OpenCircuit
end SatLowerBound
