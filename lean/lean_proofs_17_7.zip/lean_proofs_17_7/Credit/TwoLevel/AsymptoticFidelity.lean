import Credit.TwoLevel.WidthBound

/-! The paper's epsilon formulation of the leading asymptotic result. -/
namespace SatLowerBound

/-- The logarithm of the encoded input length tends to infinity. -/
theorem encoded_log_tendsto : Filter.Tendsto (fun w : Nat => Real.logb 2 (inputBits w))
    Filter.atTop Filter.atTop := by
  apply Filter.tendsto_atTop_mono' Filter.atTop _ (tendsto_natCast_atTop_atTop :
    Filter.Tendsto (fun w : Nat => (w : ℝ)) Filter.atTop Filter.atTop)
  filter_upwards [Filter.eventually_ge_atTop (8 : Nat)] with w hw
  exact (PdfAsymptotics.q_comparison w hw).1

/-- The paper's equivalent statement: every coefficient below `17/7`
eventually lower-bounds every circuit in the encoded family. -/
theorem seventeen_sevenths_epsilon (ε : ℝ) (hε : 0 < ε) :
    ∃ w₀ : Nat, ∀ w ≥ w₀, ∀ C : Circuit (inputBits w),
      C.Computes (satFunction w) →
      ((17 / 7 : ℝ) - ε) * inputBits w ≤ (C.size : ℝ) := by
  have hratio : Filter.Tendsto (fun x : ℝ => Real.logb 2 x / x) Filter.atTop (nhds 0) := by
    simpa using (Real.tendsto_pow_logb_div_mul_add_atTop (b := 2) 1 0 1 (by norm_num))
  have hlim : Filter.Tendsto (fun w : Nat => 70 *
      (Real.logb 2 (Real.logb 2 (inputBits w)) / Real.logb 2 (inputBits w)))
      Filter.atTop (nhds 0) := by
    simpa using (hratio.comp encoded_log_tendsto).const_mul 70
  have hsmall : ∀ᶠ w : Nat in Filter.atTop,
      70 * (Real.logb 2 (Real.logb 2 (inputBits w)) / Real.logb 2 (inputBits w)) < ε := by
    have h := hlim.eventually (Iio_mem_nhds hε)
    simpa using h
  have hevent : ∀ᶠ w : Nat in Filter.atTop, ∀ C : Circuit (inputBits w),
      C.Computes (satFunction w) →
      ((17 / 7 : ℝ) - ε) * inputBits w ≤ (C.size : ℝ) := by
    filter_upwards [Filter.eventually_ge_atTop (32 : Nat), hsmall] with w hw hs
    intro C hc
    have hmain := seventeen_sevenths_logarithmic_bound w hw C hc
    have hn : (0 : ℝ) ≤ inputBits w := by positivity
    have hm := mul_le_mul_of_nonneg_left hs.le hn
    have he : (inputBits w : ℝ) * (70 *
        (Real.logb 2 (Real.logb 2 (inputBits w)) / Real.logb 2 (inputBits w))) =
        70 * inputBits w * Real.logb 2 (Real.logb 2 (inputBits w)) /
          Real.logb 2 (inputBits w) := by ring
    rw [he] at hm
    nlinarith
  exact Filter.eventually_atTop.mp hevent

end SatLowerBound
