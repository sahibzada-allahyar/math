import Credit.TwoLevel.Robust

/-! Restriction consequences of the manuscript's robust-block definition. -/
namespace SatLowerBound

/-- Any free coordinate is essential when at least two free coordinates
remain in a robust restriction. -/
theorem Robust.every_free_essential {n k : Nat} {f : (Fin n → Bool) → Bool}
    (h : Robust k f) (ρ : Fin n → Option Bool)
    (hk : k ≤ (freeCoordinates ρ).card) (h2 : 2 ≤ (freeCoordinates ρ).card)
    (z : Fin n) (hz : ρ z = none) : Essential (fun x => f (applyPartial ρ x)) z := by
  obtain ⟨w,hw,hwz⟩ := Finset.exists_mem_ne (show 1 < (freeCoordinates ρ).card by omega) z
  have hwfree : ρ w = none := (Finset.mem_filter.mp hw).2
  exact h.restricted_essential ρ hk z w (Ne.symm hwz) hz hwfree

/-- A coordinate fixed by a partial assignment is inessential in the cofactor. -/
theorem essential_of_partial_is_free {n : Nat} (f : (Fin n → Bool) → Bool)
    (ρ : Fin n → Option Bool) (z : Fin n)
    (h : Essential (fun x => f (applyPartial ρ x)) z) : ρ z = none := by
  cases hρ : ρ z with
  | none => rfl
  | some b =>
    obtain ⟨u,v,hu,hne⟩ := h
    exfalso
    apply hne
    have heq : applyPartial ρ u = applyPartial ρ v := by
      funext w
      unfold applyPartial
      by_cases hw : w = z
      · subst w
        rw [hρ]
        rfl
      · rw [hu w hw]
    exact congrArg f heq

/-- The four-cofactor condition survives any robust restriction on the
remaining essential coordinates, even when the ambient type retains fixed bits. -/
theorem Robust.restricted_s4Essential {n k : Nat} {f : (Fin n → Bool) → Bool}
    (h : Robust k f) (ρ : Fin n → Option Bool) (hk : k ≤ (freeCoordinates ρ).card) :
    S4Essential (fun x => f (applyPartial ρ x)) := by
  intro i j hij hi hj
  exact h ρ hk i j hij (essential_of_partial_is_free f ρ i hi)
    (essential_of_partial_is_free f ρ j hj)

/-- Fix a coordinate that is still free, retaining existing fixed values. -/
def partialFix {n : Nat} (ρ : Fin n → Option Bool) (x : Fin n) (b : Bool) : Fin n → Option Bool :=
  fun z => if z = x ∧ ρ z = none then some b else ρ z

theorem applyPartial_fixBit {n : Nat} (ρ : Fin n → Option Bool) (x : Fin n)
    (b : Bool) (v : Fin n → Bool) :
    applyPartial ρ (fixBit x b v) = applyPartial (partialFix ρ x b) v := by
  funext z
  by_cases hz : z = x
  · subst z
    cases hρ : ρ x <;> simp [applyPartial,partialFix,fixBit,hρ]
  · simp [applyPartial,partialFix,fixBit,hz]

theorem freeCoordinates_partialFix {n : Nat} (ρ : Fin n → Option Bool)
    (x : Fin n) (b : Bool) :
    freeCoordinates (partialFix ρ x b) = (freeCoordinates ρ).erase x := by
  apply Finset.ext
  intro z
  simp only [freeCoordinates,Finset.mem_erase,Finset.mem_filter,Finset.mem_univ,true_and]
  change (if z = x ∧ ρ z = none then some b else ρ z) = none ↔ z ≠ x ∧ ρ z = none
  by_cases hz : z = x
  · subst z
    cases hρ : ρ x <;> simp_all
  · simp [hz]

theorem partialFix_free_card {n : Nat} (ρ : Fin n → Option Bool)
    (x : Fin n) (b : Bool) :
    (freeCoordinates ρ).card ≤ (freeCoordinates (partialFix ρ x b)).card + 1 := by
  rw [freeCoordinates_partialFix]
  by_cases hx : x ∈ freeCoordinates ρ
  · have hh := Finset.card_erase_add_one hx
    omega
  · rw [Finset.erase_eq_of_notMem hx]
    omega

/-- Every free essential coordinate remains essential after one more fixing,
provided the robust restriction has at least `k+1` free coordinates. -/
theorem Robust.restricted_e1 {n k : Nat} {f : (Fin n → Bool) → Bool}
    (h : Robust k f) (ρ : Fin n → Option Bool)
    (hk : k + 1 ≤ (freeCoordinates ρ).card) (h2 : 2 ≤ k) :
    E1 (fun x => f (applyPartial ρ x)) := by
  intro x b z hzx hz
  let τ := partialFix ρ x b
  have hcard := partialFix_free_card ρ x b
  change (freeCoordinates ρ).card ≤ (freeCoordinates τ).card + 1 at hcard
  have hzfree := essential_of_partial_is_free f ρ z hz
  have hzt : τ z = none := by simp [τ,partialFix,hzx,hzfree]
  have hess := h.every_free_essential τ (by omega) (by omega) z hzt
  have heq : (fun v => f (applyPartial τ v)) =
      (fun v => f (applyPartial ρ (fixBit x b v))) := by
    funext v
    rw [applyPartial_fixBit]
  rwa [heq] at hess

/-- The corresponding two-fixing condition for a robust restriction. -/
theorem Robust.restricted_e2 {n k : Nat} {f : (Fin n → Bool) → Bool}
    (h : Robust k f) (ρ : Fin n → Option Bool)
    (hk : k + 2 ≤ (freeCoordinates ρ).card) (h2 : 2 ≤ k) :
    E2 (fun x => f (applyPartial ρ x)) := by
  intro x y a b z _hxy hzx hzy hz
  let τ := partialFix ρ x a
  have hc := partialFix_free_card ρ x a
  change (freeCoordinates ρ).card ≤ (freeCoordinates τ).card + 1 at hc
  have he1 := h.restricted_e1 ρ (by omega) h2
  have he1τ := h.restricted_e1 τ (by omega) h2
  have hz₁ := he1 x a z hzx hz
  have heq : (fun v => f (applyPartial τ v)) =
      (fun v => f (applyPartial ρ (fixBit x a v))) := by
    funext v
    rw [applyPartial_fixBit]
  have hzτ : Essential (fun v => f (applyPartial τ v)) z := by rw [heq]; exact hz₁
  have hz₂ := he1τ y b z hzy hzτ
  rw [heq] at hz₂
  have heval : (fun v => f (applyPartial ρ (fixBit x a (fixBit y b v)))) =
      (fun v => f (applyPartial ρ (setPair v x y a b))) := by
    funext v
    rw [ModularTree.setPair_eq_fixBit]
  rwa [heval] at hz₂

/-- The full semantic context required by the elimination lemma for an
arbitrary sufficiently large robust cofactor. -/
theorem Robust.restricted_goodFn {n k : Nat} {f : (Fin n → Bool) → Bool}
    (h : Robust k f) (ρ : Fin n → Option Bool)
    (hk : k + 2 ≤ (freeCoordinates ρ).card) (h2 : 2 ≤ k) :
    GoodFn (fun x => f (applyPartial ρ x)) := by
  have hf : 1 < (freeCoordinates ρ).card := by omega
  obtain ⟨i,hi,j,hj,hij⟩ := Finset.one_lt_card.mp hf
  have hiρ : ρ i = none := (Finset.mem_filter.mp hi).2
  have hjρ : ρ j = none := (Finset.mem_filter.mp hj).2
  have hie := h.every_free_essential ρ (by omega) (by omega) i hiρ
  have hje := h.every_free_essential ρ (by omega) (by omega) j hjρ
  have he1 := h.restricted_e1 ρ (by omega) h2
  have he2 := h.restricted_e2 ρ hk h2
  have h4 := h.restricted_s4Essential ρ (by omega)
  refine ⟨⟨i,j,hij,hie,hje⟩,he1,he2,?_,?_⟩
  · intro x y hxy hx hy
    exact (h4 x y hxy hx hy).threeRows
  · intro x b
    by_cases hxi : i = x
    · have hjx : j ≠ x := by intro he; exact hij (hxi.trans he.symm)
      exact (he1 x b j hjx hje).nonconstant
    · exact (he1 x b i hxi hie).nonconstant

/-- A robust function on at least `k+1` inputs has (E1), provided at least
two free coordinates remain after a single restriction. -/
theorem Robust.e1 {n k : Nat} {f : (Fin n → Bool) → Bool}
    (h : Robust k f) (hk : k + 1 ≤ n) (h2 : 3 ≤ n) : E1 f := by
  intro x b z hzx _
  let ρ : Fin n → Option Bool := fun w => if w = x then some b else none
  have hfree : freeCoordinates ρ = Finset.univ.erase x := by
    ext w
    by_cases he : w = x <;> simp [freeCoordinates,ρ,he]
  have hcard : (freeCoordinates ρ).card + 1 = n := by
    rw [hfree, Finset.card_erase_add_one (Finset.mem_univ x), Finset.card_univ, Fintype.card_fin]
  have hz : ρ z = none := by simp [ρ,hzx]
  have he := h.every_free_essential ρ (by omega) (by omega) z hz
  have hfun : (fun v => f (applyPartial ρ v)) = fun v => f (fixBit x b v) := by
    funext v
    congr 1
    funext w
    by_cases heq : w = x <;> simp [applyPartial,ρ,fixBit,heq]
  rwa [hfun] at he

/-- With two additional coordinates beyond the robustness threshold, every
two-input restriction preserves each remaining essential input: (E2). -/
theorem Robust.e2 {n k : Nat} {f : (Fin n → Bool) → Bool}
    (h : Robust k f) (hk : k + 2 ≤ n) (h2 : 4 ≤ n) : E2 f := by
  intro x y a b z hxy hzx hzy _
  let ρ : Fin n → Option Bool := fun w => if w = x then some a else if w = y then some b else none
  have hfree : freeCoordinates ρ = (Finset.univ.erase x).erase y := by
    ext w
    by_cases hx : w = x <;> by_cases hy : w = y <;> simp [freeCoordinates,ρ,hx,hy,Ne.symm hxy]
  have hcard : (freeCoordinates ρ).card + 2 = n := by
    have hy : y ∈ (Finset.univ : Finset (Fin n)).erase x := by simp [Ne.symm hxy]
    have h1 := Finset.card_erase_add_one (Finset.mem_univ x)
    have h2' := Finset.card_erase_add_one hy
    rw [hfree]
    simp only [Finset.card_univ, Fintype.card_fin] at h1
    omega
  have hz : ρ z = none := by simp [ρ,hzx,hzy]
  have he := h.every_free_essential ρ (by omega) (by omega) z hz
  have hfun : (fun v => f (applyPartial ρ v)) = fun v => f (setPair v x y a b) := by
    funext v
    congr 1
    funext w
    by_cases hx : w = x <;> by_cases hy : w = y <;> simp [applyPartial,ρ,setPair,hx,hy,Ne.symm hxy]
  rwa [hfun] at he

end SatLowerBound
