import Credit.TwoLevel.SubsetSumLeading
import Mathlib.LinearAlgebra.Vandermonde

/-! Determinant representation of the signed Vandermonde polynomial. -/
namespace SatLowerBound
open MvPolynomial

/-- The product of pairwise square differences is the determinant of the
Vandermonde matrix at the negated squared indeterminates. -/
theorem signedVandermonde_eq_det {R : Type} [CommRing R] (d : Nat) :
    signedVandermonde R d = Matrix.det (Matrix.vandermonde
      (fun i : Fin d => -(X i : MvPolynomial (Fin d) R) ^ 2)) := by
  classical
  rw [Matrix.det_vandermonde]
  unfold signedVandermonde variablePairs
  rw [Finset.prod_filter]
  rw [Finset.product_eq_sprod, Finset.prod_product]
  apply Finset.prod_congr rfl
  intro i _
  rw [← Finset.prod_filter]
  apply Finset.prod_congr
  · ext j
    simp
  · intro j _
    ring

/-- The homogeneous polynomial's leading coefficient can be expanded as an
alternating sum indexed by permutations, matching the determinant step of
the cited argument. -/
theorem signedLeadingPolynomial_coeff_permutation_sum {R : Type} [CommRing R]
    (d k : Nat) (t : Fin d →₀ Nat) :
    (signedLeadingPolynomial R d k).coeff t =
      ∑ e : Equiv.Perm (Fin d),
        ((e.sign • (∏ i : Fin d, (-(X (e i) : MvPolynomial (Fin d) R) ^ 2) ^ i.val)) *
          (∑ i : Fin d, X i) ^ k).coeff t := by
  classical
  unfold signedLeadingPolynomial
  rw [signedVandermonde_eq_det, Matrix.det_apply, Finset.sum_mul, MvPolynomial.coeff_sum]
  rfl

end SatLowerBound
