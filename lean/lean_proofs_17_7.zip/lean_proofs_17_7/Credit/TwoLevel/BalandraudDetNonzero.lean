import Credit.TwoLevel.BalandraudDomains

/-! Reduction of prime-field determinant nonvanishing to its integer value. -/
namespace SatLowerBound

/-- Balandraud's determinant evaluation with denominators cleared. This form
also covers the endpoints where the exponent in the fractional expression
would be negative. -/
def BalandraudDeterminantIdentity (d cut : Nat) : Prop :=
  (binomialCoefficientMatrix (R := ℤ) (balandraudExponent d cut)).det *
      (2 : ℤ) ^ cut * (d : ℤ) =
    (2 : ℤ) ^ Nat.choose d 2 * (Nat.choose d cut : ℤ) * ((d + cut : Nat) : ℤ)

/-- Binomial coefficients in row `n` are nonzero in prime characteristic
when `n` is smaller than the characteristic. -/
theorem choose_cast_ne_zero_of_lt_char {R : Type} [Field R]
    (p n k : Nat) [Fact p.Prime] [CharP R p] (hkn : k ≤ n) (hnp : n < p) :
    (Nat.choose n k : R) ≠ 0 := by
  have hf : (Nat.factorial n : R) ≠ 0 :=
    ((IsUnit.natCast_factorial_iff_of_charP (A := R) p).mpr hnp).ne_zero
  have hc : (Nat.choose n k : R) * (Nat.factorial k : R) *
      (Nat.factorial (n - k) : R) = (Nat.factorial n : R) := by
    simpa only [Nat.cast_mul] using congrArg (fun x : Nat => (x : R))
      (Nat.choose_mul_factorial_mul_factorial hkn)
  intro hz
  apply hf
  rw [← hc, hz]
  simp

/-- The determinant formula implies nonvanishing modulo every odd prime
larger than twice the dimension. -/
theorem balandraud_det_ne_zero_of_identity
    {p d cut : Nat} [Fact p.Prime] (hd : 0 < d) (hdp : 2 * d < p)
    (hcut : cut ≤ d) (hidentity : BalandraudDeterminantIdentity d cut) :
    (binomialCoefficientMatrix (R := ZMod p) (balandraudExponent d cut)).det ≠ 0 := by
  have hp2 : 2 < p := by omega
  have htwo : (2 : ZMod p) ≠ 0 := by
    intro h
    have hv : p ∣ 2 := (ZMod.natCast_eq_zero_iff 2 p).mp (by simpa using h)
    have hle := Nat.le_of_dvd (by decide : 0 < 2) hv
    omega
  have hn : d < p := by omega
  have hc : (Nat.choose d cut : ZMod p) ≠ 0 :=
    choose_cast_ne_zero_of_lt_char p d cut hcut hn
  have hsum : ((d + cut : Nat) : ZMod p) ≠ 0 := by
    have hpos : 0 < d + cut := by omega
    have hlt : d + cut < p := by omega
    intro hz
    have hdiv : p ∣ d + cut := (ZMod.natCast_eq_zero_iff _ _).mp hz
    have hle := Nat.le_of_dvd hpos hdiv
    omega
  have heq := congrArg (fun z : ℤ => (z : ZMod p)) hidentity
  have hmat : (binomialCoefficientMatrix (R := ZMod p) (balandraudExponent d cut)).det =
      ((binomialCoefficientMatrix (R := ℤ) (balandraudExponent d cut)).det : ZMod p) := by
    change (binomialCoefficientMatrix (R := ZMod p) (balandraudExponent d cut)).det =
      (Int.castRingHom (ZMod p)) ((binomialCoefficientMatrix (R := ℤ)
        (balandraudExponent d cut)).det)
    rw [RingHom.map_det]
    congr 1
    ext i j
    simp [binomialCoefficientMatrix]
  rw [hmat]
  intro hzero
  have hrhs : (2 : ZMod p) ^ Nat.choose d 2 * (Nat.choose d cut : ZMod p) *
      ((d + cut : Nat) : ZMod p) ≠ 0 :=
    mul_ne_zero (mul_ne_zero (pow_ne_zero _ htwo) hc) hsum
  apply hrhs
  simpa [BalandraudDeterminantIdentity, hzero] using heq.symm

/-- If the first column consists of ones, subtracting each preceding row
and expanding in that column leaves the determinant of the differences. -/
theorem det_eq_det_successive_row_differences {R : Type} [CommRing R]
    {n : Nat} (A : Matrix (Fin (n + 1)) (Fin (n + 1)) R)
    (hfirst : ∀ i, A i 0 = 1) :
    A.det = (Matrix.of fun i j : Fin n =>
      A i.succ j.succ - A (Fin.castSucc i) j.succ).det := by
  classical
  let B : Matrix (Fin (n + 1)) (Fin (n + 1)) R :=
    Matrix.of fun i j => Fin.cases (A 0 j)
      (fun k => A k.succ j - A (Fin.castSucc k) j) i
  have heq : A.det = B.det := by
    apply Matrix.det_eq_of_forall_row_eq_smul_add_pred (fun _ => 1)
    · intro j
      rfl
    · intro i j
      dsimp [B]
      ring
  rw [heq, Matrix.det_succ_column_zero, Fin.sum_univ_succ]
  simp only [Fin.val_zero, pow_zero, one_mul]
  have hb0 : B 0 0 = 1 := hfirst 0
  have hbs (i : Fin n) : B i.succ 0 = 0 := by
    simp [B, hfirst]
  simp only [hb0, hbs, mul_zero, zero_mul, Finset.sum_const_zero, add_zero]
  simp [B, Matrix.submatrix]

/-- Consecutive upper indices and initial lower index zero reduce the
binomial determinant to the smaller determinant, by Pascal's identity. -/
theorem binomial_det_consecutive_rows (n x : Nat) (b : Fin n → Nat) :
    (Matrix.of (fun i j : Fin (n + 1) =>
      (Nat.choose (x + i.val) (Fin.cases 0 (fun k => b k + 1) j) : ℤ))).det =
    (Matrix.of (fun i j : Fin n => (Nat.choose (x + i.val) (b j) : ℤ))).det := by
  classical
  let A : Matrix (Fin (n + 1)) (Fin (n + 1)) ℤ := Matrix.of fun i j =>
    (Nat.choose (x + i.val) (Fin.cases 0 (fun k => b k + 1) j) : ℤ)
  have hfirst : ∀ i, A i 0 = 1 := by
    intro i
    simp [A]
  rw [show (Matrix.of (fun i j : Fin (n + 1) =>
      (Nat.choose (x + i.val) (Fin.cases 0 (fun k => b k + 1) j) : ℤ))).det = A.det from rfl,
    det_eq_det_successive_row_differences A hfirst]
  congr 1
  ext i j
  simp only [Matrix.of_apply, A, Fin.val_succ, Fin.val_castSucc, Fin.cases_succ]
  have h := Nat.choose_succ_succ (x + i.val) (b j)
  have hh : (Nat.choose (x + i.val + 1) (b j + 1) : ℤ) =
      (Nat.choose (x + i.val) (b j) : ℤ) +
        (Nat.choose (x + i.val) (b j + 1) : ℤ) := by exact_mod_cast h
  simp only [Nat.add_assoc] at *
  omega

/-- Clearing the row and column factors in the standard shifted-binomial
determinant identity requires no division. -/
theorem binomial_det_shift_factor (n : Nat) (a b : Fin n → Nat) :
    (∏ j : Fin n, ((b j + 1 : Nat) : ℤ)) *
      (Matrix.of (fun i j : Fin n => (Nat.choose (a i + 1) (b j + 1) : ℤ))).det =
    (∏ i : Fin n, ((a i + 1 : Nat) : ℤ)) *
      (Matrix.of (fun i j : Fin n => (Nat.choose (a i) (b j) : ℤ))).det := by
  classical
  rw [← Matrix.det_mul_row, ← Matrix.det_mul_column]
  congr 1
  ext i j
  simp only [Matrix.of_apply]
  have h := Nat.add_one_mul_choose_eq (a i) (b j)
  have hh := congrArg (fun x : Nat => (x : ℤ)) h
  simp only [Nat.cast_mul, Nat.cast_add, Nat.cast_one] at hh ⊢
  linarith

/-- The cleared integer determinant formula supplies the hypothesis needed
for the triangular subset-sum bound. -/
theorem balandraud_subsetSum_of_det_identity
    {p d cut : Nat} [Fact p.Prime] (hpodd : p ≠ 2) (a : Fin d → ZMod p)
    (ha : Function.Injective a) (hopp : ∀ i j, a i ≠ -a j)
    (hd : 0 < d) (hdp : 2 * d < p) (hcut : cut ≤ d)
    (hkp : Nat.choose (d + 1) 2 - cut < p)
    (hidentity : BalandraudDeterminantIdentity d cut) :
    Nat.choose (d + 1) 2 - cut < (Finset.univ.image a).subsetSum.card := by
  exact balandraudDomains_subsetSum_triangular hpodd a ha hopp (Nat.le_of_lt hdp)
    hcut hkp (balandraud_det_ne_zero_of_identity hd hdp hcut hidentity)

end SatLowerBound
