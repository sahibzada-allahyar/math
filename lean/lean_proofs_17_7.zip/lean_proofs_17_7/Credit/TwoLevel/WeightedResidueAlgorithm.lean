import Credit.TwoLevel.WeightedDegree

/-! The residue-parity recurrence used to find a full-degree modular block. -/
namespace SatLowerBound

/-- The weighted sum of an extended assignment adds the last weight exactly
when the new bit is true. -/
theorem weightedSum_extend (n p : Nat) (v : Fin n → Bool) (b : Bool) :
    weightedSum (p := p) (extend v b) = weightedSum v +
      (if b then ((n + 1 : Nat) : ZMod p) else 0) := by
  unfold weightedSum
  rw [Fin.sum_univ_castSucc]
  simp only [Fin.val_castSucc,Fin.val_last,extend_old,extend_last]

/-- The top coefficient satisfies the paper's one-coordinate update. -/
theorem weightedBlock_top_step (n p : Nat) (t : ZMod p) :
    (BPoly.ofFunction (n+1) (weightedModularBlock (n+1) p t)).topCoefficient =
      Bool.xor (BPoly.ofFunction n (weightedModularBlock n p t)).topCoefficient
        (BPoly.ofFunction n (weightedModularBlock n p (t - (n + 1 : Nat)))).topCoefficient := by
  rw [BPoly.top_function_step]
  congr 2
  · congr 1
    funext v
    simp [weightedModularBlock,weightedSum_extend]
  · congr 1
    funext v
    simp [weightedModularBlock,weightedSum_extend,eq_sub_iff_add_eq]

/-- The paper's recurrence `v ← v + z^i v` on Boolean residue parities. -/
def weightedResidueParity (p : Nat) : Nat → ZMod p → Bool
  | 0, t => decide (t = 0)
  | n + 1, t => Bool.xor (weightedResidueParity p n t)
      (weightedResidueParity p n (t - (n + 1 : Nat)))

/-- The recurrence computes the actual top coefficient of every residue
block, not merely a proxy for it. -/
theorem weightedResidueParity_correct (n p : Nat) (t : ZMod p) :
    weightedResidueParity p n t = (BPoly.ofFunction n (weightedModularBlock n p t)).topCoefficient := by
  induction n generalizing t with
  | zero =>
    simp [weightedResidueParity, BPoly.ofFunction, BPoly.topCoefficient, weightedModularBlock,weightedSum]
    exact eq_comm
  | succ n ih =>
    rw [weightedResidueParity, weightedBlock_top_step, ih, ih]

/-- For the paper's odd prime modulus, at least one entry produced by the
recurrence is true. -/
theorem weightedResidueParity_exists (n p : Nat) (hp : p.Prime) (hpodd : p ≠ 2) (hnp : n < p) :
    ∃ t : ZMod p, weightedResidueParity p n t = true := by
  obtain ⟨t,ht⟩ := weighted_block_full_degree_of_prime n p hp hpodd hnp
  exact ⟨t, (weightedResidueParity_correct n p t).trans ht⟩

end SatLowerBound
