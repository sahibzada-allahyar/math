import SatLowerBound.TexDegreeBound

/-! Proposition 5.5 for arbitrary positive leaf degrees, not only
full-degree leaves. -/
namespace SatLowerBound
namespace BPoly

@[simp] theorem tensor_zero_right {n : Nat} (p : BPoly n) (m : Nat) :
    p.tensor (zero m) = zero (n+m) := by
  induction m with
  | zero => simp [tensor,zero,select]
  | succ m ih => simp [tensor,zero,ih]

theorem hasDegree_shift_bound {n d : Nat} (p : BPoly n) (hp : p.HasDegree d) (k : Nat) :
    p.DegreeLT (d+k) ↔ 0 < k := by
  cases k with
  | zero => simpa using hp.2
  | succ k =>
    constructor
    · intro _; omega
    · intro _; exact degree_mono p hp.1 (by omega)

/-- Disjoint multiplication shifts the exact degree filtration by d. -/
theorem tensor_degreeLT_iff {n m d : Nat} (p : BPoly n) (hp : p.HasDegree d)
    (q : BPoly m) (k : Nat) :
    (p.tensor q).DegreeLT (d+k) ↔ q.DegreeLT k := by
  induction q generalizing k with
  | constant b =>
    cases b with
    | false => simp [tensor,select,DegreeLT,zero_degree]
    | true => simpa [tensor,select,DegreeLT] using hasDegree_shift_bound p hp k
  | node q s ihq ihs =>
    cases k with
    | zero =>
      change ((p.tensor q).DegreeLT d ∧ (p.tensor s).DegreeLT (d-1)) ↔
        q.DegreeLT 0 ∧ s.DegreeLT 0
      constructor
      · rintro ⟨hq,hs⟩
        exact ⟨(ihq 0).mp hq,(ihs 0).mp (degree_mono _ hs (by omega))⟩
      · rintro ⟨hq,hs⟩
        refine ⟨(ihq 0).mpr hq,?_⟩
        rw [(degree_zero_iff s).mp hs,tensor_zero_right]
        exact zero_degree _ _
    | succ k =>
      change ((p.tensor q).DegreeLT (d+(k+1)) ∧
        (p.tensor s).DegreeLT (d+(k+1)-1)) ↔ q.DegreeLT (k+1) ∧ s.DegreeLT k
      rw [show d+(k+1)-1 = d+k by omega,ihq,ihs]

/-- Disjoint AND multiplies nonzero polynomials and adds their degrees. -/
theorem hasDegree_tensor {n m d e : Nat} (p : BPoly n) (q : BPoly m)
    (hp : p.HasDegree d) (hq : q.HasDegree e) : (p.tensor q).HasDegree (d+e) := by
  constructor
  · have h := (tensor_degreeLT_iff p hp q (e+1)).mpr hq.1
    simpa [Nat.add_assoc] using h
  · intro h
    exact hq.2 ((tensor_degreeLT_iff p hp q e).mp h)

theorem one_hasDegree_zero (n : Nat) : (one n).HasDegree 0 := by
  refine ⟨one_degree n,?_⟩
  intro h
  have he := (degree_zero_iff (one n)).mp h
  have hh := congrArg (fun p : BPoly n => p.eval (fun _ => false)) he
  simp [eval_one,eval_zero] at hh

theorem add_add_self_cancel {n : Nat} (p q : BPoly n) : p.add (p.add q) = q := by
  apply BPoly.ext
  intro v
  simp only [eval_add]
  cases p.eval v <;> cases q.eval v <;> rfl

/-- Disjoint OR has the same top-degree part as the product when both
factors have positive degree. -/
theorem hasDegree_disjointOr {n m d e : Nat} (p : BPoly n) (q : BPoly m)
    (hd : 0 < d) (he : 0 < e) (hp : p.HasDegree d) (hq : q.HasDegree e) :
    (p.disjointOr q).HasDegree (d+e) := by
  have hprod := hasDegree_tensor p q hp hq
  have hleft := hasDegree_tensor p (one m) hp (one_hasDegree_zero m)
  have hright := hasDegree_tensor (one n) q (one_hasDegree_zero n) hq
  let a := (p.tensor (one m)).add ((one n).tensor q)
  have ha : a.DegreeLT (d+e) := degree_add _ _
    (degree_mono _ hleft.1 (by omega)) (degree_mono _ hright.1 (by omega))
  refine ⟨degree_add _ _ (degree_mono _ ha (by omega)) hprod.1,?_⟩
  intro h
  have hsum := degree_add a (a.add (p.tensor q)) ha h
  rw [add_add_self_cancel] at hsum
  exact hprod.2 hsum

end BPoly
namespace ReadOnce

/-- Assign each leaf its positive exact degree and sum those degrees
through the tree, as in Proposition 5.5. -/
inductive HasLeafDegrees : {n : Nat} → ReadOnce n → Nat → Prop where
  | leaf {n d : Nat} (f : (Fin n → Bool) → Bool) (hd : 0 < d)
      (hf : (BPoly.ofFunction n f).HasDegree d) : HasLeafDegrees (.leaf f) d
  | branch {n m d e : Nat} (isOr : Bool) (a : ReadOnce n) (b : ReadOnce m)
      (ha : HasLeafDegrees a d) (hb : HasLeafDegrees b e) :
      HasLeafDegrees (.branch isOr a b) (d+e)

theorem HasLeafDegrees.positive {n d : Nat} {T : ReadOnce n}
    (h : HasLeafDegrees T d) : 0 < d := by
  induction h with
  | leaf f hd hf => exact hd
  | branch isOr a b ha hb iha ihb => omega

/-- The degree of any read-once AND/OR composition is the sum of its
positive leaf degrees, without requiring that the leaves have full degree. -/
theorem degree_of_leaf_degrees {n d : Nat} {T : ReadOnce n}
    (h : HasLeafDegrees T d) : (BPoly.ofFunction n T.eval).HasDegree d := by
  induction h with
  | leaf f hd hf => exact hf
  | @branch n m d e isOr a b ha hb iha ihb =>
    cases isOr with
    | false =>
      have heq : BPoly.ofFunction (n+m) (ReadOnce.branch false a b).eval =
          (BPoly.ofFunction n a.eval).tensor (BPoly.ofFunction m b.eval) := by
        apply BPoly.ext
        intro v
        simp [BPoly.eval_ofFunction,BPoly.eval_tensor,ReadOnce.eval]
      rw [heq]
      exact BPoly.hasDegree_tensor _ _ iha ihb
    | true =>
      have heq : BPoly.ofFunction (n+m) (ReadOnce.branch true a b).eval =
          (BPoly.ofFunction n a.eval).disjointOr (BPoly.ofFunction m b.eval) := by
        apply BPoly.ext
        intro v
        simp [BPoly.eval_ofFunction,BPoly.eval_disjointOr,ReadOnce.eval]
      rw [heq]
      exact BPoly.hasDegree_disjointOr _ _ ha.positive hb.positive iha ihb

/-- The nonlinear-gate consequence of Proposition 5.5 for arbitrary
positive degrees, on an unrestricted circuit computing the composition. -/
theorem nonlinear_bound_of_leaf_degrees {n d : Nat} {T : ReadOnce n}
    (h : HasLeafDegrees T d) (C : Circuit n) (hc : C.Computes T.eval) :
    d ≤ C.nonlinearCount+1 :=
  C.nonlinear_bound_of_exact_degree T.eval hc (degree_of_leaf_degrees h)

end ReadOnce

end SatLowerBound
