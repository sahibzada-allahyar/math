import Credit.TwoLevel.BalandraudFiniteSet
import Credit.TwoLevel.WeightedCertificate

/-! Unconditional weighted-construction certificates, with the cited
subset-sum theorem supplied by its Lean proof. -/
namespace SatLowerBound

theorem weightedPrime_subsetSumBound (r : Nat) (hr : 1 ≤ r)
    (A : Finset (ZMod (weightedPrime r))) (hA : ∀ x ∈ A, -x ∉ A) :
    min (weightedPrime r) (1 + A.card * (A.card + 1) / 2) ≤ A.subsetSum.card := by
  obtain ⟨hp, hlarge⟩ := weightedPrime_spec r
  let _ : Fact (weightedPrime r).Prime := ⟨hp⟩
  exact balandraud_subsetSum_bound (by omega) A hA

theorem exists_paper_weighted_block (r : Nat) (hr : 4 ≤ r)
 :
    ∃ t : ZMod (weightedPrime r),
      Robust (weightedTriangleThreshold (weightedPrime r) + 2)
        (weightedModularBlock r (weightedPrime r) t) ∧
      (BPoly.ofFunction r (weightedModularBlock r (weightedPrime r) t)).topCoefficient = true := by
  exact exists_paper_weighted_block_of_subsetSumBound r hr
    (weightedPrime_subsetSumBound r (by omega))

theorem paper_weighted_finite_certificate (w : Nat) (hw : 32 ≤ w)
 :
    ∃ t : ZMod (weightedPrime (paperBlockSize w)), ∀ C : Circuit (inputBits w),
      C.Computes (satFunction w) →
      7 * (inputBits w : Int) +
        (30 * (paperBlockSize w : Int) -
          42 * ((weightedTriangleThreshold (weightedPrime (paperBlockSize w)) : Int) + 3)) *
          genericRemainingClauses w (canonicalForbiddenFamily
            (weightedModularBlock (paperBlockSize w) (weightedPrime (paperBlockSize w)) t)) - 3 ≤
        7 * (C.size : Int) := by
  obtain ⟨hr, _⟩ := paperBlockSize_bounds w hw
  exact paper_weighted_finite_certificate_of_subsetSumBound w hw
    (weightedPrime_subsetSumBound (paperBlockSize w) (by omega))

theorem paper_weighted_width_bound (w : Nat) (hw : 32 ≤ w)

    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    17 * (inputBits w : Int) -
      (30 * (logarithmicOffset w : Int) +
       42 * (weightedTriangleThreshold (weightedPrime (paperBlockSize w)) : Int) + 216) *
        (variableCount w : Int) - 3 ≤ 7 * (C.size : Int) := by
  obtain ⟨hr, _⟩ := paperBlockSize_bounds w hw
  exact paper_weighted_width_bound_of_subsetSumBound w hw
    (weightedPrime_subsetSumBound (paperBlockSize w) (by omega)) C hc

theorem paper_weighted_log_bound (w : Nat) (hw : 32 ≤ w)

    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    (17 / 7 : ℝ) * inputBits w -
      50 * inputBits w / Real.sqrt (Real.logb 2 (inputBits w)) ≤ (C.size : ℝ) := by
  obtain ⟨hr, _⟩ := paperBlockSize_bounds w hw
  exact paper_weighted_log_bound_of_subsetSumBound w hw
    (weightedPrime_subsetSumBound (paperBlockSize w) (by omega)) C hc

end SatLowerBound
