import Credit.TwoLevel.BalandraudGap

/-! Dimension recurrence for the binomial determinants. -/
namespace SatLowerBound

noncomputable def balandraudDet (d cut : Nat) : ℤ :=
  (binomialCoefficientMatrix (R := ℤ) (balandraudExponent d cut)).det

/-- The exponent vector is the consecutive sequence with the cut omitted. -/
theorem balandraudExponent_eq_succAbove {n : Nat} (c : Fin (n + 1)) (i : Fin n) :
    balandraudExponent n c.val i = n - 1 + (c.succAbove i).val := by
  rw [balandraudExponent_apply]
  simp only [Fin.succAbove, Fin.lt_def, Fin.val_castSucc]
  split_ifs <;> simp [Nat.add_assoc]

/-- The interior dimension recurrence with its integer product factors left
uncancelled. No division or determinant evaluation is assumed. -/
theorem balandraudDet_dimension_recurrence {n : Nat} (g : Fin n) :
    (∏ j : Fin n, ((2 * j.val + 1 : Nat) : ℤ)) * balandraudDet (n + 1) (g.val + 1) =
    (∏ i : Fin n, ((n + (g.castSucc.succAbove i).val : Nat) : ℤ)) *
      balandraudDet n g.val +
    (∏ i : Fin n, ((n + (g.succ.succAbove i).val : Nat) : ℤ)) *
      balandraudDet n (g.val + 1) := by
  classical
  have hn : 0 < n := Nat.zero_lt_of_lt g.isLt
  let B : Matrix (Fin n) (Fin n) ℤ := Matrix.of fun i j =>
    (Nat.choose (n + (g.castSucc.succAbove i).val) (2 * j.val + 1) : ℤ)
  let C : Matrix (Fin n) (Fin n) ℤ := Matrix.of fun i j =>
    (Nat.choose (n + (g.succ.succAbove i).val) (2 * j.val + 1) : ℤ)
  have hgap : balandraudDet (n + 1) (g.val + 1) = B.det + C.det := by
    have h := binomial_det_one_gap n n g (fun j => 2 * j.val + 1)
    have hm : binomialCoefficientMatrix (R := ℤ) (balandraudExponent (n + 1) (g.val + 1)) =
        Matrix.of (fun i j : Fin (n + 1) => Fin.cases (1 : ℤ)
          (fun k => (Nat.choose (n + (if i.val ≤ g.val then i.val else i.val + 1))
            (2 * k.val + 1 + 1) : ℤ)) j) := by
      ext i j
      refine Fin.cases ?_ (fun j => ?_) j
      · simp [binomialCoefficientMatrix]
      · simp only [binomialCoefficientMatrix, Matrix.of_apply, Fin.cases_succ,
          Fin.val_succ, balandraudExponent_apply, Nat.add_sub_cancel]
        congr 2; split_ifs <;> omega
    unfold balandraudDet
    rw [hm]
    exact h
  have hshift (c : Fin (n + 1)) :
      (∏ j : Fin n, ((2 * j.val + 1 : Nat) : ℤ)) *
        (Matrix.of (fun i j : Fin n =>
          (Nat.choose (n + (c.succAbove i).val) (2 * j.val + 1) : ℤ))).det =
      (∏ i : Fin n, ((n + (c.succAbove i).val : Nat) : ℤ)) * balandraudDet n c.val := by
    have h := binomial_det_shift_factor n
      (fun i => n - 1 + (c.succAbove i).val) (fun j => 2 * j.val)
    have ha (i : Fin n) : n - 1 + (c.succAbove i).val + 1 = n + (c.succAbove i).val := by omega
    simp only [ha] at h
    convert h using 1
    unfold balandraudDet
    congr 2
    ext i j
    simp only [binomialCoefficientMatrix, Matrix.of_apply, balandraudExponent_eq_succAbove]
  rw [hgap, mul_add]
  exact congrArg₂ (· + ·) (hshift g.castSucc) (hshift g.succ)

/-- The boundary with no missing initial row satisfies the corresponding
one-term dimension recurrence. -/
theorem balandraudDet_zero_dimension_recurrence (n : Nat) :
    (∏ j : Fin n, ((2 * j.val + 1 : Nat) : ℤ)) * balandraudDet (n + 1) 0 =
    (∏ i : Fin n, ((n + i.val + 1 : Nat) : ℤ)) * balandraudDet n 0 := by
  classical
  have htop (i : Fin (n + 1)) : balandraudExponent (n + 1) 0 i = n + 1 + i.val := by
    simp [balandraudExponent_apply]
    omega
  have hgap : balandraudDet (n + 1) 0 =
      (Matrix.of (fun i j : Fin n => (Nat.choose (n + 1 + i.val) (2 * j.val + 1) : ℤ))).det := by
    have h := binomial_det_consecutive_rows n (n + 1) (fun j => 2 * j.val + 1)
    unfold balandraudDet
    convert h using 1
    congr 1
    ext i j
    refine Fin.cases ?_ (fun j => ?_) j
    · simp [binomialCoefficientMatrix]
    · simp only [binomialCoefficientMatrix, htop, Matrix.of_apply, Fin.cases_succ, Fin.val_succ]
      congr 2
  rw [hgap]
  have h := binomial_det_shift_factor n (fun i => n + i.val) (fun j => 2 * j.val)
  have ha (i : Fin n) : n + i.val + 1 = n + 1 + i.val := by omega
  simp only [ha] at h ⊢
  convert h using 1
  unfold balandraudDet
  congr 2
  ext i j
  simp only [binomialCoefficientMatrix, Matrix.of_apply, balandraudExponent_apply,
    Nat.not_lt_zero, ↓reduceIte]
  have hi := i.isLt
  congr 2
  omega

/-- At the opposite boundary, the last column has only its final entry
nonzero, and removing it gives the zero-cut determinant in one lower dimension. -/
theorem balandraudDet_last_dimension_recurrence (n : Nat) :
    balandraudDet (n + 1) (n + 1) = balandraudDet n 0 := by
  classical
  let A := binomialCoefficientMatrix (R := ℤ) (balandraudExponent (n + 1) (n + 1))
  have ht (i : Fin (n + 1)) : balandraudExponent (n + 1) (n + 1) i = n + i.val := by
    simp [balandraudExponent_apply, i.isLt]
  have hz (i : Fin n) : A i.castSucc (Fin.last n) = 0 := by
    dsimp [A, binomialCoefficientMatrix]
    rw [ht]
    have hi := i.isLt
    simp [Nat.choose_eq_zero_of_lt (show n + i.val < 2 * n by omega)]
  have ho : A (Fin.last n) (Fin.last n) = 1 := by
    simp [A, binomialCoefficientMatrix, ht, two_mul]
  change A.det = _
  rw [Matrix.det_succ_column A (Fin.last n), Fin.sum_univ_castSucc]
  simp only [hz, mul_zero, zero_mul, Finset.sum_const_zero, zero_add, ho, mul_one,
    Fin.val_last, ← two_mul, pow_mul, neg_one_sq, one_pow, one_mul]
  unfold balandraudDet
  congr 1
  ext i j
  simp only [Matrix.submatrix_apply, Fin.succAbove_last, A, binomialCoefficientMatrix,
    ht, Fin.val_castSucc, balandraudExponent_apply, Nat.not_lt_zero, ↓reduceIte]
  have hi := i.isLt
  congr 2
  omega

end SatLowerBound
