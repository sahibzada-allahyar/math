import Credit.TwoLevel.UnreducedChain

/-! Gate-by-gate weight accounting for resolution of an unreduced circuit. -/
namespace SatLowerBound
namespace OpenCircuit

def gatePsi2W {n : Nat} (C : OpenCircuit n) (k : Nat) : Nat :=
  match C.gateAt k with
  | some (g,_,_) => g.psi2W
  | none => 0

theorem gatePsi2W_head {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n+1)) :
    (OpenCircuit.gate g i j rest).gatePsi2W n = g.psi2W := by
  simp [gatePsi2W,gateAt_head]

theorem gatePsi2W_tail {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n+1))
    (k : Nat) (hk : k ≠ n) :
    (OpenCircuit.gate g i j rest).gatePsi2W k = rest.gatePsi2W k := by
  simp [gatePsi2W,gateAt_tail g i j rest hk]

theorem aliasedPsi2Weight_cons {n : Nat} (g : Table) (i j : Fin n)
    (rest : OpenCircuit (n+1)) (ρ : Fin n → Res) :
    (OpenCircuit.gate g i j rest).aliasedPsi2Weight ρ =
      (if (Res.step g (ρ i) (ρ j)).isSome then g.psi2W else 0) +
        rest.aliasedPsi2Weight (FlatKeptAux.tailRes g i j ρ) := by
  cases h : Res.step g (ρ i) (ρ j) <;> simp [aliasedPsi2Weight,FlatKeptAux.tailRes,h]

theorem aliasedPsi2Weight_eq_sum {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) :
    C.aliasedPsi2Weight ρ =
      ∑ k ∈ Finset.range (n+C.size), if C.isAliased ρ k = true then C.gatePsi2W k else 0 := by
  induction C with
  | output o =>
    refine (Finset.sum_eq_zero (fun k _ => ?_)).symm
    rw [FlatKeptAux.isAliased_output]
    rfl
  | @gate n g i j rest ih =>
    have hFG : ∀ k, k ≠ n →
        (if (gate g i j rest).isAliased ρ k = true then (gate g i j rest).gatePsi2W k else 0) =
        (if rest.isAliased (FlatKeptAux.tailRes g i j ρ) k = true then rest.gatePsi2W k else 0) :=
      fun k hk => by rw [FlatKeptAux.isAliased_cons_tail g i j rest ρ hk,gatePsi2W_tail g i j rest k hk]
    have hG : (if rest.isAliased (FlatKeptAux.tailRes g i j ρ) n = true
        then rest.gatePsi2W n else 0) = 0 :=
      FlatKeptAux.ite_eq_zero_of_false (FlatKeptAux.isAliased_rest_head rest _) _
    rw [FlatKeptAux.size_cons,
      FlatKeptAux.sum_split (n+1+rest.size) n (by omega) _ _ hFG hG,
      FlatKeptAux.isAliased_cons_head,gatePsi2W_head,aliasedPsi2Weight_cons,ih]

/-- Resolution without fixing a credited input cannot increase the two-level
potential, even if the input circuit contains degenerate or dead gates. -/
theorem psi2_free_restriction_le_of_distinct {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (hsafe : C.DGateSafe)
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (horig : ∀ z, C.isDStar z.val = true → Essential f z) :
    (C.restrict (fixSubst P c)).psi2 ≤ C.psi2 := by
  have hloss : C.credit2Lost (C.restrict (fixSubst P c)) ≤ C.aliasedPsi2Weight (fixRes P c) := by
    rw [C.free_credit_loss_eq_gate_charges_distinct P c hDistinct W V hfree hw hv hess,
      C.aliasedPsi2Weight_eq_sum]
    apply Finset.sum_le_sum
    intro k _
    cases ha : C.isAliased (fixRes P c) k with
    | false =>
      rw [C.free_gate_charge_zero_of_not_aliased_distinct P c hDistinct W V hfree hw hv hess k ha]
      simp
    | true =>
      cases hk : C.gateAt k with
      | none => simp [isAliased,hk] at ha
      | some p =>
        obtain ⟨g,a,b⟩ := p
        cases he : g.essential with
        | false =>
          have hz := C.gate_charges_zero_of_degenerate P c hDistinct W V hfree hess hw hv k g a b hk he
          rw [hz]
          simp
        | true =>
          have hcap := C.free_gate_total_charge_le_two_distinct P c hDistinct hsafe f hc hE1
            W V hfree hw hv hess horig k g a b hk
          have hweight : 4 ≤ g.psi2W := by
            revert he
            rcases g with ⟨a,b,c,d⟩
            cases a <;> cases b <;> cases c <;> cases d <;> decide
          simp only [↓reduceIte,gatePsi2W,hk]
          omega
  have hbalance := C.psi2_restriction_gain_loss P c
  omega

/-- Identity resolution preserves semantics and cannot increase potential in
any distinct-operand circuit satisfying the manuscript's E1 and essential-use
hypotheses. -/
theorem psi2_identity_resolution_le {n : Nat} (C : OpenCircuit n)
    (hDistinct : C.DistinctOperands) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z) :
    (C.restrict (fixSubst (fun _ => false) (fun _ => false))).psi2 ≤ C.psi2 ∧
      ∀ v, (C.restrict (fixSubst (fun _ => false) (fun _ => false))).eval v = C.eval v := by
  classical
  let P : Fin n → Bool := fun _ => false
  let c : Fin n → Bool := fun _ => false
  let R := C.restrict (fixSubst P c)
  have heval : ∀ v, R.eval v = C.eval v := by
    intro v
    dsimp [R]
    rw [restrict_eval]
    congr 1
    funext z
    simp [fixSubst,P,Signal.eval]
  have existsW : ∀ z : Fin n, C.isD z.val = true → ∃ w, w ∈ C.users z.val := by
    intro z hd
    obtain ⟨_,w,g,a,b,hgate,hab,_⟩ := (C.isD_iff z.val).mp hd
    exact ⟨w,C.mem_users.mpr ⟨g,a,b,hgate,hab⟩⟩
  let W : Fin n → Nat := fun z => if h : C.isD z.val = true then Classical.choose (existsW z h) else 0
  have hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val := by
    intro z hz
    simp only [W,hz,↓reduceDIte]
    exact Classical.choose_spec (existsW z hz)
  have existsV : ∀ z : Fin n, C.isDStar z.val = true → ∃ v, v ∈ C.users (W z) := by
    intro z hz
    have hd := C.isD_of_isDStar z.val hz
    obtain ⟨_,w,hmem,hDW⟩ := (C.isDStar_iff z.val).mp hz
    have hu := C.users_singleton_of_isD z.val (W z) hd (hw z hd)
    rw [hu,Finset.mem_singleton] at hmem
    subst w
    obtain ⟨_,v,g,a,b,hgate,hab,_⟩ := (C.isD_iff (W z)).mp hDW
    exact ⟨v,C.mem_users.mpr ⟨g,a,b,hgate,hab⟩⟩
  let V : Fin n → Nat := fun z => if h : C.isDStar z.val = true then Classical.choose (existsV z h) else 0
  have hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z) := by
    intro z hz
    simp only [V,hz,↓reduceDIte]
    exact Classical.choose_spec (existsV z hz)
  have horig : ∀ z, C.isDStar z.val = true → Essential C.eval z := by
    intro z hz
    have hd := C.isD_of_isDStar z.val hz
    apply hused z
    rw [C.usage_singleUse]
    have hh := ((C.isD_iff z.val).mp hd).1
    omega
  have hess : ∀ z, C.isDStar z.val = true → Essential R.eval z := by
    intro z hz
    obtain ⟨u,v,hu,hne⟩ := horig z hz
    exact ⟨u,v,hu,by simpa only [heval] using hne⟩
  have hs := forbid_a_of_distinct C.eval C hDistinct (fun _ => rfl) hE1 hused
  have hbound := C.psi2_free_restriction_le_of_distinct P c hDistinct hs C.eval (fun _ => rfl)
    hE1 W V (by intro z _; rfl) hw hv hess horig
  exact ⟨hbound,heval⟩

/-- A nonessential table is eliminated for every resolution of its inputs. -/
theorem step_isSome_of_not_essential (g : Table) (hg : g.essential = false)
    (r₁ r₂ : Res) : (Res.step g r₁ r₂).isSome = true := by
  have hdeg (t : Table) (ht : t.essential = false) :
      (t.ff = t.tf ∧ t.ft = t.tt) ∨ (t.ff = t.ft ∧ t.tf = t.tt) := by
    revert ht
    rcases t with ⟨a,b,c,d⟩
    cases a <;> cases b <;> cases c <;> cases d <;> decide
  cases r₁ with
  | const a => exact Res.step_const_left_isSome g a r₂
  | lit s na =>
    cases r₂ with
    | const b => exact Res.step_const_right_isSome g _ b
    | lit t nb =>
      have hd := hdeg (twist g na nb) (by rw [twist_essential]; exact hg)
      simp only [Res.step]
      split_ifs with _ h₂ h₃
      · rfl
      · rfl
      · rfl
      · exact (hd.elim h₂ h₃).elim

/-- Identity resolution strictly decreases the number of gates whenever an
original gate has a nonessential table. -/
theorem identity_resolution_size_lt_of_degenerate {n : Nat} (C : OpenCircuit n)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b))
    (hdeg : g.essential = false) :
    (C.restrict (fixSubst (fun _ => false) (fun _ => false))).size < C.size := by
  let P : Fin n → Bool := fun _ => false
  let c : Fin n → Bool := fun _ => false
  let ρ := fixRes P c
  have ha : C.isAliased ρ k = true := by
    simp only [isAliased,hk]
    exact step_isSome_of_not_essential g hdeg _ _
  have hsub : ({k} : Finset Nat) ⊆ Finset.range (n+C.size) := by
    intro v hv
    rw [Finset.mem_singleton.mp hv]
    exact Finset.mem_range.mpr (C.gateAt_bounds hk).2.1
  have hcount := C.aliasedCount_ge_card ρ {k} hsub (by
    intro v hv
    rw [Finset.mem_singleton.mp hv]
    exact ha)
  have ht := (C.fix_transfer P c).1
  have hsplit := C.size_split ρ
  change (C.restrict (fixSubst P c)).size = C.keptCount ρ at ht
  simp only [Finset.card_singleton] at hcount
  change (C.restrict (fixSubst P c)).size < C.size
  omega

/-- Resolve a degenerate gate and prune dead gates. This is the
size-decreasing branch of the two-level normalization argument. -/
theorem degenerate_resolution_reduced {n : Nat} (h2 : 2 ≤ n) (C : OpenCircuit n)
    (hDistinct : C.DistinctOperands) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b))
    (hdeg : g.essential = false) :
    ∃ D : OpenCircuit n, D.Reduced ∧ (∀ v, D.eval v = C.eval v) ∧
      D.psi2 ≤ C.psi2 ∧ D.size < C.size := by
  let P : Fin n → Bool := fun _ => false
  let c : Fin n → Bool := fun _ => false
  let R := C.restrict (fixSubst P c)
  have ⟨hpsi,heval⟩ := C.psi2_identity_resolution_le hDistinct hE1 hused
  change R.psi2 ≤ C.psi2 at hpsi
  change ∀ v, R.eval v = C.eval v at heval
  have hsize : R.size < C.size := C.identity_resolution_size_lt_of_degenerate k g a b hk hdeg
  have hp : R.GateProper := C.restrict_gateProper (fixSubst P c)
  have husedR : ∀ z : Fin n, 0 < R.usage (singleUse z) → Essential R.eval z := by
    intro z hz
    have hzC := C.usage_pos_of_fix_usage_pos P c z hz
    obtain ⟨u,v,hu,hne⟩ := hused z hzC
    exact ⟨u,v,hu,by simpa only [heval] using hne⟩
  obtain ⟨D,hD,hDe,hDp,hDs,_⟩ := R.exists_reduced_potential_le_size h2 hp husedR
  exact ⟨D,hD,fun v => (hDe v).trans (heval v),le_trans hDp hpsi,by omega⟩


/-- The degenerate normalization branch also preserves the used-input support. -/
theorem degenerate_resolution_reduced_support {n : Nat} (h2 : 2 ≤ n) (C : OpenCircuit n)
    (hDistinct : C.DistinctOperands) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b))
    (hdeg : g.essential = false) :
    ∃ D : OpenCircuit n, D.Reduced ∧ (∀ v, D.eval v = C.eval v) ∧
      D.psi2 ≤ C.psi2 ∧ D.size < C.size ∧
      (∀ z : Fin n, 0 < D.usage (singleUse z) → 0 < C.usage (singleUse z)) := by
  let P : Fin n → Bool := fun _ => false
  let c : Fin n → Bool := fun _ => false
  let R := C.restrict (fixSubst P c)
  have ⟨hpsi,heval⟩ := C.psi2_identity_resolution_le hDistinct hE1 hused
  change R.psi2 ≤ C.psi2 at hpsi
  change ∀ v, R.eval v = C.eval v at heval
  have hsize : R.size < C.size := C.identity_resolution_size_lt_of_degenerate k g a b hk hdeg
  have hp : R.GateProper := C.restrict_gateProper (fixSubst P c)
  have husedR : ∀ z : Fin n, 0 < R.usage (singleUse z) → Essential R.eval z := by
    intro z hz
    have hzC := C.usage_pos_of_fix_usage_pos P c z hz
    obtain ⟨u,v,hu,hne⟩ := hused z hzC
    exact ⟨u,v,hu,by simpa only [heval] using hne⟩
  obtain ⟨D,hD,hDe,hDp,hDs,_,hDused⟩ := R.exists_reduced_potential_le_size_support h2 hp husedR
  exact ⟨D,hD,fun v => (hDe v).trans (heval v),le_trans hDp hpsi,by omega,
    fun z hz => C.usage_pos_of_fix_usage_pos P c z (hDused z hz)⟩

end OpenCircuit
end SatLowerBound
