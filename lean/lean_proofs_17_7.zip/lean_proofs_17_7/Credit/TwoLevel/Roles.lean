import Credit.TwoLevel.Ledger

/-! Structural counting of the W and W² roles in the manuscript's charging lemma. -/
namespace SatLowerBound
namespace OpenCircuit

/-- Under the paper's D-gate safety condition, a gate is first reader for at
most one D-variable. -/
theorem first_reader_unique {n : Nat} (C : OpenCircuit n) (hsafe : C.DGateSafe) {k : Nat}
    {z₁ z₂ : Fin n} (h₁ : C.isD z₁.val = true) (h₂ : C.isD z₂.val = true)
    (hk₁ : k ∈ C.users z₁.val) (hk₂ : k ∈ C.users z₂.val) : z₁ = z₂ := by
  obtain ⟨g, a, b, hg, hab₁⟩ := C.mem_users.mp hk₁
  obtain ⟨g', a', b', hg', hab₂⟩ := C.mem_users.mp hk₂
  rw [hg] at hg'
  simp only [Option.some.injEq, Prod.mk.injEq] at hg'
  obtain ⟨-, ha, hb⟩ := hg'
  rw [← ha, ← hb] at hab₂
  apply Fin.ext
  have hz₁ := z₁.isLt
  have hz₂ := z₂.isLt
  rcases hab₁ with ha₁ | hb₁ <;> rcases hab₂ with ha₂ | hb₂
  · omega
  · have h := (hsafe k g a b hg (by omega) (by omega)).1
    rw [ha₁, h₁] at h
    exact Bool.noConfusion h
  · have h := (hsafe k g a b hg (by omega) (by omega)).1
    rw [ha₂, h₂] at h
    exact Bool.noConfusion h
  · omega

/-- At most one input can assign a first-gate role to a gate. -/
theorem first_role_card_le_one {n : Nat} (C : OpenCircuit n)
    (hsafe : C.DGateSafe) (W : Fin n → Nat)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val) (k : Nat) :
    ((Finset.univ : Finset (Fin n)).filter
      (fun z => C.isD z.val = true ∧ W z = k)).card ≤ 1 := by
  apply Finset.card_le_one.mpr
  intro x hx y hy
  have hx' := (Finset.mem_filter.mp hx).2
  have hy' := (Finset.mem_filter.mp hy).2
  apply C.first_reader_unique hsafe hx'.1 hy'.1
  · simpa [hx'.2] using hw x hx'.1
  · simpa [hy'.2] using hw y hy'.1

/-- The set of input credit chains for which `k` is the second gate has size
at most two: the first gates are distinct and must be operands of `k`. -/
theorem second_role_card_le_two {n : Nat} (C : OpenCircuit n)
    (hsafe : C.DGateSafe) (W V : Fin n → Nat)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b)) :
    ((Finset.univ : Finset (Fin n)).filter
      (fun z => C.isDStar z.val = true ∧ V z = k)).card ≤ 2 := by
  let S := (Finset.univ : Finset (Fin n)).filter
    (fun z => C.isDStar z.val = true ∧ V z = k)
  calc S.card ≤ ({a,b} : Finset Nat).card := by
        apply Finset.card_le_card_of_injOn W
        · intro z hz
          have h := (Finset.mem_filter.mp hz).2
          have hread : k ∈ C.users (W z) := by simpa [h.2] using hv z h.1
          obtain ⟨g',a',b',hg',hab⟩ := C.mem_users.mp hread
          rw [hk] at hg'
          simp only [Option.some.injEq, Prod.mk.injEq] at hg'
          obtain ⟨_,ha,hb⟩ := hg'
          rw [Finset.mem_coe, Finset.mem_insert, Finset.mem_singleton]
          rcases hab with ha' | hb'
          · exact Or.inl (by rw [ha, ha'])
          · exact Or.inr (by rw [hb, hb'])
        · intro z₁ hz₁ z₂ hz₂ he
          have h₁ := (Finset.mem_filter.mp hz₁).2.1
          have h₂ := (Finset.mem_filter.mp hz₂).2.1
          have hd₁ := C.isD_of_isDStar z₁.val h₁
          have hd₂ := C.isD_of_isDStar z₂.val h₂
          apply C.first_reader_unique hsafe hd₁ hd₂ (hw z₁ hd₁)
          rw [he]
          exact hw z₂ hd₂
    _ ≤ 2 := Finset.card_le_two

end OpenCircuit
end SatLowerBound

namespace SatLowerBound
namespace OpenCircuit

/-- Total first-role charge assigned to an original gate. -/
def gateFirstCharge {n : Nat} (C D : OpenCircuit n) (ρ : Fin n → Res)
    (W : Fin n → Nat) (k : Nat) : Nat :=
  ∑ z ∈ (Finset.univ : Finset (Fin n)).filter (fun z => W z = k),
    C.firstGateCharge D ρ W z

/-- Total second-role charge assigned to an original gate. -/
def gateSecondCharge {n : Nat} (C D : OpenCircuit n) (ρ : Fin n → Res)
    (W V : Fin n → Nat) (k : Nat) : Nat :=
  ∑ z ∈ (Finset.univ : Finset (Fin n)).filter (fun z => V z = k),
    C.secondGateCharge D ρ W z

theorem gateFirstCharge_le_one {n : Nat} (C D : OpenCircuit n) (ρ : Fin n → Res)
    (hsafe : C.DGateSafe) (W : Fin n → Nat)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val) (k : Nat) :
    C.gateFirstCharge D ρ W k ≤ 1 := by
  let S := (Finset.univ : Finset (Fin n)).filter (fun z => W z = k)
  let T := (Finset.univ : Finset (Fin n)).filter
    (fun z => C.isD z.val = true ∧ W z = k)
  have hsub : T ⊆ S := by
    intro z hz
    simp only [T, S, Finset.mem_filter, Finset.mem_univ, true_and] at hz ⊢
    exact hz.2
  have heq : (∑ z ∈ T, C.firstGateCharge D ρ W z) =
      ∑ z ∈ S, C.firstGateCharge D ρ W z := by
    apply Finset.sum_subset hsub
    intro z _ hzT
    have hd : C.isD z.val = false := by
      cases h : C.isD z.val with
      | false => rfl
      | true =>
        exfalso
        have hzS : z ∈ S := by assumption
        apply hzT
        simp only [T, S, Finset.mem_filter, Finset.mem_univ, true_and] at hzS ⊢
        exact ⟨h,hzS⟩
    have hb := C.first_charge_bound D ρ W z
    simp [indicator, hd] at hb
    omega
  have hsum : (∑ z ∈ T, C.firstGateCharge D ρ W z) ≤ T.card := by
    have h := Finset.sum_le_card_nsmul T (fun z => C.firstGateCharge D ρ W z) 1 (by
      intro z _
      have hb := (C.charge_allocation_exact D ρ W z).2
      cases h : C.isAliased ρ (W z) <;> simp [indicator, h] at hb <;> omega)
    simpa using h
  have hcard := C.first_role_card_le_one hsafe W hw k
  change S.sum (fun z => C.firstGateCharge D ρ W z) ≤ 1
  rw [← heq]
  exact le_trans hsum hcard

/-- At most two units of second-role charge can reach one gate. This is the
general structural bound; reducing it to one on eliminated gates requires the
paper's additional two-chain survival lemma. -/
theorem gateSecondCharge_le_two {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (hsafe : C.DGateSafe)
    (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b)) :
    C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V k ≤ 2 := by
  let D := C.restrict (fixSubst P c)
  let ρ := fixRes P c
  let S := (Finset.univ : Finset (Fin n)).filter (fun z => V z = k)
  let T := (Finset.univ : Finset (Fin n)).filter
    (fun z => C.isDStar z.val = true ∧ V z = k)
  have hsub : T ⊆ S := by
    intro z hz
    simp only [T, S, Finset.mem_filter, Finset.mem_univ, true_and] at hz ⊢
    exact hz.2
  have heq : (∑ z ∈ T, C.secondGateCharge D ρ W z) =
      ∑ z ∈ S, C.secondGateCharge D ρ W z := by
    apply Finset.sum_subset hsub
    intro z hzS hzT
    have hs : C.isDStar z.val = false := by
      cases h : C.isDStar z.val with
      | false => rfl
      | true =>
        exfalso
        apply hzT
        simp only [T, S, Finset.mem_filter, Finset.mem_univ, true_and] at hzS ⊢
        exact ⟨h,hzS⟩
    have hb := C.free_second_charge_bound P c hr W V hfree hw hv hess z
    simp [indicator, hs] at hb
    exact hb
  have hsum : (∑ z ∈ T, C.secondGateCharge D ρ W z) ≤ T.card := by
    have h := Finset.sum_le_card_nsmul T (fun z => C.secondGateCharge D ρ W z) 1 (by
      intro z _
      have hb := C.free_second_charge_bound P c hr W V hfree hw hv hess z
      change C.secondGateCharge (C.restrict (fixSubst P c)) (fixRes P c) W z ≤ 1
      have hprod : indicator (C.isDStar z.val) *
          indicator (C.isAliased (fixRes P c) (V z)) ≤ 1 := by
        cases C.isDStar z.val <;> cases C.isAliased (fixRes P c) (V z) <;> decide
      exact le_trans hb hprod)
    simpa using h
  have hcard := C.second_role_card_le_two hsafe W V hw hv k g a b hk
  change S.sum (fun z => C.secondGateCharge D ρ W z) ≤ 2
  rw [← heq]
  exact le_trans hsum hcard

end OpenCircuit
end SatLowerBound
