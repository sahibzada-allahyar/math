import Credit.Charging

/-! Generalization of the manuscript's passers lemma to a retained gate signal.
The earlier library lemma applies only when the source is a primary input; the
two-level charging proof must also track the first gate `W_z`. -/
namespace SatLowerBound
namespace OpenCircuit

/-- If the initial inputs do not resolve to a literal of `s`, and every gate
outside `A` (other than `s`) reading `s` or `A` fails to resolve to `s`, then
every gate that resolves to `s` is either `s` itself or belongs to `A`. -/
theorem gate_passers_subset {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res)
    (s : Nat) (hinit : ∀ w : Fin n, (ρ w).hits s = false)
    (A : Finset Nat) (K : Nat)
    (hA : ∀ k g a b, k < K → C.gateAt k = some (g, a, b) → k ≠ s → k ∉ A →
      (a = s ∨ a ∈ A ∨ b = s ∨ b ∈ A) → (C.resAt ρ k).hits s = false) :
    ∀ k, n ≤ k → k < K → (C.resAt ρ k).hits s = true → k = s ∨ k ∈ A := by
  intro k
  induction k using Nat.strong_induction_on with
  | h k ih =>
    intro hnk hkK hhit
    rcases FlatKeptAux.hits_cases C ρ hhit with ⟨hkn, hin⟩ | ⟨g, a, b, hk, hcase⟩
    · have hfalse := hinit ⟨k,hkn⟩
      rw [hfalse] at hin
      contradiction
    · rcases hcase with ⟨_, hsk⟩ | hab
      · exact Or.inl hsk.symm
      · have hbounds := C.gateAt_bounds hk
        have key : ∀ o, o < k → (C.resAt ρ o).hits s = true → o = s ∨ o ∈ A := by
          intro o hok ho
          by_cases hon : o < n
          · have hin : C.resAt ρ o = ρ ⟨o, hon⟩ := C.resAt_input ρ ⟨o, hon⟩
            rw [hin, hinit] at ho
            contradiction
          · exact ih o hok (Nat.le_of_not_lt hon) (by omega) ho
        by_cases hks : k = s
        · exact Or.inl hks
        by_cases hkA : k ∈ A
        · exact Or.inr hkA
        exfalso
        have hpre : a = s ∨ a ∈ A ∨ b = s ∨ b ∈ A := by
          rcases hab with ha | hb
          · rcases key a hbounds.2.2.1 ha with h | h
            · exact Or.inl h
            · exact Or.inr (Or.inl h)
          · rcases key b hbounds.2.2.2 hb with h | h
            · exact Or.inr (Or.inr (Or.inl h))
            · exact Or.inr (Or.inr (Or.inr h))
        have hfalse := hA k g a b hkK hk hks hkA hpre
        rw [hfalse] at hhit
        contradiction

/-- If all direct successors of an original gate survive a fixed-input
restriction, no *other* gate can resolve to that original gate's signal. -/
theorem gate_passers_of_kept_users {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (s : Nat) (hs : n ≤ s)
    (husers : ∀ k ∈ C.users s, C.isKept (fixRes P c) k = true) :
    ∀ k, n ≤ k → k < n + C.size →
      (C.resAt (fixRes P c) k).hits s = true → k = s := by
  have hinit : ∀ w : Fin n, (fixRes P c w).hits s = false := by
    intro w
    apply Bool.eq_false_iff.mpr
    intro h
    have he := fixRes_hits P c s w h
    have hw := w.isLt
    omega
  have hall := C.gate_passers_subset (fixRes P c) s hinit ∅ (n + C.size) (by
    intro k g a b _ hk hks _ hab
    have hkuser : k ∈ C.users s := by
      apply C.mem_users.mpr
      refine ⟨g, a, b, hk, ?_⟩
      rcases hab with ha | ha | hb | hb
      · exact Or.inl ha
      · simp at ha
      · exact Or.inr hb
      · simp at hb
    rw [C.resAt_kept _ (husers k hkuser), Bool.eq_false_iff]
    intro hhit
    exact hks ((Res.hits_lit _ _ _).mp hhit))
  intro k hn hk hh
  rcases hall k hn hk hh with he | he
  · exact he
  · simp at he

end OpenCircuit
end SatLowerBound
