import Credit.TwoLevel.SignedVandermondeDet
import Mathlib.Algebra.MvPolynomial.Coeff

/-! Multinomial expansion for the leading coefficient calculation. -/
namespace SatLowerBound
open MvPolynomial

/-- A monomial times a power of the sum of the variables has the expected
multinomial coefficient. -/
theorem coeff_monomial_mul_sum_pow {R : Type} [CommSemiring R]
    {d : Nat} (s t : Fin d →₀ Nat) (k : Nat) :
    ((monomial s (1 : R)) * (∑ i : Fin d, X i) ^ k).coeff t =
      if s ≤ t then
        (if (t - s).degree = k then ((t - s).multinomial : R) else 0)
      else 0 := by
  classical
  rw [MvPolynomial.coeff_monomial_mul', MvPolynomial.coeff_sum_X_pow_of_fintype]
  simp [Finsupp.degree_apply, Finsupp.sum]
  split_ifs <;> simp_all

/-- The variable exponents contributed by one determinant permutation. -/
noncomputable def permutationSquareExponent {d : Nat} (e : Equiv.Perm (Fin d)) :
    Fin d →₀ Nat :=
  Finsupp.indicator Finset.univ (fun i _ => 2 * (e.symm i).val)

/-- Each unsigned term in the Vandermonde expansion is one monomial. -/
theorem permutation_square_product_eq_monomial {R : Type} [CommSemiring R]
    {d : Nat} (e : Equiv.Perm (Fin d)) :
    (∏ i : Fin d, (X (e i) : MvPolynomial (Fin d) R) ^ (2 * i.val)) =
      monomial (permutationSquareExponent e) 1 := by
  classical
  calc
    _ = ∏ j : Fin d, (X j : MvPolynomial (Fin d) R) ^ (2 * (e.symm j).val) := by
      simpa using (Equiv.prod_comp e (fun j =>
        (X j : MvPolynomial (Fin d) R) ^ (2 * (e.symm j).val)))
    _ = _ := by
      simpa [permutationSquareExponent] using
        (MvPolynomial.prod_X_pow (R := R) (fun j : Fin d => 2 * (e.symm j).val) Finset.univ)

/-- The signed Vandermonde term consists of a fixed sign and a monomial. -/
theorem signed_permutation_product_eq_monomial {R : Type} [CommRing R]
    {d : Nat} (e : Equiv.Perm (Fin d)) :
    (∏ i : Fin d, (-(X (e i) : MvPolynomial (Fin d) R) ^ 2) ^ i.val) =
      ((-1 : MvPolynomial (Fin d) R) ^ (∑ i : Fin d, i.val)) *
        monomial (permutationSquareExponent e) 1 := by
  classical
  calc
    _ = (∏ i : Fin d, ((-1 : MvPolynomial (Fin d) R) ^ i.val) *
        ((X (e i) : MvPolynomial (Fin d) R) ^ (2 * i.val))) := by
      apply Finset.prod_congr rfl
      intro i _
      rw [pow_mul]
      rw [← mul_pow]
      simp
    _ = _ := by
      rw [Finset.prod_mul_distrib, Finset.prod_pow_eq_pow_sum, permutation_square_product_eq_monomial]

/-- The leading coefficient is the explicit alternating multinomial sum. -/
theorem signedLeadingPolynomial_coeff_multinomial_sum {R : Type} [CommRing R]
    (d k : Nat) (t : Fin d →₀ Nat) :
    (signedLeadingPolynomial R d k).coeff t =
      ∑ e : Equiv.Perm (Fin d), e.sign •
        ((-1 : R) ^ (∑ i : Fin d, i.val) *
          (if permutationSquareExponent e ≤ t then
            (if (t - permutationSquareExponent e).degree = k then
              ((t - permutationSquareExponent e).multinomial : R) else 0)
           else 0)) := by
  classical
  rw [signedLeadingPolynomial_coeff_permutation_sum]
  apply Finset.sum_congr rfl
  intro e _
  rw [smul_mul_assoc, MvPolynomial.coeff_smul, signed_permutation_product_eq_monomial]
  rw [mul_assoc]
  have hC : ((-1 : MvPolynomial (Fin d) R) ^ (∑ i : Fin d, i.val)) =
      MvPolynomial.C ((-1 : R) ^ (∑ i : Fin d, i.val)) := by simp
  rw [hC, MvPolynomial.coeff_C_mul, coeff_monomial_mul_sum_pow]

/-- The multinomial term times its factorial denominator is the factorial
of its total degree, without division or characteristic assumptions. -/
theorem multinomial_mul_factorials {R : Type} [CommSemiring R]
    {d : Nat} (f : Fin d →₀ Nat) :
    (f.multinomial : R) * (∏ i : Fin d, (Nat.factorial (f i) : R)) =
      (Nat.factorial f.degree : R) := by
  classical
  have h := Nat.multinomial_spec Finset.univ (fun i : Fin d => f i)
  rw [← Finsupp.multinomial_eq_of_support_subset (Finset.subset_univ f.support),
    ← Finsupp.degree_eq_sum] at h
  have h' : f.multinomial * (∏ i : Fin d, Nat.factorial (f i)) =
      Nat.factorial f.degree := by simpa [Nat.mul_comm] using h
  simpa only [Nat.cast_mul, Nat.cast_prod] using congrArg (fun n : Nat => (n : R)) h'

/-- When the factorial denominators are nonzero, a multinomial coefficient
is the degree factorial times the product of inverse factorials. -/
theorem multinomial_eq_factorial_mul_inv {R : Type} [Field R]
    {d : Nat} (f : Fin d →₀ Nat)
    (hne : ∀ i, (Nat.factorial (f i) : R) ≠ 0) :
    (f.multinomial : R) = (Nat.factorial f.degree : R) *
      ∏ i : Fin d, (Nat.factorial (f i) : R)⁻¹ := by
  classical
  have hp : (∏ i : Fin d, (Nat.factorial (f i) : R)) ≠ 0 :=
    Finset.prod_ne_zero_iff.mpr (by simpa using hne)
  calc
    (f.multinomial : R) =
        ((f.multinomial : R) * ∏ i : Fin d, (Nat.factorial (f i) : R)) /
          (∏ i : Fin d, (Nat.factorial (f i) : R)) := by
      symm
      exact mul_div_cancel_right₀ _ hp
    _ = _ := by
      rw [multinomial_mul_factorials, div_eq_mul_inv, Finset.prod_inv_distrib]

/-- Every determinant permutation contributes the same total exponent. -/
theorem permutationSquareExponent_degree {d : Nat} (e : Equiv.Perm (Fin d)) :
    (permutationSquareExponent e).degree = 2 * Nat.choose d 2 := by
  classical
  rw [Finsupp.degree_eq_sum]
  simp only [permutationSquareExponent, Finsupp.indicator_apply, Finset.mem_univ,
    dite_true]
  rw [← Finset.mul_sum]
  rw [Equiv.sum_comp e.symm (fun i : Fin d => i.val)]
  have hsum : (∑ i : Fin d, i.val) = ∑ i ∈ Finset.range d, i :=
    Fin.sum_univ_eq_sum_range id d
  rw [hsum, Finset.sum_range_id, Nat.choose_two_right]

/-- Subtracting a permitted exponent leaves exactly the power of the
linear form in a top-degree coefficient. -/
theorem permutationSquareExponent_sub_degree {d k : Nat} (t : Fin d →₀ Nat)
    (e : Equiv.Perm (Fin d)) (ht : t.degree = 2 * Nat.choose d 2 + k)
    (hle : permutationSquareExponent e ≤ t) :
    (t - permutationSquareExponent e).degree = k := by
  have hs : t - permutationSquareExponent e + permutationSquareExponent e = t := by
    ext i
    simp only [Finsupp.add_apply]
    exact Nat.sub_add_cancel (hle i)
  have hd := congrArg Finsupp.degree hs
  simp only [map_add] at hd
  rw [permutationSquareExponent_degree, ht] at hd
  omega

/-- At top degree, the alternating coefficient sum has the inverse-factorial
form used to construct the binomial determinant. -/
theorem signedLeadingPolynomial_coeff_inverse_factorial_sum {R : Type} [Field R]
    (d k : Nat) (t : Fin d →₀ Nat)
    (ht : t.degree = 2 * Nat.choose d 2 + k)
    (hfac : ∀ i m, m ≤ t i → (Nat.factorial m : R) ≠ 0) :
    (signedLeadingPolynomial R d k).coeff t =
      ∑ e : Equiv.Perm (Fin d), e.sign •
        ((-1 : R) ^ (∑ i : Fin d, i.val) *
          (if permutationSquareExponent e ≤ t then
            (Nat.factorial k : R) *
              ∏ i : Fin d, (Nat.factorial ((t - permutationSquareExponent e) i) : R)⁻¹
           else 0)) := by
  classical
  rw [signedLeadingPolynomial_coeff_multinomial_sum]
  apply Finset.sum_congr rfl
  intro e _
  by_cases hle : permutationSquareExponent e ≤ t
  · have hd := permutationSquareExponent_sub_degree t e ht hle
    have hn : ∀ i, (Nat.factorial ((t - permutationSquareExponent e) i) : R) ≠ 0 := by
      intro i
      apply hfac
      exact Nat.sub_le _ _
    simp only [hle, hd, ↓reduceIte]
    rw [multinomial_eq_factorial_mul_inv (t - permutationSquareExponent e) hn, hd]
  · simp [hle]

/-- Reciprocal factorial entries, with zero for an out-of-range exponent. -/
noncomputable def inverseFactorialMatrix {R : Type} [Field R] {d : Nat}
    (t : Fin d →₀ Nat) : Matrix (Fin d) (Fin d) R :=
  fun i j => if 2 * j.val ≤ t i then (Nat.factorial (t i - 2 * j.val) : R)⁻¹ else 0

/-- A permutation's inverse-factorial product is exactly the corresponding
product of entries in the reciprocal-factorial matrix. -/
theorem inverseFactorialMatrix_perm_product {R : Type} [Field R]
    {d : Nat} (t : Fin d →₀ Nat) (e : Equiv.Perm (Fin d)) :
    (if permutationSquareExponent e ≤ t then
      ∏ i : Fin d, (Nat.factorial ((t - permutationSquareExponent e) i) : R)⁻¹
     else 0) = ∏ j : Fin d, inverseFactorialMatrix (R := R) t (e j) j := by
  classical
  have heval (i : Fin d) : permutationSquareExponent e i = 2 * (e.symm i).val := by
    simp [permutationSquareExponent, Finsupp.indicator_apply]
  by_cases hle : permutationSquareExponent e ≤ t
  · simp only [hle, ↓reduceIte]
    calc
      _ = ∏ j : Fin d, (Nat.factorial ((t - permutationSquareExponent e) (e j)) : R)⁻¹ := by
        symm
        exact Equiv.prod_comp e (fun i => (Nat.factorial ((t - permutationSquareExponent e) i) : R)⁻¹)
      _ = _ := by
        apply Finset.prod_congr rfl
        intro j _
        have hj : 2 * j.val ≤ t (e j) := by
          simpa [heval] using (Finsupp.le_def.mp hle (e j))
        simp [inverseFactorialMatrix, hj, heval]
  · have hx : ∃ i, t i < permutationSquareExponent e i := by
      simp only [Finsupp.le_def, not_forall, not_le] at hle
      exact hle
    obtain ⟨i, hi⟩ := hx
    have hz : inverseFactorialMatrix t i (e.symm i) = (0 : R) := by
      simp [inverseFactorialMatrix, not_le.mpr (by simpa [heval] using hi)]
    have hp : (∏ j : Fin d, inverseFactorialMatrix (R := R) t (e j) j) = 0 := by
      apply Finset.prod_eq_zero (Finset.mem_univ (e.symm i))
      simpa using hz
    simp [hle, hp]

/-- The leading coefficient is a factorial times a reciprocal-factorial
determinant. This is the bridge from the polynomial method to a determinant
evaluation. -/
theorem signedLeadingPolynomial_coeff_inverse_factorial_det {R : Type} [Field R]
    (d k : Nat) (t : Fin d →₀ Nat)
    (ht : t.degree = 2 * Nat.choose d 2 + k)
    (hfac : ∀ i m, m ≤ t i → (Nat.factorial m : R) ≠ 0) :
    (signedLeadingPolynomial R d k).coeff t =
      ((-1 : R) ^ (∑ i : Fin d, i.val) * (Nat.factorial k : R)) *
        (inverseFactorialMatrix (R := R) t).det := by
  classical
  rw [signedLeadingPolynomial_coeff_inverse_factorial_sum d k t ht hfac,
    Matrix.det_apply, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro e _
  rw [← inverseFactorialMatrix_perm_product t e, mul_smul_comm]
  by_cases hle : permutationSquareExponent e ≤ t
  · simp [hle, mul_assoc]
  · simp [hle]

/-- The binomial matrix appearing in the coefficient determinant. -/
def binomialCoefficientMatrix {R : Type} [CommRing R] {d : Nat}
    (t : Fin d →₀ Nat) : Matrix (Fin d) (Fin d) R :=
  fun i j => (Nat.choose (t i) (2 * j.val) : R)

/-- Clearing row denominators turns reciprocal factorials into binomial
coefficients with the corresponding column factorials. -/
theorem factorial_mul_inverseFactorialMatrix {R : Type} [Field R]
    {d : Nat} (t : Fin d →₀ Nat) (i j : Fin d)
    (hfac : ∀ m, m ≤ t i → (Nat.factorial m : R) ≠ 0) :
    (Nat.factorial (t i) : R) * inverseFactorialMatrix t i j =
      (Nat.factorial (2 * j.val) : R) * binomialCoefficientMatrix t i j := by
  classical
  by_cases h : 2 * j.val ≤ t i
  · have hn : (Nat.factorial (t i - 2 * j.val) : R) ≠ 0 := hfac _ (Nat.sub_le _ _)
    have hc : ((Nat.choose (t i) (2 * j.val) : R) *
        (Nat.factorial (2 * j.val) : R) *
        (Nat.factorial (t i - 2 * j.val) : R)) = (Nat.factorial (t i) : R) := by
      simpa only [Nat.cast_mul] using congrArg (fun n : Nat => (n : R))
        (Nat.choose_mul_factorial_mul_factorial h)
    simp only [inverseFactorialMatrix, h, ↓reduceIte, binomialCoefficientMatrix]
    rw [← hc]
    field_simp
  · have hz : Nat.choose (t i) (2 * j.val) = 0 := Nat.choose_eq_zero_of_lt (Nat.lt_of_not_ge h)
    simp [inverseFactorialMatrix, binomialCoefficientMatrix, h, hz]

/-- Clearing denominators in the determinant gives precisely the binomial
determinant used in the cited subset-sum proof. -/
theorem inverseFactorialMatrix_det_mul_factorials {R : Type} [Field R]
    {d : Nat} (t : Fin d →₀ Nat)
    (hfac : ∀ i m, m ≤ t i → (Nat.factorial m : R) ≠ 0) :
    (∏ i : Fin d, (Nat.factorial (t i) : R)) *
      (inverseFactorialMatrix (R := R) t).det =
    (∏ j : Fin d, (Nat.factorial (2 * j.val) : R)) *
      (binomialCoefficientMatrix (R := R) t).det := by
  classical
  rw [← Matrix.det_mul_column, ← Matrix.det_mul_row]
  congr 1
  ext i j
  exact factorial_mul_inverseFactorialMatrix t i j (hfac i)

/-- A nonzero binomial determinant and nonzero factorials certify the
coefficient needed by the combinatorial Nullstellensatz. -/
theorem signedLeadingPolynomial_coeff_ne_zero_of_binomial_det {R : Type} [Field R]
    (d k : Nat) (t : Fin d →₀ Nat)
    (ht : t.degree = 2 * Nat.choose d 2 + k)
    (hfac : ∀ i m, m ≤ t i → (Nat.factorial m : R) ≠ 0)
    (hcol : ∀ j : Fin d, (Nat.factorial (2 * j.val) : R) ≠ 0)
    (hk : (Nat.factorial k : R) ≠ 0)
    (hdet : (binomialCoefficientMatrix (R := R) t).det ≠ 0) :
    (signedLeadingPolynomial R d k).coeff t ≠ 0 := by
  classical
  have hp : (∏ j : Fin d, (Nat.factorial (2 * j.val) : R)) ≠ 0 :=
    Finset.prod_ne_zero_iff.mpr (by simpa using hcol)
  have hn := mul_ne_zero hp hdet
  rw [← inverseFactorialMatrix_det_mul_factorials t hfac] at hn
  have hi : (inverseFactorialMatrix (R := R) t).det ≠ 0 := (mul_ne_zero_iff.mp hn).2
  rw [signedLeadingPolynomial_coeff_inverse_factorial_det d k t ht hfac]
  exact mul_ne_zero (mul_ne_zero (pow_ne_zero _ (neg_ne_zero.mpr one_ne_zero)) hk) hi

/-- The binomial determinant criterion yields the restricted-sum bound. -/
theorem restrictedSums_gt_of_binomial_det
    {R : Type} [Field R] [DecidableEq R] [Fintype R]
    {d k : Nat} (a : Fin d → R) (domains : Fin d → Finset R)
    (hdom : ∀ i x, x ∈ domains i → ∃ j, x = a j ∨ x = -a j)
    (t : Fin d →₀ Nat) (hsize : ∀ i, t i < (domains i).card)
    (ht : t.degree = 2 * Nat.choose d 2 + k)
    (hcard : k ≤ Fintype.card R)
    (hfac : ∀ i m, m ≤ t i → (Nat.factorial m : R) ≠ 0)
    (hcol : ∀ j : Fin d, (Nat.factorial (2 * j.val) : R) ≠ 0)
    (hk : (Nat.factorial k : R) ≠ 0)
    (hdet : (binomialCoefficientMatrix (R := R) t).det ≠ 0) :
    k < (signedRestrictedSums a domains).card := by
  apply restrictedSums_gt_of_leading_coefficient a domains hdom t hsize ht hcard
  exact signedLeadingPolynomial_coeff_ne_zero_of_binomial_det d k t ht hfac hcol hk hdet

end SatLowerBound
