import Credit.TwoLevel.PruningRoles

/-! E2 supplies E1 for the one-input cofactors used in normalization. -/
namespace SatLowerBound

/-- An essential coordinate of a one-input cofactor differs from the fixed
coordinate and was already essential before the restriction. -/
theorem essential_of_single_cofactor {n : Nat} {f : (Fin n → Bool) → Bool}
    (x z : Fin n) (b : Bool) (h : Essential (fun v => f (fixBit x b v)) z) :
    z ≠ x ∧ Essential f z := by
  obtain ⟨u,v,huv,hne⟩ := h
  have hzx : z ≠ x := by
    intro he
    subst z
    apply hne
    change f (fixBit x b u) = f (fixBit x b v)
    apply congrArg f
    funext q
    by_cases hq : q = x
    · simp [fixBit,hq]
    · simp [fixBit,hq,huv q hq]
  refine ⟨hzx,fixBit x b u,fixBit x b v,?_,hne⟩
  intro q hq
  by_cases hx : q = x
  · simp [fixBit,hx]
  · simp [fixBit,hx,huv q hq]

/-- The manuscript's implication: if `f` satisfies E2, then each one-input
cofactor satisfies E1, including when the second fixed coordinate is the
same one already fixed. -/
theorem E2.single_cofactor_e1 {n : Nat} {f : (Fin n → Bool) → Bool}
    (hE2 : E2 f) (x : Fin n) (b : Bool) : E1 (fun v => f (fixBit x b v)) := by
  intro y c z hzy hz
  obtain ⟨hzx,hzorig⟩ := essential_of_single_cofactor x z b hz
  by_cases hyx : y = x
  · subst y
    have hfun : (fun v => f (fixBit x b (fixBit x c v))) = fun v => f (fixBit x b v) := by
      funext v
      congr 1
      funext q
      by_cases hq : q = x <;> simp [fixBit,hq]
    rwa [hfun]
  · have he := hE2 x y b c z (Ne.symm hyx) hzx hzy hzorig
    have hfun : (fun v => f (setPair v x y b c)) =
        fun v => f (fixBit x b (fixBit y c v)) := by
      funext v
      congr 1
    rwa [hfun] at he

end SatLowerBound
