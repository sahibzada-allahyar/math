import Credit.TwoLevel.WeightedResidueAlgorithm
import Mathlib.NumberTheory.Bertrand
import Mathlib.Analysis.SpecialFunctions.Sqrt

/-! The prime and square-root parameters of Proposition 5.10. -/
namespace SatLowerBound

private theorem exists_prime_above_twice (r : Nat) : ∃ p, p.Prime ∧ 2 * r < p := by
  obtain ⟨p,hp,hprime⟩ := Nat.exists_infinite_primes (2 * r + 1)
  exact ⟨p,hprime,by omega⟩

/-- The least prime strictly larger than twice the block length. -/
noncomputable def weightedPrime (r : Nat) : Nat := Nat.find (exists_prime_above_twice r)

theorem weightedPrime_spec (r : Nat) : (weightedPrime r).Prime ∧ 2 * r < weightedPrime r :=
  Nat.find_spec (exists_prime_above_twice r)

theorem weightedPrime_minimal (r q : Nat) (hq : q.Prime) (h : 2 * r < q) :
    weightedPrime r ≤ q := Nat.find_min' (exists_prime_above_twice r) ⟨hq,h⟩

/-- Bertrand's postulate bounds the chosen prime by `4r`. -/
theorem weightedPrime_le_four (r : Nat) (hr : 1 ≤ r) : weightedPrime r ≤ 4 * r := by
  obtain ⟨q,hq,hlo,hhi⟩ := Nat.exists_prime_lt_and_le_two_mul (2*r) (by omega)
  have h := weightedPrime_minimal r q hq hlo
  omega

private theorem exists_triangular_threshold (p : Nat) : ∃ m, p ≤ 1 + m * (m + 1) / 2 := by
  refine ⟨2 * p, ?_⟩
  have hmul : p * 2 ≤ (2 * p) * (2 * p + 1) := by nlinarith
  have hdiv := (Nat.le_div_iff_mul_le (by decide : 0 < 2)).mpr hmul
  omega

/-- The smallest `m` whose triangular subset-sum lower bound reaches `p`. -/
noncomputable def weightedTriangleThreshold (p : Nat) : Nat :=
  Nat.find (exists_triangular_threshold p)

theorem weightedTriangleThreshold_spec (p : Nat) :
    p ≤ 1 + weightedTriangleThreshold p * (weightedTriangleThreshold p + 1) / 2 :=
  Nat.find_spec (exists_triangular_threshold p)

theorem weightedTriangleThreshold_minimal (p m : Nat)
    (hm : p ≤ 1 + m * (m + 1) / 2) : weightedTriangleThreshold p ≤ m :=
  Nat.find_min' (exists_triangular_threshold p) hm

/-- The paper's `ceil(sqrt(8r))` upper bound for the least threshold. -/
theorem weightedTriangleThreshold_sqrt_bound (r : Nat) (hr : 1 ≤ r) :
    weightedTriangleThreshold (weightedPrime r) ≤ ⌈Real.sqrt (8 * (r : ℝ))⌉₊ := by
  let q := ⌈Real.sqrt (8 * (r : ℝ))⌉₊
  have hq : Real.sqrt (8 * (r : ℝ)) ≤ (q : ℝ) := Nat.le_ceil _
  have hs : (Real.sqrt (8 * (r : ℝ))) ^ 2 = 8 * (r : ℝ) := Real.sq_sqrt (by positivity)
  have hq0 : (0 : ℝ) ≤ q := Nat.cast_nonneg _
  have hs0 : 0 ≤ Real.sqrt (8 * (r : ℝ)) := Real.sqrt_nonneg _
  have hq2 : 8 * r ≤ q * q := by
    have hrq : (8 : ℝ) * r ≤ (q : ℝ) * q := by nlinarith
    exact_mod_cast hrq
  have hmul : 2 * (4 * r) ≤ q * (q + 1) := by nlinarith
  have hdiv : 4 * r ≤ q * (q + 1) / 2 :=
    (Nat.le_div_iff_mul_le (by decide : 0 < 2)).mpr (by nlinarith)
  change weightedTriangleThreshold (weightedPrime r) ≤ q
  apply weightedTriangleThreshold_minimal
  have hp := weightedPrime_le_four r hr
  omega

/-- The full-degree weighted block with the manuscript's least-prime and
least-threshold parameters. The cited subset-sum theorem remains explicit. -/
theorem exists_paper_weighted_block_of_subsetSumBound (r : Nat) (hr : 4 ≤ r)
    (hbound : ∀ A : Finset (ZMod (weightedPrime r)), (∀ x ∈ A, -x ∉ A) →
      min (weightedPrime r) (1 + A.card * (A.card + 1) / 2) ≤ A.subsetSum.card) :
    ∃ t : ZMod (weightedPrime r),
      Robust (weightedTriangleThreshold (weightedPrime r) + 2)
        (weightedModularBlock r (weightedPrime r) t) ∧
      (BPoly.ofFunction r (weightedModularBlock r (weightedPrime r) t)).topCoefficient = true := by
  obtain ⟨hp,hlarge⟩ := weightedPrime_spec r
  have hpodd : weightedPrime r ≠ 2 := by omega
  exact exists_weighted_robust_full_degree_of_subsetSumBound r (weightedPrime r)
    (weightedTriangleThreshold (weightedPrime r)) (weightedTriangleThreshold (weightedPrime r) + 2)
    hp hpodd hlarge (by omega) (weightedTriangleThreshold_spec _) hbound

end SatLowerBound
