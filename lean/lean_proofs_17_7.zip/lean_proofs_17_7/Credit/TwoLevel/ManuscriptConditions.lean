import Credit.TwoLevel.ManuscriptElimination

/-! Literal interfaces for Definition 5.6. Internal E1/E2 preserve previously
essential coordinates and permit unused ambient coordinates. The paper's
conditions require every remaining coordinate to be essential. This file
states that distinction explicitly and proves the boundary conversion. -/
namespace SatLowerBound

/-- Definition 5.6: every one-bit restriction depends on every remaining bit. -/
def PaperE1 {n : Nat} (f : (Fin n → Bool) → Bool) : Prop :=
  ∀ x b z, z ≠ x → Essential (fun v => f (fixBit x b v)) z

/-- Definition 5.6: every restriction fixing at most two bits depends on
every remaining bit, including the empty and one-bit restrictions. -/
def PaperE2 {n : Nat} (f : (Fin n → Bool) → Bool) : Prop :=
  (∀ z, Essential f z) ∧ PaperE1 f ∧
    ∀ x y a b z, x ≠ y → z ≠ x → z ≠ y →
      Essential (fun v => f (setPair v x y a b)) z

theorem PaperE1.toE1 {n : Nat} {f : (Fin n → Bool) → Bool} (h : PaperE1 f) : E1 f :=
  fun x b z hzx _ => h x b z hzx

theorem PaperE2.toE2 {n : Nat} {f : (Fin n → Bool) → Bool} (h : PaperE2 f) : E2 f :=
  fun x y a b z hxy hzx hzy _ => h.2.2 x y a b z hxy hzx hzy

/-- No weakening of E1 occurs when every original coordinate is essential. -/
theorem paperE1_iff_E1_of_full_support {n : Nat} (f : (Fin n → Bool) → Bool)
    (hall : ∀ z, Essential f z) : PaperE1 f ↔ E1 f := by
  constructor
  · exact PaperE1.toE1
  · intro h x b z hzx
    exact h x b z hzx (hall z)

/-- Under Lemma 7.1's S4 premise, internal E2 is equivalent to the paper's
at-most-two-bit condition, including full original support and E1. -/
theorem paperE2_iff_E2_of_S4 {n : Nat} (hn : 2 ≤ n)
    (f : (Fin n → Bool) → Bool) (hS4 : S4 f) : PaperE2 f ↔ E2 f := by
  constructor
  · exact PaperE2.toE2
  · intro h
    have hall := hS4.all_essential hn
    have he1 := h.e1_of_three (hS4.at_least_three hn)
    refine ⟨hall,?_,?_⟩
    · exact (paperE1_iff_E1_of_full_support f hall).mpr he1
    · intro x y a b z hxy hzx hzy
      exact h x y a b z hxy hzx hzy (hall z)

/-- Lemma 7.1 with Definition 5.6's literal E2, distinct-successor fan-out,
and Definition 6.9's potential on both circuits. -/
theorem paper_elimination_E2 {n : Nat} (hn : 2 ≤ n)
    (f : (Fin n → Bool) → Bool) (hE2 : PaperE2 f) (hS4 : S4 f)
    (C : OpenCircuit n) (hr : C.Reduced)
    (ht : C.NoInputTriangles (fun _ => none)) (hc : ∀ v, C.eval v = f v) :
    ∃ (x : Fin n) (b : Bool) (D : OpenCircuit n),
      2 ≤ (C.users x.val).card ∧ D.Reduced ∧ D.NoInputTriangles (fun _ => none) ∧
      (∀ v, D.eval v = f (fixBit x b v)) ∧ D.paperPsi2 + 14 ≤ C.paperPsi2 :=
  paper_one_step_elimination_successor_potential hn f hE2.toE2 hS4 C hr ht hc

end SatLowerBound
