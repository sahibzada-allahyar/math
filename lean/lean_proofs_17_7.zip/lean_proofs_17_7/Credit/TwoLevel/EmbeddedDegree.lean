import Credit.TwoLevel.CoordinateDegree
import Credit.TwoLevel.RobustDegree
import SatLowerBound.GroupedDegree

/-! Full degree is preserved when a localBlock block is embedded on a finite support. -/
namespace SatLowerBound

/-- An injective placement of a full-degree block remains full-degree after
its ambient support is packed into consecutive coordinates. -/
theorem embedded_leaf_full_degree {n r : Nat} (e : Fin r → Fin n) (he : Function.Injective e)
    (g : (Fin r → Bool) → Bool) (hfull : (BPoly.ofFunction r g).topCoefficient = true) :
    (BPoly.ofFunction (Finset.univ.image e).card
      (RobustTree.leafLocal (fun v => g (fun i => v (e i))) (Finset.univ.image e))).topCoefficient = true := by
  classical
  let S : Finset (Fin n) := Finset.univ.image e
  have hcard : S.card = r := by simp [S,Finset.card_image_of_injective _ he]
  let E : Fin r ≃ Fin S.card := (embeddingImageEquiv e he).trans S.equivFin
  let p : Fin r ≃ Fin r := E.trans (finCongr hcard)
  let localBlock : (Fin S.card → Bool) → Bool := RobustTree.leafLocal (fun v => g (fun i => v (e i))) S
  let reindexed : (Fin r → Bool) → Bool := fun v => localBlock (fun j => v (Fin.cast hcard j))
  have hre : reindexed = fun v => g (fun i => v (p i)) := by
    funext v
    dsimp [reindexed,localBlock,RobustTree.leafLocal]
    congr 1
    funext i
    have hi : e i ∈ S := Finset.mem_image.mpr ⟨i,Finset.mem_univ i,rfl⟩
    simp only [hi,↓reduceDIte]
    rfl
  have hcast := top_function_cast hcard reindexed
  have hback : (fun v : Fin S.card → Bool => reindexed (fun i => v (Fin.cast hcard.symm i))) = localBlock := by
    funext v
    dsimp [reindexed]
  rw [hback,hre,topCoefficient_perm] at hcast
  exact hcast.trans hfull

end SatLowerBound
