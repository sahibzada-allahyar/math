import Credit.TwoLevel.DeadGate

/-! Credit roles in circuits before dead-gate pruning. -/
namespace SatLowerBound
namespace OpenCircuit

theorem forbid_a_of_distinct {n : Nat} (f : (Fin n → Bool) → Bool) (C : OpenCircuit n) (hdis : C.DistinctOperands)
    (hc : ∀ v, C.eval v = f v) (hE1 : E1 f)
    (hess : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential f z) : C.DGateSafe := by
  intro k g a b hk ha hb
  have hab : a ≠ b := hdis k g a b hk
  -- the table of a D-gate is nonlinear
  have hnl : ∀ z : Nat, C.isD z = true → (a = z ∨ b = z) → g.nonlinear = true := by
    intro z hDz hzk
    obtain ⟨h1, k', g', a', b', hk', hzk', hnl'⟩ := (C.isD_iff z).mp hDz
    have hkz : k ∈ C.users z := C.mem_users.mpr ⟨g, a, b, hk, hzk⟩
    have hk'z : k' ∈ C.users z := C.mem_users.mpr ⟨g', a', b', hk', hzk'⟩
    have hge := C.refCount_ge z
    have hcard : (C.users z).card = 1 := by
      have := Finset.card_pos.mpr ⟨k, hkz⟩
      omega
    obtain ⟨u, hu⟩ := Finset.card_eq_one.mp hcard
    rw [hu, Finset.mem_singleton] at hkz hk'z
    rw [hk'z, ← hkz, hk] at hk'
    cases hk'
    exact hnl'
  constructor
  · cases hDa : C.isD a with
    | false => rfl
    | true =>
      exfalso
      have hg := hnl a hDa (Or.inl rfl)
      obtain ⟨β, hβ, -⟩ := g.nonlinear_exists_blocksRight hg
      have hconst : (C.resAt (singleRes ⟨b, hb⟩ β) k).isConst = true := by
        have hne : (⟨a, ha⟩ : Fin n) ≠ ⟨b, hb⟩ := fun he => hab (congrArg Fin.val he)
        have hra : C.resAt (singleRes ⟨b, hb⟩ β) a = .lit a false := by
          have h0 := C.resAt_single_input ⟨b, hb⟩ β ⟨a, ha⟩
          simpa [hne] using h0
        have hrb : C.resAt (singleRes ⟨b, hb⟩ β) b = .const β := by
          have h0 := C.resAt_single_input ⟨b, hb⟩ β ⟨b, hb⟩
          simpa using h0
        rw [C.resAt_gate _ hk, hra, hrb, Res.step_blocked_right g _ β hβ]
        rfl
      exact dvar_reader_not_const f C hc hE1 hess ⟨b, hb⟩ β ⟨a, ha⟩
        (fun he => hab (congrArg Fin.val he)) hDa (C.mem_users.mpr ⟨g, a, b, hk, Or.inl rfl⟩)
        hconst
  · cases hDb : C.isD b with
    | false => rfl
    | true =>
      exfalso
      have hg := hnl b hDb (Or.inr rfl)
      obtain ⟨α, hα, -⟩ := g.nonlinear_exists_blocksLeft hg
      have hconst : (C.resAt (singleRes ⟨a, ha⟩ α) k).isConst = true := by
        have hne : (⟨b, hb⟩ : Fin n) ≠ ⟨a, ha⟩ := fun he => hab (congrArg Fin.val he).symm
        have hra : C.resAt (singleRes ⟨a, ha⟩ α) a = .const α := by
          have h0 := C.resAt_single_input ⟨a, ha⟩ α ⟨a, ha⟩
          simpa using h0
        have hrb : C.resAt (singleRes ⟨a, ha⟩ α) b = .lit b false := by
          have h0 := C.resAt_single_input ⟨a, ha⟩ α ⟨b, hb⟩
          simpa [hne] using h0
        rw [C.resAt_gate _ hk, hra, hrb, Res.step_blocked_left g α _ hα]
        rfl
      exact dvar_reader_not_const f C hc hE1 hess ⟨a, ha⟩ α ⟨b, hb⟩
        (fun he => hab (congrArg Fin.val he).symm) hDb
        (C.mem_users.mpr ⟨g, a, b, hk, Or.inr rfl⟩) hconst

theorem second_role_has_no_primary_unreduced {n : Nat} (C : OpenCircuit n) 
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (z : Fin n) (hzEss : Essential f z) (W G : Nat)
    (hstar : C.isDStar z.val = true) (hW : W ∈ C.users z.val)
    (hG : G ∈ C.users W) (g : Table) (a b : Nat)
    (hgate : C.gateAt G = some (g,a,b)) (x : Fin n) (hoperand : a = x.val ∨ b = x.val) : False := by
  have hDz := C.isD_of_isDStar z.val hstar
  have huz := C.users_singleton_of_isD z.val W hDz hW
  have hDW : C.isD W = true := by
    obtain ⟨_, w, hw, hd⟩ := (C.isDStar_iff z.val).mp hstar
    rw [huz, Finset.mem_singleton] at hw
    simpa [hw] using hd
  have huW := C.users_singleton_of_isD W G hDW hG
  have hgnl : g.nonlinear = true := by
    obtain ⟨_, k, g', a', b', hk, hab, hnl⟩ := (C.isD_iff W).mp hDW
    have hkW : k ∈ C.users W := C.mem_users.mpr ⟨g',a',b',hk,hab⟩
    rw [huW, Finset.mem_singleton] at hkW
    rw [hkW, hgate] at hk
    cases hk
    exact hnl
  have hGW : W < G := by
    obtain ⟨g',a',b',hg',hab⟩ := C.mem_users.mp hG
    have hb := C.gateAt_bounds hg'
    rcases hab with he | he <;> omega
  have hzx : z ≠ x := by
    intro he
    have hGz : G ∈ C.users z.val := C.mem_users.mpr ⟨g,a,b,hgate,by
      rcases hoperand with ha | hb
      · exact Or.inl (by rw [ha, ← he])
      · exact Or.inr (by rw [hb, ← he])⟩
    rw [huz, Finset.mem_singleton] at hGz
    omega
  have houtz : C.outIs z.val = 0 := by
    have hc := ((C.isD_iff z.val).mp hDz).1
    have hge := C.refCount_ge z.val
    have hp := Finset.card_pos.mpr ⟨W,hW⟩
    omega
  have houtW : C.outIs W = 0 := by
    have hc := ((C.isD_iff W).mp hDW).1
    have hge := C.refCount_ge W
    have hp := Finset.card_pos.mpr ⟨G,hG⟩
    omega
  have hout : ∀ k neg, C.outWire = some (k,neg) → k ≠ z.val ∧ k ≠ W := by
    intro k neg hk
    constructor <;> intro he
    · simp [outIs, hk, he] at houtz
    · simp [outIs, hk, he] at houtW
  have hchainz : ∀ k ∈ C.users z.val, k = W := by
    intro k hk; simpa [huz] using hk
  have hchainW : ∀ k ∈ C.users W, k = G := by
    intro k hk; simpa [huW] using hk
  have hblock : ∃ β value : Bool, ∀ v,
      C.valueAt (fixBit x β v) G = value := by
    rcases hoperand with ha | hb
    · obtain ⟨β,hβ,_⟩ := g.nonlinear_exists_blocksLeft hgnl
      refine ⟨β, g.eval β false, ?_⟩
      intro v
      rw [C.valueAt_gate _ hgate, ha, C.valueAt_input]
      have hfixed : fixBit x β v x = β := by simp [fixBit]
      rw [hfixed, g.blocksLeft_eval β hβ]
    · obtain ⟨β,hβ,_⟩ := g.nonlinear_exists_blocksRight hgnl
      refine ⟨β, g.eval false β, ?_⟩
      intro v
      rw [C.valueAt_gate _ hgate, hb, C.valueAt_input]
      have hfixed : fixBit x β v x = β := by simp [fixBit]
      rw [hfixed, g.blocksRight_eval β hβ]
  obtain ⟨β,value,hvalue⟩ := hblock
  obtain ⟨p,q,hagree,hdiff⟩ := hE1 x β z hzx hzEss
  apply hdiff
  have hinputs : ∀ v, v ≠ z → fixBit x β p v = fixBit x β q v := by
    intro v hv
    simp [fixBit, hagree v hv]
  have hGvalue : C.valueAt (fixBit x β p) G = C.valueAt (fixBit x β q) G := by
    rw [hvalue, hvalue]
  have heval := C.eval_eq_of_chain_cut z W G (fixBit x β p) (fixBit x β q)
    hinputs hchainz hchainW hGvalue hout
  simpa only [hc] using heval


theorem not_dGate_of_multi_of_safe {n : Nat} (C : OpenCircuit n) (hsafe : C.DGateSafe) (x : Fin n) (h2 : 2 ≤ C.refCount x.val)
    {k : Nat} (hk : k ∈ C.users x.val) : C.isDGate k = false := by
  cases hd : C.isDGate k with
  | false => rfl
  | true =>
    exfalso
    obtain ⟨g, a, b, hg, hab⟩ := (C.isDGate_iff k).mp hd
    obtain ⟨g', a', b', hg', hx⟩ := C.mem_users.mp hk
    rw [hg] at hg'
    cases hg'
    have hnotD (s : Nat) (hs : C.isD s = true) (hsx : s = x.val) : False := by
      rw [hsx] at hs
      have := ((C.isD_iff x.val).mp hs).1
      omega
    rcases hab with ⟨ha, hDa⟩ | ⟨hb, hDb⟩
    · rcases hx with hax | hbx
      · exact hnotD a hDa hax
      · have hfa := (hsafe k g a b hg ha (by rw [hbx]; exact x.isLt)).1
        rw [hfa] at hDa
        contradiction
    · rcases hx with hax | hbx
      · have hfb := (hsafe k g a b hg (by rw [hax]; exact x.isLt) hb).2
        rw [hfb] at hDb
        contradiction
      · exact hnotD b hDb hbx

/-- A dead reader of an essential input carries neither two-level credit
role, even when the circuit has not yet been reduced. -/
theorem dead_essential_reader_no_role {n : Nat} (C : OpenCircuit n)
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (hsafe : C.DGateSafe)
    (horig : ∀ z : Fin n, C.isDStar z.val = true → Essential f z)
    (y q : Fin n) (hq : q ≠ y) (V : Nat) (hVy : V ∈ C.users y.val)
    (hdead : C.refCount V = 0) (hyess : Essential C.eval y)
    (W Z : Fin n → Nat)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hz : ∀ z, C.isDStar z.val = true → Z z ∈ C.users (W z)) :
    (∀ z, C.isD z.val = true → W z ≠ V) ∧
    (∀ z, C.isDStar z.val = true → Z z ≠ V) := by
  have hy2 := C.essential_input_with_dead_reader_has_two_refs y q hq V hVy hdead hyess
  have hnot := C.not_dGate_of_multi_of_safe hsafe y hy2 hVy
  obtain ⟨g,a,b,hg,hab⟩ := C.mem_users.mp hVy
  constructor
  · intro z hd he
    have hVz : V ∈ C.users z.val := by simpa [he] using hw z hd
    obtain ⟨g',a',b',hg',hab'⟩ := C.mem_users.mp hVz
    rw [hg] at hg'
    cases hg'
    have hD : C.isDGate V = true := by
      apply (C.isDGate_iff V).mpr
      refine ⟨g,a,b,hg,?_⟩
      rcases hab' with he' | he'
      · exact Or.inl ⟨by rw [he']; exact z.isLt, by rw [he']; exact hd⟩
      · exact Or.inr ⟨by rw [he']; exact z.isLt, by rw [he']; exact hd⟩
    rw [hnot] at hD
    contradiction
  · intro z hs he
    have hd := C.isD_of_isDStar z.val hs
    have hread : V ∈ C.users (W z) := by simpa [he] using hz z hs
    exact C.second_role_has_no_primary_unreduced f hc hE1 z (horig z hs)
      (W z) V hs (hw z hd) hread g a b hg y hab

end OpenCircuit
end SatLowerBound
