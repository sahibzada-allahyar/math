import Credit.TwoLevel.CofactorE1
import Credit.TwoLevel.Eliminated

/-! Gate shape of the restriction compiler, independent of liveness. -/
namespace SatLowerBound

/-- Every binary gate emitted by `simplifyGate` has distinct operands. -/
theorem simplifyGate_binary_distinct {n : Nat} (g h : Table) (s t : Signal n)
    (i j : Fin n) (hs : simplifyGate g s t = .binary h i j) : i ≠ j := by
  cases s with
  | constant a => cases t <;> simp [simplifyGate] at hs
  | wire k a =>
    cases t with
    | constant b => simp [simplifyGate] at hs
    | wire l b =>
      simp only [simplifyGate] at hs
      split at hs
      · contradiction
      · rename_i hkl
        unfold GateStep.classify at hs
        split at hs
        · contradiction
        · split at hs
          · contradiction
          · cases hs
            exact hkl

namespace OpenCircuit

/-- Restriction simplification emits only gates with distinct operands,
even when the resulting circuit contains dead gates. -/
theorem restrict_distinct_operands {n m : Nat} (C : OpenCircuit n) (σ : Fin n → Signal m) :
    (C.restrict σ).DistinctOperands := by
  induction C generalizing m with
  | output s =>
    intro k g a b hk
    simp [restrict,gateAt] at hk
  | @gate n g i j rest ih =>
    cases hs : simplifyGate g (σ i) (σ j) with
    | «alias» s =>
      simpa [restrict,hs] using ih (extendSubst σ s)
    | binary g' a' b' =>
      have hab : a' ≠ b' := simplifyGate_binary_distinct g g' (σ i) (σ j) a' b' hs
      have ht := ih (liftSubst σ)
      intro k h a b hk
      have hk' : (OpenCircuit.gate g' a' b' (rest.restrict (liftSubst σ))).gateAt k =
          some (h,a,b) := by simpa [restrict,hs] using hk
      by_cases he : k = m
      · subst k
        rw [gateAt_head] at hk'
        simp only [Option.some.injEq, Prod.mk.injEq] at hk'
        obtain ⟨_,ha,hb⟩ := hk'
        intro heq
        exact hab (Fin.ext (ha.trans (heq.trans hb.symm)))
      · rw [gateAt_tail _ _ _ _ he] at hk'
        exact ht k h a b hk'

/-- A primary input absent from the initial resolution cannot be created
by resolution of later gates. -/
theorem resAt_no_hit_of_no_initial_hit {n : Nat} (C : OpenCircuit n)
    (ρ : Fin n → Res) (z : Nat) (hzn : z < n)
    (hinit : ∀ w, (ρ w).hits z = false) :
    ∀ k, (C.resAt ρ k).hits z = false := by
  intro k
  induction k using Nat.strong_induction_on with
  | h k ih =>
    apply Bool.eq_false_iff.mpr
    intro hh
    rcases FlatKeptAux.hits_cases C ρ hh with ⟨hkn,hin⟩ | ⟨g,a,b,hgate,hcase⟩
    · rw [hinit] at hin
      contradiction
    · obtain ⟨_,_,ha,hb⟩ := C.gateAt_bounds hgate
      rcases hcase with ⟨_,he⟩ | hsource
      · omega
      · rcases hsource with hs | hs
        · rw [ih a ha] at hs
          contradiction
        · rw [ih b hb] at hs
          contradiction

/-- A fixed coordinate has no references in the compiler's restricted
circuit; no dangling occurrence of that input is introduced. -/
theorem fixed_input_unused_after_restriction {n : Nat} (C : OpenCircuit n)
    (x : Fin n) (b : Bool) :
    (C.restrict (singleSubst x b)).usage (singleUse x) = 0 := by
  let P : Fin n → Bool := fun z => decide (z = x)
  let c : Fin n → Bool := fun _ => b
  let ρ := fixRes P c
  have hinit : ∀ w, (ρ w).hits x.val = false := by
    intro w
    by_cases he : w = x
    · subst w
      simp [ρ,fixRes,P,c,Res.hits]
    · simp [ρ,fixRes,P,c,Res.hits,he,Fin.val_inj]
  have hnone := C.resAt_no_hit_of_no_initial_hit ρ x.val x.isLt hinit
  have hsum : ∑ k ∈ Finset.range (n + C.size), C.keptSlotHits ρ k x.val = 0 := by
    apply Finset.sum_eq_zero
    intro k _
    cases hg : C.gateAt k with
    | none => exact FlatKeptAux.keptSlotHits_none C ρ x.val hg
    | some p =>
      obtain ⟨g,a,d⟩ := p
      rw [FlatKeptAux.keptSlotHits_eq C ρ x.val hg]
      simp [hnone,indicator]
  have hout : C.outHits ρ x.val = 0 := by
    unfold outHits
    cases hw : C.outWire with
    | none => rfl
    | some p =>
      obtain ⟨k,neg⟩ := p
      simp [hnone,indicator]
  have hzero : C.keptRefs ρ x.val = 0 := by
    have he := C.keptRefs_eq_sum ρ x.val
    omega
  have hu := C.usage_restrict_fix P c x
  change (C.restrict (singleSubst x b)).usage (singleUse x) = 0
  simpa [P,c,← singleSubst_eq_fixSubst,ρ,hzero] using hu

/-- A fixed-input restriction cannot introduce a primary input that had no
reference in the original circuit. -/
theorem usage_pos_of_fix_usage_pos {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool)
    (z : Fin n) (hu : 0 < (C.restrict (fixSubst P c)).usage (singleUse z)) :
    0 < C.usage (singleUse z) := by
  by_contra hn
  have hz : C.refCount z.val = 0 := by
    rw [C.usage_singleUse] at hn
    omega
  have hge := C.refCount_ge z.val
  have hempty : C.users z.val = ∅ := Finset.card_eq_zero.mp (by omega)
  have hout0 : C.outIs z.val = 0 := by omega
  have hout : ∀ k neg, C.outWire = some (k,neg) → k ≠ z.val := by
    intro k neg hk he
    simp [outIs,hk,he] at hout0
  have hzero := C.keptRefs_zero_of_eliminated_nonpassing_readers P c z (by
    intro k hk
    rw [hempty] at hk
    simp at hk) (by
    intro k hk
    rw [hempty] at hk
    simp at hk) hout
  rw [C.usage_restrict_fix P c z,hzero] at hu
  omega

end OpenCircuit
end SatLowerBound
