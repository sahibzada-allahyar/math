import Credit.TwoLevel.SubsetSumPolynomial

/-! Degree bounds for the polynomial in the subset-sum proof. -/
namespace SatLowerBound
open MvPolynomial

theorem variablePairs_card (d : Nat) : (variablePairs d).card = Nat.choose d 2 := by
  unfold variablePairs
  simpa using (Finset.card_product_filter_lt (s := (Finset.univ : Finset (Fin d))))

/-- Each pair contributes at most two to the total degree. -/
theorem signedVandermonde_degree_le {R : Type} [CommRing R] [Nontrivial R] (d : Nat) :
    (signedVandermonde R d).totalDegree ≤ 2 * Nat.choose d 2 := by
  classical
  unfold signedVandermonde
  calc
    _ ≤ ∑ p ∈ variablePairs d, (((X p.1 - X p.2) * (X p.1 + X p.2) : MvPolynomial (Fin d) R).totalDegree) :=
      MvPolynomial.totalDegree_finsetProd _ _
    _ ≤ ∑ _p ∈ variablePairs d, 2 := by
      apply Finset.sum_le_sum
      intro p _
      have hsub : ((X p.1 - X p.2 : MvPolynomial (Fin d) R)).totalDegree ≤ 1 := by
        exact (MvPolynomial.totalDegree_sub _ _).trans (by simp)
      have hadd : ((X p.1 + X p.2 : MvPolynomial (Fin d) R)).totalDegree ≤ 1 := by
        exact (MvPolynomial.totalDegree_add _ _).trans (by simp)
      exact (MvPolynomial.totalDegree_mul _ _).trans (by omega)
    _ = 2 * Nat.choose d 2 := by simp [variablePairs_card,Nat.mul_comm]

/-- A product of `|C|` linear sum-avoiding factors has degree at most `|C|`. -/
theorem sumAvoidingFactor_degree_le {R : Type} [CommRing R] [Nontrivial R]
    (d : Nat) (Cset : Finset R) :
    (∏ c ∈ Cset, ((∑ i : Fin d, X i) - MvPolynomial.C c) : MvPolynomial (Fin d) R).totalDegree ≤ Cset.card := by
  classical
  have hlinear : ((∑ i : Fin d, X i) : MvPolynomial (Fin d) R).totalDegree ≤ 1 := by
    apply MvPolynomial.totalDegree_finsetSum_le
    intro i _
    simp
  calc
    _ ≤ ∑ c ∈ Cset, (((∑ i : Fin d, X i) - MvPolynomial.C c : MvPolynomial (Fin d) R).totalDegree) :=
      MvPolynomial.totalDegree_finsetProd _ _
    _ ≤ ∑ _c ∈ Cset, 1 := by
      apply Finset.sum_le_sum
      intro c _
      exact (MvPolynomial.totalDegree_sub_C_le _ _).trans hlinear
    _ = Cset.card := by simp

/-- The full vanishing polynomial has the degree bound used in the cited
Nullstellensatz argument. -/
theorem signedSumAvoidingPolynomial_degree_le {R : Type} [CommRing R] [Nontrivial R]
    (d : Nat) (Cset : Finset R) :
    (signedSumAvoidingPolynomial R d Cset).totalDegree ≤ d * (d - 1) + Cset.card := by
  have hchoose : 2 * Nat.choose d 2 ≤ d * (d - 1) := by rw [Nat.choose_two_right]; omega
  unfold signedSumAvoidingPolynomial
  have hv := signedVandermonde_degree_le (R := R) d
  have hs := sumAvoidingFactor_degree_le (R := R) d Cset
  exact (MvPolynomial.totalDegree_mul _ _).trans (by omega)

/-- The Nullstellensatz degree premise follows from the elementary count of
pair factors and sum-avoiding factors. -/
theorem signedSumAvoidingPolynomial_coefficient_zero_of_degree_bound
    {R : Type} [Field R] [DecidableEq R] [Fintype R]
    {d : Nat} (a : Fin d → R) (domains : Fin d → Finset R)
    (hdom : ∀ i x, x ∈ domains i → ∃ j, x = a j ∨ x = -a j)
    (t : Fin d →₀ Nat)
    (hdegree : d * (d - 1) + (signedRestrictedSums a domains).card ≤ t.degree)
    (hsize : ∀ i, t i < (domains i).card) :
    (signedSumAvoidingPolynomial R d (signedRestrictedSums a domains)).coeff t = 0 := by
  apply signedSumAvoidingPolynomial_coefficient_zero a domains hdom t _ hsize
  exact (signedSumAvoidingPolynomial_degree_le d _).trans hdegree

/-- A nonzero coefficient of the polynomial forces the restricted sumset to
be large. Establishing that nonzero coefficient is the determinant step in
Balandraud's proof. -/
theorem restrictedSums_card_gt_of_nonzero_coefficient
    {R : Type} [Field R] [DecidableEq R] [Fintype R]
    {d : Nat} (a : Fin d → R) (domains : Fin d → Finset R)
    (hdom : ∀ i x, x ∈ domains i → ∃ j, x = a j ∨ x = -a j)
    (t : Fin d →₀ Nat) (hsize : ∀ i, t i < (domains i).card)
    (hcoef : (signedSumAvoidingPolynomial R d (signedRestrictedSums a domains)).coeff t ≠ 0) :
    t.degree < d * (d - 1) + (signedRestrictedSums a domains).card := by
  by_contra h
  apply hcoef
  exact signedSumAvoidingPolynomial_coefficient_zero_of_degree_bound a domains hdom t (by omega) hsize

end SatLowerBound
