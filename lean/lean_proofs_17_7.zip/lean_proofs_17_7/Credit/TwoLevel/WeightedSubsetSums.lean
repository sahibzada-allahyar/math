import Credit.TwoLevel.WeightedModularRows
import Credit.TwoLevel.CofactorSubcube
import Mathlib.Combinatorics.Additive.SubsetSum

/-! Residual weights used in the manuscript's subset-sum argument. -/
namespace SatLowerBound

/-- The free coordinates other than the chosen pair. -/
def residualCoordinates {n : Nat} (ρ : Fin n → Option Bool) (i j : Fin n) : Finset (Fin n) :=
  ((freeCoordinates ρ).erase i).erase j

/-- The corresponding distinct nonzero weights in `ZMod p`. -/
def residualWeights {n p : Nat} (ρ : Fin n → Option Bool) (i j : Fin n) : Finset (ZMod p) :=
  (residualCoordinates ρ i j).image (fun z => ((z.val + 1 : Nat) : ZMod p))

/-- The weights `1,...,n` remain distinct modulo a modulus larger than `n`. -/
theorem weightedCoordinate_injective {n p : Nat} (h : n < p) :
    Function.Injective (fun z : Fin n => ((z.val + 1 : Nat) : ZMod p)) := by
  intro i j he
  have hm := (ZMod.natCast_eq_natCast_iff' _ _ p).mp he
  rw [Nat.mod_eq_of_lt (by have := i.isLt; omega),
    Nat.mod_eq_of_lt (by have := j.isLt; omega)] at hm
  apply Fin.ext
  omega

/-- Exactly two free coordinates were removed to form the residual weights. -/
theorem residualWeights_card {n p : Nat} (ρ : Fin n → Option Bool) (i j : Fin n)
    (hij : i ≠ j) (hi : ρ i = none) (hj : ρ j = none) (hlarge : n < p) :
    (residualWeights (p := p) ρ i j).card + 2 = (freeCoordinates ρ).card := by
  classical
  unfold residualWeights
  rw [Finset.card_image_of_injective _ (weightedCoordinate_injective hlarge)]
  have hi' : i ∈ freeCoordinates ρ := by simp [freeCoordinates,hi]
  have hj' : j ∈ (freeCoordinates ρ).erase i := by simp [freeCoordinates,hj,Ne.symm hij]
  unfold residualCoordinates
  rw [Finset.card_erase_of_mem hj', Finset.card_erase_of_mem hi']
  have h1 := Finset.card_pos.mpr ⟨i,hi'⟩
  have h2 := Finset.card_pos.mpr ⟨j,hj'⟩
  rw [Finset.card_erase_of_mem hi'] at h2
  omega

/-- None of the weights from `1,...,n` is the negative of another when
`p > 2n`; in particular the residual weight set is disjoint from its negative. -/
theorem weightedCoordinate_ne_neg {n p : Nat} (hlarge : 2 * n < p) (i j : Fin n) :
    ((i.val + 1 : Nat) : ZMod p) ≠ -((j.val + 1 : Nat) : ZMod p) := by
  intro he
  have hz : (((i.val + 1) + (j.val + 1) : Nat) : ZMod p) = 0 := by
    push_cast at he ⊢
    exact add_eq_zero_iff_eq_neg.mpr he
  have hm := (ZMod.natCast_eq_natCast_iff' ((i.val + 1) + (j.val + 1)) 0 p).mp (by simpa using hz)
  have hi := i.isLt
  have hj := j.isLt
  have hlt : (i.val + 1) + (j.val + 1) < p := by omega
  rw [Nat.mod_eq_of_lt hlt, Nat.zero_mod] at hm
  omega

theorem residualWeights_no_opposites {n p : Nat} (ρ : Fin n → Option Bool) (i j : Fin n)
    (hlarge : 2 * n < p) :
    ∀ x ∈ residualWeights (p := p) ρ i j, -x ∉ residualWeights (p := p) ρ i j := by
  classical
  intro x hx hneg
  obtain ⟨a,_,rfl⟩ := Finset.mem_image.mp hx
  obtain ⟨b,_,hb⟩ := Finset.mem_image.mp hneg
  exact weightedCoordinate_ne_neg hlarge b a hb

/-- A restricted weighted residual is the fixed offset plus the sum of the
free, unselected weights whose input bits are true. -/
theorem weightedResidual_decomposition {n p : Nat} (ρ : Fin n → Option Bool)
    (i j : Fin n) (hi : ρ i = none) (hj : ρ j = none) (v : Fin n → Bool) :
    weightedResidual (p := p) ρ i j v = weightedResidual ρ i j (fun _ => false) +
      ∑ z ∈ residualCoordinates ρ i j, if v z then ((z.val + 1 : Nat) : ZMod p) else 0 := by
  classical
  have hfilter : (∑ z ∈ residualCoordinates ρ i j, if v z then ((z.val + 1 : Nat) : ZMod p) else 0) =
      ∑ z : Fin n, if ρ z = none ∧ z ≠ i ∧ z ≠ j then
        (if v z then ((z.val + 1 : Nat) : ZMod p) else 0) else 0 := by
    have hset : residualCoordinates ρ i j = Finset.univ.filter
        (fun z => ρ z = none ∧ z ≠ i ∧ z ≠ j) := by
      ext z
      simp [residualCoordinates,freeCoordinates, and_comm, and_left_comm, and_assoc]
    rw [hset, Finset.sum_filter]
  rw [hfilter]
  unfold weightedResidual weightedSum
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro z _
  by_cases hzi : z = i
  · subst z
    simp [applyPartial,setPair,hi]
  · by_cases hzj : z = j
    · subst z
      simp [applyPartial,setPair,hj,hzi]
    · cases hρ : ρ z with
      | none => simp [applyPartial,setPair,hzi,hzj,hρ]
      | some b => cases b <;> simp [applyPartial,setPair,hzi,hzj,hρ]

/-- Coverage by residual subset sums gives every prescribed restricted
weighted sum; fixed coordinates only translate the set of sums. -/
theorem weightedResidual_surjective_of_subsetSum {n p : Nat} [NeZero p]
    (ρ : Fin n → Option Bool) (i j : Fin n) (hi : ρ i = none) (hj : ρ j = none)
    (hlarge : n < p)
    (hcover : (residualWeights (p := p) ρ i j).subsetSum = Finset.univ) :
    Function.Surjective (weightedResidual (p := p) ρ i j) := by
  classical
  intro target
  let weight : Fin n → ZMod p := fun z => ((z.val + 1 : Nat) : ZMod p)
  let offset := weightedResidual (p := p) ρ i j (fun _ => false)
  have ht : target - offset ∈ (residualWeights (p := p) ρ i j).subsetSum := by
    rw [hcover]
    exact Finset.mem_univ _
  obtain ⟨B,hB,hBsum⟩ := Finset.mem_subsetSum_iff.mp ht
  let T := (residualCoordinates ρ i j).filter (fun z => weight z ∈ B)
  have himage : T.image weight = B := by
    ext b
    constructor
    · intro hb
      obtain ⟨z,hz,rfl⟩ := Finset.mem_image.mp hb
      exact (Finset.mem_filter.mp hz).2
    · intro hb
      have hm := hB hb
      change b ∈ (residualCoordinates ρ i j).image weight at hm
      obtain ⟨z,hz,he⟩ := Finset.mem_image.mp hm
      exact Finset.mem_image.mpr ⟨z,Finset.mem_filter.mpr ⟨hz,by rw [he]; exact hb⟩,he⟩
  let v : Fin n → Bool := fun z => decide (weight z ∈ B)
  refine ⟨v, ?_⟩
  rw [weightedResidual_decomposition ρ i j hi hj v]
  change offset + (∑ z ∈ residualCoordinates ρ i j, if decide (weight z ∈ B) then weight z else 0) = target
  simp only [decide_eq_true_eq, ← Finset.sum_filter]
  change offset + (∑ z ∈ T, weight z) = target
  have hsum : (∑ z ∈ T, weight z) = ∑ b ∈ B, b := by
    rw [← himage, Finset.sum_image]
    intro x _ y _ hxy
    exact weightedCoordinate_injective hlarge hxy
  rw [hsum,hBsum]
  abel

/-- A per-restriction subset-sum coverage theorem is enough for the paper's
robustness conclusion. -/
theorem weightedModularBlock_robust_of_subsetSum (n p k : Nat) [NeZero p] (hlarge : 2 * n < p)
    (hcover : ∀ (ρ : Fin n → Option Bool), k ≤ (freeCoordinates ρ).card →
      ∀ i j, i ≠ j → ρ i = none → ρ j = none →
        (residualWeights (p := p) ρ i j).subsetSum = Finset.univ)
    (target : ZMod p) : Robust k (weightedModularBlock n p target) := by
  apply weightedModularBlock_robust_of_coverage n p k hlarge
  intro ρ hfree i j hij hi hj
  exact weightedResidual_surjective_of_subsetSum ρ i j hi hj (by omega)
    (hcover ρ hfree i j hij hi hj)

/-- If the paper's subset-sum cardinality bound is available for `ZMod p`,
then its stated threshold implies robustness of every weighted block. The
cardinality bound remains an explicit hypothesis of this intermediate result. -/
theorem weightedModularBlock_robust_of_subsetSumBound (n p m k : Nat) [NeZero p]
    (hlarge : 2 * n < p) (hk : m + 2 ≤ k)
    (hthreshold : p ≤ 1 + m * (m + 1) / 2)
    (hbound : ∀ A : Finset (ZMod p), (∀ x ∈ A, -x ∉ A) →
      min p (1 + A.card * (A.card + 1) / 2) ≤ A.subsetSum.card)
    (target : ZMod p) : Robust k (weightedModularBlock n p target) := by
  apply weightedModularBlock_robust_of_subsetSum n p k hlarge
  intro ρ hfree i j hij hi hj
  let A := residualWeights (p := p) ρ i j
  have hcard := residualWeights_card ρ i j hij hi hj (show n < p by omega)
  change A.card + 2 = (freeCoordinates ρ).card at hcard
  have hm : m ≤ A.card := by omega
  have hmul : m * (m + 1) ≤ A.card * (A.card + 1) :=
    Nat.mul_le_mul hm (by omega)
  have hdiv := Nat.div_le_div_right (c := 2) hmul
  have hp : p ≤ 1 + A.card * (A.card + 1) / 2 := by omega
  have hlower := hbound A (residualWeights_no_opposites ρ i j hlarge)
  rw [Nat.min_eq_left hp] at hlower
  change A.subsetSum = Finset.univ
  apply Finset.eq_univ_of_card
  rw [ZMod.card]
  have hupper := Finset.card_le_univ A.subsetSum
  rw [ZMod.card] at hupper
  omega

end SatLowerBound
