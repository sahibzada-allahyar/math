import Credit.TwoLevel.BalandraudBound

namespace SatLowerBound

/-- An antipodal-free set in an odd prime field has fewer than half as
many elements as the field. -/
theorem antipodal_free_card_lt_half {p : Nat} [Fact p.Prime] (hpodd : p ≠ 2)
    (A : Finset (ZMod p)) (hA : ∀ x ∈ A, -x ∉ A) : 2 * A.card < p := by
  classical
  have hd : Disjoint A (A.image Neg.neg) := by
    rw [Finset.disjoint_left]
    intro x hx hy
    obtain ⟨y, hmem, rfl⟩ := Finset.mem_image.mp hy
    exact hA y hmem hx
  have hc := Finset.card_le_univ (A ∪ A.image Neg.neg)
  rw [Finset.card_union_of_disjoint hd, Finset.card_image_of_injective _ neg_injective,
    ZMod.card] at hc
  obtain ⟨k, hk⟩ := (Fact.out : p.Prime).odd_of_ne_two hpodd
  omega

/-- Balandraud's subset-sum theorem in the exact finite-set interface used
by the weighted construction. -/
theorem balandraud_subsetSum_bound {p : Nat} [Fact p.Prime] (hpodd : p ≠ 2)
    (A : Finset (ZMod p)) (hA : ∀ x ∈ A, -x ∉ A) :
    min p (1 + A.card * (A.card + 1) / 2) ≤ A.subsetSum.card := by
  classical
  let e := A.equivFin.symm
  let a : Fin A.card → ZMod p := fun i => (e i).val
  have ha : Function.Injective a := by
    intro i j h
    apply e.injective
    exact Subtype.ext h
  have hop : ∀ i j, a i ≠ -a j := by
    intro i j hij
    have hi : a i ∈ A := (e i).property
    have hj : a j ∈ A := (e j).property
    rw [hij] at hi
    exact hA (a j) hj hi
  have he : Finset.univ.image a = A := by
    ext x
    constructor
    · intro hx
      obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hx
      exact (e i).property
    · intro hx
      obtain ⟨i, hi⟩ := e.surjective ⟨x, hx⟩
      exact Finset.mem_image.mpr ⟨i, Finset.mem_univ _, congrArg Subtype.val hi⟩
  have h := balandraud_subsetSum_min_enumerated hpodd A.card a ha hop
    (antipodal_free_card_lt_half hpodd A hA)
  rw [he] at h
  simpa [Nat.choose_two_right, Nat.mul_comm] using h

/-- Robustness of the manuscript's weighted modular block without a
subset-sum theorem assumption. -/
theorem weightedModularBlock_robust (n p m k : Nat) [Fact p.Prime]
    (hpodd : p ≠ 2) (hlarge : 2 * n < p) (hk : m + 2 ≤ k)
    (hthreshold : p ≤ 1 + m * (m + 1) / 2) (target : ZMod p) :
    Robust k (weightedModularBlock n p target) := by
  exact weightedModularBlock_robust_of_subsetSumBound n p m k hlarge hk hthreshold
    (fun A hA => balandraud_subsetSum_bound hpodd A hA) target

end SatLowerBound
