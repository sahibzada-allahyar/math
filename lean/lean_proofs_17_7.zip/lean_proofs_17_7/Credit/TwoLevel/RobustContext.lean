import Credit.TwoLevel.RobustOn
import Credit.TwoLevel.RetirementAccounting

/-! Selected leaves and their retirement in general robust-block trees. -/
namespace SatLowerBound
open OpenCircuit

namespace RobustTree

def blocks {n : Nat} : RobustTree n → Nat
  | .leaf _ _ => 1
  | .branch _ a b => a.blocks + b.blocks

end RobustTree

/-- A read-once tree with one distinguished leaf replaced by a hole. -/
inductive RobustContext (n : Nat) where
  | hole
  | left (isOr : Bool) (inside : RobustContext n) (sibling : RobustTree n)
  | right (isOr : Bool) (sibling : RobustTree n) (inside : RobustContext n)

namespace RobustContext

def plug {n : Nat} : RobustContext n → RobustTree n → RobustTree n
  | .hole, T => T
  | .left p K R, T => .branch p (K.plug T) R
  | .right p L K, T => .branch p L (K.plug T)

def support {n : Nat} : RobustContext n → Finset (Fin n)
  | .hole => ∅
  | .left _ K R => K.support ∪ R.support
  | .right _ L K => L.support ∪ K.support

def blocks {n : Nat} : RobustContext n → Nat
  | .hole => 0
  | .left _ K R => K.blocks + R.blocks
  | .right _ L K => L.blocks + K.blocks

def retire {n : Nat} : RobustContext n → Option (RobustTree n)
  | .hole => none
  | .left p K R => some (match K.retire with | none => R | some U => .branch p U R)
  | .right p L K => some (match K.retire with | none => L | some U => .branch p L U)

def neutral {n : Nat} : RobustContext n → Bool
  | .hole => false
  | .left p K _ => if K.retire.isNone then !p else K.neutral
  | .right p _ K => if K.retire.isNone then !p else K.neutral

theorem retire_none {n : Nat} (K : RobustContext n) : K.retire = none ↔ K = .hole := by
  cases K <;> simp [retire]

theorem plug_support {n : Nat} (K : RobustContext n) (T : RobustTree n) :
    (K.plug T).support = T.support ∪ K.support := by
  induction K with
  | hole => simp [plug,support]
  | left p K R ih => simp only [plug,support,RobustTree.support,ih,Finset.union_assoc]
  | right p L K ih =>
    simp only [plug,support,RobustTree.support,ih]
    ext i
    simp only [Finset.mem_union]
    tauto

theorem plug_blocks {n : Nat} (K : RobustContext n) (T : RobustTree n) :
    (K.plug T).blocks = T.blocks + K.blocks := by
  induction K with
  | hole => simp [plug,blocks]
  | left p K R ih => simp only [plug,blocks,RobustTree.blocks,ih]; omega
  | right p L K ih => simp only [plug,blocks,RobustTree.blocks,ih]; omega

theorem retire_stats {n : Nat} (K : RobustContext n) (R : RobustTree n) (h : K.retire = some R) :
    R.support = K.support ∧ R.blocks = K.blocks := by
  induction K generalizing R with
  | hole => contradiction
  | left p K U ih =>
    cases hk : K.retire with
    | none =>
      have he := K.retire_none.mp hk
      subst K
      simp only [retire,Option.some.injEq] at h
      subst R
      simp [support,blocks]
    | some V =>
      simp only [retire,hk,Option.some.injEq] at h
      subst R
      obtain ⟨hs,hb⟩ := ih V hk
      simp only [support,blocks,RobustTree.support,RobustTree.blocks,hs,hb,and_self]
  | right p U K ih =>
    cases hk : K.retire with
    | none =>
      have he := K.retire_none.mp hk
      subst K
      simp only [retire,Option.some.injEq] at h
      subst R
      simp [support,blocks]
    | some V =>
      simp only [retire,hk,Option.some.injEq] at h
      subst R
      obtain ⟨hs,hb⟩ := ih V hk
      simp only [support,blocks,RobustTree.support,RobustTree.blocks,hs,hb,and_self]

/-- The sibling subtrees meet the current block-size condition and have
disjoint support from the selected hole and each other. -/
def Fits {n : Nat} (k : Nat) (ρ : Fin n → Option Bool) (S : Finset (Fin n)) : RobustContext n → Prop
  | .hole => True
  | .left _ K R => K.Fits k ρ S ∧ R.Valid k ρ ∧ Disjoint (S ∪ K.support) R.support
  | .right _ L K => L.Valid k ρ ∧ K.Fits k ρ S ∧ Disjoint L.support (S ∪ K.support)

theorem fits_of_plug {n k : Nat} (ρ : Fin n → Option Bool) (K : RobustContext n) (T : RobustTree n)
    (h : (K.plug T).Valid k ρ) : T.Valid k ρ ∧ K.Fits k ρ T.support := by
  induction K with
  | hole => exact ⟨h,True.intro⟩
  | left p K R ih =>
    obtain ⟨ht,hK⟩ := ih h.1
    exact ⟨ht,hK,h.2.1,by simpa only [plug_support] using h.2.2⟩
  | right p L K ih =>
    obtain ⟨ht,hK⟩ := ih h.2.1
    exact ⟨ht,h.1,hK,by simpa only [plug_support] using h.2.2⟩

theorem fits_disjoint {n k : Nat} (ρ : Fin n → Option Bool) (K : RobustContext n)
    (S : Finset (Fin n)) (h : K.Fits k ρ S) : Disjoint S K.support := by
  induction K with
  | hole => simp [support]
  | left p K R ih =>
    apply Finset.disjoint_left.mpr
    intro x hx hmem
    rcases Finset.mem_union.mp hmem with hk | hr
    · exact Finset.disjoint_left.mp (ih h.1) hx hk
    · exact Finset.disjoint_left.mp h.2.2 (Finset.mem_union_left _ hx) hr
  | right p L K ih =>
    apply Finset.disjoint_left.mpr
    intro x hx hmem
    rcases Finset.mem_union.mp hmem with hl | hk
    · exact Finset.disjoint_left.mp h.2.2 hl (Finset.mem_union_left _ hx)
    · exact Finset.disjoint_left.mp (ih h.2.1) hx hk

/-- Plugging a leaf at the retirement threshold retains the E1-level
validity of the whole tree. -/
theorem plug_validOne {n k : Nat} (ρ : Fin n → Option Bool) (K : RobustContext n)
    (S : Finset (Fin n)) (h : K.Fits k ρ S) (T : RobustTree n)
    (hT : T.ValidOne k ρ) (hS : T.support = S) : (K.plug T).ValidOne k ρ := by
  induction K with
  | hole => exact hT
  | left p K R ih =>
    refine ⟨ih h.1,RobustTree.Valid.toValidOne h.2.1,?_⟩
    simpa only [plug_support,hS] using h.2.2
  | right p L K ih =>
    refine ⟨RobustTree.Valid.toValidOne h.1,ih h.2.1,?_⟩
    simpa only [plug_support,hS] using h.2.2

theorem retire_valid {n k : Nat} (ρ : Fin n → Option Bool) (K : RobustContext n)
    (S : Finset (Fin n)) (h : K.Fits k ρ S) (R : RobustTree n)
    (hr : K.retire = some R) : R.Valid k ρ := by
  induction K generalizing R with
  | hole => contradiction
  | left p K U ih =>
    cases hk : K.retire with
    | none =>
      simp only [retire,hk,Option.some.injEq] at hr
      subst R
      exact h.2.1
    | some V =>
      simp only [retire,hk,Option.some.injEq] at hr
      subst R
      refine ⟨ih h.1 V hk,h.2.1,?_⟩
      rw [(K.retire_stats V hk).1]
      apply Finset.disjoint_left.mpr
      intro i hi hj
      exact Finset.disjoint_left.mp h.2.2 (Finset.mem_union_right _ hi) hj
  | right p U K ih =>
    cases hk : K.retire with
    | none =>
      simp only [retire,hk,Option.some.injEq] at hr
      subst R
      exact h.1
    | some V =>
      simp only [retire,hk,Option.some.injEq] at hr
      subst R
      refine ⟨h.1,ih h.2.1 V hk,?_⟩
      rw [(K.retire_stats V hk).1]
      apply Finset.disjoint_left.mpr
      intro i hi hj
      exact Finset.disjoint_left.mp h.2.2 hi (Finset.mem_union_right _ hj)

theorem retire_eval {n : Nat} (K : RobustContext n) (R T : RobustTree n)
    (h : K.retire = some R) (v : Fin n → Bool) (ht : T.eval v = K.neutral) :
    (K.plug T).eval v = R.eval v := by
  induction K generalizing R with
  | hole => contradiction
  | left p K U ih =>
    cases hk : K.retire with
    | none =>
      have he := K.retire_none.mp hk
      subst K
      simp only [retire,Option.some.injEq] at h
      subst R
      simp only [neutral,retire,Option.isNone_none,↓reduceIte] at ht
      simp only [plug,RobustTree.eval,ht]
      rw [combine_comm,combine_neutral]
    | some V =>
      simp only [retire,hk,Option.some.injEq] at h
      subst R
      simp only [neutral,hk,Option.isNone_some,Bool.false_eq_true,↓reduceIte] at ht
      simp only [plug,RobustTree.eval,ih V hk ht]
  | right p U K ih =>
    cases hk : K.retire with
    | none =>
      have he := K.retire_none.mp hk
      subst K
      simp only [retire,Option.some.injEq] at h
      subst R
      simp only [neutral,retire,Option.isNone_none,↓reduceIte] at ht
      simp only [plug,RobustTree.eval,ht,combine_neutral]
    | some V =>
      simp only [retire,hk,Option.some.injEq] at h
      subst R
      simp only [neutral,hk,Option.isNone_some,Bool.false_eq_true,↓reduceIte] at ht
      simp only [plug,RobustTree.eval,ih V hk ht]

/-- Retiring a selected leaf at its neutral value preserves the rest of the
composition and does not increase the two-level potential. -/
theorem retire_leaf_normalized {n k : Nat} (ρ : Fin n → Option Bool) (K : RobustContext n)
    (S : Finset (Fin n)) (f : (Fin n → Bool) → Bool) (R : RobustTree n)
    (hk : 2 ≤ k) (hfit : K.Fits k ρ S) (hr : K.retire = some R)
    (hrobust : RobustOn k f S) (hleaf : k+1 ≤ (freeOn S ρ).card)
    (C : OpenCircuit n) (hC : C.Reduced)
    (hc : ∀ v, C.eval v = (K.plug (.leaf f S)).eval (applyPartial ρ v))
    (hsupport : ∀ z, 0 < C.usage (OpenCircuit.singleUse z) → z ∈ freeOn (K.plug (.leaf f S)).support ρ) :
    ∃ D : OpenCircuit n, D.Reduced ∧ D.NoInputTriangles (fun _ => none) ∧
      (∀ v, D.eval v = R.eval (applyPartial ρ v)) ∧ D.psi2 ≤ C.psi2 ∧
      (∀ z, 0 < D.usage (OpenCircuit.singleUse z) → z ∈ freeOn R.support ρ) := by
  have hT : (K.plug (.leaf f S)).ValidOne k ρ :=
    K.plug_validOne ρ S hfit (.leaf f S) ⟨hrobust,hleaf⟩ rfl
  have hdep := (K.plug (.leaf f S)).restricted_oneDependence ρ hk hT
  have hR := K.retire_valid ρ S hfit R hr
  have hRdep := R.restricted_dependence ρ hk hR
  have hLeaf := hrobust.restricted_oneDependence ρ hleaf hk
  obtain ⟨u,hu⟩ := hLeaf.nonconstant.has_value K.neutral
  let P : Fin n → Bool := fun z => decide (z ∈ freeOn S ρ)
  have hdis := K.fits_disjoint ρ S hfit
  have hRsupp := (K.retire_stats R hr).1
  have hRcomp : ∀ v, (C.restrict (fixSubst P u)).eval v = R.eval (applyPartial ρ v) := by
    intro v
    rw [restrict_eval,hc]
    let w : Fin n → Bool := fun z => (fixSubst P u z).eval v
    have hwS : ∀ z ∈ freeOn S ρ, w z = u z := by
      intro z hz
      simp [w,fixSubst,P,hz,Signal.eval]
    have hwout : ∀ z, z ∉ freeOn S ρ → w z = v z := by
      intro z hz
      simp [w,fixSubst,P,hz,Signal.eval]
    have hblock : (RobustTree.leaf f S).eval (applyPartial ρ w) = K.neutral := by
      change f (applyPartial ρ w) = K.neutral
      rw [← hu]
      exact hLeaf.supported w u hwS
    change (K.plug (.leaf f S)).eval (applyPartial ρ w) = R.eval (applyPartial ρ v)
    rw [K.retire_eval R (.leaf f S) hr (applyPartial ρ w) hblock]
    apply hRdep.supported
    intro z hz
    apply hwout z
    intro hzS
    have hzs := (Finset.mem_filter.mp hzS).1
    have hzr := (Finset.mem_filter.mp hz).1
    rw [hRsupp] at hzr
    exact Finset.disjoint_left.mp hdis hzs hzr
  have heqC : C.eval = fun v => (K.plug (.leaf f S)).eval (applyPartial ρ v) := funext hc
  have heqR : (C.restrict (fixSubst P u)).eval = fun v => R.eval (applyPartial ρ v) := funext hRcomp
  have hE1C : E1 C.eval := by rw [heqC]; exact hdep.e1
  have hE1R : E1 (C.restrict (fixSubst P u)).eval := by rw [heqR]; exact hRdep.e1
  have hused : ∀ z : Fin n, 0 < C.usage (OpenCircuit.singleUse z) → Essential C.eval z := by
    intro z hz
    rw [heqC]
    exact hdep.essential z (hsupport z hz)
  have hpres : ∀ z, P z = false → Essential C.eval z → Essential (C.restrict (fixSubst P u)).eval z := by
    intro z hzP hz
    have hmem : z ∈ freeOn (K.plug (.leaf f S)).support ρ := by
      apply hdep.supported.essential_mem z
      rw [← heqC]
      exact hz
    have hnot : z ∉ freeOn S ρ := by simpa [P] using hzP
    rw [K.plug_support,show (RobustTree.leaf f S).support = S from rfl,
      RobustTree.freeOn_union] at hmem
    have hzK : z ∈ freeOn K.support ρ := (Finset.mem_union.mp hmem).resolve_left hnot
    rw [heqR]
    apply hRdep.essential
    simpa [hRsupp] using hzK
  have hn : 2 ≤ n := by
    have hle := Finset.card_le_univ (freeOn S ρ)
    simp only [Fintype.card_fin] at hle
    omega
  obtain ⟨D,hD,htri,hDe,hDp,hDs⟩ := C.psi2_retirement_normalized hn P u
    (C.reduced_distinct hC) hE1C hused hpres hE1R
  refine ⟨D,hD,htri,fun v => (hDe v).trans (hRcomp v),hDp,?_⟩
  intro z hz
  obtain ⟨hzC,hzP⟩ := hDs z hz
  have hmem := hsupport z hzC
  have hnot : z ∉ freeOn S ρ := by simpa [P] using hzP
  rw [K.plug_support,show (RobustTree.leaf f S).support = S from rfl,
    RobustTree.freeOn_union] at hmem
  have hzK : z ∈ freeOn K.support ρ := (Finset.mem_union.mp hmem).resolve_left hnot
  simpa [hRsupp] using hzK

end RobustContext

/-- Any coordinate in a robust composition belongs to a located leaf. -/
theorem RobustTree.locate {n : Nat} (T : RobustTree n) (x : Fin n) (hx : x ∈ T.support) :
    ∃ (K : RobustContext n) (f : (Fin n → Bool) → Bool) (S : Finset (Fin n)),
      T = K.plug (.leaf f S) ∧ x ∈ S := by
  induction T with
  | leaf f S => exact ⟨.hole,f,S,rfl,hx⟩
  | branch p L R ihL ihR =>
    rcases Finset.mem_union.mp hx with hL | hR
    · obtain ⟨K,f,S,hK,hS⟩ := ihL hL
      exact ⟨.left p K R,f,S,by simp only [RobustContext.plug,hK],hS⟩
    · obtain ⟨K,f,S,hK,hS⟩ := ihR hR
      exact ⟨.right p L K,f,S,by simp only [RobustContext.plug,hK],hS⟩

end SatLowerBound
