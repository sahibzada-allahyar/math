import Credit.TwoLevel.TopologicalOrder

/-! Evaluation of every wire in a topologically ordered network. -/
namespace SatLowerBound

/-- Evaluate all primary inputs and gate outputs of an ordered network. -/
def OrderedNetwork.values : {n s : Nat} → OrderedNetwork n s →
    (Fin n → Bool) → Fin (n + s) → Bool
  | _, 0, _, v => fun i => v (Fin.cast (by omega) i)
  | _, _ + 1, N, v =>
    let first := N.node 0
    let v' := extend v (first.table.eval (v first.left) (v first.right))
    fun i => N.tail.values v' (Fin.cast (by omega) i)

/-- Network evaluation is the value of the designated output wire. -/
theorem OrderedNetwork.eval_eq_values {n s : Nat} (N : OrderedNetwork n s) (v : Fin n → Bool) :
    N.eval v = N.values v N.output := by
  induction s generalizing n with
  | zero => rfl
  | succ s ih =>
    change N.tail.eval _ = N.tail.values _ _
    exact ih N.tail _

/-- Primary input values are preserved by evaluation of every later gate. -/
theorem OrderedNetwork.values_input {n s : Nat} (N : OrderedNetwork n s)
    (v : Fin n → Bool) (i : Fin n) :
    N.values v ⟨i.val,by have := i.isLt; omega⟩ = v i := by
  induction s generalizing n with
  | zero => rfl
  | succ s ih =>
    let first := N.node 0
    let v' := extend v (first.table.eval (v first.left) (v first.right))
    have h := ih N.tail v' i.castSucc
    change N.tail.values v' ⟨i.val,by have := i.isLt; omega⟩ = v i
    convert h using 1 <;> simp [v']

/-- The value of the first gate is retained in the full wire valuation. -/
theorem OrderedNetwork.values_first {n s : Nat} (N : OrderedNetwork n (s+1))
    (v : Fin n → Bool) :
    N.values v ⟨n,by omega⟩ = (N.node 0).table.eval (v (N.node 0).left) (v (N.node 0).right) := by
  let first := N.node 0
  let v' := extend v (first.table.eval (v first.left) (v first.right))
  have h := N.tail.values_input v' (Fin.last n)
  change N.tail.values v' ⟨n,by omega⟩ = _
  simpa [v'] using h

/-- Every gate value satisfies its own table and predecessor equations. -/
theorem OrderedNetwork.values_gate {n s : Nat} (N : OrderedNetwork n s)
    (v : Fin n → Bool) (i : Fin s) :
    N.values v ⟨n + i.val,by have := i.isLt; omega⟩ =
      (N.node i).table.eval
        (N.values v ⟨(N.node i).left.val,by have := (N.node i).left.isLt; have := i.isLt; omega⟩)
        (N.values v ⟨(N.node i).right.val,by have := (N.node i).right.isLt; have := i.isLt; omega⟩) := by
  induction s generalizing n with
  | zero => exact Fin.elim0 i
  | succ s ih =>
    induction i using Fin.cases with
    | zero =>
      have hl := N.values_input v (N.node 0).left
      have hr := N.values_input v (N.node 0).right
      have hf := N.values_first v
      simpa using hf.trans (congrArg₂ (N.node 0).table.eval hl.symm hr.symm)
    | succ j =>
      let first := N.node 0
      let v' := extend v (first.table.eval (v first.left) (v first.right))
      have h := ih N.tail v' j
      change N.tail.values v' _ = (N.node j.succ).table.eval
        (N.tail.values v' _) (N.tail.values v' _)
      simpa [OrderedNetwork.tail,NetworkNode.cast,Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using h

/-- Values of the originally labelled gates after topological evaluation. -/
noncomputable def AcyclicNetwork.gateValues {n s : Nat} (N : AcyclicNetwork n s)
    (v : Fin n → Bool) (g : Fin s) : Bool :=
  N.toOrdered.values v ⟨n + (N.order.symm g).val, by
    have := (N.order.symm g).isLt
    omega⟩

/-- The independent graph interpretation of a predecessor wire. -/
noncomputable def AcyclicNetwork.sourceValue {n s : Nat} (N : AcyclicNetwork n s)
    (v : Fin n → Bool) (wire : Fin n ⊕ Fin s) : Bool :=
  match wire with
  | .inl x => v x
  | .inr g => N.gateValues v g

theorem AcyclicNetwork.ordered_left_index {n s : Nat} (N : AcyclicNetwork n s) (i : Fin s) :
    ((N.toOrdered.node i).left).val =
      match N.left (N.order i) with
      | .inl x => x.val
      | .inr g => n + (N.order.symm g).val := by
  unfold AcyclicNetwork.toOrdered
  dsimp
  split <;> simp_all

theorem AcyclicNetwork.ordered_right_index {n s : Nat} (N : AcyclicNetwork n s) (i : Fin s) :
    ((N.toOrdered.node i).right).val =
      match N.right (N.order i) with
      | .inl x => x.val
      | .inr g => n + (N.order.symm g).val := by
  unfold AcyclicNetwork.toOrdered
  dsimp
  split <;> simp_all

theorem AcyclicNetwork.ordered_left_value {n s : Nat} (N : AcyclicNetwork n s)
    (v : Fin n → Bool) (i : Fin s) :
    N.toOrdered.values v ⟨(N.toOrdered.node i).left.val,by
      have := (N.toOrdered.node i).left.isLt
      have := i.isLt
      omega⟩ = N.sourceValue v (N.left (N.order i)) := by
  have hidx := N.ordered_left_index i
  cases h : N.left (N.order i) with
  | inl x =>
    simp only [h] at hidx
    simp only [sourceValue]
    convert N.toOrdered.values_input v x using 1; congr 1
    exact Fin.ext hidx
  | inr g =>
    simp only [h] at hidx
    simp only [sourceValue,gateValues]
    congr 1
    exact Fin.ext hidx

theorem AcyclicNetwork.ordered_right_value {n s : Nat} (N : AcyclicNetwork n s)
    (v : Fin n → Bool) (i : Fin s) :
    N.toOrdered.values v ⟨(N.toOrdered.node i).right.val,by
      have := (N.toOrdered.node i).right.isLt
      have := i.isLt
      omega⟩ = N.sourceValue v (N.right (N.order i)) := by
  have hidx := N.ordered_right_index i
  cases h : N.right (N.order i) with
  | inl x =>
    simp only [h] at hidx
    simp only [sourceValue]
    convert N.toOrdered.values_input v x using 1; congr 1
    exact Fin.ext hidx
  | inr g =>
    simp only [h] at hidx
    simp only [sourceValue,gateValues]
    congr 1
    exact Fin.ext hidx

/-- The values produced by compilation satisfy the original graph's gate
equations with the original, independently assigned gate names. -/
theorem AcyclicNetwork.gateValues_equations {n s : Nat} (N : AcyclicNetwork n s)
    (v : Fin n → Bool) (g : Fin s) :
    N.gateValues v g = (N.table g).eval (N.sourceValue v (N.left g))
      (N.sourceValue v (N.right g)) := by
  have h := N.toOrdered.values_gate v (N.order.symm g)
  rw [N.ordered_left_value v (N.order.symm g), N.ordered_right_value v (N.order.symm g)] at h
  simpa only [AcyclicNetwork.toOrdered,Equiv.apply_symm_apply,gateValues] using h

/-- Interpret a predecessor using independently supplied gate values. -/
def AcyclicNetwork.wireValue {n s : Nat} (v : Fin n → Bool) (gates : Fin s → Bool)
    (wire : Fin n ⊕ Fin s) : Bool :=
  match wire with
  | .inl x => v x
  | .inr g => gates g

/-- The graph's semantic equations, independent of any enumeration or compiler. -/
def AcyclicNetwork.GateConsistent {n s : Nat} (N : AcyclicNetwork n s)
    (v : Fin n → Bool) (gates : Fin s → Bool) : Prop :=
  ∀ g, gates g = (N.table g).eval (wireValue v gates (N.left g))
    (wireValue v gates (N.right g))

/-- Acyclicity makes the graph's gate equations have at most one solution. -/
theorem AcyclicNetwork.consistent_unique {n s : Nat} (N : AcyclicNetwork n s)
    (v : Fin n → Bool) (a b : Fin s → Bool)
    (ha : N.GateConsistent v a) (hb : N.GateConsistent v b) : a = b := by
  funext g
  induction g using (measure (fun g : Fin s => (N.order.symm g).val)).wf.induction with
  | h g ih =>
    rw [ha g, hb g]
    congr 1
    · cases hw : N.left g with
      | inl x => rfl
      | inr j =>
        change a j = b j
        apply ih j
        exact N.order_precedes j g (Or.inl hw)
    · cases hw : N.right g with
      | inl x => rfl
      | inr j =>
        change a j = b j
        apply ih j
        exact N.order_precedes j g (Or.inr hw)

/-- The compiled wire values are a solution of the independent graph equations. -/
theorem AcyclicNetwork.gateValues_consistent {n s : Nat} (N : AcyclicNetwork n s)
    (v : Fin n → Bool) : N.GateConsistent v (N.gateValues v) := by
  intro g
  simpa [AcyclicNetwork.sourceValue,AcyclicNetwork.wireValue] using N.gateValues_equations v g

/-- The designated graph output evaluated with the computed gate values. -/
noncomputable def AcyclicNetwork.graphEval {n s : Nat} (N : AcyclicNetwork n s)
    (v : Fin n → Bool) : Bool := N.sourceValue v N.output

/-- The graph output is independent of the topological ordering: any solution
of the original gate equations yields the same output. -/
theorem AcyclicNetwork.graphEval_eq_of_consistent {n s : Nat} (N : AcyclicNetwork n s)
    (v : Fin n → Bool) (gates : Fin s → Bool) (h : N.GateConsistent v gates) :
    N.graphEval v = AcyclicNetwork.wireValue v gates N.output := by
  have he := N.consistent_unique v (N.gateValues v) gates (N.gateValues_consistent v) h
  unfold graphEval sourceValue wireValue
  cases N.output <;> simp_all

/-- Compiling the network preserves its graph output value. -/
theorem AcyclicNetwork.compiled_eval {n s : Nat} (N : AcyclicNetwork n s)
    (v : Fin n → Bool) : N.toOrdered.toCircuit.eval v = N.graphEval v := by
  rw [N.toOrdered.toCircuit_eval, N.toOrdered.eval_eq_values]
  unfold graphEval
  cases h : N.output with
  | inl x =>
    simp only [sourceValue]
    have he : N.toOrdered.output.val = x.val := by
      unfold AcyclicNetwork.toOrdered
      dsimp
      split <;> simp_all
    convert N.toOrdered.values_input v x using 1; congr 1
    exact Fin.ext he
  | inr g =>
    simp only [sourceValue, gateValues]
    have he : N.toOrdered.output.val = n + (N.order.symm g).val := by
      unfold AcyclicNetwork.toOrdered
      dsimp
      split <;> simp_all
    congr 1
    exact Fin.ext he

/-- The leading bound for a finite acyclic graph, with evaluation defined by
the original gate equations and designated output. -/
theorem seventeen_sevenths_epsilon_acyclic_network (ε : ℝ) (hε : 0 < ε) :
    ∃ w₀ : Nat, ∀ w ≥ w₀, ∀ s : Nat, ∀ N : AcyclicNetwork (inputBits w) s,
      (∀ v, N.graphEval v = satFunction w v) →
      ((17 / 7 : ℝ) - ε) * inputBits w ≤ (s : ℝ) := by
  obtain ⟨w₀,hw₀⟩ := seventeen_sevenths_epsilon ε hε
  refine ⟨w₀, ?_⟩
  intro w hw s N hN
  have hc : N.toOrdered.toCircuit.Computes (satFunction w) := by
    intro v
    rw [N.compiled_eval]
    exact hN v
  simpa [N.compiled_size] using hw₀ w hw N.toOrdered.toCircuit hc

/-- The main bound stated using only the original acyclic graph equations,
without mentioning a topological order in the computation hypothesis. -/
theorem seventeen_sevenths_epsilon_graph_equations (ε : ℝ) (hε : 0 < ε) :
    ∃ w₀ : Nat, ∀ w ≥ w₀, ∀ s : Nat, ∀ N : AcyclicNetwork (inputBits w) s,
      (∀ v, ∃ gates, N.GateConsistent v gates ∧
        AcyclicNetwork.wireValue v gates N.output = satFunction w v) →
      ((17 / 7 : ℝ) - ε) * inputBits w ≤ (s : ℝ) := by
  obtain ⟨w₀,hw₀⟩ := seventeen_sevenths_epsilon_acyclic_network ε hε
  refine ⟨w₀, ?_⟩
  intro w hw s N hN
  apply hw₀ w hw s N
  intro v
  obtain ⟨gates,hg,hout⟩ := hN v
  exact (N.graphEval_eq_of_consistent v gates hg).trans hout

end SatLowerBound
