import Credit.TwoLevel.NormalizeTriangle

/-! Connect the fourteen-unit elimination to potential-preserving normalization. -/
namespace SatLowerBound
namespace MAContext
open OpenCircuit

theorem pruning_branch_main_drop_proper {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (hS4 : S4Essential f) {t : Table} {i j : Fin n}
    {rest : OpenCircuit (n+1)} (hC : C = .gate t i j rest) (hnl : t.nonlinear = true)
    (hno : ∀ x, (x = i ∨ x = j) → ∀ b,
      ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2)) :
    ∃ (b : Bool) (D : OpenCircuit n), (∀ v, D.eval v = f (fixBit i b v)) ∧
      D.psi2 + 14 ≤ C.psi2 ∧ D.GateProper ∧
      (∀ z : Fin n, 0 < D.usage (singleUse z) → Essential D.eval z) := by
  obtain ⟨U,V,R,b,hUi,hVj,hR,hUR,hVU,hUc,hUpar,hRpar,hTa,hUa,hRa,hVk,
    k₀,g₀,a₀,d₀,hg₀,hdead₀⟩ :=
    h.no_drop_forces_dead_gate_after_three_eliminations hS4 hC hnl hno
  have hT : C.gateAt n = some (t,i.val,j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hij : i ≠ j := fun he => (h.gate_facts hT).2.1 (congrArg Fin.val he)
  have hTi : n ∈ C.users i.val := C.mem_users.mpr ⟨t,i.val,j.val,hT,Or.inl rfl⟩
  have hU : U ∈ C.users i.val := by rw [hUi]; simp
  have hV : V ∈ C.users j.val := by rw [hVj]; simp
  have hRT : R ∈ C.users n := by rw [hR]; simp
  have hRU : R ∈ C.users U := by rw [hUR]; simp
  have hUV : U ∈ C.users V := by rw [hVU]; simp
  obtain ⟨gV,aV,dV,hgV,_⟩ := C.mem_users.mp hV
  obtain ⟨gU,aU,dU,hgU,habU⟩ := C.mem_users.mp hUV
  obtain ⟨gR,aR,dR,hgR,habR⟩ := C.mem_users.mp hRU
  have hVUgt : V < U := by have hb := C.gateAt_bounds hgU; rcases habU with he | he <;> omega
  have hURgt : U < R := by have hb := C.gateAt_bounds hgR; rcases habR with he | he <;> omega
  have hVge := (C.gateAt_bounds hgV).1
  have hUn : n ≠ U := by omega
  have hRn : n ≠ R := by omega
  have hURne : U ≠ R := by omega
  have hTpar : (C.tableAt n).parity = false := by
    have ht : t.parity = false := by
      unfold Table.nonlinear at hnl
      cases hp : t.parity <;> simp [hp] at hnl ⊢
    simp [tableAt,hT,ht]
  let E : Finset Nat := {n,U,R}
  have hEcard : E.card = 3 := by simp [E,hUn,hRn,hURne]
  have hE : ∀ k ∈ E, C.isAliased (singleRes i b) k = true ∧
      (C.tableAt k).parity = false ∧
      (k ∈ C.users i.val ∨ ∃ P g a d, C.gateAt P = some (g,a,d) ∧
        a < n ∧ d < n ∧ k ∈ C.users P) := by
    intro k hk
    simp only [E,Finset.mem_insert,Finset.mem_singleton] at hk
    rcases hk with he | he | he
    · rw [he]; exact ⟨hTa,hTpar,Or.inl hTi⟩
    · rw [he]; exact ⟨hUa,hUpar,Or.inl hU⟩
    · rw [he]; exact ⟨hRa,hRpar,Or.inr ⟨n,t,i.val,j.val,hT,i.isLt,j.isLt,hRT⟩⟩
  have hsub : E ⊆ Finset.range (n + C.size) := by
    intro k hk
    have ha := (hE k hk).1
    cases hg : C.gateAt k with
    | none => simp [OpenCircuit.isAliased,hg] at ha
    | some p =>
      obtain ⟨g,a,d⟩ := p
      exact Finset.mem_range.mpr (C.gateAt_bounds hg).2.1
  have hcount := C.aliasedCount_ge_card (singleRes i b) E hsub (fun k hk => (hE k hk).1)
  rw [hEcard] at hcount
  have hi2 := (h.degrees_of_nonlinear hC hnl).1
  have hraw := h.twoLevel_single_drop_with_primary_successors i b hi2 E hE
  rw [hEcard] at hraw
  have hraw12 : (C.restrict (singleSubst i b)).psi2 + 12 ≤ C.psi2 := by omega
  obtain ⟨k,g,a,d,hg,hdead,heval,hprune⟩ := h.cofactor_dead_reader_pruning_drop hS4
    i j hij b V U gV aV dV hgV hV hVk hVU hUc
  have hess := (C.restrict (singleSubst i b)).essentialGates_gate
    (C.restrict_essential (singleSubst i b)) hg
  have hw : 4 ≤ g.psi2W := by
    revert hess
    rcases g with ⟨a,b,c,d⟩
    cases a <;> cases b <;> cases c <;> cases d <;> decide
  let R := C.restrict (singleSubst i b)
  let D := R.deleteDead k
  have hp : R.GateProper := C.restrict_gateProper (singleSubst i b)
  have he : ∀ v, D.eval v = f (fixBit i b v) := by
    intro v
    rw [show D = (C.restrict (singleSubst i b)).deleteDead k from rfl,
      heval,restrict_single_eval,h.computes]
  have husedD : ∀ z : Fin n, 0 < D.usage (singleUse z) → Essential D.eval z := by
    intro z hz
    have hkge := (R.gateAt_bounds hg).1
    have hle := R.deleteDead_refCount_before_le hp k g a d hg hdead z.val (by have := z.isLt; omega)
    change D.refCount z.val ≤ R.refCount z.val at hle
    have hzR : 0 < R.usage (singleUse z) := by
      rw [D.usage_singleUse] at hz
      rw [R.usage_singleUse]
      omega
    have hessF := h.cofactor_used_essential hS4 i j hij b z hzR
    obtain ⟨v,w,hvw,hne⟩ := hessF
    exact ⟨v,w,hvw,by simpa only [he] using hne⟩
  refine ⟨b,D,he,?_,R.deleteDead_preserves_proper hp k,husedD⟩
  change D.psi2 + (g.psi2W : Int) ≤ R.psi2 at hprune
  change R.psi2 + 12 ≤ C.psi2 at hraw12
  omega



theorem pruning_branch_main_drop_proper_support {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (hS4 : S4Essential f) {t : Table} {i j : Fin n}
    {rest : OpenCircuit (n+1)} (hC : C = .gate t i j rest) (hnl : t.nonlinear = true)
    (hno : ∀ x, (x = i ∨ x = j) → ∀ b,
      ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2)) :
    ∃ (b : Bool) (D : OpenCircuit n), (∀ v, D.eval v = f (fixBit i b v)) ∧
      D.psi2 + 14 ≤ C.psi2 ∧ D.GateProper ∧
      (∀ z : Fin n, 0 < D.usage (singleUse z) → Essential D.eval z) ∧
      (∀ z : Fin n, 0 < D.usage (singleUse z) → 0 < C.usage (singleUse z) ∧ z ≠ i) := by
  obtain ⟨U,V,R,b,hUi,hVj,hR,hUR,hVU,hUc,hUpar,hRpar,hTa,hUa,hRa,hVk,
    k₀,g₀,a₀,d₀,hg₀,hdead₀⟩ :=
    h.no_drop_forces_dead_gate_after_three_eliminations hS4 hC hnl hno
  have hT : C.gateAt n = some (t,i.val,j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hij : i ≠ j := fun he => (h.gate_facts hT).2.1 (congrArg Fin.val he)
  have hTi : n ∈ C.users i.val := C.mem_users.mpr ⟨t,i.val,j.val,hT,Or.inl rfl⟩
  have hU : U ∈ C.users i.val := by rw [hUi]; simp
  have hV : V ∈ C.users j.val := by rw [hVj]; simp
  have hRT : R ∈ C.users n := by rw [hR]; simp
  have hRU : R ∈ C.users U := by rw [hUR]; simp
  have hUV : U ∈ C.users V := by rw [hVU]; simp
  obtain ⟨gV,aV,dV,hgV,_⟩ := C.mem_users.mp hV
  obtain ⟨gU,aU,dU,hgU,habU⟩ := C.mem_users.mp hUV
  obtain ⟨gR,aR,dR,hgR,habR⟩ := C.mem_users.mp hRU
  have hVUgt : V < U := by have hb := C.gateAt_bounds hgU; rcases habU with he | he <;> omega
  have hURgt : U < R := by have hb := C.gateAt_bounds hgR; rcases habR with he | he <;> omega
  have hVge := (C.gateAt_bounds hgV).1
  have hUn : n ≠ U := by omega
  have hRn : n ≠ R := by omega
  have hURne : U ≠ R := by omega
  have hTpar : (C.tableAt n).parity = false := by
    have ht : t.parity = false := by
      unfold Table.nonlinear at hnl
      cases hp : t.parity <;> simp [hp] at hnl ⊢
    simp [tableAt,hT,ht]
  let E : Finset Nat := {n,U,R}
  have hEcard : E.card = 3 := by simp [E,hUn,hRn,hURne]
  have hE : ∀ k ∈ E, C.isAliased (singleRes i b) k = true ∧
      (C.tableAt k).parity = false ∧
      (k ∈ C.users i.val ∨ ∃ P g a d, C.gateAt P = some (g,a,d) ∧
        a < n ∧ d < n ∧ k ∈ C.users P) := by
    intro k hk
    simp only [E,Finset.mem_insert,Finset.mem_singleton] at hk
    rcases hk with he | he | he
    · rw [he]; exact ⟨hTa,hTpar,Or.inl hTi⟩
    · rw [he]; exact ⟨hUa,hUpar,Or.inl hU⟩
    · rw [he]; exact ⟨hRa,hRpar,Or.inr ⟨n,t,i.val,j.val,hT,i.isLt,j.isLt,hRT⟩⟩
  have hsub : E ⊆ Finset.range (n + C.size) := by
    intro k hk
    have ha := (hE k hk).1
    cases hg : C.gateAt k with
    | none => simp [OpenCircuit.isAliased,hg] at ha
    | some p =>
      obtain ⟨g,a,d⟩ := p
      exact Finset.mem_range.mpr (C.gateAt_bounds hg).2.1
  have hcount := C.aliasedCount_ge_card (singleRes i b) E hsub (fun k hk => (hE k hk).1)
  rw [hEcard] at hcount
  have hi2 := (h.degrees_of_nonlinear hC hnl).1
  have hraw := h.twoLevel_single_drop_with_primary_successors i b hi2 E hE
  rw [hEcard] at hraw
  have hraw12 : (C.restrict (singleSubst i b)).psi2 + 12 ≤ C.psi2 := by omega
  obtain ⟨k,g,a,d,hg,hdead,heval,hprune⟩ := h.cofactor_dead_reader_pruning_drop hS4
    i j hij b V U gV aV dV hgV hV hVk hVU hUc
  have hess := (C.restrict (singleSubst i b)).essentialGates_gate
    (C.restrict_essential (singleSubst i b)) hg
  have hw : 4 ≤ g.psi2W := by
    revert hess
    rcases g with ⟨a,b,c,d⟩
    cases a <;> cases b <;> cases c <;> cases d <;> decide
  let R := C.restrict (singleSubst i b)
  let D := R.deleteDead k
  have hp : R.GateProper := C.restrict_gateProper (singleSubst i b)
  have he : ∀ v, D.eval v = f (fixBit i b v) := by
    intro v
    rw [show D = (C.restrict (singleSubst i b)).deleteDead k from rfl,
      heval,restrict_single_eval,h.computes]
  have husedD : ∀ z : Fin n, 0 < D.usage (singleUse z) → Essential D.eval z := by
    intro z hz
    have hkge := (R.gateAt_bounds hg).1
    have hle := R.deleteDead_refCount_before_le hp k g a d hg hdead z.val (by have := z.isLt; omega)
    change D.refCount z.val ≤ R.refCount z.val at hle
    have hzR : 0 < R.usage (singleUse z) := by
      rw [D.usage_singleUse] at hz
      rw [R.usage_singleUse]
      omega
    have hessF := h.cofactor_used_essential hS4 i j hij b z hzR
    obtain ⟨v,w,hvw,hne⟩ := hessF
    exact ⟨v,w,hvw,by simpa only [he] using hne⟩
  have hsupport : ∀ z : Fin n, 0 < D.usage (singleUse z) → 0 < C.usage (singleUse z) ∧ z ≠ i := by
    intro z hz
    have hkge := (R.gateAt_bounds hg).1
    have hle := R.deleteDead_refCount_before_le hp k g a d hg hdead z.val (by have := z.isLt; omega)
    change D.refCount z.val ≤ R.refCount z.val at hle
    have hzR : 0 < R.usage (singleUse z) := by
      rw [D.usage_singleUse] at hz
      rw [R.usage_singleUse]
      omega
    constructor
    · have hh := C.usage_pos_of_fix_usage_pos (fun w => decide (w = i)) (fun _ => b) z
      rw [← singleSubst_eq_fixSubst] at hh
      exact hh hzR
    · intro heq
      subst z
      have hh := C.fixed_input_unused_after_restriction i b
      change R.usage (singleUse i) = 0 at hh
      omega
  refine ⟨b,D,he,?_,R.deleteDead_preserves_proper hp k,husedD,hsupport⟩
  change D.psi2 + (g.psi2W : Int) ≤ R.psi2 at hprune
  change R.psi2 + 12 ≤ C.psi2 at hraw12
  omega


/-- A one-bit cofactor cannot introduce a primary input or retain the fixed coordinate. -/
theorem cofactor_usage_support {n : Nat} (C : OpenCircuit n) (x : Fin n) (b : Bool)
    (z : Fin n) (hz : 0 < (C.restrict (singleSubst x b)).usage (singleUse z)) :
    0 < C.usage (singleUse z) ∧ z ≠ x := by
  constructor
  · have hh := C.usage_pos_of_fix_usage_pos (fun w => decide (w = x)) (fun _ => b) z
    rw [← singleSubst_eq_fixSubst] at hh
    exact hh hz
  · intro he
    subst z
    have hh := C.fixed_input_unused_after_restriction x b
    omega

/-- The raw cofactor has proper gates and uses only essential coordinates. -/
theorem cofactor_proper_used {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (hS4 : S4Essential f) (hn : 2 ≤ n)
    (x : Fin n) (b : Bool) :
    (C.restrict (singleSubst x b)).GateProper ∧
      (∀ z : Fin n, 0 < (C.restrict (singleSubst x b)).usage (singleUse z) →
        Essential (C.restrict (singleSubst x b)).eval z) := by
  refine ⟨C.restrict_gateProper _,?_⟩
  have hall : 1 < (Finset.univ : Finset (Fin n)).card := by simp; omega
  obtain ⟨y,_,hyx⟩ := Finset.exists_mem_ne hall x
  intro z hz
  have hess := h.cofactor_used_essential hS4 x y (Ne.symm hyx) b z hz
  have heval : (C.restrict (singleSubst x b)).eval = fun v => f (fixBit x b v) := by
    funext v
    rw [restrict_single_eval,h.computes]
  rwa [heval]

theorem main_lemma_B_proper {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (hS4 : S4Essential f) :
    ∃ (x : Fin n) (b : Bool) (D : OpenCircuit n),
      2 ≤ C.refCount x.val ∧ Essential f x ∧
      (∀ v, D.eval v = f (fixBit x b v)) ∧ D.psi2 + 14 ≤ C.psi2 ∧
      D.GateProper ∧ (∀ z : Fin n, 0 < D.usage (singleUse z) → Essential D.eval z) := by
  obtain ⟨t,i,j,rest,hC⟩ := h.exists_first_gate
  have hr := h.reduced
  rw [hC] at hr
  have hij : i ≠ j := hr.2.1
  have hn2 : 2 ≤ n := by
    have hne : i.val ≠ j.val := fun he => hij (Fin.ext he)
    have := i.isLt
    have := j.isLt
    omega
  have hte : t.essential = true := hr.1
  have hiu : 0 < C.usage (singleUse i) := by
    rw [C.usage_singleUse,hC]
    simp only [refCount,↓reduceIte]
    omega
  have hju : 0 < C.usage (singleUse j) := by
    rw [C.usage_singleUse,hC]
    simp only [refCount,↓reduceIte]
    omega
  have hie := h.usedEssential i hiu
  have hje := h.usedEssential j hju
  rcases t.essential_parity_or_nonlinear hte with hpar | hnl
  · have hfun : (OpenCircuit.gate t i j rest).eval = f := by
      rw [← hC]
      exact funext h.computes
    have hsep : PairSeparated (OpenCircuit.gate t i j rest).eval i j := by
      rw [hfun]
      exact h.good.s3 i j hij hie hje
    rcases OpenCircuit.first_gate_multiple_use t i j rest hij hsep with hu | hu
    · have h2 : 2 ≤ C.refCount i.val := by rw [← C.usage_singleUse,hC]; exact hu
      obtain ⟨b,hb⟩ := h.case_parity_first hC hpar i (Or.inl rfl) h2
      refine ⟨i,b,C.restrict (singleSubst i b),h2,hie,?_,hb,(h.cofactor_proper_used hS4 hn2 i b).1,(h.cofactor_proper_used hS4 hn2 i b).2⟩
      intro v
      rw [restrict_single_eval,h.computes]
    · have h2 : 2 ≤ C.refCount j.val := by rw [← C.usage_singleUse,hC]; exact hu
      obtain ⟨b,hb⟩ := h.case_parity_first hC hpar j (Or.inr rfl) h2
      refine ⟨j,b,C.restrict (singleSubst j b),h2,hje,?_,hb,(h.cofactor_proper_used hS4 hn2 j b).1,(h.cofactor_proper_used hS4 hn2 j b).2⟩
      intro v
      rw [restrict_single_eval,h.computes]
  · have hdegrees := h.degrees_of_nonlinear hC hnl
    by_cases hraw : ∃ x, (x = i ∨ x = j) ∧ ∃ b,
        (C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2
    · obtain ⟨x,hx,b,hb⟩ := hraw
      have hx2 : 2 ≤ C.refCount x.val := by
        rcases hx with rfl | rfl
        · exact hdegrees.1
        · exact hdegrees.2
      have hxe : Essential f x := by rcases hx with rfl | rfl <;> assumption
      refine ⟨x,b,C.restrict (singleSubst x b),hx2,hxe,?_,hb,(h.cofactor_proper_used hS4 hn2 x b).1,(h.cofactor_proper_used hS4 hn2 x b).2⟩
      intro v
      rw [restrict_single_eval,h.computes]
    · have hno : ∀ x, (x = i ∨ x = j) → ∀ b,
          ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2) := by
        intro x hx b hb
        exact hraw ⟨x,hx,b,hb⟩
      obtain ⟨b,D,hD,hdrop,hp,hu⟩ := h.pruning_branch_main_drop_proper hS4 hC hnl hno
      exact ⟨i,b,D,hdegrees.1,hie,hD,hdrop,hp,hu⟩



theorem main_lemma_B_proper_support {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (hS4 : S4Essential f) :
    ∃ (x : Fin n) (b : Bool) (D : OpenCircuit n),
      2 ≤ C.refCount x.val ∧ Essential f x ∧
      (∀ v, D.eval v = f (fixBit x b v)) ∧ D.psi2 + 14 ≤ C.psi2 ∧
      D.GateProper ∧ (∀ z : Fin n, 0 < D.usage (singleUse z) → Essential D.eval z) ∧
      (∀ z : Fin n, 0 < D.usage (singleUse z) → 0 < C.usage (singleUse z) ∧ z ≠ x) := by
  obtain ⟨t,i,j,rest,hC⟩ := h.exists_first_gate
  have hr := h.reduced
  rw [hC] at hr
  have hij : i ≠ j := hr.2.1
  have hn2 : 2 ≤ n := by
    have hne : i.val ≠ j.val := fun he => hij (Fin.ext he)
    have := i.isLt
    have := j.isLt
    omega
  have hte : t.essential = true := hr.1
  have hiu : 0 < C.usage (singleUse i) := by
    rw [C.usage_singleUse,hC]
    simp only [refCount,↓reduceIte]
    omega
  have hju : 0 < C.usage (singleUse j) := by
    rw [C.usage_singleUse,hC]
    simp only [refCount,↓reduceIte]
    omega
  have hie := h.usedEssential i hiu
  have hje := h.usedEssential j hju
  rcases t.essential_parity_or_nonlinear hte with hpar | hnl
  · have hfun : (OpenCircuit.gate t i j rest).eval = f := by
      rw [← hC]
      exact funext h.computes
    have hsep : PairSeparated (OpenCircuit.gate t i j rest).eval i j := by
      rw [hfun]
      exact h.good.s3 i j hij hie hje
    rcases OpenCircuit.first_gate_multiple_use t i j rest hij hsep with hu | hu
    · have h2 : 2 ≤ C.refCount i.val := by rw [← C.usage_singleUse,hC]; exact hu
      obtain ⟨b,hb⟩ := h.case_parity_first hC hpar i (Or.inl rfl) h2
      refine ⟨i,b,C.restrict (singleSubst i b),h2,hie,?_,hb,(h.cofactor_proper_used hS4 hn2 i b).1,(h.cofactor_proper_used hS4 hn2 i b).2,cofactor_usage_support C i b⟩
      intro v
      rw [restrict_single_eval,h.computes]
    · have h2 : 2 ≤ C.refCount j.val := by rw [← C.usage_singleUse,hC]; exact hu
      obtain ⟨b,hb⟩ := h.case_parity_first hC hpar j (Or.inr rfl) h2
      refine ⟨j,b,C.restrict (singleSubst j b),h2,hje,?_,hb,(h.cofactor_proper_used hS4 hn2 j b).1,(h.cofactor_proper_used hS4 hn2 j b).2,cofactor_usage_support C j b⟩
      intro v
      rw [restrict_single_eval,h.computes]
  · have hdegrees := h.degrees_of_nonlinear hC hnl
    by_cases hraw : ∃ x, (x = i ∨ x = j) ∧ ∃ b,
        (C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2
    · obtain ⟨x,hx,b,hb⟩ := hraw
      have hx2 : 2 ≤ C.refCount x.val := by
        rcases hx with rfl | rfl
        · exact hdegrees.1
        · exact hdegrees.2
      have hxe : Essential f x := by rcases hx with rfl | rfl <;> assumption
      refine ⟨x,b,C.restrict (singleSubst x b),hx2,hxe,?_,hb,(h.cofactor_proper_used hS4 hn2 x b).1,(h.cofactor_proper_used hS4 hn2 x b).2,cofactor_usage_support C x b⟩
      intro v
      rw [restrict_single_eval,h.computes]
    · have hno : ∀ x, (x = i ∨ x = j) → ∀ b,
          ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2) := by
        intro x hx b hb
        exact hraw ⟨x,hx,b,hb⟩
      obtain ⟨b,D,hD,hdrop,hp,hu,hs⟩ := h.pruning_branch_main_drop_proper_support hS4 hC hnl hno
      exact ⟨i,b,D,hdegrees.1,hie,hD,hdrop,hp,hu,hs⟩


/-- Manuscript Lemma 7.1 with an explicitly normalized cofactor circuit. -/
theorem main_lemma_B_normalized {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (hS4 : S4Essential f) :
    ∃ (x : Fin n) (b : Bool) (D : OpenCircuit n),
      2 ≤ C.refCount x.val ∧ Essential f x ∧ D.Reduced ∧
      D.NoInputTriangles (fun _ => none) ∧
      (∀ v, D.eval v = f (fixBit x b v)) ∧ D.psi2 + 14 ≤ C.psi2 := by
  obtain ⟨x,y,hxy,_,_⟩ := h.good.two_essential
  have hn : 2 ≤ n := by
    have hne : x.val ≠ y.val := fun he => hxy (Fin.ext he)
    have := x.isLt
    have := y.isLt
    omega
  obtain ⟨z,b,R,hz,hze,hRe,hRp,hRproper,hRused⟩ := h.main_lemma_B_proper hS4
  have hE : E1 (fun v => f (fixBit z b v)) := h.good.e2.single_cofactor_e1 z b
  have heq : R.eval = fun v => f (fixBit z b v) := funext hRe
  have hER : E1 R.eval := by rw [heq]; exact hE
  obtain ⟨D,hD,htri,hDe,hDp,_⟩ := R.psi2_normalize_proper hn hRproper hER hRused
  exact ⟨z,b,D,hz,hze,hD,htri,fun v => (hDe v).trans (hRe v),by omega⟩


/-- The normalized cofactor uses only previous inputs and excludes the fixed bit. -/
theorem main_lemma_B_normalized_support {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (hS4 : S4Essential f) :
    ∃ (x : Fin n) (b : Bool) (D : OpenCircuit n),
      2 ≤ C.refCount x.val ∧ Essential f x ∧ D.Reduced ∧
      D.NoInputTriangles (fun _ => none) ∧
      (∀ v, D.eval v = f (fixBit x b v)) ∧ D.psi2 + 14 ≤ C.psi2 ∧
      (∀ z : Fin n, 0 < D.usage (singleUse z) → 0 < C.usage (singleUse z) ∧ z ≠ x) := by
  obtain ⟨x,y,hxy,_,_⟩ := h.good.two_essential
  have hn : 2 ≤ n := by
    have hne : x.val ≠ y.val := fun he => hxy (Fin.ext he)
    have := x.isLt
    have := y.isLt
    omega
  obtain ⟨z,b,R,hz,hze,hRe,hRp,hRproper,hRused,hRsupport⟩ := h.main_lemma_B_proper_support hS4
  have hE : E1 (fun v => f (fixBit z b v)) := h.good.e2.single_cofactor_e1 z b
  have heq : R.eval = fun v => f (fixBit z b v) := funext hRe
  have hER : E1 R.eval := by rw [heq]; exact hE
  obtain ⟨D,hD,htri,hDe,hDp,_,hDsupport⟩ := R.psi2_normalize_proper_support hn hRproper hER hRused
  exact ⟨z,b,D,hz,hze,hD,htri,fun v => (hDe v).trans (hRe v),by omega,
    fun w hw => hRsupport w (hDsupport w hw)⟩

end MAContext
end SatLowerBound
