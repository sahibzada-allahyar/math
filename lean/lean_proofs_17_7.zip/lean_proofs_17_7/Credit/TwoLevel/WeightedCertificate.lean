import Credit.TwoLevel.WeightedParameters
import Credit.TwoLevel.WidthBound

/-! Instantiating the finite 3-SAT certificate with the paper's weighted block. -/
namespace SatLowerBound

/-- The paper's weighted robustness threshold fits inside every block of size
at least sixteen. -/
theorem weightedThreshold_fits (r : Nat) (hr : 16 ≤ r) :
    weightedTriangleThreshold (weightedPrime r) + 4 ≤ r := by
  have hrR : (16 : ℝ) ≤ r := by exact_mod_cast hr
  have hs : Real.sqrt (8 * (r : ℝ)) ≤ ((r - 4 : Nat) : ℝ) := by
    apply Real.sqrt_le_iff.mpr
    have hcast : ((r - 4 : Nat) : ℝ) = (r : ℝ) - 4 := by
      rw [Nat.cast_sub (by omega : 4 ≤ r)]
      norm_num
    rw [hcast]
    constructor
    · linarith
    · nlinarith [sq_nonneg ((r : ℝ) - 16)]
  have hc : ⌈Real.sqrt (8 * (r : ℝ))⌉₊ ≤ r - 4 := Nat.ceil_le.mpr hs
  have ht := weightedTriangleThreshold_sqrt_bound r (by omega)
  omega

/-- With the manuscript's block size, least prime, and triangular threshold,
the explicit weighted restriction satisfies the finite 3-SAT bound, subject
to the cited subset-sum cardinality theorem. -/
theorem paper_weighted_finite_certificate_of_subsetSumBound (w : Nat) (hw : 32 ≤ w)
    (hbound : ∀ A : Finset (ZMod (weightedPrime (paperBlockSize w))),
      (∀ x ∈ A, -x ∉ A) →
      min (weightedPrime (paperBlockSize w)) (1 + A.card * (A.card + 1) / 2) ≤ A.subsetSum.card) :
    ∃ t : ZMod (weightedPrime (paperBlockSize w)), ∀ C : Circuit (inputBits w),
      C.Computes (satFunction w) →
      7 * (inputBits w : Int) +
        (30 * (paperBlockSize w : Int) -
          42 * ((weightedTriangleThreshold (weightedPrime (paperBlockSize w)) : Int) + 3)) *
          genericRemainingClauses w (canonicalForbiddenFamily
            (weightedModularBlock (paperBlockSize w) (weightedPrime (paperBlockSize w)) t)) - 3 ≤
        7 * (C.size : Int) := by
  obtain ⟨hr,hlt⟩ := paperBlockSize_bounds w hw
  obtain ⟨t,hrob,hfull⟩ := exists_paper_weighted_block_of_subsetSumBound
    (paperBlockSize w) (by omega) hbound
  refine ⟨t, fun C hc => ?_⟩
  have hfit := weightedThreshold_fits (paperBlockSize w) hr
  have h := sat_certificate_of_robust_block w (paperBlockSize w)
    (weightedTriangleThreshold (weightedPrime (paperBlockSize w)) + 2)
    (by omega) hlt (by omega) (by omega) _ hrob hfull C hc
  push_cast at h
  convert h using 1; ring

/-- Width-dependent weighted lower bound, with the only remaining mathematical
hypothesis being the cited subset-sum cardinality estimate. -/
theorem paper_weighted_width_bound_of_subsetSumBound (w : Nat) (hw : 32 ≤ w)
    (hbound : ∀ A : Finset (ZMod (weightedPrime (paperBlockSize w))),
      (∀ x ∈ A, -x ∉ A) →
      min (weightedPrime (paperBlockSize w)) (1 + A.card * (A.card + 1) / 2) ≤ A.subsetSum.card)
    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    17 * (inputBits w : Int) -
      (30 * (logarithmicOffset w : Int) +
       42 * (weightedTriangleThreshold (weightedPrime (paperBlockSize w)) : Int) + 216) *
        (variableCount w : Int) - 3 ≤ 7 * (C.size : Int) := by
  classical
  obtain ⟨t,hcert⟩ := paper_weighted_finite_certificate_of_subsetSumBound w hw hbound
  let g := weightedModularBlock (paperBlockSize w) (weightedPrime (paperBlockSize w)) t
  let r : Int := paperBlockSize w
  let k : Int := weightedTriangleThreshold (weightedPrime (paperBlockSize w))
  let l : Int := logarithmicOffset w
  let m : Int := variableCount w
  let b : Int := (canonicalForbiddenFamily g).count
  let M : Int := genericRemainingClauses w (canonicalForbiddenFamily g)
  let W : Int := w
  let N : Int := inputBits w
  have hrw := (paperBlockSize_bounds w hw).2
  have hrNat : paperBlockSize w + logarithmicOffset w + 1 = w := by
    have hl : logarithmicOffset w ≤ w - 17 := Nat.clog_le_of_le_pow (width_power_fit w hw)
    unfold paperBlockSize
    omega
  have hr : r + l + 1 = W := by dsimp [r,l,W]; exact_mod_cast hrNat
  have hR : r ≤ W := by dsimp [r,W]; exact_mod_cast hrw.le
  have hm : 0 ≤ m := by dsimp [m]; positivity
  have hb : 0 ≤ b := by dsimp [b]; positivity
  have hk : 0 ≤ k := by dsimp [k]; positivity
  have hbudget : W * b ≤ m := by
    dsimp [W,b,m]
    exact_mod_cast paperBlockSize_forbidden_budget w hw g
  have hfit : (canonicalForbiddenFamily g).count ≤ variableCount w :=
    (genericRemaining_pos_of_count w (paperBlockSize w) hrw
      (by have := (paperBlockSize_bounds w hw).1; omega)
      (canonicalForbiddenFamily g) (canonical_forbidden_count_le g)).1
  have hremain : M + b = m := by
    dsimp [M,b,m,genericRemainingClauses]
    exact_mod_cast Nat.sub_add_cancel hfit
  have hn : N = 3 * m * (W + 1) := by dsimp [N,m,W,inputBits]
  have hc' : 7*N + (30*r-42*(k+3))*M - 3 ≤ 7*(C.size : Int) := by
    simpa [N,r,k,M,g] using hcert C hc
  have ha' : 30*r-42*(k+3) ≤ 30*W := by omega
  have hmul2 := mul_le_mul_of_nonneg_right ha' hb
  have hmul3 := mul_le_mul_of_nonneg_left hbudget (show (0 : Int) ≤ 30 by omega)
  change 17*N - (30*l+42*k+216)*m - 3 ≤ 7*(C.size : Int)
  nlinarith

/-- The weighted construction gives the paper's `n / sqrt(log n)` loss,
conditional on the cited subset-sum theorem. -/
theorem paper_weighted_log_bound_of_subsetSumBound (w : Nat) (hw : 32 ≤ w)
    (hbound : ∀ A : Finset (ZMod (weightedPrime (paperBlockSize w))),
      (∀ x ∈ A, -x ∉ A) →
      min (weightedPrime (paperBlockSize w)) (1 + A.card * (A.card + 1) / 2) ≤ A.subsetSum.card)
    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    (17 / 7 : ℝ) * inputBits w -
      50 * inputBits w / Real.sqrt (Real.logb 2 (inputBits w)) ≤ (C.size : ℝ) := by
  let W : ℝ := w
  let N : ℝ := inputBits w
  let M : ℝ := variableCount w
  let L : ℝ := logarithmicOffset w
  let K : ℝ := weightedTriangleThreshold (weightedPrime (paperBlockSize w))
  let Q : ℝ := Real.logb 2 (inputBits w)
  let S : ℝ := Real.sqrt W
  let T : ℝ := Real.sqrt Q
  have hW : 32 ≤ W := by dsimp [W]; exact_mod_cast hw
  have hS0 : 0 ≤ S := Real.sqrt_nonneg _
  have hS2 : S ^ 2 = W := Real.sq_sqrt (by linarith)
  have hS1 : 1 ≤ S := by nlinarith
  have hL0 : 0 ≤ L := by dsimp [L]; positivity
  have hLsq : L * L ≤ 4 * W := by
    dsimp [L,W]
    exact_mod_cast logarithmic_offset_square w (by omega)
  have hL : L ≤ 2 * S := by nlinarith
  have hR : (paperBlockSize w : ℝ) ≤ W := by
    dsimp [W]
    exact_mod_cast (paperBlockSize_bounds w hw).2.le
  have hKnat := weightedTriangleThreshold_sqrt_bound (paperBlockSize w) (by
    have := (paperBlockSize_bounds w hw).1; omega)
  have hKcast : K ≤ (⌈Real.sqrt (8 * (paperBlockSize w : ℝ))⌉₊ : ℝ) := by
    dsimp [K]
    exact_mod_cast hKnat
  have hceil := (Nat.ceil_lt_add_one (Real.sqrt_nonneg (8 * (paperBlockSize w : ℝ)))).le
  have hroot : Real.sqrt (8 * (paperBlockSize w : ℝ)) ≤ 3 * S := by
    apply Real.sqrt_le_iff.mpr
    constructor
    · positivity
    · nlinarith
  have hK : K ≤ 3 * S + 1 := by linarith
  have hcoeff : 30 * L + 42 * K + 219 ≤ 447 * S := by linarith
  have hq := PdfAsymptotics.q_comparison w (by omega)
  change W ≤ Q ∧ Q ≤ 3 * W at hq
  have hT0 : 0 ≤ T := Real.sqrt_nonneg _
  have hTpos : 0 < T := Real.sqrt_pos.mpr (by linarith [hq.1])
  have hT2 : T ^ 2 = Q := Real.sq_sqrt (by linarith [hq.1])
  have hT : T ≤ 2 * S := by nlinarith
  have hM0 : 0 ≤ M := by dsimp [M]; positivity
  have hM1 : 1 ≤ M := by
    dsimp [M,variableCount]
    have hp : 2 ≤ 2 ^ w := Nat.pow_le_pow_right (n := 2) (by decide) (by omega : 1 ≤ w)
    have hn : 1 ≤ 2 ^ w - 1 := by omega
    exact_mod_cast hn
  have hN : N = 3 * M * (W + 1) := by dsimp [N,M,W,inputBits]; push_cast; ring
  have hprod : M * S * T ≤ 2 * M * W := by
    have h := mul_le_mul_of_nonneg_left hT (show 0 ≤ M * S by positivity)
    nlinarith
  have hcoefM := mul_le_mul_of_nonneg_right hcoeff hM0
  have hcoefMT := mul_le_mul_of_nonneg_right hcoefM hT0
  have hbudget : (30 * L + 42 * K + 219) * M * T ≤ 350 * N := by nlinarith
  have hdiv := (le_div_iff₀ hTpos).mpr hbudget
  have hint : 17 * N - (30 * L + 42 * K + 216) * M - 3 ≤ 7 * (C.size : ℝ) := by
    dsimp [N,L,K,M]
    exact_mod_cast paper_weighted_width_bound_of_subsetSumBound w hw hbound C hc
  change (17 / 7 : ℝ) * N - 50 * N / T ≤ (C.size : ℝ)
  have hdiv' : (30 * L + 42 * K + 219) * M ≤ 7 * (50 * N / T) := by
    convert hdiv using 1; ring
  nlinarith only [hdiv',hint,hM1]

end SatLowerBound
