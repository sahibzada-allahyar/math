import Credit.TwoLevel.BalandraudProducts

namespace SatLowerBound

/-- Pairing the even and odd factors in a factorial. -/
theorem balandraud_factorial_even_odd (n : Nat) :
    ((2 * n).factorial : ℤ) = (2 : ℤ)^n * (n.factorial : ℤ) *
      (∏ j : Fin n, ((2 * j.val + 1 : Nat) : ℤ)) := by
  induction n with
  | zero => simp
  | succ n ih =>
    have he : 2 * (n + 1) = (2 * n + 1) + 1 := by omega
    rw [he, Nat.factorial_succ, Nat.factorial_succ, Nat.cast_mul, Nat.cast_mul, ih,
      Fin.prod_univ_castSucc, Nat.factorial_succ, Nat.cast_mul, pow_succ]
    simp only [Fin.val_castSucc, Fin.val_last, Nat.cast_add, Nat.cast_mul, Nat.cast_one,
      Nat.cast_ofNat]
    ring

/-- Splitting a factorial into its first and second halves. -/
theorem balandraud_factorial_halves (n : Nat) :
    ((2 * n).factorial : ℤ) = (n.factorial : ℤ) *
      (∏ i : Fin n, ((n + i.val + 1 : Nat) : ℤ)) := by
  have h := Finset.prod_range_add (fun i : Nat => (i + 1 : Nat)) n n
  rw [← Nat.factorial_eq_prod_range_add_one, ← Nat.factorial_eq_prod_range_add_one] at h
  have hh := congrArg (fun k : Nat => (k : ℤ)) h
  simp only [Nat.cast_mul, Nat.cast_prod] at hh
  have hf := Fin.prod_univ_eq_prod_range (fun i : Nat => ((n + i + 1 : Nat) : ℤ)) n
  rw [hf, two_mul]
  exact hh

/-- The product ratio in the determinant recurrence is exactly a power of two. -/
theorem balandraud_product_ratio (n : Nat) :
    (∏ i : Fin n, ((n + i.val + 1 : Nat) : ℤ)) =
      (2 : ℤ)^n * (∏ j : Fin n, ((2 * j.val + 1 : Nat) : ℤ)) := by
  have h₁ := balandraud_factorial_halves n
  have h₂ := balandraud_factorial_even_odd n
  have hn : (n.factorial : ℤ) ≠ 0 := by positivity
  apply mul_left_cancel₀ hn
  linear_combination h₂ - h₁

/-- The zero-cut determinant has the power-of-two value in the cited proof. -/
theorem balandraudDet_zero_closed (n : Nat) :
    balandraudDet n 0 = (2 : ℤ) ^ Nat.choose n 2 := by
  induction n with
  | zero => simp [balandraudDet]
  | succ n ih =>
    have h := balandraudDet_zero_dimension_recurrence n
    rw [balandraud_product_ratio, ih] at h
    have he : Nat.choose (n + 1) 2 = Nat.choose n 2 + n := by
      rw [Nat.choose_succ_succ]
      simp [Nat.add_comm]
    rw [he, pow_add]
    apply mul_left_cancel₀ (balandraud_odd_product_ne_zero n)
    linear_combination h

end SatLowerBound
