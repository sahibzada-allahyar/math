import SatLowerBound.SparseRestriction

/-! The paper's sparse-helper restriction for an arbitrary Boolean block. -/
namespace SatLowerBound

/-- An enumeration of the inputs on which the chosen block is false. -/
structure ForbiddenFamily (r : Nat) (g : (Fin r → Bool) → Bool) where
  count : Nat
  suffix : Fin count → Fin r → Bool
  spec : ∀ i, g (suffix i) = false
  complete : ∀ x, g x = false → ∃ i, suffix i = x

/-- The set of inputs on which a block is false. -/
noncomputable def forbiddenSet {r : Nat} (g : (Fin r → Bool) → Bool) : Finset (Fin r → Bool) :=
  Finset.univ.filter (fun x => g x = false)

/-- Enumerate every false input exactly once by a finite index. -/
noncomputable def canonicalForbiddenFamily {r : Nat} (g : (Fin r → Bool) → Bool) : ForbiddenFamily r g where
  count := (forbiddenSet g).card
  suffix i := ((forbiddenSet g).equivFin.symm i).val
  spec i := (Finset.mem_filter.mp ((forbiddenSet g).equivFin.symm i).property).2
  complete x hx := by
    have hm : x ∈ forbiddenSet g := Finset.mem_filter.mpr ⟨Finset.mem_univ x,hx⟩
    refine ⟨(forbiddenSet g).equivFin ⟨x,hm⟩,?_⟩
    exact congrArg Subtype.val ((forbiddenSet g).equivFin.symm_apply_apply ⟨x,hm⟩)

theorem canonical_forbidden_count_le {r : Nat} (g : (Fin r → Bool) → Bool) :
    (canonicalForbiddenFamily g).count ≤ 2^r := by
  have h := Finset.card_le_univ (forbiddenSet g)
  simpa [canonicalForbiddenFamily,Fintype.card_fun] using h

abbrev GenericSuffixAssignment (w : Nat) {r : Nat} {g : (Fin r → Bool) → Bool}
    (B : ForbiddenFamily r g) := Fin (variableCount w - B.count) → Fin 3 → Fin r → Bool

/-- Use one negative unit clause per forbidden suffix; remaining clauses
contain three positive, freely chosen suffixes. -/
def genericSparseFormula (w r : Nat) (hr : r < w) {g : (Fin r → Bool) → Bool}
    (B : ForbiddenFamily r g) (x : GenericSuffixAssignment w B) : Formula (variableCount w) :=
  fun c s => if h : c.val < B.count then
    ⟨suffixVariable w r hr (B.suffix ⟨c.val,h⟩),true⟩
  else ⟨suffixVariable w r hr (x ⟨c.val-B.count,by have := c.isLt; omega⟩ s),false⟩

def genericHelperClause (w : Nat) {r : Nat} {g : (Fin r → Bool) → Bool}
    (B : ForbiddenFamily r g) (hfit : B.count ≤ variableCount w) (i : Fin B.count) :
    Fin (variableCount w) := ⟨i.val,Nat.lt_of_lt_of_le i.isLt hfit⟩

def genericFreeClause (w : Nat) {r : Nat} {g : (Fin r → Bool) → Bool}
    (B : ForbiddenFamily r g) (j : Fin (variableCount w-B.count)) : Fin (variableCount w) :=
  ⟨B.count+j.val,by have := j.isLt; omega⟩

theorem genericSparseFormula_helper (w r : Nat) (hr : r < w) {g : (Fin r → Bool) → Bool}
    (B : ForbiddenFamily r g) (hfit : B.count ≤ variableCount w) (x : GenericSuffixAssignment w B)
    (i : Fin B.count) (s : Fin 3) :
    genericSparseFormula w r hr B x (genericHelperClause w B hfit i) s =
      ⟨suffixVariable w r hr (B.suffix i),true⟩ := by
  simp only [genericSparseFormula,genericHelperClause,i.isLt,↓reduceDIte]

theorem genericSparseFormula_free (w r : Nat) (hr : r < w) {g : (Fin r → Bool) → Bool}
    (B : ForbiddenFamily r g) (x : GenericSuffixAssignment w B)
    (j : Fin (variableCount w-B.count)) (s : Fin 3) :
    genericSparseFormula w r hr B x (genericFreeClause w B j) s =
      ⟨suffixVariable w r hr (x j s),false⟩ := by
  have h : ¬ B.count+j.val < B.count := by omega
  simp only [genericSparseFormula,genericFreeClause,h,↓reduceDIte,Nat.add_sub_cancel_left]

/-- The arbitrary-block version of the manuscript's sparse-helper equivalence. -/
theorem genericSparseFormula_sat_iff (w r : Nat) (hr : r < w)
    {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g)
    (hfit : B.count ≤ variableCount w) (x : GenericSuffixAssignment w B) :
    (genericSparseFormula w r hr B x).SAT ↔ ∀ j, ∃ s, g (x j s) = true := by
  classical
  constructor
  · rintro ⟨a,ha⟩
    have forced (i : Fin B.count) : a (suffixVariable w r hr (B.suffix i)) = false := by
      obtain ⟨s,hs⟩ := ha (genericHelperClause w B hfit i)
      rw [genericSparseFormula_helper] at hs
      simpa [Literal.eval] using hs
    intro j
    obtain ⟨s,hs⟩ := ha (genericFreeClause w B j)
    rw [genericSparseFormula_free] at hs
    change a (suffixVariable w r hr (x j s)) = true at hs
    refine ⟨s,?_⟩
    cases hg : g (x j s) with
    | true => rfl
    | false =>
      obtain ⟨i,hi⟩ := B.complete _ hg
      have hf := forced i
      rw [hi,hs] at hf
      contradiction
  · intro hx
    let a : Fin (variableCount w) → Bool := fun v =>
      decide (∀ i : Fin B.count, v ≠ suffixVariable w r hr (B.suffix i))
    refine ⟨a,?_⟩
    intro c
    by_cases hc : c.val < B.count
    · refine ⟨0,?_⟩
      simp only [genericSparseFormula,hc,↓reduceDIte,Literal.eval,↓reduceIte]
      have hf : a (suffixVariable w r hr (B.suffix ⟨c.val,hc⟩)) = false := by
        simp only [a,decide_eq_false_iff_not]
        intro hh
        exact hh ⟨c.val,hc⟩ rfl
      rw [hf]
      rfl
    · let j : Fin (variableCount w-B.count) := ⟨c.val-B.count,by have := c.isLt; omega⟩
      obtain ⟨s,hs⟩ := hx j
      refine ⟨s,?_⟩
      simp only [genericSparseFormula,hc,↓reduceDIte,Literal.eval,Bool.false_eq_true,↓reduceIte]
      change a (suffixVariable w r hr (x j s)) = true
      apply decide_eq_true_iff.mpr
      intro i he
      have hi := suffixVariable_injective w r hr _ _ he
      have hf := B.spec i
      rw [← hi] at hf
      rw [hs] at hf
      contradiction

abbrev genericRemainingClauses (w : Nat) {r : Nat} {g : (Fin r → Bool) → Bool}
    (B : ForbiddenFamily r g) : Nat := variableCount w - B.count

abbrev genericFreeBits (w : Nat) {r : Nat} {g : (Fin r → Bool) → Bool}
    (B : ForbiddenFamily r g) : Nat := genericRemainingClauses w B * 3 * r

def genericFreeBitIndex {w r : Nat} {g : (Fin r → Bool) → Bool} {B : ForbiddenFamily r g}
    (c : Fin (genericRemainingClauses w B)) (s : Fin 3) (b : Fin r) :
    Fin (genericFreeBits w B) := pairIndex (pairIndex c s) b

def genericSuffixAssignmentOf {w r : Nat} {g : (Fin r → Bool) → Bool} {B : ForbiddenFamily r g}
    (x : Fin (genericFreeBits w B) → Bool) : GenericSuffixAssignment w B :=
  fun c s b => x (genericFreeBitIndex c s b)

def genericSparseFieldSignal (w r : Nat) {g : (Fin r → Bool) → Bool}
    (B : ForbiddenFamily r g) (c : Fin (clauseCount w)) (s : Fin 3) (b : Fin (w+1)) :
    Signal (genericFreeBits w B) :=
  if hc : c.val < B.count then
    .constant (if hb : b.val < w then
      suffixIdentifierBits w r (B.suffix ⟨c.val,hc⟩) ⟨b.val,hb⟩ else true)
  else if hb : b.val < r then
    .wire (genericFreeBitIndex ⟨c.val-B.count,by
      have := c.isLt; change c.val < variableCount w at this
      unfold genericRemainingClauses; omega⟩ s ⟨b.val,hb⟩) false
  else .constant (decide (b.val+1 = w))

def genericSparseRestriction (w r : Nat) {g : (Fin r → Bool) → Bool}
    (B : ForbiddenFamily r g) : Fin (inputBits w) → Signal (genericFreeBits w B) :=
  packFields w (genericSparseFieldSignal w r B)

/-- The explicit wire/constant substitution encodes the generic sparse formula. -/
theorem genericSparseRestriction_correct (w r : Nat) (hr : r < w)
    {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g)
    (x : Fin (genericFreeBits w B) → Bool) :
    (fun i => (genericSparseRestriction w r B i).eval x) =
      encodeFormula w (genericSparseFormula w r hr B (genericSuffixAssignmentOf x)) := by
  funext i
  obtain ⟨c,s,b,rfl⟩ := coordinate_surjective w i
  simp only [genericSparseRestriction,packFields_coordinate,encodeFormula,encode_coordinate]
  by_cases hc : c.val < B.count
  · simp only [genericSparseFieldSignal,genericSparseFormula,hc,↓reduceDIte,Signal.eval,
      suffixVariable_digits]
  · simp only [genericSparseFieldSignal,genericSparseFormula,hc,↓reduceDIte]
    by_cases hb : b.val < r
    · have hbw : b.val < w := Nat.lt_trans hb hr
      simp only [hb,hbw,↓reduceDIte,suffixVariable_digits,suffixIdentifierBits,
        Signal.eval,Bool.xor_false,genericSuffixAssignmentOf]
    · simp only [hb,↓reduceDIte,Signal.eval]
      by_cases hbw : b.val < w
      · simp only [hbw,↓reduceDIte,suffixVariable_digits,suffixIdentifierBits,hb]
      · have hbw' : b.val = w := by have := b.isLt; omega
        simp only [hbw',Nat.lt_irrefl,↓reduceDIte,Nat.add_one_ne_self,decide_false]

noncomputable def genericSparseFunction (w : Nat) {r : Nat} {g : (Fin r → Bool) → Bool}
    (B : ForbiddenFamily r g) (x : Fin (genericFreeBits w B) → Bool) : Bool := by
  classical
  exact decide (∀ j : Fin (genericRemainingClauses w B), ∃ s : Fin 3,
    g (genericSuffixAssignmentOf x j s) = true)

theorem genericSparseRestriction_sat (w r : Nat) (hr : r < w)
    {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g) (hfit : B.count ≤ variableCount w)
    (x : Fin (genericFreeBits w B) → Bool) :
    satFunction w (fun i => (genericSparseRestriction w r B i).eval x) = genericSparseFunction w B x := by
  rw [genericSparseRestriction_correct w r hr B x]
  apply Bool.eq_iff_iff.mpr
  rw [encodeFormula_correct,genericSparseFormula_sat_iff w r hr B hfit]
  classical
  simp only [genericSparseFunction,decide_eq_true_eq]

end SatLowerBound
