import Credit.TwoLevel.FullDegreeCounting
import SatLowerBound.Logarithmic

/-! Explicit logarithmic threshold for the probabilistic block construction. -/
namespace SatLowerBound

/-- A logarithmic robustness threshold. The additive constant absorbs the
ordered-pair union bound used in `RobustCounting`. -/
def countingThreshold (r : Nat) : Nat := Nat.clog 2 r + 5

/-- The singly exponential event count is dominated by `2^(8r)`. -/
theorem collision_event_count_lt (r : Nat) (hr : 1 ≤ r) :
    2 * (3 ^ r * r * r * 6) < 2 ^ (8 * r) := by
  have h3 : 3 ^ r ≤ 2 ^ (2 * r) := by
    calc
      3 ^ r ≤ 4 ^ r := Nat.pow_le_pow_left (by decide : 3 ≤ 4) r
      _ = 2 ^ (2 * r) := by rw [pow_mul]; norm_num
  have hrpow : r ≤ 2 ^ r := (Nat.lt_two_pow_self (n := r)).le
  have hrr : r * r ≤ 2 ^ (2 * r) := by
    calc
      r * r ≤ 2 ^ r * 2 ^ r := Nat.mul_le_mul hrpow hrpow
      _ = 2 ^ (2 * r) := by rw [show 2 * r = r + r by omega, pow_add]
  have hm := Nat.mul_le_mul h3 hrr
  have he : 2 ^ (2 * r) * 2 ^ (2 * r) = 2 ^ (4 * r) := by
    rw [← pow_add]
    congr 1
    omega
  rw [he] at hm
  have hpos : 0 < 2 ^ (4 * r) := by positivity
  have hless : 12 * 2 ^ (4 * r) < 16 * 2 ^ (4 * r) := by nlinarith
  have hupper : 16 * 2 ^ (4 * r) ≤ 2 ^ (8 * r) := by
    calc
      16 * 2 ^ (4 * r) = 2 ^ (4 + 4 * r) := by rw [pow_add]; norm_num
      _ ≤ 2 ^ (8 * r) := Nat.pow_le_pow_right (by omega) (by omega)
  nlinarith

/-- The double exponential in the probability bound dominates `2^(8r)`. -/
theorem countingThreshold_power (r : Nat) : 8 * r ≤ 2 ^ (countingThreshold r - 2) := by
  have h := Nat.le_pow_clog (b := 2) (by decide) r
  unfold countingThreshold
  have he : Nat.clog 2 r + 5 - 2 = Nat.clog 2 r + 3 := by omega
  rw [he, Nat.pow_add]
  norm_num
  omega

theorem countingThreshold_condition (r : Nat) (hr : 1 ≤ r) :
    2 * (3 ^ r * r * r * 6) < 2 ^ (2 ^ (countingThreshold r - 2)) := by
  exact (collision_event_count_lt r hr).trans_le
    (Nat.pow_le_pow_right (by omega) (countingThreshold_power r))

/-- A robust full-degree block exists at a logarithmic threshold, once that
threshold fits the block, with no unproved counting hypothesis. -/
theorem exists_robust_fullDegree_logarithmic (r : Nat) (hr : 1 ≤ r)
    (hfit : countingThreshold r ≤ r + 2) :
    ∃ f : (Fin r → Bool) → Bool,
      Robust (countingThreshold r) f ∧ (BPoly.ofFunction r f).topCoefficient = true :=
  exists_robust_fullDegree r (countingThreshold r) hfit (countingThreshold_condition r hr)

/-- Elementary growth estimate used to fit the logarithmic threshold. -/
theorem power_fit (r : Nat) (hr : 16 ≤ r) : r ≤ 2 ^ (r - 7) := by
  induction r, hr using Nat.le_induction with
  | base => norm_num
  | succ r hr ih =>
    have he : r + 1 - 7 = (r - 7) + 1 := by omega
    rw [he, pow_succ]
    nlinarith

/-- The threshold leaves at least two additional coordinates for every block
of size at least sixteen. -/
theorem countingThreshold_fits (r : Nat) (hr : 16 ≤ r) :
    countingThreshold r + 2 ≤ r := by
  have hlog : Nat.clog 2 r ≤ r - 7 := Nat.clog_le_of_le_pow (power_fit r hr)
  unfold countingThreshold
  omega

/-- Every sufficiently large block admits the required logarithmically robust
full-degree function. -/
theorem exists_robust_fullDegree_large (r : Nat) (hr : 16 ≤ r) :
    ∃ f : (Fin r → Bool) → Bool,
      Robust (countingThreshold r) f ∧ (BPoly.ofFunction r f).topCoefficient = true :=
  exists_robust_fullDegree_logarithmic r (by omega) (by
    have h := countingThreshold_fits r hr
    omega)

/-- The finite 3-SAT certificate for a specific logarithmic threshold, with
all block-existence and counting hypotheses discharged. -/
theorem exists_sat_certificate_logarithmic (w r : Nat) (hw : 2 ≤ w)
    (hrw : r < w) (hr : 16 ≤ r) :
    ∃ g : (Fin r → Bool) → Bool, ∀ (C : Circuit (inputBits w)),
      C.Computes (satFunction w) →
      7 * (inputBits w : Int) +
        (30*(r : Int)-42*((countingThreshold r : Int)+1)) *
        genericRemainingClauses w (canonicalForbiddenFamily g) - 3 ≤ 7 * (C.size : Int) := by
  apply exists_sat_certificate_of_count w r (countingThreshold r) hw hrw
  · unfold countingThreshold; omega
  · exact countingThreshold_fits r hr
  · exact countingThreshold_condition r (by omega)

/-- The block length in the 17/7 manuscript's first parameter choice. -/
def paperBlockSize (w : Nat) : Nat := w - logarithmicOffset w - 1

theorem width_power_fit (w : Nat) (hw : 32 ≤ w) : w ≤ 2 ^ (w - 17) := by
  induction w, hw using Nat.le_induction with
  | base => norm_num
  | succ w hw ih =>
    have he : w + 1 - 17 = (w - 17) + 1 := by omega
    rw [he, pow_succ]
    nlinarith

theorem paperBlockSize_bounds (w : Nat) (hw : 32 ≤ w) :
    16 ≤ paperBlockSize w ∧ paperBlockSize w < w := by
  have hlog : Nat.clog 2 w ≤ w - 17 := Nat.clog_le_of_le_pow (width_power_fit w hw)
  unfold paperBlockSize logarithmicOffset
  omega

theorem countingThreshold_paperBlockSize_le (w : Nat) :
    countingThreshold (paperBlockSize w) ≤ logarithmicOffset w + 5 := by
  unfold countingThreshold logarithmicOffset
  have h : paperBlockSize w ≤ w := by unfold paperBlockSize; omega
  exact Nat.add_le_add_right (Nat.clog_mono_right 2 h) 5

/-- The paper's block size and a logarithmic robustness threshold yield the
finite certificate for every width at least 32. -/
theorem paper_parameter_finite_certificate (w : Nat) (hw : 32 ≤ w) :
    ∃ g : (Fin (paperBlockSize w) → Bool) → Bool,
      ∀ (C : Circuit (inputBits w)), C.Computes (satFunction w) →
        7 * (inputBits w : Int) +
          (30*(paperBlockSize w : Int)-42*((countingThreshold (paperBlockSize w) : Int)+1)) *
          genericRemainingClauses w (canonicalForbiddenFamily g) - 3 ≤ 7 * (C.size : Int) := by
  obtain ⟨hlarge,hlt⟩ := paperBlockSize_bounds w hw
  exact exists_sat_certificate_logarithmic w (paperBlockSize w) (by omega) hlt hlarge

end SatLowerBound
