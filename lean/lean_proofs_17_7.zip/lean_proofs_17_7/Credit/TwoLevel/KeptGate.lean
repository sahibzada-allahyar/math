import Credit.TwoLevel.Preserve
import Credit.Transfer

/-! Existence of a reindexed target gate for every retained original gate.
Further work must transfer its references and reader identities. -/
namespace SatLowerBound
namespace OpenCircuit

/-- A gate retained by the restriction trace exists in the restricted circuit,
with the same nonlinear/parity classification. Target gate indices may differ. -/
theorem restrict_kept_gate_exists {n m : Nat} (C : OpenCircuit n)
    (σ : Fin n → Signal m) (ρ : Fin n → Res) (φ : Fin m → Nat)
    (hφ : Function.Injective φ) (hφn : ∀ w, φ w < n)
    (hrel : ∀ k, ResRel φ (σ k) (ρ k))
    (s : Nat) (g : Table) (a b : Nat) (hgate : C.gateAt s = some (g,a,b))
    (hkept : C.isKept ρ s = true) :
    ∃ k g' a' b', (C.restrict σ).gateAt k = some (g',a',b') ∧
      g'.nonlinear = g.nonlinear ∧ g'.parity = g.parity := by
  induction C generalizing m with
  | output o => simp [gateAt] at hgate
  | @gate n h i j rest ih =>
    rcases hsg : simplifyGate h (σ i) (σ j) with sig | ⟨q, k, l⟩
    · obtain ⟨r, hstep, hsr⟩ := TransferAux.step_of_alias φ hφ h (hrel i) (hrel j) hsg
      have hsne : s ≠ n := by
        intro he
        subst s
        rw [FlatKeptAux.isKept_cons_head, hstep] at hkept
        contradiction
      have htail : rest.gateAt s = some (g,a,b) := by
        rw [← gateAt_tail h i j rest hsne]
        exact hgate
      have hkeepTail : rest.isKept (appendValue ρ r) s = true := by
        rw [FlatKeptAux.isKept_cons_tail h i j rest ρ hsne] at hkept
        simpa [FlatKeptAux.tailRes, hstep] using hkept
      have h := ih (extendSubst σ sig) (appendValue ρ r) φ hφ
        (fun w => Nat.lt_succ_of_lt (hφn w)) (TransferAux.rel_extend hrel hsr)
        htail hkeepTail
      simpa only [restrict, hsg] using h
    · obtain ⟨hstep, x, y, hq, _, _⟩ :=
        TransferAux.step_of_binary φ hφ h (hrel i) (hrel j) hsg
      subst hq
      by_cases hs : s = n
      · subst s
        rw [gateAt_head] at hgate
        simp only [Option.some.injEq, Prod.mk.injEq] at hgate
        obtain ⟨rfl, rfl, rfl⟩ := hgate
        refine ⟨m, twist h x y, k.val, l.val, ?_, twist_nonlinear h x y, twist_parity h x y⟩
        simp only [restrict, hsg, gateAt_head]
      · have htail : rest.gateAt s = some (g,a,b) := by
          rw [← gateAt_tail h i j rest hs]
          exact hgate
        have hkeepTail : rest.isKept (appendValue ρ (.lit n false)) s = true := by
          rw [FlatKeptAux.isKept_cons_tail h i j rest ρ hs] at hkept
          simpa [FlatKeptAux.tailRes, hstep] using hkept
        obtain ⟨k', g', a', b', hk', hn, hp⟩ :=
          ih (liftSubst σ) (appendValue ρ (.lit n false)) (appendValue φ n)
            (TransferAux.appendValue_injective hφ hφn) (TransferAux.appendValue_lt hφn)
            (TransferAux.rel_lift hrel) htail hkeepTail
        have hkne : k' ≠ m := by
          have hb := ((rest.restrict (liftSubst σ)).gateAt_bounds hk').1
          omega
        refine ⟨k', g', a', b', ?_, hn, hp⟩
        simp only [restrict, hsg]
        rw [gateAt_tail _ _ _ _ hkne]
        exact hk'

/-- Specialization to the paper's fixed-input restrictions. -/
theorem fix_kept_gate_exists {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool)
    (s : Nat) (g : Table) (a b : Nat) (hgate : C.gateAt s = some (g,a,b))
    (hkept : C.isKept (fixRes P c) s = true) :
    ∃ k g' a' b', (C.restrict (fixSubst P c)).gateAt k = some (g',a',b') ∧
      g'.nonlinear = g.nonlinear ∧ g'.parity = g.parity := by
  exact C.restrict_kept_gate_exists (fixSubst P c) (fixRes P c) Fin.val
    Fin.val_injective (fun w => w.isLt) (fixSubst_rel P c) s g a b hgate hkept

end OpenCircuit
end SatLowerBound
