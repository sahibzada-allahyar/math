import Credit.TwoLevel.Basic
import Credit.Charging

/-! Terminal bound for the two-level composition induction. -/
namespace SatLowerBound
namespace OpenCircuit

private theorem card_le_two_mul_of_rel {α β : Type} [DecidableEq β] [Nonempty β]
    (s : Finset α) (t : Finset β) (r : α → β → Prop)
    (hs : ∀ a ∈ s, ∃ b, b ∈ t ∧ r a b)
    (ht : ∀ b ∈ t, ∀ u : Finset α, (∀ a ∈ u, r a b) → u.card ≤ 2) :
    s.card ≤ 2 * t.card := by
  choose! f hft hfr using hs
  apply Finset.card_le_mul_card_image_of_maps_to hft 2
  intro b hb
  apply ht b hb
  intro a ha
  obtain ⟨ha₁, ha₂⟩ := Finset.mem_filter.mp ha
  rw [← ha₂]
  exact hfr a ha₁

/-- Every D-variable has a nonlinear reader, and each binary gate reads at
most two primary inputs. This is the paper's unconditional `D ≤ 2A`. -/
theorem dCount_le_two_nonlinearCount {n : Nat} (C : OpenCircuit n) :
    C.dCount ≤ 2 * C.nonlinearCount := by
  have h1 : C.dCount = (Finset.univ.filter (fun z : Fin n => C.isD z.val = true)).card := by
    rw [Finset.card_filter]
    rfl
  have h2 : C.nonlinearCount = ((Finset.range (n + C.size)).filter
      (fun k => (C.tableAt k).nonlinear = true)).card := by
    rw [Finset.card_filter, C.nonlinearCount_eq_sum]
    rfl
  rw [h1, h2]
  apply card_le_two_mul_of_rel _ _ (fun (z : Fin n) (k : Nat) => k ∈ C.users z.val)
  · intro z hz
    have hD := (Finset.mem_filter.mp hz).2
    obtain ⟨_, W, g, a, b, hW, hab, hnl⟩ := (C.isD_iff z.val).mp hD
    refine ⟨W, ?_, C.mem_users.mpr ⟨g, a, b, hW, hab⟩⟩
    rw [Finset.mem_filter, Finset.mem_range]
    exact ⟨(C.gateAt_bounds hW).2.1, by simpa [tableAt, hW] using hnl⟩
  · intro k hk u hu
    have hknl := (Finset.mem_filter.mp hk).2
    cases hg : C.gateAt k with
    | none =>
      have hf : (⟨false, false, false, false⟩ : Table).nonlinear = false := by decide
      simp only [tableAt, hg] at hknl
      rw [hf] at hknl
      contradiction
    | some p =>
      obtain ⟨g, a, b⟩ := p
      calc u.card ≤ ({a, b} : Finset Nat).card := by
            apply Finset.card_le_card_of_injOn (fun z : Fin n => z.val)
            · intro z hz
              obtain ⟨g', a', b', hg', hab⟩ := C.mem_users.mp (hu z hz)
              rw [hg] at hg'
              simp only [Option.some.injEq, Prod.mk.injEq] at hg'
              obtain ⟨-, ha, hb⟩ := hg'
              rw [Finset.mem_coe, Finset.mem_insert, Finset.mem_singleton]
              rcases hab with h | h
              · exact Or.inl (by rw [ha, h])
              · exact Or.inr (by rw [hb, h])
            · intro z₁ _ z₂ _ h
              exact Fin.ext h
        _ ≤ 2 := Finset.card_le_two

/-- The paper's terminal estimate `Ψ₂ ≥ 7X ≥ 0`, without an E1 or
normalization hypothesis. -/
theorem psi2_nonnegative {n : Nat} (C : OpenCircuit n) : 0 ≤ C.psi2 := by
  have hd : (C.dCount : Int) ≤ 2 * C.nonlinearCount := by
    exact_mod_cast C.dCount_le_two_nonlinearCount
  have hstar : (C.dStarCount : Int) ≤ C.dCount := by
    exact_mod_cast C.dStarCount_le_dCount
  have hp : (0 : Int) ≤ C.parityCount := by omega
  unfold psi2
  rw [C.psi2Weight_eq]
  push_cast
  omega

/-- Under the manuscript's no-shared-D-gate condition, the two-level
potential is nonnegative. This uses the stronger `D ≤ A` bound, while the
paper's terminal argument uses the more general `D ≤ 2A` bound. -/
theorem psi2_nonnegative_of_DGateSafe {n : Nat} (C : OpenCircuit n)
    (hsafe : C.DGateSafe) : 0 ≤ C.psi2 := by
  have hd : (C.dCount : Int) ≤ C.nonlinearCount := by
    exact_mod_cast C.dCount_le_nonlinearCount hsafe
  have hstar : (C.dStarCount : Int) ≤ C.dCount := by
    exact_mod_cast C.dStarCount_le_dCount
  have hp : (0 : Int) ≤ C.parityCount := by omega
  have ha : (0 : Int) ≤ C.nonlinearCount := by omega
  unfold psi2
  rw [C.psi2Weight_eq]
  push_cast
  omega

end OpenCircuit
end SatLowerBound
