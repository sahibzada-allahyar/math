import Credit.TwoLevel.RobustCounting
import Credit.TwoLevel.CoordinateDegree
import Credit.TwoLevel.ConcreteCertificate

/-! Counting full-degree Boolean functions by flipping one truth-table entry. -/
namespace SatLowerBound

/-- Indicator of the all-false input. -/
def originIndicator (n : Nat) (v : Fin n → Bool) : Bool :=
  decide (v = fun _ => false)

/-- A singleton truth table has odd parity and hence full top coefficient. -/
theorem originIndicator_top (n : Nat) :
    (BPoly.ofFunction n (originIndicator n)).topCoefficient = true := by
  classical
  have hs : (∑ v : Fin n → Bool, fieldBit (R := FourField) (originIndicator n v)) = 1 := by
    simp [originIndicator, fieldBit]
  have h := topCoefficient_field_sum (R := FourField) n (originIndicator n)
  rw [lastCubeSum_eq_sum,hs] at h
  cases htop : (BPoly.ofFunction n (originIndicator n)).topCoefficient <;>
    simp_all [fieldBit]

/-- Toggle the truth-table entry at the all-false input. -/
def flipOrigin {n : Nat} (f : (Fin n → Bool) → Bool) : (Fin n → Bool) → Bool :=
  fun v => Bool.xor (f v) (originIndicator n v)

theorem flipOrigin_involutive {n : Nat} : Function.Involutive (@flipOrigin n) := by
  intro f
  funext v
  simp [flipOrigin]

theorem top_flipOrigin {n : Nat} (f : (Fin n → Bool) → Bool) :
    (BPoly.ofFunction n (flipOrigin f)).topCoefficient =
      !(BPoly.ofFunction n f).topCoefficient := by
  change (BPoly.ofFunction n (fun v => Bool.xor (f v) (originIndicator n v))).topCoefficient = _
  rw [BPoly.ofFunction_xor, BPoly.top_add, originIndicator_top]
  cases (BPoly.ofFunction n f).topCoefficient <;> rfl

/-- The truth tables of full algebraic degree. -/
noncomputable def fullDegreeFunctions (n : Nat) : Finset ((Fin n → Bool) → Bool) := by
  classical
  exact Finset.univ.filter (fun f => (BPoly.ofFunction n f).topCoefficient = true)

/-- Toggling the origin exchanges full-degree and non-full-degree functions. -/
noncomputable def fullDegreeEquiv (n : Nat) :
    {f : (Fin n → Bool) → Bool // (BPoly.ofFunction n f).topCoefficient = true} ≃
    {f : (Fin n → Bool) → Bool // ¬ (BPoly.ofFunction n f).topCoefficient = true} where
  toFun f := ⟨flipOrigin f.val, by rw [top_flipOrigin,f.property]; decide⟩
  invFun f := ⟨flipOrigin f.val, by
    rw [top_flipOrigin]
    have hf := f.property
    cases h : (BPoly.ofFunction n f.val).topCoefficient <;> simp_all⟩
  left_inv f := by apply Subtype.ext; exact flipOrigin_involutive f.val
  right_inv f := by apply Subtype.ext; exact flipOrigin_involutive f.val

/-- Exactly half of all truth tables have full degree. -/
theorem fullDegreeFunctions_card (n : Nat) :
    (fullDegreeFunctions n).card = 2 ^ (2 ^ n - 1) := by
  classical
  let P : ((Fin n → Bool) → Bool) → Prop :=
    fun f => (BPoly.ofFunction n f).topCoefficient = true
  have he := Fintype.card_congr (fullDegreeEquiv n)
  have hc := Fintype.card_subtype_compl P
  have hcard : (fullDegreeFunctions n).card = Fintype.card {f // P f} := by
    rw [Fintype.card_subtype]
    rfl
  rw [← he, ← hcard] at hc
  have htotal : Fintype.card ((Fin n → Bool) → Bool) = 2 ^ (2 ^ n) := by
    simp
  rw [htotal] at hc
  have hpos : 0 < 2 ^ n := by positivity
  have hp : 2 ^ (2 ^ n) = 2 ^ (2 ^ n - 1) * 2 := by
    conv_lhs => rw [show 2 ^ n = (2 ^ n - 1) + 1 by omega]
    simp [pow_succ]
  omega

/-- The finite union bound leaves at least one robust truth table of full
degree whenever the number of bad tables is smaller than half the total. -/
theorem exists_robust_fullDegree_of_count (n k : Nat)
    (hcount : (3 ^ n * n * n * 6) * 2 ^ (2 ^ n - 2 ^ (k - 2)) <
      2 ^ (2 ^ n - 1)) :
    ∃ f : (Fin n → Bool) → Bool,
      Robust k f ∧ (BPoly.ofFunction n f).topCoefficient = true := by
  classical
  have hlt : (badFunctions n k).card < (fullDegreeFunctions n).card := by
    rw [fullDegreeFunctions_card]
    exact (badFunctions_card_le n k).trans_lt hcount
  obtain ⟨f,hfull,hgood⟩ := Finset.exists_mem_notMem_of_card_lt_card hlt
  refine ⟨f, ?_, ?_⟩
  · by_contra hn
    exact hgood (notRobust_mem_badFunctions f hn)
  · simpa [fullDegreeFunctions] using hfull

/-- A compact sufficient inequality for the finite count, obtained by
multiplying the paper's collision probability by the event count. -/
theorem count_condition_of_exponential (n k : Nat) (hkn : k ≤ n + 2)
    (h : 2 * (3 ^ n * n * n * 6) < 2 ^ (2 ^ (k - 2))) :
    (3 ^ n * n * n * 6) * 2 ^ (2 ^ n - 2 ^ (k - 2)) <
      2 ^ (2 ^ n - 1) := by
  have hd : 2 ^ (k - 2) ≤ 2 ^ n := Nat.pow_le_pow_right (by omega) (by omega)
  have hN : 0 < 2 ^ n := by positivity
  have hp : 0 < 2 ^ (2 ^ n - 2 ^ (k - 2)) := by positivity
  have hm := Nat.mul_lt_mul_of_pos_right h hp
  have heq : 2 ^ (2 ^ (k - 2)) * 2 ^ (2 ^ n - 2 ^ (k - 2)) = 2 ^ (2 ^ n) := by
    rw [← pow_add]
    congr 1
    omega
  have heq' : 2 ^ (2 ^ n - 1) * 2 = 2 ^ (2 ^ n) := by
    rw [← pow_succ]
    congr 1
    omega
  rw [heq] at hm
  nlinarith

/-- Probabilistic construction of a robust full-degree block, with the
ordered-coordinate-pair union bound used in this development. -/
theorem exists_robust_fullDegree (n k : Nat) (hkn : k ≤ n + 2)
    (h : 2 * (3 ^ n * n * n * 6) < 2 ^ (2 ^ (k - 2))) :
    ∃ f : (Fin n → Bool) → Bool,
      Robust k f ∧ (BPoly.ofFunction n f).topCoefficient = true :=
  exists_robust_fullDegree_of_count n k (count_condition_of_exponential n k hkn h)

/-- The block in the concrete 3-SAT certificate can be constructed from the
finite counting inequality rather than assumed. -/
theorem exists_sat_certificate_of_count (w r k : Nat) (hw : 2 ≤ w) (hr : r < w)
    (hk : 2 ≤ k) (hkr : k + 2 ≤ r)
    (h : 2 * (3 ^ r * r * r * 6) < 2 ^ (2 ^ (k - 2))) :
    ∃ g : (Fin r → Bool) → Bool, ∀ (C : Circuit (inputBits w)),
      C.Computes (satFunction w) →
      7 * (inputBits w : Int) + (30*(r : Int)-42*((k : Int)+1)) *
        genericRemainingClauses w (canonicalForbiddenFamily g) - 3 ≤ 7 * (C.size : Int) := by
  obtain ⟨g,hrob,hfull⟩ := exists_robust_fullDegree r k (by omega) h
  exact ⟨g, fun C hc => sat_certificate_of_robust_block w r k hw hr hk hkr g hrob hfull C hc⟩

end SatLowerBound
