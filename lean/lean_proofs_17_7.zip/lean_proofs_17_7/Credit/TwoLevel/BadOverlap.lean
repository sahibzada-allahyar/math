import Credit.TwoLevel.BadReaders

/-! Gate orientation and restriction identities needed for the final
both-bad overlap. -/
namespace SatLowerBound
namespace OpenCircuit

/-- A gate reading two different signals can be oriented in either physical
operand order, with its table kind preserved. -/
theorem oriented_signal_of_two_readers {n : Nat} (C : OpenCircuit n)
    (a b k : Nat) (hab : a ≠ b) (ha : k ∈ C.users a) (hb : k ∈ C.users b) :
    ∃ g, C.OrientedSignalGate k a b g ∧ g.nonlinear = (C.tableAt k).nonlinear := by
  obtain ⟨g,x,y,hg,hax⟩ := C.mem_users.mp ha
  obtain ⟨g',x',y',hg',hbx⟩ := C.mem_users.mp hb
  rw [hg] at hg'
  simp only [Option.some.injEq, Prod.mk.injEq] at hg'
  obtain ⟨_,hxx,hyy⟩ := hg'
  rw [← hxx, ← hyy] at hbx
  rcases hax with ha' | ha' <;> rcases hbx with hb' | hb'
  · exact False.elim (hab (ha'.symm.trans hb'))
  · refine ⟨g,Or.inl ?_,?_⟩
    · simpa [ha',hb'] using hg
    · simp [tableAt,hg]
  · refine ⟨g.swap,Or.inr ?_,?_⟩
    · simpa [hb',ha',table_swap_swap] using hg
    · simp [table_swap_nonlinear,tableAt,hg]
  · exact False.elim (hab (ha'.symm.trans hb'))

/-- Any reader may be oriented so that the designated signal comes first. -/
theorem oriented_signal_of_reader {n : Nat} (C : OpenCircuit n)
    (a k : Nat) (ha : k ∈ C.users a) :
    ∃ b g, C.OrientedSignalGate k a b g ∧ g.nonlinear = (C.tableAt k).nonlinear := by
  obtain ⟨g,x,y,hg,hab⟩ := C.mem_users.mp ha
  rcases hab with hx | hy
  · refine ⟨y,g,Or.inl ?_,?_⟩
    · simpa [hx] using hg
    · simp [tableAt,hg]
  · refine ⟨x,g.swap,Or.inr ?_,?_⟩
    · simpa [hy,table_swap_swap] using hg
    · simp [table_swap_nonlinear,tableAt,hg]

theorem swap_blocksRight (g : Table) (b : Bool) :
    g.swap.blocksRight b = g.blocksLeft b := by
  have hh := table_swap_blocksLeft g.swap b
  simpa [table_swap_swap] using hh.symm

/-- Oriented gates resolve to their blocked constant when the first operand
resolves to the gate's blocking value. -/
theorem oriented_res_blocked_left {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res)
    (k a b : Nat) (g : Table) (v : Bool) (hg : C.OrientedSignalGate k a b g)
    (ha : C.resAt ρ a = .const v) (hb : g.blocksLeft v = true) :
    C.resAt ρ k = .const (g.eval v false) := by
  rcases hg with hg | hg
  · rw [C.resAt_gate _ hg, ha, Res.step_blocked_left g v _ hb]
    rfl
  · have hbr : g.swap.blocksRight v = true := by simpa [swap_blocksRight] using hb
    rw [C.resAt_gate _ hg, ha, Res.step_blocked_right g.swap _ v hbr]
    simp [Table.swap_eval]

/-- The corresponding identity for the second operand. -/
theorem oriented_res_blocked_right {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res)
    (k a b : Nat) (g : Table) (v : Bool) (hg : C.OrientedSignalGate k a b g)
    (hb : C.resAt ρ b = .const v) (ha : g.blocksRight v = true) :
    C.resAt ρ k = .const (g.eval false v) := by
  rcases hg with hg | hg
  · rw [C.resAt_gate _ hg, hb, Res.step_blocked_right g _ v ha]
    rfl
  · have hbl : g.swap.blocksLeft v = true := by simpa [table_swap_blocksLeft] using ha
    rw [C.resAt_gate _ hg, hb, Res.step_blocked_left g.swap v _ hbl]
    simp [Table.swap_eval]

end OpenCircuit

namespace MAContext
open OpenCircuit

/-- The overlap `V₂ = R, U₂ = V` is impossible under the no-drop
assumption. Blocking values are derived from the restriction trace and the
oriented gate tables, rather than assumed as circuit facts. -/
theorem final_opposite_overlap_impossible {n : Nat}
    {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) {t : Table} {i j : Fin n} {rest : OpenCircuit (n+1)}
    (hC : C = .gate t i j rest) (hnl : t.nonlinear = true)
    (hno : ∀ x, (x = i ∨ x = j) → ∀ b,
      ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2))
    (U V R : Nat) (hUn : U ≠ n) (hVn : V ≠ n)
    (hUi : C.users i.val = {n,U}) (hVj : C.users j.val = {n,V})
    (hR : C.users n = {R}) (hUV : C.users U = {V}) (hVR : C.users V = {R})
    (ε : Bool) (hε : t.blocksLeft ε = true)
    (hTc : (C.resAt (singleRes i ε) n).isConst = true)
    (hRnc : (C.resAt (singleRes i ε) R).isConst = false)
    (hUpar : (C.tableAt U).parity = false) (hRpar : (C.tableAt R).parity = false) : False := by
  have hT : C.gateAt n = some (t,i.val,j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hij : i ≠ j := fun he => (h.gate_facts hT).2.1 (congrArg Fin.val he)
  have hTi : n ∈ C.users i.val := C.mem_users.mpr ⟨t,i.val,j.val,hT,Or.inl rfl⟩
  have hTj : n ∈ C.users j.val := C.mem_users.mpr ⟨t,i.val,j.val,hT,Or.inr rfl⟩
  have hU : U ∈ C.users i.val := by rw [hUi]; simp
  have hV : V ∈ C.users j.val := by rw [hVj]; simp
  have hVU : V ∈ C.users U := by rw [hUV]; simp
  have hRT : R ∈ C.users n := by rw [hR]; simp
  have hRV : R ∈ C.users V := by rw [hVR]; simp
  obtain ⟨hi2,hj2⟩ := h.degrees_of_nonlinear hC hnl
  have hVpar : (C.tableAt V).parity = false := by
    apply Bool.eq_false_iff.mpr
    intro hp
    obtain ⟨b,hb⟩ := h.case_nonlinear_parity_twoLevel hC hnl j (Or.inr rfl)
      hj2 V hVn hV (Or.inl hp)
    exact hno j (Or.inr rfl) b hb
  have hUnl : (C.tableAt U).nonlinear = true := by
    obtain ⟨g,a,d,hg,_⟩ := C.mem_users.mp hU
    rcases g.essential_parity_or_nonlinear (h.gate_facts hg).1 with hp | hg'
    · have : (C.tableAt U).parity = true := by simp [tableAt,hg,hp]
      rw [this] at hUpar; contradiction
    · simpa [tableAt,hg] using hg'
  have hVnl : (C.tableAt V).nonlinear = true := by
    obtain ⟨g,a,d,hg,_⟩ := C.mem_users.mp hV
    rcases g.essential_parity_or_nonlinear (h.gate_facts hg).1 with hp | hg'
    · have : (C.tableAt V).parity = true := by simp [tableAt,hg,hp]
      rw [this] at hVpar; contradiction
    · simpa [tableAt,hg] using hg'
  have hRnl : (C.tableAt R).nonlinear = true := by
    obtain ⟨g,a,d,hg,_⟩ := C.mem_users.mp hRT
    rcases g.essential_parity_or_nonlinear (h.gate_facts hg).1 with hp | hg'
    · have : (C.tableAt R).parity = true := by simp [tableAt,hg,hp]
      rw [this] at hRpar; contradiction
    · simpa [tableAt,hg] using hg'
  obtain ⟨other,u,hUgate,hukind⟩ := C.oriented_signal_of_reader i.val U hU
  have hunl : u.nonlinear = true := by rw [hukind,hUnl]
  have hUge : n ≤ U := by
    obtain ⟨g,a,d,hg,_⟩ := C.mem_users.mp hU
    exact (C.gateAt_bounds hg).1
  obtain ⟨v,hVgate,hvkind⟩ := C.oriented_signal_of_two_readers j.val U V (by have := j.isLt; omega) hV hVU
  have hvnl : v.nonlinear = true := by rw [hvkind,hVnl]
  obtain ⟨r,hRgate,hrkind⟩ := C.oriented_signal_of_two_readers n V R (Ne.symm hVn) hRT hRV
  have hrnl : r.nonlinear = true := by rw [hrkind,hRnl]
  have hinput : ∀ (x : Fin n) (b : Bool), C.resAt (singleRes x b) x.val = .const b := by
    intro x b
    rw [C.resAt_single_input x b x]
    simp
  obtain ⟨β,hβ,_⟩ := u.nonlinear_exists_blocksLeft hunl
  have hUβ := C.oriented_res_blocked_left (singleRes i β) U i.val other u β hUgate (hinput i β) hβ
  have hUcβ : (C.resAt (singleRes i β) U).isConst = true := by rw [hUβ]; rfl
  have hTncβ : (C.resAt (singleRes i β) n).isConst = false := by
    apply Bool.eq_false_iff.mpr
    intro hc
    exact hno i (Or.inl rfl) β (h.case_both_constant_twoLevel i β hi2 hUn hU hTi hUcβ hc)
  have hβε : β ≠ ε := by intro he; rw [he,hTc] at hTncβ; contradiction
  have hβeq : β = !ε := by cases β <;> cases ε <;> simp_all
  have hu : u.blocksLeft (!ε) = true := by simpa [hβeq] using hβ
  have hUres : C.resAt (singleRes i (!ε)) U = .const (u.eval (!ε) false) :=
    C.oriented_res_blocked_left (singleRes i (!ε)) U i.val other u (!ε) hUgate (hinput i (!ε)) hu
  have hUc : (C.resAt (singleRes i (!ε)) U).isConst = true := by rw [hUres]; rfl
  have hVnc : (C.resAt (singleRes i (!ε)) V).isConst = false := by
    apply Bool.eq_false_iff.mpr
    intro hc
    exact hno i (Or.inl rfl) (!ε) (h.case_successor_constant_twoLevel i (!ε) hi2 hUn hU hTi hUc hVU hc)
  have hvu : v.blocksRight (u.eval (!ε) false) = false := by
    apply Bool.eq_false_iff.mpr
    intro hb
    have he := C.oriented_res_blocked_right (singleRes i (!ε)) V j.val U v
      (u.eval (!ε) false) hVgate hUres hb
    rw [he] at hVnc
    contradiction
  obtain ⟨δ,hδ,_⟩ := t.nonlinear_exists_blocksRight hnl
  have hTδ : (C.resAt (singleRes j δ) n).isConst = true := by
    rw [C.resAt_gate _ hT, hinput j δ, Res.step_blocked_right t _ δ hδ]
    rfl
  obtain ⟨γ,hγ,_⟩ := v.nonlinear_exists_blocksLeft hvnl
  have hVγ := C.oriented_res_blocked_left (singleRes j γ) V j.val U v γ hVgate (hinput j γ) hγ
  have hVcγ : (C.resAt (singleRes j γ) V).isConst = true := by rw [hVγ]; rfl
  have hTncγ : (C.resAt (singleRes j γ) n).isConst = false := by
    apply Bool.eq_false_iff.mpr
    intro hc
    exact hno j (Or.inr rfl) γ (h.case_both_constant_twoLevel j γ hj2 hVn hV hTj hVcγ hc)
  have hγδ : γ ≠ δ := by intro he; rw [he,hTδ] at hTncγ; contradiction
  have hγeq : γ = !δ := by cases γ <;> cases δ <;> simp_all
  have hvx : v.blocksLeft (!δ) = true := by simpa [hγeq] using hγ
  have hVres : C.resAt (singleRes j (!δ)) V = .const (v.eval (!δ) false) :=
    C.oriented_res_blocked_left (singleRes j (!δ)) V j.val U v (!δ) hVgate (hinput j (!δ)) hvx
  have hVc : (C.resAt (singleRes j (!δ)) V).isConst = true := by rw [hVres]; rfl
  have hRnc' : (C.resAt (singleRes j (!δ)) R).isConst = false := by
    apply Bool.eq_false_iff.mpr
    intro hc
    exact hno j (Or.inr rfl) (!δ) (h.case_successor_constant_twoLevel j (!δ) hj2 hVn hV hTj hVc hRV hc)
  have hrv0 : r.blocksRight (v.eval (!δ) false) = false := by
    apply Bool.eq_false_iff.mpr
    intro hb
    have he := C.oriented_res_blocked_right (singleRes j (!δ)) R n V r
      (v.eval (!δ) false) hRgate hVres hb
    rw [he] at hRnc'
    contradiction
  have hrv : r.blocksRight (v.eval (!δ) (u.eval (!ε) false)) = false := by
    rw [v.blocksLeft_eval (!δ) hvx]
    exact hrv0
  have hTres : C.resAt (singleRes i ε) n = .const (t.eval ε δ) := by
    rw [C.resAt_gate _ hT, hinput i ε, Res.step_blocked_left t ε _ hε]
    simp [t.blocksLeft_eval ε hε δ]
  have hrt : r.blocksLeft (t.eval ε δ) = false := by
    apply Bool.eq_false_iff.mpr
    intro hb
    have he := C.oriented_res_blocked_left (singleRes i ε) R n V r (t.eval ε δ) hRgate hTres hb
    rw [he] at hRnc
    contradiction
  exact h.opposite_bad_wiring_impossible i j hij n U V R other t u v r ε δ (Or.inl hT)
    hUgate hVgate hRgate hVj hR hVR hnl hε hδ hu hvx hvu hrnl hrt hrv

/-- After ruling out the opposite-blocking overlap, the only no-drop
configuration left is `V₂ = U`, the pruning case of the manuscript. -/
theorem no_drop_forces_pruning_overlap {n : Nat}
    {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (hS4 : S4Essential f) {t : Table} {i j : Fin n}
    {rest : OpenCircuit (n+1)} (hC : C = .gate t i j rest) (hnl : t.nonlinear = true)
    (hno : ∀ x, (x = i ∨ x = j) → ∀ b,
      ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2)) :
    ∃ U V R U₂ ε, U ≠ V ∧ U ≠ n ∧ V ≠ n ∧
      C.users i.val = {n,U} ∧ C.users j.val = {n,V} ∧ C.users n = {R} ∧
      C.users U = {U₂} ∧ C.users V = {U} ∧
      t.blocksLeft ε = true ∧ (C.resAt (singleRes i ε) n).isConst = true ∧
      (C.resAt (singleRes i ε) U).isConst = false ∧
      (C.resAt (singleRes i ε) R).isConst = false ∧
      (C.tableAt U).parity = false ∧ (C.tableAt R).parity = false ∧
      BadReader C i U n ∧ BadReader C j V n := by
  obtain ⟨U,V,R,U₂,V₂,ε,hUV,hUn,hVn,hUi,hVj,hR,hU₂,hV₂,hover,hε,hTc,hUnc,hRnc,
    hUpar,hRpar,hUbad,hVbad⟩ := h.no_drop_forces_final_bad_overlaps hS4 hC hnl hno
  have hV₂eq : V₂ = U := by
    rcases hover with he | ⟨he,he'⟩
    · exact he
    · have hVR : C.users V = {R} := by rw [← he]; exact hV₂
      have hUVread : C.users U = {V} := by rw [← he']; exact hU₂
      exact False.elim (h.final_opposite_overlap_impossible hC hnl hno U V R hUn hVn
        hUi hVj hR hUVread hVR ε hε hTc hRnc hUpar hRpar)
  have hVU : C.users V = {U} := by rw [← hV₂eq]; exact hV₂
  exact ⟨U,V,R,U₂,ε,hUV,hUn,hVn,hUi,hVj,hR,hU₂,hVU,hε,hTc,hUnc,hRnc,
    hUpar,hRpar,hUbad,hVbad⟩

/-- In the last overlap, the symmetric no-drop analysis forces the unique
successor of `U` to be `R`: the other possibility would point backwards to
`V`, even though `V` feeds `U`. -/
theorem pruning_overlap_U_successor_is_R {n : Nat}
    {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) {t : Table} {i j : Fin n} {rest : OpenCircuit (n+1)}
    (hC : C = .gate t i j rest) (hnl : t.nonlinear = true)
    (hno : ∀ x, (x = i ∨ x = j) → ∀ b,
      ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2))
    (U V R U₂ : Nat) (hUV : U ≠ V) (hUn : U ≠ n) (hVn : V ≠ n)
    (hUi : C.users i.val = {n,U}) (hVj : C.users j.val = {n,V})
    (hR : C.users n = {R}) (hVU : C.users V = {U}) (hUU₂ : C.users U = {U₂})
    (hUpar : (C.tableAt U).parity = false) (hRpar : (C.tableAt R).parity = false)
    (hU₂par : (C.tableAt U₂).parity = false) : U₂ = R := by
  have hT : C.gateAt n = some (t,i.val,j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hij : i ≠ j := fun he => (h.gate_facts hT).2.1 (congrArg Fin.val he)
  have hTj : n ∈ C.users j.val := C.mem_users.mpr ⟨t,i.val,j.val,hT,Or.inr rfl⟩
  have hV : V ∈ C.users j.val := by rw [hVj]; simp
  have hRT : R ∈ C.users n := by rw [hR]; simp
  have hUreadV : U ∈ C.users V := by rw [hVU]; simp
  have hU₂readU : U₂ ∈ C.users U := by rw [hUU₂]; simp
  have hVUgt : V < U := by
    obtain ⟨g,a,d,hg,hab⟩ := C.mem_users.mp hUreadV
    have hb := C.gateAt_bounds hg
    rcases hab with he | he <;> omega
  have hUU₂gt : U < U₂ := by
    obtain ⟨g,a,d,hg,hab⟩ := C.mem_users.mp hU₂readU
    have hb := C.gateAt_bounds hg
    rcases hab with he | he <;> omega
  have hTpar : (C.tableAt n).parity = false := by
    have ht : t.parity = false := by
      unfold Table.nonlinear at hnl
      cases hp : t.parity <;> simp [hp] at hnl ⊢
    simp [tableAt,hT,ht]
  have hj2 : 2 ≤ C.refCount j.val := (h.degrees_of_nonlinear hC hnl).2
  have hVpar : (C.tableAt V).parity = false := by
    apply Bool.eq_false_iff.mpr
    intro hp
    obtain ⟨b,hb⟩ := h.case_nonlinear_parity_twoLevel hC hnl j (Or.inr rfl)
      hj2 V hVn hV (Or.inl hp)
    exact hno j (Or.inr rfl) b hb
  obtain ⟨δ,hδ,_⟩ := t.nonlinear_exists_blocksRight hnl
  have hTδ : (C.resAt (singleRes j δ) n).isConst = true := by
    rw [C.resAt_gate _ hT, C.resAt_single_input j δ j]
    simp only [ite_true]
    rw [Res.step_blocked_right t _ δ hδ]
    rfl
  have hov := h.tight_no_drop_forces_second_overlap j i (Ne.symm hij) δ hj2 n V R U U₂ rfl
    (Ne.symm hVn) (Ne.symm hUn) (Ne.symm hUV) hTj hV hUi hT i.isLt j.isLt hTδ hRT
    hTpar hVpar hRpar hUpar hUU₂ hU₂par (hno j (Or.inr rfl) δ)
  rcases hov with he | he
  · omega
  · exact he

/-- The no-drop hypothesis narrows the final configuration to a single
chain `V → U → R` with `T → R` as well. -/
theorem no_drop_forces_pruning_chain {n : Nat}
    {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (hS4 : S4Essential f) {t : Table} {i j : Fin n}
    {rest : OpenCircuit (n+1)} (hC : C = .gate t i j rest) (hnl : t.nonlinear = true)
    (hno : ∀ x, (x = i ∨ x = j) → ∀ b,
      ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2)) :
    ∃ U V R ε, U ≠ V ∧ U ≠ n ∧ V ≠ n ∧
      C.users i.val = {n,U} ∧ C.users j.val = {n,V} ∧ C.users n = {R} ∧
      C.users U = {R} ∧ C.users V = {U} ∧
      t.blocksLeft ε = true ∧ (C.resAt (singleRes i ε) n).isConst = true ∧
      (C.resAt (singleRes i ε) U).isConst = false ∧
      (C.resAt (singleRes i ε) R).isConst = false ∧
      (C.tableAt U).parity = false ∧ (C.tableAt R).parity = false ∧
      BadReader C i U n ∧ BadReader C j V n := by
  obtain ⟨U,V,R,U₂,ε,hUV,hUn,hVn,hUi,hVj,hR,hU₂,hVU,hε,hTc,hUnc,hRnc,
    hUpar,hRpar,hUbad,hVbad⟩ := h.no_drop_forces_pruning_overlap hS4 hC hnl hno
  obtain ⟨b,S,hS,hSc,hTnc,hSnext,hSpar⟩ := hUbad
  have hSU₂ : S = U₂ := by rw [hU₂] at hS; exact (by simpa using hS : U₂ = S).symm
  have hU₂par : (C.tableAt U₂).parity = false := by simpa [hSU₂] using hSpar
  have hU₂eq := h.pruning_overlap_U_successor_is_R hC hnl hno U V R U₂ hUV hUn hVn
    hUi hVj hR hVU hU₂ hUpar hRpar hU₂par
  have hUR : C.users U = {R} := by rw [← hU₂eq]; exact hU₂
  have hUbad' : BadReader C i U n := ⟨b,S,hS,hSc,hTnc,hSnext,hSpar⟩
  exact ⟨U,V,R,ε,hUV,hUn,hVn,hUi,hVj,hR,hUR,hVU,hε,hTc,hUnc,hRnc,
    hUpar,hRpar,hUbad',hVbad⟩

end MAContext
end SatLowerBound
