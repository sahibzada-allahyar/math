import Credit.TwoLevel.MainBReduction

/-! The S4 corner exclusion in the tight branch, including deriving the
opposite blocking values from the actual restriction trace. -/
namespace SatLowerBound
namespace OpenCircuit

/-- A gate that reads two distinct primary inputs has an oriented table for
that pair, independent of its physical operand order. -/
theorem oriented_pair_of_two_readers {n : Nat} (C : OpenCircuit n)
    (i j : Fin n) (hij : i ≠ j) (U : Nat)
    (hi : U ∈ C.users i.val) (hj : U ∈ C.users j.val)
    (hpar : (C.tableAt U).parity = false) (hr : C.Reduced) :
    ∃ u, C.OrientedPairGate U i j u ∧ u.nonlinear = true := by
  obtain ⟨g,a,b,hgate,hai⟩ := C.mem_users.mp hi
  obtain ⟨g',a',b',hgate',haj⟩ := C.mem_users.mp hj
  rw [hgate] at hgate'
  simp only [Option.some.injEq, Prod.mk.injEq] at hgate'
  obtain ⟨_,heA,heB⟩ := hgate'
  rw [← heA, ← heB] at haj
  have hij' : i.val ≠ j.val := fun he => hij (Fin.ext he)
  have hnl : g.nonlinear = true := by
    rcases g.essential_parity_or_nonlinear (C.reduced_gate hr hgate).1 with hp | hn
    · have hp' : (C.tableAt U).parity = true := by simp [tableAt,hgate,hp]
      rw [hp'] at hpar
      contradiction
    · exact hn
  rcases hai with hai | hbi <;> rcases haj with haj | hbj
  · exact False.elim (hij' (hai.symm.trans haj))
  · refine ⟨g,Or.inl ?_,hnl⟩
    simpa [hai,hbj] using hgate
  · refine ⟨g.swap,Or.inr ?_,?_⟩
    · simpa [haj,hbi,table_swap_swap] using hgate
    · simpa [table_swap_nonlinear] using hnl
  · exact False.elim (hij' (hbi.symm.trans hbj))

/-- If an oriented pair gate's first input is fixed to a blocking value,
the gate resolves to a constant. -/
theorem oriented_pair_blocked_const {n : Nat} (C : OpenCircuit n)
    (i j : Fin n) (U : Nat) (u : Table) (ε : Bool)
    (hu : C.OrientedPairGate U i j u) (hb : u.blocksLeft ε = true) :
    (C.resAt (singleRes i ε) U).isConst = true := by
  have hires : C.resAt (singleRes i ε) i.val = .const ε := by
    rw [C.resAt_single_input i ε i]
    simp
  rcases hu with hg | hg
  · rw [C.resAt_gate _ hg, hires, Res.step_blocked_left u ε _ hb]
    rfl
  · have hbr : u.swap.blocksRight ε = true := by
      have he := table_swap_blocksLeft u.swap ε
      simpa [table_swap_swap, hb] using he.symm
    rw [C.resAt_gate _ hg, hires, Res.step_blocked_right u.swap _ ε hbr]
    rfl

end OpenCircuit
namespace MAContext
open OpenCircuit

/-- The paper's corner exclusion: in the tight configuration the other
reader of each first-gate input cannot be the same gate. -/
theorem tight_corner_other_readers_distinct {n : Nat}
    {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (hS4 : S4Essential f) {t : Table} {i j : Fin n}
    {rest : OpenCircuit (n+1)} (hC : C = .gate t i j rest)
    (hnl : t.nonlinear = true) (ε : Bool) (hε : t.blocksLeft ε = true)
    (U V : Nat) (hi : C.users i.val = {n,U}) (hj : C.users j.val = {n,V})
    (hUpar : (C.tableAt U).parity = false)
    (hUnc : (C.resAt (singleRes i ε) U).isConst = false) : U ≠ V := by
  intro he
  subst V
  have hT : C.gateAt n = some (t,i.val,j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hij : i ≠ j := fun he' => (h.gate_facts hT).2.1 (congrArg Fin.val he')
  have hUi : U ∈ C.users i.val := by rw [hi]; simp
  have hUj : U ∈ C.users j.val := by rw [hj]; simp
  obtain ⟨u,hu,hunl⟩ := C.oriented_pair_of_two_readers i j hij U hUi hUj hUpar h.reduced
  have hunblock : u.blocksLeft ε = false := by
    apply Bool.eq_false_iff.mpr
    intro hb
    have hc := C.oriented_pair_blocked_const i j U u ε hu hb
    rw [hUnc] at hc
    contradiction
  have hublock := u.blocksLeft_not_of_false ε hunl hunblock
  have hTi : C.OrientedPairGate n i j t := Or.inl hT
  have hreadi : ∀ k ∈ C.users i.val, k = n ∨ k = U := by intro k hk; simpa [hi] using hk
  have hreadj : ∀ k ∈ C.users j.val, k = n ∨ k = U := by intro k hk; simpa [hj] using hk
  have hfour : PairFour C.eval i j := by
    have hfun : C.eval = f := funext h.computes
    rw [hfun]
    have hie : Essential f i := h.usedEssential i (by
      rw [C.usage_singleUse]
      have hp := Finset.card_pos.mpr ⟨U,hUi⟩
      have hg := C.refCount_ge i.val
      omega)
    have hje : Essential f j := h.usedEssential j (by
      rw [C.usage_singleUse]
      have hp := Finset.card_pos.mpr ⟨U,hUj⟩
      have hg := C.refCount_ge j.val
      omega)
    exact hS4 i j hij hie hje
  exact C.no_opposite_blocking_oriented_reduced h.reduced i j hij n U t u ε hTi hu
    hreadi hreadj hfour hnl hunl hε hublock

/-- If no input restriction gives the drop, S4 forces the two other
successors in the reduced tight configuration to be distinct. -/
theorem nonlinear_no_drop_tight_corner_distinct {n : Nat}
    {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (hS4 : S4Essential f) {t : Table} {i j : Fin n}
    {rest : OpenCircuit (n+1)} (hC : C = .gate t i j rest) (hnl : t.nonlinear = true)
    (hno : ∀ x, (x = i ∨ x = j) → ∀ b,
      ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2)) :
    ∃ U V R ε, U ≠ V ∧ U ≠ n ∧ V ≠ n ∧
      C.users i.val = {n,U} ∧ C.users j.val = {n,V} ∧ C.users n = {R} ∧
      t.blocksLeft ε = true ∧ (C.resAt (singleRes i ε) n).isConst = true ∧
      (C.resAt (singleRes i ε) U).isConst = false ∧
      (C.resAt (singleRes i ε) R).isConst = false ∧
      (C.tableAt U).parity = false ∧ (C.tableAt R).parity = false := by
  obtain ⟨_,hj,htight⟩ := h.nonlinear_no_drop_reduces_to_tight hC hnl hno
  obtain ⟨U,R,ε,hUn,hUi,hR,hTc,hUnc,hRnc,hUpar,hRpar⟩ := htight
  have hT : C.gateAt n = some (t,i.val,j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hij : i ≠ j := fun he => (h.gate_facts hT).2.1 (congrArg Fin.val he)
  have hTj : n ∈ C.users j.val := C.mem_users.mpr ⟨t,i.val,j.val,hT,Or.inr rfl⟩
  obtain ⟨V,hVn,hVj⟩ := h.users_two j hj hTj
  have hε : t.blocksLeft ε = true := by
    cases hb : t.blocksLeft ε with
    | true => rfl
    | false =>
      obtain ⟨neg,hstep⟩ := Res.step_unblocked_left t ε j.val false hb
      have hjres : C.resAt (singleRes i ε) j.val = .lit j.val false := by
        rw [C.resAt_single_input i ε j]
        simp [Ne.symm hij]
      have hires : C.resAt (singleRes i ε) i.val = .const ε := by
        rw [C.resAt_single_input i ε i]
        simp
      rw [C.resAt_gate _ hT, hires, hjres, hstep] at hTc
      simp [Res.isConst] at hTc
  have hUV := h.tight_corner_other_readers_distinct hS4 hC hnl ε hε U V hUi hVj hUpar hUnc
  exact ⟨U,V,R,ε,hUV,hUn,hVn,hUi,hVj,hR,hε,hTc,hUnc,hRnc,hUpar,hRpar⟩

end MAContext
end SatLowerBound
