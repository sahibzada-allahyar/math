import Credit.TwoLevel.RobustOn

/-! Embedding a robust local Boolean block into a disjoint ambient support. -/
namespace SatLowerBound

/-- Put a local input assignment on the image of an injective block embedding. -/
noncomputable def extendBlock {n r : Nat} (e : Fin r → Fin n) (v : Fin r → Bool) : Fin n → Bool :=
  fun z => if h : ∃ i, e i = z then v (Classical.choose h) else false

theorem extendBlock_apply {n r : Nat} (e : Fin r → Fin n) (he : Function.Injective e)
    (v : Fin r → Bool) (i : Fin r) : extendBlock e v (e i) = v i := by
  classical
  unfold extendBlock
  split
  · rename_i h
    rw [he (Classical.choose_spec h)]
  · rename_i h
    exact False.elim (h ⟨i,rfl⟩)

/-- The image of a robust local block has exactly the corresponding local
free coordinates after an ambient partial assignment. -/
theorem embedded_freeOn {n r : Nat} (e : Fin r → Fin n) (_he : Function.Injective e)
    (ρ : Fin n → Option Bool) :
    freeOn (Finset.univ.image e) ρ = (freeCoordinates (fun i => ρ (e i))).image e := by
  classical
  apply Finset.ext
  intro z
  constructor
  · intro hz
    obtain ⟨hzImg,hzρ⟩ := Finset.mem_filter.mp hz
    obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp hzImg
    apply Finset.mem_image.mpr
    exact ⟨i,Finset.mem_filter.mpr ⟨Finset.mem_univ i,hzρ⟩,rfl⟩
  · intro hz
    obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hz
    have hiρ := (Finset.mem_filter.mp hi).2
    apply Finset.mem_filter.mpr
    exact ⟨Finset.mem_image.mpr ⟨i,Finset.mem_univ i,rfl⟩,hiρ⟩

/-- Pull back an ambient pair-cofactor equality to local block coordinates. -/
theorem embedded_pairFour {n r : Nat} (e : Fin r → Fin n) (he : Function.Injective e)
    (g : (Fin r → Bool) → Bool) (ρ : Fin n → Option Bool) (i j : Fin r)
    (hpair : PairFour (fun v => g (applyPartial (fun i => ρ (e i)) v)) i j) :
    PairFour (fun v => g (fun t => applyPartial ρ v (e t))) (e i) (e j) := by
  intro p q hpq
  apply hpair
  funext v
  have hh := congrFun hpq (extendBlock e v)
  change g (applyPartial (fun t => ρ (e t)) (setPair v i j p.1 p.2)) =
    g (applyPartial (fun t => ρ (e t)) (setPair v i j q.1 q.2))
  have hcomm (a b : Bool) :
      (fun t => applyPartial ρ (setPair (extendBlock e v) (e i) (e j) a b) (e t)) =
        applyPartial (fun t => ρ (e t)) (setPair v i j a b) := by
    funext t
    unfold applyPartial setPair
    by_cases ht : t = i
    · subst t
      simp
    · have hti : e t ≠ e i := fun h => ht (he h)
      by_cases htj : t = j
      · subst t
        simp [hti,ht]
      · have htj' : e t ≠ e j := fun h => htj (he h)
        simp [hti,htj',ht,htj,extendBlock_apply e he v t]
  simpa only [PairRow,hcomm] using hh

/-- Injective placement of a robust local block yields a robust ambient block
on precisely the image of its coordinates. -/
theorem Robust.embedded {n r k : Nat} {g : (Fin r → Bool) → Bool}
    (h : Robust k g) (e : Fin r → Fin n) (he : Function.Injective e) :
    RobustOn k (fun v => g (fun i => v (e i))) (Finset.univ.image e) := by
  classical
  constructor
  · intro u v huv
    change g (fun i => u (e i)) = g (fun i => v (e i))
    apply congrArg g
    funext i
    exact huv (e i) (Finset.mem_image.mpr ⟨i,Finset.mem_univ i,rfl⟩)
  · intro ρ hcard x y hxy hx hy
    have hcard' : k ≤ (freeCoordinates (fun i => ρ (e i))).card := by
      rw [embedded_freeOn e he ρ,Finset.card_image_of_injective _ he] at hcard
      exact hcard
    obtain ⟨hximg,hxρ⟩ := Finset.mem_filter.mp hx
    obtain ⟨hyimg,hyρ⟩ := Finset.mem_filter.mp hy
    obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp hximg
    obtain ⟨j,_,rfl⟩ := Finset.mem_image.mp hyimg
    have hij : i ≠ j := fun heq => hxy (congrArg e heq)
    have hp := h (fun i => ρ (e i)) hcard' i j hij hxρ hyρ
    exact embedded_pairFour e he g ρ i j hp

end SatLowerBound
