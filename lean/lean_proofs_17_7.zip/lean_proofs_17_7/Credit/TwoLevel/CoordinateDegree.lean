import SatLowerBound.FiniteFieldDegree

/-! Full algebraic degree is invariant under permutation of input coordinates. -/
namespace SatLowerBound

/-- Split the last Boolean coordinate from a Boolean cube assignment. -/
def cubeStepEquiv (n : Nat) : ((Fin n → Bool) × Bool) ≃ (Fin (n+1) → Bool) where
  toFun p := extend p.1 p.2
  invFun v := (fun i => v i.castSucc, v (Fin.last n))
  left_inv p := by
    obtain ⟨v,b⟩ := p
    simp only [extend_old,extend_last]
  right_inv v := by
    funext i
    induction i using Fin.lastCases with
    | last => exact extend_last _ _
    | cast i => exact extend_old _ _ i

/-- The recursive cube sum is the ordinary finite sum over assignments. -/
theorem lastCubeSum_eq_sum {R : Type*} [AddCommMonoid R] (n : Nat)
    (f : (Fin n → Bool) → R) : lastCubeSum n f = ∑ v, f v := by
  classical
  induction n with
  | zero =>
    have he : ∀ v : Fin 0 → Bool, v = fun i => Fin.elim0 i := by
      intro v
      funext i
      exact Fin.elim0 i
    simp [lastCubeSum,he]
  | succ n ih =>
    simp only [lastCubeSum,ih]
    rw [← (cubeStepEquiv n).sum_comp f,Fintype.sum_prod_type]
    simp only [cubeStepEquiv,Fintype.sum_bool]
    rw [Finset.sum_add_distrib]
    ac_rfl

/-- Reindexing the inputs by any coordinate permutation preserves the top
multilinear coefficient. -/
theorem topCoefficient_perm {n : Nat} (f : (Fin n → Bool) → Bool) (e : Fin n ≃ Fin n) :
    (BPoly.ofFunction n (fun v => f (fun i => v (e i)))).topCoefficient =
      (BPoly.ofFunction n f).topCoefficient := by
  classical
  let E : (Fin n → Bool) ≃ (Fin n → Bool) :=
    { toFun := fun v i => v (e i)
      invFun := fun v i => v (e.symm i)
      left_inv := by intro v; funext i; simp
      right_inv := by intro v; funext i; simp }
  have heq : fieldBit (R := FourField)
      (BPoly.ofFunction n (fun v => f (fun i => v (e i)))).topCoefficient =
      fieldBit (R := FourField) (BPoly.ofFunction n f).topCoefficient := by
    rw [topCoefficient_field_sum,topCoefficient_field_sum,lastCubeSum_eq_sum,lastCubeSum_eq_sum]
    exact E.sum_comp (fun v => fieldBit (R := FourField) (f v))
  cases h₁ : (BPoly.ofFunction n (fun v => f (fun i => v (e i)))).topCoefficient <;>
    cases h₂ : (BPoly.ofFunction n f).topCoefficient <;> simp_all [fieldBit]

end SatLowerBound

namespace SatLowerBound

/-- An injective block placement is a bijection onto its finite image. -/
noncomputable def embeddingImageEquiv {n r : Nat} (e : Fin r → Fin n) (he : Function.Injective e) :
    Fin r ≃ ↥(Finset.univ.image e) := by
  classical
  apply Equiv.ofBijective (fun i => ⟨e i,Finset.mem_image.mpr ⟨i,Finset.mem_univ i,rfl⟩⟩)
  constructor
  · intro i j hij
    exact he (congrArg Subtype.val hij)
  · intro z
    obtain ⟨i,_,hi⟩ := Finset.mem_image.mp z.property
    exact ⟨i,Subtype.ext hi⟩

end SatLowerBound
