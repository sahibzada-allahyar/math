import Credit.TwoLevel.SignedSubsetSums

/-! Signed tuples and the subset sums appearing in the polynomial argument. -/
namespace SatLowerBound

/-- Choosing either sign independently for each distinct weight gives a signed
subset sum. -/
theorem signed_tuple_mem_signedSubsetSums {G : Type} [DecidableEq G] [AddCommGroup G]
    {d : Nat} (a : Fin d → G) (ha : Function.Injective a) (sign : Fin d → Bool) :
    (∑ i : Fin d, if sign i then a i else -a i) ∈
      signedSubsetSums (Finset.univ.image a) := by
  classical
  let S : Finset (Fin d) := Finset.univ.filter (fun i => sign i = true)
  let B : Finset G := S.image a
  have hB : B ⊆ Finset.univ.image a := Finset.image_mono _ (Finset.subset_univ S)
  have hcomp : (Finset.univ.image a) \ B = (Finset.univ \ S).image a := by
    ext x
    simp only [B,Finset.mem_sdiff,Finset.mem_image,Finset.mem_univ,true_and]
    constructor
    · rintro ⟨⟨i,rfl⟩,hi⟩
      refine ⟨i,?_,rfl⟩
      intro his
      exact hi ⟨i,his,rfl⟩
    · rintro ⟨i,hi,rfl⟩
      refine ⟨⟨i,rfl⟩,?_⟩
      rintro ⟨j,hj,he⟩
      have hij := ha he
      subst j
      exact hi hj
  unfold signedSubsetSums
  apply Finset.mem_image.mpr
  refine ⟨B,Finset.mem_powerset.mpr hB, ?_⟩
  rw [hcomp]
  have hBsum : (∑ x ∈ B, x) = ∑ i ∈ S, a i := by
    dsimp [B]
    rw [Finset.sum_image]
    exact ha.injOn
  have hCsum : (∑ x ∈ (Finset.univ \ S).image a, x) = ∑ i ∈ Finset.univ \ S, a i := by
    rw [Finset.sum_image]
    exact ha.injOn
  rw [hBsum,hCsum]
  have hsplit : (∑ i : Fin d, if sign i then a i else -a i) =
      (∑ i ∈ S, a i) + ∑ i ∈ Finset.univ \ S, -a i := by
    calc
      _ = (∑ i : Fin d, if i ∈ S then a i else -a i) := by
        apply Finset.sum_congr rfl
        intro i _
        simp [S]
      _ = _ := by rw [Finset.sum_ite]; simp [Finset.sdiff_eq_filter] 
  rw [hsplit, Finset.sum_neg_distrib]
  simp [sub_eq_add_neg]

/-- Reordering a signed tuple does not affect the signed-subset-sum property. -/
theorem signed_reindexed_tuple_mem {G : Type} [DecidableEq G] [AddCommGroup G]
    {d : Nat} (a : Fin d → G) (ha : Function.Injective a) (e : Fin d ≃ Fin d)
    (sign : Fin d → Bool) :
    (∑ i : Fin d, if sign i then a (e i) else -a (e i)) ∈
      signedSubsetSums (Finset.univ.image a) := by
  have h := signed_tuple_mem_signedSubsetSums a ha (fun j => sign (e.symm j))
  have he : (∑ j : Fin d, if sign (e.symm j) then a j else -a j) =
      ∑ i : Fin d, if sign i then a (e i) else -a (e i) := by
    simpa using (e.sum_comp (fun j => if sign (e.symm j) then a j else -a j)).symm
  rw [he] at h
  exact h

/-- If each tuple entry is a signed original weight and no two entries agree
up to sign, their underlying weight indices form a permutation. -/
theorem signed_tuple_indices_form_permutation {G : Type} [DecidableEq G] [AddCommGroup G]
    {d : Nat} (a x : Fin d → G)
    (hrep : ∀ i, ∃ j, x i = a j ∨ x i = -a j)
    (hsep : ∀ i j, i ≠ j → x i ≠ x j ∧ x i ≠ -x j) :
    ∃ e : Fin d ≃ Fin d, ∀ i, x i = a (e i) ∨ x i = -a (e i) := by
  classical
  let f : Fin d → Fin d := fun i => (hrep i).choose
  have hf : Function.Injective f := by
    intro i j hij
    by_contra hne
    have hi := (hrep i).choose_spec
    have hj := (hrep j).choose_spec
    change x i = a (f i) ∨ x i = -a (f i) at hi
    change x j = a (f j) ∨ x j = -a (f j) at hj
    rw [hij] at hi
    have hs := hsep i j hne
    rcases hi with hi | hi <;> rcases hj with hj | hj <;> simp_all
  let e : Fin d ≃ Fin d := Equiv.ofBijective f ⟨hf,Finite.surjective_of_injective hf⟩
  exact ⟨e,fun i => (hrep i).choose_spec⟩

/-- Any tuple of pairwise distinct values up to sign, each drawn from the
signed weights, has a sum in the signed-subset-sum set. -/
theorem distinct_signed_tuple_sum_mem {G : Type} [DecidableEq G] [AddCommGroup G]
    {d : Nat} (a x : Fin d → G) (ha : Function.Injective a)
    (hrep : ∀ i, ∃ j, x i = a j ∨ x i = -a j)
    (hsep : ∀ i j, i ≠ j → x i ≠ x j ∧ x i ≠ -x j) :
    (∑ i : Fin d, x i) ∈ signedSubsetSums (Finset.univ.image a) := by
  classical
  obtain ⟨e,he⟩ := signed_tuple_indices_form_permutation a x hrep hsep
  let sign : Fin d → Bool := fun i => decide (x i = a (e i))
  have heval (i : Fin d) : x i = if sign i then a (e i) else -a (e i) := by
    dsimp [sign]
    by_cases h : x i = a (e i)
    · simp [h]
    · have hh := (he i).resolve_left h
      simp [hh]
  have h := signed_reindexed_tuple_mem a ha e sign
  convert h using 1
  apply Finset.sum_congr rfl
  intro i _
  exact heval i

/-- The signed, pairwise-distinct tuple sums considered in the cited
polynomial argument, allowing arbitrary additional coordinate domains. -/
noncomputable def signedRestrictedSums {G : Type} [DecidableEq G] [AddCommGroup G] [Fintype G]
    {d : Nat} (a : Fin d → G) (domains : Fin d → Finset G) : Finset G := by
  classical
  exact (Finset.univ.filter (fun x : Fin d → G =>
    (∀ i, x i ∈ domains i) ∧
    (∀ i, ∃ j, x i = a j ∨ x i = -a j) ∧
    (∀ i j, i ≠ j → x i ≠ x j ∧ x i ≠ -x j))).image (fun x => ∑ i, x i)

/-- Every restricted sum used by the polynomial method is a signed subset
sum, and hence its cardinality is a lower bound for the signed-sum set. -/
theorem signedRestrictedSums_subset {G : Type} [DecidableEq G] [AddCommGroup G] [Fintype G]
    {d : Nat} (a : Fin d → G) (ha : Function.Injective a) (domains : Fin d → Finset G) :
    signedRestrictedSums a domains ⊆ signedSubsetSums (Finset.univ.image a) := by
  classical
  intro t ht
  obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp ht
  have hx' := (Finset.mem_filter.mp hx).2
  exact distinct_signed_tuple_sum_mem a x ha hx'.2.1 hx'.2.2

theorem signedRestrictedSums_card_le {G : Type} [DecidableEq G] [AddCommGroup G] [Fintype G]
    {d : Nat} (a : Fin d → G) (ha : Function.Injective a) (domains : Fin d → Finset G) :
    (signedRestrictedSums a domains).card ≤ (signedSubsetSums (Finset.univ.image a)).card :=
  Finset.card_le_card (signedRestrictedSums_subset a ha domains)

/-- Over an odd prime field, any lower bound on these restricted sums
immediately transfers to the ordinary subset sums. -/
theorem signedRestrictedSums_card_le_subsetSum (p : Nat) [NeZero p] (hp : p.Prime) (hpodd : p ≠ 2)
    {d : Nat} (a : Fin d → ZMod p) (ha : Function.Injective a)
    (domains : Fin d → Finset (ZMod p)) :
    (signedRestrictedSums a domains).card ≤ (Finset.univ.image a).subsetSum.card := by
  have h := signedRestrictedSums_card_le a ha domains
  rwa [signedSubsetSums_card_zmod_prime p hp hpodd] at h

end SatLowerBound
