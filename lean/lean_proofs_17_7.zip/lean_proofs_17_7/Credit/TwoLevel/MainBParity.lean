import Credit.TwoLevel.MainBToolkit

/-! The all-parity successor branch of Main Lemma B. -/
namespace SatLowerBound
namespace OpenCircuit

/-- Every distinct designated eliminated parity gate contributes one to the
parity elimination count. -/
theorem aliasedParityCount_ge_card {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res)
    (E : Finset Nat) (hsub : E ⊆ Finset.range (n + C.size))
    (hE : ∀ k ∈ E, C.isAliased ρ k = true ∧ (C.tableAt k).parity = true) :
    E.card ≤ C.aliasedParityCount ρ := by
  rw [C.aliasedParityCount_eq_sum]
  have hs := Finset.sum_le_sum_of_subset (f := fun k =>
    if C.isAliased ρ k = true then (C.tableAt k).parityCount else 0) hsub
  have he : (∑ k ∈ E, if C.isAliased ρ k = true then (C.tableAt k).parityCount else 0) = E.card := by
    calc
      _ = ∑ _k ∈ E, (1 : Nat) := by
        apply Finset.sum_congr rfl
        intro k hk
        obtain ⟨ha,hp⟩ := hE k hk
        simp [ha, hp, Table.parityCount]
      _ = E.card := by simp
  omega

theorem aliasedParityCount_le_aliasedCount {n : Nat} (C : OpenCircuit n)
    (ρ : Fin n → Res) : C.aliasedParityCount ρ ≤ C.aliasedCount ρ := by
  rw [C.aliasedParityCount_eq_sum, C.aliasedCount_eq_sum]
  apply Finset.sum_le_sum
  intro k _
  cases ha : C.isAliased ρ k with
  | false => simp [indicator]
  | true => cases hp : (C.tableAt k).parity <;> simp [hp, Table.parityCount, indicator]

/-- Distinct designated eliminated gates give a lower bound on the total. -/
theorem aliasedCount_ge_card {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res)
    (E : Finset Nat) (hsub : E ⊆ Finset.range (n + C.size))
    (hE : ∀ k ∈ E, C.isAliased ρ k = true) : E.card ≤ C.aliasedCount ρ := by
  rw [C.aliasedCount_eq_sum]
  have hs := Finset.sum_le_sum_of_subset (f := fun k => indicator (C.isAliased ρ k)) hsub
  have he : (∑ k ∈ E, indicator (C.isAliased ρ k)) = E.card := by
    calc
      _ = ∑ _k ∈ E, (1 : Nat) := by
        apply Finset.sum_congr rfl
        intro k hk
        simp [hE k hk, indicator]
      _ = E.card := by simp
  omega

end OpenCircuit
namespace MAContext
open OpenCircuit

/-- If an input has at least two successors and all of them are parity gates,
fixing it to either value produces the fourteen-unit drop in case I of the paper. -/
theorem case_all_parity {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (x : Fin n) (b : Bool) (h2 : 2 ≤ C.refCount x.val)
    (hall : ∀ k ∈ C.users x.val, (C.tableAt k).parity = true) :
    (C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2 := by
  have hcard : 2 ≤ (C.users x.val).card := by
    rw [← h.refCount_input x]
    exact h2
  have hsub : C.users x.val ⊆ Finset.range (n + C.size) := by
    intro k hk
    obtain ⟨g,a,d,hg,_⟩ := C.mem_users.mp hk
    exact Finset.mem_range.mpr (C.gateAt_bounds hg).2.1
  have hE : ∀ k ∈ C.users x.val, C.isAliased (singleRes x b) k = true ∧
      (C.tableAt k).parity = true := by
    intro k hk
    refine ⟨?_, hall k hk⟩
    obtain ⟨g,a,d,hg,had⟩ := C.mem_users.mp hk
    apply C.isAliased_of_const _ hg
    have hxres : C.resAt (singleRes x b) x.val = .const b := by
      rw [C.resAt_single_input x b x]
      simp
    rcases had with ha | hd
    · left
      rw [ha, hxres]
      rfl
    · right
      rw [hd, hxres]
      rfl
  have hp := C.aliasedParityCount_ge_card (singleRes x b) (C.users x.val) hsub hE
  have ht := C.aliasedParityCount_le_aliasedCount (singleRes x b)
  have hd := h.twoLevel_single_drop x b h2
  omega

/-- Two distinct parity successors already give the fourteen-unit drop;
other successors may have arbitrary tables. -/
theorem case_two_parity {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (x : Fin n) (b : Bool) (h2 : 2 ≤ C.refCount x.val)
    (k l : Nat) (hkl : k ≠ l) (hk : k ∈ C.users x.val) (hl : l ∈ C.users x.val)
    (hkp : (C.tableAt k).parity = true) (hlp : (C.tableAt l).parity = true) :
    (C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2 := by
  have hsub : ({k, l} : Finset Nat) ⊆ Finset.range (n + C.size) := by
    intro q hq
    simp only [Finset.mem_insert, Finset.mem_singleton] at hq
    have hqu : q ∈ C.users x.val := by rcases hq with rfl | rfl <;> assumption
    obtain ⟨g,a,d,hg,_⟩ := C.mem_users.mp hqu
    exact Finset.mem_range.mpr (C.gateAt_bounds hg).2.1
  have hE : ∀ q ∈ ({k,l} : Finset Nat), C.isAliased (singleRes x b) q = true ∧
      (C.tableAt q).parity = true := by
    intro q hq
    simp only [Finset.mem_insert, Finset.mem_singleton] at hq
    have hqu : q ∈ C.users x.val := by rcases hq with rfl | rfl <;> assumption
    have hqp : (C.tableAt q).parity = true := by rcases hq with rfl | rfl <;> assumption
    refine ⟨?_, hqp⟩
    obtain ⟨g,a,d,hg,had⟩ := C.mem_users.mp hqu
    apply C.isAliased_of_const _ hg
    have hxres : C.resAt (singleRes x b) x.val = .const b := by
      rw [C.resAt_single_input x b x]
      simp
    rcases had with ha | hd
    · left; rw [ha, hxres]; rfl
    · right; rw [hd, hxres]; rfl
  have hp := C.aliasedParityCount_ge_card (singleRes x b) {k,l} hsub hE
  simp [hkl] at hp
  have ht := C.aliasedParityCount_le_aliasedCount (singleRes x b)
  have hd := h.twoLevel_single_drop x b h2
  omega

/-- Main Lemma B, parity first gate and a nonlinear successor of the same
input: block the nonlinear gate and eliminate one of its successors. -/
theorem case_parity_nonlinear {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) {t : Table} {i j : Fin n} {rest : OpenCircuit (n + 1)}
    (hC : C = .gate t i j rest) (hpar : t.parity = true) (x : Fin n) (hx : x = i ∨ x = j)
    (h2 : 2 ≤ C.refCount x.val) (P : Nat) (hP : P ∈ C.users x.val)
    (hPpar : (C.tableAt P).parity = false) :
    ∃ b, (C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2 := by
  have hT : C.gateAt n = some (t, i.val, j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hTpar : (C.tableAt n).parity = true := by simp [tableAt, hT, hpar]
  have hTx : n ∈ C.users x.val := by
    rw [C.mem_users]
    refine ⟨t, i.val, j.val, hT, ?_⟩
    rcases hx with rfl | rfl <;> simp
  have hPn : P ≠ n := by
    intro he
    rw [he, hTpar] at hPpar
    contradiction
  obtain ⟨g,a,d,hgP,had⟩ := C.mem_users.mp hP
  have hgnl : g.nonlinear = true := by
    rcases g.essential_parity_or_nonlinear (h.gate_facts hgP).1 with hp | hn
    · have : (C.tableAt P).parity = true := by simp [tableAt, hgP, hp]
      rw [this] at hPpar
      contradiction
    · exact hn
  have hxres : ∀ b : Bool, C.resAt (singleRes x b) x.val = .const b := by
    intro b
    rw [C.resAt_single_input x b x]
    simp
  have halias : ∀ b : Bool, ∀ k ∈ C.users x.val, C.isAliased (singleRes x b) k = true := by
    intro b k hk
    obtain ⟨g', a', d', hg', had'⟩ := C.mem_users.mp hk
    apply C.isAliased_of_const _ hg'
    rcases had' with ha | hd
    · left; rw [ha, hxres b]; rfl
    · right; rw [hd, hxres b]; rfl
  obtain ⟨b,hbc⟩ : ∃ b, (C.resAt (singleRes x b) P).isConst = true := by
    rcases had with ha | hd
    · obtain ⟨b,hb,_⟩ := g.nonlinear_exists_blocksLeft hgnl
      refine ⟨b, ?_⟩
      rw [C.resAt_gate _ hgP, ha, hxres b, Res.step_blocked_left g b _ hb]
      rfl
    · obtain ⟨b,hb,_⟩ := g.nonlinear_exists_blocksRight hgnl
      refine ⟨b, ?_⟩
      rw [C.resAt_gate _ hgP, hd, hxres b, Res.step_blocked_right g _ b hb]
      rfl
  have hPb := C.gateAt_bounds hgP
  obtain ⟨⟨Q,hQ⟩,hQalias⟩ := h.const_users x b hPb.1 hPb.2.1 hbc
  obtain ⟨gQ,aQ,dQ,hgQ,habQ⟩ := C.mem_users.mp hQ
  have hQb := C.gateAt_bounds hgQ
  have hPQ : P < Q := by rcases habQ with he | he <;> omega
  have hnQ : n ≠ Q := by omega
  have hsub : ({n,P,Q} : Finset Nat) ⊆ Finset.range (n + C.size) := by
    intro k hk
    simp only [Finset.mem_insert, Finset.mem_singleton] at hk
    have hTb := C.gateAt_bounds hT
    rcases hk with rfl | rfl | rfl <;> exact Finset.mem_range.mpr (by omega)
  have hE : ∀ k ∈ ({n,P,Q} : Finset Nat), C.isAliased (singleRes x b) k = true := by
    intro k hk
    simp only [Finset.mem_insert, Finset.mem_singleton] at hk
    rcases hk with he | he | he
    · simpa [he] using halias b n hTx
    · simpa [he] using halias b P hP
    · simpa [he] using hQalias Q hQ
  have hcount := C.aliasedCount_ge_card (singleRes x b) {n,P,Q} hsub hE
  simp [hPn.symm, hnQ, hPQ.ne] at hcount
  have hpsub : ({n} : Finset Nat) ⊆ Finset.range (n + C.size) := by
    intro k hk
    have hk' : k = n := Finset.mem_singleton.mp hk
    rw [hk']
    exact Finset.mem_range.mpr (C.gateAt_bounds hT).2.1
  have hparity := C.aliasedParityCount_ge_card (singleRes x b) {n} hpsub (by
    intro k hk
    rw [Finset.mem_singleton.mp hk]
    exact ⟨halias b n hTx,hTpar⟩)
  simp at hparity
  have hd := h.twoLevel_single_drop_with_readers x b h2 {P} (by
    intro k hk
    rw [Finset.mem_singleton.mp hk]
    exact ⟨hP,halias b P hP,hPpar⟩)
  simp only [Finset.card_singleton, Nat.cast_one] at hd
  exact ⟨b, by omega⟩

/-- Complete parity-first branch of Main Lemma B: either every reader is
parity, or a nonlinear reader can be blocked. -/
theorem case_parity_first {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) {t : Table} {i j : Fin n} {rest : OpenCircuit (n + 1)}
    (hC : C = .gate t i j rest) (hpar : t.parity = true) (x : Fin n) (hx : x = i ∨ x = j)
    (h2 : 2 ≤ C.refCount x.val) :
    ∃ b, (C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2 := by
  by_cases hall : ∀ k ∈ C.users x.val, (C.tableAt k).parity = true
  · exact ⟨false, h.case_all_parity x false h2 hall⟩
  · obtain ⟨P,hP,hp⟩ : ∃ P ∈ C.users x.val, (C.tableAt P).parity ≠ true := by
      by_contra hn
      apply hall
      intro k hk
      by_contra hkp
      exact hn ⟨k,hk,hkp⟩
    have hp' : (C.tableAt P).parity = false := Bool.eq_false_iff.mpr hp
    exact h.case_parity_nonlinear hC hpar x hx h2 P hP hp'

end MAContext
end SatLowerBound
