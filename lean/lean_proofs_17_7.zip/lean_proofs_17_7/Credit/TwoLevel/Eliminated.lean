import Credit.TwoLevel.PreserveFull
import Credit.TwoLevel.Correspondence

/-! The free-input case of the two-level charging argument. -/
namespace SatLowerBound
namespace OpenCircuit

/-- If every original reader of an input is eliminated without passing that
input, and the output is not the input itself, restriction removes all uses of
that input. This extends the constant-reader disconnection lemma to aliases. -/
theorem keptRefs_zero_of_eliminated_nonpassing_readers {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (z : Fin n)
    (hpass : ∀ k ∈ C.users z.val, (C.resAt (fixRes P c) k).hits z.val = false)
    (halias : ∀ k ∈ C.users z.val, C.isAliased (fixRes P c) k = true)
    (hout : ∀ k neg, C.outWire = some (k,neg) → k ≠ z.val) :
    C.keptRefs (fixRes P c) z.val = 0 := by
  let ρ := fixRes P c
  have hgatepass := C.passers_subset ρ z.val z.isLt (fixRes_hits P c z.val) ∅ (n + C.size) (by
    intro k g a b _ hk _ hab
    have hmem : k ∈ C.users z.val := by
      apply C.mem_users.mpr
      refine ⟨g,a,b,hk,?_⟩
      rcases hab with ha | ha | hb | hb
      · exact Or.inl ha
      · simp at ha
      · exact Or.inr hb
      · simp at hb
    exact hpass k hmem)
  have honly : ∀ k, (C.resAt ρ k).hits z.val = true → k = z.val := by
    intro k hk
    rcases FlatKeptAux.hits_cases C ρ hk with ⟨hkn, hρk⟩ | ⟨g,a,b,hgate,_⟩
    · exact fixRes_hits P c z.val ⟨k,hkn⟩ hρk
    · have hb := C.gateAt_bounds hgate
      exact absurd (hgatepass k hb.1 hb.2.1 hk) (Finset.notMem_empty k)
  have hsum : ∑ k ∈ Finset.range (n + C.size), C.keptSlotHits ρ k z.val = 0 := by
    apply Finset.sum_eq_zero
    intro k _
    cases hk : C.gateAt k with
    | none => exact FlatKeptAux.keptSlotHits_none C ρ z.val hk
    | some p =>
      obtain ⟨g,a,b⟩ := p
      rw [FlatKeptAux.keptSlotHits_eq C ρ z.val hk]
      by_cases hkept : C.isKept ρ k = true
      · rw [ite_eq_left hkept]
        have hfa : ∀ o, (o = a ∨ o = b) → (C.resAt ρ o).hits z.val = false := by
          intro o ho
          apply Bool.eq_false_iff.mpr
          intro hh
          have hoz := honly o hh
          have hmem : k ∈ C.users z.val := by
            apply C.mem_users.mpr
            refine ⟨g,a,b,hk,?_⟩
            rcases ho with he | he
            · exact Or.inl (he.symm.trans hoz)
            · exact Or.inr (he.symm.trans hoz)
          have hnot := C.isKept_eq_not_isAliased ρ hk
          rw [hkept, halias k hmem] at hnot
          contradiction
        exact FlatKeptAux.indicator_add_eq_zero (hfa a (Or.inl rfl)) (hfa b (Or.inr rfl))
      · rw [ite_eq_right hkept]
  have hout0 : C.outHits ρ z.val = 0 := by
    unfold outHits
    cases ho : C.outWire with
    | none => rfl
    | some p =>
      obtain ⟨k,neg⟩ := p
      have hf : (C.resAt ρ k).hits z.val = false := by
        apply Bool.eq_false_iff.mpr
        intro hh
        exact (hout k neg ho) (honly k hh)
      simp only [hf, FlatKeptAux.indicator_false]
  have h := C.keptRefs_eq_sum ρ z.val
  rw [hsum, hout0] at h
  simpa [ρ] using h

/-- If a D-input remains essential while its only reader is eliminated, that
reader must resolve to a literal of the input. This is the manuscript's first
step when the first credited gate is eliminated. -/
theorem eliminated_unique_reader_must_pass {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (z : Fin n) (W : Nat)
    (hD : C.isD z.val = true) (hW : W ∈ C.users z.val)
    (hWal : C.isAliased (fixRes P c) W = true)
    (hess : Essential (C.restrict (fixSubst P c)).eval z) :
    (C.resAt (fixRes P c) W).hits z.val = true := by
  have hu := C.users_singleton_of_isD z.val W hD hW
  have hout0 := C.reduced_outIs_zero_of_user hr z.val (Finset.ne_empty_of_mem hW)
  have hout : ∀ k neg, C.outWire = some (k,neg) → k ≠ z.val := by
    intro k neg hk he
    simp [outIs, hk, he] at hout0
  by_contra hn
  have hnot : (C.resAt (fixRes P c) W).hits z.val = false := Bool.eq_false_iff.mpr hn
  have hzero := C.keptRefs_zero_of_eliminated_nonpassing_readers P c z (by
    intro k hk
    rw [hu, Finset.mem_singleton] at hk
    simpa [hk] using hnot) (by
    intro k hk
    rw [hu, Finset.mem_singleton] at hk
    simpa [hk] using hWal) hout
  exact C.not_essential_of_keptRefs_zero P c z hzero hess

/-- If the second gate is retained, no original gate other than the first gate
can resolve to the credited input. This is the paper's `S_z ⊆ {z,W}` step. -/
theorem two_link_passers_only_first {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (z : Fin n) (W V : Nat)
    (hstar : C.isDStar z.val = true) (hW : W ∈ C.users z.val)
    (hV : V ∈ C.users W) (hVkept : C.isKept (fixRes P c) V = true) :
    ∀ k, n ≤ k → k < n + C.size →
      (C.resAt (fixRes P c) k).hits z.val = true → k = W := by
  have hDz := C.isD_of_isDStar z.val hstar
  have huz := C.users_singleton_of_isD z.val W hDz hW
  have hDW : C.isD W = true := by
    obtain ⟨_, w, hw, hd⟩ := (C.isDStar_iff z.val).mp hstar
    rw [huz, Finset.mem_singleton] at hw
    simpa [hw] using hd
  have huW := C.users_singleton_of_isD W V hDW hV
  have hpass := C.passers_subset (fixRes P c) z.val z.isLt
    (fixRes_hits P c z.val) {W} (n + C.size) (by
      intro k g a b _ hk hkW hab
      have hVeq : k = V := by
        have hmem : k ∈ C.users z.val ∨ k ∈ C.users W := by
          rcases hab with ha | ha | hb | hb
          · exact Or.inl (C.mem_users.mpr ⟨g,a,b,hk,Or.inl ha⟩)
          · have haW : a = W := Finset.mem_singleton.mp ha
            exact Or.inr (C.mem_users.mpr ⟨g,a,b,hk,Or.inl haW⟩)
          · exact Or.inl (C.mem_users.mpr ⟨g,a,b,hk,Or.inr hb⟩)
          · have hbW : b = W := Finset.mem_singleton.mp hb
            exact Or.inr (C.mem_users.mpr ⟨g,a,b,hk,Or.inr hbW⟩)
        rcases hmem with hz | hw
        · rw [huz, Finset.mem_singleton] at hz
          exact False.elim (hkW (by simp [hz]))
        · rw [huW, Finset.mem_singleton] at hw
          exact hw
      subst k
      rw [C.resAt_kept _ hVkept, Bool.eq_false_iff]
      intro hh
      have hvz := (Res.hits_lit _ _ _).mp hh
      have hgate := C.gateAt_bounds hk
      have hzlt := z.isLt
      omega)
  intro k hn hk hh
  have h := hpass k hn hk hh
  exact Finset.mem_singleton.mp h

/-- Second free-input charging case: if the first credited gate is eliminated,
the second survives, and the restricted function still depends on the input,
then the input retains its first credit in the restricted circuit. -/
theorem first_credit_survives_eliminated_first_gate {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (z : Fin n) (hz : P z = false)
    (W V : Nat) (hstar : C.isDStar z.val = true) (hW : W ∈ C.users z.val)
    (hV : V ∈ C.users W) (hWal : C.isAliased (fixRes P c) W = true)
    (hVkept : C.isKept (fixRes P c) V = true)
    (hess : Essential (C.restrict (fixSubst P c)).eval z) :
    (C.restrict (fixSubst P c)).isD z.val = true := by
  have hDz := C.isD_of_isDStar z.val hstar
  have huz := C.users_singleton_of_isD z.val W hDz hW
  have hDW : C.isD W = true := by
    obtain ⟨_, w, hw, hd⟩ := (C.isDStar_iff z.val).mp hstar
    rw [huz, Finset.mem_singleton] at hw
    simpa [hw] using hd
  have huW := C.users_singleton_of_isD W V hDW hV
  have hWhit := C.eliminated_unique_reader_must_pass P c hr z W hDz hW hWal hess
  have hzHit : (C.resAt (fixRes P c) z.val).hits z.val = true := by
    rw [C.resAt_input]
    simp [fixRes, hz, Res.hits]
  have honly : ∀ o, o < n + C.size → o ≠ z.val → o ≠ W →
      (C.resAt (fixRes P c) o).hits z.val = false := by
    intro o ho hno hnW
    apply Bool.eq_false_iff.mpr
    intro hh
    by_cases hon : o < n
    · have hres : C.resAt (fixRes P c) o = fixRes P c ⟨o,hon⟩ :=
        C.resAt_input (fixRes P c) ⟨o,hon⟩
      rw [hres] at hh
      exact hno (fixRes_hits P c z.val ⟨o,hon⟩ hh)
    · exact hnW (C.two_link_passers_only_first P c z W V hstar hW hV hVkept o (by omega) ho hh)
  obtain ⟨g,a,b,hgate,hab⟩ := C.mem_users.mp hV
  have hbound := C.gateAt_bounds hgate
  have hVgt : W < V := by rcases hab with ha | hb <;> omega
  have hVneW : V ≠ W := by omega
  have hVnotz : a ≠ z.val ∧ b ≠ z.val := by
    constructor <;> intro he
    · have hm : V ∈ C.users z.val := C.mem_users.mpr ⟨g,a,b,hgate,Or.inl he⟩
      rw [huz, Finset.mem_singleton] at hm
      exact hVneW hm
    · have hm : V ∈ C.users z.val := C.mem_users.mpr ⟨g,a,b,hgate,Or.inr he⟩
      rw [huz, Finset.mem_singleton] at hm
      exact hVneW hm
  have hdis := (C.reduced_gate hr hgate).2.1
  have hnl : g.nonlinear = true := by
    obtain ⟨_, v, g', a', b', hv, hab', hn⟩ := (C.isD_iff W).mp hDW
    have hm : v ∈ C.users W := C.mem_users.mpr ⟨g',a',b',hv,hab'⟩
    rw [huW, Finset.mem_singleton] at hm
    rw [hm, hgate] at hv
    cases hv
    exact hn
  have houtz := C.reduced_outIs_zero_of_user hr z.val (Finset.ne_empty_of_mem hW)
  have houtW := C.reduced_outIs_zero_of_user hr W (Finset.ne_empty_of_mem hV)
  rw [(C.fix_transfer P c).2.2.2 z]
  apply C.keptIsD_of_unique_slot (fixRes P c) z.val V g a b hgate hVkept hnl
  · rcases hab with ha | hb
    · have hbne : b ≠ W := by omega
      rw [ha, hWhit, honly b (by omega) hVnotz.2 hbne]
      rfl
    · have hane : a ≠ W := by omega
      rw [hb, hWhit, honly a (by omega) hVnotz.1 hane]
      rfl
  · intro k g' a' b' hkV hk hkept
    have hbnd := C.gateAt_bounds hk
    have hbad : ∀ o, (o = a' ∨ o = b') → o ≠ z.val ∧ o ≠ W := by
      intro o ho
      constructor
      · intro he
        have hm : k ∈ C.users z.val := C.mem_users.mpr ⟨g',a',b',hk,by
          rcases ho with rfl | rfl <;> simp [he]⟩
        rw [huz, Finset.mem_singleton] at hm
        have hrel := C.isKept_eq_not_isAliased (fixRes P c) hk
        rw [hm, hWal] at hrel
        rw [hm] at hkept
        rw [hkept] at hrel
        contradiction
      · intro he
        have hm : k ∈ C.users W := C.mem_users.mpr ⟨g',a',b',hk,by
          rcases ho with rfl | rfl <;> simp [he]⟩
        rw [huW, Finset.mem_singleton] at hm
        exact hkV hm
    have ha := hbad a' (Or.inl rfl)
    have hb := hbad b' (Or.inr rfl)
    exact ⟨honly a' (by omega) ha.1 ha.2, honly b' (by omega) hb.1 hb.2⟩
  · intro k neg hk
    have hkz : k ≠ z.val := by intro he; simp [outIs, hk, he] at houtz
    have hkW : k ≠ W := by intro he; simp [outIs, hk, he] at houtW
    exact honly k (C.outWire_bound hk) hkz hkW

/-- If both credits are lost after the first gate is eliminated while the input
remains free and essential, the second gate is eliminated too. -/
theorem lost_both_credits_eliminates_second {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (z : Fin n) (hz : P z = false)
    (W V : Nat) (hstar : C.isDStar z.val = true) (hW : W ∈ C.users z.val)
    (hV : V ∈ C.users W) (hWal : C.isAliased (fixRes P c) W = true)
    (hess : Essential (C.restrict (fixSubst P c)).eval z)
    (hlost : (C.restrict (fixSubst P c)).isD z.val = false) :
    C.isAliased (fixRes P c) V = true ∧
      C.credit2 z - (C.restrict (fixSubst P c)).credit2 z = 2 := by
  have hVkept : C.isKept (fixRes P c) V = false := by
    apply Bool.eq_false_iff.mpr
    intro hk
    have hp := C.first_credit_survives_eliminated_first_gate P c hr z hz W V hstar hW hV hWal hk hess
    rw [hlost] at hp
    contradiction
  have hValias : C.isAliased (fixRes P c) V = true := by
    obtain ⟨g,a,b,hgate,_⟩ := C.mem_users.mp hV
    have h := C.isKept_eq_not_isAliased (fixRes P c) hgate
    rw [hVkept] at h
    cases hv : C.isAliased (fixRes P c) V with
    | false => rw [hv] at h; contradiction
    | true => rfl
  have hDz := C.isD_of_isDStar z.val hstar
  have hnewStar : (C.restrict (fixSubst P c)).isDStar z.val = false := by
    simp [isDStar, hlost]
  exact ⟨hValias, by simp [credit2, hDz, hstar, hlost, hnewStar, indicator]⟩

/-- Per-input charging bound for a free, essential two-credit input. Each of
the two original gates contributes one unit only if eliminated. -/
theorem free_two_credit_loss_le_eliminated {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (z : Fin n) (hz : P z = false)
    (W V : Nat) (hstar : C.isDStar z.val = true) (hW : W ∈ C.users z.val)
    (hV : V ∈ C.users W)
    (hess : Essential (C.restrict (fixSubst P c)).eval z) :
    C.credit2 z - (C.restrict (fixSubst P c)).credit2 z ≤
      indicator (C.isAliased (fixRes P c) W) + indicator (C.isAliased (fixRes P c) V) := by
  have hDz := C.isD_of_isDStar z.val hstar
  have hWkept : C.isAliased (fixRes P c) W = false → C.isKept (fixRes P c) W = true := by
    intro ha
    obtain ⟨g,a,b,hgate,_⟩ := C.mem_users.mp hW
    rw [C.isKept_eq_not_isAliased (fixRes P c) hgate, ha]
    rfl
  have hVkept : C.isAliased (fixRes P c) V = false → C.isKept (fixRes P c) V = true := by
    intro ha
    obtain ⟨g,a,b,hgate,_⟩ := C.mem_users.mp hV
    rw [C.isKept_eq_not_isAliased (fixRes P c) hgate, ha]
    rfl
  cases hWal : C.isAliased (fixRes P c) W with
  | false =>
    cases hVal : C.isAliased (fixRes P c) V with
    | false =>
      have hs := C.retained_DStar_survives P c hr z hz W V hstar hW hV (hWkept hWal) (hVkept hVal)
      have hd := (C.restrict (fixSubst P c)).isD_of_isDStar z.val hs
      simp [credit2, indicator, hDz, hstar, hs, hd]
    | true =>
      cases hs : (C.restrict (fixSubst P c)).isDStar z.val with
      | false =>
        have hloss := C.lost_DStar_with_first_gate_kept P c hr z hz W V hstar hW hV (hWkept hWal) hs
        rw [hloss.2]
        simp [indicator]
      | true =>
        have hd := (C.restrict (fixSubst P c)).isD_of_isDStar z.val hs
        simp [credit2, indicator, hDz, hstar, hs, hd]
  | true =>
    cases hVal : C.isAliased (fixRes P c) V with
    | false =>
      have hd := C.first_credit_survives_eliminated_first_gate P c hr z hz W V hstar hW hV hWal (hVkept hVal) hess
      cases hs : (C.restrict (fixSubst P c)).isDStar z.val <;>
        simp [credit2, indicator, hDz, hstar, hs, hd]
    | true =>
      have hcredit : 0 ≤ (C.restrict (fixSubst P c)).credit2 z := Nat.zero_le _
      simp only [credit2, indicator, hDz, hstar, ↓reduceIte]
      omega

/-- A free input with exactly one original credit loses at most one unit,
charged to its unique first gate if that gate is eliminated. -/
theorem free_one_credit_loss_le_eliminated {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (z : Fin n) (hz : P z = false)
    (W : Nat) (hD : C.isD z.val = true) (hstar : C.isDStar z.val = false)
    (hW : W ∈ C.users z.val) :
    C.credit2 z - (C.restrict (fixSubst P c)).credit2 z ≤
      indicator (C.isAliased (fixRes P c) W) := by
  have huz := C.users_singleton_of_isD z.val W hD hW
  cases hWal : C.isAliased (fixRes P c) W with
  | false =>
    have hk : C.isKept (fixRes P c) W = true := by
      obtain ⟨g,a,b,hgate,_⟩ := C.mem_users.mp hW
      rw [C.isKept_eq_not_isAliased (fixRes P c) hgate, hWal]
      rfl
    have hnewD : (C.restrict (fixSubst P c)).isD z.val = true := by
      rw [(C.fix_transfer P c).2.2.2 z]
      apply C.keptIsD_of_isD P c z hz hD
      intro k hk'
      rw [huz, Finset.mem_singleton] at hk'
      simpa [hk'] using hk
    cases hs : (C.restrict (fixSubst P c)).isDStar z.val <;>
      simp [credit2, indicator, hD, hstar, hnewD, hs]
  | true =>
    simp [credit2, indicator, hD, hstar]

/-- Aggregate free-input losses over chosen first and second credited gates.
This is an input-indexed upper bound; bounding multiple charges to the same
gate is the separate per-gate part of the paper's charging lemma. -/
theorem free_credit_losses_le_chain_eliminations {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z) :
    C.credit2Lost (C.restrict (fixSubst P c)) ≤
      ∑ z : Fin n, (indicator (C.isD z.val) * indicator (C.isAliased (fixRes P c) (W z)) +
        indicator (C.isDStar z.val) * indicator (C.isAliased (fixRes P c) (V z))) := by
  unfold credit2Lost
  apply Finset.sum_le_sum
  intro z _
  cases hd : C.isD z.val with
  | false =>
    have hs : C.isDStar z.val = false := by simp [isDStar, hd]
    simp [credit2, indicator, hd, hs]
  | true =>
    cases hs : C.isDStar z.val with
    | false =>
      have h := C.free_one_credit_loss_le_eliminated P c z (hfree z hd) (W z) hd hs (hw z hd)
      simpa [indicator, hd, hs] using h
    | true =>
      have h := C.free_two_credit_loss_le_eliminated P c hr z (hfree z hd) (W z) (V z)
        hs (hw z hd) (hv z hs) (hess z hs)
      simpa [indicator, hd, hs] using h

end OpenCircuit
end SatLowerBound
