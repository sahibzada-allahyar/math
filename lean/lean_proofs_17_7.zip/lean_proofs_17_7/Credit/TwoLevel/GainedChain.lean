import Credit.TwoLevel.PrimarySuccessor
import Credit.TwoLevel.MainBNonlinearTwo

/-! The two credit gains in the tight branch of Main Lemma B. -/
namespace SatLowerBound
namespace OpenCircuit

/-- A previously uncredited input that becomes a D-star input contributes
both new credit units to the gain. -/
theorem credit2Gained_ge_two_of_new_DStar {n : Nat} (C D : OpenCircuit n) (z : Fin n)
    (hold : C.isD z.val = false) (hnew : D.isDStar z.val = true) :
    2 ≤ C.credit2Gained D := by
  have hnewD := D.isD_of_isDStar z.val hnew
  have holdStar : C.isDStar z.val = false := by simp [isDStar, hold]
  have hs := Finset.single_le_sum (s := (Finset.univ : Finset (Fin n)))
    (f := fun w => D.credit2 w - C.credit2 w) (fun _ _ => Nat.zero_le _) (Finset.mem_univ z)
  simp [credit2, indicator, hold, holdStar, hnew, hnewD] at hs
  exact hs

/-- If the retained original gate `s` reads `z`, is the unique nonlinear
reader of `z`, and itself has one nonlinear reader after restriction, then
`z` has the two-level credit in the restricted circuit. This transports the
trace's original gate index to the actual reindexed circuit. -/
theorem fix_DStar_of_kept_chain {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (z : Fin n) (s : Nat) (g : Table) (a d : Nat)
    (hgate : C.gateAt s = some (g,a,d))
    (hkept : C.isKept (fixRes P c) s = true)
    (hzD : C.keptIsD (fixRes P c) z.val = true)
    (hsD : C.keptIsD (fixRes P c) s = true)
    (hread : (C.resAt (fixRes P c) a).hits z.val = true ∨
      (C.resAt (fixRes P c) d).hits z.val = true) :
    (C.restrict (fixSubst P c)).isDStar z.val = true := by
  obtain ⟨k,g',a',d',hk,href,hfirst,hread'⟩ :=
    C.restrict_kept_readers (fixSubst P c) (fixRes P c) Fin.val
      Fin.val_injective (fun w => w.isLt) (fixSubst_rel P c) s g a d hgate hkept
  have hkD : (C.restrict (fixSubst P c)).isD k = true := by
    have heq : (C.restrict (fixSubst P c)).isD k = C.keptIsD (fixRes P c) s := by
      simp only [isD, keptIsD, href, hfirst]
    rw [heq, hsD]
  have hzD' : (C.restrict (fixSubst P c)).isD z.val = true := by
    rw [(C.fix_transfer P c).2.2.2 z, hzD]
  have hkread : k ∈ (C.restrict (fixSubst P c)).users z.val :=
    (C.restrict (fixSubst P c)).mem_users.mpr ⟨g',a',d',hk,(hread' z).mpr hread⟩
  exact ((C.restrict (fixSubst P c)).isDStar_iff z.val).mpr ⟨hzD',k,hkread,hkD⟩

/-- The trace conditions used in the paper imply two actual new credits. -/
theorem fix_gain_two_of_kept_chain {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (z : Fin n) (s : Nat) (g : Table) (a d : Nat)
    (hold : C.isD z.val = false) (hgate : C.gateAt s = some (g,a,d))
    (hkept : C.isKept (fixRes P c) s = true)
    (hzD : C.keptIsD (fixRes P c) z.val = true)
    (hsD : C.keptIsD (fixRes P c) s = true)
    (hread : (C.resAt (fixRes P c) a).hits z.val = true ∨
      (C.resAt (fixRes P c) d).hits z.val = true) :
    2 ≤ C.credit2Gained (C.restrict (fixSubst P c)) :=
  C.credit2Gained_ge_two_of_new_DStar _ z hold
    (C.fix_DStar_of_kept_chain P c z s g a d hgate hkept hzD hsD hread)

end OpenCircuit

namespace MAContext
open OpenCircuit

/-- Tight-branch accounting: three eliminated role-free nonlinear gates
and two gained credits give the required fourteen-unit drop. -/
theorem tight_drop_of_three_rolefree_and_two_gains {n : Nat}
    {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (x : Fin n) (b : Bool) (hx2 : 2 ≤ C.refCount x.val)
    (E : Finset Nat) (hcard : 3 ≤ E.card)
    (hE : ∀ k ∈ E, C.isAliased (singleRes x b) k = true ∧
      (C.tableAt k).parity = false ∧
      (k ∈ C.users x.val ∨ ∃ P g a d, C.gateAt P = some (g,a,d) ∧
        a < n ∧ d < n ∧ k ∈ C.users P))
    (hgain : 2 ≤ C.credit2Gained (C.restrict (singleSubst x b))) :
    (C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2 := by
  have hsub : E ⊆ Finset.range (n + C.size) := by
    intro k hk
    have ha := (hE k hk).1
    cases hg : C.gateAt k with
    | none => simp [OpenCircuit.isAliased, hg] at ha
    | some p =>
      obtain ⟨g,a,d⟩ := p
      exact Finset.mem_range.mpr (C.gateAt_bounds hg).2.1
  have hcount := C.aliasedCount_ge_card (singleRes x b) E hsub (fun k hk => (hE k hk).1)
  have hd := h.twoLevel_single_drop_with_primary_successors x b hx2 E hE
  omega

end MAContext
end SatLowerBound
