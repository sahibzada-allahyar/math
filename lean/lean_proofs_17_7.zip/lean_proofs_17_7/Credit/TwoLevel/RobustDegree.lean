import Credit.TwoLevel.RobustComposition
import SatLowerBound.CompositionDegree

/-! Algebraic degree of robust-block compositions. -/
namespace SatLowerBound
namespace OpenCircuit

/-- Every binary gate kept by restriction has the original nonlinear status. -/
theorem simplifyGate_binary_nonlinearCount {n : Nat} (g t : Table)
    (s₁ s₂ : Signal n) (i j : Fin n) (hs : simplifyGate g s₁ s₂ = .binary t i j) :
    t.nonlinearCount = g.nonlinearCount := by
  cases s₁ with
  | constant a => cases s₂ <;> simp [simplifyGate] at hs
  | wire a na =>
    cases s₂ with
    | constant b => simp [simplifyGate] at hs
    | wire b nb =>
      simp only [simplifyGate] at hs
      split at hs
      · contradiction
      · unfold GateStep.classify at hs
        split at hs
        · contradiction
        · split at hs
          · contradiction
          · cases hs
            simp [Table.nonlinearCount,twist_nonlinear]

/-- A restriction compiler cannot increase the number of nonlinear gates. -/
theorem restrict_nonlinearCount_le {n m : Nat} (C : OpenCircuit n) (σ : Fin n → Signal m) :
    (C.restrict σ).nonlinearCount ≤ C.nonlinearCount := by
  induction C generalizing m with
  | output o => simp [restrict,nonlinearCount]
  | @gate n g i j rest ih =>
    simp only [restrict]
    split
    · exact Nat.le_trans (ih _) (Nat.le_add_left _ _)
    · rename_i t a b hs
      have he := simplifyGate_binary_nonlinearCount g t (σ i) (σ j) a b hs
      simp only [nonlinearCount,he]
      exact Nat.add_le_add_left (ih _) _

end OpenCircuit
namespace RobustTree

/-- Number of coordinates in all leaf supports, counted blockwise. -/
def inputs {n : Nat} : RobustTree n → Nat
  | .leaf _ S => S.card
  | .branch _ a b => a.inputs + b.inputs

/-- Express one block on consecutively indexed local coordinates. -/
noncomputable def leafLocal {n : Nat} (f : (Fin n → Bool) → Bool) (S : Finset (Fin n))
    (v : Fin S.card → Bool) : Bool :=
  f (fun z => if hz : z ∈ S then v (S.equivFin ⟨z,hz⟩) else false)

/-- The corresponding consecutive-coordinate read-once tree. -/
noncomputable def packed {n : Nat} : (T : RobustTree n) → ReadOnce T.inputs
  | .leaf f S => .leaf (leafLocal f S)
  | .branch p a b => .branch p a.packed b.packed

noncomputable def coordinate {n : Nat} : (T : RobustTree n) → Fin T.inputs → Fin n
  | .leaf _ S, i => (S.equivFin.symm i).val
  | .branch _ a b, i => Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i

theorem coordinate_mem {n : Nat} (T : RobustTree n) (i : Fin T.inputs) :
    T.coordinate i ∈ T.support := by
  induction T with
  | leaf f S => exact (S.equivFin.symm i).property
  | branch p a b iha ihb =>
    change Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i ∈ a.support ∪ b.support
    induction i using Fin.addCases with
    | left i => simpa only [Fin.addCases_left] using Finset.mem_union_left b.support (iha i)
    | right i => simpa only [Fin.addCases_right] using Finset.mem_union_right a.support (ihb i)

theorem coordinate_injective {n k : Nat} (T : RobustTree n) (ρ : Fin n → Option Bool)
    (hv : T.Valid k ρ) : Function.Injective T.coordinate := by
  induction T with
  | leaf f S =>
    intro i j h
    exact S.equivFin.symm.injective (Subtype.ext h)
  | branch p a b iha ihb =>
    intro i j h
    change Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i =
      Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate j at h
    induction i using Fin.addCases <;> induction j using Fin.addCases
    · simp only [Fin.addCases_left] at h
      exact congrArg (Fin.castAdd _) (iha hv.1 h)
    · simp only [Fin.addCases_left,Fin.addCases_right] at h
      exact False.elim (Finset.disjoint_left.mp hv.2.2 (a.coordinate_mem _) (h.symm ▸ b.coordinate_mem _))
    · simp only [Fin.addCases_left,Fin.addCases_right] at h
      exact False.elim (Finset.disjoint_left.mp hv.2.2 (h ▸ a.coordinate_mem _) (b.coordinate_mem _))
    · simp only [Fin.addCases_right] at h
      exact congrArg (Fin.natAdd _) (ihb hv.2.1 h)

/-- Packing and unpacking preserve evaluation, using the leaf support proofs. -/
theorem packed_eval {n k : Nat} (T : RobustTree n) (ρ : Fin n → Option Bool)
    (hv : T.Valid k ρ) (v : Fin n → Bool) :
    T.packed.eval (fun i => v (T.coordinate i)) = T.eval v := by
  induction T with
  | leaf f S =>
    change f (fun z => if hz : z ∈ S then v ((S.equivFin.symm (S.equivFin ⟨z,hz⟩)).val) else false) = f v
    apply hv.1.supported
    intro z hz
    simp [hz]
  | branch p a b iha ihb =>
    change (if p then
      a.packed.eval (leftBits (fun i => v (Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i))) ||
        b.packed.eval (rightBits (fun i => v (Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i)))
      else a.packed.eval (leftBits (fun i => v (Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i))) &&
        b.packed.eval (rightBits (fun i => v (Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i)))) = _
    have hl : leftBits (fun i => v ((branch p a b).coordinate i)) = (fun i => v (a.coordinate i)) := by
      funext i
      exact congrArg v (Fin.addCases_left i)
    have hr : rightBits (fun i => v ((branch p a b).coordinate i)) = (fun i => v (b.coordinate i)) := by
      funext i
      exact congrArg v (Fin.addCases_right i)
    change leftBits (fun i => v (Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i)) = _ at hl
    change rightBits (fun i => v (Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i)) = _ at hr
    rw [hl,hr,iha hv.1,ihb hv.2.1]
    rfl

/-- A leaf has full algebraic degree in its own block coordinates. -/
def FullLeaves {n : Nat} : RobustTree n → Prop
  | .leaf f S => 0 < S.card ∧ (BPoly.ofFunction S.card (leafLocal f S)).topCoefficient = true
  | .branch _ a b => a.FullLeaves ∧ b.FullLeaves

theorem packed_full {n : Nat} (T : RobustTree n) (h : T.FullLeaves) : T.packed.FullLeaves := by
  induction T with
  | leaf f S => exact h
  | branch p a b iha ihb => exact ⟨iha h.1,ihb h.2⟩

theorem inputs_eq_card {n k : Nat} (T : RobustTree n) (ρ : Fin n → Option Bool)
    (h : T.Valid k ρ) : T.inputs = T.support.card := by
  induction T with
  | leaf f S => rfl
  | branch p a b iha ihb =>
    simp only [inputs,support,Finset.card_union_of_disjoint h.2.2,iha h.1,ihb h.2.1]

/-- Full degree of the leaves forces at least `inputs - 1` nonlinear gates in
an arbitrary circuit computing the original shared-input composition. -/
theorem nonlinear_lower_bound_of_full_leaves {n k : Nat} (T : RobustTree n)
    (ρ : Fin n → Option Bool) (hv : T.Valid k ρ) (hfull : T.FullLeaves)
    (C : OpenCircuit n) (hc : ∀ v, C.eval v = T.eval v) :
    T.inputs ≤ C.nonlinearCount + 1 := by
  classical
  have hp := T.packed.inputs_positive (T.packed_full hfull)
  let r : Fin n → Fin T.inputs := fun x =>
    if h : ∃ i, T.coordinate i = x then Classical.choose h else ⟨0,hp⟩
  have hr (i : Fin T.inputs) : r (T.coordinate i) = i := by
    dsimp [r]
    split
    · rename_i h
      exact T.coordinate_injective ρ hv (Classical.choose_spec h)
    · rename_i h
      exact False.elim (h ⟨i,rfl⟩)
  let σ : Fin n → Signal T.inputs := fun x => .wire (r x) false
  have he : ∀ v, (C.restrict σ).eval v = T.packed.eval v := by
    intro v
    rw [C.restrict_eval,hc]
    simp only [σ,Signal.eval,Bool.xor_false]
    rw [← T.packed_eval ρ hv (fun x => v (r x))]
    congr 1
    funext i
    rw [hr]
  have hb := (C.restrict σ).nonlinear_lower_bound T.packed.eval he (T.packed.full_degree (T.packed_full hfull))
  have hn := C.restrict_nonlinearCount_le σ
  omega

/-- Theorem 8.1's size inequality from full-degree leaves, without assuming
full degree of their composition as a separate premise. -/
theorem full_leaves_size {n k : Nat} (hk : 2 ≤ k) (T : RobustTree n)
    (hT : T.Valid k (fun _ => none)) (hs : T.support = Finset.univ) (hfull : T.FullLeaves)
    (C : OpenCircuit n) (hc : ∀ v, C.eval v = T.eval v) :
    17 * (n : Int) - 14 * ((k : Int)+1) * T.blocks - 3 ≤ 7 * (C.size : Int) := by
  obtain ⟨D,hD,htri,hsize,_,heval⟩ := C.normalize_by_descent
  have hDe : ∀ v, D.eval v = T.eval v := fun v => (heval v).trans (hc v)
  have hDcomp : ∀ v, D.eval v = T.eval (applyPartial (fun _ => none) v) := by
    intro v
    rw [hDe]
    congr 1
  have hsupport : ∀ z, 0 < D.usage (OpenCircuit.singleUse z) → z ∈ freeOn T.support (fun _ => none) := by
    intro z _
    simp [freeOn,hs]
  have hpot := robust_tree_psi2_bound hk T (fun _ => none) hT D hD htri hDcomp hsupport
  have hcard : (freeOn T.support (fun _ => none)).card = n := by simp [freeOn,hs]
  rw [hcard] at hpot
  have hinputs : T.inputs = n := by
    rw [T.inputs_eq_card (fun _ => none) hT,hs]
    simp
  have hdegree := T.nonlinear_lower_bound_of_full_leaves (fun _ => none) hT hfull D hDe
  rw [hinputs] at hdegree
  have hsizebound := D.size_bound_of_potential (D.reduced_essential hD) n T.blocks k hpot (by omega)
  omega

end RobustTree
end SatLowerBound
