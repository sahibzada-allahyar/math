import Credit.TwoLevel.DeadGate
import Credit.TwoLevel.Cut

/-! Boolean calculation in the `V₂ = R, U₂ = V` contradiction of
Main Lemma B. -/
namespace SatLowerBound
namespace Table

/-- For a nonlinear gate, the corner opposite the two blocking inputs has
output complementary to the common blocked output. -/
theorem opposite_blocking_corner (g : Table) (a b : Bool)
    (hnl : g.nonlinear = true) (ha : g.blocksLeft a = true)
    (hb : g.blocksRight b = true) : g.eval (!a) (!b) = !(g.eval a b) := by
  revert hnl ha hb
  rcases g with ⟨ff,ft,tf,tt⟩
  cases a <;> cases b <;> cases ff <;> cases ft <;> cases tf <;> cases tt <;> decide

/-- In a nonblocking column, flipping the other input flips the output. -/
theorem nonblocking_column_flip (g : Table) (a b : Bool)
    (hb : g.blocksRight b = false) : g.eval (!a) b = !(g.eval a b) := by
  revert hb
  rcases g with ⟨ff,ft,tf,tt⟩
  cases a <;> cases b <;> cases ff <;> cases ft <;> cases tf <;> cases tt <;> decide

/-- For a nonlinear table, the other input value is the blocking value. -/
theorem blocksLeft_not_of_false (g : Table) (a : Bool)
    (hnl : g.nonlinear = true) (ha : g.blocksLeft a = false) : g.blocksLeft (!a) = true := by
  have hh := g.nonlinear_blocksLeft hnl
  cases a <;> cases h : g.blocksLeft false <;> simp_all

theorem blocksRight_not_of_false (g : Table) (a : Bool)
    (hnl : g.nonlinear = true) (ha : g.blocksRight a = false) : g.blocksRight (!a) = true := by
  have hh := g.nonlinear_blocksRight hnl
  cases a <;> cases h : g.blocksRight false <;> simp_all

/-- In the last both-bad overlap, after blocking `U`, the two possible
values of `y` block opposite operands of `R`. Thus its output is constant.
The assumptions directly name the blocking values and constants used in the
manuscript; `v` receives `y` on its left and the constant output of `U` on its
right. -/
theorem opposite_bad_chain_constant (t v r : Table) (ε δ u : Bool)
    (ht : t.nonlinear = true) (htx : t.blocksLeft ε = true)
    (hty : t.blocksRight δ = true)
    (hvx : v.blocksLeft (!δ) = true) (hvu : v.blocksRight u = false)
    (hr : r.nonlinear = true)
    (hrt : r.blocksLeft (t.eval ε δ) = false)
    (hrv : r.blocksRight (v.eval (!δ) u) = false) :
    ∀ y, r.eval (t.eval (!ε) y) (v.eval y u) =
      r.eval (!(t.eval ε δ)) (!(v.eval (!δ) u)) := by
  have hrt' := r.blocksLeft_not_of_false (t.eval ε δ) hr hrt
  have hrv' := r.blocksRight_not_of_false (v.eval (!δ) u) hr hrv
  have htflip := t.opposite_blocking_corner ε δ ht htx hty
  have hvflip := v.nonblocking_column_flip (!δ) u hvu
  intro y
  by_cases hy : y = δ
  · subst y
    have hv : v.eval δ u = !(v.eval (!δ) u) := by simpa using hvflip
    rw [hv, r.blocksRight_eval _ hrv']
    exact (r.blocksRight_eval _ hrv' _).symm
  · have hy' : y = !δ := by cases y <;> cases δ <;> simp_all
    rw [hy', htflip, r.blocksLeft_eval _ hrt']
    exact (r.blocksLeft_eval _ hrt' _).symm

end Table

namespace OpenCircuit

/-- A physical binary gate presented with a chosen operand orientation. -/
def OrientedSignalGate {n : Nat} (C : OpenCircuit n) (k a b : Nat) (g : Table) : Prop :=
  C.gateAt k = some (g,a,b) ∨ C.gateAt k = some (g.swap,b,a)

theorem orientedSignalGate_value {n : Nat} (C : OpenCircuit n) (k a b : Nat) (g : Table)
    (hg : C.OrientedSignalGate k a b g) (v : Fin n → Bool) :
    C.valueAt v k = g.eval (C.valueAt v a) (C.valueAt v b) := by
  rcases hg with hg | hg
  · exact C.valueAt_gate v hg
  · rw [C.valueAt_gate v hg, Table.swap_eval]

/-- If all dependence on `y` passes through `T` or `V`, and both gates
feed only `R`, equality at `R` cuts the influence of `y` on the output. -/
theorem eval_eq_of_two_branch_funnel {n : Nat} (C : OpenCircuit n)
    (y : Fin n) (T V R : Nat) (u w : Fin n → Bool)
    (hinputs : ∀ z, z ≠ y → u z = w z)
    (hy : ∀ k ∈ C.users y.val, k = T ∨ k = V)
    (hT : ∀ k ∈ C.users T, k = R) (hV : ∀ k ∈ C.users V, k = R)
    (hR : C.valueAt u R = C.valueAt w R)
    (hout : ∀ k b, C.outWire = some (k,b) → k ≠ y.val ∧ k ≠ T ∧ k ≠ V) :
    C.eval u = C.eval w := by
  have hsig : ∀ k, k < n + C.size → k ≠ y.val → k ≠ T → k ≠ V →
      C.valueAt u k = C.valueAt w k := by
    intro k
    induction k using Nat.strong_induction_on with
    | h k ih =>
      intro hk hky hkT hkV
      by_cases hkR : k = R
      · simpa [hkR] using hR
      by_cases hkn : k < n
      · let z : Fin n := ⟨k,hkn⟩
        have hzy : z ≠ y := fun he => hky (congrArg Fin.val he)
        change C.valueAt u z.val = C.valueAt w z.val
        exact (C.valueAt_input u z).trans ((hinputs z hzy).trans (C.valueAt_input w z).symm)
      · obtain ⟨g,a,b,hgate⟩ := C.gateAt_exists (by omega) hk
        obtain ⟨_,_,ha,hb⟩ := C.gateAt_bounds hgate
        have hop : ∀ o, (a = o ∨ b = o) → o < k → C.valueAt u o = C.valueAt w o := by
          intro o ho holt
          have hm : k ∈ C.users o := C.mem_users.mpr ⟨g,a,b,hgate,ho⟩
          refine ih o holt (by omega) ?_ ?_ ?_
          · intro he
            rw [he] at hm
            rcases hy k hm with he' | he' <;> contradiction
          · intro he
            rw [he] at hm
            exact hkR (hT k hm)
          · intro he
            rw [he] at hm
            exact hkR (hV k hm)
        rw [C.valueAt_gate u hgate, C.valueAt_gate w hgate,
          hop a (Or.inl rfl) ha, hop b (Or.inr rfl) hb]
  cases hw : C.outWire with
  | none => exact C.eval_const_of_outWire_none hw u w
  | some p =>
    obtain ⟨k,neg⟩ := p
    obtain ⟨hky,hkT,hkV⟩ := hout k neg hw
    rw [C.eval_of_outWire u hw, C.eval_of_outWire w hw,
      hsig k (C.outWire_bound hw) hky hkT hkV]

end OpenCircuit

namespace MAContext
open OpenCircuit

/-- The opposite-blocking overlap is incompatible with E1 once its circuit
signals have the factorization displayed in the paper. -/
theorem opposite_bad_funnel_impossible {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x y : Fin n) (hxy : x ≠ y)
    (T V R : Nat) (hy : ∀ k ∈ C.users y.val, k = T ∨ k = V)
    (hT : ∀ k ∈ C.users T, k = R) (hV : ∀ k ∈ C.users V, k = R)
    (hout : ∀ k b, C.outWire = some (k,b) → k ≠ y.val ∧ k ≠ T ∧ k ≠ V)
    (hyess : Essential f y) (t v r : Table) (ε δ u : Bool)
    (ht : t.nonlinear = true) (htx : t.blocksLeft ε = true)
    (hty : t.blocksRight δ = true) (hvx : v.blocksLeft (!δ) = true)
    (hvu : v.blocksRight u = false) (hr : r.nonlinear = true)
    (hrt : r.blocksLeft (t.eval ε δ) = false)
    (hrv : r.blocksRight (v.eval (!δ) u) = false)
    (hfactor : ∀ a, C.valueAt (fixBit x (!ε) a) R =
      r.eval (t.eval (!ε) (a y)) (v.eval (a y) u)) : False := by
  obtain ⟨p,q,hagree,hdiff⟩ := h.good.e1 x (!ε) y (Ne.symm hxy) hyess
  apply hdiff
  have hin : ∀ z, z ≠ y → fixBit x (!ε) p z = fixBit x (!ε) q z := by
    intro z hz
    simp [fixBit, hagree z hz]
  have heqR : C.valueAt (fixBit x (!ε) p) R = C.valueAt (fixBit x (!ε) q) R := by
    rw [hfactor, hfactor, t.opposite_bad_chain_constant v r ε δ u ht htx hty hvx hvu hr hrt hrv,
      t.opposite_bad_chain_constant v r ε δ u ht htx hty hvx hvu hr hrt hrv]
  have heval := C.eval_eq_of_two_branch_funnel y T V R (fixBit x (!ε) p) (fixBit x (!ε) q)
    hin hy hT hV heqR hout
  simpa only [h.computes] using heval

/-- Circuit-wiring version of the paper's opposite-blocking contradiction.
Physical operands may occur in either order; the oriented tables always
describe the inputs in the order used in the manuscript. -/
theorem opposite_bad_wiring_impossible {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x y : Fin n) (hxy : x ≠ y)
    (T U V R other : Nat) (t u v r : Table) (ε δ : Bool)
    (hTgate : C.OrientedPairGate T x y t)
    (hUgate : C.OrientedSignalGate U x.val other u)
    (hVgate : C.OrientedSignalGate V y.val U v)
    (hRgate : C.OrientedSignalGate R T V r)
    (hy : C.users y.val = {T,V}) (hT : C.users T = {R}) (hV : C.users V = {R})
    (ht : t.nonlinear = true) (htx : t.blocksLeft ε = true)
    (hty : t.blocksRight δ = true) (hu : u.blocksLeft (!ε) = true)
    (hvx : v.blocksLeft (!δ) = true)
    (hvu : v.blocksRight (u.eval (!ε) false) = false) (hr : r.nonlinear = true)
    (hrt : r.blocksLeft (t.eval ε δ) = false)
    (hrv : r.blocksRight (v.eval (!δ) (u.eval (!ε) false)) = false) : False := by
  have hTy : T ∈ C.users y.val := by rw [hy]; simp
  have hR_T : R ∈ C.users T := by rw [hT]; simp
  have hR_V : R ∈ C.users V := by rw [hV]; simp
  have hyess : Essential f y := h.usedEssential y (by
    rw [C.usage_singleUse, h.refCount_input y]
    exact Finset.card_pos.mpr ⟨T,hTy⟩)
  have hyread : ∀ k ∈ C.users y.val, k = T ∨ k = V := by
    intro k hk
    simpa [hy] using hk
  have hTread : ∀ k ∈ C.users T, k = R := by
    intro k hk
    simpa [hT] using hk
  have hVread : ∀ k ∈ C.users V, k = R := by
    intro k hk
    simpa [hV] using hk
  have hTzero := C.reduced_outIs_zero_of_user h.reduced T (Finset.ne_empty_of_mem hR_T)
  have hVzero := C.reduced_outIs_zero_of_user h.reduced V (Finset.ne_empty_of_mem hR_V)
  have hyzero := h.outIs_input y
  have hout : ∀ k b, C.outWire = some (k,b) → k ≠ y.val ∧ k ≠ T ∧ k ≠ V := by
    intro k b hk
    constructor
    · intro he; simp [outIs,hk,he] at hyzero
    constructor
    · intro he; simp [outIs,hk,he] at hTzero
    · intro he; simp [outIs,hk,he] at hVzero
  have hfactor : ∀ a, C.valueAt (fixBit x (!ε) a) R =
      r.eval (t.eval (!ε) (a y)) (v.eval (a y) (u.eval (!ε) false)) := by
    intro a
    have hx : fixBit x (!ε) a x = !ε := by simp [fixBit]
    have hy' : fixBit x (!ε) a y = a y := by simp [fixBit,Ne.symm hxy]
    have hTv : C.valueAt (fixBit x (!ε) a) T = t.eval (!ε) (a y) := by
      rw [C.orientedPairGate_value T x y t hTgate, hx, hy']
    have hUv : C.valueAt (fixBit x (!ε) a) U = u.eval (!ε) false := by
      rw [C.orientedSignalGate_value U x.val other u hUgate, C.valueAt_input, hx,
        u.blocksLeft_eval (!ε) hu]
    have hVv : C.valueAt (fixBit x (!ε) a) V = v.eval (a y) (u.eval (!ε) false) := by
      rw [C.orientedSignalGate_value V y.val U v hVgate, C.valueAt_input, hy', hUv]
    rw [C.orientedSignalGate_value R T V r hRgate, hTv, hVv]
  exact h.opposite_bad_funnel_impossible x y hxy T V R hyread hTread hVread hout hyess
    t v r ε δ (u.eval (!ε) false) ht htx hty hvx hvu hr hrt hrv hfactor

end MAContext
end SatLowerBound
