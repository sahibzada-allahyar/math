import Credit.TwoLevel.Corner

/-! A circuit factorization for the first two gates of the corner configuration.
This is a special case: the paper also permits gates between the two readers.
-/
namespace SatLowerBound
namespace OpenCircuit

/-- If the only uses of `i` and `j` are as operands of two consecutive gates,
all subsequent dependence on those inputs goes through their two gate outputs. -/
theorem first_two_gates_factor {n : Nat} (t u : Table) (i j : Fin n)
    (rest : OpenCircuit (n + 2)) (hij : i ≠ j)
    (hi : (OpenCircuit.gate t i j (.gate u i.castSucc j.castSucc rest)).usage (singleUse i) = 2)
    (hj : (OpenCircuit.gate t i j (.gate u i.castSucc j.castSucc rest)).usage (singleUse j) = 2) :
    ∃ H : (Bool × Bool) → (Fin n → Bool) → Bool, ∀ a b x,
      (OpenCircuit.gate t i j (.gate u i.castSucc j.castSucc rest)).eval (setPair x i j a b) =
        H (t.eval a b, u.eval a b) x := by
  have hi0 : rest.usage (appendValue (appendValue (singleUse i) 0) 0) = 0 := by
    simp only [usage, singleUse, Fin.val_castSucc, appendValue,
      i.isLt, j.isLt, ↓reduceDIte, ↓reduceIte, Ne.symm hij] at hi
    omega
  have hj0 : rest.usage (appendValue (appendValue (singleUse j) 0) 0) = 0 := by
    simp only [usage, singleUse, Fin.val_castSucc, appendValue,
      i.isLt, j.isLt, ↓reduceDIte, ↓reduceIte, hij] at hj
    omega
  let p : Fin (n + 2) → Nat := fun k =>
    appendValue (appendValue (singleUse i) 0) 0 k +
    appendValue (appendValue (singleUse j) 0) 0 k
  have hp : rest.usage p = 0 := by
    simp only [p, usage_add, hi0, hj0, Nat.add_zero]
  refine ⟨fun v x => rest.eval (extend (extend x v.1) v.2), ?_⟩
  intro a b x
  have hai : setPair x i j a b i = a := by simp [setPair]
  have hbj : setPair x i j a b j = b := by simp [setPair, Ne.symm hij]
  simp only [eval, extend_old, hai, hbj]
  apply rest.eval_eq_of_zero_usage p hp
  intro k hk
  simp only [p, appendValue] at hk
  simp only [extend]
  split at hk
  · rename_i hk1
    simp only [hk1, ↓reduceDIte]
    split at hk
    · rename_i hk0
      simp only [hk0, ↓reduceDIte]
      have hki : (⟨k.val, hk0⟩ : Fin n) ≠ i := by
        intro he
        simp [he, singleUse] at hk
      have hkj : (⟨k.val, hk0⟩ : Fin n) ≠ j := by
        intro he
        simp [he, singleUse] at hk
      simp [setPair, hki, hkj]
    · rename_i hk0
      simp only [hk0, ↓reduceDIte]
  · rename_i hk1
    simp only [hk1, ↓reduceDIte]

/-- Corner exclusion for consecutive readers. The full manuscript permits
intermediate gates; that generalization is not asserted by this lemma. -/
theorem no_opposite_blocking_consecutive {n : Nat} (t u : Table) (i j : Fin n)
    (rest : OpenCircuit (n + 2)) (hij : i ≠ j)
    (hi : (OpenCircuit.gate t i j (.gate u i.castSucc j.castSucc rest)).usage (singleUse i) = 2)
    (hj : (OpenCircuit.gate t i j (.gate u i.castSucc j.castSucc rest)).usage (singleUse j) = 2)
    (hT : t.nonlinear = true) (hU : u.nonlinear = true) (ε : Bool)
    (hTb : t.blocksLeft ε = true) (hUb : u.blocksLeft (!ε) = true)
    (hS4 : S4 (OpenCircuit.gate t i j (.gate u i.castSucc j.castSucc rest)).eval) : False := by
  obtain ⟨H, hH⟩ := first_two_gates_factor t u i j rest hij hi hj
  apply FourRows.no_opposite_blocking_factor (hS4 i j hij) t u ε hT hU hTb hUb H
  intro p x
  exact hH p.1 p.2 x

end OpenCircuit
end SatLowerBound
