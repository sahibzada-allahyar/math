import Credit.TwoLevel.TriangleWeight

/-! The syntactic shape of the intermediate triangle rewrite in Lemma 6.12. -/
namespace SatLowerBound
namespace Table

set_option maxRecDepth 4096 in
/-- If both original gates are essential, their triangle composite is never
parity. It is therefore either nonlinear or degenerate. -/
theorem triangle_not_parity (p q : Table) (hp : p.essential = true)
    (hq : q.essential = true) : (triangle p q).parity = false := by
  revert hp hq
  rcases p with ⟨a,b,c,d⟩
  rcases q with ⟨e,f,g,h⟩
  cases a <;> cases b <;> cases c <;> cases d <;>
    cases e <;> cases f <;> cases g <;> cases h <;> decide

/-- The only weights of the triangle replacement are zero and four. -/
theorem triangle_psi2W_zero_or_four (p q : Table) (hp : p.essential = true)
    (hq : q.essential = true) : (triangle p q).psi2W = 0 ∨ (triangle p q).psi2W = 4 := by
  have hpar := triangle_not_parity p q hp hq
  unfold psi2W parityCount nonlinearCount nonlinear
  rw [hpar]
  cases (triangle p q).essential <;> decide

end Table
namespace OpenCircuit
namespace PsiTriangleAux

/-- The replacement instruction is present at the requested global index. -/
theorem replaceAt_gateAt_self {n : Nat} (C : OpenCircuit n) {q : Nat}
    {g : Table} {i j : Nat} (hq : C.gateAt q = some (g,i,j))
    (f : Table) {a b : Nat} (ha : a < q) (hb : b < q) :
    (replaceAt C q f a b).gateAt q = some (f,a,b) := by
  induction C with
  | output o => simp [gateAt] at hq
  | @gate n t x y rest ih =>
    by_cases he : q = n
    · subst q
      rw [replaceAt_head t f x y rest ha hb,gateAt_head]
    · rw [replaceAt_tail t f x y rest he,gateAt_tail t x y _ he]
      rw [gateAt_tail t x y rest he] at hq
      exact ih hq

/-- If the replacement uses distinct operands, all operand pairs remain
 distinct even if the replacement table is degenerate. -/
theorem replaceAt_distinct_operands {n : Nat} (C : OpenCircuit n) (hr : C.Reduced)
    (q : Nat) (f : Table) (x u : Nat) (hxu : x ≠ u) :
    (replaceAt C q f x u).DistinctOperands := by
  intro k g a b hk
  by_cases hkq : k = q
  · subst k
    induction C with
    | output o => simp [replaceAt,gateAt] at hk
    | @gate n t i j rest ih =>
      by_cases hrep : q = n ∧ x < n ∧ u < n
      · rw [hrep.1,replaceAt_head t f i j rest hrep.2.1 hrep.2.2,gateAt_head] at hk
        simp only [Option.some.injEq,Prod.mk.injEq] at hk
        obtain ⟨_,ha,hb⟩ := hk
        simpa [← ha,← hb] using hxu
      · have hre : replaceAt (gate t i j rest) q f x u =
            gate t i j (replaceAt rest q f x u) := dite_eq_right hrep
        rw [hre] at hk
        by_cases hqn : q = n
        · subst q
          simp only [gateAt_head,Option.some.injEq,Prod.mk.injEq] at hk
          obtain ⟨_,ha,hb⟩ := hk
          have hd := hr.2.1
          intro he
          exact hd (Fin.ext (ha.trans (he.trans hb.symm)))
        · rw [gateAt_tail t i j _ hqn] at hk
          exact ih hr.2.2.2 hk
  · rw [replaceAt_gateAt_of_ne C q f x u k hkq] at hk
    exact (C.reduced_gate hr hk).2.1

/-- Pointwise gate properness gives the recursive circuit invariant. -/
theorem gateProper_of_pointwise {n : Nat} (C : OpenCircuit n)
    (h : ∀ k g a b, C.gateAt k = some (g,a,b) → g.essential = true ∧ a ≠ b) :
    C.GateProper := by
  induction C with
  | output o => trivial
  | @gate n g i j rest ih =>
    have hh := h n g i.val j.val (gateAt_head g i j rest)
    refine ⟨hh.1,?_,ih ?_⟩
    · intro he
      exact hh.2 (congrArg Fin.val he)
    · intro k t a b hk
      have hkn : k ≠ n := by have := (rest.gateAt_bounds hk).1; omega
      exact h k t a b ((gateAt_tail g i j rest hkn).trans hk)

/-- An essential triangle replacement leaves a proper (possibly non-live)
circuit. Thus only the degenerate-table branch needs resolution. -/
theorem replaceAt_proper_of_essential {n : Nat} (C : OpenCircuit n) (hr : C.Reduced)
    {q : Nat} {g f : Table} {i j x u : Nat} (hq : C.gateAt q = some (g,i,j))
    (hx : x < q) (hu : u < q) (hxu : x ≠ u) (hf : f.essential = true) :
    (replaceAt C q f x u).GateProper := by
  apply gateProper_of_pointwise
  intro k t a b hk
  have hdist := replaceAt_distinct_operands C hr q f x u hxu k t a b hk
  refine ⟨?_,hdist⟩
  by_cases he : k = q
  · subst k
    have hh := replaceAt_gateAt_self C hq f hx hu
    rw [hh] at hk
    simp only [Option.some.injEq,Prod.mk.injEq] at hk
    rw [← hk.1]
    exact hf
  · have ho := (replaceAt_gateAt_of_ne C q f x u k he).symm.trans hk
    exact C.essentialGates_gate (C.reduced_essential hr) ho

/-- Potential does not increase at the concrete rewritten circuit. -/
theorem replaceAt_twoLevel_potential_le {n : Nat} (C : OpenCircuit n)
    (hsafe : C.DGateSafe) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z)
    {q x P u : Nat} {g p f : Table} {i j c d : Nat}
    (hq : C.gateAt q = some (g,i,j)) (hij : (i = x ∧ j = P) ∨ (i = P ∧ j = x))
    (hx : x < n) (hP : C.gateAt P = some (p,c,d))
    (hcd : (c = x ∧ d = u) ∨ (c = u ∧ d = x)) (hw : f.psi2W ≤ g.psi2W) :
    (replaceAt C q f x u).psi2 ≤ C.psi2 := by
  obtain ⟨_,_,hiq,hjq⟩ := C.gateAt_bounds hq
  obtain ⟨_,_,hcP,hdP⟩ := C.gateAt_bounds hP
  have hPq : P < q := by rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have hxq : x < q := by rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have huP : u < P := by rcases hcd with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have huq : u < q := by omega
  have hweight := replaceAt_psi2Weight C (f := f) hq hxq huq
  have hd : C.dCount ≤ (replaceAt C q f x u).dCount :=
    dCount_mono C _ (replaceAt_preserves_D_triangle C hsafe hq hij hx hP hcd)
  have hstar : C.dStarCount ≤ (replaceAt C q f x u).dStarCount := by
    unfold dStarCount
    refine Finset.sum_le_sum fun z _ => ?_
    show indicator (C.isDStar z.val) ≤ indicator ((replaceAt C q f x u).isDStar z.val)
    cases hz : C.isDStar z.val with
    | false => exact Nat.zero_le _
    | true => exact Nat.le_of_eq (by rw [replaceAt_preserves_DStar_triangle C hsafe hE1 hused hq hij hx hP hcd z hz])
  unfold psi2
  omega

/-- If the replacement table remains essential, rewrite and dead-gate pruning
produce an equivalent reduced circuit of no greater two-level potential. -/
theorem essential_triangle_reduced {n : Nat} (h2 : 2 ≤ n) (C : OpenCircuit n)
    (hr : C.Reduced) (hsafe : C.DGateSafe) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z)
    {q x P u : Nat} {g p f : Table} {i j c d : Nat}
    (hq : C.gateAt q = some (g,i,j)) (hij : (i = x ∧ j = P) ∨ (i = P ∧ j = x))
    (hx : x < n) (hP : C.gateAt P = some (p,c,d))
    (hcd : (c = x ∧ d = u) ∨ (c = u ∧ d = x)) (hw : f.psi2W ≤ g.psi2W)
    (hf : f.essential = true)
    (hv : ∀ v, f.eval (C.valueAt v x) (C.valueAt v u) =
      g.eval (C.valueAt v i) (C.valueAt v j)) :
    ∃ D : OpenCircuit n, D.Reduced ∧ (∀ v, D.eval v = C.eval v) ∧ D.psi2 ≤ C.psi2 ∧
      D.size ≤ C.size ∧ (D.size = C.size → D.predecessorSum < C.predecessorSum) := by
  let R := replaceAt C q f x u
  obtain ⟨_,_,hiq,hjq⟩ := C.gateAt_bounds hq
  obtain ⟨_,_,hcP,hdP⟩ := C.gateAt_bounds hP
  have hPq : P < q := by rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have hxq : x < q := by rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have huP : u < P := by rcases hcd with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have huq : u < q := by omega
  have hxu : x ≠ u := by
    have hd := (C.reduced_gate hr hP).2.1
    rcases hcd with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have hp : R.GateProper := replaceAt_proper_of_essential C hr hq hxq huq hxu hf
  have he : ∀ v, R.eval v = C.eval v := fun v => replaceAt_eval C hq hxq huq v (hv v)
  have husedR : ∀ z : Fin n, 0 < R.usage (singleUse z) → Essential R.eval z := by
    intro z hz
    have hzC : 0 < C.usage (singleUse z) := by
      rw [R.usage_singleUse] at hz
      rw [C.usage_singleUse]
      by_cases hzx : z.val = x
      · have hm : P ∈ C.users z.val := C.mem_users.mpr ⟨p,c,d,hP,by
          rcases hcd with ⟨h1,_⟩ | ⟨_,h2⟩
          · exact Or.inl (h1.trans hzx.symm)
          · exact Or.inr (h2.trans hzx.symm)⟩
        have hp := Finset.card_pos.mpr ⟨P,hm⟩
        have hg := C.refCount_ge z.val
        omega
      · by_cases hzu : z.val = u
        · have hm : P ∈ C.users z.val := C.mem_users.mpr ⟨p,c,d,hP,by
            rcases hcd with ⟨_,h2⟩ | ⟨h1,_⟩
            · exact Or.inr (h2.trans hzu.symm)
            · exact Or.inl (h1.trans hzu.symm)⟩
          have hp := Finset.card_pos.mpr ⟨P,hm⟩
          have hg := C.refCount_ge z.val
          omega
        · have hr' := replaceAt_refCount C (f := f) hq hxq huq z.val
          change R.refCount z.val + _ = _ at hr'
          have hzP : z.val ≠ P := by have := z.isLt; have := (C.gateAt_bounds hP).1; omega
          rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> split_ifs at hr' <;> omega
    obtain ⟨v,w,hvw,hne⟩ := hused z hzC
    exact ⟨v,w,hvw,by simpa only [he] using hne⟩
  have hdrop : R.psi2 ≤ C.psi2 :=
    replaceAt_twoLevel_potential_le C hsafe hE1 hused hq hij hx hP hcd hw
  have hRsize : R.size = C.size := replaceAt_size C q f x u
  have hRpred : R.predecessorSum < C.predecessorSum := by
    change (replaceAt C q f x u).predecessorSum < C.predecessorSum
    have hh := replaceAt_predecessorSum C (f := f) hq hxq huq
    rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  obtain ⟨D,hD,hDe,hDp,hDs,hDpred⟩ := R.exists_reduced_potential_le_size h2 hp husedR
  refine ⟨D,hD,fun v => (hDe v).trans (he v),le_trans hDp hdrop,by omega,?_⟩
  intro heq
  have heqR : D.size = R.size := by omega
  rw [hDpred heqR]
  exact hRpred

/-- All gates except the rewritten instruction retain exactly their table and
operands. The exceptional instruction is identified by its global index. -/
theorem triangle_other_gates_proper {n : Nat} (C : OpenCircuit n) (hr : C.Reduced)
    (q : Nat) (f : Table) (x u : Nat) :
    ∀ k g a b, k ≠ q → (replaceAt C q f x u).gateAt k = some (g,a,b) →
      g.essential = true ∧ a ≠ b := by
  intro k g a b hk hgate
  rw [replaceAt_gateAt_of_ne C q f x u k hk] at hgate
  exact ⟨C.essentialGates_gate (C.reduced_essential hr) hgate,
    (C.reduced_gate hr hgate).2.1⟩

end PsiTriangleAux
end OpenCircuit
end SatLowerBound
