import Credit.TwoLevel.DeleteDead

/-! Dead-gate credit roles without assuming the circuit has been reduced. -/
namespace SatLowerBound
namespace OpenCircuit

/-- If the only path from an input is a two-gate chain ending in a dead
gate, changing that input cannot change the output. -/
theorem eval_eq_of_dead_two_gate_chain {n : Nat} (C : OpenCircuit n)
    (z : Fin n) (W G : Nat) (u v : Fin n → Bool)
    (hin : ∀ q, q ≠ z → u q = v q)
    (hz : ∀ k ∈ C.users z.val, k = W) (hW : ∀ k ∈ C.users W, k = G)
    (hG : C.users G = ∅)
    (hout : ∀ k b, C.outWire = some (k,b) → k ≠ z.val ∧ k ≠ W ∧ k ≠ G) :
    C.eval u = C.eval v := by
  have hsig : ∀ k, k < n + C.size → k ≠ z.val → k ≠ W → k ≠ G →
      C.valueAt u k = C.valueAt v k := by
    intro k
    induction k using Nat.strong_induction_on with
    | h k ih =>
      intro hk hkz hkW hkG
      by_cases hkn : k < n
      · let q : Fin n := ⟨k,hkn⟩
        have hqz : q ≠ z := fun he => hkz (congrArg Fin.val he)
        change C.valueAt u q.val = C.valueAt v q.val
        exact (C.valueAt_input u q).trans ((hin q hqz).trans (C.valueAt_input v q).symm)
      · obtain ⟨g,a,b,hgate⟩ := C.gateAt_exists (by omega) hk
        obtain ⟨_,_,ha,hb⟩ := C.gateAt_bounds hgate
        have hop : ∀ o, (a = o ∨ b = o) → o < k → C.valueAt u o = C.valueAt v o := by
          intro o ho ho'
          have hm : k ∈ C.users o := C.mem_users.mpr ⟨g,a,b,hgate,ho⟩
          refine ih o ho' (by omega) ?_ ?_ ?_
          · intro he; rw [he] at hm; exact hkW (hz k hm)
          · intro he; rw [he] at hm; exact hkG (hW k hm)
          · intro he; rw [he,hG] at hm; simp at hm
        rw [C.valueAt_gate u hgate, C.valueAt_gate v hgate,
          hop a (Or.inl rfl) ha, hop b (Or.inr rfl) hb]
  cases hw : C.outWire with
  | none => exact C.eval_const_of_outWire_none hw u v
  | some p =>
    obtain ⟨k,b⟩ := p
    obtain ⟨hkz,hkW,hkG⟩ := hout k b hw
    rw [C.eval_of_outWire u hw, C.eval_of_outWire v hw,
      hsig k (C.outWire_bound hw) hkz hkW hkG]

/-- A dead gate cannot be the second credit gate of an essential input. -/
theorem dead_gate_not_second_role {n : Nat} (C : OpenCircuit n)
    (z : Fin n) (hz : C.isDStar z.val = true) (hess : Essential C.eval z)
    (W G : Nat) (hW : W ∈ C.users z.val) (hG : G ∈ C.users W)
    (hdead : C.refCount G = 0) : False := by
  have hDz := C.isD_of_isDStar z.val hz
  have huz := C.users_singleton_of_isD z.val W hDz hW
  have hDW : C.isD W = true := by
    obtain ⟨_,w,hw,hd⟩ := (C.isDStar_iff z.val).mp hz
    rw [huz,Finset.mem_singleton] at hw
    simpa [hw] using hd
  have huW := C.users_singleton_of_isD W G hDW hG
  have hGge := C.refCount_ge G
  have hGempty : C.users G = ∅ := Finset.card_eq_zero.mp (by omega)
  have hGout : C.outIs G = 0 := by omega
  have hzout : C.outIs z.val = 0 := by
    have hc := ((C.isD_iff z.val).mp hDz).1
    have hg := C.refCount_ge z.val
    have hp := Finset.card_pos.mpr ⟨W,hW⟩
    omega
  have hWout : C.outIs W = 0 := by
    have hc := ((C.isD_iff W).mp hDW).1
    have hg := C.refCount_ge W
    have hp := Finset.card_pos.mpr ⟨G,hG⟩
    omega
  have hout : ∀ k b, C.outWire = some (k,b) → k ≠ z.val ∧ k ≠ W ∧ k ≠ G := by
    intro k b hk
    constructor
    · intro he; simp [outIs,hk,he] at hzout
    constructor
    · intro he; simp [outIs,hk,he] at hWout
    · intro he; simp [outIs,hk,he] at hGout
  obtain ⟨u,v,hin,hne⟩ := hess
  have hzu : ∀ k ∈ C.users z.val, k = W := by intro k hk; simpa [huz] using hk
  have hWu : ∀ k ∈ C.users W, k = G := by intro k hk; simpa [huW] using hk
  exact hne (C.eval_eq_of_dead_two_gate_chain z W G u v hin hzu hWu hGempty hout)

/-- If every used primary input is essential and there are at least two
primary coordinates, no dead gate carries either credit role. -/
theorem dead_gate_credit_role_free {n : Nat} (C : OpenCircuit n)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z)
    (h2 : 2 ≤ n) (G : Nat) (g : Table) (a b : Nat)
    (hgate : C.gateAt G = some (g,a,b)) (hdead : C.refCount G = 0) :
    C.isDGate G = false ∧
      (∀ z : Fin n, C.isDStar z.val = true → ∀ W, W ∈ C.users z.val → G ∉ C.users W) := by
  constructor
  · cases hg : C.isDGate G with
    | false => rfl
    | true =>
      exfalso
      obtain ⟨g',a',b',hg',hab⟩ := (C.isDGate_iff G).mp hg
      rw [hgate] at hg'
      cases hg'
      rcases hab with ⟨ha,hd⟩ | ⟨hb,hd⟩
      · let z : Fin n := ⟨a,ha⟩
        have hGz : G ∈ C.users z.val := C.mem_users.mpr ⟨g,a,b,hgate,Or.inl rfl⟩
        have hess : Essential C.eval z := hused z (by rw [C.usage_singleUse]; have := ((C.isD_iff z.val).mp hd).1; omega)
        have hall : 1 < (Finset.univ : Finset (Fin n)).card := by simp; omega
        obtain ⟨q,_,hq⟩ := Finset.exists_mem_ne hall z
        have htwo := C.essential_input_with_dead_reader_has_two_refs z q hq G hGz hdead hess
        have hone := ((C.isD_iff z.val).mp hd).1
        omega
      · let z : Fin n := ⟨b,hb⟩
        have hGz : G ∈ C.users z.val := C.mem_users.mpr ⟨g,a,b,hgate,Or.inr rfl⟩
        have hess : Essential C.eval z := hused z (by rw [C.usage_singleUse]; have := ((C.isD_iff z.val).mp hd).1; omega)
        have hall : 1 < (Finset.univ : Finset (Fin n)).card := by simp; omega
        obtain ⟨q,_,hq⟩ := Finset.exists_mem_ne hall z
        have htwo := C.essential_input_with_dead_reader_has_two_refs z q hq G hGz hdead hess
        have hone := ((C.isD_iff z.val).mp hd).1
        omega
  · intro z hz W hW hG
    have hd := C.isD_of_isDStar z.val hz
    have hc := ((C.isD_iff z.val).mp hd).1
    have hess : Essential C.eval z := hused z (by rw [C.usage_singleUse]; omega)
    exact C.dead_gate_not_second_role z hz hess W G hW hG hdead

/-- Deleting any dead gate in this setting lowers the two-level potential
by its full weight. -/
theorem deleteDead_potential_drop_of_used_essential {n : Nat} (C : OpenCircuit n)
    (hp : C.GateProper)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z)
    (h2 : 2 ≤ n) (G : Nat) (g : Table) (a b : Nat)
    (hgate : C.gateAt G = some (g,a,b)) (hdead : C.refCount G = 0) :
    (C.deleteDead G).psi2 + (g.psi2W : Int) ≤ C.psi2 := by
  obtain ⟨hfirst,hsecond⟩ := C.dead_gate_credit_role_free hused h2 G g a b hgate hdead
  exact C.deleteDead_role_free_potential_drop hp G g a b hgate hdead hfirst hsecond

/-- A proper circuit that is not reduced contains a dead gate. -/
theorem exists_dead_gate_of_not_reduced {n : Nat} (C : OpenCircuit n)
    (hp : C.GateProper) (hn : ¬ C.Reduced) :
    ∃ k g a b, C.gateAt k = some (g,a,b) ∧ C.refCount k = 0 := by
  induction C with
  | output o => exact False.elim (hn trivial)
  | @gate n t i j rest ih =>
    by_cases hu : 0 < rest.lastUses
    · have hr : ¬ rest.Reduced := fun h => hn ⟨hp.1,hp.2.1,hu,h⟩
      obtain ⟨k,g,a,b,hk,hd⟩ := ih hp.2.2 hr
      have hkge := (rest.gateAt_bounds hk).1
      have hne : k ≠ n := by omega
      refine ⟨k,g,a,b,(gateAt_tail t i j rest hne).trans hk,?_⟩
      simp only [refCount]
      have hi : i.val ≠ k := by have := i.isLt; omega
      have hj : j.val ≠ k := by have := j.isLt; omega
      simp [hi,hj,hd]
    · have hd : rest.refCount n = 0 := by rw [← FlatA.lastUses_eq]; omega
      refine ⟨n,t,i.val,j.val,gateAt_head t i j rest,?_⟩
      simp only [refCount]
      have hi : i.val ≠ n := by have := i.isLt; omega
      have hj : j.val ≠ n := by have := j.isLt; omega
      simp [hi,hj,hd]

/-- Removing all dead gates preserves the function and does not increase
its two-level potential, provided every used input is essential. -/
theorem exists_reduced_potential_le {n : Nat} (h2 : 2 ≤ n) (C : OpenCircuit n)
    (hp : C.GateProper)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z) :
    ∃ D : OpenCircuit n, D.Reduced ∧ (∀ x, D.eval x = C.eval x) ∧ D.psi2 ≤ C.psi2 := by
  induction hs : C.size using Nat.strong_induction_on generalizing C with
  | h m ih =>
    by_cases hr : C.Reduced
    · exact ⟨C,hr,fun _ => rfl,le_rfl⟩
    · obtain ⟨k,g,a,b,hk,hd⟩ := C.exists_dead_gate_of_not_reduced hp hr
      let E := C.deleteDead k
      have hspec := C.deleteDead_spec hp k g a b hk hd
      have hproper : E.GateProper := C.deleteDead_preserves_proper hp k
      have heval : ∀ x, E.eval x = C.eval x := hspec.1
      have husedE : ∀ z : Fin n, 0 < E.usage (singleUse z) → Essential E.eval z := by
        intro z hz
        have hkge := (C.gateAt_bounds hk).1
        have hle := C.deleteDead_refCount_before_le hp k g a b hk hd z.val (by have := z.isLt; omega)
        change E.refCount z.val ≤ C.refCount z.val at hle
        have hzC : 0 < C.usage (singleUse z) := by
          rw [E.usage_singleUse] at hz
          rw [C.usage_singleUse]
          omega
        obtain ⟨u,v,hu,hne⟩ := hused z hzC
        exact ⟨u,v,hu,by simpa only [heval] using hne⟩
      have hdrop := C.deleteDead_potential_drop_of_used_essential hp hused h2 k g a b hk hd
      change E.psi2 + (g.psi2W : Int) ≤ C.psi2 at hdrop
      have hsmall : E.size < m := by dsimp [E]; omega
      obtain ⟨D,hD,hDeval,hDpsi⟩ := ih E.size hsmall E hproper husedE rfl
      refine ⟨D,hD,fun x => (hDeval x).trans (heval x),?_⟩
      omega


/-- Dead-gate normalization also records strict size reduction whenever
any deletion is made, for the normalization termination argument. -/
theorem exists_reduced_potential_le_size {n : Nat} (h2 : 2 ≤ n) (C : OpenCircuit n)
    (hp : C.GateProper)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z) :
    ∃ D : OpenCircuit n, D.Reduced ∧ (∀ x, D.eval x = C.eval x) ∧ D.psi2 ≤ C.psi2 ∧
      D.size ≤ C.size ∧ (D.size = C.size → D.predecessorSum = C.predecessorSum) := by
  induction hs : C.size using Nat.strong_induction_on generalizing C with
  | h m ih =>
    by_cases hr : C.Reduced
    · exact ⟨C,hr,fun _ => rfl,le_rfl,by omega,fun _ => rfl⟩
    · obtain ⟨k,g,a,b,hk,hd⟩ := C.exists_dead_gate_of_not_reduced hp hr
      let E := C.deleteDead k
      have hspec := C.deleteDead_spec hp k g a b hk hd
      have hproper : E.GateProper := C.deleteDead_preserves_proper hp k
      have heval : ∀ x, E.eval x = C.eval x := hspec.1
      have husedE : ∀ z : Fin n, 0 < E.usage (singleUse z) → Essential E.eval z := by
        intro z hz
        have hkge := (C.gateAt_bounds hk).1
        have hle := C.deleteDead_refCount_before_le hp k g a b hk hd z.val (by have := z.isLt; omega)
        change E.refCount z.val ≤ C.refCount z.val at hle
        have hzC : 0 < C.usage (singleUse z) := by
          rw [E.usage_singleUse] at hz
          rw [C.usage_singleUse]
          omega
        obtain ⟨u,v,hu,hne⟩ := hused z hzC
        exact ⟨u,v,hu,by simpa only [heval] using hne⟩
      have hdrop := C.deleteDead_potential_drop_of_used_essential hp hused h2 k g a b hk hd
      change E.psi2 + (g.psi2W : Int) ≤ C.psi2 at hdrop
      have hsmall : E.size < m := by dsimp [E]; omega
      obtain ⟨D,hD,hDeval,hDpsi,hDsize,_⟩ := ih E.size hsmall E hproper husedE rfl
      refine ⟨D,hD,fun x => (hDeval x).trans (heval x),?_,?_,?_⟩
      · omega
      · omega
      · intro heq
        omega


/-- Dead-gate normalization never introduces a new used input. -/
theorem exists_reduced_potential_le_size_support {n : Nat} (h2 : 2 ≤ n) (C : OpenCircuit n)
    (hp : C.GateProper)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z) :
    ∃ D : OpenCircuit n, D.Reduced ∧ (∀ x, D.eval x = C.eval x) ∧ D.psi2 ≤ C.psi2 ∧
      D.size ≤ C.size ∧ (D.size = C.size → D.predecessorSum = C.predecessorSum) ∧
      (∀ z : Fin n, 0 < D.usage (singleUse z) → 0 < C.usage (singleUse z)) := by
  induction hs : C.size using Nat.strong_induction_on generalizing C with
  | h m ih =>
    by_cases hr : C.Reduced
    · exact ⟨C,hr,fun _ => rfl,le_rfl,by omega,fun _ => rfl,fun _ hz => hz⟩
    · obtain ⟨k,g,a,b,hk,hd⟩ := C.exists_dead_gate_of_not_reduced hp hr
      let E := C.deleteDead k
      have hspec := C.deleteDead_spec hp k g a b hk hd
      have hproper : E.GateProper := C.deleteDead_preserves_proper hp k
      have heval : ∀ x, E.eval x = C.eval x := hspec.1
      have husedE : ∀ z : Fin n, 0 < E.usage (singleUse z) → Essential E.eval z := by
        intro z hz
        have hkge := (C.gateAt_bounds hk).1
        have hle := C.deleteDead_refCount_before_le hp k g a b hk hd z.val (by have := z.isLt; omega)
        change E.refCount z.val ≤ C.refCount z.val at hle
        have hzC : 0 < C.usage (singleUse z) := by
          rw [E.usage_singleUse] at hz
          rw [C.usage_singleUse]
          omega
        obtain ⟨u,v,hu,hne⟩ := hused z hzC
        exact ⟨u,v,hu,by simpa only [heval] using hne⟩
      have hdrop := C.deleteDead_potential_drop_of_used_essential hp hused h2 k g a b hk hd
      change E.psi2 + (g.psi2W : Int) ≤ C.psi2 at hdrop
      have hsmall : E.size < m := by dsimp [E]; omega
      obtain ⟨D,hD,hDeval,hDpsi,hDsize,_,hDused⟩ := ih E.size hsmall E hproper husedE rfl
      refine ⟨D,hD,fun x => (hDeval x).trans (heval x),?_,?_,?_,?_⟩
      · omega
      · omega
      · intro heq
        omega
      · intro z hzD
        have hzE := hDused z hzD
        have hkge := (C.gateAt_bounds hk).1
        have hle := C.deleteDead_refCount_before_le hp k g a b hk hd z.val (by have := z.isLt; omega)
        change E.refCount z.val ≤ C.refCount z.val at hle
        rw [E.usage_singleUse] at hzE
        rw [C.usage_singleUse]
        omega

end OpenCircuit
end SatLowerBound
