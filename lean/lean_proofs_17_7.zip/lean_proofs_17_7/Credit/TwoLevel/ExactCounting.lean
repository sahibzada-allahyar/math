import Credit.TwoLevel.FiniteSharpBound
import SatLowerBound.PairRestriction
import SatLowerBound.Logarithmic

/-! Match the manuscript's unordered-coordinate-pair collision count. -/
namespace SatLowerBound

theorem PairFour.swap {n : Nat} {f : (Fin n → Bool) → Bool} {i j : Fin n}
    (hij : i ≠ j) (h : PairFour f i j) : PairFour f j i := by
  intro p q hpq
  have hs : ∀ (x : Fin n → Bool) (p : Bool × Bool),
      setPair x j i p.1 p.2 = setPair x i j p.2 p.1 := by
    intro x p
    funext z
    by_cases hzj : z = j <;> by_cases hzi : z = i <;> simp_all [setPair]
  have he : PairRow (fun a b x => f (setPair x i j a b)) (p.2,p.1) =
      PairRow (fun a b x => f (setPair x i j a b)) (q.2,q.1) := by
    funext x
    have hx := congrFun hpq x
    simpa only [PairRow, ← hs] using hx
  have ht := h he
  exact Prod.ext (congrArg Prod.snd ht) (congrArg Prod.fst ht)

noncomputable def orderedCollisionIndices (n k : Nat) : Finset (CollisionIndex n) := by
  classical
  exact (collisionIndices n k).filter (fun t => t.2.1 < t.2.2.1)

noncomputable def orderedBadFunctions (n k : Nat) : Finset ((Fin n → Bool) → Bool) := by
  classical
  exact (orderedCollisionIndices n k).biUnion collisionEvent

theorem notRobust_mem_orderedBadFunctions {n k : Nat} (f : (Fin n → Bool) → Bool)
    (hf : ¬ Robust k f) : f ∈ orderedBadFunctions n k := by
  classical
  by_contra hn
  apply hf
  intro ρ hfree i j hij hi hj
  have hordered : ∀ a b : Fin n, a < b → ρ a = none → ρ b = none →
      PairFour (fun x => f (applyPartial ρ x)) a b := by
    intro a b hab ha hb p q hpqeq
    by_contra hpq
    obtain ⟨t,ht | ht⟩ := sixRowPairs_cover p q hpq
    all_goals
      have hidx : (ρ,a,b,t) ∈ orderedCollisionIndices n k := by
        change (ρ,a,b,t) ∈ (collisionIndices n k).filter _
        simp only [Finset.mem_filter]
        constructor
        · change (ρ,a,b,t) ∈ Finset.univ.filter (fun t => @ValidCollisionIndex n k t)
          simp only [Finset.mem_filter, Finset.mem_univ, true_and]
          exact ⟨hfree,ne_of_lt hab,ha,hb⟩
        · exact hab
      have hrow : f ∈ collisionEvent (ρ,a,b,t) := by
        simp only [collisionEvent,rowCollisionSet,Finset.mem_filter,Finset.mem_univ,true_and]
        simp only [ht]
        first | exact hpqeq | exact hpqeq.symm
      exact hn (Finset.mem_biUnion.mpr ⟨(ρ,a,b,t),hidx,hrow⟩)
  rcases lt_or_gt_of_ne hij with hijlt | hjilt
  · exact hordered i j hijlt hi hj
  · exact (hordered j i hjilt hj hi).swap (Ne.symm hij)

/-- Unordered pairs of distinct coordinates, represented in increasing order. -/
def increasingCoordinatePairs (n : Nat) : Finset (Fin n × Fin n) :=
  (Finset.univ.product Finset.univ).filter (fun p => p.1 < p.2)

theorem increasingCoordinatePairs_card (n : Nat) :
    (increasingCoordinatePairs n).card = Nat.choose n 2 := by
  unfold increasingCoordinatePairs
  simpa using (Finset.card_product_filter_lt (s := (Finset.univ : Finset (Fin n))))

/-- Every valid index belongs to a product of restrictions, increasing
coordinate pairs and the six row pairs. -/
theorem orderedCollisionIndices_card_le_choose (n k : Nat) :
    (orderedCollisionIndices n k).card ≤ 3 ^ n * Nat.choose n 2 * 6 := by
  classical
  let S := (Finset.univ : Finset (Fin n → Option Bool)).product
    ((increasingCoordinatePairs n).product (Finset.univ : Finset (Fin 6)))
  let pack : (Fin n → Option Bool) × ((Fin n × Fin n) × Fin 6) → CollisionIndex n :=
    fun x => (x.1,x.2.1.1,x.2.1.2,x.2.2)
  have hsub : orderedCollisionIndices n k ⊆ S.image pack := by
    intro x hx
    rcases x with ⟨ρ,i,j,t⟩
    have hlt : i < j := (Finset.mem_filter.mp hx).2
    apply Finset.mem_image.mpr
    refine ⟨(ρ,((i,j),t)), ?_, rfl⟩
    simp [S, increasingCoordinatePairs, hlt]
  have hc := (Finset.card_le_card hsub).trans (Finset.card_image_le)
  simpa [S,Finset.card_product,increasingCoordinatePairs_card,Fintype.card_fun,
    Fintype.card_option,Fintype.card_bool,Fintype.card_fin,Nat.mul_assoc] using hc

/-- The index count in Proposition 5.9: at most `3^n · 3n(n-1)`. -/
theorem orderedCollisionIndices_card_le (n k : Nat) :
    (orderedCollisionIndices n k).card ≤ 3 ^ n * 3 * n * (n - 1) := by
  have hchoose : 2 * Nat.choose n 2 ≤ n * (n - 1) := by
    rw [Nat.choose_two_right]
    omega
  have hmul := Nat.mul_le_mul_left (3 ^ n * 3) hchoose
  have he : 3 ^ n * Nat.choose n 2 * 6 =
      (3 ^ n * 3) * (2 * Nat.choose n 2) := by ring
  have he' : (3 ^ n * 3) * (n * (n - 1)) = 3 ^ n * 3 * n * (n - 1) := by ring
  rw [← he, he'] at hmul
  exact (orderedCollisionIndices_card_le_choose n k).trans hmul

/-- Union bound with exactly the event-count factor appearing in the PDF. -/
theorem orderedBadFunctions_card_le (n k : Nat) :
    (orderedBadFunctions n k).card ≤
      (3 ^ n * 3 * n * (n - 1)) * 2 ^ (2 ^ n - 2 ^ (k - 2)) := by
  classical
  calc
    (orderedBadFunctions n k).card ≤
        ∑ t ∈ orderedCollisionIndices n k, 2 ^ (2 ^ n - 2 ^ (k - 2)) := by
      apply (Finset.card_biUnion_le).trans
      apply Finset.sum_le_sum
      intro t ht
      exact collisionEvent_card_le t (Finset.mem_filter.mp ht).1
    _ = (orderedCollisionIndices n k).card * 2 ^ (2 ^ n - 2 ^ (k - 2)) := by simp
    _ ≤ _ := Nat.mul_le_mul_right _ (orderedCollisionIndices_card_le n k)

/-- The paper's count condition yields a robust full-degree block. -/
theorem exists_robust_fullDegree_exact_count (n k : Nat) (hkn : k ≤ n + 2)
    (h : 2 * (3 ^ n * 3 * n * (n - 1)) < 2 ^ (2 ^ (k - 2))) :
    ∃ f : (Fin n → Bool) → Bool,
      Robust k f ∧ (BPoly.ofFunction n f).topCoefficient = true := by
  classical
  have hd : 2 ^ (k - 2) ≤ 2 ^ n := Nat.pow_le_pow_right (by omega) (by omega)
  have hN : 0 < 2 ^ n := by positivity
  have hp : 0 < 2 ^ (2 ^ n - 2 ^ (k - 2)) := by positivity
  have hm := Nat.mul_lt_mul_of_pos_right h hp
  have heq : 2 ^ (2 ^ (k - 2)) * 2 ^ (2 ^ n - 2 ^ (k - 2)) = 2 ^ (2 ^ n) := by
    rw [← pow_add]
    congr 1
    omega
  have heq' : 2 ^ (2 ^ n - 1) * 2 = 2 ^ (2 ^ n) := by
    rw [← pow_succ]
    congr 1
    omega
  rw [heq] at hm
  have hcount : (3 ^ n * 3 * n * (n - 1)) * 2 ^ (2 ^ n - 2 ^ (k - 2)) <
      2 ^ (2 ^ n - 1) := by nlinarith
  have hlt : (orderedBadFunctions n k).card < (fullDegreeFunctions n).card := by
    rw [fullDegreeFunctions_card]
    exact (orderedBadFunctions_card_le n k).trans_lt hcount
  obtain ⟨f,hfull,hgood⟩ := Finset.exists_mem_notMem_of_card_lt_card hlt
  refine ⟨f, ?_, ?_⟩
  · by_contra hn
    exact hgood (notRobust_mem_orderedBadFunctions f hn)
  · simpa [fullDegreeFunctions] using hfull

/-- Equation (5) under the exact finite counting inequality of Proposition 5.9. -/
theorem finite_paper_bound_exact_count (w r k : Nat)
    (hw : 2 ≤ w) (hr : r < w) (hk : 2 ≤ k) (hkr : k + 2 ≤ r)
    (hcount : 2 * (3 ^ r * 3 * r * (r - 1)) < 2 ^ (2 ^ (k - 2)))
    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    7 * (inputBits w : Int) + (30 * (r : Int) - 42 * ((k : Int) + 1)) *
      ((variableCount w : Int) - ((2 ^ r : Nat) : Int)) - 3 ≤ 7 * (C.size : Int) := by
  obtain ⟨g,hrobust,hfull⟩ := exists_robust_fullDegree_exact_count r k (by omega) hcount
  exact finite_paper_bound_of_robust_block w r k hw hr hk hkr g hrobust hfull C hc

/-- The logarithmic hypothesis of Proposition 5.9 implies its finite
exponential counting inequality. -/
theorem paper_log_condition_implies_count (r k : Nat) (hr : 4 ≤ r)
    (hlog : (2 : ℝ) ^ (k - 2) >
      Real.logb 2 (6 * (r : ℝ) * ((r : ℝ) - 1)) + (r : ℝ) * Real.logb 2 3) :
    2 * (3 ^ r * 3 * r * (r - 1)) < 2 ^ (2 ^ (k - 2)) := by
  have hrR : (4 : ℝ) ≤ r := by exact_mod_cast hr
  have hrpos : (0 : ℝ) < (r : ℝ) - 1 := by linarith
  have ha : (0 : ℝ) < 6 * (r : ℝ) * ((r : ℝ) - 1) := by positivity
  have hb : (0 : ℝ) < (3 : ℝ) ^ r := by positivity
  have hlog' : Real.logb 2 ((6 * (r : ℝ) * ((r : ℝ) - 1)) * 3 ^ r) <
      ((2 ^ (k - 2) : Nat) : ℝ) := by
    rw [Real.logb_mul (ne_of_gt ha) (ne_of_gt hb), Real.logb_pow]
    simpa only [Nat.cast_pow, Nat.cast_ofNat] using hlog
  have hh := (Real.logb_lt_iff_lt_rpow (b := 2) (by norm_num) (mul_pos ha hb)).mp hlog'
  rw [Real.rpow_natCast] at hh
  have hre : ((2 * (3 ^ r * 3 * r * (r - 1)) : Nat) : ℝ) =
      (6 * (r : ℝ) * ((r : ℝ) - 1)) * 3 ^ r := by
    simp only [Nat.cast_mul, Nat.cast_pow, Nat.cast_sub (by omega : 1 ≤ r),
      Nat.cast_ofNat, Nat.cast_one]
    ring
  rw [← hre] at hh
  exact_mod_cast hh

/-- Equation (5) with the same logarithmic hypothesis as Theorem 8.2. -/
theorem finite_paper_bound_log_condition (w r k : Nat)
    (hw : 2 ≤ w) (hrw : r < w) (hr : 4 ≤ r) (hk : 3 ≤ k) (hkr : k + 2 ≤ r)
    (hlog : (2 : ℝ) ^ (k - 2) >
      Real.logb 2 (6 * (r : ℝ) * ((r : ℝ) - 1)) + (r : ℝ) * Real.logb 2 3)
    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    7 * (inputBits w : Int) + (30 * (r : Int) - 42 * ((k : Int) + 1)) *
      ((variableCount w : Int) - ((2 ^ r : Nat) : Int)) - 3 ≤ 7 * (C.size : Int) :=
  finite_paper_bound_exact_count w r k hw hrw (by omega) hkr
    (paper_log_condition_implies_count r k hr hlog) C hc

end SatLowerBound
