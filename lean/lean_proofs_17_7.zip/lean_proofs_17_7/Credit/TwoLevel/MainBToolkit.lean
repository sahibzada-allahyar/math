import Credit.MainA.Toolkit
import Credit.TwoLevel.Uncharged

/-! Instantiating the two-level charging lemma for a single input of degree at
least two, as required at the start of Main Lemma B. -/
namespace SatLowerBound
namespace MAContext

open OpenCircuit

/-- Choose the two successive readers used by the credit ledger. -/
theorem twoLevel_readers {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (_h : MAContext f C) : ∃ W V : Fin n → Nat,
      (∀ z, C.isD z.val = true → W z ∈ C.users z.val) ∧
      (∀ z, C.isDStar z.val = true → V z ∈ C.users (W z)) := by
  classical
  have hfirst : ∀ z : Fin n, ∃ w, C.isD z.val = true → w ∈ C.users z.val := by
    intro z
    by_cases hd : C.isD z.val = true
    · obtain ⟨_, w, g, a, b, hg, hab, _⟩ := (C.isD_iff z.val).mp hd
      exact ⟨w, fun _ => C.mem_users.mpr ⟨g, a, b, hg, hab⟩⟩
    · exact ⟨0, fun hd' => False.elim (hd hd')⟩
  choose W hW using hfirst
  have hsecond : ∀ z : Fin n, ∃ v, C.isDStar z.val = true → v ∈ C.users (W z) := by
    intro z
    by_cases hs : C.isDStar z.val = true
    · obtain ⟨hd, w, hw, hdw⟩ := (C.isDStar_iff z.val).mp hs
      have heq := C.users_singleton_of_isD z.val (W z) hd (hW z hd)
      rw [heq, Finset.mem_singleton] at hw
      rw [hw] at hdw
      obtain ⟨_, v, g, a, b, hg, hab, _⟩ := (C.isD_iff (W z)).mp hdw
      exact ⟨v, fun _ => C.mem_users.mpr ⟨g, a, b, hg, hab⟩⟩
    · exact ⟨0, fun hs' => False.elim (hs hs')⟩
  choose V hV using hsecond
  exact ⟨W, V, hW, hV⟩

/-- The one-input restriction retains the essentiality required by the
charging argument for every original two-level credit. -/
theorem twoLevel_single_assumptions {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x : Fin n) (b : Bool)
    (h2 : 2 ≤ C.refCount x.val) :
    (∀ z, C.isD z.val = true → decide (z = x) = false) ∧
    (∀ z, C.isDStar z.val = true → Essential f z) ∧
    (∀ z, C.isDStar z.val = true → Essential (C.restrict (singleSubst x b)).eval z) := by
  have hx : C.isD x.val = false := by
    cases hd : C.isD x.val with
    | false => rfl
    | true => have hh := ((C.isD_iff x.val).mp hd).1; omega
  have hfree : ∀ z, C.isD z.val = true → decide (z = x) = false := by
    intro z hd
    apply decide_eq_false_iff_not.mpr
    intro hz
    subst z
    rw [hx] at hd
    contradiction
  have horig : ∀ z, C.isDStar z.val = true → Essential f z := by
    intro z hs
    have hd := C.isD_of_isDStar z.val hs
    have hc := ((C.isD_iff z.val).mp hd).1
    exact h.usedEssential z (by rw [C.usage_singleUse]; omega)
  refine ⟨hfree, horig, ?_⟩
  intro z hs
  have hzx : z ≠ x := by
    intro he
    have hf := hfree z (C.isD_of_isDStar z.val hs)
    simp [he] at hf
  have he := h.good.e1 x b z hzx (horig z hs)
  have hfun : (C.restrict (singleSubst x b)).eval = fun v => f (fixBit x b v) := by
    funext v
    rw [restrict_single_eval, h.computes]
  rwa [hfun]

/-- Main Lemma B's charging estimate for a single input of degree at least
 two, with the choice of credit readers and the essentiality hypotheses derived
 from the circuit and function assumptions. -/
theorem twoLevel_single_drop {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x : Fin n) (b : Bool)
    (h2 : 2 ≤ C.refCount x.val) :
    (C.restrict (singleSubst x b)).psi2 +
      3 * (C.aliasedCount (singleRes x b) : Int) +
      4 * (C.aliasedParityCount (singleRes x b) : Int) +
      C.credit2Gained (C.restrict (singleSubst x b)) ≤ C.psi2 := by
  obtain ⟨W,V,hW,hV⟩ := h.twoLevel_readers
  obtain ⟨hfree,horig,hess⟩ := h.twoLevel_single_assumptions x b h2
  have hd := C.psi2_free_drop_full_parity (fun z => decide (z = x)) (fun _ => b)
    h.reduced h.dGateSafe f h.computes h.good.e1 W V hfree hW hV
    (by simpa [← singleSubst_eq_fixSubst] using hess) horig
  simpa [← singleSubst_eq_fixSubst, singleRes] using hd

/-- Direct readers of a primary input with at least two readers carry no
first or second credit role. -/
theorem twoLevel_reader_no_role {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x : Fin n)
    (h2 : 2 ≤ C.refCount x.val) (W V : Fin n → Nat)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (horig : ∀ z, C.isDStar z.val = true → Essential f z)
    (k : Nat) (hk : k ∈ C.users x.val) :
    (∀ z, C.isD z.val = true → W z ≠ k) ∧
    (∀ z, C.isDStar z.val = true → V z ≠ k) := by
  obtain ⟨g,a,b,hg,hab⟩ := C.mem_users.mp hk
  constructor
  · intro z hz he
    have hzread : k ∈ C.users z.val := by simpa [he] using hw z hz
    obtain ⟨g',a',b',hg',hab'⟩ := C.mem_users.mp hzread
    rw [hg] at hg'
    cases hg'
    have hD : C.isDGate k = true := (C.isDGate_iff k).mpr
      ⟨g,a,b,hg, by rcases hab' with ha | hb
                    · exact Or.inl ⟨by rw [ha]; exact z.isLt, by rw [ha]; exact hz⟩
                    · exact Or.inr ⟨by rw [hb]; exact z.isLt, by rw [hb]; exact hz⟩⟩
    rw [h.not_dGate_of_multi x h2 hk] at hD
    contradiction
  · intro z hz he
    have hd := C.isD_of_isDStar z.val hz
    have hread : k ∈ C.users (W z) := by simpa [he] using hv z hz
    exact C.second_role_has_no_primary h.reduced f h.computes h.good.e1 z (horig z hz)
      (W z) k hz (hw z hd) hread g a b hg x hab

/-- In the one-input estimate, each eliminated nonlinear direct reader adds
one further unit, because it has neither credit role. -/
theorem twoLevel_single_drop_with_readers {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x : Fin n) (b : Bool)
    (h2 : 2 ≤ C.refCount x.val) (E : Finset Nat)
    (hE : ∀ k ∈ E, k ∈ C.users x.val ∧
      C.isAliased (singleRes x b) k = true ∧ (C.tableAt k).parity = false) :
    (C.restrict (singleSubst x b)).psi2 +
      3 * (C.aliasedCount (singleRes x b) : Int) +
      4 * (C.aliasedParityCount (singleRes x b) : Int) +
      (E.card : Int) + C.credit2Gained (C.restrict (singleSubst x b)) ≤ C.psi2 := by
  obtain ⟨W,V,hW,hV⟩ := h.twoLevel_readers
  obtain ⟨hfree,horig,hess⟩ := h.twoLevel_single_assumptions x b h2
  have hsub : E ⊆ Finset.range (n + C.size) := by
    intro k hk
    obtain ⟨g,a,d,hg,_⟩ := C.mem_users.mp (hE k hk).1
    exact Finset.mem_range.mpr (C.gateAt_bounds hg).2.1
  have hroles : ∀ k ∈ E, C.isAliased (fixRes (fun z => decide (z = x)) (fun _ => b)) k = true ∧
      (C.tableAt k).parity = false ∧
      (∀ z, C.isD z.val = true → W z ≠ k) ∧
      (∀ z, C.isDStar z.val = true → V z ≠ k) := by
    intro k hk
    obtain ⟨hread,ha,hpar⟩ := hE k hk
    obtain ⟨hfirst,hsecond⟩ := h.twoLevel_reader_no_role x h2 W V hW hV horig k hread
    exact ⟨ha,hpar,hfirst,hsecond⟩
  have hd := C.psi2_free_drop_with_uncharged (fun z => decide (z = x)) (fun _ => b)
    h.reduced h.dGateSafe f h.computes h.good.e1 W V hfree hW hV
    (by simpa [← singleSubst_eq_fixSubst] using hess) horig E hsub hroles
  simpa [← singleSubst_eq_fixSubst, singleRes] using hd

end MAContext
end SatLowerBound
