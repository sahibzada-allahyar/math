import Credit.TwoLevel.GenericCertificate
import Credit.TwoLevel.SparseRobustTree

/-! The actual sparse 3-SAT certificate, conditional only on a robust
full-degree local block. -/
namespace SatLowerBound

/-- Instantiate the sparse target tree and the explicit 3-SAT restriction.
No tree existence or target-equivalence premise is left to the caller. -/
theorem sat_certificate_of_robust_block (w r k : Nat) (hw : 2 ≤ w) (hr : r < w)
    (hk : 2 ≤ k) (hkr : k+2 ≤ r) (g : (Fin r → Bool) → Bool)
    (hrobust : Robust k g) (hfull : (BPoly.ofFunction r g).topCoefficient = true)
    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    7 * (inputBits w : Int) + (30*(r : Int)-42*((k : Int)+1)) *
      genericRemainingClauses w (canonicalForbiddenFamily g) - 3 ≤ 7 * (C.size : Int) := by
  classical
  have hr0 : 0 < r := by omega
  let B := canonicalForbiddenFamily g
  have hcount : B.count ≤ 2^r := canonical_forbidden_count_le g
  obtain ⟨hfit,hM⟩ := genericRemaining_pos_of_count w r hr hr0 B hcount
  let T : RobustTree (genericFreeBits w B) := positiveSparseTree (genericRemainingClauses w B) r hM g
  have hvalid : T.Valid k (fun _ => none) := positiveSparseTree_valid _ _ _ hM hr0 hkr g hrobust
  have hs : T.support = Finset.univ := positiveSparseTree_support _ _ hM hr0 g
  have hfullT : T.FullLeaves := positiveSparseTree_full _ _ hM hr0 g hfull
  have hblocks : T.blocks = 3 * genericRemainingClauses w B := positiveSparseTree_blocks _ _ hM g
  have htarget : ∀ v, T.eval v = genericSparseFunction w B v := by
    intro v
    rw [show T = positiveSparseTree (genericRemainingClauses w B) r hM g from rfl,
      positiveSparseTree_eval]
    rfl
  have hblock : Nonconstant g := full_degree_nonconstant hr0 g hfull
  have hh := generic_sat_tree_certificate w r k hw hr hr0 hk B hfit hM hblock T hvalid hs hfullT hblocks htarget C hc
  dsimp [B] at hh
  change _ ≤ 7 * (C.size : Int)
  ring_nf at hh ⊢
  omega

end SatLowerBound
