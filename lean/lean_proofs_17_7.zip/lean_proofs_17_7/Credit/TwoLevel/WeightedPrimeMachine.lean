import Credit.TwoLevel.WeightedListMachine

/-! Executable prime selection in the same unary-counter cost model as the
residue machine. Trial division is deliberately elementary; only polynomial
time is required for selecting the modulus. -/
namespace SatLowerBound
namespace ResidueMachine

/-- Compare unary counters by removing one constructor from each. -/
def less : Nat → Nat → Run Bool
  | _, 0 => ⟨false,1⟩
  | 0, _+1 => ⟨true,1⟩
  | a+1, b+1 => let r := less a b; ⟨r.value,r.steps+3⟩

@[simp] theorem less_value (a b : Nat) : (less a b).value = decide (a < b) := by
  induction b generalizing a with
  | zero => simp [less]
  | succ b ih => cases a <;> simp [less,ih]

theorem less_steps (a b : Nat) : (less a b).steps ≤ 3*b+1 := by
  induction b generalizing a with
  | zero => simp [less]
  | succ b ih =>
    cases a with
    | zero => simp [less]
    | succ a => have := ih a; simp only [less]; omega

/-- Remainder by repeated subtraction, with explicit unary fuel. -/
def remainder : Nat → Nat → Nat → Run Nat
  | 0, a, _ => ⟨a,1⟩
  | _+1, a, 0 => ⟨a,1⟩
  | fuel+1, a, b+1 =>
    let test := less a (b+1)
    if test.value then ⟨a,test.steps+2⟩ else
      let next := sub a (b+1)
      let rest := remainder fuel next.value (b+1)
      ⟨rest.value,test.steps+next.steps+rest.steps+4⟩

theorem remainder_value (fuel a b : Nat) (hf : a ≤ fuel) :
    (remainder fuel a b).value = a % b := by
  induction fuel generalizing a with
  | zero =>
    have : a = 0 := by omega
    subst a
    simp [remainder]
  | succ fuel ih =>
    cases b with
    | zero => simp [remainder]
    | succ b =>
      by_cases h : a < b+1
      · simp [remainder,h,Nat.mod_eq_of_lt h]
      · have hle : b+1 ≤ a := by omega
        have hsmall : a-(b+1) ≤ fuel := by omega
        simp only [remainder,less_value,decide_eq_true_eq]
        rw [ite_eq_right h,sub_value,ih _ hsmall]
        exact (Nat.mod_eq_sub_mod hle).symm

theorem remainder_steps (fuel a b B : Nat) (ha : a ≤ B) (hb : b ≤ B) :
    (remainder fuel a b).steps ≤ (fuel+1)*(6*B+6) := by
  induction fuel generalizing a with
  | zero => simp only [remainder]; nlinarith
  | succ fuel ih =>
    cases b with
    | zero => simp only [remainder]; nlinarith
    | succ b =>
      have ht := less_steps a (b+1)
      have hs := sub_steps a (b+1)
      have hrec := ih (a-(b+1)) (by omega)
      simp only [remainder,less_value,decide_eq_true_eq,sub_value]
      split_ifs <;> nlinarith

/-- Check that none of 2,...,k+1 divides n. -/
def noDivisors (n : Nat) : Nat → Run Bool
  | 0 => ⟨true,1⟩
  | k+1 =>
    let rem := remainder n n (k+2)
    match rem.value with
    | 0 => ⟨false,rem.steps+2⟩
    | _+1 => let rest := noDivisors n k; ⟨rest.value,rem.steps+rest.steps+3⟩

theorem noDivisors_value (n k : Nat) :
    (noDivisors n k).value = true ↔ ∀ d, 2 ≤ d → d ≤ k+1 → ¬d ∣ n := by
  induction k with
  | zero => simp [noDivisors]; omega
  | succ k ih =>
    have hv := remainder_value n n (k+2) (by omega)
    cases he : (remainder n n (k+2)).value with
    | zero =>
      have hd : k+2 ∣ n := Nat.dvd_of_mod_eq_zero (hv.symm.trans he)
      simp only [noDivisors,he,Bool.false_eq_true,false_iff]
      intro h
      exact h (k+2) (by omega) (by omega) hd
    | succ v =>
      have hd : ¬(k+2) ∣ n := by
        intro hd
        have hz := Nat.mod_eq_zero_of_dvd hd
        rw [hz,he] at hv
        omega
      simp only [noDivisors,he,ih]
      constructor
      · intro h d hlo hhi
        by_cases heq : d = k+2
        · simpa [heq] using hd
        · exact h d hlo (by omega)
      · intro h d hlo hhi
        exact h d hlo (by omega)

theorem noDivisors_steps (n k B : Nat) (hn : n ≤ B) (hk : k+1 ≤ B) :
    (noDivisors n k).steps ≤ 1+k*((B+1)*(6*B+6)+3) := by
  induction k with
  | zero => simp [noDivisors]
  | succ k ih =>
    have hr := remainder_steps n n (k+2) B hn (by omega)
    have hi := ih (by omega)
    have hm : (n+1)*(6*B+6) ≤ (B+1)*(6*B+6) := Nat.mul_le_mul_right _ (by omega)
    simp only [noDivisors]
    split <;> nlinarith

/-- Primality test using all possible proper divisors. -/
def primeTest : Nat → Run Bool
  | 0 => ⟨false,1⟩
  | 1 => ⟨false,2⟩
  | n+2 => let r := noDivisors (n+2) n; ⟨r.value,r.steps+3⟩

theorem primeTest_value (n : Nat) : (primeTest n).value = true ↔ n.Prime := by
  cases n with
  | zero => simp [primeTest,Nat.prime_def_lt']
  | succ n =>
    cases n with
    | zero => simp [primeTest,Nat.prime_def_lt']
    | succ n =>
      simp only [primeTest,noDivisors_value,Nat.prime_def_lt']
      constructor
      · intro h
        exact ⟨by omega,fun d hd hlt => h d hd (by omega)⟩
      · rintro ⟨_,h⟩ d hd hle
        exact h d hd (by omega)

theorem primeTest_steps (n B : Nat) (hn : n ≤ B) :
    (primeTest n).steps ≤ (B+1)*((B+1)*(6*B+6)+3)+4 := by
  cases n with
  | zero => simp only [primeTest]; omega
  | succ n =>
    cases n with
    | zero => simp only [primeTest]; omega
    | succ n =>
      have h := noDivisors_steps (n+2) n B hn (by omega)
      have hm : n*((B+1)*(6*B+6)+3) ≤ (B+1)*((B+1)*(6*B+6)+3) :=
        Nat.mul_le_mul_right _ (by omega)
      simp only [primeTest]
      omega

/-- Search an increasing finite interval and return its first prime. -/
def search (lo : Nat) : Nat → Run (Option Nat)
  | 0 => ⟨none,1⟩
  | fuel+1 =>
    let test := primeTest lo
    if test.value then ⟨some lo,test.steps+2⟩ else
      let rest := search (lo+1) fuel
      ⟨rest.value,test.steps+rest.steps+3⟩

theorem search_finds (lo fuel p : Nat) (hlo : lo ≤ p) (hhi : p < lo+fuel)
    (hp : p.Prime) (hmin : ∀ q, lo ≤ q → q < p → ¬q.Prime) :
    (search lo fuel).value = some p := by
  induction fuel generalizing lo with
  | zero => omega
  | succ fuel ih =>
    by_cases he : lo = p
    · subst lo
      have ht : (primeTest p).value = true := (primeTest_value p).mpr hp
      simp [search,ht]
    · have hn : ¬lo.Prime := hmin lo (by omega) (by omega)
      have ht : (primeTest lo).value = false :=
        Bool.eq_false_iff.mpr (fun h => hn ((primeTest_value lo).mp h))
      simp only [search,ht,Bool.false_eq_true,ite_false]
      exact ih (lo+1) (by omega) (by omega) (fun q hq hqp => hmin q (by omega) hqp)

/-- Upper bound for one primality test at a counter bounded by B. -/
def primeBudget (B : Nat) : Nat := (B+1)*((B+1)*(6*B+6)+3)+4

theorem search_steps (lo fuel B : Nat) (hbound : lo+fuel ≤ B+1) :
    (search lo fuel).steps ≤ 1+fuel*(primeBudget B+3) := by
  induction fuel generalizing lo with
  | zero => simp [search]
  | succ fuel ih =>
    have ht : (primeTest lo).steps ≤ primeBudget B := primeTest_steps lo B (by omega)
    have hr := ih (lo+1) (by omega)
    simp only [search]
    split_ifs <;> nlinarith

/-- Construct twice a unary counter, including the construction cost. -/
def double : Nat → Run Nat
  | 0 => ⟨0,1⟩
  | n+1 => let r := double n; ⟨r.value+2,r.steps+4⟩

@[simp] theorem double_value (n : Nat) : (double n).value = 2*n := by
  induction n with
  | zero => rfl
  | succ n ih => simp [double,ih]; omega

@[simp] theorem double_steps (n : Nat) : (double n).steps = 4*n+1 := by
  induction n with
  | zero => rfl
  | succ n ih => simp [double,ih]; omega

/-- Search precisely 2r+1,...,4r, constructing its unary bounds internally. -/
def findPrime (r : Nat) : Run (Option Nat) :=
  let twice := double r
  let result := search (twice.value+1) twice.value
  ⟨result.value,twice.steps+result.steps+3⟩

/-- The executable search agrees with the paper's least-prime definition. -/
theorem findPrime_value (r : Nat) (hr : 1 ≤ r) :
    (findPrime r).value = some (weightedPrime r) := by
  obtain ⟨hp,hlarge⟩ := weightedPrime_spec r
  have hupper := weightedPrime_le_four r hr
  simp only [findPrime,double_value]
  apply search_finds _ _ _ (by omega) (by omega) hp
  intro q hq hqp hprime
  have hh := weightedPrime_minimal r q hprime (by omega)
  omega

/-- Polynomial search cost, including construction of the interval bounds. -/
theorem findPrime_steps (r : Nat) :
    (findPrime r).steps ≤ 4*r+5+2*r*(primeBudget (4*r)+3) := by
  have h := search_steps (2*r+1) (2*r) (4*r) (by omega)
  simp only [findPrime,double_value,double_steps]
  omega

/-- The uniform construction: find the prime, build the residue table,
and return the modulus and least successful residue. -/
def construct (r : Nat) : Run (Option (Nat × Nat)) :=
  let prime := findPrime r
  match prime.value with
  | none => ⟨none,prime.steps+1⟩
  | some p =>
    let residue := select p r
    ⟨residue.value.map (fun t => (p,t)),prime.steps+residue.steps+3⟩

/-- Explicit polynomial bound for the complete uniform construction. -/
theorem construct_steps (r : Nat) (hr : 1 ≤ r) :
    (construct r).steps ≤ 1675*r^4 := by
  have hp := findPrime_value r hr
  have hprime := findPrime_steps r
  have hresidue := select_steps_quadratic r hr
  simp only [construct,hp]
  have h2 : r ≤ r*r := by nlinarith
  have h3 : r*r ≤ r*r*r := by nlinarith
  have h4 : r*r*r ≤ r*r*r*r := by nlinarith
  dsimp [primeBudget] at hprime
  nlinarith

/-- The complete algorithm returns the exact prime specified by the paper
and the least residue with odd top coefficient, and that block is robust.
No prime or subset-sum existence oracle is an input to this computation. -/
theorem construct_correct_with_cost (r : Nat) (hr : 4 ≤ r) :
    ∃ i : Fin (weightedPrime r),
      (construct r).value = some (weightedPrime r,i.val) ∧
      Robust (weightedTriangleThreshold (weightedPrime r)+2)
        (weightedModularBlock r (weightedPrime r) (i.val : ZMod (weightedPrime r))) ∧
      (BPoly.ofFunction r
        (weightedModularBlock r (weightedPrime r) (i.val : ZMod (weightedPrime r)))).topCoefficient = true ∧
      (∀ j : Fin (weightedPrime r), j < i →
        (BPoly.ofFunction r
          (weightedModularBlock r (weightedPrime r) (j.val : ZMod (weightedPrime r)))).topCoefficient = false) ∧
      (construct r).steps ≤ 1675*r^4 := by
  obtain ⟨i,hi,hrob,hfull,hmin,_⟩ := paper_selected_block_quadratic r hr
  refine ⟨i,?_,hrob,hfull,hmin,construct_steps r (by omega)⟩
  simp only [construct,findPrime_value r (by omega),hi,Option.map_some]

end ResidueMachine
end SatLowerBound

