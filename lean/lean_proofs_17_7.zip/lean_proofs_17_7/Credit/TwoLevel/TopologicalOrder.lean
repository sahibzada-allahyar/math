import Credit.TwoLevel.OrderedNetwork
import Mathlib.Order.Extension.Linear
import Mathlib.Data.Finset.Sort

/-! Acyclic finite dependencies admit a topological enumeration. -/
namespace SatLowerBound

/-- Any finite irreflexive transitive-closure relation has an enumeration in
which every predecessor occurs before its successor. -/
theorem exists_finite_topological_order {α : Type} [Fintype α]
    (r : α → α → Prop) (hacyclic : ∀ x, ¬ Relation.TransGen r x x) :
    ∃ e : Fin (Fintype.card α) ≃ α,
      ∀ a b, r a b → e.symm a < e.symm b := by
  classical
  let rel : α → α → Prop := fun x y => x = y ∨ Relation.TransGen r x y
  let _ : IsPartialOrder α rel := {
    refl := fun _ => Or.inl rfl
    trans := by
      intro a b c hab hbc
      rcases hab with rfl | hab
      · exact hbc
      rcases hbc with rfl | hbc
      · exact Or.inr hab
      · exact Or.inr (hab.trans hbc)
    antisymm := by
      intro a b hab hba
      rcases hab with he | hab
      · exact he
      rcases hba with he | hba
      · exact he.symm
      · exact False.elim (hacyclic a (hab.trans hba)) }
  obtain ⟨le',hle',hext⟩ := extend_partialOrder rel
  let _ : LinearOrder α := {
    le := le'
    le_refl := hle'.refl
    le_trans := hle'.trans
    le_antisymm := hle'.antisymm
    le_total := hle'.total
    toDecidableLE := Classical.decRel _ }
  let order : Fin (Fintype.card α) ≃o ↥(Finset.univ : Finset α) :=
    Finset.orderIsoOfFin _ (Finset.card_univ)
  let e : Fin (Fintype.card α) ≃ α := {
    toFun := fun i => (order i).val
    invFun := fun x => order.symm ⟨x,Finset.mem_univ x⟩
    left_inv := by intro i; exact order.symm_apply_apply i
    right_inv := by intro x; exact congrArg Subtype.val (order.apply_symm_apply ⟨x,Finset.mem_univ x⟩) }
  refine ⟨e, ?_⟩
  intro a b hab
  have hne : a ≠ b := by
    intro he
    subst b
    exact hacyclic a (Relation.TransGen.single hab)
  have hle : a ≤ b := hext a b (Or.inr (Relation.TransGen.single hab))
  have hlt' : a < b := lt_of_le_of_ne hle hne
  have hlt : (⟨a,Finset.mem_univ a⟩ : ↥(Finset.univ : Finset α)) <
      ⟨b,Finset.mem_univ b⟩ := hlt' 
  exact order.symm.strictMono hlt

/-- Gate nodes named independently of their eventual topological order. -/
structure AcyclicNetwork (n s : Nat) where
  table : Fin s → Table
  left : Fin s → (Fin n ⊕ Fin s)
  right : Fin s → (Fin n ⊕ Fin s)
  output : Fin n ⊕ Fin s
  acyclic : ∀ i, ¬ Relation.TransGen
    (fun a b => left b = Sum.inr a ∨ right b = Sum.inr a) i i

/-- The predecessor relation in an arbitrarily labelled network. -/
def AcyclicNetwork.dep {n s : Nat} (N : AcyclicNetwork n s) (a b : Fin s) : Prop :=
  N.left b = Sum.inr a ∨ N.right b = Sum.inr a

/-- A topological order exists for the actual gate-predecessor relation. -/
theorem AcyclicNetwork.exists_order {n s : Nat} (N : AcyclicNetwork n s) :
    ∃ e : Fin s ≃ Fin s, ∀ a b, N.dep a b → e.symm a < e.symm b := by
  have h := exists_finite_topological_order N.dep N.acyclic
  rw [Fintype.card_fin] at h
  exact h

/-- A chosen topological enumeration of the network's gates. -/
noncomputable def AcyclicNetwork.order {n s : Nat} (N : AcyclicNetwork n s) : Fin s ≃ Fin s :=
  N.exists_order.choose

theorem AcyclicNetwork.order_precedes {n s : Nat} (N : AcyclicNetwork n s)
    (a b : Fin s) (hab : N.dep a b) : N.order.symm a < N.order.symm b :=
  N.exists_order.choose_spec a b hab

/-- Relabel the independently named gates into topological order, preserving
all gate tables, edges, repeated predecessors and the designated output. -/
noncomputable def AcyclicNetwork.toOrdered {n s : Nat} (N : AcyclicNetwork n s) : OrderedNetwork n s where
  node i := by
    let g := N.order i
    let src : (side : Bool) → Fin (n + i.val) := fun side =>
      match h : (if side then N.right g else N.left g) with
      | .inl x => ⟨x.val, by have := x.isLt; omega⟩
      | .inr a => ⟨n + (N.order.symm a).val, by
          have hdep : N.dep a g := by
            cases side with
            | false => exact Or.inl h
            | true => exact Or.inr h
          have hrank := N.order_precedes a g hdep
          have heq : N.order.symm g = i := N.order.symm_apply_apply i
          rw [heq] at hrank
          have := (Fin.lt_def).mp hrank
          omega⟩
    exact ⟨N.table g, src false, src true⟩
  output := match N.output with
    | .inl x => ⟨x.val, by have := x.isLt; omega⟩
    | .inr a => ⟨n + (N.order.symm a).val, by have := (N.order.symm a).isLt; omega⟩

/-- The relabelled network compiles to exactly one circuit gate per original
network gate. -/
theorem AcyclicNetwork.compiled_size {n s : Nat} (N : AcyclicNetwork n s) :
    N.toOrdered.toCircuit.size = s := N.toOrdered.toCircuit_size

end SatLowerBound
