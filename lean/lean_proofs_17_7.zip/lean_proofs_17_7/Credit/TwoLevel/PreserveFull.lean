import Credit.TwoLevel.KeptReaders
import Credit.TwoLevel.Preserve
import Credit.TwoLevel.Accounting

/-! The two-credit preservation step in the actual restricted circuit. -/
namespace SatLowerBound
namespace OpenCircuit

/-- If a free D-star input and both gates in its original credit chain survive,
the same input is D-star in the reindexed restricted circuit. -/
theorem retained_DStar_survives {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool)
    (hr : C.Reduced) (z : Fin n) (hz : P z = false) (W V : Nat)
    (hstar : C.isDStar z.val = true) (hW : W ∈ C.users z.val)
    (hV : V ∈ C.users W)
    (hWkept : C.isKept (fixRes P c) W = true)
    (hVkept : C.isKept (fixRes P c) V = true) :
    (C.restrict (fixSubst P c)).isDStar z.val = true := by
  obtain ⟨hzD, hWD⟩ := C.retained_two_credit_links P c hr z hz W V hstar hW hV hWkept hVkept
  obtain ⟨g,a,b,hgate,hab⟩ := C.mem_users.mp hW
  obtain ⟨k,g',a',b',hgate',href,hfirst,hread⟩ :=
    C.restrict_kept_readers (fixSubst P c) (fixRes P c) Fin.val
      Fin.val_injective (fun w => w.isLt) (fixSubst_rel P c) W g a b hgate hWkept
  have hnewD : (C.restrict (fixSubst P c)).isD k = true := by
    simp only [isD, href, hfirst]
    exact hWD
  have hzres : (C.resAt (fixRes P c) z.val).hits z.val = true := by
    rw [C.resAt_input]
    simp [fixRes, hz, Res.hits]
  have hreadz : a' = z.val ∨ b' = z.val := by
    apply (hread z).mpr
    rcases hab with ha | hb
    · exact Or.inl (by simpa [ha] using hzres)
    · exact Or.inr (by simpa [hb] using hzres)
  have hnewW : k ∈ (C.restrict (fixSubst P c)).users z.val :=
    (C.restrict (fixSubst P c)).mem_users.mpr ⟨g',a',b',hgate',hreadz⟩
  apply ((C.restrict (fixSubst P c)).isDStar_iff z.val).mpr
  refine ⟨?_, k, hnewW, hnewD⟩
  rw [(C.fix_transfer P c).2.2.2 z]
  exact hzD

/-- First case of the paper's two-level charging proof. If the input is free,
its first credited gate survives, and its D-star status is lost, the second
credited gate is eliminated and the input loses exactly one credit. -/
theorem lost_DStar_with_first_gate_kept {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (z : Fin n) (hz : P z = false)
    (W V : Nat) (hstar : C.isDStar z.val = true) (hW : W ∈ C.users z.val)
    (hV : V ∈ C.users W) (hWkept : C.isKept (fixRes P c) W = true)
    (hlost : (C.restrict (fixSubst P c)).isDStar z.val = false) :
    C.isAliased (fixRes P c) V = true ∧
      C.credit2 z - (C.restrict (fixSubst P c)).credit2 z = 1 := by
  have hDz := C.isD_of_isDStar z.val hstar
  have huz := C.users_singleton_of_isD z.val W hDz hW
  have hnewD : (C.restrict (fixSubst P c)).isD z.val = true := by
    rw [(C.fix_transfer P c).2.2.2 z]
    apply C.keptIsD_of_isD P c z hz hDz
    intro k hk
    rw [huz, Finset.mem_singleton] at hk
    simpa [hk] using hWkept
  have hVk : C.isKept (fixRes P c) V = false := by
    apply Bool.eq_false_iff.mpr
    intro hkept
    have hsurvive := C.retained_DStar_survives P c hr z hz W V hstar hW hV hWkept hkept
    rw [hlost] at hsurvive
    contradiction
  have hValias : C.isAliased (fixRes P c) V = true := by
    obtain ⟨g,a,b,hgate,_⟩ := C.mem_users.mp hV
    have h := C.isKept_eq_not_isAliased (fixRes P c) hgate
    rw [hVk] at h
    cases hv : C.isAliased (fixRes P c) V with
    | false => rw [hv] at h; contradiction
    | true => rfl
  refine ⟨hValias, ?_⟩
  simp [credit2, hDz, hstar, hnewD, hlost, indicator]

/-- Fixed-input case of charging: every original reader of the fixed input is
eliminated, and the input carries no credit in the restricted circuit. -/
theorem fixed_input_credit_removed {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (z : Fin n) (hz : P z = true)
    (W : Nat) (hW : W ∈ C.users z.val) :
    C.isAliased (fixRes P c) W = true ∧
      (C.restrict (fixSubst P c)).credit2 z = 0 := by
  obtain ⟨g,a,b,hgate,hab⟩ := C.mem_users.mp hW
  have hzconst : (C.resAt (fixRes P c) z.val).isConst = true := by
    rw [C.resAt_input]
    simp [fixRes, hz, Res.isConst]
  have halias : C.isAliased (fixRes P c) W = true := by
    apply C.isAliased_of_const _ hgate
    rcases hab with ha | hb
    · rw [ha]; exact Or.inl hzconst
    · rw [hb]; exact Or.inr hzconst
  have hnewD : (C.restrict (fixSubst P c)).isD z.val = false := by
    rw [(C.fix_transfer P c).2.2.2 z]
    exact C.keptIsD_of_fixed P c z hz
  have hnewStar : (C.restrict (fixSubst P c)).isDStar z.val = false := by
    simp [isDStar, hnewD]
  exact ⟨halias, by simp [credit2, hnewD, hnewStar, indicator]⟩

end OpenCircuit
end SatLowerBound
