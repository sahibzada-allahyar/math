import Credit.TwoLevel.WeightedSubsetSums

/-! The signed-sum reduction in Balandraud's subset-sum argument. -/
namespace SatLowerBound

/-- All signed sums obtained by assigning `+` or `-` to each member of `A`. -/
def signedSubsetSums {G : Type} [DecidableEq G] [AddCommGroup G] (A : Finset G) : Finset G :=
  A.powerset.image (fun B => (∑ x ∈ B, x) - ∑ x ∈ A \ B, x)

/-- Signed sums are an affine image of ordinary subset sums. -/
theorem signedSubsetSums_eq_image {G : Type} [DecidableEq G] [AddCommGroup G]
    (A : Finset G) : signedSubsetSums A =
      A.subsetSum.image (fun x => x + x - ∑ a ∈ A, a) := by
  ext x
  simp only [signedSubsetSums, Finset.mem_image, Finset.mem_powerset, Finset.mem_subsetSum_iff]
  constructor
  · rintro ⟨B,hBA,hx⟩
    refine ⟨∑ b ∈ B, b, ⟨B,hBA,rfl⟩, ?_⟩
    have hsum : (∑ b ∈ B, b) + ∑ a ∈ A \ B, a = ∑ a ∈ A, a := by
      rw [← Finset.sum_union]
      · rw [Finset.union_sdiff_of_subset hBA]
      · exact Finset.disjoint_sdiff
    calc
      (∑ b ∈ B, b) + (∑ b ∈ B, b) - ∑ a ∈ A, a =
          (∑ b ∈ B, b) - ∑ a ∈ A \ B, a := by rw [← hsum]; abel
      _ = x := hx
  · rintro ⟨y,⟨B,hBA,hB⟩,hy⟩
    refine ⟨B,hBA, ?_⟩
    have hsum : (∑ b ∈ B, b) + ∑ a ∈ A \ B, a = ∑ a ∈ A, a := by
      rw [← Finset.sum_union]
      · rw [Finset.union_sdiff_of_subset hBA]
      · exact Finset.disjoint_sdiff
    rw [← hB] at hy
    rw [← hsum] at hy
    convert hy using 1; abel

/-- If doubling is injective, passing between subset sums and signed sums
preserves cardinality. -/
theorem signedSubsetSums_card_of_doubling_injective {G : Type} [DecidableEq G]
    [AddCommGroup G] (A : Finset G) (hdouble : Function.Injective (fun x : G => x + x)) :
    (signedSubsetSums A).card = A.subsetSum.card := by
  rw [signedSubsetSums_eq_image]
  apply Finset.card_image_of_injective
  intro x y hxy
  apply hdouble
  exact sub_left_injective hxy

/-- For an odd prime modulus, doubling is injective, so the signed-sum set
has exactly as many elements as the subset-sum set. -/
theorem signedSubsetSums_card_zmod_prime (p : Nat) (hp : p.Prime) (hpodd : p ≠ 2)
    (A : Finset (ZMod p)) : (signedSubsetSums A).card = A.subsetSum.card := by
  let _ : Fact p.Prime := ⟨hp⟩
  apply signedSubsetSums_card_of_doubling_injective
  intro x y hxy
  have hpgt : 2 < p := by have := hp.two_le; omega
  have htwo : (2 : ZMod p) ≠ 0 := by
    intro hzero
    have hdiv : p ∣ 2 := (ZMod.natCast_eq_zero_iff 2 p).mp (by simpa using hzero)
    have hh := Nat.le_of_dvd (by decide : 0 < 2) hdiv
    omega
  have hmul : (2 : ZMod p) * x = (2 : ZMod p) * y := by
    calc
      (2 : ZMod p) * x = x + x := by ring
      _ = y + y := hxy
      _ = (2 : ZMod p) * y := by ring
  exact mul_left_cancel₀ htwo hmul

end SatLowerBound
