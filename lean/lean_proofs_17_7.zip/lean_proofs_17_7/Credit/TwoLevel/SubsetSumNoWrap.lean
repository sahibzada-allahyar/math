import Credit.TwoLevel.WeightedSubsetSums

/-! A verified no-wrap case of the subset-sum bound. This does not replace
Balandraud's bound for arbitrary subsets of a prime cyclic group. -/
namespace SatLowerBound

/-- If all subset sums lie below the modulus, modular reduction preserves the
quadratic subset-sum lower bound for distinct positive weights. -/
theorem subsetSum_no_wrap_bound (p : Nat) (A : Finset Nat)
    (hpositive : ∀ a ∈ A, 0 < a) (hsmall : (∑ a ∈ A, a) < p) :
    1 + A.card * (A.card + 1) / 2 ≤
      ((A.image (fun a : Nat => (a : ZMod p))).subsetSum).card := by
  classical
  have hsubsetSmall : ∀ a ∈ A.subsetSum, a < p := by
    intro a ha
    obtain ⟨B,hBA,hB⟩ := Finset.mem_subsetSum_iff.mp ha
    have hle : (∑ b ∈ B, b) ≤ ∑ a ∈ A, a := Finset.sum_le_sum_of_subset hBA
    omega
  have hcast : Set.InjOn (fun a : Nat => (a : ZMod p)) ↑A.subsetSum := by
    intro a ha b hb he
    have hmod := (ZMod.natCast_eq_natCast_iff' a b p).mp he
    rw [Nat.mod_eq_of_lt (hsubsetSmall a ha), Nat.mod_eq_of_lt (hsubsetSmall b hb)] at hmod
    exact hmod
  have hcastA : Set.InjOn (fun a : Nat => (a : ZMod p)) ↑A := by
    intro a ha b hb he
    exact hcast (Finset.subset_subsetSum ha) (Finset.subset_subsetSum hb) he
  have hsub : A.subsetSum.image (fun a : Nat => (a : ZMod p)) ⊆
      (A.image (fun a : Nat => (a : ZMod p))).subsetSum := by
    intro x hx
    obtain ⟨s,hs,rfl⟩ := Finset.mem_image.mp hx
    obtain ⟨B,hBA,hBsum⟩ := Finset.mem_subsetSum_iff.mp hs
    apply Finset.mem_subsetSum_iff.mpr
    refine ⟨B.image (fun a : Nat => (a : ZMod p)),Finset.image_mono _ hBA, ?_⟩
    rw [Finset.sum_image]
    · simpa only [Nat.cast_sum] using congrArg (fun a : Nat => (a : ZMod p)) hBsum
    · intro a ha b hb he
      exact hcastA (hBA ha) (hBA hb) he
  have hcard := Finset.card_le_card hsub
  rw [Finset.card_image_of_injOn hcast] at hcard
  have hn := Finset.card_succ_choose_two_lt_card_subsetSum_of_pos hpositive
  rw [Nat.choose_two_right] at hn
  have he : A.card + 1 - 1 = A.card := by omega
  rw [he] at hn
  have hs : (A.card + 1) * A.card = A.card * (A.card + 1) := by ring
  rw [hs] at hn
  omega

end SatLowerBound
