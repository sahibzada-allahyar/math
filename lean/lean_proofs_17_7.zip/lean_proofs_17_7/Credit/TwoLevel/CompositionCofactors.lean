import Credit.TwoLevel.RobustRestrictions
import SatLowerBound.SeparationLifting

/-! Four-cofactor separation through disjoint AND/OR composition, following
Lemma 5.8 of the manuscript. -/
namespace SatLowerBound

/-- Pulling back each cofactor along one common map preserves all four distinct rows. -/
theorem fourRows_pullback {α β : Type} (f : Bool → Bool → α → Bool)
    (g : Bool → Bool → β → Bool) (e : α → β)
    (he : ∀ a b u, g a b (e u) = f a b u) (h : FourRows f) : FourRows g := by
  intro p q hpq
  apply h
  funext u
  have hu := congrFun hpq (e u)
  simpa only [PairRow,he] using hu

/-- Four separated cofactors within one child remain separated when the other
child of an AND/OR gate is held at its neutral value. -/
theorem combine_pair_four_left {n : Nat} (p : Bool) (f g : (Fin n → Bool) → Bool)
    (S T : Finset (Fin n)) (hf : Supported f S) (hg : Supported g T) (hd : Disjoint S T)
    (hgn : Nonconstant g) (x y : Fin n) (hx : x ∈ S) (hy : y ∈ S)
    (hs : PairFour f x y) : PairFour (fun v => combine p (f v) (g v)) x y := by
  obtain ⟨z,hz⟩ := hgn.has_value (!p)
  have hxt : x ∉ T := fun ht => Finset.disjoint_left.mp hd hx ht
  have hyt : y ∉ T := fun ht => Finset.disjoint_left.mp hd hy ht
  apply fourRows_pullback _ _ (fun v => patchValues S v z) _ hs
  intro a b v
  change combine p (f (setPair (patchValues S v z) x y a b))
    (g (setPair (patchValues S v z) x y a b)) = f (setPair v x y a b)
  rw [hf.pair_patch,hg.pair_right x y hxt,hg.fixBit_outside y hyt,
    hg.patch_right hd,hz,combine_neutral]

/-- The cross-child case of the four-cofactor condition. The product
projections recover each of the two cofactor functions. -/
theorem combine_pair_four_cross {n : Nat} (p : Bool) (f g : (Fin n → Bool) → Bool)
    (S T : Finset (Fin n)) (hf : Supported f S) (hg : Supported g T) (hd : Disjoint S T)
    (x y : Fin n) (hx : Essential f x) (hy : Essential g y)
    (hfx : ∀ a, Nonconstant (fun v => f (fixBit x a v)))
    (hgy : ∀ b, Nonconstant (fun v => g (fixBit y b v))) :
    PairFour (fun v => combine p (f v) (g v)) x y := by
  have hxs := hf.essential_mem x hx
  have hyt := hg.essential_mem y hy
  have hxt : x ∉ T := fun ht => Finset.disjoint_left.mp hd hxs ht
  have hys : y ∉ S := fun hs => Finset.disjoint_left.mp hd hs hyt
  have hrow (a b : Bool) : PairRow (fun a b v => combine p (f (setPair v x y a b))
      (g (setPair v x y a b))) (a,b) =
      (fun v => combine p (f (fixBit x a v)) (g (fixBit y b v))) := by
    funext v
    simp only [PairRow,hf.pair_left x y hys,hg.pair_right x y hxt]
  have hfd := essential_cofactors_distinct f x hx
  have hgd := essential_cofactors_distinct g y hy
  intro u v huv
  obtain ⟨a,b⟩ := u
  obtain ⟨c,d⟩ := v
  rw [hrow,hrow] at huv
  have hfe := combine_product_left_unique p _ _ _ _ S T (hf.cofactor x a) (hf.cofactor x c)
    (hg.cofactor y b) (hg.cofactor y d) hd (hgy b) (hgy d) huv
  have hge := combine_product_right_unique p _ _ _ _ S T (hf.cofactor x a) (hf.cofactor x c)
    (hg.cofactor y b) (hg.cofactor y d) hd (hfx a) (hfx c) huv
  have hac : a = c := by
    cases a <;> cases c <;> try rfl
    · exact False.elim (hfd hfe)
    · exact False.elim (hfd hfe.symm)
  have hbd : b = d := by
    cases b <;> cases d <;> try rfl
    · exact False.elim (hgd hge)
    · exact False.elim (hgd hge.symm)
  simp [hac,hbd]

/-- Four-cofactor separation is symmetric in the two selected inputs. -/
theorem PairFour.symm {n : Nat} {f : (Fin n → Bool) → Bool} {x y : Fin n}
    (h : PairFour f x y) (hxy : x ≠ y) : PairFour f y x := by
  intro p q hpq
  have hh : PairRow (fun a b v => f (setPair v x y a b)) (p.2,p.1) =
      PairRow (fun a b v => f (setPair v x y a b)) (q.2,q.1) := by
    funext v
    have h := congrFun hpq v
    simpa only [PairRow,setPair_symm v x y p.2 p.1 hxy,
      setPair_symm v x y q.2 q.1 hxy] using h
  have he := h hh
  cases p
  cases q
  simp only [Prod.mk.injEq] at he ⊢
  exact ⟨he.2,he.1⟩

/-- Four-cofactor separation lifts through an AND/OR node on disjoint
supports when each coordinate in a child support remains essential there. -/
theorem combine_s4Essential {n : Nat} (p : Bool) (f g : (Fin n → Bool) → Bool)
    (S T : Finset (Fin n)) (hf : Supported f S) (hg : Supported g T) (hd : Disjoint S T)
    (hfn : Nonconstant f) (hgn : Nonconstant g)
    (hfess : ∀ x ∈ S, Essential f x) (hgess : ∀ x ∈ T, Essential g x)
    (hf4 : S4Essential f) (hg4 : S4Essential g)
    (hfx : ∀ x, Essential f x → ∀ a, Nonconstant (fun v => f (fixBit x a v)))
    (hgy : ∀ y, Essential g y → ∀ b, Nonconstant (fun v => g (fixBit y b v))) :
    S4Essential (fun v => combine p (f v) (g v)) := by
  intro x y hxy hx hy
  have hs := supported_combine p f g S T hf hg
  have hxmem := Finset.mem_union.mp (hs.essential_mem x hx)
  have hymem := Finset.mem_union.mp (hs.essential_mem y hy)
  rcases hxmem with hxs | hxt <;> rcases hymem with hys | hyt
  · exact combine_pair_four_left p f g S T hf hg hd hgn x y hxs hys
      (hf4 x y hxy (hfess x hxs) (hfess y hys))
  · exact combine_pair_four_cross p f g S T hf hg hd x y (hfess x hxs) (hgess y hyt)
      (hfx x (hfess x hxs)) (hgy y (hgess y hyt))
  · have h := combine_pair_four_cross p f g S T hf hg hd y x (hfess y hys) (hgess x hxt)
      (hfx y (hfess y hys)) (hgy x (hgess x hxt))
    exact h.symm (Ne.symm hxy)
  · have h := combine_pair_four_left p g f T S hg hf hd.symm hfn x y hxt hyt
      (hg4 x y hxy (hgess x hxt) (hgess y hyt))
    simpa only [combine_comm p (g _) (f _)] using h

/-- Fixing any two coordinates preserves the specified support. -/
theorem Supported.pairCofactor {n : Nat} {f : (Fin n → Bool) → Bool}
    {S : Finset (Fin n)} (hf : Supported f S) (x y : Fin n) (a b : Bool) :
    Supported (fun v => f (setPair v x y a b)) S := by
  have hh := (hf.cofactor x a).cofactor y b
  simpa only [ModularTree.setPair_eq_fixBit] using hh

/-- A disjoint AND/OR composition retains E1 when both children retain
nonconstant one-bit cofactors. -/
theorem combine_e1 {n : Nat} (p : Bool) (f g : (Fin n → Bool) → Bool)
    (S T : Finset (Fin n)) (hf : Supported f S) (hg : Supported g T) (hd : Disjoint S T)
    (hfess : ∀ x ∈ S, Essential f x) (hgess : ∀ x ∈ T, Essential g x)
    (hfe : E1 f) (hge : E1 g)
    (hfn : ∀ x a, Nonconstant (fun v => f (fixBit x a v)))
    (hgn : ∀ x a, Nonconstant (fun v => g (fixBit x a v))) :
    E1 (fun v => combine p (f v) (g v)) := by
  intro x b z hzx hz
  have hmem := Finset.mem_union.mp ((supported_combine p f g S T hf hg).essential_mem z hz)
  rcases hmem with hzS | hzT
  · exact combine_essential_left p _ _ S T (hf.cofactor x b) (hg.cofactor x b) hd
      (hgn x b) z (hfe x b z hzx (hfess z hzS))
  · exact combine_essential_right p _ _ S T (hf.cofactor x b) (hg.cofactor x b) hd
      (hfn x b) z (hge x b z hzx (hgess z hzT))

/-- The analogous two-fixing statement, using nonconstant two-bit cofactors
for the sibling child. -/
theorem combine_e2 {n : Nat} (p : Bool) (f g : (Fin n → Bool) → Bool)
    (S T : Finset (Fin n)) (hf : Supported f S) (hg : Supported g T) (hd : Disjoint S T)
    (hfess : ∀ x ∈ S, Essential f x) (hgess : ∀ x ∈ T, Essential g x)
    (hfe : E2 f) (hge : E2 g)
    (hfn : ∀ x y a b, x ≠ y → Nonconstant (fun v => f (setPair v x y a b)))
    (hgn : ∀ x y a b, x ≠ y → Nonconstant (fun v => g (setPair v x y a b))) :
    E2 (fun v => combine p (f v) (g v)) := by
  intro x y a b z hxy hzx hzy hz
  have hmem := Finset.mem_union.mp ((supported_combine p f g S T hf hg).essential_mem z hz)
  rcases hmem with hzS | hzT
  · exact combine_essential_left p _ _ S T (hf.pairCofactor x y a b) (hg.pairCofactor x y a b) hd
      (hgn x y a b hxy) z (hfe x y a b z hxy hzx hzy (hfess z hzS))
  · exact combine_essential_right p _ _ S T (hf.pairCofactor x y a b) (hg.pairCofactor x y a b) hd
      (hfn x y a b hxy) z (hge x y a b z hxy hzx hzy (hgess z hzT))

/-- Nonconstancy after two fixings also lifts through a disjoint AND/OR node. -/
theorem combine_pair_nonconstant {n : Nat} (p : Bool) (f g : (Fin n → Bool) → Bool)
    (S T : Finset (Fin n)) (hf : Supported f S) (hg : Supported g T) (hd : Disjoint S T)
    (x y : Fin n) (a b : Bool)
    (hfn : Nonconstant (fun v => f (setPair v x y a b)))
    (hgn : Nonconstant (fun v => g (setPair v x y a b))) :
    Nonconstant (fun v => combine p (f (setPair v x y a b)) (g (setPair v x y a b))) :=
  combine_nonconstant p _ _ S T (hf.pairCofactor x y a b) (hg.pairCofactor x y a b) hd hfn hgn

/-- Semantic invariants maintained at every node of the manuscript's
read-once composition. -/
structure CompositionDependence {n : Nat} (f : (Fin n → Bool) → Bool)
    (S : Finset (Fin n)) : Prop where
  supported : Supported f S
  essential : ∀ x ∈ S, Essential f x
  nonconstant : Nonconstant f
  e1 : E1 f
  e2 : E2 f
  s4 : S4Essential f
  one_nonconstant : ∀ x a, Nonconstant (fun v => f (fixBit x a v))
  two_nonconstant : ∀ x y a b, x ≠ y → Nonconstant (fun v => f (setPair v x y a b))

/-- The dependence invariants lift through every disjoint AND/OR node. -/
theorem CompositionDependence.combine {n : Nat} (p : Bool)
    {f g : (Fin n → Bool) → Bool} {S T : Finset (Fin n)}
    (hf : CompositionDependence f S) (hg : CompositionDependence g T) (hd : Disjoint S T) :
    CompositionDependence (fun v => combine p (f v) (g v)) (S ∪ T) := by
  refine ⟨supported_combine p f g S T hf.supported hg.supported,?_,?_,?_,?_,?_,?_,?_⟩
  · intro x hx
    rcases Finset.mem_union.mp hx with hxS | hxT
    · exact combine_essential_left p f g S T hf.supported hg.supported hd hg.nonconstant x (hf.essential x hxS)
    · exact combine_essential_right p f g S T hf.supported hg.supported hd hf.nonconstant x (hg.essential x hxT)
  · exact combine_nonconstant p f g S T hf.supported hg.supported hd hf.nonconstant hg.nonconstant
  · exact combine_e1 p f g S T hf.supported hg.supported hd hf.essential hg.essential
      hf.e1 hg.e1 hf.one_nonconstant hg.one_nonconstant
  · exact combine_e2 p f g S T hf.supported hg.supported hd hf.essential hg.essential
      hf.e2 hg.e2 hf.two_nonconstant hg.two_nonconstant
  · exact combine_s4Essential p f g S T hf.supported hg.supported hd hf.nonconstant hg.nonconstant
      hf.essential hg.essential hf.s4 hg.s4 (fun x _ => hf.one_nonconstant x) (fun y _ => hg.one_nonconstant y)
  · intro x b
    exact combine_nonconstant p _ _ S T (hf.supported.cofactor x b) (hg.supported.cofactor x b) hd
      (hf.one_nonconstant x b) (hg.one_nonconstant x b)
  · intro x y a b hxy
    exact combine_pair_nonconstant p f g S T hf.supported hg.supported hd x y a b
      (hf.two_nonconstant x y a b hxy) (hg.two_nonconstant x y a b hxy)

/-- The invariant provides all semantic hypotheses needed by the fourteen-unit
elimination lemma whenever at least two support coordinates are present. -/
theorem CompositionDependence.goodFn {n : Nat} {f : (Fin n → Bool) → Bool}
    {S : Finset (Fin n)} (h : CompositionDependence f S) (hcard : 2 ≤ S.card) : GoodFn f := by
  obtain ⟨x,hx,y,hy,hxy⟩ := Finset.one_lt_card.mp (by omega : 1 < S.card)
  refine ⟨⟨x,y,hxy,h.essential x hx,h.essential y hy⟩,h.e1,h.e2,?_,h.one_nonconstant⟩
  intro i j hij hi hj
  exact (h.s4 i j hij hi hj).threeRows

/-- Read-once AND/OR trees whose leaves are arbitrary Boolean functions on
specified ambient-coordinate supports. -/
inductive DependenceTree (n : Nat) where
  | leaf (f : (Fin n → Bool) → Bool) (S : Finset (Fin n))
  | branch (isOr : Bool) (left right : DependenceTree n)

namespace DependenceTree

def eval {n : Nat} : DependenceTree n → (Fin n → Bool) → Bool
  | .leaf f _, v => f v
  | .branch p a b, v => combine p (a.eval v) (b.eval v)

def support {n : Nat} : DependenceTree n → Finset (Fin n)
  | .leaf _ S => S
  | .branch _ a b => a.support ∪ b.support

def Valid {n : Nat} : DependenceTree n → Prop
  | .leaf f S => CompositionDependence f S
  | .branch _ a b => a.Valid ∧ b.Valid ∧ Disjoint a.support b.support

/-- Induction over the paper's entire read-once composition. -/
theorem dependence {n : Nat} (T : DependenceTree n) (h : T.Valid) :
    CompositionDependence T.eval T.support := by
  induction T with
  | leaf f S => exact h
  | branch p a b iha ihb =>
    exact (iha h.1).combine p (ihb h.2.1) h.2.2

end DependenceTree
end SatLowerBound
