import Credit.Hypotheses

/-! Semantic definitions corresponding to (S4) and k-robust blocks in the
3-SAT manuscript. Restrictions retain the original coordinate type; fixed
coordinates are explicitly excluded from pair selection. -/

namespace SatLowerBound

/-- All four pair cofactors are distinct. -/
def FourRows {α : Type} (f : Bool → Bool → α → Bool) : Prop :=
  Function.Injective (PairRow f)

/-- The four cofactors of the pair `(i,j)` are distinct. -/
def PairFour {n : Nat} (f : (Fin n → Bool) → Bool) (i j : Fin n) : Prop :=
  FourRows (fun a b x => f (setPair x i j a b))

/-- Manuscript property (S4), over all pairs of distinct primary inputs. -/
def S4 {n : Nat} (f : (Fin n → Bool) → Bool) : Prop :=
  ∀ i j, i ≠ j → PairFour f i j

/-- Four-cofactor separation for pairs of essential coordinates, allowing
unused ambient coordinates introduced by prior restrictions. -/
def S4Essential {n : Nat} (f : (Fin n → Bool) → Bool) : Prop :=
  ∀ i j, i ≠ j → Essential f i → Essential f j → PairFour f i j

theorem S4.toEssential {n : Nat} {f : (Fin n → Bool) → Bool} (h : S4 f) : S4Essential f := by
  intro i j hij _ _
  exact h i j hij

theorem FourRows.threeRows {α : Type} {f : Bool → Bool → α → Bool}
    (h : FourRows f) : ThreeRows f := by
  refine ⟨(false, false), (false, true), (true, false), ?_, ?_, ?_⟩
  · intro he; have := h he; contradiction
  · intro he; have := h he; contradiction
  · intro he; have := h he; contradiction

theorem S4.s3 {n : Nat} {f : (Fin n → Bool) → Bool} (h : S4 f) : S3 f := by
  intro i j hij _ _
  exact (h i j hij).threeRows

/-- Four distinct pair cofactors force each input of the pair to be essential. -/
theorem PairFour.essential_left {n : Nat} {f : (Fin n → Bool) → Bool}
    {i j : Fin n} (h : PairFour f i j) : Essential f i := by
  have hne : PairRow (fun a b x => f (setPair x i j a b)) (false, false) ≠
      PairRow (fun a b x => f (setPair x i j a b)) (true, false) := by
    intro he
    have heq := h he
    contradiction
  have hex : ∃ x, f (setPair x i j false false) ≠ f (setPair x i j true false) := by
    by_contra hnone
    apply hne
    funext x
    by_contra hdiff
    exact hnone ⟨x, hdiff⟩
  obtain ⟨x, hx⟩ := hex
  refine ⟨setPair x i j false false, setPair x i j true false, ?_, hx⟩
  intro z hzi
  simp [setPair, hzi]

/-- Assignment after fixing coordinates marked `some`; `none` means free. -/
def applyPartial {n : Nat} (ρ : Fin n → Option Bool) (x : Fin n → Bool) : Fin n → Bool :=
  fun i => (ρ i).getD (x i)

/-- Number of free input coordinates in a partial assignment. -/
def freeCoordinates {n : Nat} (ρ : Fin n → Option Bool) : Finset (Fin n) :=
  Finset.univ.filter (fun i => ρ i = none)

/-- Every restriction leaving at least `k` free inputs has four distinct
cofactors for every pair of free inputs (the paper's exact definition). -/
def Robust {n : Nat} (k : Nat) (f : (Fin n → Bool) → Bool) : Prop :=
  ∀ ρ : Fin n → Option Bool, k ≤ (freeCoordinates ρ).card →
    ∀ i j, i ≠ j → ρ i = none → ρ j = none →
      PairFour (fun x => f (applyPartial ρ x)) i j

/-- A stronger robustness threshold entails every weaker requirement obtained
by asking for at least as many remaining variables. -/
theorem Robust.mono {n k k' : Nat} {f : (Fin n → Bool) → Bool}
    (h : Robust k f) (hkk : k ≤ k') : Robust k' f := by
  intro ρ hfree i j hij hi hj
  exact h ρ (Nat.le_trans hkk hfree) i j hij hi hj

/-- For `k ≤ n`, robustness includes the unrestricted S4 property. -/
theorem Robust.s4 {n k : Nat} {f : (Fin n → Bool) → Bool}
    (h : Robust k f) (hkn : k ≤ n) : S4 f := by
  intro i j hij
  have hf : (freeCoordinates (fun _ : Fin n => none)).card = n := by
    simp [freeCoordinates]
  have hcard : k ≤ (freeCoordinates (fun _ : Fin n => none)).card := by
    rw [hf]
    exact hkn
  have hpair := h (fun _ => none) hcard i j hij rfl rfl
  have hfun : (fun x => f (applyPartial (fun _ => none) x)) = f := by
    funext x
    congr 1
  rw [hfun] at hpair
  exact hpair

/-- Under a robust restriction, any free input with another free input is essential. -/
theorem Robust.restricted_essential {n k : Nat} {f : (Fin n → Bool) → Bool}
    (h : Robust k f) (ρ : Fin n → Option Bool)
    (hfree : k ≤ (freeCoordinates ρ).card) (i j : Fin n)
    (hij : i ≠ j) (hi : ρ i = none) (hj : ρ j = none) :
    Essential (fun x => f (applyPartial ρ x)) i :=
  (h ρ hfree i j hij hi hj).essential_left

end SatLowerBound
