import Credit.TwoLevel.UnreducedAccounting

/-! Complete triangle-rewrite step, including resolution of a degenerate
replacement and dead-gate removal. -/
namespace SatLowerBound
namespace OpenCircuit
namespace PsiTriangleAux

/-- A triangle rewrite introduces no newly used primary coordinate. -/
theorem triangle_usage_pos_of_rewrite {n : Nat} (C : OpenCircuit n)
    {q x P u : Nat} {g p f : Table} {i j c d : Nat}
    (hq : C.gateAt q = some (g,i,j)) (hij : (i = x ∧ j = P) ∨ (i = P ∧ j = x))
    (hP : C.gateAt P = some (p,c,d))
    (hcd : (c = x ∧ d = u) ∨ (c = u ∧ d = x)) (z : Fin n)
    (hz : 0 < (replaceAt C q f x u).usage (singleUse z)) :
    0 < C.usage (singleUse z) := by
  let R := replaceAt C q f x u
  change 0 < R.usage (singleUse z) at hz
  obtain ⟨_,_,hiq,hjq⟩ := C.gateAt_bounds hq
  obtain ⟨_,_,hcP,hdP⟩ := C.gateAt_bounds hP
  have hPq : P < q := by rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have hxq : x < q := by rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have huP : u < P := by rcases hcd with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have huq : u < q := by omega
  rw [R.usage_singleUse] at hz
  rw [C.usage_singleUse]
  by_cases hzx : z.val = x
  · have hm : P ∈ C.users z.val := C.mem_users.mpr ⟨p,c,d,hP,by
      rcases hcd with ⟨h1,_⟩ | ⟨_,h2⟩
      · exact Or.inl (h1.trans hzx.symm)
      · exact Or.inr (h2.trans hzx.symm)⟩
    have hp := Finset.card_pos.mpr ⟨P,hm⟩
    have hg := C.refCount_ge z.val
    omega
  · by_cases hzu : z.val = u
    · have hm : P ∈ C.users z.val := C.mem_users.mpr ⟨p,c,d,hP,by
        rcases hcd with ⟨_,h2⟩ | ⟨h1,_⟩
        · exact Or.inr (h2.trans hzu.symm)
        · exact Or.inl (h1.trans hzu.symm)⟩
      have hp := Finset.card_pos.mpr ⟨P,hm⟩
      have hg := C.refCount_ge z.val
      omega
    · have hr' := replaceAt_refCount C (f := f) hq hxq huq z.val
      change R.refCount z.val + _ = _ at hr'
      have hzP : z.val ≠ P := by have := z.isLt; have := (C.gateAt_bounds hP).1; omega
      rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> split_ifs at hr' <;> omega

theorem triangle_reduced_core {n : Nat} (h2 : 2 ≤ n) (C : OpenCircuit n)
    (hr : C.Reduced) (hsafe : C.DGateSafe) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z)
    {q x P u : Nat} {g p f : Table} {i j c d : Nat}
    (hq : C.gateAt q = some (g,i,j)) (hij : (i = x ∧ j = P) ∨ (i = P ∧ j = x))
    (hx : x < n) (hP : C.gateAt P = some (p,c,d))
    (hcd : (c = x ∧ d = u) ∨ (c = u ∧ d = x)) (hw : f.psi2W ≤ g.psi2W)
    (hv : ∀ v, f.eval (C.valueAt v x) (C.valueAt v u) =
      g.eval (C.valueAt v i) (C.valueAt v j)) :
    ∃ D : OpenCircuit n, D.Reduced ∧ (∀ v, D.eval v = C.eval v) ∧ D.psi2 ≤ C.psi2 ∧
      D.size ≤ C.size ∧ (D.size = C.size → D.predecessorSum < C.predecessorSum) := by
  let R := replaceAt C q f x u
  obtain ⟨_,_,hiq,hjq⟩ := C.gateAt_bounds hq
  obtain ⟨_,_,hcP,hdP⟩ := C.gateAt_bounds hP
  have hPq : P < q := by rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have hxq : x < q := by rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have huP : u < P := by rcases hcd with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have huq : u < q := by omega
  have hxu : x ≠ u := by
    have hd := (C.reduced_gate hr hP).2.1
    rcases hcd with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have he : ∀ v, R.eval v = C.eval v := fun v => replaceAt_eval C hq hxq huq v (hv v)
  have husedR : ∀ z : Fin n, 0 < R.usage (singleUse z) → Essential R.eval z := by
    intro z hz
    have hzC : 0 < C.usage (singleUse z) := by
      rw [R.usage_singleUse] at hz
      rw [C.usage_singleUse]
      by_cases hzx : z.val = x
      · have hm : P ∈ C.users z.val := C.mem_users.mpr ⟨p,c,d,hP,by
          rcases hcd with ⟨h1,_⟩ | ⟨_,h2⟩
          · exact Or.inl (h1.trans hzx.symm)
          · exact Or.inr (h2.trans hzx.symm)⟩
        have hp := Finset.card_pos.mpr ⟨P,hm⟩
        have hg := C.refCount_ge z.val
        omega
      · by_cases hzu : z.val = u
        · have hm : P ∈ C.users z.val := C.mem_users.mpr ⟨p,c,d,hP,by
            rcases hcd with ⟨_,h2⟩ | ⟨h1,_⟩
            · exact Or.inr (h2.trans hzu.symm)
            · exact Or.inl (h1.trans hzu.symm)⟩
          have hp := Finset.card_pos.mpr ⟨P,hm⟩
          have hg := C.refCount_ge z.val
          omega
        · have hr' := replaceAt_refCount C (f := f) hq hxq huq z.val
          change R.refCount z.val + _ = _ at hr'
          have hzP : z.val ≠ P := by have := z.isLt; have := (C.gateAt_bounds hP).1; omega
          rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> split_ifs at hr' <;> omega
    obtain ⟨v,w,hvw,hne⟩ := hused z hzC
    exact ⟨v,w,hvw,by simpa only [he] using hne⟩
  have hdrop : R.psi2 ≤ C.psi2 :=
    replaceAt_twoLevel_potential_le C hsafe hE1 hused hq hij hx hP hcd hw
  have hRsize : R.size = C.size := replaceAt_size C q f x u
  have hRpred : R.predecessorSum < C.predecessorSum := by
    change (replaceAt C q f x u).predecessorSum < C.predecessorSum
    have hh := replaceAt_predecessorSum C (f := f) hq hxq huq
    rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  cases hf : f.essential with
  | true =>
    exact essential_triangle_reduced h2 C hr hsafe hE1 hused hq hij hx hP hcd hw hf hv
  | false =>
    have hdist : R.DistinctOperands := replaceAt_distinct_operands C hr q f x u hxu
    have heval : R.eval = C.eval := funext he
    have hE1R : E1 R.eval := by rw [heval]; exact hE1
    have hgateR : R.gateAt q = some (f,x,u) := replaceAt_gateAt_self C hq f hxq huq
    obtain ⟨D,hD,hDe,hDp,hDs⟩ := R.degenerate_resolution_reduced h2 hdist hE1R husedR q f x u hgateR hf
    refine ⟨D,hD,fun v => (hDe v).trans (he v),le_trans hDp hdrop,by omega,?_⟩
    intro heq
    omega

theorem triangle_reduced_core_support {n : Nat} (h2 : 2 ≤ n) (C : OpenCircuit n)
    (hr : C.Reduced) (hsafe : C.DGateSafe) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z)
    {q x P u : Nat} {g p f : Table} {i j c d : Nat}
    (hq : C.gateAt q = some (g,i,j)) (hij : (i = x ∧ j = P) ∨ (i = P ∧ j = x))
    (hx : x < n) (hP : C.gateAt P = some (p,c,d))
    (hcd : (c = x ∧ d = u) ∨ (c = u ∧ d = x)) (hw : f.psi2W ≤ g.psi2W)
    (hv : ∀ v, f.eval (C.valueAt v x) (C.valueAt v u) =
      g.eval (C.valueAt v i) (C.valueAt v j)) :
    ∃ D : OpenCircuit n, D.Reduced ∧ (∀ v, D.eval v = C.eval v) ∧ D.psi2 ≤ C.psi2 ∧
      D.size ≤ C.size ∧ (D.size = C.size → D.predecessorSum < C.predecessorSum) ∧
      (∀ z : Fin n, 0 < D.usage (singleUse z) → 0 < C.usage (singleUse z)) := by
  let R := replaceAt C q f x u
  obtain ⟨_,_,hiq,hjq⟩ := C.gateAt_bounds hq
  obtain ⟨_,_,hcP,hdP⟩ := C.gateAt_bounds hP
  have hPq : P < q := by rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have hxq : x < q := by rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have huP : u < P := by rcases hcd with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have huq : u < q := by omega
  have hxu : x ≠ u := by
    have hd := (C.reduced_gate hr hP).2.1
    rcases hcd with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have he : ∀ v, R.eval v = C.eval v := fun v => replaceAt_eval C hq hxq huq v (hv v)
  have husedR : ∀ z : Fin n, 0 < R.usage (singleUse z) → Essential R.eval z := by
    intro z hz
    have hzC : 0 < C.usage (singleUse z) := by
      rw [R.usage_singleUse] at hz
      rw [C.usage_singleUse]
      by_cases hzx : z.val = x
      · have hm : P ∈ C.users z.val := C.mem_users.mpr ⟨p,c,d,hP,by
          rcases hcd with ⟨h1,_⟩ | ⟨_,h2⟩
          · exact Or.inl (h1.trans hzx.symm)
          · exact Or.inr (h2.trans hzx.symm)⟩
        have hp := Finset.card_pos.mpr ⟨P,hm⟩
        have hg := C.refCount_ge z.val
        omega
      · by_cases hzu : z.val = u
        · have hm : P ∈ C.users z.val := C.mem_users.mpr ⟨p,c,d,hP,by
            rcases hcd with ⟨_,h2⟩ | ⟨h1,_⟩
            · exact Or.inr (h2.trans hzu.symm)
            · exact Or.inl (h1.trans hzu.symm)⟩
          have hp := Finset.card_pos.mpr ⟨P,hm⟩
          have hg := C.refCount_ge z.val
          omega
        · have hr' := replaceAt_refCount C (f := f) hq hxq huq z.val
          change R.refCount z.val + _ = _ at hr'
          have hzP : z.val ≠ P := by have := z.isLt; have := (C.gateAt_bounds hP).1; omega
          rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> split_ifs at hr' <;> omega
    obtain ⟨v,w,hvw,hne⟩ := hused z hzC
    exact ⟨v,w,hvw,by simpa only [he] using hne⟩
  have hdrop : R.psi2 ≤ C.psi2 :=
    replaceAt_twoLevel_potential_le C hsafe hE1 hused hq hij hx hP hcd hw
  have hRsize : R.size = C.size := replaceAt_size C q f x u
  have hRpred : R.predecessorSum < C.predecessorSum := by
    change (replaceAt C q f x u).predecessorSum < C.predecessorSum
    have hh := replaceAt_predecessorSum C (f := f) hq hxq huq
    rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  cases hf : f.essential with
  | true =>
    have hp : R.GateProper := replaceAt_proper_of_essential C hr hq hxq huq hxu hf
    obtain ⟨D,hD,hDe,hDp,hDs,hDpred,hDused⟩ := R.exists_reduced_potential_le_size_support h2 hp husedR
    refine ⟨D,hD,fun v => (hDe v).trans (he v),le_trans hDp hdrop,by omega,?_,?_⟩
    · intro heq
      have heqR : D.size = R.size := by omega
      rw [hDpred heqR]
      exact hRpred
    · intro z hz
      exact triangle_usage_pos_of_rewrite C hq hij hP hcd z (hDused z hz)
  | false =>
    have hdist : R.DistinctOperands := replaceAt_distinct_operands C hr q f x u hxu
    have heval : R.eval = C.eval := funext he
    have hE1R : E1 R.eval := by rw [heval]; exact hE1
    have hgateR : R.gateAt q = some (f,x,u) := replaceAt_gateAt_self C hq f hxq huq
    obtain ⟨D,hD,hDe,hDp,hDs,hDused⟩ := R.degenerate_resolution_reduced_support h2 hdist hE1R husedR q f x u hgateR hf
    refine ⟨D,hD,fun v => (hDe v).trans (he v),le_trans hDp hdrop,by omega,?_,?_⟩
    · intro heq
      omega
    · intro z hz
      exact triangle_usage_pos_of_rewrite C hq hij hP hcd z (hDused z hz)

end PsiTriangleAux

/-- One complete triangle rewrite followed by resolution and pruning. -/
theorem twoLevel_triangle_reduced_step {n : Nat} (h2 : 2 ≤ n) (C : OpenCircuit n) (hr : C.Reduced)
    (hsafe : C.DGateSafe) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z)
    (ht : ¬ C.NoInputTriangles (fun _ => none)) :
    ∃ D : OpenCircuit n, D.Reduced ∧ (∀ x, D.eval x = C.eval x) ∧ D.psi2 ≤ C.psi2 ∧
      D.size ≤ C.size ∧ (D.size = C.size → D.predecessorSum < C.predecessorSum) := by
  obtain ⟨q,g,i,j,hq,htr⟩ := PsiTriangleAux.exists_flat_triangle C ht
  have hg : g.essential = true := C.essentialGates_gate (C.reduced_essential hr) hq
  have hgs : g.swap.essential = true := by rw [Table.swap_essential]; exact hg
  rcases htr with ⟨hin,t,c,d,hjP,hcd⟩ | ⟨hjn,t,c,d,hiP,hcd⟩
  · rcases hcd with hc | hd
    · refine PsiTriangleAux.triangle_reduced_core h2 C hr hsafe hE1 hused (x := i) (P := j) (u := d)
        (f := Table.triangle t g) hq (Or.inl ⟨rfl,rfl⟩) hin hjP (Or.inl ⟨hc,rfl⟩)
        (Table.triangle_psi2W t g hg) ?_
      intro v
      rw [Table.triangle_eval,valueAt_gate C v hjP,hc]
    · refine PsiTriangleAux.triangle_reduced_core h2 C hr hsafe hE1 hused (x := i) (P := j) (u := c)
        (f := Table.triangle t.swap g) hq (Or.inl ⟨rfl,rfl⟩) hin hjP (Or.inr ⟨rfl,hd⟩)
        (Table.triangle_psi2W t.swap g hg) ?_
      intro v
      rw [Table.triangle_eval,Table.swap_eval,valueAt_gate C v hjP,hd]
  · rcases hcd with hc | hd
    · refine PsiTriangleAux.triangle_reduced_core h2 C hr hsafe hE1 hused (x := j) (P := i) (u := d)
        (f := Table.triangle t g.swap) hq (Or.inr ⟨rfl,rfl⟩) hjn hiP (Or.inl ⟨hc,rfl⟩)
        (Nat.le_trans (Table.triangle_psi2W t g.swap hgs) (Nat.le_of_eq (Table.swap_psi2W g))) ?_
      intro v
      rw [Table.triangle_eval,Table.swap_eval,valueAt_gate C v hiP,hc]
    · refine PsiTriangleAux.triangle_reduced_core h2 C hr hsafe hE1 hused (x := j) (P := i) (u := c)
        (f := Table.triangle t.swap g.swap) hq (Or.inr ⟨rfl,rfl⟩) hjn hiP (Or.inr ⟨rfl,hd⟩)
        (Nat.le_trans (Table.triangle_psi2W t.swap g.swap hgs) (Nat.le_of_eq (Table.swap_psi2W g))) ?_
      intro v
      rw [Table.triangle_eval,Table.swap_eval,Table.swap_eval,valueAt_gate C v hiP,hd]



theorem twoLevel_triangle_reduced_step_support {n : Nat} (h2 : 2 ≤ n) (C : OpenCircuit n) (hr : C.Reduced)
    (hsafe : C.DGateSafe) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z)
    (ht : ¬ C.NoInputTriangles (fun _ => none)) :
    ∃ D : OpenCircuit n, D.Reduced ∧ (∀ x, D.eval x = C.eval x) ∧ D.psi2 ≤ C.psi2 ∧
      D.size ≤ C.size ∧ (D.size = C.size → D.predecessorSum < C.predecessorSum) ∧
      (∀ z : Fin n, 0 < D.usage (singleUse z) → 0 < C.usage (singleUse z)) := by
  obtain ⟨q,g,i,j,hq,htr⟩ := PsiTriangleAux.exists_flat_triangle C ht
  have hg : g.essential = true := C.essentialGates_gate (C.reduced_essential hr) hq
  have hgs : g.swap.essential = true := by rw [Table.swap_essential]; exact hg
  rcases htr with ⟨hin,t,c,d,hjP,hcd⟩ | ⟨hjn,t,c,d,hiP,hcd⟩
  · rcases hcd with hc | hd
    · refine PsiTriangleAux.triangle_reduced_core_support h2 C hr hsafe hE1 hused (x := i) (P := j) (u := d)
        (f := Table.triangle t g) hq (Or.inl ⟨rfl,rfl⟩) hin hjP (Or.inl ⟨hc,rfl⟩)
        (Table.triangle_psi2W t g hg) ?_
      intro v
      rw [Table.triangle_eval,valueAt_gate C v hjP,hc]
    · refine PsiTriangleAux.triangle_reduced_core_support h2 C hr hsafe hE1 hused (x := i) (P := j) (u := c)
        (f := Table.triangle t.swap g) hq (Or.inl ⟨rfl,rfl⟩) hin hjP (Or.inr ⟨rfl,hd⟩)
        (Table.triangle_psi2W t.swap g hg) ?_
      intro v
      rw [Table.triangle_eval,Table.swap_eval,valueAt_gate C v hjP,hd]
  · rcases hcd with hc | hd
    · refine PsiTriangleAux.triangle_reduced_core_support h2 C hr hsafe hE1 hused (x := j) (P := i) (u := d)
        (f := Table.triangle t g.swap) hq (Or.inr ⟨rfl,rfl⟩) hjn hiP (Or.inl ⟨hc,rfl⟩)
        (Nat.le_trans (Table.triangle_psi2W t g.swap hgs) (Nat.le_of_eq (Table.swap_psi2W g))) ?_
      intro v
      rw [Table.triangle_eval,Table.swap_eval,valueAt_gate C v hiP,hc]
    · refine PsiTriangleAux.triangle_reduced_core_support h2 C hr hsafe hE1 hused (x := j) (P := i) (u := c)
        (f := Table.triangle t.swap g.swap) hq (Or.inr ⟨rfl,rfl⟩) hjn hiP (Or.inr ⟨rfl,hd⟩)
        (Nat.le_trans (Table.triangle_psi2W t.swap g.swap hgs) (Nat.le_of_eq (Table.swap_psi2W g))) ?_
      intro v
      rw [Table.triangle_eval,Table.swap_eval,Table.swap_eval,valueAt_gate C v hiP,hd]


/-- Two-level normalization by the manuscript's lexicographic descent,
for functions essential in every primary coordinate. -/
theorem psi2_normalize_all_essential {n : Nat} (h2 : 2 ≤ n) (C : OpenCircuit n)
    (hr : C.Reduced) (hE1 : E1 C.eval) (hall : ∀ z : Fin n, Essential C.eval z) :
    ∃ D : OpenCircuit n, D.Reduced ∧ D.NoInputTriangles (fun _ => none) ∧
      (∀ v, D.eval v = C.eval v) ∧ D.psi2 ≤ C.psi2 ∧ D.size ≤ C.size := by
  suffices h : ∀ s p, ∀ C : OpenCircuit n, C.size = s → C.predecessorSum = p →
      C.Reduced → E1 C.eval → (∀ z : Fin n, Essential C.eval z) →
      ∃ D : OpenCircuit n, D.Reduced ∧ D.NoInputTriangles (fun _ => none) ∧
        (∀ v, D.eval v = C.eval v) ∧ D.psi2 ≤ C.psi2 ∧ D.size ≤ C.size from
    h C.size C.predecessorSum C rfl rfl hr hE1 hall
  intro s
  induction s using Nat.strong_induction_on with
  | h s ihs =>
    intro p
    induction p using Nat.strong_induction_on with
    | h p ihp =>
      intro C hs hp hr hE1 hall
      by_cases ht : C.NoInputTriangles (fun _ => none)
      · exact ⟨C,hr,ht,fun _ => rfl,le_rfl,le_rfl⟩
      · have hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z :=
          fun z _ => hall z
        have hsafe := forbid_a_of_distinct C.eval C (C.reduced_distinct hr)
          (fun _ => rfl) hE1 hused
        obtain ⟨E,hE,heval,hpsi,hsize,hpred⟩ := C.twoLevel_triangle_reduced_step h2 hr hsafe hE1 hused ht
        have heq : E.eval = C.eval := funext heval
        have hE1E : E1 E.eval := by rw [heq]; exact hE1
        have hallE : ∀ z : Fin n, Essential E.eval z := by rw [heq]; exact hall
        by_cases hlt : E.size < C.size
        · obtain ⟨D,hD,htri,hDe,hDp,hDs⟩ := ihs E.size (by omega)
            E.predecessorSum E rfl rfl hE hE1E hallE
          exact ⟨D,hD,htri,fun v => (hDe v).trans (heval v),le_trans hDp hpsi,by omega⟩
        · have heqs : E.size = C.size := by omega
          have hltp : E.predecessorSum < p := by have := hpred heqs; omega
          obtain ⟨D,hD,htri,hDe,hDp,hDs⟩ := ihp E.predecessorSum hltp
            E (by omega) rfl hE hE1E hallE
          exact ⟨D,hD,htri,fun v => (hDe v).trans (heval v),le_trans hDp hpsi,by omega⟩


/-- The same descent with unused ambient coordinates, as needed after restrictions. -/
theorem psi2_normalize_used_essential {n : Nat} (h2 : 2 ≤ n) (C : OpenCircuit n)
    (hr : C.Reduced) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z) :
    ∃ D : OpenCircuit n, D.Reduced ∧ D.NoInputTriangles (fun _ => none) ∧
      (∀ v, D.eval v = C.eval v) ∧ D.psi2 ≤ C.psi2 ∧ D.size ≤ C.size := by
  suffices h : ∀ s p, ∀ C : OpenCircuit n, C.size = s → C.predecessorSum = p →
      C.Reduced → E1 C.eval →
      (∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z) →
      ∃ D : OpenCircuit n, D.Reduced ∧ D.NoInputTriangles (fun _ => none) ∧
        (∀ v, D.eval v = C.eval v) ∧ D.psi2 ≤ C.psi2 ∧ D.size ≤ C.size from
    h C.size C.predecessorSum C rfl rfl hr hE1 hused
  intro s
  induction s using Nat.strong_induction_on with
  | h s ihs =>
    intro p
    induction p using Nat.strong_induction_on with
    | h p ihp =>
      intro C hs hp hr hE1 hused
      by_cases ht : C.NoInputTriangles (fun _ => none)
      · exact ⟨C,hr,ht,fun _ => rfl,le_rfl,le_rfl⟩
      · have hsafe := forbid_a_of_distinct C.eval C (C.reduced_distinct hr)
          (fun _ => rfl) hE1 hused
        obtain ⟨E,hE,heval,hpsi,hsize,hpred,hsupport⟩ := C.twoLevel_triangle_reduced_step_support h2 hr hsafe hE1 hused ht
        have heq : E.eval = C.eval := funext heval
        have hE1E : E1 E.eval := by rw [heq]; exact hE1
        have husedE : ∀ z : Fin n, 0 < E.usage (singleUse z) → Essential E.eval z := by
          intro z hz
          rw [heq]
          exact hused z (hsupport z hz)
        by_cases hlt : E.size < C.size
        · obtain ⟨D,hD,htri,hDe,hDp,hDs⟩ := ihs E.size (by omega)
            E.predecessorSum E rfl rfl hE hE1E husedE
          exact ⟨D,hD,htri,fun v => (hDe v).trans (heval v),le_trans hDp hpsi,by omega⟩
        · have heqs : E.size = C.size := by omega
          have hltp : E.predecessorSum < p := by have := hpred heqs; omega
          obtain ⟨D,hD,htri,hDe,hDp,hDs⟩ := ihp E.predecessorSum hltp
            E (by omega) rfl hE hE1E husedE
          exact ⟨D,hD,htri,fun v => (hDe v).trans (heval v),le_trans hDp hpsi,by omega⟩


/-- Normalization additionally preserves the set of used coordinates. -/
theorem psi2_normalize_used_essential_support {n : Nat} (h2 : 2 ≤ n) (C : OpenCircuit n)
    (hr : C.Reduced) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z) :
    ∃ D : OpenCircuit n, D.Reduced ∧ D.NoInputTriangles (fun _ => none) ∧
      (∀ v, D.eval v = C.eval v) ∧ D.psi2 ≤ C.psi2 ∧ D.size ≤ C.size ∧
      (∀ z : Fin n, 0 < D.usage (singleUse z) → 0 < C.usage (singleUse z)) := by
  suffices h : ∀ s p, ∀ C : OpenCircuit n, C.size = s → C.predecessorSum = p →
      C.Reduced → E1 C.eval →
      (∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z) →
      ∃ D : OpenCircuit n, D.Reduced ∧ D.NoInputTriangles (fun _ => none) ∧
        (∀ v, D.eval v = C.eval v) ∧ D.psi2 ≤ C.psi2 ∧ D.size ≤ C.size ∧
      (∀ z : Fin n, 0 < D.usage (singleUse z) → 0 < C.usage (singleUse z)) from
    h C.size C.predecessorSum C rfl rfl hr hE1 hused
  intro s
  induction s using Nat.strong_induction_on with
  | h s ihs =>
    intro p
    induction p using Nat.strong_induction_on with
    | h p ihp =>
      intro C hs hp hr hE1 hused
      by_cases ht : C.NoInputTriangles (fun _ => none)
      · exact ⟨C,hr,ht,fun _ => rfl,le_rfl,le_rfl,fun _ hz => hz⟩
      · have hsafe := forbid_a_of_distinct C.eval C (C.reduced_distinct hr)
          (fun _ => rfl) hE1 hused
        obtain ⟨E,hE,heval,hpsi,hsize,hpred,hsupport⟩ := C.twoLevel_triangle_reduced_step_support h2 hr hsafe hE1 hused ht
        have heq : E.eval = C.eval := funext heval
        have hE1E : E1 E.eval := by rw [heq]; exact hE1
        have husedE : ∀ z : Fin n, 0 < E.usage (singleUse z) → Essential E.eval z := by
          intro z hz
          rw [heq]
          exact hused z (hsupport z hz)
        by_cases hlt : E.size < C.size
        · obtain ⟨D,hD,htri,hDe,hDp,hDs,hDu⟩ := ihs E.size (by omega)
            E.predecessorSum E rfl rfl hE hE1E husedE
          exact ⟨D,hD,htri,fun v => (hDe v).trans (heval v),le_trans hDp hpsi,by omega,
            fun z hz => hsupport z (hDu z hz)⟩
        · have heqs : E.size = C.size := by omega
          have hltp : E.predecessorSum < p := by have := hpred heqs; omega
          obtain ⟨D,hD,htri,hDe,hDp,hDs,hDu⟩ := ihp E.predecessorSum hltp
            E (by omega) rfl hE hE1E husedE
          exact ⟨D,hD,htri,fun v => (hDe v).trans (heval v),le_trans hDp hpsi,by omega,
            fun z hz => hsupport z (hDu z hz)⟩

/-- The two-level normalization lemma for proper circuits, including circuits
with dead gates and unused primary coordinates. -/
theorem psi2_normalize_proper {n : Nat} (h2 : 2 ≤ n) (C : OpenCircuit n)
    (hp : C.GateProper) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z) :
    ∃ D : OpenCircuit n, D.Reduced ∧ D.NoInputTriangles (fun _ => none) ∧
      (∀ v, D.eval v = C.eval v) ∧ D.psi2 ≤ C.psi2 ∧ D.size ≤ C.size := by
  obtain ⟨R,hR,hRe,hRp,hRs,_,hRused⟩ := C.exists_reduced_potential_le_size_support h2 hp hused
  have heq : R.eval = C.eval := funext hRe
  have hE1R : E1 R.eval := by rw [heq]; exact hE1
  have husedR : ∀ z : Fin n, 0 < R.usage (singleUse z) → Essential R.eval z := by
    intro z hz
    rw [heq]
    exact hused z (hRused z hz)
  obtain ⟨D,hD,htri,hDe,hDp,hDs⟩ := R.psi2_normalize_used_essential h2 hR hE1R husedR
  exact ⟨D,hD,htri,fun v => (hDe v).trans (hRe v),le_trans hDp hRp,by omega⟩


/-- Proper-circuit normalization with explicit support preservation. -/
theorem psi2_normalize_proper_support {n : Nat} (h2 : 2 ≤ n) (C : OpenCircuit n)
    (hp : C.GateProper) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z) :
    ∃ D : OpenCircuit n, D.Reduced ∧ D.NoInputTriangles (fun _ => none) ∧
      (∀ v, D.eval v = C.eval v) ∧ D.psi2 ≤ C.psi2 ∧ D.size ≤ C.size ∧
      (∀ z : Fin n, 0 < D.usage (singleUse z) → 0 < C.usage (singleUse z)) := by
  obtain ⟨R,hR,hRe,hRp,hRs,_,hRused⟩ := C.exists_reduced_potential_le_size_support h2 hp hused
  have heq : R.eval = C.eval := funext hRe
  have hE1R : E1 R.eval := by rw [heq]; exact hE1
  have husedR : ∀ z : Fin n, 0 < R.usage (singleUse z) → Essential R.eval z := by
    intro z hz
    rw [heq]
    exact hused z (hRused z hz)
  obtain ⟨D,hD,htri,hDe,hDp,hDs,hDu⟩ := R.psi2_normalize_used_essential_support h2 hR hE1R husedR
  exact ⟨D,hD,htri,fun v => (hDe v).trans (hRe v),le_trans hDp hRp,by omega,
    fun z hz => hRused z (hDu z hz)⟩

end OpenCircuit
end SatLowerBound
