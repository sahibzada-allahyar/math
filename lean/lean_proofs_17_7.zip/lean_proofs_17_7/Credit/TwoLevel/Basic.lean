import Credit.Basic

/-! Definitions for the two-level potential in Section 7 of the SAT manuscript.
A reference counts operand slots and the circuit output, as in Credit.Basic.
The correspondence with the manuscript's distinct-successor convention must be
proved under its normalization and semantic hypotheses before using these definitions.
-/

namespace SatLowerBound
namespace Table

/-- The gate contribution to the two-level potential: 7 for parity, 4 for nonlinear. -/
def psi2W (g : Table) : Nat := 7 * g.parityCount + 4 * g.nonlinearCount

theorem psi2W_nonnegative (g : Table) : 0 ≤ g.psi2W := Nat.zero_le _

theorem psi2W_le_seven (g : Table) : g.psi2W ≤ 7 := by
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem twist_psi2W (g : Table) (a b : Bool) : (twist g a b).psi2W = g.psi2W := by
  simp only [psi2W, Table.parityCount, Table.nonlinearCount, twist_parity, twist_nonlinear]

end Table

namespace OpenCircuit

/-- The gate weight `7X + 4A`. -/
def psi2Weight : {n : Nat} → OpenCircuit n → Nat
  | _, .output _ => 0
  | _, .gate g _ _ rest => g.psi2W + rest.psi2Weight

/-- A two-level credit: the input has a unique nonlinear reader, and that reader
has a unique nonlinear reader in turn. The finite search ranges over real gates. -/
def isDStar {n : Nat} (C : OpenCircuit n) (z : Nat) : Bool :=
  C.isD z && decide (∃ w ∈ C.users z, C.isD w = true)

def dStarCount {n : Nat} (C : OpenCircuit n) : Nat :=
  ∑ z : Fin n, indicator (C.isDStar z.val)

/-- The manuscript's `Ψ₂ = 7X + 4A - D - D*`. -/
def psi2 {n : Nat} (C : OpenCircuit n) : Int :=
  (C.psi2Weight : Int) - C.dCount - C.dStarCount

theorem isD_of_isDStar {n : Nat} (C : OpenCircuit n) (z : Nat)
    (h : C.isDStar z = true) : C.isD z = true := by
  simp only [isDStar, Bool.and_eq_true] at h
  exact h.1

theorem isDStar_iff {n : Nat} (C : OpenCircuit n) (z : Nat) :
    C.isDStar z = true ↔ C.isD z = true ∧
      ∃ w ∈ C.users z, C.isD w = true := by
  simp [isDStar]

theorem dStarCount_le_dCount {n : Nat} (C : OpenCircuit n) :
    C.dStarCount ≤ C.dCount := by
  unfold dStarCount dCount
  apply Finset.sum_le_sum
  intro z _
  simp only [isDStar, indicator]
  by_cases h : C.isD z.val = true
  · simp only [h, Bool.true_and, ite_true]
    split <;> decide
  · have hf : C.isD z.val = false := Bool.eq_false_iff.mpr h
    simp [hf]

theorem psi2Weight_eq {n : Nat} (C : OpenCircuit n) :
    C.psi2Weight = 7 * C.parityCount + 4 * C.nonlinearCount := by
  induction C with
  | output s => simp [psi2Weight, parityCount, nonlinearCount]
  | gate g i j rest ih =>
    simp only [psi2Weight, parityCount, nonlinearCount, Table.psi2W, ih]
    omega

/-- Exact gate-count identity used when converting the potential into a size bound. -/
theorem seven_size {n : Nat} (C : OpenCircuit n) (he : C.EssentialGates) :
    7 * C.size = C.psi2Weight + 3 * C.nonlinearCount := by
  rw [psi2Weight_eq, size_eq_counts C he]
  omega

/-- Algebraic conversion in the two-level composition theorem of the manuscript. The hypotheses are
explicit: this lemma does not assert the two-level potential bound or the degree bound. -/
theorem size_bound_of_potential {n : Nat} (C : OpenCircuit n)
    (he : C.EssentialGates) (L B k : Nat)
    (hpot : 14 * ((L : Int) - ((k : Int) + 1) * B) ≤ C.psi2)
    (hdegree : (L : Int) - 1 ≤ C.nonlinearCount) :
    17 * (L : Int) - 14 * ((k : Int) + 1) * B - 3 ≤ 7 * (C.size : Int) := by
  have hsize : 7 * (C.size : Int) = (C.psi2Weight : Int) + 3 * C.nonlinearCount := by
    exact_mod_cast C.seven_size he
  unfold psi2 at hpot
  ring_nf at hpot ⊢
  omega

end OpenCircuit
end SatLowerBound
