import Credit.TwoLevel.TightCorner

/-! Good/bad successor reduction in Main Lemma B. -/
namespace SatLowerBound
namespace MAContext
open OpenCircuit

/-- The structural and restriction-trace conditions called "bad" in the
manuscript, including the fact that the companion reader does not become
constant at the chosen blocking value. -/
def BadReader {n : Nat} (C : OpenCircuit n) (x : Fin n) (P Q : Nat) : Prop :=
  ∃ b : Bool, ∃ S : Nat, C.users P = {S} ∧
    (C.resAt (singleRes x b) P).isConst = true ∧
    (C.resAt (singleRes x b) Q).isConst = false ∧
    (C.resAt (singleRes x b) S).isConst = false ∧
    (C.tableAt S).parity = false

/-- If fixing neither value of `x` gives the drop, every nonlinear direct
reader `P` with a distinct companion `Q` has a unique, nonlinear successor
that survives blocking `P`. -/
theorem nonlinear_reader_bad_of_no_drop {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x : Fin n) (hx2 : 2 ≤ C.refCount x.val)
    (P Q : Nat) (hPQ : P ≠ Q) (hPx : P ∈ C.users x.val) (hQx : Q ∈ C.users x.val)
    (hPpar : (C.tableAt P).parity = false)
    (hno : ∀ b, ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2)) :
    BadReader C x P Q := by
  obtain ⟨g,a,d,hg,had⟩ := C.mem_users.mp hPx
  have hnl : g.nonlinear = true := by
    rcases g.essential_parity_or_nonlinear (h.gate_facts hg).1 with hp | hn
    · have hp' : (C.tableAt P).parity = true := by simp [tableAt,hg,hp]
      rw [hp'] at hPpar
      contradiction
    · exact hn
  have hxres : ∀ b : Bool, C.resAt (singleRes x b) x.val = .const b := by
    intro b
    rw [C.resAt_single_input x b x]
    simp
  obtain ⟨b,hPc⟩ : ∃ b, (C.resAt (singleRes x b) P).isConst = true := by
    rcases had with ha | hd
    · obtain ⟨b,hb,_⟩ := g.nonlinear_exists_blocksLeft hnl
      refine ⟨b,?_⟩
      rw [C.resAt_gate _ hg, ha, hxres b, Res.step_blocked_left g b _ hb]
      rfl
    · obtain ⟨b,hb,_⟩ := g.nonlinear_exists_blocksRight hnl
      refine ⟨b,?_⟩
      rw [C.resAt_gate _ hg, hd, hxres b, Res.step_blocked_right g _ b hb]
      rfl
  have hQnc : (C.resAt (singleRes x b) Q).isConst = false := by
    apply Bool.eq_false_iff.mpr
    intro hQc
    exact hno b (h.case_both_constant_twoLevel x b hx2 hPQ hPx hQx hPc hQc)
  have hPb := C.gateAt_bounds hg
  obtain ⟨hne,_⟩ := h.const_users x b hPb.1 hPb.2.1 hPc
  have hle : (C.users P).card ≤ 1 := by
    by_contra hn
    have hm : 1 < (C.users P).card := by omega
    exact hno b (h.case_blocked_two_successors_twoLevel x b hx2 hPQ hPx hQx hPpar hPc hm)
  have hcard : (C.users P).card = 1 := by
    have hp := Finset.card_pos.mpr hne
    omega
  obtain ⟨S,hS⟩ := Finset.card_eq_one.mp hcard
  have hSP : S ∈ C.users P := by rw [hS]; simp
  have hSpar : (C.tableAt S).parity = false := by
    apply Bool.eq_false_iff.mpr
    intro hp
    exact hno b (h.case_blocked_with_parity_twoLevel x b hx2 hPQ hPx hQx hPpar hPc
      (Or.inr ⟨S,hSP,hp⟩))
  have hSnc : (C.resAt (singleRes x b) S).isConst = false := by
    apply Bool.eq_false_iff.mpr
    intro hc
    exact hno b (h.case_successor_constant_twoLevel x b hx2 hPQ hPx hQx hPc hSP hc)
  exact ⟨b,S,hS,hPc,hQnc,hSnc,hSpar⟩

/-- In the tight configuration, the distinct-chain case already yields a
drop, so failure of the drop forces `V₂` to be either `U` or `R`. -/
theorem tight_no_drop_forces_second_overlap {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x y : Fin n) (hxy : x ≠ y) (b : Bool)
    (hx2 : 2 ≤ C.refCount x.val) (T U R V V₂ : Nat) (hTfirst : T = n)
    (hTU : T ≠ U) (hTV : T ≠ V) (hUV : U ≠ V)
    (hTx : T ∈ C.users x.val) (hUx : U ∈ C.users x.val)
    (husersY : C.users y.val = {T,V})
    {gT : Table} {aT dT : Nat} (hgT : C.gateAt T = some (gT,aT,dT))
    (haT : aT < n) (hdT : dT < n) (hTc : (C.resAt (singleRes x b) T).isConst = true)
    (hRT : R ∈ C.users T) (hTpar : (C.tableAt T).parity = false)
    (hUpar : (C.tableAt U).parity = false) (hRpar : (C.tableAt R).parity = false)
    (hVpar : (C.tableAt V).parity = false) (husersV : C.users V = {V₂})
    (hV₂par : (C.tableAt V₂).parity = false)
    (hno : ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2)) :
    V₂ = U ∨ V₂ = R := by
  by_contra hn
  have hV₂U : V₂ ≠ U := fun he => hn (Or.inl he)
  have hV₂R : V₂ ≠ R := fun he => hn (Or.inr he)
  have hTy : T ∈ C.users y.val := by rw [husersY]; simp
  have hVy : V ∈ C.users y.val := by rw [husersY]; simp
  have hV₂V : V₂ ∈ C.users V := by rw [husersV]; simp
  have hRy : R ∉ C.users y.val := h.no_triangle y.isLt hTy hRT
  have hVR : V ≠ R := fun he => hRy (he ▸ hVy)
  obtain ⟨gV,aV,dV,hgV,_⟩ := C.mem_users.mp hVy
  obtain ⟨g₂,a₂,d₂,hg₂,hab₂⟩ := C.mem_users.mp hV₂V
  have hVnl : gV.nonlinear = true := by
    rcases gV.essential_parity_or_nonlinear (h.gate_facts hgV).1 with hp | hn'
    · have hp' : (C.tableAt V).parity = true := by simp [tableAt,hgV,hp]
      rw [hp'] at hVpar
      contradiction
    · exact hn'
  have hV₂nl : g₂.nonlinear = true := by
    rcases g₂.essential_parity_or_nonlinear (h.gate_facts hg₂).1 with hp | hn'
    · have hp' : (C.tableAt V₂).parity = true := by simp [tableAt,hg₂,hp]
      rw [hp'] at hV₂par
      contradiction
    · exact hn'
  have hV₂gt : V < V₂ := by
    have hh := C.gateAt_bounds hg₂
    rcases hab₂ with he | he <;> omega
  have hVge : n ≤ V := (C.gateAt_bounds hgV).1
  have hVout : V ∉ ({T,U,R} : Finset Nat) := by
    simp only [Finset.mem_insert, Finset.mem_singleton, not_or]
    exact ⟨Ne.symm hTV,Ne.symm hUV,hVR⟩
  have hV₂out : V₂ ∉ ({T,U,R} : Finset Nat) := by
    have hTlt : T < V₂ := by omega
    simp only [Finset.mem_insert, Finset.mem_singleton, not_or]
    exact ⟨by omega,hV₂U,hV₂R⟩
  exact hno (h.tight_distinct_chain_or_four x y hxy b hx2 T U R V V₂ hTU hTx hUx
    hgT haT hdT hTc hRT hTpar hUpar hRpar hTV husersY hgV hVnl husersV
    hg₂ hV₂nl hVout hV₂out)

/-- The no-drop tight configuration has distinct other readers, and both
are bad in the sense used by the manuscript's final case split. -/
theorem no_drop_forces_both_bad {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (hS4 : S4Essential f) {t : Table} {i j : Fin n}
    {rest : OpenCircuit (n+1)} (hC : C = .gate t i j rest) (hnl : t.nonlinear = true)
    (hno : ∀ x, (x = i ∨ x = j) → ∀ b,
      ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2)) :
    ∃ U V R ε, U ≠ V ∧ U ≠ n ∧ V ≠ n ∧
      C.users i.val = {n,U} ∧ C.users j.val = {n,V} ∧ C.users n = {R} ∧
      t.blocksLeft ε = true ∧ (C.resAt (singleRes i ε) n).isConst = true ∧
      (C.resAt (singleRes i ε) U).isConst = false ∧
      (C.resAt (singleRes i ε) R).isConst = false ∧
      (C.tableAt U).parity = false ∧ (C.tableAt R).parity = false ∧
      BadReader C i U n ∧ BadReader C j V n := by
  obtain ⟨U,V,R,ε,hUV,hUn,hVn,hUi,hVj,hR,hε,hTc,hUnc,hRnc,hUpar,hRpar⟩ :=
    h.nonlinear_no_drop_tight_corner_distinct hS4 hC hnl hno
  obtain ⟨hi,hj,_⟩ := h.nonlinear_no_drop_reduces_to_tight hC hnl hno
  have hT : C.gateAt n = some (t,i.val,j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hTi : n ∈ C.users i.val := C.mem_users.mpr ⟨t,i.val,j.val,hT,Or.inl rfl⟩
  have hTj : n ∈ C.users j.val := C.mem_users.mpr ⟨t,i.val,j.val,hT,Or.inr rfl⟩
  have hU : U ∈ C.users i.val := by rw [hUi]; simp
  have hV : V ∈ C.users j.val := by rw [hVj]; simp
  have hVpar : (C.tableAt V).parity = false := by
    apply Bool.eq_false_iff.mpr
    intro hp
    obtain ⟨b,hb⟩ := h.case_nonlinear_parity_twoLevel hC hnl j (Or.inr rfl)
      (by omega) V hVn hV (Or.inl hp)
    exact hno j (Or.inr rfl) b hb
  have hUbad := h.nonlinear_reader_bad_of_no_drop i (by omega) U n hUn hU hTi hUpar
    (fun b => hno i (Or.inl rfl) b)
  have hVbad := h.nonlinear_reader_bad_of_no_drop j (by omega) V n hVn hV hTj hVpar
    (fun b => hno j (Or.inr rfl) b)
  exact ⟨U,V,R,ε,hUV,hUn,hVn,hUi,hVj,hR,hε,hTc,hUnc,hRnc,hUpar,hRpar,hUbad,hVbad⟩

/-- Under the no-drop assumption, the second gate in the bad `V` chain
must be `U` or the first gate's unique successor `R`. -/
theorem no_drop_forces_bad_overlap {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (hS4 : S4Essential f) {t : Table} {i j : Fin n}
    {rest : OpenCircuit (n+1)} (hC : C = .gate t i j rest) (hnl : t.nonlinear = true)
    (hno : ∀ x, (x = i ∨ x = j) → ∀ b,
      ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2)) :
    ∃ U V R V₂ ε, U ≠ V ∧ U ≠ n ∧ V ≠ n ∧
      C.users i.val = {n,U} ∧ C.users j.val = {n,V} ∧ C.users n = {R} ∧
      C.users V = {V₂} ∧ (V₂ = U ∨ V₂ = R) ∧
      t.blocksLeft ε = true ∧ (C.resAt (singleRes i ε) n).isConst = true ∧
      (C.resAt (singleRes i ε) U).isConst = false ∧
      (C.resAt (singleRes i ε) R).isConst = false ∧
      (C.tableAt U).parity = false ∧ (C.tableAt R).parity = false ∧
      BadReader C i U n ∧ BadReader C j V n := by
  obtain ⟨U,V,R,ε,hUV,hUn,hVn,hUi,hVj,hR,hε,hTc,hUnc,hRnc,hUpar,hRpar,hUbad,hVbad⟩ :=
    h.no_drop_forces_both_bad hS4 hC hnl hno
  obtain ⟨bV,V₂,hV₂,hVc,hTnc,hV₂nc,hV₂par⟩ := hVbad
  have hVbad' : BadReader C j V n := ⟨bV,V₂,hV₂,hVc,hTnc,hV₂nc,hV₂par⟩
  obtain ⟨hi,_,_⟩ := h.nonlinear_no_drop_reduces_to_tight hC hnl hno
  have hT : C.gateAt n = some (t,i.val,j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hij : i ≠ j := fun he => (h.gate_facts hT).2.1 (congrArg Fin.val he)
  have hTi : n ∈ C.users i.val := C.mem_users.mpr ⟨t,i.val,j.val,hT,Or.inl rfl⟩
  have hU : U ∈ C.users i.val := by rw [hUi]; simp
  have hV : V ∈ C.users j.val := by rw [hVj]; simp
  have hRT : R ∈ C.users n := by rw [hR]; simp
  have hTpar : (C.tableAt n).parity = false := by
    have ht : t.parity = false := by
      unfold Table.nonlinear at hnl
      cases hp : t.parity <;> simp [hp] at hnl ⊢
    simp [tableAt,hT,ht]
  have hj2 : 2 ≤ C.refCount j.val := (h.degrees_of_nonlinear hC hnl).2
  have hVpar : (C.tableAt V).parity = false := by
    apply Bool.eq_false_iff.mpr
    intro hp
    obtain ⟨b,hb⟩ := h.case_nonlinear_parity_twoLevel hC hnl j (Or.inr rfl)
      hj2 V hVn hV (Or.inl hp)
    exact hno j (Or.inr rfl) b hb
  have hoverlap := h.tight_no_drop_forces_second_overlap i j hij ε (by omega) n U R V V₂ rfl
    (Ne.symm hUn) (Ne.symm hVn) hUV hTi hU hVj hT i.isLt j.isLt hTc hRT
    hTpar hUpar hRpar hVpar hV₂ hV₂par (hno i (Or.inl rfl) ε)
  exact ⟨U,V,R,V₂,ε,hUV,hUn,hVn,hUi,hVj,hR,hV₂,hoverlap,hε,hTc,hUnc,hRnc,
    hUpar,hRpar,hUbad,hVbad'⟩

/-- A binary gate cannot read three pairwise distinct signals. -/
theorem binary_gate_no_three_readers {n : Nat} (C : OpenCircuit n)
    (T U V R : Nat) (hTU : T ≠ U) (hTV : T ≠ V) (hUV : U ≠ V)
    (hT : R ∈ C.users T) (hU : R ∈ C.users U) (hV : R ∈ C.users V) : False := by
  obtain ⟨g,a,b,hg,ht⟩ := C.mem_users.mp hT
  obtain ⟨g',a',b',hg',hu⟩ := C.mem_users.mp hU
  obtain ⟨g'',a'',b'',hg'',hv⟩ := C.mem_users.mp hV
  rw [hg] at hg' hg''
  cases hg'
  cases hg''
  omega

/-- If `V₂ = R`, symmetry forces `U₂` to be `V` or `R`; the latter would
give `R` three distinct operands, so only `U₂ = V` remains. -/
theorem no_drop_V_second_eq_R_forces_U_second_eq_V {n : Nat}
    {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) {t : Table} {i j : Fin n} {rest : OpenCircuit (n+1)}
    (hC : C = .gate t i j rest) (hnl : t.nonlinear = true)
    (hno : ∀ x, (x = i ∨ x = j) → ∀ b,
      ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2))
    (U V R U₂ : Nat) (hUV : U ≠ V) (hUn : U ≠ n) (hVn : V ≠ n)
    (hUi : C.users i.val = {n,U}) (hVj : C.users j.val = {n,V})
    (hR : C.users n = {R}) (hVR : C.users V = {R}) (hUU₂ : C.users U = {U₂})
    (hUpar : (C.tableAt U).parity = false) (hRpar : (C.tableAt R).parity = false)
    (hU₂par : (C.tableAt U₂).parity = false) : U₂ = V := by
  have hT : C.gateAt n = some (t,i.val,j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hij : i ≠ j := fun he => (h.gate_facts hT).2.1 (congrArg Fin.val he)
  have hTj : n ∈ C.users j.val := C.mem_users.mpr ⟨t,i.val,j.val,hT,Or.inr rfl⟩
  have hU : U ∈ C.users i.val := by rw [hUi]; simp
  have hV : V ∈ C.users j.val := by rw [hVj]; simp
  have hRT : R ∈ C.users n := by rw [hR]; simp
  have hTpar : (C.tableAt n).parity = false := by
    have ht : t.parity = false := by
      unfold Table.nonlinear at hnl
      cases hp : t.parity <;> simp [hp] at hnl ⊢
    simp [tableAt,hT,ht]
  have hj2 : 2 ≤ C.refCount j.val := (h.degrees_of_nonlinear hC hnl).2
  have hVpar : (C.tableAt V).parity = false := by
    apply Bool.eq_false_iff.mpr
    intro hp
    obtain ⟨b,hb⟩ := h.case_nonlinear_parity_twoLevel hC hnl j (Or.inr rfl)
      hj2 V hVn hV (Or.inl hp)
    exact hno j (Or.inr rfl) b hb
  obtain ⟨δ,hδ,_⟩ := t.nonlinear_exists_blocksRight hnl
  have hTδ : (C.resAt (singleRes j δ) n).isConst = true := by
    rw [C.resAt_gate _ hT, C.resAt_single_input j δ j]
    simp only [ite_true]
    rw [Res.step_blocked_right t _ δ hδ]
    rfl
  have hov := h.tight_no_drop_forces_second_overlap j i (Ne.symm hij) δ hj2 n V R U U₂ rfl
    (Ne.symm hVn) (Ne.symm hUn) (Ne.symm hUV) hTj hV hUi hT i.isLt j.isLt hTδ hRT
    hTpar hVpar hRpar hUpar hUU₂ hU₂par (hno j (Or.inr rfl) δ)
  rcases hov with he | he
  · exact he
  · have hRU : R ∈ C.users U := by rw [hUU₂, he]; simp
    have hRV : R ∈ C.users V := by rw [hVR]; simp
    exact False.elim (binary_gate_no_three_readers C n U V R (Ne.symm hUn) (Ne.symm hVn)
      hUV hRT hRU hRV)

/-- No drop leaves precisely the two exceptional both-bad overlaps:
`V₂ = U`, or `V₂ = R` together with `U₂ = V`. -/
theorem no_drop_forces_final_bad_overlaps {n : Nat}
    {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (hS4 : S4Essential f) {t : Table} {i j : Fin n}
    {rest : OpenCircuit (n+1)} (hC : C = .gate t i j rest) (hnl : t.nonlinear = true)
    (hno : ∀ x, (x = i ∨ x = j) → ∀ b,
      ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2)) :
    ∃ U V R U₂ V₂ ε, U ≠ V ∧ U ≠ n ∧ V ≠ n ∧
      C.users i.val = {n,U} ∧ C.users j.val = {n,V} ∧ C.users n = {R} ∧
      C.users U = {U₂} ∧ C.users V = {V₂} ∧
      (V₂ = U ∨ (V₂ = R ∧ U₂ = V)) ∧
      t.blocksLeft ε = true ∧ (C.resAt (singleRes i ε) n).isConst = true ∧
      (C.resAt (singleRes i ε) U).isConst = false ∧
      (C.resAt (singleRes i ε) R).isConst = false ∧
      (C.tableAt U).parity = false ∧ (C.tableAt R).parity = false ∧
      BadReader C i U n ∧ BadReader C j V n := by
  obtain ⟨U,V,R,V₂,ε,hUV,hUn,hVn,hUi,hVj,hR,hV₂,hover,hε,hTc,hUnc,hRnc,
    hUpar,hRpar,hUbad,hVbad⟩ := h.no_drop_forces_bad_overlap hS4 hC hnl hno
  obtain ⟨bU,U₂,hU₂,hUc,hTnc,hU₂nc,hU₂par⟩ := hUbad
  have hUbad' : BadReader C i U n := ⟨bU,U₂,hU₂,hUc,hTnc,hU₂nc,hU₂par⟩
  have hfinal : V₂ = U ∨ (V₂ = R ∧ U₂ = V) := by
    rcases hover with he | he
    · exact Or.inl he
    · right
      refine ⟨he,?_⟩
      have hVR : C.users V = {R} := by rw [← he]; exact hV₂
      exact h.no_drop_V_second_eq_R_forces_U_second_eq_V hC hnl hno U V R U₂ hUV hUn hVn
        hUi hVj hR hVR hU₂ hUpar hRpar hU₂par
  exact ⟨U,V,R,U₂,V₂,ε,hUV,hUn,hVn,hUi,hVj,hR,hU₂,hV₂,hfinal,hε,hTc,hUnc,hRnc,
    hUpar,hRpar,hUbad',hVbad⟩

end MAContext
end SatLowerBound
