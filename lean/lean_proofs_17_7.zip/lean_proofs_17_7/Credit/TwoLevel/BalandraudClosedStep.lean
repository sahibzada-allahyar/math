import Credit.TwoLevel.BalandraudNormalizedRecurrence

namespace SatLowerBound

/-- Binomial identity used to solve the interior determinant recurrence. -/
theorem balandraud_binomial_step (n k : Nat) (hk : k ≤ n) :
    2 * ((n + 1 : Nat) : ℤ) * (Nat.choose n k : ℤ) +
      ((n + 1 : Nat) : ℤ) * (Nat.choose n (k + 1) : ℤ) =
    ((n + k + 2 : Nat) : ℤ) * (Nat.choose (n + 1) (k + 1) : ℤ) := by
  have h₁ := congrArg (fun x : Nat => (x : ℤ)) (Nat.choose_succ_right_eq n k)
  have h₂ := congrArg (fun x : Nat => (x : ℤ)) (Nat.choose_succ_succ n k)
  simp only [Nat.cast_mul, Nat.cast_add, Nat.cast_one, Nat.cast_sub hk] at h₁ h₂
  push_cast
  linear_combination -h₁ - ((n : ℤ) + (k : ℤ) + 2) * h₂

/-- Two neighboring identities in dimension n prove the interior identity
in dimension n+1. -/
theorem balandraud_identity_interior {n : Nat} (g : Fin n)
    (hleft : BalandraudDeterminantIdentity n g.val)
    (hright : BalandraudDeterminantIdentity n (g.val + 1)) :
    BalandraudDeterminantIdentity (n + 1) (g.val + 1) := by
  change balandraudDet n g.val * (2 : ℤ)^g.val * (n : ℤ) = _ at hleft
  change balandraudDet n (g.val + 1) * (2 : ℤ)^(g.val + 1) * (n : ℤ) = _ at hright
  change balandraudDet (n + 1) (g.val + 1) * (2 : ℤ)^(g.val + 1) * ((n + 1 : Nat) : ℤ) = _
  have ht : Nat.choose (n + 1) 2 = Nat.choose n 2 + n := by
    rw [Nat.choose_succ_succ]
    simp [Nat.add_comm]
  rw [ht, pow_add]
  have hrec := balandraudDet_normalized_recurrence g
  have hb := balandraud_binomial_step n g.val (Nat.le_of_lt g.isLt)
  have hn : 0 < n := Nat.zero_lt_of_lt g.isLt
  have hc : ((n + g.val : Nat) : ℤ) * ((n + g.val + 1 : Nat) : ℤ) ≠ 0 := by
    apply mul_ne_zero <;> positivity
  apply mul_left_cancel₀ hc
  simp only [pow_succ, Nat.cast_add, Nat.cast_one, Nat.cast_ofNat] at *
  linear_combination
    (2 : ℤ)^g.val * 2 * ((n : ℤ) + 1) * hrec +
    (2 : ℤ)^n * 2 * ((n : ℤ) + 1) * ((n : ℤ) + (g.val : ℤ) + 1) * hleft +
    (2 : ℤ)^n * ((n : ℤ) + 1) * ((n : ℤ) + (g.val : ℤ)) * hright +
    (2 : ℤ)^n * (2 : ℤ)^Nat.choose n 2 *
      ((n : ℤ) + (g.val : ℤ)) * ((n : ℤ) + (g.val : ℤ) + 1) * hb

/-- The complete denominator-free binomial determinant evaluation. -/
theorem balandraud_determinant_identity (n k : Nat) (hk : k ≤ n) :
    BalandraudDeterminantIdentity n k := by
  induction n generalizing k with
  | zero =>
    have : k = 0 := by omega
    subst k
    simp [BalandraudDeterminantIdentity]
  | succ n ih =>
    by_cases hz : k = 0
    · subst k
      change balandraudDet (n + 1) 0 * (2 : ℤ)^0 * ((n + 1 : Nat) : ℤ) = _
      rw [balandraudDet_zero_closed]
      simp
    by_cases hl : k = n + 1
    · subst k
      change balandraudDet (n + 1) (n + 1) * (2 : ℤ)^(n + 1) * ((n + 1 : Nat) : ℤ) = _
      rw [balandraudDet_last_closed]
      have ht : Nat.choose (n + 1) 2 = Nat.choose n 2 + n := by
        rw [Nat.choose_succ_succ]
        simp [Nat.add_comm]
      rw [ht, pow_add, pow_succ]
      simp only [Nat.choose_self, Nat.cast_one, mul_one, Nat.cast_add]
      ring
    obtain ⟨s, rfl⟩ := Nat.exists_eq_succ_of_ne_zero hz
    have hs : s < n := by omega
    exact balandraud_identity_interior ⟨s, hs⟩ (ih s (by omega)) (ih (s + 1) (by omega))

end SatLowerBound
