import Credit.TwoLevel.CollisionCounting

/-! The disjoint subcubes associated with two different cofactor rows. -/
namespace SatLowerBound

/-- Coordinates which remain free after fixing the two selected inputs. -/
def ResidualCoord {n : Nat} (ρ : Fin n → Option Bool) (i j : Fin n) :=
  {z : Fin n // ρ z = none ∧ z ≠ i ∧ z ≠ j}

noncomputable instance {n : Nat} (ρ : Fin n → Option Bool) (i j : Fin n) :
    Fintype (ResidualCoord ρ i j) := by
  classical
  unfold ResidualCoord
  infer_instance

noncomputable instance {n : Nat} (ρ : Fin n → Option Bool) (i j : Fin n) :
    DecidableEq (ResidualCoord ρ i j) := Classical.decEq _

/-- Extend a residual assignment arbitrarily on all other coordinates. -/
def residualExtend {n : Nat} (ρ : Fin n → Option Bool) (i j : Fin n)
    (x : ResidualCoord ρ i j → Bool) : Fin n → Bool :=
  fun z => if h : ρ z = none ∧ z ≠ i ∧ z ≠ j then x ⟨z,h⟩ else false

/-- One of the four disjoint subcubes of a partially restricted truth table. -/
def cofactorCube {n : Nat} (ρ : Fin n → Option Bool) (i j : Fin n)
    (p : Bool × Bool) (x : ResidualCoord ρ i j → Bool) : Fin n → Bool :=
  applyPartial ρ (setPair (residualExtend ρ i j x) i j p.1 p.2)

theorem cofactorCube_injective {n : Nat} (ρ : Fin n → Option Bool)
    (i j : Fin n) (p : Bool × Bool) : Function.Injective (cofactorCube ρ i j p) := by
  classical
  intro x y h
  funext z
  rcases z with ⟨z,hz⟩
  have hv := congrFun h z
  simpa [cofactorCube, applyPartial, setPair, residualExtend,
    hz.1, hz.2.1, hz.2.2] using hv

theorem cofactorCube_disjoint {n : Nat} (ρ : Fin n → Option Bool)
    (i j : Fin n) (hij : i ≠ j) (hi : ρ i = none) (hj : ρ j = none)
    (p q : Bool × Bool) (hpq : p ≠ q) :
    ∀ x y, cofactorCube ρ i j p x ≠ cofactorCube ρ i j q y := by
  intro x y he
  have h1 := congrFun he i
  have h2 := congrFun he j
  simp [cofactorCube, applyPartial, setPair, hi] at h1
  simp [cofactorCube, applyPartial, setPair, hj, Ne.symm hij] at h2
  apply hpq
  exact Prod.ext h1 h2

/-- A collision of two rows forces equality on their disjoint subcubes. -/
theorem rowCollision_on_subcubes {n : Nat} (ρ : Fin n → Option Bool)
    (i j : Fin n) (p q : Bool × Bool) (f : (Fin n → Bool) → Bool)
    (h : PairRow (fun a b x => f (applyPartial ρ (setPair x i j a b))) p =
      PairRow (fun a b x => f (applyPartial ρ (setPair x i j a b))) q) :
    ∀ x, f (cofactorCube ρ i j p x) = f (cofactorCube ρ i j q x) := by
  intro x
  exact congrFun h (residualExtend ρ i j x)

/-- A restricted pair leaves precisely the free coordinates other than the
selected pair. -/
theorem residualCoord_card {n : Nat} (ρ : Fin n → Option Bool)
    (i j : Fin n) (hij : i ≠ j) (hi : ρ i = none) (hj : ρ j = none) :
    Fintype.card (ResidualCoord ρ i j) + 2 = (freeCoordinates ρ).card := by
  classical
  have hi' : i ∈ freeCoordinates ρ := by simp [freeCoordinates,hi]
  have hj' : j ∈ (freeCoordinates ρ).erase i := by
    simp [freeCoordinates,hj,Ne.symm hij]
  have hs : (Finset.univ.filter (fun z : Fin n => ρ z = none ∧ z ≠ i ∧ z ≠ j)) =
      ((freeCoordinates ρ).erase i).erase j := by
    ext z
    simp [freeCoordinates, and_comm, and_left_comm, and_assoc]
  unfold ResidualCoord
  rw [Fintype.card_subtype, hs, Finset.card_erase_of_mem hj',
    Finset.card_erase_of_mem hi']
  have h1 := Finset.card_pos.mpr ⟨i,hi'⟩
  have h2 := Finset.card_pos.mpr ⟨j,hj'⟩
  rw [Finset.card_erase_of_mem hi'] at h2
  omega

/-- The exact exponential bound for a collision of two distinct cofactor
rows in a restriction with the given free-coordinate count. -/
theorem cofactor_collision_card_le {n : Nat} (ρ : Fin n → Option Bool)
    (i j : Fin n) (hij : i ≠ j) (hi : ρ i = none) (hj : ρ j = none)
    (p q : Bool × Bool) (hpq : p ≠ q) :
    coincidentCard (cofactorCube ρ i j p) (cofactorCube ρ i j q) ≤
      2 ^ (2 ^ n - 2 ^ ((freeCoordinates ρ).card - 2)) := by
  classical
  have h := coincidentFunctions_card_le_pow (cofactorCube ρ i j p)
    (cofactorCube ρ i j q) (cofactorCube_injective ρ i j p)
    (cofactorCube_disjoint ρ i j hij hi hj p q hpq)
  have hc := residualCoord_card ρ i j hij hi hj
  simp only [Fintype.card_fun, Fintype.card_bool, Fintype.card_fin] at h
  have hc' : Fintype.card (ResidualCoord ρ i j) = (freeCoordinates ρ).card - 2 := by omega
  simpa [hc'] using h


end SatLowerBound
