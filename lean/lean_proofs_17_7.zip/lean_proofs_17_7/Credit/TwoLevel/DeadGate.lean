import Credit.TwoLevel.TightDistinctB
import Credit.PsiReduce

/-! Dead retained gates produced by the restriction trace. They are not
counted as trace eliminations and must be removed by normalization. -/
namespace SatLowerBound
namespace OpenCircuit

/-- A gate signal has no retained references when all its original readers
resolve to constants and it is not the original output. -/
theorem gate_keptRefs_eq_zero_of_users_const {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (z : Nat) (hzn : n ≤ z)
    (hu : ∀ k ∈ C.users z, (C.resAt (fixRes P c) k).isConst = true)
    (hout : ∀ k neg, C.outWire = some (k,neg) → k ≠ z) :
    C.keptRefs (fixRes P c) z = 0 := by
  let ρ := fixRes P c
  have hinit : ∀ w : Fin n, (ρ w).hits z = false := by
    intro w
    apply Bool.eq_false_iff.mpr
    intro hh
    have he := fixRes_hits P c z w hh
    have hw := w.isLt
    omega
  have hpass := C.gate_passers_subset ρ z hinit ∅ (n + C.size) (by
    intro k g a b _ hk _ _ hab
    have hmem : k ∈ C.users z := by
      apply C.mem_users.mpr
      refine ⟨g,a,b,hk,?_⟩
      rcases hab with he | he | he | he
      · exact Or.inl he
      · simp at he
      · exact Or.inr he
      · simp at he
    have hc := hu k hmem
    cases hr : C.resAt ρ k with
    | const v => rfl
    | lit t neg =>
      rw [hr] at hc
      exact absurd hc Bool.false_ne_true)
  have honly : ∀ k, (C.resAt ρ k).hits z = true → k = z := by
    intro k hk
    rcases FlatKeptAux.hits_cases C ρ hk with ⟨hkn,hρk⟩ | ⟨g,a,b,hgate,_⟩
    · have hf := hinit ⟨k,hkn⟩
      rw [hf] at hρk
      contradiction
    · have hb := C.gateAt_bounds hgate
      rcases hpass k hb.1 hb.2.1 hk with he | he
      · exact he
      · simp at he
  have hsum : ∑ k ∈ Finset.range (n + C.size), C.keptSlotHits ρ k z = 0 := by
    apply Finset.sum_eq_zero
    intro k _
    cases hk : C.gateAt k with
    | none => exact FlatKeptAux.keptSlotHits_none C ρ z hk
    | some p =>
      obtain ⟨g, a, b⟩ := p
      rw [FlatKeptAux.keptSlotHits_eq C ρ z hk]
      by_cases hkept : C.isKept ρ k = true
      · rw [ite_eq_left hkept]
        have hnc : (C.resAt ρ k).isConst = false := by
          rw [C.resAt_kept ρ hkept]
          rfl
        have hfa : ∀ o, (o = a ∨ o = b) → (C.resAt ρ o).hits z = false := by
          intro o ho
          cases hh : (C.resAt ρ o).hits z with
          | false => rfl
          | true =>
            exfalso
            have hoz := honly o hh
            have hmem : k ∈ C.users z := by
              apply FlatKeptAux.mem_users_of C hk
              rcases ho with ho | ho
              · left
                rw [← ho]
                exact hoz
              · right
                rw [← ho]
                exact hoz
            rw [hu k hmem] at hnc
            cases hnc
        exact FlatKeptAux.indicator_add_eq_zero (hfa a (Or.inl rfl)) (hfa b (Or.inr rfl))
      · rw [ite_eq_right hkept]
  have hout0 : C.outHits ρ z = 0 := by
    unfold outHits
    cases ho : C.outWire with
    | none => rfl
    | some p =>
      obtain ⟨k, neg⟩ := p
      have hf : (C.resAt ρ k).hits z = false := by
        cases hh : (C.resAt ρ k).hits z with
        | false => rfl
        | true => exact absurd (honly k hh) (hout k neg ho)
      simp only [hf, FlatKeptAux.indicator_false]
  have := C.keptRefs_eq_sum ρ z
  change C.keptRefs ρ z = 0
  omega


/-- If the original gate survives, its reindexed gate in the restricted
circuit has zero references and is therefore dead. -/
theorem fix_kept_gate_dead_of_users_const {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (z : Nat) (g : Table) (a d : Nat)
    (hgate : C.gateAt z = some (g,a,d)) (hkept : C.isKept (fixRes P c) z = true)
    (hu : ∀ k ∈ C.users z, (C.resAt (fixRes P c) k).isConst = true)
    (hout : ∀ k neg, C.outWire = some (k,neg) → k ≠ z) :
    ∃ k g' a' d', (C.restrict (fixSubst P c)).gateAt k = some (g',a',d') ∧
      (C.restrict (fixSubst P c)).refCount k = 0 := by
  obtain ⟨k,g',a',d',hk,href,_,_⟩ :=
    C.restrict_kept_readers (fixSubst P c) (fixRes P c) Fin.val
      Fin.val_injective (fun w => w.isLt) (fixSubst_rel P c) z g a d hgate hkept
  refine ⟨k,g',a',d',hk,?_⟩
  rw [href, C.gate_keptRefs_eq_zero_of_users_const P c z (C.gateAt_bounds hgate).1 hu hout]

/-- In the paper's `V₂ = U` configuration, if `V` survives while its
unique successor `U` becomes constant, its reindexed gate is dead. -/
theorem single_kept_gate_dead_of_unique_constant_successor {n : Nat} (C : OpenCircuit n)
    (hr : C.Reduced) (x : Fin n) (b : Bool) (V U : Nat) (g : Table) (a d : Nat)
    (hgate : C.gateAt V = some (g,a,d)) (hkept : C.isKept (singleRes x b) V = true)
    (husers : C.users V = {U}) (hUc : (C.resAt (singleRes x b) U).isConst = true) :
    ∃ k g' a' d', (C.restrict (singleSubst x b)).gateAt k = some (g',a',d') ∧
      (C.restrict (singleSubst x b)).refCount k = 0 := by
  have hU : U ∈ C.users V := by rw [husers]; simp
  have hout0 := C.reduced_outIs_zero_of_user hr V (Finset.ne_empty_of_mem hU)
  have hout : ∀ k neg, C.outWire = some (k,neg) → k ≠ V := by
    intro k neg hk he
    simp [outIs, hk, he] at hout0
  have hu : ∀ k ∈ C.users V,
      (C.resAt (fixRes (fun z => decide (z = x)) (fun _ => b)) k).isConst = true := by
    intro k hk
    rw [husers, Finset.mem_singleton] at hk
    simpa [hk, singleRes] using hUc
  have hdead := C.fix_kept_gate_dead_of_users_const (fun z => decide (z = x)) (fun _ => b)
    V g a d hgate hkept hu hout
  simpa [← singleSubst_eq_fixSubst] using hdead

/-- A circuit with a dead gate has a smaller equivalent circuit whose
one-level potential does not increase. This does not assert the corresponding
two-level potential inequality. -/
theorem smaller_equivalent_of_dead_gate {n : Nat} (C : OpenCircuit n)
    (k : Nat) (g : Table) (a d : Nat) (hg : C.gateAt k = some (g,a,d))
    (hdead : C.refCount k = 0) :
    ∃ D : OpenCircuit n, D.size < C.size ∧ D.psi ≤ C.psi ∧ ∀ x, D.eval x = C.eval x := by
  have hn : ¬ C.Reduced := by
    intro hr
    have hpos := (C.reduced_gate hr hg).2.2
    omega
  exact C.psi_smaller_of_not_reduced hn

/-- The dead surviving gate forces an equivalent smaller circuit after the
restriction, with the established one-level potential guarantee. -/
theorem single_unique_constant_successor_smaller {n : Nat} (C : OpenCircuit n)
    (hr : C.Reduced) (x : Fin n) (b : Bool) (V U : Nat) (g : Table) (a d : Nat)
    (hgate : C.gateAt V = some (g,a,d)) (hkept : C.isKept (singleRes x b) V = true)
    (husers : C.users V = {U}) (hUc : (C.resAt (singleRes x b) U).isConst = true) :
    ∃ D : OpenCircuit n, D.size < (C.restrict (singleSubst x b)).size ∧
      D.psi ≤ (C.restrict (singleSubst x b)).psi ∧
      ∀ v, D.eval v = (C.restrict (singleSubst x b)).eval v := by
  obtain ⟨k,g',a',d',hk,hdead⟩ :=
    C.single_kept_gate_dead_of_unique_constant_successor hr x b V U g a d hgate hkept husers hUc
  exact (C.restrict (singleSubst x b)).smaller_equivalent_of_dead_gate k g' a' d' hk hdead

/-- An essential input with a dead reader must have at least two
references. Otherwise every path from that input stops at the dead gate. -/
theorem essential_input_with_dead_reader_has_two_refs {n : Nat} (C : OpenCircuit n)
    (z q : Fin n) (hq : q ≠ z) (V : Nat) (hVz : V ∈ C.users z.val)
    (hdead : C.refCount V = 0) (hess : Essential C.eval z) : 2 ≤ C.refCount z.val := by
  by_contra hlt
  have hzbound := C.refCount_ge z.val
  have hvbound := C.refCount_ge V
  have hpos : 0 < (C.users z.val).card := Finset.card_pos.mpr ⟨V,hVz⟩
  have hcard : (C.users z.val).card = 1 := by omega
  have hzero : C.outIs z.val = 0 := by omega
  have hVzero : C.outIs V = 0 := by omega
  have hVempty : C.users V = ∅ := Finset.card_eq_zero.mp (by omega)
  obtain ⟨w,hw⟩ := Finset.card_eq_one.mp hcard
  have hVw : V = w := by simpa [hw] using hVz
  have husers : ∀ k ∈ C.users z.val, k = V := by
    intro k hk
    rw [hw, Finset.mem_singleton] at hk
    exact hk.trans hVw.symm
  have hout : ∀ k b, C.outWire = some (k,b) → k ≠ z.val ∧ k ≠ V := by
    intro k b hk
    constructor <;> intro he
    · simp [outIs,hk,he] at hzero
    · simp [outIs,hk,he] at hVzero
  obtain ⟨u,w,huw,hne⟩ := hess
  have hqval : C.valueAt u q.val = C.valueAt w q.val := by
    rw [C.valueAt_input, C.valueAt_input, huw q hq]
  have heval := C.eval_eq_of_chain_cut z V q.val u w huw husers (by
    intro k hk
    rw [hVempty] at hk
    simp at hk) hqval hout
  exact hne heval

/-- The surviving dead gate still reads an unfixed input that it originally
read. This preserves the specific reindexed gate witness, not only its
existence. -/
theorem single_dead_gate_retains_input_reader {n : Nat} (C : OpenCircuit n)
    (hr : C.Reduced) (x y : Fin n) (hxy : x ≠ y) (b : Bool) (V U : Nat)
    (g : Table) (a d : Nat) (hgate : C.gateAt V = some (g,a,d))
    (hVy : V ∈ C.users y.val) (hkept : C.isKept (singleRes x b) V = true)
    (husers : C.users V = {U}) (hUc : (C.resAt (singleRes x b) U).isConst = true) :
    ∃ k g' a' d', (C.restrict (singleSubst x b)).gateAt k = some (g',a',d') ∧
      (C.restrict (singleSubst x b)).refCount k = 0 ∧
      k ∈ (C.restrict (singleSubst x b)).users y.val := by
  let P : Fin n → Bool := fun z => decide (z = x)
  let c : Fin n → Bool := fun _ => b
  have hkeep' : C.isKept (fixRes P c) V = true := hkept
  obtain ⟨k,g',a',d',hk,href,_,hread⟩ :=
    C.restrict_kept_readers (fixSubst P c) (fixRes P c) Fin.val
      Fin.val_injective (fun w => w.isLt) (fixSubst_rel P c) V g a d hgate hkeep'
  have hU : U ∈ C.users V := by rw [husers]; simp
  have hout0 := C.reduced_outIs_zero_of_user hr V (Finset.ne_empty_of_mem hU)
  have hout : ∀ k neg, C.outWire = some (k,neg) → k ≠ V := by
    intro k neg hk' he
    simp [outIs,hk',he] at hout0
  have hu : ∀ k ∈ C.users V, (C.resAt (fixRes P c) k).isConst = true := by
    intro k hk'
    rw [husers,Finset.mem_singleton] at hk'
    simpa [hk',P,c,singleRes] using hUc
  have hzero := C.gate_keptRefs_eq_zero_of_users_const P c V (C.gateAt_bounds hgate).1 hu hout
  obtain ⟨g₁,a₁,d₁,hg₁,hab⟩ := C.mem_users.mp hVy
  rw [hgate] at hg₁
  cases hg₁
  have hyres : C.resAt (fixRes P c) y.val = .lit y.val false := by
    change C.resAt (singleRes x b) y.val = .lit y.val false
    rw [C.resAt_single_input x b y]
    simp [Ne.symm hxy]
  have hyhit : (C.resAt (fixRes P c) y.val).hits y.val = true := by
    rw [hyres]
    exact (Res.hits_lit _ _ _).mpr rfl
  have horig : (C.resAt (fixRes P c) a).hits y.val = true ∨
      (C.resAt (fixRes P c) d).hits y.val = true := by
    rcases hab with he | he
    · left; rw [he]; exact hyhit
    · right; rw [he]; exact hyhit
  have hnew : k ∈ (C.restrict (fixSubst P c)).users y.val :=
    (C.restrict (fixSubst P c)).mem_users.mpr ⟨g',a',d',hk,(hread y).mpr horig⟩
  have hkdead : (C.restrict (fixSubst P c)).refCount k = 0 := by rw [href,hzero]
  refine ⟨k,g',a',d',?_,?_,?_⟩
  · simpa [P,c,← singleSubst_eq_fixSubst] using hk
  · simpa [P,c,← singleSubst_eq_fixSubst] using hkdead
  · simpa [P,c,← singleSubst_eq_fixSubst] using hnew

end OpenCircuit
end SatLowerBound
