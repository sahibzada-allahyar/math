import Credit.TwoLevel.RobustMeasure
import Credit.TwoLevel.MainBNormalized
import Credit.TwoLevel.Terminal
import SatLowerBound.ResidualDegree

/-! The paper's robust-block composition induction. -/
namespace SatLowerBound
open OpenCircuit

/-- Fourteen units per non-retired input, for the entire read-once
composition and allowing unrestricted sharing in the circuit. -/
theorem robust_tree_psi2_surplus {n k : Nat} (hk : 2 ≤ k)
    (T : RobustTree n) (ρ : Fin n → Option Bool) (hT : T.Valid k ρ)
    (C : OpenCircuit n) (hr : C.Reduced) (ht : C.NoInputTriangles (fun _ => none))
    (hc : ∀ v, C.eval v = T.eval (applyPartial ρ v))
    (hsupport : ∀ z, 0 < C.usage (singleUse z) → z ∈ freeOn T.support ρ) :
    14 * (T.surplus k ρ : Int) ≤ C.psi2 := by
  suffices main : ∀ m, ∀ (T : RobustTree n) (ρ : Fin n → Option Bool), T.surplus k ρ = m →
      T.Valid k ρ → ∀ C : OpenCircuit n, C.Reduced → C.NoInputTriangles (fun _ => none) →
      (∀ v, C.eval v = T.eval (applyPartial ρ v)) →
      (∀ z, 0 < C.usage (singleUse z) → z ∈ freeOn T.support ρ) →
      14 * (T.surplus k ρ : Int) ≤ C.psi2 from
    main (T.surplus k ρ) T ρ rfl hT C hr ht hc hsupport
  intro m
  induction m using Nat.strong_induction_on with
  | h m ih =>
    intro T ρ hm hT C hr ht hc hsupport
    by_cases hm0 : m = 0
    · have hnonneg := C.psi2_nonnegative
      omega
    · let F : (Fin n → Bool) → Bool := fun v => T.eval (applyPartial ρ v)
      have hdep := T.restricted_dependence ρ hk hT
      have hcard : 2 ≤ (freeOn T.support ρ).card := by
        have hh := T.valid_free_card_ge ρ hT
        omega
      have hgood : GoodFn F := hdep.goodFn hcard
      have hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential F z := by
        intro z hz
        exact hdep.essential z (hsupport z hz)
      have hctx : MAContext F C := ⟨hgood,hr,ht,hc,hused⟩
      obtain ⟨x,b,D,hx,he,hD,htri,hDe,hdrop,hDs⟩ := hctx.main_lemma_B_normalized_support hdep.s4
      have hxF : x ∈ freeOn T.support ρ := hdep.supported.essential_mem x he
      have hxT : x ∈ T.support := (Finset.mem_filter.mp hxF).1
      have hxρ : ρ x = none := (Finset.mem_filter.mp hxF).2
      obtain ⟨K,f,S,hplug,hxS⟩ := T.locate x hxT
      subst T
      have ⟨hLeaf,hFit⟩ := K.fits_of_plug ρ (.leaf f S) hT
      have hrob : RobustOn k f S := hLeaf.1
      have hsize : k+2 ≤ (freeOn S ρ).card := hLeaf.2
      have hxFree : x ∈ freeOn S ρ := Finset.mem_filter.mpr ⟨hxS,hxρ⟩
      let τ := partialFix ρ x b
      have hcard' : (freeOn S τ).card + 1 = (freeOn S ρ).card := by
        change (freeOn S (partialFix ρ x b)).card + 1 = _
        rw [freeOn_partialFix]
        exact Finset.card_erase_add_one hxFree
      have hFit' := K.fits_partialFix ρ S hFit x hxS b
      have hstep := K.plug_surplus_partialFix ρ S f hFit x hxFree b hsize
      change (K.plug (.leaf f S)).surplus k τ + 1 = _ at hstep
      have hDcomp : ∀ v, D.eval v = (K.plug (.leaf f S)).eval (applyPartial τ v) := by
        intro v
        rw [hDe]
        change (K.plug (.leaf f S)).eval (applyPartial ρ (fixBit x b v)) = _
        rw [applyPartial_fixBit]
      have hDsupport : ∀ z, 0 < D.usage (singleUse z) → z ∈ freeOn (K.plug (.leaf f S)).support τ := by
        intro z hz
        obtain ⟨hzC,hzx⟩ := hDs z hz
        have hmemb := hsupport z hzC
        change z ∈ freeOn (K.plug (.leaf f S)).support (partialFix ρ x b)
        rw [freeOn_partialFix]
        exact Finset.mem_erase.mpr ⟨hzx,hmemb⟩
      by_cases hlarge : k+3 ≤ (freeOn S ρ).card
      · have hT' : (K.plug (.leaf f S)).Valid k τ :=
          K.plug_valid τ S hFit' (.leaf f S) ⟨hrob,by omega⟩ rfl
        have hb := ih ((K.plug (.leaf f S)).surplus k τ) (by omega)
          (K.plug (.leaf f S)) τ rfl hT' D hD htri hDcomp hDsupport
        omega
      · have hsmall : (freeOn S τ).card = k+1 := by omega
        cases hret : K.retire with
        | none =>
          have heK := K.retire_none.mp hret
          subst K
          have hnonneg := D.psi2_nonnegative
          simp only [RobustContext.plug,RobustTree.surplus] at hm hstep ⊢
          omega
        | some R =>
          obtain ⟨E,hE,hEtri,hEcomp,hEpsi,hEsupport⟩ :=
            K.retire_leaf_normalized τ S f R hk hFit' hret hrob (by omega) D hD hDcomp hDsupport
          have hR : R.Valid k τ := K.retire_valid τ S hFit' R hret
          have hRs := K.retire_surplus (k := k) τ R hret
          have hKstep := K.plug_surplus (k := k) τ (.leaf f S)
          have hsmall0 : (freeOn S τ).card - (k+1) = 0 := by omega
          have hsEq : (K.plug (.leaf f S)).surplus k τ = R.surplus k τ := by
            rw [hKstep]
            simp only [RobustTree.surplus,hsmall0,Nat.zero_add,hRs]
          have hb := ih (R.surplus k τ) (by omega) R τ rfl hR E hE hEtri hEcomp hEsupport
          omega

/-- The potential inequality in Theorem 8.1, with the paper's `L` and `B`
represented by free-coordinate count and leaf count. -/
theorem robust_tree_psi2_bound {n k : Nat} (hk : 2 ≤ k)
    (T : RobustTree n) (ρ : Fin n → Option Bool) (hT : T.Valid k ρ)
    (C : OpenCircuit n) (hr : C.Reduced) (ht : C.NoInputTriangles (fun _ => none))
    (hc : ∀ v, C.eval v = T.eval (applyPartial ρ v))
    (hsupport : ∀ z, 0 < C.usage (singleUse z) → z ∈ freeOn T.support ρ) :
    14 * (((freeOn T.support ρ).card : Int) - ((k : Int)+1) * T.blocks) ≤ C.psi2 := by
  have hpot := robust_tree_psi2_surplus hk T ρ hT C hr ht hc hsupport
  have hs := T.surplus_add_retired ρ hT
  have hcast : (T.surplus k ρ : Int) + ((k : Int)+1) * T.blocks = (freeOn T.support ρ).card := by
    exact_mod_cast hs
  omega

/-- Full-degree, full-support composition size inequality from Theorem 8.1.
The full-degree premise is stated directly and is not assumed by the
potential induction. -/
theorem robust_tree_full_degree_size {n k : Nat} (hk : 2 ≤ k) (T : RobustTree n)
    (hT : T.Valid k (fun _ => none)) (hs : T.support = Finset.univ)
    (hfull : (BPoly.ofFunction n T.eval).topCoefficient = true)
    (C : OpenCircuit n) (hc : ∀ v, C.eval v = T.eval v) :
    17 * (n : Int) - 14 * ((k : Int)+1) * T.blocks - 3 ≤ 7 * (C.size : Int) := by
  obtain ⟨D,hD,htri,hsize,_,heval⟩ := C.normalize_by_descent
  have hDcomp : ∀ v, D.eval v = T.eval (applyPartial (fun _ => none) v) := by
    intro v
    rw [heval,hc]
    congr 1
  have hsupport : ∀ z, 0 < D.usage (singleUse z) → z ∈ freeOn T.support (fun _ => none) := by
    intro z _
    simp [freeOn,hs]
  have hpot := robust_tree_psi2_bound hk T (fun _ => none) hT D hD htri hDcomp hsupport
  have hcard : (freeOn T.support (fun _ => none)).card = n := by simp [freeOn,hs]
  rw [hcard] at hpot
  have hdegree := D.nonlinear_lower_bound T.eval (fun v => (heval v).trans (hc v)) hfull
  have hsizebound := D.size_bound_of_potential (D.reduced_essential hD) n T.blocks k hpot (by omega)
  omega

end SatLowerBound
