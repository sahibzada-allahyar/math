import Credit.TwoLevel.TriangleStructure

/-! Credit-chain accounting for distinct-operand circuits that may contain
    degenerate gates and gates not on a path to the output. -/
namespace SatLowerBound
namespace OpenCircuit

theorem isD_outIs_zero_of_reader {n : Nat} (C : OpenCircuit n) (s W : Nat)
    (hd : C.isD s = true) (hw : W ∈ C.users s) : C.outIs s = 0 := by
  have href := ((C.isD_iff s).mp hd).1
  have hge := C.refCount_ge s
  have hp := Finset.card_pos.mpr ⟨W,hw⟩
  omega

theorem keptIsD_of_kept_gate_distinct {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool)
    (hDistinct : C.DistinctOperands) (s : Nat) (hs : n ≤ s) (hD : C.isD s = true)
    (hsKept : C.isKept (fixRes P c) s = true)
    (husers : ∀ k ∈ C.users s, C.isKept (fixRes P c) k = true) :
    C.keptIsD (fixRes P c) s = true := by
  obtain ⟨href, W, g, a, b, hgW, hab, hnl⟩ := (C.isD_iff s).mp hD
  have hWmem : W ∈ C.users s := C.mem_users.mpr ⟨g, a, b, hgW, hab⟩
  have hge := C.refCount_ge s
  have hcard : (C.users s).card = 1 := by
    have hp := Finset.card_pos.mpr ⟨W, hWmem⟩
    omega
  have hout0 : C.outIs s = 0 := by omega
  have huniq : C.users s = {W} := by
    obtain ⟨w, hw⟩ := Finset.card_eq_one.mp hcard
    have he : W = w := by simpa [hw] using hWmem
    simpa [he] using hw
  have hpass := C.gate_passers_of_kept_users P c s hs husers
  have hother : ∀ o, o < n + C.size → o ≠ s →
      (C.resAt (fixRes P c) o).hits s = false := by
    intro o ho hne
    apply Bool.eq_false_iff.mpr
    intro hh
    by_cases hon : o < n
    · have hres : C.resAt (fixRes P c) o = fixRes P c ⟨o, hon⟩ :=
        C.resAt_input (fixRes P c) ⟨o, hon⟩
      rw [hres] at hh
      have he := fixRes_hits P c s ⟨o, hon⟩ hh
      omega
    · exact hne (hpass o (by omega) ho hh)
  have hsres : (C.resAt (fixRes P c) s).hits s = true := by
    rw [C.resAt_kept _ hsKept]
    exact (Res.hits_lit _ _ _).mpr rfl
  have hbW := C.gateAt_bounds hgW
  have hdis : a ≠ b := hDistinct W g a b hgW
  apply C.keptIsD_of_unique_slot (fixRes P c) s W g a b hgW (husers W hWmem) hnl
  · rcases hab with ha | hb
    · have hbne : b ≠ s := by omega
      rw [ha, hsres, hother b (by omega) hbne]
      rfl
    · have hane : a ≠ s := by omega
      rw [hb, hsres, hother a (by omega) hane]
      rfl
  · intro k g' a' b' hkW hk _
    have hane : a' ≠ s := by
      intro he
      have hmem : k ∈ C.users s := C.mem_users.mpr ⟨g', a', b', hk, Or.inl he⟩
      rw [huniq, Finset.mem_singleton] at hmem
      exact hkW hmem
    have hbne : b' ≠ s := by
      intro he
      have hmem : k ∈ C.users s := C.mem_users.mpr ⟨g', a', b', hk, Or.inr he⟩
      rw [huniq, Finset.mem_singleton] at hmem
      exact hkW hmem
    have hbound := C.gateAt_bounds hk
    exact ⟨hother a' (by omega) hane, hother b' (by omega) hbne⟩
  · intro k neg hk
    have hkne : k ≠ s := by
      intro he
      simp [outIs, hk, he] at hout0
    exact hother k (C.outWire_bound hk) hkne

theorem retained_two_credit_links_distinct {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool)
    (hDistinct : C.DistinctOperands) (z : Fin n) (hz : P z = false) (W V : Nat)
    (hstar : C.isDStar z.val = true) (hW : W ∈ C.users z.val)
    (hV : V ∈ C.users W)
    (hWkept : C.isKept (fixRes P c) W = true)
    (hVkept : C.isKept (fixRes P c) V = true) :
    C.keptIsD (fixRes P c) z.val = true ∧ C.keptIsD (fixRes P c) W = true := by
  have hDz := C.isD_of_isDStar z.val hstar
  have huz := C.users_singleton_of_isD z.val W hDz hW
  have hDW : C.isD W = true := by
    obtain ⟨_, w, hw, hd⟩ := (C.isDStar_iff z.val).mp hstar
    rw [huz, Finset.mem_singleton] at hw
    simpa [hw] using hd
  have huW := C.users_singleton_of_isD W V hDW hV
  have hWbound : n ≤ W := by
    obtain ⟨g,a,b,hgate,-⟩ := C.mem_users.mp hW
    exact (C.gateAt_bounds hgate).1
  constructor
  · apply C.keptIsD_of_isD P c z hz hDz
    intro k hk
    rw [huz, Finset.mem_singleton] at hk
    simpa [hk] using hWkept
  · apply C.keptIsD_of_kept_gate_distinct P c hDistinct W hWbound hDW hWkept
    intro k hk
    rw [huW, Finset.mem_singleton] at hk
    simpa [hk] using hVkept

theorem retained_DStar_survives_distinct {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool)
    (hDistinct : C.DistinctOperands) (z : Fin n) (hz : P z = false) (W V : Nat)
    (hstar : C.isDStar z.val = true) (hW : W ∈ C.users z.val)
    (hV : V ∈ C.users W)
    (hWkept : C.isKept (fixRes P c) W = true)
    (hVkept : C.isKept (fixRes P c) V = true) :
    (C.restrict (fixSubst P c)).isDStar z.val = true := by
  obtain ⟨hzD, hWD⟩ := C.retained_two_credit_links_distinct P c hDistinct z hz W V hstar hW hV hWkept hVkept
  obtain ⟨g,a,b,hgate,hab⟩ := C.mem_users.mp hW
  obtain ⟨k,g',a',b',hgate',href,hfirst,hread⟩ :=
    C.restrict_kept_readers (fixSubst P c) (fixRes P c) Fin.val
      Fin.val_injective (fun w => w.isLt) (fixSubst_rel P c) W g a b hgate hWkept
  have hnewD : (C.restrict (fixSubst P c)).isD k = true := by
    simp only [isD, href, hfirst]
    exact hWD
  have hzres : (C.resAt (fixRes P c) z.val).hits z.val = true := by
    rw [C.resAt_input]
    simp [fixRes, hz, Res.hits]
  have hreadz : a' = z.val ∨ b' = z.val := by
    apply (hread z).mpr
    rcases hab with ha | hb
    · exact Or.inl (by simpa [ha] using hzres)
    · exact Or.inr (by simpa [hb] using hzres)
  have hnewW : k ∈ (C.restrict (fixSubst P c)).users z.val :=
    (C.restrict (fixSubst P c)).mem_users.mpr ⟨g',a',b',hgate',hreadz⟩
  apply ((C.restrict (fixSubst P c)).isDStar_iff z.val).mpr
  refine ⟨?_, k, hnewW, hnewD⟩
  rw [(C.fix_transfer P c).2.2.2 z]
  exact hzD

theorem lost_DStar_with_first_gate_kept_distinct {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (z : Fin n) (hz : P z = false)
    (W V : Nat) (hstar : C.isDStar z.val = true) (hW : W ∈ C.users z.val)
    (hV : V ∈ C.users W) (hWkept : C.isKept (fixRes P c) W = true)
    (hlost : (C.restrict (fixSubst P c)).isDStar z.val = false) :
    C.isAliased (fixRes P c) V = true ∧
      C.credit2 z - (C.restrict (fixSubst P c)).credit2 z = 1 := by
  have hDz := C.isD_of_isDStar z.val hstar
  have huz := C.users_singleton_of_isD z.val W hDz hW
  have hnewD : (C.restrict (fixSubst P c)).isD z.val = true := by
    rw [(C.fix_transfer P c).2.2.2 z]
    apply C.keptIsD_of_isD P c z hz hDz
    intro k hk
    rw [huz, Finset.mem_singleton] at hk
    simpa [hk] using hWkept
  have hVk : C.isKept (fixRes P c) V = false := by
    apply Bool.eq_false_iff.mpr
    intro hkept
    have hsurvive := C.retained_DStar_survives_distinct P c hDistinct z hz W V hstar hW hV hWkept hkept
    rw [hlost] at hsurvive
    contradiction
  have hValias : C.isAliased (fixRes P c) V = true := by
    obtain ⟨g,a,b,hgate,_⟩ := C.mem_users.mp hV
    have h := C.isKept_eq_not_isAliased (fixRes P c) hgate
    rw [hVk] at h
    cases hv : C.isAliased (fixRes P c) V with
    | false => rw [hv] at h; contradiction
    | true => rfl
  refine ⟨hValias, ?_⟩
  simp [credit2, hDz, hstar, hnewD, hlost, indicator]

theorem eliminated_unique_reader_must_pass_distinct {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (_hDistinct : C.DistinctOperands) (z : Fin n) (W : Nat)
    (hD : C.isD z.val = true) (hW : W ∈ C.users z.val)
    (hWal : C.isAliased (fixRes P c) W = true)
    (hess : Essential (C.restrict (fixSubst P c)).eval z) :
    (C.resAt (fixRes P c) W).hits z.val = true := by
  have hu := C.users_singleton_of_isD z.val W hD hW
  have hout0 := C.isD_outIs_zero_of_reader z.val W hD hW
  have hout : ∀ k neg, C.outWire = some (k,neg) → k ≠ z.val := by
    intro k neg hk he
    simp [outIs, hk, he] at hout0
  by_contra hn
  have hnot : (C.resAt (fixRes P c) W).hits z.val = false := Bool.eq_false_iff.mpr hn
  have hzero := C.keptRefs_zero_of_eliminated_nonpassing_readers P c z (by
    intro k hk
    rw [hu, Finset.mem_singleton] at hk
    simpa [hk] using hnot) (by
    intro k hk
    rw [hu, Finset.mem_singleton] at hk
    simpa [hk] using hWal) hout
  exact C.not_essential_of_keptRefs_zero P c z hzero hess

theorem first_credit_survives_eliminated_first_gate_distinct {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (z : Fin n) (hz : P z = false)
    (W V : Nat) (hstar : C.isDStar z.val = true) (hW : W ∈ C.users z.val)
    (hV : V ∈ C.users W) (hWal : C.isAliased (fixRes P c) W = true)
    (hVkept : C.isKept (fixRes P c) V = true)
    (hess : Essential (C.restrict (fixSubst P c)).eval z) :
    (C.restrict (fixSubst P c)).isD z.val = true := by
  have hDz := C.isD_of_isDStar z.val hstar
  have huz := C.users_singleton_of_isD z.val W hDz hW
  have hDW : C.isD W = true := by
    obtain ⟨_, w, hw, hd⟩ := (C.isDStar_iff z.val).mp hstar
    rw [huz, Finset.mem_singleton] at hw
    simpa [hw] using hd
  have huW := C.users_singleton_of_isD W V hDW hV
  have hWhit := C.eliminated_unique_reader_must_pass_distinct P c hDistinct z W hDz hW hWal hess
  have hzHit : (C.resAt (fixRes P c) z.val).hits z.val = true := by
    rw [C.resAt_input]
    simp [fixRes, hz, Res.hits]
  have honly : ∀ o, o < n + C.size → o ≠ z.val → o ≠ W →
      (C.resAt (fixRes P c) o).hits z.val = false := by
    intro o ho hno hnW
    apply Bool.eq_false_iff.mpr
    intro hh
    by_cases hon : o < n
    · have hres : C.resAt (fixRes P c) o = fixRes P c ⟨o,hon⟩ :=
        C.resAt_input (fixRes P c) ⟨o,hon⟩
      rw [hres] at hh
      exact hno (fixRes_hits P c z.val ⟨o,hon⟩ hh)
    · exact hnW (C.two_link_passers_only_first P c z W V hstar hW hV hVkept o (by omega) ho hh)
  obtain ⟨g,a,b,hgate,hab⟩ := C.mem_users.mp hV
  have hbound := C.gateAt_bounds hgate
  have hVgt : W < V := by rcases hab with ha | hb <;> omega
  have hVneW : V ≠ W := by omega
  have hVnotz : a ≠ z.val ∧ b ≠ z.val := by
    constructor <;> intro he
    · have hm : V ∈ C.users z.val := C.mem_users.mpr ⟨g,a,b,hgate,Or.inl he⟩
      rw [huz, Finset.mem_singleton] at hm
      exact hVneW hm
    · have hm : V ∈ C.users z.val := C.mem_users.mpr ⟨g,a,b,hgate,Or.inr he⟩
      rw [huz, Finset.mem_singleton] at hm
      exact hVneW hm
  have hdis := hDistinct V g a b hgate
  have hnl : g.nonlinear = true := by
    obtain ⟨_, v, g', a', b', hv, hab', hn⟩ := (C.isD_iff W).mp hDW
    have hm : v ∈ C.users W := C.mem_users.mpr ⟨g',a',b',hv,hab'⟩
    rw [huW, Finset.mem_singleton] at hm
    rw [hm, hgate] at hv
    cases hv
    exact hn
  have houtz := C.isD_outIs_zero_of_reader z.val W hDz hW
  have houtW := C.isD_outIs_zero_of_reader W V hDW hV
  rw [(C.fix_transfer P c).2.2.2 z]
  apply C.keptIsD_of_unique_slot (fixRes P c) z.val V g a b hgate hVkept hnl
  · rcases hab with ha | hb
    · have hbne : b ≠ W := by omega
      rw [ha, hWhit, honly b (by omega) hVnotz.2 hbne]
      rfl
    · have hane : a ≠ W := by omega
      rw [hb, hWhit, honly a (by omega) hVnotz.1 hane]
      rfl
  · intro k g' a' b' hkV hk hkept
    have hbnd := C.gateAt_bounds hk
    have hbad : ∀ o, (o = a' ∨ o = b') → o ≠ z.val ∧ o ≠ W := by
      intro o ho
      constructor
      · intro he
        have hm : k ∈ C.users z.val := C.mem_users.mpr ⟨g',a',b',hk,by
          rcases ho with rfl | rfl <;> simp [he]⟩
        rw [huz, Finset.mem_singleton] at hm
        have hrel := C.isKept_eq_not_isAliased (fixRes P c) hk
        rw [hm, hWal] at hrel
        rw [hm] at hkept
        rw [hkept] at hrel
        contradiction
      · intro he
        have hm : k ∈ C.users W := C.mem_users.mpr ⟨g',a',b',hk,by
          rcases ho with rfl | rfl <;> simp [he]⟩
        rw [huW, Finset.mem_singleton] at hm
        exact hkV hm
    have ha := hbad a' (Or.inl rfl)
    have hb := hbad b' (Or.inr rfl)
    exact ⟨honly a' (by omega) ha.1 ha.2, honly b' (by omega) hb.1 hb.2⟩
  · intro k neg hk
    have hkz : k ≠ z.val := by intro he; simp [outIs, hk, he] at houtz
    have hkW : k ≠ W := by intro he; simp [outIs, hk, he] at houtW
    exact honly k (C.outWire_bound hk) hkz hkW

theorem free_two_credit_loss_le_eliminated_distinct {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (z : Fin n) (hz : P z = false)
    (W V : Nat) (hstar : C.isDStar z.val = true) (hW : W ∈ C.users z.val)
    (hV : V ∈ C.users W)
    (hess : Essential (C.restrict (fixSubst P c)).eval z) :
    C.credit2 z - (C.restrict (fixSubst P c)).credit2 z ≤
      indicator (C.isAliased (fixRes P c) W) + indicator (C.isAliased (fixRes P c) V) := by
  have hDz := C.isD_of_isDStar z.val hstar
  have hWkept : C.isAliased (fixRes P c) W = false → C.isKept (fixRes P c) W = true := by
    intro ha
    obtain ⟨g,a,b,hgate,_⟩ := C.mem_users.mp hW
    rw [C.isKept_eq_not_isAliased (fixRes P c) hgate, ha]
    rfl
  have hVkept : C.isAliased (fixRes P c) V = false → C.isKept (fixRes P c) V = true := by
    intro ha
    obtain ⟨g,a,b,hgate,_⟩ := C.mem_users.mp hV
    rw [C.isKept_eq_not_isAliased (fixRes P c) hgate, ha]
    rfl
  cases hWal : C.isAliased (fixRes P c) W with
  | false =>
    cases hVal : C.isAliased (fixRes P c) V with
    | false =>
      have hs := C.retained_DStar_survives_distinct P c hDistinct z hz W V hstar hW hV (hWkept hWal) (hVkept hVal)
      have hd := (C.restrict (fixSubst P c)).isD_of_isDStar z.val hs
      simp [credit2, indicator, hDz, hstar, hs, hd]
    | true =>
      cases hs : (C.restrict (fixSubst P c)).isDStar z.val with
      | false =>
        have hloss := C.lost_DStar_with_first_gate_kept_distinct P c hDistinct z hz W V hstar hW hV (hWkept hWal) hs
        rw [hloss.2]
        simp [indicator]
      | true =>
        have hd := (C.restrict (fixSubst P c)).isD_of_isDStar z.val hs
        simp [credit2, indicator, hDz, hstar, hs, hd]
  | true =>
    cases hVal : C.isAliased (fixRes P c) V with
    | false =>
      have hd := C.first_credit_survives_eliminated_first_gate_distinct P c hDistinct z hz W V hstar hW hV hWal (hVkept hVal) hess
      cases hs : (C.restrict (fixSubst P c)).isDStar z.val <;>
        simp [credit2, indicator, hDz, hstar, hs, hd]
    | true =>
      have hcredit : 0 ≤ (C.restrict (fixSubst P c)).credit2 z := Nat.zero_le _
      simp only [credit2, indicator, hDz, hstar, ↓reduceIte]
      omega

theorem free_credit_losses_le_chain_eliminations_distinct {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z) :
    C.credit2Lost (C.restrict (fixSubst P c)) ≤
      ∑ z : Fin n, (indicator (C.isD z.val) * indicator (C.isAliased (fixRes P c) (W z)) +
        indicator (C.isDStar z.val) * indicator (C.isAliased (fixRes P c) (V z))) := by
  unfold credit2Lost
  apply Finset.sum_le_sum
  intro z _
  cases hd : C.isD z.val with
  | false =>
    have hs : C.isDStar z.val = false := by simp [isDStar, hd]
    simp [credit2, indicator, hd, hs]
  | true =>
    cases hs : C.isDStar z.val with
    | false =>
      have h := C.free_one_credit_loss_le_eliminated P c z (hfree z hd) (W z) hd hs (hw z hd)
      simpa [indicator, hd, hs] using h
    | true =>
      have h := C.free_two_credit_loss_le_eliminated_distinct P c hDistinct z (hfree z hd) (W z) (V z)
        hs (hw z hd) (hv z hs) (hess z hs)
      simpa [indicator, hd, hs] using h

theorem free_second_charge_bound_distinct {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (z : Fin n) :
    C.secondGateCharge (C.restrict (fixSubst P c)) (fixRes P c) W z ≤
      indicator (C.isDStar z.val) * indicator (C.isAliased (fixRes P c) (V z)) := by
  have hloss : C.credit2 z - (C.restrict (fixSubst P c)).credit2 z ≤
      indicator (C.isAliased (fixRes P c) (W z)) +
      indicator (C.isDStar z.val) * indicator (C.isAliased (fixRes P c) (V z)) := by
    cases hd : C.isD z.val with
    | false =>
      have hs : C.isDStar z.val = false := by simp [isDStar, hd]
      simp [credit2, indicator, hd, hs]
    | true =>
      cases hs : C.isDStar z.val with
      | false =>
        have h := C.free_one_credit_loss_le_eliminated P c z (hfree z hd) (W z) hd hs (hw z hd)
        simpa [indicator, hs] using h
      | true =>
        have h := C.free_two_credit_loss_le_eliminated_distinct P c hDistinct z (hfree z hd) (W z) (V z)
          hs (hw z hd) (hv z hs) (hess z hs)
        simpa [indicator, hs] using h
  simp only [secondGateCharge, firstGateCharge, Nat.min_def]
  split <;> omega

theorem free_credit_loss_eq_gate_charges_distinct {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z) :
    C.credit2Lost (C.restrict (fixSubst P c)) =
      ∑ k ∈ Finset.range (n + C.size),
        (C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k +
          C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V k) := by
  let D := C.restrict (fixSubst P c)
  let ρ := fixRes P c
  let R := Finset.range (n + C.size)
  have hf : (∑ z : Fin n, C.firstGateCharge D ρ W z) =
      ∑ k ∈ R, C.gateFirstCharge D ρ W k := by
    unfold gateFirstCharge
    rw [Finset.sum_fiberwise_eq_sum_filter]
    symm
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro z _ hz
    have hnot : W z ∉ R := by simpa using hz
    have hd : C.isD z.val = false := by
      apply Bool.eq_false_iff.mpr
      intro hd
      have hb := C.reader_index_lt (hw z hd)
      exact hnot (Finset.mem_range.mpr hb)
    have hbound := C.first_charge_bound D ρ W z
    simp [indicator, hd] at hbound
    exact hbound
  have hs : (∑ z : Fin n, C.secondGateCharge D ρ W z) =
      ∑ k ∈ R, C.gateSecondCharge D ρ W V k := by
    unfold gateSecondCharge
    rw [Finset.sum_fiberwise_eq_sum_filter]
    symm
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro z _ hz
    have hnot : V z ∉ R := by simpa using hz
    have hd : C.isDStar z.val = false := by
      apply Bool.eq_false_iff.mpr
      intro hd
      have hb := C.reader_index_lt (hv z hd)
      exact hnot (Finset.mem_range.mpr hb)
    have hbound := C.free_second_charge_bound_distinct P c hDistinct W V hfree hw hv hess z
    simp [indicator, hd] at hbound
    exact hbound
  have htotal := C.credit2Lost_eq_allocated D ρ W
  rw [Finset.sum_add_distrib, hf, hs, ← Finset.sum_add_distrib] at htotal
  exact htotal

theorem free_gate_charge_zero_of_not_aliased_distinct {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (k : Nat) (halias : C.isAliased (fixRes P c) k = false) :
    C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k +
      C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V k = 0 := by
  have hfirst : C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k = 0 := by
    unfold gateFirstCharge
    apply Finset.sum_eq_zero
    intro z hz
    have he := (Finset.mem_filter.mp hz).2
    have hb := C.first_charge_bound (C.restrict (fixSubst P c)) (fixRes P c) W z
    rw [he, halias] at hb
    simp [indicator] at hb
    exact hb
  have hsecond : C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V k = 0 := by
    unfold gateSecondCharge
    apply Finset.sum_eq_zero
    intro z hz
    have he := (Finset.mem_filter.mp hz).2
    have hb := C.free_second_charge_bound_distinct P c hDistinct W V hfree hw hv hess z
    rw [he, halias] at hb
    simp [indicator] at hb
    exact hb
  rw [hfirst, hsecond]

theorem gateSecondCharge_le_two_distinct {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (hsafe : C.DGateSafe)
    (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b)) :
    C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V k ≤ 2 := by
  let D := C.restrict (fixSubst P c)
  let ρ := fixRes P c
  let S := (Finset.univ : Finset (Fin n)).filter (fun z => V z = k)
  let T := (Finset.univ : Finset (Fin n)).filter
    (fun z => C.isDStar z.val = true ∧ V z = k)
  have hsub : T ⊆ S := by
    intro z hz
    simp only [T, S, Finset.mem_filter, Finset.mem_univ, true_and] at hz ⊢
    exact hz.2
  have heq : (∑ z ∈ T, C.secondGateCharge D ρ W z) =
      ∑ z ∈ S, C.secondGateCharge D ρ W z := by
    apply Finset.sum_subset hsub
    intro z hzS hzT
    have hs : C.isDStar z.val = false := by
      cases h : C.isDStar z.val with
      | false => rfl
      | true =>
        exfalso
        apply hzT
        simp only [T, S, Finset.mem_filter, Finset.mem_univ, true_and] at hzS ⊢
        exact ⟨h,hzS⟩
    have hb := C.free_second_charge_bound_distinct P c hDistinct W V hfree hw hv hess z
    simp [indicator, hs] at hb
    exact hb
  have hsum : (∑ z ∈ T, C.secondGateCharge D ρ W z) ≤ T.card := by
    have h := Finset.sum_le_card_nsmul T (fun z => C.secondGateCharge D ρ W z) 1 (by
      intro z _
      have hb := C.free_second_charge_bound_distinct P c hDistinct W V hfree hw hv hess z
      change C.secondGateCharge (C.restrict (fixSubst P c)) (fixRes P c) W z ≤ 1
      have hprod : indicator (C.isDStar z.val) *
          indicator (C.isAliased (fixRes P c) (V z)) ≤ 1 := by
        cases C.isDStar z.val <;> cases C.isAliased (fixRes P c) (V z) <;> decide
      exact le_trans hb hprod)
    simpa using h
  have hcard := C.second_role_card_le_two hsafe W V hw hv k g a b hk
  change S.sum (fun z => C.secondGateCharge D ρ W z) ≤ 2
  rw [← heq]
  exact le_trans hsum hcard

theorem first_second_roles_disjoint_distinct {n : Nat} (C : OpenCircuit n) (_hDistinct : C.DistinctOperands)
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (z₁ z₂ : Fin n) (W G : Nat) (hz₂ : Essential f z₂)
    (hfirst : G ∈ C.users z₁.val)
    (hstar : C.isDStar z₂.val = true) (hW : W ∈ C.users z₂.val)
    (hsecond : G ∈ C.users W) : False := by
  obtain ⟨g,a,b,hgate,hab⟩ := C.mem_users.mp hfirst
  exact C.second_role_has_no_primary_unreduced f hc hE1 z₂ hz₂ W G hstar hW hsecond
    g a b hgate z₁ hab

theorem free_gate_total_charge_le_two_distinct {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (hsafe : C.DGateSafe)
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (horig : ∀ z, C.isDStar z.val = true → Essential f z)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b)) :
    C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k +
      C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V k ≤ 2 := by
  let D := C.restrict (fixSubst P c)
  let ρ := fixRes P c
  change C.gateFirstCharge D ρ W k + C.gateSecondCharge D ρ W V k ≤ 2
  by_cases hf : ∃ z, C.isD z.val = true ∧ W z = k
  · obtain ⟨z₁, hz₁, hkW⟩ := hf
    have hsecondZero : C.gateSecondCharge D ρ W V k = 0 := by
      unfold gateSecondCharge
      apply Finset.sum_eq_zero
      intro z hz
      have hVk : V z = k := (Finset.mem_filter.mp hz).2
      have hstar : C.isDStar z.val = false := by
        cases hs : C.isDStar z.val with
        | false => rfl
        | true =>
          exfalso
          have hfirst : k ∈ C.users z₁.val := by simpa [hkW] using hw z₁ hz₁
          have hsecond : k ∈ C.users (W z) := by simpa [hVk] using hv z hs
          exact C.first_second_roles_disjoint_distinct hDistinct f hc hE1 z₁ z (W z) k (horig z hs)
            hfirst hs (hw z (C.isD_of_isDStar z.val hs)) hsecond
      have hbound := C.free_second_charge_bound_distinct P c hDistinct W V hfree hw hv hess z
      simp [indicator, hstar] at hbound
      exact hbound
    have hfirst := C.gateFirstCharge_le_one D ρ hsafe W hw k
    rw [hsecondZero]
    omega
  · have hfirstZero : C.gateFirstCharge D ρ W k = 0 := by
      unfold gateFirstCharge
      apply Finset.sum_eq_zero
      intro z hz
      have hWk : W z = k := (Finset.mem_filter.mp hz).2
      have hDz : C.isD z.val = false := by
        apply Bool.eq_false_iff.mpr
        intro hd
        exact hf ⟨z,hd,hWk⟩
      have hbound := C.first_charge_bound D ρ W z
      simp [indicator, hDz] at hbound
      exact hbound
    have hsecond := C.gateSecondCharge_le_two_distinct P c hDistinct hsafe W V hfree hw hv hess k g a b hk
    change C.gateFirstCharge D ρ W k + C.gateSecondCharge D ρ W V k ≤ 2
    rw [hfirstZero]
    simpa only [Nat.zero_add] using hsecond

/-- The unique reader in a D-link has a nonlinear truth table. -/
theorem isD_reader_nonlinear {n : Nat} (C : OpenCircuit n) (s k : Nat)
    (hd : C.isD s = true) (hk : k ∈ C.users s) (g : Table) (a b : Nat)
    (hgate : C.gateAt k = some (g,a,b)) : g.nonlinear = true := by
  obtain ⟨_,w,t,c,d,hw,hab,hnl⟩ := (C.isD_iff s).mp hd
  have hm : w ∈ C.users s := C.mem_users.mpr ⟨t,c,d,hw,hab⟩
  have hu := C.users_singleton_of_isD s k hd hk
  rw [hu,Finset.mem_singleton] at hm
  rw [hm,hgate] at hw
  cases hw
  exact hnl

/-- No first or second credit can be charged to a degenerate gate. -/
theorem gate_charges_zero_of_degenerate {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hDistinct : C.DistinctOperands) (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (k : Nat) (g : Table) (a b : Nat) (hgate : C.gateAt k = some (g,a,b))
    (hdeg : g.essential = false) :
    C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k +
      C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V k = 0 := by
  let D := C.restrict (fixSubst P c)
  let ρ := fixRes P c
  change C.gateFirstCharge D ρ W k + C.gateSecondCharge D ρ W V k = 0
  have hnl : g.nonlinear = false := by simp [Table.nonlinear,hdeg]
  have hf : C.gateFirstCharge D ρ W k = 0 := by
    unfold gateFirstCharge
    apply Finset.sum_eq_zero
    intro z hz
    have hW : W z = k := (Finset.mem_filter.mp hz).2
    have hzD : C.isD z.val = false := by
      apply Bool.eq_false_iff.mpr
      intro hd
      have hm : k ∈ C.users z.val := by simpa [hW] using hw z hd
      have hh := C.isD_reader_nonlinear z.val k hd hm g a b hgate
      rw [hnl] at hh
      contradiction
    have hbound := C.first_charge_bound D ρ W z
    simp [indicator,hzD] at hbound
    omega
  have hs : C.gateSecondCharge D ρ W V k = 0 := by
    unfold gateSecondCharge
    apply Finset.sum_eq_zero
    intro z hz
    have hV : V z = k := (Finset.mem_filter.mp hz).2
    have hzS : C.isDStar z.val = false := by
      apply Bool.eq_false_iff.mpr
      intro hstar
      have hDz := C.isD_of_isDStar z.val hstar
      have hW := hw z hDz
      have huz := C.users_singleton_of_isD z.val (W z) hDz hW
      have hDW : C.isD (W z) = true := by
        obtain ⟨_,w,hmem,hd⟩ := (C.isDStar_iff z.val).mp hstar
        rw [huz,Finset.mem_singleton] at hmem
        simpa [hmem] using hd
      have hm : k ∈ C.users (W z) := by simpa [hV] using hv z hstar
      have hh := C.isD_reader_nonlinear (W z) k hDW hm g a b hgate
      rw [hnl] at hh
      contradiction
    have hb := C.free_second_charge_bound_distinct P c hDistinct W V hfree hw hv hess z
    change C.secondGateCharge D ρ W z ≤ _ at hb
    simp [hzS,indicator] at hb
    omega
  omega

end OpenCircuit
end SatLowerBound
