import Credit.TwoLevel.RobustDegree
import Credit.TwoLevel.Correspondence

/-! Theorem 8.1 stated with successor-set credits and the printed ceiling. -/
namespace SatLowerBound

/-- Equation (2) in the manuscript's potential convention. The support
premise makes explicit which coordinates remain free after restrictions. -/
theorem paper_composition_potential {n k : Nat} (hk : 2 ≤ k)
    (T : RobustTree n) (ρ : Fin n → Option Bool) (hT : T.Valid k ρ)
    (C : OpenCircuit n) (hr : C.Reduced) (ht : C.NoInputTriangles (fun _ => none))
    (hc : ∀ v, C.eval v = T.eval (applyPartial ρ v))
    (hsupport : ∀ z, 0 < C.usage (OpenCircuit.singleUse z) → z ∈ freeOn T.support ρ) :
    14 * (((freeOn T.support ρ).card : Int) - ((k : Int)+1) * T.blocks) ≤
      C.paperPsi2 := by
  rw [← C.psi2_eq_paperPsi2 hr]
  exact robust_tree_psi2_bound hk T ρ hT C hr ht hc hsupport

/-- Equation (3) for a composition on exactly its L=n input coordinates.
Full degree is required of the leaves, not assumed of the composition. -/
theorem paper_composition_ceiling_bound {n k : Nat} (hk : 2 ≤ k)
    (T : RobustTree n) (hT : T.Valid k (fun _ => none))
    (hs : T.support = Finset.univ) (hfull : T.FullLeaves)
    (C : OpenCircuit n) (hc : ∀ v, C.eval v = T.eval v) :
    ⌈(17 * (n : ℝ) - 14 * ((k : ℝ) + 1) * T.blocks - 3) / 7⌉ ≤
      (C.size : ℤ) := by
  apply Int.ceil_le.mpr
  have h := T.full_leaves_size hk hT hs hfull C hc
  have hreal : 17 * (n : ℝ) - 14 * ((k : ℝ) + 1) * T.blocks - 3 ≤
      7 * (C.size : ℝ) := by exact_mod_cast h
  push_cast
  linarith

end SatLowerBound
