import Credit.TwoLevel.CofactorSubcube

/-! Counting failures of the paper's four-row condition. -/
namespace SatLowerBound

/-- The Boolean truth tables whose restricted pair cofactors coincide. -/
noncomputable def rowCollisionSet {n : Nat} (ρ : Fin n → Option Bool)
    (i j : Fin n) (p q : Bool × Bool) : Finset ((Fin n → Bool) → Bool) := by
  classical
  exact Finset.univ.filter (fun f =>
    PairRow (fun a b x => f (applyPartial ρ (setPair x i j a b))) p =
    PairRow (fun a b x => f (applyPartial ρ (setPair x i j a b))) q)

/-- The set of functions which agree on a given pair of subcubes. -/
noncomputable def coincidentSet {α β : Type} [Fintype α] [Fintype β]
    (a b : β → α) : Finset (α → Bool) := by
  classical
  exact Finset.univ.filter (fun f => ∀ x, f (a x) = f (b x))

theorem coincidentSet_card {α β : Type} [Fintype α] [Fintype β] (a b : β → α) :
    (coincidentSet a b).card = coincidentCard a b := by
  classical
  unfold coincidentSet coincidentCard CoincidentFunctions
  rw [Fintype.card_subtype]

/-- A row collision event is contained in the corresponding subcube collision
event. -/
theorem rowCollisionSet_subset {n : Nat} (ρ : Fin n → Option Bool)
    (i j : Fin n) (p q : Bool × Bool) :
    rowCollisionSet ρ i j p q ⊆
      coincidentSet (cofactorCube ρ i j p) (cofactorCube ρ i j q) := by
  classical
  intro f hf
  simp only [rowCollisionSet, Finset.mem_filter, Finset.mem_univ, true_and] at hf
  simp only [coincidentSet, Finset.mem_filter, Finset.mem_univ, true_and]
  exact rowCollision_on_subcubes ρ i j p q f hf

/-- Number of truth tables with this particular cofactor collision. -/
theorem rowCollisionSet_card_le {n : Nat} (ρ : Fin n → Option Bool)
    (i j : Fin n) (hij : i ≠ j) (hi : ρ i = none) (hj : ρ j = none)
    (p q : Bool × Bool) (hpq : p ≠ q) :
    (rowCollisionSet ρ i j p q).card ≤
      2 ^ (2 ^ n - 2 ^ ((freeCoordinates ρ).card - 2)) := by
  calc
    _ ≤ (coincidentSet (cofactorCube ρ i j p) (cofactorCube ρ i j q)).card :=
      Finset.card_le_card (rowCollisionSet_subset ρ i j p q)
    _ = coincidentCard (cofactorCube ρ i j p) (cofactorCube ρ i j q) :=
      coincidentSet_card _ _
    _ ≤ _ := cofactor_collision_card_le ρ i j hij hi hj p q hpq

/-- The six unordered pairs among the four possible Boolean pair rows. -/
def sixRowPairs : Fin 6 → (Bool × Bool) × (Bool × Bool) :=
  ![((false,false),(false,true)), ((false,false),(true,false)),
    ((false,false),(true,true)), ((false,true),(true,false)),
    ((false,true),(true,true)), ((true,false),(true,true))]

theorem sixRowPairs_distinct (t : Fin 6) : (sixRowPairs t).1 ≠ (sixRowPairs t).2 := by
  fin_cases t <;> decide

theorem sixRowPairs_cover (p q : Bool × Bool) (hpq : p ≠ q) :
    ∃ t, sixRowPairs t = (p,q) ∨ sixRowPairs t = (q,p) := by
  revert p q
  decide

/-- Indices for potential failures: a restriction, a pair of coordinates,
    and one of the six unordered row pairs. -/
abbrev CollisionIndex (n : Nat) := (Fin n → Option Bool) × Fin n × Fin n × Fin 6

def ValidCollisionIndex {n k : Nat} (t : CollisionIndex n) : Prop :=
  k ≤ (freeCoordinates t.1).card ∧ t.2.1 ≠ t.2.2.1 ∧
    t.1 t.2.1 = none ∧ t.1 t.2.2.1 = none

noncomputable def collisionIndices (n k : Nat) : Finset (CollisionIndex n) := by
  classical
  exact Finset.univ.filter (fun t => @ValidCollisionIndex n k t)

noncomputable def collisionEvent {n : Nat} (t : CollisionIndex n) :
    Finset ((Fin n → Bool) → Bool) :=
  rowCollisionSet t.1 t.2.1 t.2.2.1 (sixRowPairs t.2.2.2).1 (sixRowPairs t.2.2.2).2

noncomputable def badFunctions (n k : Nat) : Finset ((Fin n → Bool) → Bool) := by
  classical
  exact (collisionIndices n k).biUnion collisionEvent

/-- If a block fails robustness, it belongs to one of the indexed cofactor
collision events. -/
theorem notRobust_mem_badFunctions {n k : Nat} (f : (Fin n → Bool) → Bool)
    (hf : ¬ Robust k f) : f ∈ badFunctions n k := by
  classical
  by_contra hn
  apply hf
  intro ρ hfree i j hij hi hj p q hpqeq
  by_contra hpq
  obtain ⟨t,ht | ht⟩ := sixRowPairs_cover p q hpq
  all_goals
    have hidx : (ρ,i,j,t) ∈ collisionIndices n k := by
      change (ρ,i,j,t) ∈ Finset.univ.filter (fun t => @ValidCollisionIndex n k t)
      simp only [Finset.mem_filter, Finset.mem_univ, true_and]
      exact ⟨hfree,hij,hi,hj⟩
    have hrow : f ∈ collisionEvent (ρ,i,j,t) := by
      simp only [collisionEvent,rowCollisionSet,Finset.mem_filter,Finset.mem_univ,true_and]
      simp only [ht]
      first | exact hpqeq | exact hpqeq.symm
    exact hn (Finset.mem_biUnion.mpr ⟨(ρ,i,j,t),hidx,hrow⟩)

/-- Every indexed collision event has the paper's uniform bound for at least
`k` free coordinates. -/
theorem collisionEvent_card_le {n k : Nat} (t : CollisionIndex n)
    (ht : t ∈ collisionIndices n k) :
    (collisionEvent t).card ≤ 2 ^ (2 ^ n - 2 ^ (k - 2)) := by
  classical
  rcases t with ⟨ρ,i,j,t⟩
  have hv : ValidCollisionIndex (n := n) (k := k) (ρ,i,j,t) := by
    change (ρ,i,j,t) ∈ Finset.univ.filter (fun t => @ValidCollisionIndex n k t) at ht
    exact (Finset.mem_filter.mp ht).2
  obtain ⟨hfree,hij,hi,hj⟩ := hv
  have hexp : 2 ^ (k - 2) ≤ 2 ^ ((freeCoordinates ρ).card - 2) :=
    Nat.pow_le_pow_right (by omega) (Nat.sub_le_sub_right hfree 2)
  exact (rowCollisionSet_card_le ρ i j hij hi hj _ _ (sixRowPairs_distinct t)).trans
    (Nat.pow_le_pow_right (by omega) (Nat.sub_le_sub_left hexp _))

/-- There are at most `3^n · n² · 6` potential collision events. The paper
uses unordered coordinate pairs for a slightly sharper constant. -/
theorem collisionIndices_card_le (n k : Nat) :
    (collisionIndices n k).card ≤ 3 ^ n * n * n * 6 := by
  classical
  have h := Finset.card_filter_le (Finset.univ : Finset (CollisionIndex n))
    (fun t => @ValidCollisionIndex n k t)
  change (collisionIndices n k).card ≤ _ at h
  simpa [CollisionIndex, Fintype.card_prod, Fintype.card_fun, Fintype.card_option,
    Fintype.card_bool, Fintype.card_fin, Nat.mul_assoc] using h

/-- Finite union bound for all failures of robustness. -/
theorem badFunctions_card_le (n k : Nat) :
    (badFunctions n k).card ≤
      (3 ^ n * n * n * 6) * 2 ^ (2 ^ n - 2 ^ (k - 2)) := by
  classical
  calc
    (badFunctions n k).card ≤
        ∑ t ∈ collisionIndices n k, 2 ^ (2 ^ n - 2 ^ (k - 2)) := by
      apply (Finset.card_biUnion_le).trans
      exact Finset.sum_le_sum (fun t ht => collisionEvent_card_le t ht)
    _ = (collisionIndices n k).card * 2 ^ (2 ^ n - 2 ^ (k - 2)) := by simp
    _ ≤ _ := Nat.mul_le_mul_right _ (collisionIndices_card_le n k)

end SatLowerBound
