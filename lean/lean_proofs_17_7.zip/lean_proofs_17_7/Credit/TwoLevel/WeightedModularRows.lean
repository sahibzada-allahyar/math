import Credit.TwoLevel.Robust
import Mathlib.Data.ZMod.Basic

/-! The disjoint cofactor supports in the weighted-modular construction. -/
namespace SatLowerBound

/-- In any additive group, distinct shifts and a surjective residual sum give
four nonempty and pairwise disjoint equality cofactors. -/
theorem fourRows_of_surjective_shifts {G α : Type} [AddGroup G] [DecidableEq G]
    (s : α → G) (hs : Function.Surjective s) (shift : Bool × Bool → G)
    (hshift : Function.Injective shift) (target : G) :
    FourRows (fun a b x => decide (s x + shift (a,b) = target)) := by
  intro p q hpq
  have hex : ∃ x, s x = target - shift p := hs (target - shift p)
  obtain ⟨x,hx⟩ := hex
  have hv := congrFun hpq x
  simp only [PairRow, decide_eq_decide] at hv
  have hp : s x + shift p = target := by rw [hx]; simp
  have hq : s x + shift q = target := hv.mp hp
  apply hshift
  rw [hx] at hq
  have : target - shift p + shift q = target - shift p + shift p := by
    rw [hq, sub_add_cancel]
  exact add_left_cancel this.symm

/-- The natural shift contributed by assigning the two selected coordinates. -/
def weightedPairShiftNat {n : Nat} (i j : Fin n) (p : Bool × Bool) : Nat :=
  (if p.1 then i.val + 1 else 0) + (if p.2 then j.val + 1 else 0)

theorem weightedPairShiftNat_injective {n : Nat} (i j : Fin n) (hij : i ≠ j) :
    Function.Injective (weightedPairShiftNat i j) := by
  rintro ⟨a,b⟩ ⟨c,d⟩ h
  have hv : i.val ≠ j.val := by
    intro he
    exact hij (Fin.ext he)
  cases a <;> cases b <;> cases c <;> cases d <;>
    simp_all [weightedPairShiftNat]

theorem weightedPairShiftNat_lt {n p : Nat} (i j : Fin n) (hlarge : 2 * n < p)
    (u : Bool × Bool) : weightedPairShiftNat i j u < p := by
  rcases u with ⟨a,b⟩
  have hi := i.isLt
  have hj := j.isLt
  cases a <;> cases b <;> simp [weightedPairShiftNat] <;> omega

/-- For `p > 2n`, the four shifts `0, i+1, j+1, i+j+2` are distinct in
`ZMod p`, exactly as used in Proposition 5.10. -/
theorem weightedPairShift_injective {n p : Nat} (i j : Fin n) (hij : i ≠ j)
    (hlarge : 2 * n < p) :
    Function.Injective (fun u => (weightedPairShiftNat i j u : ZMod p)) := by
  intro u v he
  have hm := (ZMod.natCast_eq_natCast_iff' _ _ p).mp he
  rw [Nat.mod_eq_of_lt (weightedPairShiftNat_lt i j hlarge u),
    Nat.mod_eq_of_lt (weightedPairShiftNat_lt i j hlarge v)] at hm
  exact weightedPairShiftNat_injective i j hij hm

/-- The cofactor separation step of the weighted-modular construction,
conditional only on coverage by the residual subset sums. -/
theorem weighted_modular_fourRows {n p : Nat} {α : Type} (i j : Fin n)
    (hij : i ≠ j) (hlarge : 2 * n < p)
    (s : α → ZMod p) (hs : Function.Surjective s) (target : ZMod p) :
    FourRows (fun a b x => decide (s x + (weightedPairShiftNat i j (a,b) : ZMod p) = target)) :=
  fourRows_of_surjective_shifts s hs _ (weightedPairShift_injective i j hij hlarge) target

/-- Weighted sum from the manuscript, with coordinate `i` carrying weight
`i+1`. -/
def weightedSum {n p : Nat} (v : Fin n → Bool) : ZMod p :=
  ∑ z : Fin n, if v z then (z.val + 1 : Nat) else 0

/-- Remove the two selected contributions, while keeping the restriction's
other fixed and free inputs. -/
def weightedResidual {n p : Nat} (ρ : Fin n → Option Bool) (i j : Fin n)
    (v : Fin n → Bool) : ZMod p :=
  weightedSum (applyPartial ρ (setPair v i j false false))

/-- On free selected coordinates, each cofactor's weighted sum is its shared
residual sum plus the corresponding pair shift. -/
theorem weightedSum_cofactor {n p : Nat} (ρ : Fin n → Option Bool) (i j : Fin n)
    (hij : i ≠ j) (hi : ρ i = none) (hj : ρ j = none)
    (v : Fin n → Bool) (a b : Bool) :
    weightedSum (p := p) (applyPartial ρ (setPair v i j a b)) =
      weightedResidual ρ i j v + (weightedPairShiftNat i j (a,b) : ZMod p) := by
  classical
  have hsum : (∑ z : Fin n,
      ((if (applyPartial ρ (setPair v i j false false)) z then ((z.val + 1 : Nat) : ZMod p) else 0) +
      (if z = i then (if a then ((i.val + 1 : Nat) : ZMod p) else 0) else 0) +
      (if z = j then (if b then ((j.val + 1 : Nat) : ZMod p) else 0) else 0))) =
      (∑ z : Fin n, if (applyPartial ρ (setPair v i j false false)) z then ((z.val + 1 : Nat) : ZMod p) else 0) +
      (if a then ((i.val + 1 : Nat) : ZMod p) else 0) +
      (if b then ((j.val + 1 : Nat) : ZMod p) else 0) := by
    simp [Finset.sum_add_distrib]
  unfold weightedResidual weightedSum weightedPairShiftNat
  simp only [Nat.cast_add, Nat.cast_ite, Nat.cast_zero]
  have he : (∑ z : Fin n, if (applyPartial ρ (setPair v i j a b)) z then ((z.val + 1 : Nat) : ZMod p) else 0) =
      ∑ z : Fin n,
      ((if (applyPartial ρ (setPair v i j false false)) z then ((z.val + 1 : Nat) : ZMod p) else 0) +
      (if z = i then (if a then ((i.val + 1 : Nat) : ZMod p) else 0) else 0) +
      (if z = j then (if b then ((j.val + 1 : Nat) : ZMod p) else 0) else 0)) := by
    apply Finset.sum_congr rfl
    intro z _
    by_cases hzi : z = i
    · subst z
      simp [applyPartial,setPair,hi,hij]
    · by_cases hzj : z = j
      · subst z
        simp [applyPartial,setPair,hj,Ne.symm hij]
      · simp [applyPartial,setPair,hzi,hzj]
  simp only [Nat.cast_add, Nat.cast_one] at he hsum ⊢
  rw [he, hsum]
  ring

/-- The weighted modular test `g_{r,t}` from Proposition 5.10. -/
def weightedModularBlock (n p : Nat) (target : ZMod p) (v : Fin n → Bool) : Bool :=
  decide (weightedSum v = target)

/-- Residual subset sums cover all residues after every allowed restriction
and deletion of two free coordinates. -/
def WeightedResidualCoverage (n p k : Nat) : Prop :=
  ∀ (ρ : Fin n → Option Bool), k ≤ (freeCoordinates ρ).card →
    ∀ i j, i ≠ j → ρ i = none → ρ j = none →
      Function.Surjective (weightedResidual (p := p) ρ i j)

/-- Once subset-sum coverage is established, the actual weighted modular
block satisfies the paper's definition of `k`-robustness. -/
theorem weightedModularBlock_robust_of_coverage (n p k : Nat) (hlarge : 2 * n < p)
    (hcoverage : WeightedResidualCoverage n p k) (target : ZMod p) :
    Robust k (weightedModularBlock n p target) := by
  intro ρ hfree i j hij hi hj
  have hrows := weighted_modular_fourRows i j hij hlarge
    (weightedResidual (p := p) ρ i j) (hcoverage ρ hfree i j hij hi hj) target
  change FourRows (fun a b x => weightedModularBlock n p target (applyPartial ρ (setPair x i j a b)))
  convert hrows using 1
  funext a b x
  simp only [weightedModularBlock,weightedSum_cofactor ρ i j hij hi hj]

end SatLowerBound
