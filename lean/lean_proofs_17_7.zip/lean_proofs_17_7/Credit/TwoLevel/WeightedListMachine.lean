import Credit.TwoLevel.WeightedResidueSelection
import Mathlib.Data.List.Rotate

/-! A costed list-machine implementation of the residue recurrence.

The machine stores bits in list cells and counters in unary. Each branch,
cell read/write, Boolean XOR and counter constructor/destructor has bounded
cost; the charges below count these elementary actions conservatively.
They are not timings for Lean's compiled arbitrary-precision Nat operations.
The result and its cost are produced by the same recursive computation.
-/
namespace SatLowerBound
namespace ResidueMachine

structure Run (α : Type) where
  value : α
  steps : Nat

/-- Allocate a zero-filled bit tape. -/
def zeros : Nat → Run (List Bool)
  | 0 => ⟨[],1⟩
  | n+1 => let r := zeros n; ⟨false :: r.value,r.steps+3⟩

/-- Walk over k cells, stopping at the end. -/
def drop : Nat → List Bool → Run (List Bool)
  | 0, xs => ⟨xs,1⟩
  | _+1, [] => ⟨[],1⟩
  | k+1, _::xs => let r := drop k xs; ⟨r.value,r.steps+3⟩

/-- Copy a prefix. -/
def take : Nat → List Bool → Run (List Bool)
  | 0, _ => ⟨[],1⟩
  | _+1, [] => ⟨[],1⟩
  | k+1, x::xs => let r := take k xs; ⟨x::r.value,r.steps+4⟩

/-- Append by copying the left tape. -/
def append : List Bool → List Bool → Run (List Bool)
  | [], ys => ⟨ys,1⟩
  | x::xs, ys => let r := append xs ys; ⟨x::r.value,r.steps+3⟩

/-- Pointwise XOR, reading two cells and writing one cell per iteration. -/
def xor : List Bool → List Bool → Run (List Bool)
  | [], _ => ⟨[],1⟩
  | _::_, [] => ⟨[],1⟩
  | x::xs, y::ys => let r := xor xs ys; ⟨Bool.xor x y :: r.value,r.steps+5⟩

/-- Saturating subtraction on unary counters. -/
def sub : Nat → Nat → Run Nat
  | a, 0 => ⟨a,1⟩
  | 0, _+1 => ⟨0,1⟩
  | a+1, b+1 => let r := sub a b; ⟨r.value,r.steps+3⟩

/-- Least true position, returned as a unary counter. -/
def first : List Bool → Run (Option Nat)
  | [] => ⟨none,1⟩
  | true::_ => ⟨some 0,2⟩
  | false::xs => let r := first xs; ⟨r.value.map Nat.succ,r.steps+4⟩

@[simp] theorem zeros_value (n : Nat) : (zeros n).value = List.replicate n false := by
  induction n with
  | zero => rfl
  | succ n ih => simp [zeros,ih,List.replicate_succ]

@[simp] theorem zeros_steps (n : Nat) : (zeros n).steps = 3*n+1 := by
  induction n with
  | zero => rfl
  | succ n ih => simp [zeros,ih]; omega

@[simp] theorem drop_value (k : Nat) (xs : List Bool) :
    (drop k xs).value = xs.drop k := by
  induction k generalizing xs with
  | zero => rfl
  | succ k ih => cases xs <;> simp [drop,ih]

theorem drop_steps (k : Nat) (xs : List Bool) : (drop k xs).steps ≤ 3*k+1 := by
  induction k generalizing xs with
  | zero => simp [drop]
  | succ k ih =>
    cases xs with
    | nil => simp [drop]
    | cons x xs => have := ih xs; simp only [drop]; omega

@[simp] theorem take_value (k : Nat) (xs : List Bool) :
    (take k xs).value = xs.take k := by
  induction k generalizing xs with
  | zero => rfl
  | succ k ih => cases xs <;> simp [take,ih]

theorem take_steps (k : Nat) (xs : List Bool) : (take k xs).steps ≤ 4*k+1 := by
  induction k generalizing xs with
  | zero => simp [take]
  | succ k ih =>
    cases xs with
    | nil => simp [take]
    | cons x xs => have := ih xs; simp only [take]; omega

@[simp] theorem append_value (xs ys : List Bool) :
    (append xs ys).value = xs ++ ys := by
  induction xs with
  | nil => rfl
  | cons x xs ih => simp [append,ih]

@[simp] theorem append_steps (xs ys : List Bool) :
    (append xs ys).steps = 3*xs.length+1 := by
  induction xs with
  | nil => rfl
  | cons x xs ih => simp [append,ih]; omega

@[simp] theorem xor_value (xs ys : List Bool) :
    (xor xs ys).value = List.zipWith Bool.xor xs ys := by
  induction xs generalizing ys with
  | nil => rfl
  | cons x xs ih => cases ys <;> simp [xor,ih]

theorem xor_steps (xs ys : List Bool) : (xor xs ys).steps ≤ 5*xs.length+1 := by
  induction xs generalizing ys with
  | nil => simp [xor]
  | cons x xs ih =>
    cases ys with
    | nil => simp [xor]
    | cons y ys => have := ih ys; simp only [xor,List.length_cons]; omega

@[simp] theorem sub_value (a b : Nat) : (sub a b).value = a-b := by
  induction b generalizing a with
  | zero => simp [sub]
  | succ b ih => cases a <;> simp [sub,ih]

theorem sub_steps (a b : Nat) : (sub a b).steps ≤ 3*b+1 := by
  induction b generalizing a with
  | zero => simp [sub]
  | succ b ih =>
    cases a with
    | zero => simp [sub]
    | succ a => have := ih a; simp only [sub]; omega

theorem first_steps (xs : List Bool) : (first xs).steps ≤ 4*xs.length+1 := by
  induction xs with
  | nil => simp [first]
  | cons x xs ih => cases x <;> simp [first] <;> omega

/-- Rotate a p-cell tape right by i positions, using only sequential tape
traversals and unary subtraction. The caller supplies i ≤ p. -/
def rotate (p i : Nat) (xs : List Bool) : Run (List Bool) :=
  let k := sub p i
  let right := drop k.value xs
  let left := take k.value xs
  let joined := append right.value left.value
  ⟨joined.value,k.steps+right.steps+left.steps+joined.steps+4⟩

theorem rotate_value (p i : Nat) (xs : List Bool) (hlen : xs.length = p) :
    (rotate p i xs).value = xs.rotate (p-i) := by
  simp only [rotate,sub_value,drop_value,take_value,append_value]
  exact (List.rotate_eq_drop_append_take (by omega)).symm

theorem rotate_steps (p i : Nat) (xs : List Bool) (hi : i ≤ p) (hlen : xs.length = p) :
    (rotate p i xs).steps ≤ 13*p+8 := by
  have hs := sub_steps p i
  have hd := drop_steps (p-i) xs
  have ht := take_steps (p-i) xs
  simp only [rotate,sub_value,append_steps,drop_value,List.length_drop,hlen]
  omega

/-- One actual recurrence round, including rotation and output construction. -/
def round (p i : Nat) (xs : List Bool) : Run (List Bool) :=
  let shifted := rotate p i xs
  let result := xor xs shifted.value
  ⟨result.value,shifted.steps+result.steps+2⟩

theorem round_value (p i : Nat) (xs : List Bool) (hlen : xs.length = p) :
    (round p i xs).value = List.zipWith Bool.xor xs (xs.rotate (p-i)) := by
  simp only [round,xor_value,rotate_value p i xs hlen]

theorem round_length (p i : Nat) (xs : List Bool) (hlen : xs.length = p) :
    (round p i xs).value.length = p := by
  rw [round_value p i xs hlen]
  simp [hlen]

theorem round_steps (p i : Nat) (xs : List Bool) (hi : i ≤ p) (hlen : xs.length = p) :
    (round p i xs).steps ≤ 18*p+11 := by
  have hr := rotate_steps p i xs hi hlen
  have hx := xor_steps xs (rotate p i xs).value
  simp only [round]
  omega

/-- Materialize the initial delta table, then perform r recurrence rounds. -/
def table (p : Nat) : Nat → Run (List Bool)
  | 0 => let z := zeros (p-1); ⟨true::z.value,z.steps+2⟩
  | r+1 =>
    let prev := table p r
    let next := round p (r+1) prev.value
    ⟨next.value,prev.steps+next.steps+2⟩

theorem table_length (p r : Nat) (hp : 0 < p) : (table p r).value.length = p := by
  induction r with
  | zero => simp [table]; omega
  | succ r ih => exact round_length p (r+1) _ ih

theorem table_steps (p r : Nat) (hp : 0 < p) (hr : r ≤ p) :
    (table p r).steps ≤ 3*p+3+r*(18*p+13) := by
  induction r with
  | zero => simp [table]
  | succ r ih =>
    have hprev := ih (by omega)
    have hround := round_steps p (r+1) (table p r).value hr (table_length p r hp)
    simp only [table]
    nlinarith

/-- Table construction and least-residue scan, in a single costed run. -/
def select (p r : Nat) : Run (Option Nat) :=
  let t := table p r
  let s := first t.value
  ⟨s.value,t.steps+s.steps+2⟩

theorem select_steps (p r : Nat) (hp : 0 < p) (hr : r ≤ p) :
    (select p r).steps ≤ 7*p+6+r*(18*p+13) := by
  have ht := table_steps p r hp hr
  have hs := first_steps (table p r).value
  rw [table_length p r hp] at hs
  simp only [select]
  omega

@[simp] theorem first_value (xs : List Bool) :
    (first xs).value = xs.findIdx? id := by
  induction xs with
  | nil => rfl
  | cons x xs ih => cases x <;> simp [first,List.findIdx?_cons,ih]

/-- Quadratic cost including initialization, all tape traversals, XORs,
output-cell construction, unary counter subtraction, and the final scan. -/
theorem select_steps_quadratic (r : Nat) (hr : 1 ≤ r) :
    (select (weightedPrime r) r).steps ≤ 119*r*r := by
  have hp := weightedPrime_spec r
  have hp4 := weightedPrime_le_four r hr
  have hb := select_steps (weightedPrime r) r hp.1.pos (by omega)
  have hm : r * (18 * weightedPrime r + 13) ≤ r * (72*r+13) :=
    Nat.mul_le_mul_left r (by omega)
  nlinarith [Nat.mul_self_le_mul_self hr]

/-- Rotation of a list is the modular backwards index used by the vector
recurrence, without executing modular arithmetic in the list machine. -/
theorem backwards_index (p i j : Nat) [NeZero p] (hi : i ≤ p) :
    (j+(p-i)) % p = ((j : ZMod p) - (i : ZMod p)).val := by
  have h : ((j+(p-i) : Nat) : ZMod p) = (j : ZMod p) - (i : ZMod p) := by
    rw [Nat.cast_add,Nat.cast_sub hi]
    simp [sub_eq_add_neg]
  rw [← h,ZMod.val_natCast]

/-- The costed implementation returns exactly the previously verified
vector table; no parity or degree property is assumed here. -/
theorem table_value (p r : Nat) [NeZero p] (hr : r ≤ p) :
    (table p r).value = (weightedResidueTable p r).toList := by
  have hp : 0 < p := Nat.pos_of_ne_zero (NeZero.ne p)
  induction r with
  | zero =>
    apply List.ext_getElem
    · simp [table_length p 0 hp]
    · intro j hj hj'
      have hjp : j < p := by simpa using hj'
      simp only [table,zeros_value,Vector.getElem_toList,weightedResidueTable,
        Vector.getElem_ofFn]
      have hz : (j : ZMod p) = 0 ↔ j = 0 := by
        rw [ZMod.natCast_eq_zero_iff,Nat.dvd_iff_mod_eq_zero,Nat.mod_eq_of_lt hjp]
      cases j with
      | zero => simp
      | succ j =>
        have hne : ((j+1 : Nat) : ZMod p) ≠ 0 := by
          intro he
          have hh := hz.mp he
          omega
        simp only [List.getElem_cons_succ,List.getElem_replicate,hne,decide_false]
  | succ r ih =>
    have prev := ih (by omega)
    change (round p (r+1) (table p r).value).value = _
    rw [round_value p (r+1) _ (table_length p r hp),prev]
    apply List.ext_getElem
    · simp
    · intro j hj hj'
      simp only [List.getElem_zipWith,List.getElem_rotate,Vector.getElem_toList,
        Vector.length_toList,weightedResidueTable,Vector.getElem_ofFn]
      congr 1
      congr 1
      exact backwards_index p (r+1) j hr

/-- The costed scan returns the same least residue as the verified selector. -/
theorem select_value_of_verified (p r : Nat) [NeZero p] (hr : r ≤ p)
    (i : Fin p) (hi : selectWeightedResidue r p = some i) :
    (select p r).value = some i.val := by
  change (first (table p r).value).value = _
  rw [first_value,table_value p r hr]
  obtain ⟨htrue,hmin⟩ := Fin.find?_eq_some_iff.mp hi
  apply List.findIdx?_eq_some_iff_getElem.mpr
  refine ⟨by simp,?_,?_⟩
  · simpa using htrue
  · intro j hj
    have h := hmin (⟨j,by omega⟩ : Fin p) hj
    simpa using h

/-- Correct residue selection and a total step bound for the list-machine
algorithm, for the odd-prime parameters of the construction. -/
theorem select_correct_with_cost (p r : Nat) [NeZero p]
    (hp : p.Prime) (hodd : p ≠ 2) (hr : r < p) :
    ∃ i : Fin p, (select p r).value = some i.val ∧
      (BPoly.ofFunction r (weightedModularBlock r p (i.val : ZMod p))).topCoefficient = true ∧
      (∀ j : Fin p, j < i →
        (BPoly.ofFunction r (weightedModularBlock r p (j.val : ZMod p))).topCoefficient = false) ∧
      (select p r).steps ≤ 7*p+6+r*(18*p+13) := by
  obtain ⟨i,hi⟩ := selectWeightedResidue_exists r p hp hodd hr
  have hs := selectWeightedResidue_spec r p i hi
  exact ⟨i,select_value_of_verified p r hr.le i hi,hs.1,hs.2,
    select_steps p r hp.pos hr.le⟩

/-- The complete selected block satisfies the needed semantic properties;
the same computation carries the proved cost bound. -/
theorem selected_block_with_cost (r p m k : Nat) [Fact p.Prime]
    (hodd : p ≠ 2) (hlarge : 2*r < p) (hk : m+2 ≤ k)
    (hthreshold : p ≤ 1+m*(m+1)/2) :
    ∃ i : Fin p, (select p r).value = some i.val ∧
      Robust k (weightedModularBlock r p (i.val : ZMod p)) ∧
      (BPoly.ofFunction r (weightedModularBlock r p (i.val : ZMod p))).topCoefficient = true ∧
      (select p r).steps ≤ 7*p+6+r*(18*p+13) := by
  obtain ⟨i,hi,hrob,hfull⟩ :=
    selectedWeightedResidue_robust_full_degree r p m k hodd hlarge hk hthreshold
  exact ⟨i,select_value_of_verified p r (by omega) i hi,hrob,hfull,
    select_steps p r (Nat.Prime.pos Fact.out) (by omega)⟩

/-- Proposition 5.10's actual least-residue construction, with the proved
subset-sum theorem and a quadratic list-machine cost bound. The modulus is
supplied as the paper's chosen prime; prime search is not charged here. -/
theorem paper_selected_block_quadratic (r : Nat) (hr : 4 ≤ r) :
    ∃ i : Fin (weightedPrime r),
      (select (weightedPrime r) r).value = some i.val ∧
      Robust (weightedTriangleThreshold (weightedPrime r)+2)
        (weightedModularBlock r (weightedPrime r) (i.val : ZMod (weightedPrime r))) ∧
      (BPoly.ofFunction r
        (weightedModularBlock r (weightedPrime r) (i.val : ZMod (weightedPrime r)))).topCoefficient = true ∧
      (∀ j : Fin (weightedPrime r), j < i →
        (BPoly.ofFunction r
          (weightedModularBlock r (weightedPrime r) (j.val : ZMod (weightedPrime r)))).topCoefficient = false) ∧
      (select (weightedPrime r) r).steps ≤ 119*r*r := by
  obtain ⟨hp,hlarge⟩ := weightedPrime_spec r
  let _ : Fact (weightedPrime r).Prime := ⟨hp⟩
  obtain ⟨i,hi,hfull,hmin,_⟩ := select_correct_with_cost (weightedPrime r) r hp (by omega) (by omega)
  exact ⟨i,hi,weightedModularBlock_robust r (weightedPrime r)
    (weightedTriangleThreshold (weightedPrime r)) _ (by omega) hlarge (by omega)
    (weightedTriangleThreshold_spec _) _,hfull,hmin,select_steps_quadratic r (by omega)⟩

end ResidueMachine
end SatLowerBound
