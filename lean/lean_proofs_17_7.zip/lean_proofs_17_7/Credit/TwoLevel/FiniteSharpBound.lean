import Credit.TwoLevel.FullDegreeCounting
import SatLowerBound.BasicLowerBound

/-! The manuscript's finite statement (5), conditional on a robust full-degree
block, including the negative-coefficient case. -/
namespace SatLowerBound

/-- The paper's substitution `M ≥ m - 2^r` is valid for nonnegative
coefficient. If the coefficient is negative, the basic `n - 1` bound
establishes the same conclusion. -/
theorem finite_paper_bound_of_robust_block (w r k : Nat)
    (hw : 2 ≤ w) (hr : r < w) (hk : 2 ≤ k) (hkr : k + 2 ≤ r)
    (g : (Fin r → Bool) → Bool) (hrobust : Robust k g)
    (hfull : (BPoly.ofFunction r g).topCoefficient = true)
    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    7 * (inputBits w : Int) + (30 * (r : Int) - 42 * ((k : Int) + 1)) *
      ((variableCount w : Int) - ((2 ^ r : Nat) : Int)) - 3 ≤ 7 * (C.size : Int) := by
  let a : Int := 30 * (r : Int) - 42 * ((k : Int) + 1)
  let m : Int := variableCount w
  let b : Int := (canonicalForbiddenFamily g).count
  let M : Int := genericRemainingClauses w (canonicalForbiddenFamily g)
  let p : Int := (2 ^ r : Nat)
  have hc' : 7 * (inputBits w : Int) + a * M - 3 ≤ 7 * (C.size : Int) :=
    sat_certificate_of_robust_block w r k hw hr hk hkr g hrobust hfull C hc
  have hb : b ≤ p := by dsimp [b,p]; exact_mod_cast canonical_forbidden_count_le g
  have hfit := (genericRemaining_pos_of_count w r hr (by omega)
    (canonicalForbiddenFamily g) (canonical_forbidden_count_le g)).1
  have hrem : M + b = m := by
    dsimp [M,b,m,genericRemainingClauses]
    exact_mod_cast Nat.sub_add_cancel hfit
  have hp : p + 1 ≤ m := by
    dsimp [p,m,variableCount]
    have hpow : 2 ^ (r + 1) ≤ 2 ^ w := Nat.pow_le_pow_right (by decide) hr
    have hpow0 : 2 ≤ 2 ^ r := Nat.pow_le_pow_right (n := 2) (by decide) (by omega : 1 ≤ r)
    rw [pow_succ] at hpow
    have hnat : 2 ^ r + 1 ≤ 2 ^ w - 1 := by omega
    exact_mod_cast hnat
  change 7 * (inputBits w : Int) + a * (m - p) - 3 ≤ 7 * (C.size : Int)
  by_cases ha : 0 ≤ a
  · have hM : m - p ≤ M := by omega
    have hm := mul_le_mul_of_nonneg_left hM ha
    omega
  · have ha6 : a ≤ -6 := by dsimp [a]; omega
    have hm : 1 ≤ m - p := by omega
    have hneg := mul_le_mul_of_nonneg_right ha6 (show 0 ≤ m - p by omega)
    have hlinear : (inputBits w : Int) ≤ (C.size : Int) + 1 := by
      exact_mod_cast sat_linear_lower_bound w hw C hc
    nlinarith

/-- The finite paper bound obtained from the verified ordered-pair counting
condition, with no supplied block. -/
theorem finite_paper_bound_of_count (w r k : Nat)
    (hw : 2 ≤ w) (hr : r < w) (hk : 2 ≤ k) (hkr : k + 2 ≤ r)
    (hcount : 2 * (3 ^ r * r * r * 6) < 2 ^ (2 ^ (k - 2)))
    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    7 * (inputBits w : Int) + (30 * (r : Int) - 42 * ((k : Int) + 1)) *
      ((variableCount w : Int) - ((2 ^ r : Nat) : Int)) - 3 ≤ 7 * (C.size : Int) := by
  obtain ⟨g,hrobust,hfull⟩ := exists_robust_fullDegree r k (by omega) hcount
  exact finite_paper_bound_of_robust_block w r k hw hr hk hkr g hrobust hfull C hc

end SatLowerBound
