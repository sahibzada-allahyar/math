import Credit.TwoLevel.Passers
import Credit.TwoLevel.Basic

/-! Preservation of the first credited gate's unique nonlinear successor.
The final bridge to the reindexed restricted circuit remains separate. -/
namespace SatLowerBound
namespace OpenCircuit

/-- A retained original gate with a unique nonlinear reader still has exactly
one retained reference, to a nonlinear reader, when that reader is kept. -/
theorem keptIsD_of_kept_gate {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool)
    (hr : C.Reduced) (s : Nat) (hs : n ≤ s) (hD : C.isD s = true)
    (hsKept : C.isKept (fixRes P c) s = true)
    (husers : ∀ k ∈ C.users s, C.isKept (fixRes P c) k = true) :
    C.keptIsD (fixRes P c) s = true := by
  obtain ⟨href, W, g, a, b, hgW, hab, hnl⟩ := (C.isD_iff s).mp hD
  have hWmem : W ∈ C.users s := C.mem_users.mpr ⟨g, a, b, hgW, hab⟩
  have hge := C.refCount_ge s
  have hcard : (C.users s).card = 1 := by
    have hp := Finset.card_pos.mpr ⟨W, hWmem⟩
    omega
  have hout0 : C.outIs s = 0 := by omega
  have huniq : C.users s = {W} := by
    obtain ⟨w, hw⟩ := Finset.card_eq_one.mp hcard
    have he : W = w := by simpa [hw] using hWmem
    simpa [he] using hw
  have hpass := C.gate_passers_of_kept_users P c s hs husers
  have hother : ∀ o, o < n + C.size → o ≠ s →
      (C.resAt (fixRes P c) o).hits s = false := by
    intro o ho hne
    apply Bool.eq_false_iff.mpr
    intro hh
    by_cases hon : o < n
    · have hres : C.resAt (fixRes P c) o = fixRes P c ⟨o, hon⟩ :=
        C.resAt_input (fixRes P c) ⟨o, hon⟩
      rw [hres] at hh
      have he := fixRes_hits P c s ⟨o, hon⟩ hh
      omega
    · exact hne (hpass o (by omega) ho hh)
  have hsres : (C.resAt (fixRes P c) s).hits s = true := by
    rw [C.resAt_kept _ hsKept]
    exact (Res.hits_lit _ _ _).mpr rfl
  have hbW := C.gateAt_bounds hgW
  have hdis : a ≠ b := (C.reduced_gate hr hgW).2.1
  apply C.keptIsD_of_unique_slot (fixRes P c) s W g a b hgW (husers W hWmem) hnl
  · rcases hab with ha | hb
    · have hbne : b ≠ s := by omega
      rw [ha, hsres, hother b (by omega) hbne]
      rfl
    · have hane : a ≠ s := by omega
      rw [hb, hsres, hother a (by omega) hane]
      rfl
  · intro k g' a' b' hkW hk _
    have hane : a' ≠ s := by
      intro he
      have hmem : k ∈ C.users s := C.mem_users.mpr ⟨g', a', b', hk, Or.inl he⟩
      rw [huniq, Finset.mem_singleton] at hmem
      exact hkW hmem
    have hbne : b' ≠ s := by
      intro he
      have hmem : k ∈ C.users s := C.mem_users.mpr ⟨g', a', b', hk, Or.inr he⟩
      rw [huniq, Finset.mem_singleton] at hmem
      exact hkW hmem
    have hbound := C.gateAt_bounds hk
    exact ⟨hother a' (by omega) hane, hother b' (by omega) hbne⟩
  · intro k neg hk
    have hkne : k ≠ s := by
      intro he
      simp [outIs, hk, he] at hout0
    exact hother k (C.outWire_bound hk) hkne

/-- Contrapositive used in the first case of the manuscript's charging lemma:
if a retained credited gate loses its unique nonlinear reader, that reader was
eliminated by the restriction trace. -/
theorem lost_kept_gate_reader {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool)
    (hr : C.Reduced) (s : Nat) (hs : n ≤ s) (hD : C.isD s = true)
    (hsKept : C.isKept (fixRes P c) s = true)
    (hlost : C.keptIsD (fixRes P c) s = false) :
    ∃ k ∈ C.users s, C.isAliased (fixRes P c) k = true := by
  by_contra hnone
  have hall : ∀ k ∈ C.users s, C.isKept (fixRes P c) k = true := by
    intro k hk
    obtain ⟨g, a, b, hgate, -⟩ := C.mem_users.mp hk
    rw [C.isKept_eq_not_isAliased _ hgate]
    cases h : C.isAliased (fixRes P c) k with
    | false => rfl
    | true => exact absurd ⟨k, hk, h⟩ hnone
  have hpres := C.keptIsD_of_kept_gate P c hr s hs hD hsKept hall
  rw [hlost] at hpres
  contradiction

/-- A signal with one reference and a known reader has exactly that reader. -/
theorem users_singleton_of_isD {n : Nat} (C : OpenCircuit n) (s W : Nat)
    (hD : C.isD s = true) (hW : W ∈ C.users s) : C.users s = {W} := by
  have href := ((C.isD_iff s).mp hD).1
  have hge := C.refCount_ge s
  have hcard : (C.users s).card = 1 := by
    have hp := Finset.card_pos.mpr ⟨W, hW⟩
    omega
  obtain ⟨w, hw⟩ := Finset.card_eq_one.mp hcard
  have he : W = w := by simpa [hw] using hW
  simpa [he] using hw

/-- Trace-level preservation of both links in a two-level credit chain. The
statement keeps the original index `W`; it is not yet the reindexed-circuit
D-star preservation theorem. -/
theorem retained_two_credit_links {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool)
    (hr : C.Reduced) (z : Fin n) (hz : P z = false) (W V : Nat)
    (hstar : C.isDStar z.val = true) (hW : W ∈ C.users z.val)
    (hV : V ∈ C.users W)
    (hWkept : C.isKept (fixRes P c) W = true)
    (hVkept : C.isKept (fixRes P c) V = true) :
    C.keptIsD (fixRes P c) z.val = true ∧ C.keptIsD (fixRes P c) W = true := by
  have hDz := C.isD_of_isDStar z.val hstar
  have huz := C.users_singleton_of_isD z.val W hDz hW
  have hDW : C.isD W = true := by
    obtain ⟨_, w, hw, hd⟩ := (C.isDStar_iff z.val).mp hstar
    rw [huz, Finset.mem_singleton] at hw
    simpa [hw] using hd
  have huW := C.users_singleton_of_isD W V hDW hV
  have hWbound : n ≤ W := by
    obtain ⟨g,a,b,hgate,-⟩ := C.mem_users.mp hW
    exact (C.gateAt_bounds hgate).1
  constructor
  · apply C.keptIsD_of_isD P c z hz hDz
    intro k hk
    rw [huz, Finset.mem_singleton] at hk
    simpa [hk] using hWkept
  · apply C.keptIsD_of_kept_gate P c hr W hWbound hDW hWkept
    intro k hk
    rw [huW, Finset.mem_singleton] at hk
    simpa [hk] using hVkept

end OpenCircuit
end SatLowerBound
