import Credit.TwoLevel.MainBToolkit

/-! The manuscript's Roles lemma (b): successors of a gate with two primary
operands have neither credit role. -/
namespace SatLowerBound
namespace MAContext
open OpenCircuit

/-- A gate with two primary operands cannot be a first credit gate. -/
theorem primary_gate_not_first_role {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) {P : Nat} {g : Table} {a d : Nat}
    (hP : C.gateAt P = some (g,a,d)) (ha : a < n) (hd : d < n) :
    C.isDGate P = false := by
  cases hD : C.isDGate P with
  | false => rfl
  | true =>
    obtain ⟨g',a',d',hg',hab⟩ := (C.isDGate_iff P).mp hD
    rw [hP] at hg'
    cases hg'
    have hs := h.dGateSafe P g a d hP ha hd
    rcases hab with h1 | h2
    · rw [hs.1] at h1
      simp at h1
    · rw [hs.2] at h2
      simp at h2

/-- The second credit gate cannot directly follow a gate with two primary
operands: fixing those operands can block the entire two-gate credit chain,
contradicting (E2), exactly as in Roles (b). -/
theorem second_role_no_primary_predecessor {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) {P S : Nat} {g : Table} {a d : Nat}
    (hP : C.gateAt P = some (g,a,d)) (ha : a < n) (hd : d < n)
    (hS : S ∈ C.users P) (z : Fin n) (hz : Essential f z)
    (W : Nat) (hstar : C.isDStar z.val = true)
    (hW : W ∈ C.users z.val) (hSW : S ∈ C.users W) : False := by
  have hDz := C.isD_of_isDStar z.val hstar
  have huz := C.users_singleton_of_isD z.val W hDz hW
  have hDW : C.isD W = true := by
    obtain ⟨_,w,hw,hdw⟩ := (C.isDStar_iff z.val).mp hstar
    rw [huz, Finset.mem_singleton] at hw
    simpa [hw] using hdw
  have huW := C.users_singleton_of_isD W S hDW hSW
  have hWneP : W ≠ P := by
    intro he
    obtain ⟨gW,aW,dW,hgW,habW⟩ := C.mem_users.mp hW
    rw [he,hP] at hgW
    cases hgW
    have hDP : C.isDGate P = true := by
      apply (C.isDGate_iff P).mpr
      refine ⟨g,a,d,hP,?_⟩
      rcases habW with he' | he'
      · exact Or.inl ⟨by rw [he']; exact z.isLt, by rw [he']; exact hDz⟩
      · exact Or.inr ⟨by rw [he']; exact z.isLt, by rw [he']; exact hDz⟩
    rw [h.primary_gate_not_first_role hP ha hd] at hDP
    contradiction
  let x : Fin n := ⟨a,ha⟩
  let y : Fin n := ⟨d,hd⟩
  have had : a ≠ d := (h.gate_facts hP).2.1
  have hxy : x ≠ y := fun he => had (congrArg Fin.val he)
  have hzx : z ≠ x := by
    intro he
    have hm : P ∈ C.users z.val := C.mem_users.mpr ⟨g,a,d,hP,Or.inl (by rw [he])⟩
    rw [huz, Finset.mem_singleton] at hm
    exact hWneP hm.symm
  have hzy : z ≠ y := by
    intro he
    have hm : P ∈ C.users z.val := C.mem_users.mpr ⟨g,a,d,hP,Or.inr (by rw [he])⟩
    rw [huz, Finset.mem_singleton] at hm
    exact hWneP hm.symm
  obtain ⟨gs,as,ds,hgate,hPS⟩ := C.mem_users.mp hS
  obtain ⟨gs',as',ds',hgate',hWS⟩ := C.mem_users.mp hSW
  rw [hgate] at hgate'
  cases hgate'
  have hnl : gs.nonlinear = true := by
    have hh := C.nonlinear_of_D_reader W S hDW hSW
    simpa [tableAt, hgate] using hh
  have hblocking : ∃ γ value : Bool, ∀ v,
      C.valueAt v P = γ → C.valueAt v S = value := by
    rcases hPS with hp | hp
    · obtain ⟨γ,hγ,_⟩ := gs.nonlinear_exists_blocksLeft hnl
      refine ⟨γ,gs.eval γ false,?_⟩
      intro v hv
      rw [C.valueAt_gate _ hgate, hp, hv, gs.blocksLeft_eval γ hγ]
    · obtain ⟨γ,hγ,_⟩ := gs.nonlinear_exists_blocksRight hnl
      refine ⟨γ,gs.eval false γ,?_⟩
      intro v hv
      rw [C.valueAt_gate _ hgate, hp, hv, gs.blocksRight_eval γ hγ]
  obtain ⟨γ,value,hblock⟩ := hblocking
  obtain ⟨α,β,hg⟩ := g.essential_attains (h.gate_facts hP).1 γ
  have hPvalue : ∀ v, C.valueAt (setPair v x y α β) P = γ := by
    intro v
    rw [C.valueAt_gate _ hP]
    change g.eval (C.valueAt (setPair v x y α β) x.val)
      (C.valueAt (setPair v x y α β) y.val) = γ
    rw [C.valueAt_input, C.valueAt_input, setPair_left, setPair_right _ _ _ _ _ hxy, hg]
  have houtz := C.reduced_outIs_zero_of_user h.reduced z.val (Finset.ne_empty_of_mem hW)
  have houtW := C.reduced_outIs_zero_of_user h.reduced W (Finset.ne_empty_of_mem hSW)
  have hout : ∀ k neg, C.outWire = some (k,neg) → k ≠ z.val ∧ k ≠ W := by
    intro k neg hk
    constructor <;> intro he
    · simp [outIs, hk, he] at houtz
    · simp [outIs, hk, he] at houtW
  obtain ⟨u,v,huv,hne⟩ := h.good.e2 x y α β z hxy hzx hzy hz
  apply hne
  have hin : ∀ q, q ≠ z → setPair u x y α β q = setPair v x y α β q := by
    intro q hq
    simp [setPair, huv q hq]
  have hzg : ∀ k ∈ C.users z.val, k = W := by intro k hk; simpa [huz] using hk
  have hWg : ∀ k ∈ C.users W, k = S := by intro k hk; simpa [huW] using hk
  have hSval : C.valueAt (setPair u x y α β) S = C.valueAt (setPair v x y α β) S := by
    rw [hblock _ (hPvalue u), hblock _ (hPvalue v)]
  have heval := C.eval_eq_of_chain_cut z W S (setPair u x y α β) (setPair v x y α β)
    hin hzg hWg hSval hout
  simpa only [h.computes] using heval

/-- Roles (b): every successor of a gate with two primary operands has
neither the first nor the second credit role. -/
theorem primary_successor_no_role {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) {P S : Nat} {g : Table} {a d : Nat}
    (hP : C.gateAt P = some (g,a,d)) (ha : a < n) (hd : d < n)
    (hS : S ∈ C.users P) (W V : Fin n → Nat)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z)) :
    (∀ z, C.isD z.val = true → W z ≠ S) ∧
    (∀ z, C.isDStar z.val = true → V z ≠ S) := by
  constructor
  · intro z hz he
    have hzread : S ∈ C.users z.val := by simpa [he] using hw z hz
    obtain ⟨gS,aS,dS,hgS,habS⟩ := C.mem_users.mp hzread
    have hD : C.isDGate S = true := by
      apply (C.isDGate_iff S).mpr
      refine ⟨gS,aS,dS,hgS,?_⟩
      rcases habS with he' | he'
      · exact Or.inl ⟨by rw [he']; exact z.isLt, by rw [he']; exact hz⟩
      · exact Or.inr ⟨by rw [he']; exact z.isLt, by rw [he']; exact hz⟩
    rw [h.not_dGate_of_primary_pred hP ha hd hS] at hD
    contradiction
  · intro z hz he
    have hDz := C.isD_of_isDStar z.val hz
    have hcount := ((C.isD_iff z.val).mp hDz).1
    have hess : Essential f z := h.usedEssential z (by rw [C.usage_singleUse]; omega)
    have hSV : S ∈ C.users (W z) := by simpa [he] using hv z hz
    exact h.second_role_no_primary_predecessor hP ha hd hS z hess (W z) hz (hw z hDz) hSV

/-- The 14-unit case analysis can designate eliminated nonlinear direct
readers and successors of two-primary-input gates as role-free. -/
theorem twoLevel_single_drop_with_primary_successors {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x : Fin n) (b : Bool)
    (h2 : 2 ≤ C.refCount x.val) (E : Finset Nat)
    (hE : ∀ k ∈ E, C.isAliased (singleRes x b) k = true ∧
      (C.tableAt k).parity = false ∧
      (k ∈ C.users x.val ∨ ∃ P g a d, C.gateAt P = some (g,a,d) ∧
        a < n ∧ d < n ∧ k ∈ C.users P)) :
    (C.restrict (singleSubst x b)).psi2 +
      3 * (C.aliasedCount (singleRes x b) : Int) +
      4 * (C.aliasedParityCount (singleRes x b) : Int) +
      (E.card : Int) + C.credit2Gained (C.restrict (singleSubst x b)) ≤ C.psi2 := by
  obtain ⟨W,V,hW,hV⟩ := h.twoLevel_readers
  obtain ⟨hfree,horig,hess⟩ := h.twoLevel_single_assumptions x b h2
  have hsub : E ⊆ Finset.range (n + C.size) := by
    intro k hk
    have halias := (hE k hk).1
    cases hg : C.gateAt k with
    | none => simp [OpenCircuit.isAliased, hg] at halias
    | some p =>
      obtain ⟨g,a,d⟩ := p
      exact Finset.mem_range.mpr (C.gateAt_bounds hg).2.1
  have hroles : ∀ k ∈ E, C.isAliased (fixRes (fun z => decide (z = x)) (fun _ => b)) k = true ∧
      (C.tableAt k).parity = false ∧
      (∀ z, C.isD z.val = true → W z ≠ k) ∧
      (∀ z, C.isDStar z.val = true → V z ≠ k) := by
    intro k hk
    obtain ⟨halias,hpar,hkind⟩ := hE k hk
    have hrole : (∀ z, C.isD z.val = true → W z ≠ k) ∧
        (∀ z, C.isDStar z.val = true → V z ≠ k) := by
      rcases hkind with hreader | ⟨P,g,a,d,hP,ha,hd,hS⟩
      · exact h.twoLevel_reader_no_role x h2 W V hW hV horig k hreader
      · exact h.primary_successor_no_role hP ha hd hS W V hW hV
    exact ⟨halias,hpar,hrole.1,hrole.2⟩
  have hd := C.psi2_free_drop_with_uncharged (fun z => decide (z = x)) (fun _ => b)
    h.reduced h.dGateSafe f h.computes h.good.e1 W V hfree hW hV
    (by simpa [← singleSubst_eq_fixSubst] using hess) horig E hsub hroles
  simpa [← singleSubst_eq_fixSubst, singleRes] using hd

end MAContext
end SatLowerBound
