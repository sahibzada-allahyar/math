import Credit.TwoLevel.Robust
import Credit.ResLemmas

/-! The cofactor argument in the "Corner exclusion" paragraph of Main Lemma B.
The circuit-to-factorization step still has to be proved separately. -/

namespace SatLowerBound

/-- If all pair cofactors factor through a two-bit state, S4 forces that state map
 to take all four possible values. -/
theorem FourRows.state_surjective {α : Type} {f : Bool → Bool → α → Bool}
    (hf : FourRows f) (state : Bool × Bool → Bool × Bool)
    (decode : (Bool × Bool) → α → Bool)
    (hfactor : ∀ p x, PairRow f p x = decode (state p) x) :
    Function.Surjective state := by
  apply (Finite.injective_iff_surjective).mp
  intro p q hpq
  apply hf
  funext x
  rw [hfactor, hfactor, hpq]

/-- In the corner configuration, the constant output of the first gate on one
half and the constant output of the second on the other half produce a repeated
state. The two nonconstant halves must each attain the corresponding constant. -/
theorem corner_state_not_injective (T U : Bool → Bool → Bool)
    (ε cT cU : Bool)
    (ht : ∀ y, T ε y = cT)
    (hu : ∀ y, U (!ε) y = cU)
    (ht_hit : ∃ y, T (!ε) y = cT)
    (hu_hit : ∃ y, U ε y = cU) :
    ¬ Function.Injective (fun p : Bool × Bool => (T p.1 p.2, U p.1 p.2)) := by
  obtain ⟨yT, hyT⟩ := ht_hit
  obtain ⟨yU, hyU⟩ := hu_hit
  intro hinj
  have he : (ε, yU) = (!ε, yT) := hinj (by simp [ht, hu, hyT, hyU])
  have hfirst := congrArg Prod.fst he
  cases ε <;> simp_all

/-- A nonblocking row of a Boolean gate attains both Boolean values. -/
theorem Table.nonblocking_row_attains (g : Table) (a v : Bool)
    (h : g.blocksLeft a = false) : ∃ b, g.eval a b = v := by
  revert a v
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

/-- The two nonlinear gate tables in the corner have a repeated joint state
when their blocking values for the common input are opposite. -/
theorem opposite_blocking_gate_state_not_injective (T U : Table) (ε : Bool)
    (hT : T.nonlinear = true) (hU : U.nonlinear = true)
    (hTb : T.blocksLeft ε = true) (hUb : U.blocksLeft (!ε) = true) :
    ¬ Function.Injective (fun p : Bool × Bool => (T.eval p.1 p.2, U.eval p.1 p.2)) := by
  have hTnb : T.blocksLeft (!ε) = false := by
    have h := T.nonlinear_blocksLeft hT
    cases ε <;> simp_all
  have hUnb : U.blocksLeft ε = false := by
    have h := U.nonlinear_blocksLeft hU
    cases ε <;> simp_all
  apply corner_state_not_injective T.eval U.eval ε (T.eval ε false) (U.eval (!ε) false)
  · exact fun y => T.blocksLeft_eval ε hTb y
  · exact fun y => U.blocksLeft_eval (!ε) hUb y
  · exact T.nonblocking_row_attains (!ε) (T.eval ε false) hTnb
  · exact U.nonblocking_row_attains ε (U.eval (!ε) false) hUnb

/-- Exact cofactor conclusion of the manuscript's corner exclusion, conditional
only on the circuit-specific factorization and the displayed gate properties. -/
theorem FourRows.no_corner_factor {α : Type} {f : Bool → Bool → α → Bool}
    (hf : FourRows f) (T U : Bool → Bool → Bool) (ε cT cU : Bool)
    (ht : ∀ y, T ε y = cT) (hu : ∀ y, U (!ε) y = cU)
    (ht_hit : ∃ y, T (!ε) y = cT) (hu_hit : ∃ y, U ε y = cU)
    (decode : (Bool × Bool) → α → Bool)
    (hfactor : ∀ p x, PairRow f p x = decode (T p.1 p.2, U p.1 p.2) x) : False := by
  have hsurj := hf.state_surjective (fun p => (T p.1 p.2, U p.1 p.2)) decode hfactor
  have hinj := (Finite.injective_iff_surjective).mpr hsurj
  exact corner_state_not_injective T U ε cT cU ht hu ht_hit hu_hit hinj

/-- S4 rules out the opposite-blocking corner once the circuit factorization
through the two gates has been established. -/
theorem FourRows.no_opposite_blocking_factor {α : Type} {f : Bool → Bool → α → Bool}
    (hf : FourRows f) (T U : Table) (ε : Bool)
    (hT : T.nonlinear = true) (hU : U.nonlinear = true)
    (hTb : T.blocksLeft ε = true) (hUb : U.blocksLeft (!ε) = true)
    (decode : (Bool × Bool) → α → Bool)
    (hfactor : ∀ p x, PairRow f p x = decode (T.eval p.1 p.2, U.eval p.1 p.2) x) : False := by
  have hsurj := hf.state_surjective (fun p => (T.eval p.1 p.2, U.eval p.1 p.2)) decode hfactor
  exact opposite_blocking_gate_state_not_injective T U ε hT hU hTb hUb
    ((Finite.injective_iff_surjective).mpr hsurj)

end SatLowerBound
