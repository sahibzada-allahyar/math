import Credit.TwoLevel.BadOverlap

/-! The surviving dead gate in the final pruning branch of Main Lemma B. -/
namespace SatLowerBound
namespace MAContext
open OpenCircuit

/-- Under the no-drop hypothesis the paper's final restriction eliminates
`T,U,R` in the trace, while `V` survives as a dead gate in the reindexed
restricted circuit. This theorem does not yet count the later pruning step. -/
theorem no_drop_forces_dead_gate_after_three_eliminations {n : Nat}
    {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (hS4 : S4Essential f) {t : Table} {i j : Fin n}
    {rest : OpenCircuit (n+1)} (hC : C = .gate t i j rest) (hnl : t.nonlinear = true)
    (hno : ∀ x, (x = i ∨ x = j) → ∀ b,
      ¬ ((C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2)) :
    ∃ (U V R : Nat) (b : Bool), C.users i.val = {n,U} ∧ C.users j.val = {n,V} ∧
      C.users n = {R} ∧ C.users U = {R} ∧ C.users V = {U} ∧
      (C.resAt (singleRes i b) U).isConst = true ∧
      (C.tableAt U).parity = false ∧ (C.tableAt R).parity = false ∧
      C.isAliased (singleRes i b) n = true ∧ C.isAliased (singleRes i b) U = true ∧
      C.isAliased (singleRes i b) R = true ∧ C.isKept (singleRes i b) V = true ∧
      ∃ k g a d, (C.restrict (singleSubst i b)).gateAt k = some (g,a,d) ∧
        (C.restrict (singleSubst i b)).refCount k = 0 := by
  obtain ⟨U,V,R,ε,hUV,hUn,hVn,hUi,hVj,hR,hUR,hVU,hε,hTc,hUnc,hRnc,
    hUpar,hRpar,hUbad,_⟩ := h.no_drop_forces_pruning_chain hS4 hC hnl hno
  obtain ⟨b,S,hS,hUc,hTnc,hSnc,hSpar⟩ := hUbad
  have hSR : S = R := by
    rw [hUR] at hS
    exact (by simpa using hS : R = S).symm
  have hU : U ∈ C.users i.val := by rw [hUi]; simp
  have hV : V ∈ C.users j.val := by rw [hVj]; simp
  have hRuser : R ∈ C.users U := by rw [hUR]; simp
  have hUuser : U ∈ C.users V := by rw [hVU]; simp
  have hT : C.gateAt n = some (t,i.val,j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hTi : n ∈ C.users i.val := C.mem_users.mpr ⟨t,i.val,j.val,hT,Or.inl rfl⟩
  obtain ⟨gV,aV,dV,hgV,_⟩ := C.mem_users.mp hV
  obtain ⟨gU,aU,dU,hgU,habU⟩ := C.mem_users.mp hUuser
  obtain ⟨gR,aR,dR,hgR,habR⟩ := C.mem_users.mp hRuser
  have hVUgt : V < U := by
    have hb := C.gateAt_bounds hgU
    rcases habU with he | he <;> omega
  have hURgt : U < R := by
    have hb := C.gateAt_bounds hgR
    rcases habR with he | he <;> omega
  have hVge := (C.gateAt_bounds hgV).1
  have halias : ∀ k ∈ C.users i.val, C.isAliased (singleRes i b) k = true := by
    intro k hk
    obtain ⟨g,a,d,hg,had⟩ := C.mem_users.mp hk
    apply C.isAliased_of_const _ hg
    have hinput : C.resAt (singleRes i b) i.val = .const b := by
      rw [C.resAt_single_input i b i]
      simp
    rcases had with ha | hd
    · left; rw [ha,hinput]; rfl
    · right; rw [hd,hinput]; rfl
  have hRa : C.isAliased (singleRes i b) R = true := by
    apply C.isAliased_of_const _ hgR
    rcases habR with ha | hd
    · left; rw [ha]; exact hUc
    · right; rw [hd]; exact hUc
  have hVnot : C.isAliased (singleRes i b) V = false := by
    apply Bool.eq_false_iff.mpr
    intro hVa
    have h4 : (C.restrict (singleSubst i b)).psi2 + 14 ≤ C.psi2 := by
      refine h.four_eliminated_two_readers_drop i b (by
        have := (h.degrees_of_nonlinear hC hnl).1; omega) {n,U,R,V} ?_ ?_
        n U (Ne.symm hUn) (by simp) (by simp) hTi hU
      · have hnR : n ≠ R := by omega
        have hUV' : U ≠ V := by omega
        have hRV : R ≠ V := by omega
        have hUR' : U ≠ R := by omega
        simp [Ne.symm hUn, hnR, Ne.symm hVn, hUR', hUV', hRV]
      · intro k hk
        simp only [Finset.mem_insert, Finset.mem_singleton] at hk
        rcases hk with he | he | he | he
        · simpa [he] using halias n hTi
        · simpa [he] using halias U hU
        · simpa [he] using hRa
        · simpa [he] using hVa
    exact hno i (Or.inl rfl) b h4
  have hVkept : C.isKept (singleRes i b) V = true := by
    rw [C.isKept_eq_not_isAliased _ hgV, hVnot]
    rfl
  obtain ⟨k,g,a,d,hgate,hdead⟩ := C.single_kept_gate_dead_of_unique_constant_successor
    h.reduced i b V U gV aV dV hgV hVkept hVU hUc
  exact ⟨U,V,R,b,hUi,hVj,hR,hUR,hVU,hUc,hUpar,hRpar,halias n hTi,halias U hU,hRa,hVkept,
    k,g,a,d,hgate,hdead⟩

end MAContext
end SatLowerBound
