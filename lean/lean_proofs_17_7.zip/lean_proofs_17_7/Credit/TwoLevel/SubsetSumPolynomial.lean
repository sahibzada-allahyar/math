import Credit.TwoLevel.SignedTuples
import Mathlib.Combinatorics.Nullstellensatz

/-! Vanishing polynomial in the cited signed-subset-sum argument. -/
namespace SatLowerBound
open MvPolynomial

/-- Pairs of distinct variables, counted in increasing order. -/
def variablePairs (d : Nat) : Finset (Fin d × Fin d) :=
  (Finset.univ.product Finset.univ).filter (fun p => p.1 < p.2)

/-- The product vanishes when two entries agree up to sign. -/
noncomputable def signedVandermonde (R : Type) [CommRing R] (d : Nat) : MvPolynomial (Fin d) R :=
  ∏ p ∈ variablePairs d, (X p.1 - X p.2) * (X p.1 + X p.2)

/-- The second factor vanishes when the coordinate sum belongs to `C`. -/
noncomputable def signedSumAvoidingPolynomial (R : Type) [CommRing R] (d : Nat)
    (C : Finset R) : MvPolynomial (Fin d) R :=
  signedVandermonde R d * ∏ c ∈ C, ((∑ i : Fin d, X i) - MvPolynomial.C c)

/-- A nonvanishing signed Vandermonde forces distinctness up to sign. -/
theorem signedVandermonde_separated {R : Type} [Field R] {d : Nat} (x : Fin d → R)
    (h : eval x (signedVandermonde R d) ≠ 0) :
    ∀ i j, i ≠ j → x i ≠ x j ∧ x i ≠ -x j := by
  classical
  have hp : ∀ i j, i < j → (x i - x j) * (x i + x j) ≠ 0 := by
    intro i j hij
    have hmem : (i,j) ∈ variablePairs d := by simp [variablePairs,hij]
    have hprod : (∏ p ∈ variablePairs d, (x p.1 - x p.2) * (x p.1 + x p.2)) ≠ 0 := by
      simpa [signedVandermonde] using h
    exact (Finset.prod_ne_zero_iff.mp hprod) (i,j) hmem
  intro i j hij
  rcases lt_or_gt_of_ne hij with hij | hji
  · have hpair := hp i j hij
    constructor
    · intro he; apply hpair; simp [he]
    · intro he; apply hpair; simp [he]
  · have hpair := hp j i hji
    constructor
    · intro he; apply hpair; simp [he]
    · intro he
      apply hpair
      have hh : x j = -x i := by rw [he,neg_neg]
      simp [hh]

/-- If each allowed coordinate value is a signed weight, the polynomial
formed using all restricted sums vanishes throughout the Cartesian grid. -/
theorem signedSumAvoidingPolynomial_vanishes {R : Type} [Field R] [DecidableEq R] [Fintype R]
    {d : Nat} (a : Fin d → R) (domains : Fin d → Finset R)
    (hdom : ∀ i x, x ∈ domains i → ∃ j, x = a j ∨ x = -a j)
    (x : Fin d → R) (hx : ∀ i, x i ∈ domains i) :
    eval x (signedSumAvoidingPolynomial R d (signedRestrictedSums a domains)) = 0 := by
  classical
  by_cases hV : eval x (signedVandermonde R d) = 0
  · simp [signedSumAvoidingPolynomial,hV]
  · have hsep := signedVandermonde_separated x hV
    have hmem : (∑ i, x i) ∈ signedRestrictedSums a domains := by
      apply Finset.mem_image.mpr
      refine ⟨x,?_,rfl⟩
      apply Finset.mem_filter.mpr
      exact ⟨Finset.mem_univ x, hx, (fun i => hdom i (x i) (hx i)),hsep⟩
    have hzero : (∏ c ∈ signedRestrictedSums a domains, ((∑ i, x i) - c)) = 0 := by
      apply Finset.prod_eq_zero hmem
      simp
    simp [signedSumAvoidingPolynomial,hzero]

/-- Consequently, the combinatorial Nullstellensatz rules out a nonzero top
coefficient of the vanishing polynomial under the stated grid-size hypotheses.
The paper supplies the separate coefficient/determinant calculation. -/
theorem signedSumAvoidingPolynomial_coefficient_zero {R : Type} [Field R] [DecidableEq R] [Fintype R]
    {d : Nat} (a : Fin d → R) (domains : Fin d → Finset R)
    (hdom : ∀ i x, x ∈ domains i → ∃ j, x = a j ∨ x = -a j)
    (t : Fin d →₀ Nat)
    (hdegree : (signedSumAvoidingPolynomial R d (signedRestrictedSums a domains)).totalDegree ≤ t.degree)
    (hsize : ∀ i, t i < (domains i).card) :
    (signedSumAvoidingPolynomial R d (signedRestrictedSums a domains)).coeff t = 0 := by
  classical
  by_contra hcoef
  have heq : (signedSumAvoidingPolynomial R d (signedRestrictedSums a domains)).totalDegree = t.degree :=
    le_antisymm hdegree (MvPolynomial.le_totalDegree (MvPolynomial.mem_support_iff.mpr hcoef))
  obtain ⟨x,hx,hnonzero⟩ := combinatorial_nullstellensatz_exists_eval_nonzero
    _ t hcoef heq domains hsize
  exact hnonzero (signedSumAvoidingPolynomial_vanishes a domains hdom x hx)

end SatLowerBound
