import Credit.TwoLevel.GeneralCompositionDegree
import Credit.TwoLevel.ManuscriptConditions
import Credit.TwoLevel.ConstantRoles
import Credit.TwoLevel.WeightedPrimeMachine
import Credit.TwoLevel.WeightedListMachine
import Credit.TwoLevel.ManuscriptComposition
import Credit.TwoLevel.ManuscriptTheorem
import Credit.TwoLevel.WeightedGraphBound
import Credit.TwoLevel.WeightedResidueSelection
import Credit.TwoLevel.WeightedResidueTable
import Credit.TwoLevel.WeightedUnconditional
import Credit.TwoLevel.BalandraudFiniteSet
import Credit.TwoLevel.BalandraudBound
import Credit.TwoLevel.BalandraudClosedStep
import Credit.TwoLevel.BalandraudNormalizedRecurrence
import Credit.TwoLevel.BalandraudProductRatio
import Credit.TwoLevel.BalandraudProducts
import Credit.TwoLevel.BalandraudRecurrence
import Credit.TwoLevel.BalandraudGap
import Credit.TwoLevel.BalandraudDetNonzero
import Credit.TwoLevel.BalandraudDomains
import Credit.TwoLevel.SubsetSumMultinomial
import Credit.TwoLevel.Correspondence
import Credit.TwoLevel.Robust
import Credit.TwoLevel.RobustRestrictions
import Credit.TwoLevel.CornerCircuit
import Credit.TwoLevel.Cut
import Credit.TwoLevel.Accounting
import Credit.TwoLevel.Passers
import Credit.TwoLevel.Preserve
import Credit.TwoLevel.Terminal
import Credit.TwoLevel.KeptGate
import Credit.TwoLevel.KeptReaders
import Credit.TwoLevel.PreserveFull
import Credit.TwoLevel.Eliminated
import Credit.TwoLevel.Ledger
import Credit.TwoLevel.Roles
import Credit.TwoLevel.ChargeCap
import Credit.TwoLevel.TwoChain
import Credit.TwoLevel.Aggregate
import Credit.TwoLevel.ParityDrop
import Credit.TwoLevel.Uncharged
import Credit.TwoLevel.MainBParity
import Credit.TwoLevel.MainBNonlinearDeg
import Credit.TwoLevel.MainBNonlinearTwo
import Credit.TwoLevel.PrimarySuccessor
import Credit.TwoLevel.GainedChain
import Credit.TwoLevel.TightGain
import Credit.TwoLevel.TightDistinctB
import Credit.TwoLevel.DeadGate
import Credit.TwoLevel.OppositeChain
import Credit.TwoLevel.MainBReduction
import Credit.TwoLevel.TightCorner
import Credit.TwoLevel.BadReaders
import Credit.TwoLevel.BadOverlap
import Credit.TwoLevel.PruningBranch
import Credit.TwoLevel.PruningRoles
import Credit.TwoLevel.CofactorRoles
import Credit.TwoLevel.DeleteDead
import Credit.TwoLevel.DeadRolesGeneral
import Credit.TwoLevel.TriangleWeight
import Credit.TwoLevel.TriangleStructure
import Credit.TwoLevel.NormalizeTriangle
import Credit.TwoLevel.MainBNormalized
import Credit.TwoLevel.RobustIteration
import Credit.TwoLevel.CompositionCofactors
import Credit.TwoLevel.RobustOn
import Credit.TwoLevel.RetirementAccounting
import Credit.TwoLevel.RobustContext
import Credit.TwoLevel.RobustComposition
import Credit.TwoLevel.RobustDegree
import Credit.TwoLevel.GenericSatTransfer
import Credit.TwoLevel.EmbeddedRobust
import Credit.TwoLevel.GenericCertificate
import Credit.TwoLevel.ConcreteCertificate
import Credit.TwoLevel.CollisionCounting
import Credit.TwoLevel.CofactorSubcube
import Credit.TwoLevel.RobustCounting
import Credit.TwoLevel.FullDegreeCounting
import Credit.TwoLevel.CountingParameters
import Credit.TwoLevel.WidthBound
import Credit.TwoLevel.FiniteSharpBound
import Credit.TwoLevel.ExactCounting
import Credit.TwoLevel.WeightedModularRows
import Credit.TwoLevel.WeightedSubsetSums
import Credit.TwoLevel.WeightedDegree
import Credit.TwoLevel.WeightedResidueAlgorithm
import Credit.TwoLevel.WeightedParameters
import Credit.TwoLevel.WeightedCertificate
import Credit.TwoLevel.SubsetSumNoWrap
import Credit.TwoLevel.AsymptoticFidelity
import Credit.TwoLevel.ManuscriptElimination
import Credit.TwoLevel.OrderedNetwork
import Credit.TwoLevel.TopologicalOrder
import Credit.TwoLevel.NetworkSemantics
import Credit.TwoLevel.SignedSubsetSums
import Credit.TwoLevel.SignedTuples
import Credit.TwoLevel.SubsetSumPolynomial
import Credit.TwoLevel.SubsetSumDegree
import Credit.TwoLevel.SubsetSumLeading
import Credit.TwoLevel.SignedVandermondeDet
import Lean

#print axioms SatLowerBound.OpenCircuit.isDStar_iff_paperDStar_of_reduced
#print axioms SatLowerBound.OpenCircuit.size_bound_of_potential

open Lean Elab Command in
run_cmd do
  let allowed : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]
  for name in [``SatLowerBound.OpenCircuit.isDStar_iff_paperDStar_of_reduced,
               ``SatLowerBound.OpenCircuit.size_bound_of_potential,
               ``SatLowerBound.Robust.restricted_essential,
               ``SatLowerBound.Robust.e1,
               ``SatLowerBound.Robust.e2,
               ``SatLowerBound.S4.toEssential,
               ``SatLowerBound.essential_of_partial_is_free,
               ``SatLowerBound.Robust.restricted_s4Essential,
               ``SatLowerBound.Robust.restricted_e1,
               ``SatLowerBound.Robust.restricted_e2,
               ``SatLowerBound.Robust.restricted_goodFn,
               ``SatLowerBound.Robust.s4,
               ``SatLowerBound.S4.s3,
               ``SatLowerBound.FourRows.no_opposite_blocking_factor,
               ``SatLowerBound.OpenCircuit.no_opposite_blocking_consecutive,
               ``SatLowerBound.OpenCircuit.no_opposite_blocking_two_gate_cut_reduced,
               ``SatLowerBound.OpenCircuit.no_opposite_blocking_oriented_reduced,
               ``SatLowerBound.OpenCircuit.psi2_restriction_gain_loss,
               ``SatLowerBound.OpenCircuit.gate_passers_of_kept_users,
               ``SatLowerBound.OpenCircuit.lost_kept_gate_reader,
               ``SatLowerBound.OpenCircuit.retained_two_credit_links,
               ``SatLowerBound.OpenCircuit.psi2_nonnegative,
               ``SatLowerBound.OpenCircuit.fix_kept_gate_exists,
               ``SatLowerBound.OpenCircuit.fix_kept_reader_status,
               ``SatLowerBound.OpenCircuit.retained_DStar_survives,
               ``SatLowerBound.OpenCircuit.lost_DStar_with_first_gate_kept,
               ``SatLowerBound.OpenCircuit.fixed_input_credit_removed,
               ``SatLowerBound.OpenCircuit.first_credit_survives_eliminated_first_gate,
               ``SatLowerBound.OpenCircuit.lost_both_credits_eliminates_second,
               ``SatLowerBound.OpenCircuit.free_two_credit_loss_le_eliminated,
               ``SatLowerBound.OpenCircuit.free_credit_losses_le_chain_eliminations,
               ``SatLowerBound.OpenCircuit.free_second_charge_bound,
               ``SatLowerBound.OpenCircuit.credit2Lost_eq_allocated,
               ``SatLowerBound.OpenCircuit.first_role_card_le_one,
               ``SatLowerBound.OpenCircuit.second_role_card_le_two,
               ``SatLowerBound.OpenCircuit.gateFirstCharge_le_one,
               ``SatLowerBound.OpenCircuit.gateSecondCharge_le_two,
               ``SatLowerBound.OpenCircuit.second_role_has_no_primary,
               ``SatLowerBound.OpenCircuit.free_gate_total_charge_le_two,
               ``SatLowerBound.OpenCircuit.shared_second_gate_isKept,
               ``SatLowerBound.OpenCircuit.free_eliminated_gate_total_charge_le_one,
               ``SatLowerBound.OpenCircuit.psi2_free_restriction_drop,
               ``SatLowerBound.OpenCircuit.psi2_free_drop_full_parity,
               ``SatLowerBound.OpenCircuit.free_loss_add_parity_uncharged_le_aliased,
               ``SatLowerBound.OpenCircuit.psi2_free_drop_with_uncharged,
               ``SatLowerBound.MAContext.twoLevel_single_drop,
               ``SatLowerBound.MAContext.case_all_parity,
               ``SatLowerBound.MAContext.case_two_parity,
               ``SatLowerBound.MAContext.twoLevel_reader_no_role,
               ``SatLowerBound.MAContext.twoLevel_single_drop_with_readers,
               ``SatLowerBound.MAContext.case_parity_nonlinear,
               ``SatLowerBound.MAContext.case_parity_first,
               ``SatLowerBound.MAContext.case_nonlinear_three_twoLevel,
               ``SatLowerBound.MAContext.case_blocked_with_parity_twoLevel,
               ``SatLowerBound.MAContext.case_nonlinear_parity_twoLevel,
               ``SatLowerBound.MAContext.four_eliminated_two_readers_drop,
               ``SatLowerBound.MAContext.case_blocked_two_successors_twoLevel,
               ``SatLowerBound.MAContext.case_both_constant_twoLevel,
               ``SatLowerBound.MAContext.case_successor_constant_twoLevel,
               ``SatLowerBound.MAContext.second_role_no_primary_predecessor,
               ``SatLowerBound.MAContext.primary_successor_no_role,
               ``SatLowerBound.MAContext.twoLevel_single_drop_with_primary_successors,
               ``SatLowerBound.OpenCircuit.fix_gain_two_of_kept_chain,
               ``SatLowerBound.MAContext.tight_drop_of_three_rolefree_and_two_gains,
               ``SatLowerBound.MAContext.tight_surviving_chain_gain,
               ``SatLowerBound.MAContext.tight_surviving_chain_drop,
               ``SatLowerBound.MAContext.tight_distinct_chain_or_four,
               ``SatLowerBound.OpenCircuit.gate_keptRefs_eq_zero_of_users_const,
               ``SatLowerBound.OpenCircuit.single_kept_gate_dead_of_unique_constant_successor,
               ``SatLowerBound.OpenCircuit.single_unique_constant_successor_smaller,
               ``SatLowerBound.Table.opposite_bad_chain_constant,
               ``SatLowerBound.MAContext.opposite_bad_funnel_impossible,
               ``SatLowerBound.MAContext.opposite_bad_wiring_impossible,
               ``SatLowerBound.MAContext.nonlinear_no_drop_reduces_to_tight,
               ``SatLowerBound.MAContext.nonlinear_no_drop_tight_corner_distinct,
               ``SatLowerBound.MAContext.nonlinear_reader_bad_of_no_drop,
               ``SatLowerBound.MAContext.no_drop_forces_both_bad,
               ``SatLowerBound.MAContext.tight_no_drop_forces_second_overlap,
               ``SatLowerBound.MAContext.no_drop_forces_bad_overlap,
               ``SatLowerBound.MAContext.no_drop_V_second_eq_R_forces_U_second_eq_V,
               ``SatLowerBound.MAContext.no_drop_forces_final_bad_overlaps,
               ``SatLowerBound.MAContext.final_opposite_overlap_impossible,
               ``SatLowerBound.MAContext.no_drop_forces_pruning_overlap,
               ``SatLowerBound.MAContext.pruning_overlap_U_successor_is_R,
               ``SatLowerBound.MAContext.no_drop_forces_pruning_chain,
               ``SatLowerBound.MAContext.no_drop_forces_dead_gate_after_three_eliminations,
               ``SatLowerBound.OpenCircuit.essential_input_with_dead_reader_has_two_refs,
               ``SatLowerBound.OpenCircuit.single_dead_gate_retains_input_reader,
               ``SatLowerBound.OpenCircuit.forbid_a_of_distinct,
               ``SatLowerBound.OpenCircuit.second_role_has_no_primary_unreduced,
               ``SatLowerBound.OpenCircuit.dead_essential_reader_no_role,
               ``SatLowerBound.E2.single_cofactor_e1,
               ``SatLowerBound.OpenCircuit.restrict_distinct_operands,
               ``SatLowerBound.OpenCircuit.fixed_input_unused_after_restriction,
               ``SatLowerBound.MAContext.cofactor_dGateSafe,
               ``SatLowerBound.MAContext.cofactor_dead_reader_no_role,
               ``SatLowerBound.OpenCircuit.deleteDead_spec,
               ``SatLowerBound.OpenCircuit.deleteDead_head_preserves_credits,
               ``SatLowerBound.OpenCircuit.deleteDead_head_potential_drop,
               ``SatLowerBound.OpenCircuit.deleteDead_profile_before,
               ``SatLowerBound.OpenCircuit.deleteDead_preserves_primary_D,
               ``SatLowerBound.OpenCircuit.deleteDead_gateAt_before,
               ``SatLowerBound.OpenCircuit.deleteDead_transport_later_gate,
               ``SatLowerBound.OpenCircuit.deleteDead_dCount_mono,
               ``SatLowerBound.OpenCircuit.deleteDead_preserves_DStar_first_before,
               ``SatLowerBound.OpenCircuit.deleteDead_preserves_primary_DStar,
               ``SatLowerBound.OpenCircuit.deleteDead_role_free_potential_drop,
               ``SatLowerBound.OpenCircuit.deleteDead_restriction_spec,
               ``SatLowerBound.MAContext.cofactor_dead_reader_pruning_drop,
               ``SatLowerBound.MAContext.pruning_branch_explicit_deletion,
               ``SatLowerBound.MAContext.pruning_branch_main_drop,
               ``SatLowerBound.MAContext.main_lemma_B_explicit,
               ``SatLowerBound.OpenCircuit.deleteDead_refCount_before_le,
               ``SatLowerBound.OpenCircuit.deleteDead_preserves_proper,
               ``SatLowerBound.OpenCircuit.dead_gate_credit_role_free,
               ``SatLowerBound.OpenCircuit.deleteDead_potential_drop_of_used_essential,
               ``SatLowerBound.OpenCircuit.exists_dead_gate_of_not_reduced,
               ``SatLowerBound.OpenCircuit.exists_reduced_potential_le,
               ``SatLowerBound.OpenCircuit.exists_reduced_potential_le_size,
               ``SatLowerBound.Table.triangle_psi2W,
               ``SatLowerBound.OpenCircuit.PsiTriangleAux.replaceAt_psi2Weight,
               ``SatLowerBound.OpenCircuit.PsiTriangleAux.replaceAt_preserves_D_triangle,
               ``SatLowerBound.OpenCircuit.PsiTriangleAux.replaceAt_gateAt_of_ne,
               ``SatLowerBound.OpenCircuit.PsiTriangleAux.replaceAt_preserves_DStar_triangle,
               ``SatLowerBound.OpenCircuit.PsiTriangleAux.twoLevel_triangle_core,
               ``SatLowerBound.OpenCircuit.twoLevel_triangle_step,
               ``SatLowerBound.Table.triangle_not_parity,
               ``SatLowerBound.Table.triangle_psi2W_zero_or_four,
               ``SatLowerBound.OpenCircuit.PsiTriangleAux.replaceAt_distinct_operands,
               ``SatLowerBound.OpenCircuit.PsiTriangleAux.replaceAt_proper_of_essential,
               ``SatLowerBound.OpenCircuit.PsiTriangleAux.triangle_other_gates_proper,
               ``SatLowerBound.OpenCircuit.PsiTriangleAux.replaceAt_twoLevel_potential_le,
               ``SatLowerBound.OpenCircuit.PsiTriangleAux.essential_triangle_reduced,
               ``SatLowerBound.OpenCircuit.free_two_credit_loss_le_eliminated_distinct,
               ``SatLowerBound.OpenCircuit.gate_charges_zero_of_degenerate,
               ``SatLowerBound.OpenCircuit.psi2_free_restriction_le_of_distinct,
               ``SatLowerBound.OpenCircuit.psi2_identity_resolution_le,
               ``SatLowerBound.OpenCircuit.identity_resolution_size_lt_of_degenerate,
               ``SatLowerBound.OpenCircuit.usage_pos_of_fix_usage_pos,
               ``SatLowerBound.OpenCircuit.degenerate_resolution_reduced,
               ``SatLowerBound.OpenCircuit.PsiTriangleAux.triangle_reduced_core,
               ``SatLowerBound.OpenCircuit.twoLevel_triangle_reduced_step,
               ``SatLowerBound.OpenCircuit.psi2_normalize_all_essential,
               ``SatLowerBound.OpenCircuit.exists_reduced_potential_le_size_support,
               ``SatLowerBound.OpenCircuit.degenerate_resolution_reduced_support,
               ``SatLowerBound.OpenCircuit.PsiTriangleAux.triangle_usage_pos_of_rewrite,
               ``SatLowerBound.OpenCircuit.PsiTriangleAux.triangle_reduced_core_support,
               ``SatLowerBound.OpenCircuit.twoLevel_triangle_reduced_step_support,
               ``SatLowerBound.OpenCircuit.psi2_normalize_used_essential,
               ``SatLowerBound.OpenCircuit.psi2_normalize_proper,
               ``SatLowerBound.MAContext.pruning_branch_main_drop_proper,
               ``SatLowerBound.MAContext.cofactor_proper_used,
               ``SatLowerBound.MAContext.main_lemma_B_proper,
               ``SatLowerBound.MAContext.main_lemma_B_normalized,
               ``SatLowerBound.OpenCircuit.psi2_normalize_used_essential_support,
               ``SatLowerBound.OpenCircuit.psi2_normalize_proper_support,
               ``SatLowerBound.MAContext.pruning_branch_main_drop_proper_support,
               ``SatLowerBound.MAContext.main_lemma_B_proper_support,
               ``SatLowerBound.MAContext.main_lemma_B_normalized_support,
               ``SatLowerBound.robust_block_psi2_bound,
               ``SatLowerBound.robust_full_degree_block_size,
               ``SatLowerBound.combine_pair_four_left,
               ``SatLowerBound.combine_pair_four_cross,
               ``SatLowerBound.combine_s4Essential,
               ``SatLowerBound.combine_e1,
               ``SatLowerBound.combine_e2,
               ``SatLowerBound.CompositionDependence.combine,
               ``SatLowerBound.CompositionDependence.goodFn,
               ``SatLowerBound.DependenceTree.dependence,
               ``SatLowerBound.RobustOn.free_essential,
               ``SatLowerBound.RobustOn.restricted_s4,
               ``SatLowerBound.RobustOn.restricted_e1,
               ``SatLowerBound.RobustOn.restricted_e2,
               ``SatLowerBound.RobustOn.restricted_dependence,
               ``SatLowerBound.RobustTree.restricted_dependence,
               ``SatLowerBound.RobustTree.restricted_oneDependence,
               ``SatLowerBound.OpenCircuit.retirement_second_charge_bound,
               ``SatLowerBound.OpenCircuit.retirement_loss_eq_charges,
               ``SatLowerBound.OpenCircuit.retirement_gate_charge_le_two,
               ``SatLowerBound.OpenCircuit.psi2_retirement_restriction_le,
               ``SatLowerBound.OpenCircuit.psi2_restrict_preserving_essential,
               ``SatLowerBound.OpenCircuit.fixed_coordinate_unused,
               ``SatLowerBound.OpenCircuit.psi2_retirement_normalized,
               ``SatLowerBound.RobustContext.retire_stats,
               ``SatLowerBound.RobustContext.retire_valid,
               ``SatLowerBound.RobustContext.retire_eval,
               ``SatLowerBound.RobustTree.locate,
               ``SatLowerBound.RobustContext.retire_leaf_normalized,
               ``SatLowerBound.RobustTree.surplus_add_retired,
               ``SatLowerBound.RobustContext.plug_surplus_partialFix,
               ``SatLowerBound.robust_tree_psi2_surplus,
               ``SatLowerBound.robust_tree_psi2_bound,
               ``SatLowerBound.robust_tree_full_degree_size,
               ``SatLowerBound.OpenCircuit.restrict_nonlinearCount_le,
               ``SatLowerBound.RobustTree.coordinate_injective,
               ``SatLowerBound.RobustTree.packed_eval,
               ``SatLowerBound.RobustTree.nonlinear_lower_bound_of_full_leaves,
               ``SatLowerBound.RobustTree.full_leaves_size,
               ``SatLowerBound.canonical_forbidden_count_le,
               ``SatLowerBound.genericSparseFormula_sat_iff,
               ``SatLowerBound.genericSparseRestriction_correct,
               ``SatLowerBound.genericSparseRestriction_sat,
               ``SatLowerBound.genericFixed_coordinate_count,
               ``SatLowerBound.genericRemaining_pos_of_count,
               ``SatLowerBound.generic_sat_sparse_transfer,
               ``SatLowerBound.embedded_pairFour,
               ``SatLowerBound.Robust.embedded,
               ``SatLowerBound.generic_sat_tree_certificate,
               ``SatLowerBound.lastCubeSum_eq_sum,
               ``SatLowerBound.topCoefficient_perm,
               ``SatLowerBound.embedded_leaf_full_degree,
               ``SatLowerBound.genericSparseTree_valid,
               ``SatLowerBound.genericSparseTree_full,
               ``SatLowerBound.genericSparseTree_support,
               ``SatLowerBound.genericSparseTree_eval,
               ``SatLowerBound.sat_certificate_of_robust_block,
               ``SatLowerBound.coincident_restrict_injective,
               ``SatLowerBound.complementCard_eq,
               ``SatLowerBound.coincidentFunctions_card_le_pow,
               ``SatLowerBound.cofactorCube_injective,
               ``SatLowerBound.cofactorCube_disjoint,
               ``SatLowerBound.rowCollision_on_subcubes,
               ``SatLowerBound.residualCoord_card,
               ``SatLowerBound.cofactor_collision_card_le,
               ``SatLowerBound.rowCollisionSet_card_le,
               ``SatLowerBound.sixRowPairs_cover,
               ``SatLowerBound.notRobust_mem_badFunctions,
               ``SatLowerBound.collisionEvent_card_le,
               ``SatLowerBound.collisionIndices_card_le,
               ``SatLowerBound.badFunctions_card_le,
               ``SatLowerBound.originIndicator_top,
               ``SatLowerBound.top_flipOrigin,
               ``SatLowerBound.fullDegreeFunctions_card,
               ``SatLowerBound.exists_robust_fullDegree_of_count,
               ``SatLowerBound.count_condition_of_exponential,
               ``SatLowerBound.exists_robust_fullDegree,
               ``SatLowerBound.exists_sat_certificate_of_count,
               ``SatLowerBound.collision_event_count_lt,
               ``SatLowerBound.countingThreshold_condition,
               ``SatLowerBound.countingThreshold_fits,
               ``SatLowerBound.exists_robust_fullDegree_large,
               ``SatLowerBound.exists_sat_certificate_logarithmic,
               ``SatLowerBound.paperBlockSize_bounds,
               ``SatLowerBound.countingThreshold_paperBlockSize_le,
               ``SatLowerBound.paper_parameter_finite_certificate,
               ``SatLowerBound.paperBlockSize_helper_budget,
               ``SatLowerBound.paperBlockSize_forbidden_budget,
               ``SatLowerBound.seventeen_sevenths_width_bound,
               ``SatLowerBound.seventeen_sevenths_logarithmic_bound,
               ``SatLowerBound.seventeen_sevenths_asymptotic,
               ``SatLowerBound.finite_paper_bound_of_robust_block,
               ``SatLowerBound.finite_paper_bound_of_count,
               ``SatLowerBound.PairFour.swap,
               ``SatLowerBound.notRobust_mem_orderedBadFunctions,
               ``SatLowerBound.orderedCollisionIndices_card_le,
               ``SatLowerBound.orderedBadFunctions_card_le,
               ``SatLowerBound.exists_robust_fullDegree_exact_count,
               ``SatLowerBound.paper_log_condition_implies_count,
               ``SatLowerBound.finite_paper_bound_log_condition,
               ``SatLowerBound.fourRows_of_surjective_shifts,
               ``SatLowerBound.weightedPairShiftNat_injective,
               ``SatLowerBound.weightedPairShift_injective,
               ``SatLowerBound.weightedSum_cofactor,
               ``SatLowerBound.weightedModularBlock_robust_of_coverage,
               ``SatLowerBound.weightedCoordinate_injective,
               ``SatLowerBound.residualWeights_card,
               ``SatLowerBound.residualWeights_no_opposites,
               ``SatLowerBound.weightedResidual_decomposition,
               ``SatLowerBound.weightedResidual_surjective_of_subsetSum,
               ``SatLowerBound.weightedModularBlock_robust_of_subsetSumBound,
               ``SatLowerBound.weighted_product_expansion,
               ``SatLowerBound.weighted_top_sum,
               ``SatLowerBound.weighted_block_full_degree_of_root,
               ``SatLowerBound.weighted_block_full_degree_of_prime,
               ``SatLowerBound.exists_weighted_robust_full_degree_of_subsetSumBound,
               ``SatLowerBound.weightedSum_extend,
               ``SatLowerBound.weightedBlock_top_step,
               ``SatLowerBound.weightedResidueParity_correct,
               ``SatLowerBound.weightedResidueParity_exists,
               ``SatLowerBound.weightedPrime_spec,
               ``SatLowerBound.weightedPrime_minimal,
               ``SatLowerBound.weightedPrime_le_four,
               ``SatLowerBound.weightedTriangleThreshold_spec,
               ``SatLowerBound.weightedTriangleThreshold_sqrt_bound,
               ``SatLowerBound.exists_paper_weighted_block_of_subsetSumBound,
               ``SatLowerBound.weightedThreshold_fits,
               ``SatLowerBound.paper_weighted_finite_certificate_of_subsetSumBound,
               ``SatLowerBound.paper_weighted_width_bound_of_subsetSumBound,
               ``SatLowerBound.paper_weighted_log_bound_of_subsetSumBound,
               ``SatLowerBound.subsetSum_no_wrap_bound,
               ``SatLowerBound.encoded_log_tendsto,
               ``SatLowerBound.seventeen_sevenths_epsilon,
               ``SatLowerBound.S4.all_essential,
               ``SatLowerBound.S4.at_least_three,
               ``SatLowerBound.goodFn_of_paper_conditions,
               ``SatLowerBound.paper_one_step_elimination,
               ``SatLowerBound.E2.e1_of_three,
               ``SatLowerBound.paper_one_step_elimination_exact,
               ``SatLowerBound.OpenCircuit.isD_iff_paperD_of_reduced,
               ``SatLowerBound.OpenCircuit.dCount_eq_paperDCount,
               ``SatLowerBound.OpenCircuit.dStarCount_eq_paperDStarCount,
               ``SatLowerBound.OpenCircuit.psi2_eq_paperPsi2,
               ``SatLowerBound.paper_one_step_elimination_successor_potential,
               ``SatLowerBound.paper_normalization_successor_potential,
               ``SatLowerBound.NetworkNode.constant_eval,
               ``SatLowerBound.NetworkNode.unary_eval,
               ``SatLowerBound.OrderedNetwork.toCircuit_eval,
               ``SatLowerBound.OrderedNetwork.toCircuit_size,
               ``SatLowerBound.seventeen_sevenths_epsilon_ordered_network,
               ``SatLowerBound.exists_finite_topological_order,
               ``SatLowerBound.AcyclicNetwork.exists_order,
               ``SatLowerBound.AcyclicNetwork.compiled_size,
               ``SatLowerBound.OrderedNetwork.values_gate,
               ``SatLowerBound.AcyclicNetwork.gateValues_equations,
               ``SatLowerBound.AcyclicNetwork.consistent_unique,
               ``SatLowerBound.AcyclicNetwork.graphEval_eq_of_consistent,
               ``SatLowerBound.AcyclicNetwork.compiled_eval,
               ``SatLowerBound.seventeen_sevenths_epsilon_graph_equations,
               ``SatLowerBound.signedSubsetSums_eq_image,
               ``SatLowerBound.signedSubsetSums_card_zmod_prime,
               ``SatLowerBound.signed_tuple_indices_form_permutation,
               ``SatLowerBound.distinct_signed_tuple_sum_mem,
               ``SatLowerBound.signedRestrictedSums_card_le_subsetSum,
               ``SatLowerBound.signedVandermonde_separated,
               ``SatLowerBound.signedSumAvoidingPolynomial_vanishes,
               ``SatLowerBound.signedSumAvoidingPolynomial_coefficient_zero,
               ``SatLowerBound.variablePairs_card,
               ``SatLowerBound.signedVandermonde_degree_le,
               ``SatLowerBound.sumAvoidingFactor_degree_le,
               ``SatLowerBound.signedSumAvoidingPolynomial_degree_le,
               ``SatLowerBound.restrictedSums_card_gt_of_nonzero_coefficient,
               ``SatLowerBound.shiftedLinearProduct_sub_power_degree,
               ``SatLowerBound.signedSumAvoidingPolynomial_top_coefficient,
               ``SatLowerBound.signedSumAvoidingPolynomial_vanishes_of_cover,
               ``SatLowerBound.restrictedSums_gt_of_leading_coefficient,
               ``SatLowerBound.signedVandermonde_eq_det,
               ``SatLowerBound.signedLeadingPolynomial_coeff_permutation_sum,
               ``SatLowerBound.coeff_monomial_mul_sum_pow,
               ``SatLowerBound.permutation_square_product_eq_monomial,
               ``SatLowerBound.signed_permutation_product_eq_monomial,
               ``SatLowerBound.signedLeadingPolynomial_coeff_multinomial_sum,
               ``SatLowerBound.multinomial_mul_factorials,
               ``SatLowerBound.multinomial_eq_factorial_mul_inv,
               ``SatLowerBound.permutationSquareExponent_degree,
               ``SatLowerBound.permutationSquareExponent_sub_degree,
               ``SatLowerBound.signedLeadingPolynomial_coeff_inverse_factorial_sum,
               ``SatLowerBound.inverseFactorialMatrix_perm_product,
               ``SatLowerBound.signedLeadingPolynomial_coeff_inverse_factorial_det,
               ``SatLowerBound.factorial_mul_inverseFactorialMatrix,
               ``SatLowerBound.inverseFactorialMatrix_det_mul_factorials,
               ``SatLowerBound.signedLeadingPolynomial_coeff_ne_zero_of_binomial_det,
               ``SatLowerBound.restrictedSums_gt_of_binomial_det,
               ``SatLowerBound.balandraudDomain_rep,
               ``SatLowerBound.balandraudDomain_card,
               ``SatLowerBound.balandraudExponent_domain_card,
               ``SatLowerBound.balandraudExponent_lt_twice,
               ``SatLowerBound.restrictedSums_gt_of_binomial_det_charP,
               ``SatLowerBound.balandraudDomains_restrictedSums_gt,
               ``SatLowerBound.balandraudDomains_subsetSum_gt,
               ``SatLowerBound.balandraud_cut_count,
               ``SatLowerBound.balandraudExponent_degree,
               ``SatLowerBound.balandraudDomains_subsetSum_triangular,
               ``SatLowerBound.choose_cast_ne_zero_of_lt_char,
               ``SatLowerBound.balandraud_det_ne_zero_of_identity,
               ``SatLowerBound.det_eq_det_successive_row_differences,
               ``SatLowerBound.binomial_det_consecutive_rows,
               ``SatLowerBound.binomial_det_shift_factor,
               ``SatLowerBound.balandraud_subsetSum_of_det_identity,
               ``SatLowerBound.adjacent_succAbove_eq_except,
               ``SatLowerBound.det_adjacent_gap_split,
               ``SatLowerBound.det_one_gap_row_differences,
               ``SatLowerBound.binomial_det_one_gap,
               ``SatLowerBound.balandraudExponent_eq_succAbove,
               ``SatLowerBound.balandraudDet_dimension_recurrence,
               ``SatLowerBound.balandraudDet_zero_dimension_recurrence,
               ``SatLowerBound.balandraudDet_last_dimension_recurrence,
               ``SatLowerBound.balandraud_omitted_product,
               ``SatLowerBound.balandraud_odd_product_ne_zero,
               ``SatLowerBound.balandraudDet_full_product_recurrence,
               ``SatLowerBound.balandraud_factorial_even_odd,
               ``SatLowerBound.balandraud_factorial_halves,
               ``SatLowerBound.balandraud_product_ratio,
               ``SatLowerBound.balandraudDet_zero_closed,
               ``SatLowerBound.balandraudDet_normalized_recurrence,
               ``SatLowerBound.balandraudDet_last_closed,
               ``SatLowerBound.balandraudDet_eq_of_recurrence,
               ``SatLowerBound.balandraud_binomial_step,
               ``SatLowerBound.balandraud_identity_interior,
               ``SatLowerBound.balandraud_determinant_identity,
               ``SatLowerBound.balandraud_subsetSum_min_of_previous_triangle,
               ``SatLowerBound.balandraud_subsetSum_eq_univ_at_threshold,
               ``SatLowerBound.balandraud_subsetSum_min_enumerated,
               ``SatLowerBound.antipodal_free_card_lt_half,
               ``SatLowerBound.balandraud_subsetSum_bound,
               ``SatLowerBound.weightedModularBlock_robust,
               ``SatLowerBound.weightedPrime_subsetSumBound,
               ``SatLowerBound.exists_paper_weighted_block,
               ``SatLowerBound.paper_weighted_finite_certificate,
               ``SatLowerBound.paper_weighted_width_bound,
               ``SatLowerBound.paper_weighted_log_bound,
               ``SatLowerBound.weightedResidueTable_correct,
               ``SatLowerBound.weightedResidueTable_topCoefficient,
               ``SatLowerBound.weightedResidueTableXors_exact,
               ``SatLowerBound.weightedResidueTableXors_quadratic,
               ``SatLowerBound.selectWeightedResidue_spec,
               ``SatLowerBound.selectWeightedResidue_exists,
               ``SatLowerBound.selectedWeightedResidue_robust_full_degree,
               ``SatLowerBound.paper_weighted_log_bound_graph_equations,
               ``SatLowerBound.paper_finite_ceiling_bound,
               ``SatLowerBound.paper_finite_ceiling_bound_graph_equations,
               ``SatLowerBound.paper_logarithmic_bound_graph_equations,
               ``SatLowerBound.paper_composition_potential,
               ``SatLowerBound.paper_composition_ceiling_bound,
               ``SatLowerBound.ResidueMachine.table_value,
               ``SatLowerBound.ResidueMachine.table_steps,
               ``SatLowerBound.ResidueMachine.select_steps,
               ``SatLowerBound.ResidueMachine.select_steps_quadratic,
               ``SatLowerBound.ResidueMachine.select_value_of_verified,
               ``SatLowerBound.ResidueMachine.select_correct_with_cost,
               ``SatLowerBound.ResidueMachine.selected_block_with_cost,
               ``SatLowerBound.ResidueMachine.paper_selected_block_quadratic,
               ``SatLowerBound.ResidueMachine.remainder_value,
               ``SatLowerBound.ResidueMachine.remainder_steps,
               ``SatLowerBound.ResidueMachine.noDivisors_value,
               ``SatLowerBound.ResidueMachine.noDivisors_steps,
               ``SatLowerBound.ResidueMachine.primeTest_value,
               ``SatLowerBound.ResidueMachine.primeTest_steps,
               ``SatLowerBound.ResidueMachine.search_finds,
               ``SatLowerBound.ResidueMachine.search_steps,
               ``SatLowerBound.ResidueMachine.findPrime_value,
               ``SatLowerBound.ResidueMachine.findPrime_steps,
               ``SatLowerBound.ResidueMachine.construct_steps,
               ``SatLowerBound.ResidueMachine.construct_correct_with_cost,
               ``SatLowerBound.PaperE1.toE1,
               ``SatLowerBound.PaperE2.toE2,
               ``SatLowerBound.paperE1_iff_E1_of_full_support,
               ``SatLowerBound.paperE2_iff_E2_of_S4,
               ``SatLowerBound.paper_elimination_E2,
               ``SatLowerBound.OpenCircuit.second_credit_gate_not_constant,
               ``SatLowerBound.OpenCircuit.first_credit_gate_not_constant,
               ``SatLowerBound.OpenCircuit.free_constant_gate_charge_zero,
               ``SatLowerBound.BPoly.tensor_degreeLT_iff,
               ``SatLowerBound.BPoly.hasDegree_tensor,
               ``SatLowerBound.BPoly.hasDegree_disjointOr,
               ``SatLowerBound.ReadOnce.degree_of_leaf_degrees,
               ``SatLowerBound.ReadOnce.nonlinear_bound_of_leaf_degrees] do
    let axs ← collectAxioms name
    for ax in axs do
      unless allowed.contains ax do
        throwError "forbidden axiom in {name}: {ax}"
    logInfo m!"AXIOM AUDIT PASSED: {name}: {axs.toList}"
