import Credit.TwoLevel.MainBNormalized
import Credit.TwoLevel.RobustRestrictions
import Credit.TwoLevel.Terminal
import SatLowerBound.ResidualDegree

/-! Repeated fourteen-unit elimination for a robust block. -/
namespace SatLowerBound
open OpenCircuit

/-- Every normalized circuit computing a robust cofactor, and using only its
free coordinates, has the potential obtained by repeated elimination until
`k+1` coordinates remain. -/
theorem robust_block_psi2_bound {n k : Nat} {f : (Fin n → Bool) → Bool}
    (hrobust : Robust k f) (hk : 2 ≤ k) (ρ : Fin n → Option Bool)
    (C : OpenCircuit n) (hr : C.Reduced) (ht : C.NoInputTriangles (fun _ => none))
    (hc : ∀ v, C.eval v = f (applyPartial ρ v))
    (hsupport : ∀ z : Fin n, 0 < C.usage (singleUse z) → ρ z = none) :
    14 * ((freeCoordinates ρ).card : Int) - 14 * (k+1 : Nat) ≤ C.psi2 := by
  suffices h : ∀ m, ∀ (ρ : Fin n → Option Bool), (freeCoordinates ρ).card = m →
      ∀ C : OpenCircuit n, C.Reduced → C.NoInputTriangles (fun _ => none) →
      (∀ v, C.eval v = f (applyPartial ρ v)) →
      (∀ z : Fin n, 0 < C.usage (singleUse z) → ρ z = none) →
      14 * ((freeCoordinates ρ).card : Int) - 14 * (k+1 : Nat) ≤ C.psi2 from
    h (freeCoordinates ρ).card ρ rfl C hr ht hc hsupport
  intro m
  induction m using Nat.strong_induction_on with
  | h m ih =>
    intro ρ hm C hr ht hc hsupport
    by_cases hsmall : (freeCoordinates ρ).card ≤ k+1
    · have hnonneg := C.psi2_nonnegative
      omega
    · have hlarge : k+2 ≤ (freeCoordinates ρ).card := by omega
      let F : (Fin n → Bool) → Bool := fun v => f (applyPartial ρ v)
      have hgood : GoodFn F := hrobust.restricted_goodFn ρ hlarge hk
      have hS4 : S4Essential F := hrobust.restricted_s4Essential ρ (by omega)
      have hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential F z := by
        intro z hz
        exact hrobust.every_free_essential ρ (by omega) (by omega) z (hsupport z hz)
      have hctx : MAContext F C := ⟨hgood,hr,ht,hc,hused⟩
      obtain ⟨x,b,D,hx,he,hD,htri,hDe,hdrop,hDs⟩ := hctx.main_lemma_B_normalized_support hS4
      have hxfree : ρ x = none := essential_of_partial_is_free f ρ x he
      let τ := partialFix ρ x b
      have hxf : x ∈ freeCoordinates ρ := by simp [freeCoordinates,hxfree]
      have hcard : (freeCoordinates τ).card + 1 = (freeCoordinates ρ).card := by
        change (freeCoordinates (partialFix ρ x b)).card + 1 = _
        rw [freeCoordinates_partialFix]
        exact Finset.card_erase_add_one hxf
      have hDcomp : ∀ v, D.eval v = f (applyPartial τ v) := by
        intro v
        rw [hDe]
        change f (applyPartial ρ (fixBit x b v)) = f (applyPartial τ v)
        rw [applyPartial_fixBit]
      have hDsupport : ∀ z : Fin n, 0 < D.usage (singleUse z) → τ z = none := by
        intro z hz
        obtain ⟨hzC,hzx⟩ := hDs z hz
        have hzfree := hsupport z hzC
        simp [τ,partialFix,hzx,hzfree]
      have hbound := ih (freeCoordinates τ).card (by omega) τ rfl D hD htri hDcomp hDsupport
      omega

/-- Full-degree robust single-block instance of the paper's size estimate. -/
theorem robust_full_degree_block_size {n k : Nat} {f : (Fin n → Bool) → Bool}
    (hrobust : Robust k f) (hk : 2 ≤ k)
    (hfull : (BPoly.ofFunction n f).topCoefficient = true)
    (C : OpenCircuit n) (hc : ∀ v, C.eval v = f v) :
    17 * (n : Int) - 14 * ((k : Int) + 1) - 3 ≤ 7 * (C.size : Int) := by
  obtain ⟨D,hr,ht,hs,_,he⟩ := C.normalize_by_descent
  have hDe : ∀ v, D.eval v = f v := fun v => (he v).trans (hc v)
  let ρ : Fin n → Option Bool := fun _ => none
  have hDco : ∀ v, D.eval v = f (applyPartial ρ v) := by
    intro v
    rw [hDe]
    congr 1
  have hsupport : ∀ z : Fin n, 0 < D.usage (singleUse z) → ρ z = none := by
    intro _ _
    rfl
  have hpot := robust_block_psi2_bound hrobust hk ρ D hr ht hDco hsupport
  have hfree : (freeCoordinates ρ).card = n := by simp [freeCoordinates,ρ]
  rw [hfree] at hpot
  have hdeg := D.nonlinear_lower_bound f hDe hfull
  have hconv := D.size_bound_of_potential (D.reduced_essential hr) n 1 k (by omega) (by omega)
  omega

end SatLowerBound
