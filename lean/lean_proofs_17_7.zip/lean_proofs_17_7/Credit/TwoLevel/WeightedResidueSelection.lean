import Credit.TwoLevel.WeightedResidueTable
import Credit.TwoLevel.WeightedUnconditional

namespace SatLowerBound

/-- Compute the table once, then select its first true entry in residue order. -/
def selectWeightedResidue (n p : Nat) [NeZero p] : Option (Fin p) :=
  let table := weightedResidueTable p n
  Fin.find? (fun i => table[i])

/-- Successful selection returns a full-degree block, and every smaller
residue has zero top coefficient. -/
theorem selectWeightedResidue_spec (n p : Nat) [NeZero p] (i : Fin p)
    (hi : selectWeightedResidue n p = some i) :
    (BPoly.ofFunction n (weightedModularBlock n p (i.val : ZMod p))).topCoefficient = true ∧
    ∀ j : Fin p, j < i →
      (BPoly.ofFunction n (weightedModularBlock n p (j.val : ZMod p))).topCoefficient = false := by
  have h := Fin.find?_eq_some_iff.mp hi
  constructor
  · rw [← weightedResidueTable_topCoefficient]
    exact h.1
  · intro j hj
    rw [← weightedResidueTable_topCoefficient]
    exact h.2 j hj

/-- For the odd prime moduli in the construction, selection always succeeds. -/
theorem selectWeightedResidue_exists (n p : Nat) [NeZero p]
    (hp : p.Prime) (hpodd : p ≠ 2) (hnp : n < p) :
    ∃ i : Fin p, selectWeightedResidue n p = some i := by
  obtain ⟨t, ht⟩ := weightedResidueParity_exists n p hp hpodd hnp
  have hex : ∃ i : Fin p, (weightedResidueTable p n)[i] = true := by
    refine ⟨⟨t.val, ZMod.val_lt t⟩, ?_⟩
    rw [weightedResidueTable_correct]
    simpa using ht
  let i := Fin.find (fun j : Fin p => (weightedResidueTable p n)[j] = true) hex
  refine ⟨i, Fin.find?_eq_some_iff.mpr ⟨Fin.find_spec hex, ?_⟩⟩
  intro j hj
  have h := Fin.find_min hex hj
  exact Bool.eq_false_iff.mpr h

/-- The explicitly selected residue has both properties needed by the
weighted lower-bound construction. -/
theorem selectedWeightedResidue_robust_full_degree (n p m k : Nat) [Fact p.Prime]
    (hpodd : p ≠ 2) (hlarge : 2 * n < p) (hk : m + 2 ≤ k)
    (hthreshold : p ≤ 1 + m * (m + 1) / 2) :
    ∃ i : Fin p, selectWeightedResidue n p = some i ∧
      Robust k (weightedModularBlock n p (i.val : ZMod p)) ∧
      (BPoly.ofFunction n (weightedModularBlock n p (i.val : ZMod p))).topCoefficient = true := by
  obtain ⟨i, hi⟩ := selectWeightedResidue_exists n p Fact.out hpodd (by omega)
  exact ⟨i, hi, weightedModularBlock_robust n p m k hpodd hlarge hk hthreshold _,
    (selectWeightedResidue_spec n p i hi).1⟩

end SatLowerBound
