import Credit.TwoLevel.CountingParameters
import SatLowerBound.PdfAsymptotics

/-! Explicit helper-cost and finite-width bounds for the 17/7 construction. -/
namespace SatLowerBound

/-- The paper's choice of block length keeps the full truth table within the
helper budget `m / w`. -/
theorem paperBlockSize_helper_budget (w : Nat) (hw : 32 ≤ w) :
    w * 2 ^ (paperBlockSize w) ≤ variableCount w := by
  have hl : logarithmicOffset w ≤ w - 17 :=
    Nat.clog_le_of_le_pow (width_power_fit w hw)
  have hr : logarithmicOffset w + paperBlockSize w + 1 = w := by
    unfold paperBlockSize
    omega
  have hpow := Nat.le_pow_clog (b := 2) (by decide) w
  change w ≤ 2 ^ logarithmicOffset w at hpow
  have hm := Nat.mul_le_mul_right (2 ^ paperBlockSize w) hpow
  rw [← pow_add] at hm
  have hp : 0 < 2 ^ (logarithmicOffset w + paperBlockSize w) := by positivity
  have he : 2 ^ w = 2 ^ (logarithmicOffset w + paperBlockSize w) * 2 := by
    calc
      2 ^ w = 2 ^ (logarithmicOffset w + paperBlockSize w + 1) := congrArg (fun x : Nat => 2 ^ x) hr.symm
      _ = _ := pow_succ _ _
  unfold variableCount
  omega

/-- All forbidden suffixes together use at most `m / w` helper clauses. -/
theorem paperBlockSize_forbidden_budget (w : Nat) (hw : 32 ≤ w)
    (g : (Fin (paperBlockSize w) → Bool) → Bool) :
    w * (canonicalForbiddenFamily g).count ≤ variableCount w := by
  exact (Nat.mul_le_mul_left w (canonical_forbidden_count_le g)).trans
    (paperBlockSize_helper_budget w hw)

/-- Explicit finite-width version of the 17/7 lower bound. -/
theorem seventeen_sevenths_width_bound (w : Nat) (hw : 32 ≤ w)
    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    17 * (inputBits w : Int) -
      (72 * (logarithmicOffset w : Int) + 342) * (variableCount w : Int) - 3 ≤
      7 * (C.size : Int) := by
  classical
  obtain ⟨g,hcert⟩ := paper_parameter_finite_certificate w hw
  let r : Int := paperBlockSize w
  let k : Int := countingThreshold (paperBlockSize w)
  let l : Int := logarithmicOffset w
  let m : Int := variableCount w
  let b : Int := (canonicalForbiddenFamily g).count
  let M : Int := genericRemainingClauses w (canonicalForbiddenFamily g)
  let W : Int := w
  let N : Int := inputBits w
  have hlarge := (paperBlockSize_bounds w hw).1
  have hrw := (paperBlockSize_bounds w hw).2
  have hrNat : paperBlockSize w + logarithmicOffset w + 1 = w := by
    have hl : logarithmicOffset w ≤ w - 17 := Nat.clog_le_of_le_pow (width_power_fit w hw)
    unfold paperBlockSize
    omega
  have hr : r + l + 1 = W := by dsimp [r,l,W]; exact_mod_cast hrNat
  have hk : k ≤ l + 5 := by
    dsimp [k,l]
    exact_mod_cast countingThreshold_paperBlockSize_le w
  have hR : r ≤ W := by dsimp [r,W]; exact_mod_cast hrw.le
  have hm : 0 ≤ m := by dsimp [m]; positivity
  have hb : 0 ≤ b := by dsimp [b]; positivity
  have hbudget : W * b ≤ m := by
    dsimp [W,b,m]
    exact_mod_cast paperBlockSize_forbidden_budget w hw g
  have hfit : (canonicalForbiddenFamily g).count ≤ variableCount w :=
    (genericRemaining_pos_of_count w (paperBlockSize w) hrw (by omega)
      (canonicalForbiddenFamily g) (canonical_forbidden_count_le g)).1
  have hremain : M + b = m := by
    dsimp [M,b,m,genericRemainingClauses]
    exact_mod_cast Nat.sub_add_cancel hfit
  have hn : N = 3 * m * (W + 1) := by
    dsimp [N,m,W,inputBits]
  have hc' : 7*N + (30*r-42*(k+1))*M - 3 ≤ 7*(C.size : Int) := by
    simpa [N,r,k,M] using hcert C hc
  have ha : 30*W-72*l-282 ≤ 30*r-42*(k+1) := by omega
  have ha' : 30*r-42*(k+1) ≤ 30*W := by
    have hk0 : 0 ≤ k := by dsimp [k]; positivity
    omega
  have hmul1 := mul_le_mul_of_nonneg_right ha hm
  have hmul2 := mul_le_mul_of_nonneg_right ha' hb
  have hmul3 := mul_le_mul_of_nonneg_left hbudget (show (0 : Int) ≤ 30 by omega)
  change 17*N - (72*l+342)*m - 3 ≤ 7*(C.size : Int)
  nlinarith

/-- The explicit finite-width estimate written using the encoded input length. -/
theorem seventeen_sevenths_logarithmic_bound (w : Nat) (hw : 32 ≤ w)
    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    (17 / 7 : ℝ) * inputBits w -
      70 * inputBits w * Real.logb 2 (Real.logb 2 (inputBits w)) /
        Real.logb 2 (inputBits w) ≤ (C.size : ℝ) := by
  let Q : ℝ := Real.logb 2 (inputBits w)
  let H : ℝ := Real.logb 2 Q
  let L : ℝ := logarithmicOffset w
  let M : ℝ := variableCount w
  let N : ℝ := inputBits w
  have hq := PdfAsymptotics.q_comparison w (by omega)
  change (w : ℝ) ≤ Q ∧ Q ≤ 3 * w at hq
  have hl := PdfAsymptotics.log_q_comparison w (by omega)
  change 1 ≤ Real.logb 2 (w : ℝ) ∧ Real.logb 2 (w : ℝ) ≤ H ∧
    H ≤ Real.logb 2 (w : ℝ) + 2 at hl
  have hoff := PdfAsymptotics.offset_bounds w (by omega)
  change Real.logb 2 (w : ℝ) ≤ L ∧ L ≤ Real.logb 2 (w : ℝ) + 1 at hoff
  have hm := PdfAsymptotics.variable_count_scale w (by omega)
  change M ≤ N / Q at hm
  have hm0 : 0 ≤ M := by dsimp [M]; positivity
  have hm1 : 1 ≤ M := by
    dsimp [M,variableCount]
    have hp : 2 ≤ 2 ^ w := Nat.pow_le_pow_right (n := 2) (by decide) (by omega : 1 ≤ w)
    have hn : 1 ≤ 2 ^ w - 1 := by omega
    exact_mod_cast hn
  have hcoeff : 72 * L + 345 ≤ 490 * H := by linarith
  have hscale := mul_le_mul hcoeff hm hm0 (by linarith : 0 ≤ 490 * H)
  have hint : 17 * N - (72 * L + 342) * M - 3 ≤ 7 * (C.size : ℝ) := by
    dsimp [N,L,M]
    exact_mod_cast seventeen_sevenths_width_bound w hw C hc
  have hsmall : 3 ≤ 3 * M := by linarith
  change (17 / 7 : ℝ) * N - 70 * N * H / Q ≤ (C.size : ℝ)
  have heq : 490 * H * (N / Q) = 490 * N * H / Q := by ring
  rw [heq] at hscale
  have hs : (72 * L + 345) * M ≤ 7 * (70 * N * H / Q) := by
    convert hscale using 1; ring
  nlinarith only [hs, hint, hsmall]

/-- Manuscript Theorem 8.2, leading asymptotic bound, along the encoded
3-SAT input lengths. -/
theorem seventeen_sevenths_asymptotic :
    ∃ E : Nat → ℝ,
      Asymptotics.IsBigO Filter.atTop E
        (fun w : Nat => (inputBits w : ℝ) * Real.logb 2 (Real.logb 2 (inputBits w)) /
          Real.logb 2 (inputBits w)) ∧
      ∀ᶠ w in Filter.atTop, ∀ C : Circuit (inputBits w),
        C.Computes (satFunction w) → (17 / 7 : ℝ) * inputBits w - E w ≤ (C.size : ℝ) := by
  let E : Nat → ℝ := fun w => 70 * ((inputBits w : ℝ) *
    Real.logb 2 (Real.logb 2 (inputBits w)) / Real.logb 2 (inputBits w))
  refine ⟨E, ?_, ?_⟩
  · apply Asymptotics.isBigO_iff.mpr
    refine ⟨70, Filter.Eventually.of_forall ?_⟩
    intro w
    simp only [E, norm_mul]
    norm_num
  · filter_upwards [Filter.eventually_ge_atTop (32 : Nat)] with w hw
    intro C hc
    convert seventeen_sevenths_logarithmic_bound w hw C hc using 1; dsimp [E]; ring

end SatLowerBound
