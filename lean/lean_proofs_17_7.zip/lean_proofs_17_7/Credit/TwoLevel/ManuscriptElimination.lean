import Credit.TwoLevel.MainBNormalized

/-! A direct interface between Lemma 7.1's semantic hypotheses and the
formal normalized fourteen-unit elimination theorem. -/
namespace SatLowerBound

/-- On a cube with at least two coordinates, S4 forces every coordinate to
be essential. -/
theorem S4.all_essential {n : Nat} (hn : 2 ≤ n)
    {f : (Fin n → Bool) → Bool} (hS4 : S4 f) : ∀ x, Essential f x := by
  intro x
  let y : Fin n := if x.val = 0 then ⟨1,by omega⟩ else ⟨0,by omega⟩
  have hyx : y ≠ x := by
    intro he
    have hv := congrArg Fin.val he
    by_cases hx : x.val = 0
    · simp [y,hx] at hv
    · simp [y,hx] at hv
      omega
  exact (hS4 x y (Ne.symm hyx)).essential_left

/-- As observed in the paper, S4 on at least two inputs forces at least
three: on a two-input cube the four cofactors would all be Boolean constants. -/
theorem S4.at_least_three {n : Nat} (hn : 2 ≤ n)
    {f : (Fin n → Bool) → Bool} (hS4 : S4 f) : 3 ≤ n := by
  by_contra hsmall
  have hn2 : n = 2 := by omega
  subst n
  let x : Fin 2 := 0
  let y : Fin 2 := 1
  have hxy : x ≠ y := by decide
  have hfix (p : Bool × Bool) (v : Fin 2 → Bool) :
      setPair v x y p.1 p.2 = setPair (fun _ => false) x y p.1 p.2 := by
    funext z
    fin_cases z <;> simp [setPair,x,y]
  let evalRow : Bool × Bool → Bool := fun p => f (setPair (fun _ => false) x y p.1 p.2)
  have hinj : Function.Injective evalRow := by
    intro p q hpq
    apply hS4 x y hxy
    funext v
    change f (setPair v x y p.1 p.2) = f (setPair v x y q.1 q.2)
    rw [hfix p v, hfix q v]
    exact hpq
  have hcard := Fintype.card_le_of_injective evalRow hinj
  norm_num at hcard

/-- For a full-support function with at least three inputs, the manuscript's
E1, E2 and S4 hypotheses imply all semantic fields of `GoodFn`. -/
theorem goodFn_of_paper_conditions {n : Nat} (hn : 3 ≤ n)
    (f : (Fin n → Bool) → Bool) (hall : ∀ x, Essential f x)
    (hE1 : E1 f) (hE2 : E2 f) (hS4 : S4 f) : GoodFn f where
  two_essential := by
    let x : Fin n := ⟨0,by omega⟩
    let y : Fin n := ⟨1,by omega⟩
    refine ⟨x,y,?_,hall x,hall y⟩
    intro h
    have hv := congrArg Fin.val h
    dsimp [x,y] at hv
    omega
  e1 := hE1
  e2 := hE2
  s3 := hS4.s3
  cofactor_nonconstant := by
    intro x b
    let z : Fin n := if x.val = 0 then ⟨1,by omega⟩ else ⟨0,by omega⟩
    have hzx : z ≠ x := by
      intro he
      have hv := congrArg Fin.val he
      by_cases hx : x.val = 0
      · simp [z,hx] at hv
      · simp [z,hx] at hv
        omega
    exact (hE1 x b z hzx (hall z)).nonconstant

/-- Lemma 7.1 for a normalized circuit computing a function that depends on
all ambient inputs: the additional `GoodFn` and used-input conditions in the
internal context follow from the manuscript's hypotheses. -/
theorem paper_one_step_elimination {n : Nat} (hn : 2 ≤ n)
    (f : (Fin n → Bool) → Bool)
    (hE1 : E1 f) (hE2 : E2 f) (hS4 : S4 f)
    (C : OpenCircuit n) (hr : C.Reduced)
    (ht : C.NoInputTriangles (fun _ => none)) (hc : ∀ v, C.eval v = f v) :
    ∃ (x : Fin n) (b : Bool) (D : OpenCircuit n),
      2 ≤ (C.users x.val).card ∧ D.Reduced ∧ D.NoInputTriangles (fun _ => none) ∧
      (∀ v, D.eval v = f (fixBit x b v)) ∧ D.psi2 + 14 ≤ C.psi2 := by
  have hn3 : 3 ≤ n := hS4.at_least_three hn
  have hall : ∀ x, Essential f x := hS4.all_essential hn
  have hctx : MAContext f C :=
    ⟨goodFn_of_paper_conditions hn3 f hall hE1 hE2 hS4,hr,ht,hc,fun z _ => hall z⟩
  obtain ⟨x,b,D,hfan,_,hD,htri,hDe,hdrop⟩ := hctx.main_lemma_B_normalized hS4.toEssential
  rw [hctx.refCount_input x] at hfan
  exact ⟨x,b,D,hfan,hD,htri,hDe,hdrop⟩

/-- On at least three coordinates, E2 already implies E1: choose a third
coordinate, use E2, then regard its witnesses as witnesses in the single
cofactor. This removes the extra E1 premise from the manuscript interface. -/
theorem E2.e1_of_three {n : Nat} (hn : 3 ≤ n)
    {f : (Fin n → Bool) → Bool} (hE2 : E2 f) : E1 f := by
  intro x b z hzx hz
  let y : Fin n := if x.val ≠ 0 ∧ z.val ≠ 0 then ⟨0,by omega⟩
    else if x.val ≠ 1 ∧ z.val ≠ 1 then ⟨1,by omega⟩ else ⟨2,by omega⟩
  have hyx : y ≠ x := by
    intro h
    have hv := congrArg Fin.val h
    have hxz : x.val ≠ z.val := fun e => hzx (Fin.ext e.symm)
    dsimp [y] at hv
    split_ifs at hv <;> dsimp only at hv <;> omega
  have hyz : y ≠ z := by
    intro h
    have hv := congrArg Fin.val h
    have hxz : x.val ≠ z.val := fun e => hzx (Fin.ext e.symm)
    dsimp [y] at hv
    split_ifs at hv <;> dsimp only at hv <;> omega
  obtain ⟨u,v,huv,hne⟩ := hE2 x y b false z (Ne.symm hyx) hzx (Ne.symm hyz) hz
  refine ⟨setPair u x y b false,setPair v x y b false,?_,?_⟩
  · intro q hq
    simp only [setPair]
    split_ifs <;> first | rfl | exact huv q hq
  · have hfix (t : Fin n → Bool) :
        fixBit x b (setPair t x y b false) = setPair t x y b false := by
      funext q
      by_cases hq : q = x <;> simp [fixBit,setPair,hq]
    change f (fixBit x b (setPair u x y b false)) ≠
      f (fixBit x b (setPair v x y b false))
    rw [hfix,hfix]
    exact hne

/-- Lemma 7.1 with exactly the paper's E2 and S4 semantic premises. -/
theorem paper_one_step_elimination_exact {n : Nat} (hn : 2 ≤ n)
    (f : (Fin n → Bool) → Bool) (hE2 : E2 f) (hS4 : S4 f)
    (C : OpenCircuit n) (hr : C.Reduced)
    (ht : C.NoInputTriangles (fun _ => none)) (hc : ∀ v, C.eval v = f v) :
    ∃ (x : Fin n) (b : Bool) (D : OpenCircuit n),
      2 ≤ (C.users x.val).card ∧ D.Reduced ∧ D.NoInputTriangles (fun _ => none) ∧
      (∀ v, D.eval v = f (fixBit x b v)) ∧ D.psi2 + 14 ≤ C.psi2 := by
  exact paper_one_step_elimination hn f
    (hE2.e1_of_three (hS4.at_least_three hn)) hE2 hS4 C hr ht hc

/-- Lemma 7.1 expressed entirely with the manuscript's distinct-successor
fan-out and potential, rather than the internal reference-count potential. -/
theorem paper_one_step_elimination_successor_potential {n : Nat} (hn : 2 ≤ n)
    (f : (Fin n → Bool) → Bool) (hE2 : E2 f) (hS4 : S4 f)
    (C : OpenCircuit n) (hr : C.Reduced)
    (ht : C.NoInputTriangles (fun _ => none)) (hc : ∀ v, C.eval v = f v) :
    ∃ (x : Fin n) (b : Bool) (D : OpenCircuit n),
      2 ≤ (C.users x.val).card ∧ D.Reduced ∧ D.NoInputTriangles (fun _ => none) ∧
      (∀ v, D.eval v = f (fixBit x b v)) ∧ D.paperPsi2 + 14 ≤ C.paperPsi2 := by
  obtain ⟨x,b,D,hx,hD,htri,heval,hdrop⟩ :=
    paper_one_step_elimination_exact hn f hE2 hS4 C hr ht hc
  rw [C.psi2_eq_paperPsi2 hr,D.psi2_eq_paperPsi2 hD] at hdrop
  exact ⟨x,b,D,hx,hD,htri,heval,hdrop⟩

/-- Potential-preserving normalization in the successor-set convention of
Definition 6.9. The used-input formulation also covers ambient coordinates
fixed during the subsequent induction. -/
theorem paper_normalization_successor_potential {n : Nat} (hn : 2 ≤ n)
    (C : OpenCircuit n) (hr : C.Reduced) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (OpenCircuit.singleUse z) → Essential C.eval z) :
    ∃ D : OpenCircuit n, D.Reduced ∧ D.NoInputTriangles (fun _ => none) ∧
      (∀ v, D.eval v = C.eval v) ∧ D.paperPsi2 ≤ C.paperPsi2 ∧ D.size ≤ C.size := by
  obtain ⟨D,hD,htri,heval,hpot,hsize⟩ :=
    C.psi2_normalize_used_essential hn hr hE1 hused
  rw [C.psi2_eq_paperPsi2 hr,D.psi2_eq_paperPsi2 hD] at hpot
  exact ⟨D,hD,htri,heval,hpot,hsize⟩

end SatLowerBound
