import Credit.TwoLevel.CompositionCofactors

/-! Robust blocks embedded on a subset of a common ambient input cube. -/
namespace SatLowerBound

def freeOn {n : Nat} (S : Finset (Fin n)) (ρ : Fin n → Option Bool) : Finset (Fin n) :=
  S.filter (fun z => ρ z = none)

/-- Robustness restricted to a block's own coordinates. -/
structure RobustOn {n : Nat} (k : Nat) (f : (Fin n → Bool) → Bool)
    (S : Finset (Fin n)) : Prop where
  supported : Supported f S
  four : ∀ ρ : Fin n → Option Bool, k ≤ (freeOn S ρ).card →
    ∀ i j, i ≠ j → i ∈ freeOn S ρ → j ∈ freeOn S ρ →
      PairFour (fun v => f (applyPartial ρ v)) i j

/-- A partial assignment leaves a block supported on its still-free bits. -/
theorem Supported.partial {n : Nat} {f : (Fin n → Bool) → Bool} {S : Finset (Fin n)}
    (hf : Supported f S) (ρ : Fin n → Option Bool) :
    Supported (fun v => f (applyPartial ρ v)) (freeOn S ρ) := by
  intro u v huv
  apply hf
  intro z hz
  unfold applyPartial
  cases hρ : ρ z with
  | none =>
    have hzfree : z ∈ freeOn S ρ := Finset.mem_filter.mpr ⟨hz,hρ⟩
    simp [huv z hzfree]
  | some b => simp

/-- Every remaining coordinate of a sufficiently large robust block is essential. -/
theorem RobustOn.free_essential {n k : Nat} {f : (Fin n → Bool) → Bool}
    {S : Finset (Fin n)} (h : RobustOn k f S) (ρ : Fin n → Option Bool)
    (hk : k ≤ (freeOn S ρ).card) (h2 : 2 ≤ (freeOn S ρ).card)
    (z : Fin n) (hz : z ∈ freeOn S ρ) : Essential (fun v => f (applyPartial ρ v)) z := by
  obtain ⟨w,hw,hwz⟩ := Finset.exists_mem_ne (show 1 < (freeOn S ρ).card by omega) z
  exact (h.four ρ hk z w (Ne.symm hwz) hz hw).essential_left

/-- A robust restricted block has the paper's S4 property on its actual
essential coordinates. -/
theorem RobustOn.restricted_s4 {n k : Nat} {f : (Fin n → Bool) → Bool}
    {S : Finset (Fin n)} (h : RobustOn k f S) (ρ : Fin n → Option Bool)
    (hk : k ≤ (freeOn S ρ).card) : S4Essential (fun v => f (applyPartial ρ v)) := by
  intro i j hij hi hj
  exact h.four ρ hk i j hij ((h.supported.partial ρ).essential_mem i hi)
    ((h.supported.partial ρ).essential_mem j hj)

theorem freeOn_partialFix {n : Nat} (S : Finset (Fin n)) (ρ : Fin n → Option Bool)
    (x : Fin n) (b : Bool) :
    freeOn S (partialFix ρ x b) = (freeOn S ρ).erase x := by
  apply Finset.ext
  intro z
  simp only [freeOn,Finset.mem_erase,Finset.mem_filter]
  change (z ∈ S ∧ (if z = x ∧ ρ z = none then some b else ρ z) = none) ↔
    z ≠ x ∧ (z ∈ S ∧ ρ z = none)
  by_cases hz : z = x
  · subst z
    cases hρ : ρ x <;> simp_all
  · simp [hz]

theorem freeOn_partialFix_card {n : Nat} (S : Finset (Fin n)) (ρ : Fin n → Option Bool)
    (x : Fin n) (b : Bool) :
    (freeOn S ρ).card ≤ (freeOn S (partialFix ρ x b)).card + 1 := by
  rw [freeOn_partialFix]
  by_cases hx : x ∈ freeOn S ρ
  · have hh := Finset.card_erase_add_one hx
    omega
  · rw [Finset.erase_eq_of_notMem hx]
    omega

/-- E1 for an embedded robust block after an arbitrary partial assignment. -/
theorem RobustOn.restricted_e1 {n k : Nat} {f : (Fin n → Bool) → Bool}
    {S : Finset (Fin n)} (h : RobustOn k f S) (ρ : Fin n → Option Bool)
    (hk : k+1 ≤ (freeOn S ρ).card) (h2 : 2 ≤ k) :
    E1 (fun v => f (applyPartial ρ v)) := by
  intro x b z hzx hz
  let τ := partialFix ρ x b
  have hc := freeOn_partialFix_card S ρ x b
  change (freeOn S ρ).card ≤ (freeOn S τ).card + 1 at hc
  have hzfree := (h.supported.partial ρ).essential_mem z hz
  have hzt : z ∈ freeOn S τ := by
    change z ∈ freeOn S (partialFix ρ x b)
    rw [freeOn_partialFix]
    exact Finset.mem_erase.mpr ⟨hzx,hzfree⟩
  have hess := h.free_essential τ (by omega) (by omega) z hzt
  have heq : (fun v => f (applyPartial τ v)) =
      (fun v => f (applyPartial ρ (fixBit x b v))) := by
    funext v
    rw [applyPartial_fixBit]
  rwa [heq] at hess

/-- E2 for an embedded robust block. -/
theorem RobustOn.restricted_e2 {n k : Nat} {f : (Fin n → Bool) → Bool}
    {S : Finset (Fin n)} (h : RobustOn k f S) (ρ : Fin n → Option Bool)
    (hk : k+2 ≤ (freeOn S ρ).card) (h2 : 2 ≤ k) :
    E2 (fun v => f (applyPartial ρ v)) := by
  intro x y a b z _hxy hzx hzy hz
  let τ := partialFix ρ x a
  have hc := freeOn_partialFix_card S ρ x a
  change (freeOn S ρ).card ≤ (freeOn S τ).card + 1 at hc
  have he1 := h.restricted_e1 ρ (by omega) h2
  have he1τ := h.restricted_e1 τ (by omega) h2
  have hz₁ := he1 x a z hzx hz
  have heq : (fun v => f (applyPartial τ v)) =
      (fun v => f (applyPartial ρ (fixBit x a v))) := by
    funext v
    rw [applyPartial_fixBit]
  have hzτ : Essential (fun v => f (applyPartial τ v)) z := by rw [heq]; exact hz₁
  have hz₂ := he1τ y b z hzy hzτ
  rw [heq] at hz₂
  have heval : (fun v => f (applyPartial ρ (fixBit x a (fixBit y b v)))) =
      (fun v => f (applyPartial ρ (setPair v x y a b))) := by
    funext v
    rw [ModularTree.setPair_eq_fixBit]
  rwa [heval] at hz₂

theorem RobustOn.restricted_nonconstant {n k : Nat} {f : (Fin n → Bool) → Bool}
    {S : Finset (Fin n)} (h : RobustOn k f S) (ρ : Fin n → Option Bool)
    (hk : k ≤ (freeOn S ρ).card) (h2 : 2 ≤ (freeOn S ρ).card) :
    Nonconstant (fun v => f (applyPartial ρ v)) := by
  obtain ⟨z,hz⟩ := Finset.card_pos.mp (by omega : 0 < (freeOn S ρ).card)
  exact (h.free_essential ρ hk h2 z hz).nonconstant

/-- Robust blocks satisfy every leaf invariant used by the composition proof. -/
theorem RobustOn.restricted_dependence {n k : Nat} {f : (Fin n → Bool) → Bool}
    {S : Finset (Fin n)} (h : RobustOn k f S) (ρ : Fin n → Option Bool)
    (hk : k+2 ≤ (freeOn S ρ).card) (h2 : 2 ≤ k) :
    CompositionDependence (fun v => f (applyPartial ρ v)) (freeOn S ρ) := by
  refine ⟨h.supported.partial ρ,?_,h.restricted_nonconstant ρ (by omega) (by omega),
    h.restricted_e1 ρ (by omega) h2,h.restricted_e2 ρ hk h2,h.restricted_s4 ρ (by omega),?_,?_⟩
  · intro z hz
    exact h.free_essential ρ (by omega) (by omega) z hz
  · intro x a
    let τ := partialFix ρ x a
    have hc := freeOn_partialFix_card S ρ x a
    change (freeOn S ρ).card ≤ (freeOn S τ).card + 1 at hc
    have hn := h.restricted_nonconstant τ (by omega) (by omega)
    have heq : (fun v => f (applyPartial τ v)) =
        (fun v => f (applyPartial ρ (fixBit x a v))) := by
      funext v
      rw [applyPartial_fixBit]
    rwa [heq] at hn
  · intro x y a b _hxy
    let τ := partialFix ρ x a
    let υ := partialFix τ y b
    have hc1 := freeOn_partialFix_card S ρ x a
    change (freeOn S ρ).card ≤ (freeOn S τ).card + 1 at hc1
    have hc2 := freeOn_partialFix_card S τ y b
    change (freeOn S τ).card ≤ (freeOn S υ).card + 1 at hc2
    have hn := h.restricted_nonconstant υ (by omega) (by omega)
    have heq : (fun v => f (applyPartial υ v)) =
        (fun v => f (applyPartial ρ (setPair v x y a b))) := by
      funext v
      rw [ModularTree.setPair_eq_fixBit,applyPartial_fixBit,applyPartial_fixBit]
    rwa [heq] at hn

/-- The weaker invariants that remain when a leaf reaches the retirement threshold. -/
structure OneDependence {n : Nat} (f : (Fin n → Bool) → Bool) (S : Finset (Fin n)) : Prop where
  supported : Supported f S
  essential : ∀ x ∈ S, Essential f x
  nonconstant : Nonconstant f
  e1 : E1 f
  one_nonconstant : ∀ x a, Nonconstant (fun v => f (fixBit x a v))

theorem OneDependence.combine {n : Nat} (p : Bool)
    {f g : (Fin n → Bool) → Bool} {S T : Finset (Fin n)}
    (hf : OneDependence f S) (hg : OneDependence g T) (hd : Disjoint S T) :
    OneDependence (fun v => combine p (f v) (g v)) (S ∪ T) := by
  refine ⟨supported_combine p f g S T hf.supported hg.supported,?_,?_,?_,?_⟩
  · intro x hx
    rcases Finset.mem_union.mp hx with hxS | hxT
    · exact combine_essential_left p f g S T hf.supported hg.supported hd hg.nonconstant x (hf.essential x hxS)
    · exact combine_essential_right p f g S T hf.supported hg.supported hd hf.nonconstant x (hg.essential x hxT)
  · exact combine_nonconstant p f g S T hf.supported hg.supported hd hf.nonconstant hg.nonconstant
  · exact combine_e1 p f g S T hf.supported hg.supported hd hf.essential hg.essential
      hf.e1 hg.e1 hf.one_nonconstant hg.one_nonconstant
  · intro x b
    exact combine_nonconstant p _ _ S T (hf.supported.cofactor x b) (hg.supported.cofactor x b) hd
      (hf.one_nonconstant x b) (hg.one_nonconstant x b)

theorem RobustOn.restricted_oneDependence {n k : Nat} {f : (Fin n → Bool) → Bool}
    {S : Finset (Fin n)} (h : RobustOn k f S) (ρ : Fin n → Option Bool)
    (hk : k+1 ≤ (freeOn S ρ).card) (h2 : 2 ≤ k) :
    OneDependence (fun v => f (applyPartial ρ v)) (freeOn S ρ) := by
  refine ⟨h.supported.partial ρ,?_,h.restricted_nonconstant ρ (by omega) (by omega),
    h.restricted_e1 ρ hk h2,?_⟩
  · intro z hz
    exact h.free_essential ρ (by omega) (by omega) z hz
  · intro x a
    let τ := partialFix ρ x a
    have hc := freeOn_partialFix_card S ρ x a
    change (freeOn S ρ).card ≤ (freeOn S τ).card + 1 at hc
    have hn := h.restricted_nonconstant τ (by omega) (by omega)
    have heq : (fun v => f (applyPartial τ v)) =
        (fun v => f (applyPartial ρ (fixBit x a v))) := by
      funext v
      rw [applyPartial_fixBit]
    rwa [heq] at hn

/-- A read-once AND/OR composition with arbitrary robust leaf functions. -/
inductive RobustTree (n : Nat) where
  | leaf (f : (Fin n → Bool) → Bool) (S : Finset (Fin n))
  | branch (isOr : Bool) (left right : RobustTree n)

namespace RobustTree

def eval {n : Nat} : RobustTree n → (Fin n → Bool) → Bool
  | .leaf f _, v => f v
  | .branch p a b, v => combine p (a.eval v) (b.eval v)

def support {n : Nat} : RobustTree n → Finset (Fin n)
  | .leaf _ S => S
  | .branch _ a b => a.support ∪ b.support

def Valid {n : Nat} (k : Nat) (ρ : Fin n → Option Bool) : RobustTree n → Prop
  | .leaf f S => RobustOn k f S ∧ k+2 ≤ (freeOn S ρ).card
  | .branch _ a b => a.Valid k ρ ∧ b.Valid k ρ ∧ Disjoint a.support b.support

def ValidOne {n : Nat} (k : Nat) (ρ : Fin n → Option Bool) : RobustTree n → Prop
  | .leaf f S => RobustOn k f S ∧ k+1 ≤ (freeOn S ρ).card
  | .branch _ a b => a.ValidOne k ρ ∧ b.ValidOne k ρ ∧ Disjoint a.support b.support

theorem Valid.toValidOne {n k : Nat} {ρ : Fin n → Option Bool} {T : RobustTree n}
    (h : T.Valid k ρ) : T.ValidOne k ρ := by
  induction T with
  | leaf f S =>
    change RobustOn k f S ∧ k+2 ≤ (freeOn S ρ).card at h
    exact ⟨h.1,by omega⟩
  | branch p a b iha ihb => exact ⟨iha h.1,ihb h.2.1,h.2.2⟩

theorem freeOn_subset {n : Nat} (S : Finset (Fin n)) (ρ : Fin n → Option Bool) :
    freeOn S ρ ⊆ S := Finset.filter_subset _ _

theorem freeOn_union {n : Nat} (S T : Finset (Fin n)) (ρ : Fin n → Option Bool) :
    freeOn (S ∪ T) ρ = freeOn S ρ ∪ freeOn T ρ := by
  simp only [freeOn,Finset.filter_union]

/-- Lemma 5.8's E1, E2 and S4 properties for the full robust composition,
including inputs already fixed by the ambient partial assignment. -/
theorem restricted_dependence {n k : Nat} (T : RobustTree n) (ρ : Fin n → Option Bool)
    (hk : 2 ≤ k) (hT : T.Valid k ρ) :
    CompositionDependence (fun v => T.eval (applyPartial ρ v)) (freeOn T.support ρ) := by
  induction T with
  | leaf f S => exact hT.1.restricted_dependence ρ hT.2 hk
  | branch p a b iha ihb =>
    have ha := iha hT.1
    have hb := ihb hT.2.1
    have hd : Disjoint (freeOn a.support ρ) (freeOn b.support ρ) := by
      apply Finset.disjoint_left.mpr
      intro z hz₁ hz₂
      exact Finset.disjoint_left.mp hT.2.2 (freeOn_subset a.support ρ hz₁)
        (freeOn_subset b.support ρ hz₂)
    have hh := ha.combine p hb hd
    simpa only [eval,support,freeOn_union] using hh

/-- The composition still has E1 at the paper's retirement threshold. -/
theorem restricted_oneDependence {n k : Nat} (T : RobustTree n) (ρ : Fin n → Option Bool)
    (hk : 2 ≤ k) (hT : T.ValidOne k ρ) :
    OneDependence (fun v => T.eval (applyPartial ρ v)) (freeOn T.support ρ) := by
  induction T with
  | leaf f S => exact hT.1.restricted_oneDependence ρ hT.2 hk
  | branch p a b iha ihb =>
    have ha := iha hT.1
    have hb := ihb hT.2.1
    have hd : Disjoint (freeOn a.support ρ) (freeOn b.support ρ) := by
      apply Finset.disjoint_left.mpr
      intro z hz₁ hz₂
      exact Finset.disjoint_left.mp hT.2.2 (freeOn_subset a.support ρ hz₁)
        (freeOn_subset b.support ρ hz₂)
    have hh := ha.combine p hb hd
    simpa only [eval,support,freeOn_union] using hh

end RobustTree
end SatLowerBound
