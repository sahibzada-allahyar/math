import Credit.TwoLevel.ChargeCap
import Credit.TwoLevel.Eliminated

/-! The shared second-gate survival argument for the no-fixed-D-input case. -/
namespace SatLowerBound
namespace OpenCircuit

/-- A credited first gate resolves either to itself (if kept) or to a literal
of its input (if eliminated), assuming the restricted function retains that
input essentially. -/
theorem first_credit_gate_resolution {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (z : Fin n) (W : Nat)
    (hD : C.isD z.val = true) (hW : W ∈ C.users z.val)
    (hess : Essential (C.restrict (fixSubst P c)).eval z) :
    ∃ s neg, C.resAt (fixRes P c) W = .lit s neg ∧ (s = W ∨ s = z.val) := by
  obtain ⟨g,a,b,hgate,_⟩ := C.mem_users.mp hW
  cases hk : C.isKept (fixRes P c) W with
  | true => exact ⟨W,false,C.resAt_kept _ hk,Or.inl rfl⟩
  | false =>
    have hal : C.isAliased (fixRes P c) W = true := by
      have h := C.isKept_eq_not_isAliased (fixRes P c) hgate
      rw [hk] at h
      cases hv : C.isAliased (fixRes P c) W with
      | false => rw [hv] at h; contradiction
      | true => rfl
    have hhit := C.eliminated_unique_reader_must_pass P c hr z W hD hW hal hess
    cases hv : C.resAt (fixRes P c) W with
    | const b => simp [hv, Res.hits] at hhit
    | lit s neg =>
      have heq : s = z.val := by simpa [hv, Res.hits] using hhit
      exact ⟨s,neg,rfl,Or.inr heq⟩

/-- A common second credited gate for two distinct essential inputs is retained
by the restriction compiler. This proves the non-elimination step in the
paper's one-charge-per-gate argument. -/
theorem shared_second_gate_isKept {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (hsafe : C.DGateSafe)
    (z₁ z₂ : Fin n) (hz : z₁ ≠ z₂) (W₁ W₂ G : Nat)
    (hD₁ : C.isD z₁.val = true) (hD₂ : C.isD z₂.val = true)
    (hW₁ : W₁ ∈ C.users z₁.val) (hW₂ : W₂ ∈ C.users z₂.val)
    (hG₁ : G ∈ C.users W₁) (hG₂ : G ∈ C.users W₂)
    (he₁ : Essential (C.restrict (fixSubst P c)).eval z₁)
    (he₂ : Essential (C.restrict (fixSubst P c)).eval z₂) :
    C.isKept (fixRes P c) G = true := by
  have hWne : W₁ ≠ W₂ := by
    intro he
    have hread₂ : W₁ ∈ C.users z₂.val := by simpa [he] using hW₂
    exact hz (C.first_reader_unique hsafe hD₁ hD₂ hW₁ hread₂)
  obtain ⟨t₁,a₁,b₁,ht₁,_⟩ := C.mem_users.mp hW₁
  obtain ⟨t₂,a₂,b₂,ht₂,_⟩ := C.mem_users.mp hW₂
  have hn₁ : n ≤ W₁ := (C.gateAt_bounds ht₁).1
  have hn₂ : n ≤ W₂ := (C.gateAt_bounds ht₂).1
  obtain ⟨s₁,neg₁,hr₁,hsrc₁⟩ := C.first_credit_gate_resolution P c hr z₁ W₁ hD₁ hW₁ he₁
  obtain ⟨s₂,neg₂,hr₂,hsrc₂⟩ := C.first_credit_gate_resolution P c hr z₂ W₂ hD₂ hW₂ he₂
  have hsrcne : s₁ ≠ s₂ := by
    have hne : z₁.val ≠ z₂.val := fun he => hz (Fin.ext he)
    have hlt₁ := z₁.isLt
    have hlt₂ := z₂.isLt
    rcases hsrc₁ with rfl | rfl <;> rcases hsrc₂ with rfl | rfl <;> omega
  obtain ⟨g,a,b,hgate,hab₁⟩ := C.mem_users.mp hG₁
  obtain ⟨g',a',b',hgate',hab₂⟩ := C.mem_users.mp hG₂
  rw [hgate] at hgate'
  simp only [Option.some.injEq, Prod.mk.injEq] at hgate'
  obtain ⟨_,ha,hb⟩ := hgate'
  rw [← ha, ← hb] at hab₂
  have hg : g.essential = true := (C.reduced_gate hr hgate).1
  unfold isKept
  rw [hgate]
  simp only
  rcases hab₁ with ha₁ | hb₁ <;> rcases hab₂ with ha₂ | hb₂
  · omega
  · rw [ha₁, hb₂, hr₁, hr₂, Res.step_kept g hg s₁ s₂ hsrcne neg₁ neg₂]
    rfl
  · rw [hb₁, ha₂, hr₁, hr₂, Res.step_kept g hg s₂ s₁ hsrcne.symm neg₂ neg₁]
    rfl
  · omega

/-- An eliminated gate cannot be the second credited gate for two distinct
inputs that both remain essential. -/
theorem eliminated_second_role_card_le_one {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (hsafe : C.DGateSafe)
    (W V : Fin n → Nat)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b))
    (halias : C.isAliased (fixRes P c) k = true) :
    ((Finset.univ : Finset (Fin n)).filter
      (fun z => C.isDStar z.val = true ∧ V z = k)).card ≤ 1 := by
  apply Finset.card_le_one.mpr
  intro z₁ hz₁ z₂ hz₂
  have h₁ := (Finset.mem_filter.mp hz₁).2
  have h₂ := (Finset.mem_filter.mp hz₂).2
  by_contra hne
  have hd₁ := C.isD_of_isDStar z₁.val h₁.1
  have hd₂ := C.isD_of_isDStar z₂.val h₂.1
  have hg₁ : k ∈ C.users (W z₁) := by simpa [h₁.2] using hv z₁ h₁.1
  have hg₂ : k ∈ C.users (W z₂) := by simpa [h₂.2] using hv z₂ h₂.1
  have hkept := C.shared_second_gate_isKept P c hr hsafe z₁ z₂ hne (W z₁) (W z₂) k
    hd₁ hd₂ (hw z₁ hd₁) (hw z₂ hd₂) hg₁ hg₂ (hess z₁ h₁.1) (hess z₂ h₂.1)
  have h := C.isKept_eq_not_isAliased (fixRes P c) hk
  rw [hkept, halias] at h
  contradiction

/-- An eliminated gate receives at most one second-role charge. -/
theorem gateSecondCharge_le_one_of_alias {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (hsafe : C.DGateSafe)
    (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b))
    (halias : C.isAliased (fixRes P c) k = true) :
    C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V k ≤ 1 := by
  let D := C.restrict (fixSubst P c)
  let ρ := fixRes P c
  let S := (Finset.univ : Finset (Fin n)).filter (fun z => V z = k)
  let T := (Finset.univ : Finset (Fin n)).filter
    (fun z => C.isDStar z.val = true ∧ V z = k)
  have hsub : T ⊆ S := by
    intro z hz
    simp only [T, S, Finset.mem_filter, Finset.mem_univ, true_and] at hz ⊢
    exact hz.2
  have heq : (∑ z ∈ T, C.secondGateCharge D ρ W z) =
      ∑ z ∈ S, C.secondGateCharge D ρ W z := by
    apply Finset.sum_subset hsub
    intro z hzS hzT
    have hs : C.isDStar z.val = false := by
      cases h : C.isDStar z.val with
      | false => rfl
      | true =>
        exfalso
        apply hzT
        simp only [T, S, Finset.mem_filter, Finset.mem_univ, true_and] at hzS ⊢
        exact ⟨h,hzS⟩
    have hb := C.free_second_charge_bound P c hr W V hfree hw hv hess z
    simp [indicator, hs] at hb
    exact hb
  have hsum : (∑ z ∈ T, C.secondGateCharge D ρ W z) ≤ T.card := by
    have h := Finset.sum_le_card_nsmul T (fun z => C.secondGateCharge D ρ W z) 1 (by
      intro z _
      have hb := C.free_second_charge_bound P c hr W V hfree hw hv hess z
      change C.secondGateCharge (C.restrict (fixSubst P c)) (fixRes P c) W z ≤ 1
      have hprod : indicator (C.isDStar z.val) *
          indicator (C.isAliased (fixRes P c) (V z)) ≤ 1 := by
        cases C.isDStar z.val <;> cases C.isAliased (fixRes P c) (V z) <;> decide
      exact le_trans hb hprod)
    simpa using h
  have hcard := C.eliminated_second_role_card_le_one P c hr hsafe W V hw hv hess k g a b hk halias
  change S.sum (fun z => C.secondGateCharge D ρ W z) ≤ 1
  rw [← heq]
  exact le_trans hsum hcard


/-- The manuscript's one-charge cap for an eliminated gate when all
credited inputs remain free and essential. -/
theorem free_eliminated_gate_total_charge_le_one {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (hsafe : C.DGateSafe)
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (horig : ∀ z, C.isDStar z.val = true → Essential f z)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b))
    (halias : C.isAliased (fixRes P c) k = true) :
    C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k +
      C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V k ≤ 1 := by
  let D := C.restrict (fixSubst P c)
  let ρ := fixRes P c
  change C.gateFirstCharge D ρ W k + C.gateSecondCharge D ρ W V k ≤ 1
  by_cases hf : ∃ z, C.isD z.val = true ∧ W z = k
  · obtain ⟨z₁, hz₁, hkW⟩ := hf
    have hsecondZero : C.gateSecondCharge D ρ W V k = 0 := by
      unfold gateSecondCharge
      apply Finset.sum_eq_zero
      intro z hz
      have hVk : V z = k := (Finset.mem_filter.mp hz).2
      have hstar : C.isDStar z.val = false := by
        cases hs : C.isDStar z.val with
        | false => rfl
        | true =>
          exfalso
          have hfirst : k ∈ C.users z₁.val := by simpa [hkW] using hw z₁ hz₁
          have hsecond : k ∈ C.users (W z) := by simpa [hVk] using hv z hs
          exact C.first_second_roles_disjoint hr f hc hE1 z₁ z (W z) k (horig z hs)
            hfirst hs (hw z (C.isD_of_isDStar z.val hs)) hsecond
      have hbound := C.free_second_charge_bound P c hr W V hfree hw hv hess z
      simp [indicator, hstar] at hbound
      exact hbound
    have hfirst := C.gateFirstCharge_le_one D ρ hsafe W hw k
    rw [hsecondZero]
    omega
  · have hfirstZero : C.gateFirstCharge D ρ W k = 0 := by
      unfold gateFirstCharge
      apply Finset.sum_eq_zero
      intro z hz
      have hWk : W z = k := (Finset.mem_filter.mp hz).2
      have hDz : C.isD z.val = false := by
        apply Bool.eq_false_iff.mpr
        intro hd
        exact hf ⟨z,hd,hWk⟩
      have hbound := C.first_charge_bound D ρ W z
      simp [indicator, hDz] at hbound
      exact hbound
    have hsecond := C.gateSecondCharge_le_one_of_alias P c hr hsafe W V hfree hw hv hess k g a b hk halias
    change C.gateFirstCharge D ρ W k + C.gateSecondCharge D ρ W V k ≤ 1
    rw [hfirstZero]
    simpa only [Nat.zero_add] using hsecond


end OpenCircuit
end SatLowerBound
