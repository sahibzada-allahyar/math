import Credit.TwoLevel.ExactCounting
import Credit.TwoLevel.NetworkSemantics

/-! The finite statement (5) in its printed ceiling form, and the sharp
logarithmic bound, for arbitrary labelled acyclic circuits. -/
namespace SatLowerBound

/-- Equation (5), with the ceiling and the exact counting hypothesis of the PDF. -/
theorem paper_finite_ceiling_bound (w r k : Nat)
    (hw : 2 ≤ w) (hrw : r < w) (hr : 4 ≤ r) (hk : 3 ≤ k) (hkr : k + 2 ≤ r)
    (hlog : (2 : ℝ) ^ (k - 2) >
      Real.logb 2 (6 * (r : ℝ) * ((r : ℝ) - 1)) + (r : ℝ) * Real.logb 2 3)
    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    (inputBits w : ℤ) +
      ⌈((30 * (r : ℝ) - 42 * ((k : ℝ) + 1)) *
        ((variableCount w : ℝ) - (2 : ℝ) ^ r) - 3) / 7⌉ ≤ (C.size : ℤ) := by
  have h := finite_paper_bound_log_condition w r k hw hrw hr hk hkr hlog C hc
  have hreal : 7 * (inputBits w : ℝ) +
      (30 * (r : ℝ) - 42 * ((k : ℝ) + 1)) *
        ((variableCount w : ℝ) - (2 : ℝ) ^ r) - 3 ≤ 7 * (C.size : ℝ) := by
    exact_mod_cast h
  have hceil :
      ⌈((30 * (r : ℝ) - 42 * ((k : ℝ) + 1)) *
        ((variableCount w : ℝ) - (2 : ℝ) ^ r) - 3) / 7⌉ ≤
          (C.size : ℤ) - (inputBits w : ℤ) := by
    apply Int.ceil_le.mpr
    push_cast
    linarith
  omega

/-- The main logarithmic-remainder bound for the original graph-equation
semantics, including arbitrary sharing and labelling of gates. -/
theorem paper_logarithmic_bound_graph_equations (w : Nat) (hw : 32 ≤ w)
    (s : Nat) (N : AcyclicNetwork (inputBits w) s)
    (hN : ∀ v, ∃ gates, N.GateConsistent v gates ∧
      AcyclicNetwork.wireValue v gates N.output = satFunction w v) :
    (17 / 7 : ℝ) * inputBits w -
      70 * inputBits w * Real.logb 2 (Real.logb 2 (inputBits w)) /
        Real.logb 2 (inputBits w) ≤ (s : ℝ) := by
  have hc : N.toOrdered.toCircuit.Computes (satFunction w) := by
    intro v
    rw [N.compiled_eval]
    obtain ⟨gates,hg,hout⟩ := hN v
    exact (N.graphEval_eq_of_consistent v gates hg).trans hout
  simpa [N.compiled_size] using seventeen_sevenths_logarithmic_bound w hw N.toOrdered.toCircuit hc

/-- The finite ceiling bound for arbitrary labelled acyclic networks. -/
theorem paper_finite_ceiling_bound_graph_equations (w r k : Nat)
    (hw : 2 ≤ w) (hrw : r < w) (hr : 4 ≤ r) (hk : 3 ≤ k) (hkr : k + 2 ≤ r)
    (hlog : (2 : ℝ) ^ (k - 2) >
      Real.logb 2 (6 * (r : ℝ) * ((r : ℝ) - 1)) + (r : ℝ) * Real.logb 2 3)
    (s : Nat) (N : AcyclicNetwork (inputBits w) s)
    (hN : ∀ v, ∃ gates, N.GateConsistent v gates ∧
      AcyclicNetwork.wireValue v gates N.output = satFunction w v) :
    (inputBits w : ℤ) +
      ⌈((30 * (r : ℝ) - 42 * ((k : ℝ) + 1)) *
        ((variableCount w : ℝ) - (2 : ℝ) ^ r) - 3) / 7⌉ ≤ (s : ℤ) := by
  have hc : N.toOrdered.toCircuit.Computes (satFunction w) := by
    intro v
    rw [N.compiled_eval]
    obtain ⟨gates,hg,hout⟩ := hN v
    exact (N.graphEval_eq_of_consistent v gates hg).trans hout
  simpa [N.compiled_size] using
    paper_finite_ceiling_bound w r k hw hrw hr hk hkr hlog N.toOrdered.toCircuit hc

end SatLowerBound
