import Credit.TwoLevel.BalandraudDetNonzero

/-! The determinant split at a single missing row. -/
namespace SatLowerBound

/-- Removing either of two adjacent positions gives the same row everywhere
except at the index between them. -/
theorem adjacent_succAbove_eq_except {n : Nat} (g i : Fin n) (h : i ≠ g) :
    g.castSucc.succAbove i = g.succ.succAbove i := by
  rcases lt_or_gt_of_ne h with hlt | hgt
  · rw [Fin.succAbove_castSucc_of_lt g i hlt,
      Fin.succAbove_succ_of_le g i (le_of_lt hlt)]
  · rw [Fin.succAbove_castSucc_of_le g i (le_of_lt hgt),
      Fin.succAbove_succ_of_lt g i hgt]

/-- The determinant with the gap-row equal to the sum of the two adjacent
rows splits into the two determinants with one adjacent row omitted. -/
theorem det_adjacent_gap_split {R : Type} [CommRing R] {n : Nat}
    (g : Fin n) (v : Fin (n + 1) → Fin n → R) :
    let B : Matrix (Fin n) (Fin n) R := Matrix.of fun i j => v (g.castSucc.succAbove i) j
    let C : Matrix (Fin n) (Fin n) R := Matrix.of fun i j => v (g.succ.succAbove i) j
    (B.updateRow g (B g + C g)).det = B.det + C.det := by
  classical
  dsimp only
  let B : Matrix (Fin n) (Fin n) R := Matrix.of fun i j => v (g.castSucc.succAbove i) j
  let C : Matrix (Fin n) (Fin n) R := Matrix.of fun i j => v (g.succ.succAbove i) j
  change (B.updateRow g (B g + C g)).det = B.det + C.det
  have heq : B.updateRow g (C g) = C := by
    ext i j
    by_cases h : i = g
    · subst i
      simp
    · rw [Matrix.updateRow_ne h]
      simp only [B, C, Matrix.of_apply, adjacent_succAbove_eq_except g i h]
  rw [Matrix.det_updateRow_add]
  simp only [Matrix.updateRow_eq_self, heq]

/-- A single gap between consecutive rows produces the sum of the two
adjacent smaller difference determinants. This is the determinant step in
the missing-index recurrence. -/
theorem det_one_gap_row_differences {R : Type} [CommRing R] {n : Nat}
    (g : Fin n) (f : Nat → Fin n → R) :
    let A : Matrix (Fin (n + 1)) (Fin (n + 1)) R := Matrix.of fun i j =>
      Fin.cases 1 (fun k => f (if i.val ≤ g.val then i.val else i.val + 1) k) j
    let v : Fin (n + 1) → Fin n → R := fun i j => f (i.val + 1) j - f i.val j
    let B : Matrix (Fin n) (Fin n) R := Matrix.of fun i j => v (g.castSucc.succAbove i) j
    let C : Matrix (Fin n) (Fin n) R := Matrix.of fun i j => v (g.succ.succAbove i) j
    A.det = B.det + C.det := by
  classical
  dsimp only
  let A : Matrix (Fin (n + 1)) (Fin (n + 1)) R := Matrix.of fun i j =>
    Fin.cases 1 (fun k => f (if i.val ≤ g.val then i.val else i.val + 1) k) j
  let v : Fin (n + 1) → Fin n → R := fun i j => f (i.val + 1) j - f i.val j
  let B : Matrix (Fin n) (Fin n) R := Matrix.of fun i j => v (g.castSucc.succAbove i) j
  let C : Matrix (Fin n) (Fin n) R := Matrix.of fun i j => v (g.succ.succAbove i) j
  change A.det = B.det + C.det
  have hfirst : ∀ i, A i 0 = 1 := by intro i; rfl
  rw [det_eq_det_successive_row_differences A hfirst]
  have hmatrix : (Matrix.of fun i j : Fin n =>
      A i.succ j.succ - A (Fin.castSucc i) j.succ) = B.updateRow g (B g + C g) := by
    ext i j
    by_cases hi : i = g
    · subst i
      simp [A, B, C, v, Fin.succAbove, Fin.lt_def, -Fin.val_fin_lt]
    · rw [Matrix.updateRow_ne hi]
      rcases lt_or_gt_of_ne hi with hlt | hgt
      · have h3 : i.val < g.val := hlt
        simp [A, B, v, Fin.succAbove, Fin.lt_def, -Fin.val_fin_lt,
          (le_of_lt hlt : i ≤ g), h3]
      · have h3 : ¬ i.val < g.val := by omega
        simp [A, B, v, Fin.succAbove, Fin.lt_def, -Fin.val_fin_lt,
          (not_le_of_gt hgt : ¬ i ≤ g), h3, Nat.add_assoc]
  rw [hmatrix]
  exact det_adjacent_gap_split g v

/-- Pascal's identity specializes the one-gap split to binomial
coefficients, yielding the missing-index determinant recurrence. -/
theorem binomial_det_one_gap (n x : Nat) (g : Fin n) (b : Fin n → Nat) :
    (Matrix.of (fun i j : Fin (n + 1) => Fin.cases (1 : ℤ)
      (fun k => (Nat.choose (x + (if i.val ≤ g.val then i.val else i.val + 1))
        (b k + 1) : ℤ)) j)).det =
    (Matrix.of (fun i j : Fin n =>
      (Nat.choose (x + (g.castSucc.succAbove i).val) (b j) : ℤ))).det +
    (Matrix.of (fun i j : Fin n =>
      (Nat.choose (x + (g.succ.succAbove i).val) (b j) : ℤ))).det := by
  classical
  have hd (r : Nat) (j : Fin n) :
      (Nat.choose (x + (r + 1)) (b j + 1) : ℤ) -
        (Nat.choose (x + r) (b j + 1) : ℤ) =
      (Nat.choose (x + r) (b j) : ℤ) := by
    have hh : (Nat.choose (x + r + 1) (b j + 1) : ℤ) =
        (Nat.choose (x + r) (b j) : ℤ) +
          (Nat.choose (x + r) (b j + 1) : ℤ) := by
      exact_mod_cast Nat.choose_succ_succ (x + r) (b j)
    simp only [Nat.add_assoc] at *
    omega
  have h := det_one_gap_row_differences g
    (fun r j => (Nat.choose (x + r) (b j + 1) : ℤ))
  simpa only [hd] using h

end SatLowerBound
