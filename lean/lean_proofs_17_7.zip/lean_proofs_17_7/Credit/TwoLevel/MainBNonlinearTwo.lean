import Credit.TwoLevel.MainBNonlinearDeg

/-! Non-tight branches when the two operands of the first nonlinear gate
have exactly two readers. -/
namespace SatLowerBound
namespace MAContext
open OpenCircuit

/-- Four eliminated gates suffice when two are distinct direct readers of
the fixed input. Parity readers contribute seven; nonlinear readers are
role-free and contribute four. -/
theorem four_eliminated_two_readers_drop {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x : Fin n) (b : Bool)
    (hx2 : 2 ≤ C.refCount x.val) (E : Finset Nat) (hcard : 4 ≤ E.card)
    (hE : ∀ k ∈ E, C.isAliased (singleRes x b) k = true)
    (P Q : Nat) (hPQ : P ≠ Q) (hPE : P ∈ E) (hQE : Q ∈ E)
    (hPx : P ∈ C.users x.val) (hQx : Q ∈ C.users x.val) :
    (C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2 := by
  have hsub : E ⊆ Finset.range (n + C.size) := by
    intro k hk
    have ha := hE k hk
    cases hg : C.gateAt k with
    | none => simp [OpenCircuit.isAliased, hg] at ha
    | some p =>
      obtain ⟨g,a,d⟩ := p
      exact Finset.mem_range.mpr (C.gateAt_bounds hg).2.1
  have hcount := C.aliasedCount_ge_card (singleRes x b) E hsub hE
  by_cases hp : (C.tableAt P).parity = true ∨ (C.tableAt Q).parity = true
  · obtain ⟨K,hK,hKp⟩ : ∃ K ∈ E, (C.tableAt K).parity = true := by
      rcases hp with hp | hq
      · exact ⟨P,hPE,hp⟩
      · exact ⟨Q,hQE,hq⟩
    have hKsub : ({K} : Finset Nat) ⊆ Finset.range (n + C.size) := by
      intro k hk
      rw [Finset.mem_singleton.mp hk]
      exact hsub hK
    have hpc := C.aliasedParityCount_ge_card (singleRes x b) {K} hKsub (by
      intro k hk
      rw [Finset.mem_singleton.mp hk]
      exact ⟨hE K hK,hKp⟩)
    simp at hpc
    have hd := h.twoLevel_single_drop x b hx2
    omega
  · have hPpar : (C.tableAt P).parity = false := Bool.eq_false_iff.mpr (fun he => hp (Or.inl he))
    have hQpar : (C.tableAt Q).parity = false := Bool.eq_false_iff.mpr (fun he => hp (Or.inr he))
    have hd := h.twoLevel_single_drop_with_readers x b hx2 {P,Q} (by
      intro k hk
      simp only [Finset.mem_insert, Finset.mem_singleton] at hk
      rcases hk with he | he
      · rw [he]; exact ⟨hPx,hE P hPE,hPpar⟩
      · rw [he]; exact ⟨hQx,hE Q hQE,hQpar⟩)
    simp only [Finset.card_pair hPQ, Nat.cast_ofNat] at hd
    omega

namespace TwoLevelTwoAux

/-- A reader of `s` is a gate after `s`. -/
private theorem lt_of_mem_users {n : Nat} (C : OpenCircuit n) {s k : Nat}
    (hk : k ∈ C.users s) : s < k ∧ n ≤ k ∧ k < n + C.size := by
  obtain ⟨g, a, b, hg, hab⟩ := C.mem_users.mp hk
  have hb := C.gateAt_bounds hg
  rcases hab with hab | hab <;> omega

/-- A gate reading the two different signals `s, s'` reads exactly them. -/
private theorem operands_of_two {n : Nat} (C : OpenCircuit n) {s s' k : Nat} (hss : s ≠ s')
    (hs : k ∈ C.users s) (hs' : k ∈ C.users s') :
    ∃ g a b, C.gateAt k = some (g, a, b) ∧ ((a = s ∧ b = s') ∨ (a = s' ∧ b = s)) := by
  obtain ⟨g, a, b, hk, hab⟩ := C.mem_users.mp hs
  obtain ⟨g', a', b', hk', hab'⟩ := C.mem_users.mp hs'
  rw [hk] at hk'
  simp only [Option.some.injEq, Prod.mk.injEq] at hk'
  obtain ⟨-, ha, hb⟩ := hk'
  rw [← ha, ← hb] at hab'
  exact ⟨g, a, b, hk, by omega⟩

/-- A gate both of whose operands resolve to constants resolves to a constant. -/
private theorem const_of_operands {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) {k : Nat}
    {g : Table} {a b : Nat} (hk : C.gateAt k = some (g, a, b))
    (ha : (C.resAt ρ a).isConst = true) (hb : (C.resAt ρ b).isConst = true) :
    (C.resAt ρ k).isConst = true := by
  rw [C.resAt_gate ρ hk]
  cases hra : C.resAt ρ a with
  | lit s neg =>
    rw [hra] at ha
    simp [Res.isConst] at ha
  | const c₁ =>
    cases hrb : C.resAt ρ b with
    | lit s neg =>
      rw [hrb] at hb
      simp [Res.isConst] at hb
    | const c₂ => rfl

/-- A gate reading two different constant signals is constant. -/
private theorem const_of_reads_two {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res)
    {k s s' : Nat} (hss : s ≠ s') (hs : k ∈ C.users s) (hs' : k ∈ C.users s')
    (hcs : (C.resAt ρ s).isConst = true) (hcs' : (C.resAt ρ s').isConst = true) :
    (C.resAt ρ k).isConst = true := by
  obtain ⟨g, a, b, hk, hab⟩ := operands_of_two C hss hs hs'
  rcases hab with ⟨ha, hb⟩ | ⟨ha, hb⟩
  · rw [← ha] at hcs
    rw [← hb] at hcs'
    exact const_of_operands C ρ hk hcs hcs'
  · rw [← ha] at hcs'
    rw [← hb] at hcs
    exact const_of_operands C ρ hk hcs' hcs

end TwoLevelTwoAux

private theorem four_named_eliminated_drop {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x : Fin n) (b : Bool)
    (hx2 : 2 ≤ C.refCount x.val) (P Q R S : Nat)
    (hPQ : P ≠ Q) (hPR : P ≠ R) (hPS : P ≠ S)
    (hQR : Q ≠ R) (hQS : Q ≠ S) (hRS : R ≠ S)
    (hPx : P ∈ C.users x.val) (hQx : Q ∈ C.users x.val)
    (haP : C.isAliased (singleRes x b) P = true)
    (haQ : C.isAliased (singleRes x b) Q = true)
    (haR : C.isAliased (singleRes x b) R = true)
    (haS : C.isAliased (singleRes x b) S = true) :
    (C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2 := by
  refine h.four_eliminated_two_readers_drop x b hx2 {P,Q,R,S}
    (by simp [hPQ,hPR,hPS,hQR,hQS,hRS]) ?_ P Q hPQ (by simp) (by simp) hPx hQx
  intro k hk
  simp only [Finset.mem_insert, Finset.mem_singleton] at hk
  rcases hk with he | he | he | he
  · simpa [he] using haP
  · simpa [he] using haQ
  · simpa [he] using haR
  · simpa [he] using haS

/-- If two distinct direct readers both become constant, their successors
give four distinct eliminated gates, including when they share a successor. -/
theorem case_both_constant_twoLevel {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x : Fin n) (b : Bool)
    (hx2 : 2 ≤ C.refCount x.val) {P Q : Nat}
    (hPQ : P ≠ Q) (hPx : P ∈ C.users x.val) (hQx : Q ∈ C.users x.val)
    (hPc : (C.resAt (singleRes x b) P).isConst = true)
    (hQc : (C.resAt (singleRes x b) Q).isConst = true) :
    (C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2 := by
  have halias : ∀ k ∈ C.users x.val, C.isAliased (singleRes x b) k = true := by
    intro k hk
    obtain ⟨g,a,d,hg,had⟩ := C.mem_users.mp hk
    apply C.isAliased_of_const _ hg
    have hxres : C.resAt (singleRes x b) x.val = .const b := by
      rw [C.resAt_single_input x b x]
      simp
    rcases had with ha | hd
    · left; rw [ha, hxres]; rfl
    · right; rw [hd, hxres]; rfl
  obtain ⟨_, hPn, hPs⟩ := TwoLevelTwoAux.lt_of_mem_users C hPx
  obtain ⟨_, hQn, hQs⟩ := TwoLevelTwoAux.lt_of_mem_users C hQx
  obtain ⟨⟨R,hR⟩,hF5P⟩ := h.const_users x b hPn hPs hPc
  obtain ⟨⟨W,hW⟩,hF5Q⟩ := h.const_users x b hQn hQs hQc
  have hRx : R ∉ C.users x.val := h.no_triangle x.isLt hPx hR
  have hWx : W ∉ C.users x.val := h.no_triangle x.isLt hQx hW
  have hPR : P ≠ R := fun he => hRx (he ▸ hPx)
  have hQR : Q ≠ R := fun he => hRx (he ▸ hQx)
  by_cases hWR : W = R
  · rw [hWR] at hW
    have hRc := TwoLevelTwoAux.const_of_reads_two C (singleRes x b) hPQ hR hW hPc hQc
    obtain ⟨hPRlt,hRn,hRs⟩ := TwoLevelTwoAux.lt_of_mem_users C hR
    have hQRlt := (TwoLevelTwoAux.lt_of_mem_users C hW).1
    obtain ⟨⟨S,hS⟩,hF5R⟩ := h.const_users x b hRn hRs hRc
    have hRSlt := (TwoLevelTwoAux.lt_of_mem_users C hS).1
    exact h.four_named_eliminated_drop x b hx2 P Q R S hPQ hPR (by omega)
      hQR (by omega) (by omega) hPx hQx (halias P hPx) (halias Q hQx)
      (hF5P R hR) (hF5R S hS)
  · have hPW : P ≠ W := fun he => hWx (he ▸ hPx)
    have hQW : Q ≠ W := fun he => hWx (he ▸ hQx)
    exact h.four_named_eliminated_drop x b hx2 P Q R W hPQ hPR hPW hQR hQW
      (Ne.symm hWR) hPx hQx (halias P hPx) (halias Q hQx) (hF5P R hR) (hF5Q W hW)

/-- If a successor of a blocked reader also becomes constant, the next
successor supplies the fourth elimination. -/
theorem case_successor_constant_twoLevel {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x : Fin n) (b : Bool)
    (hx2 : 2 ≤ C.refCount x.val) {P Q : Nat}
    (hPQ : P ≠ Q) (hPx : P ∈ C.users x.val) (hQx : Q ∈ C.users x.val)
    (hPc : (C.resAt (singleRes x b) P).isConst = true) {R : Nat}
    (hR : R ∈ C.users P) (hRc : (C.resAt (singleRes x b) R).isConst = true) :
    (C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2 := by
  by_cases hQc : (C.resAt (singleRes x b) Q).isConst = true
  · exact h.case_both_constant_twoLevel x b hx2 hPQ hPx hQx hPc hQc
  have halias : ∀ k ∈ C.users x.val, C.isAliased (singleRes x b) k = true := by
    intro k hk
    obtain ⟨g,a,d,hg,had⟩ := C.mem_users.mp hk
    apply C.isAliased_of_const _ hg
    have hxres : C.resAt (singleRes x b) x.val = .const b := by
      rw [C.resAt_single_input x b x]
      simp
    rcases had with ha | hd
    · left; rw [ha, hxres]; rfl
    · right; rw [hd, hxres]; rfl
  obtain ⟨_,hPn,hPs⟩ := TwoLevelTwoAux.lt_of_mem_users C hPx
  have hF5P := (h.const_users x b hPn hPs hPc).2
  have hRx : R ∉ C.users x.val := h.no_triangle x.isLt hPx hR
  have hPR : P ≠ R := fun he => hRx (he ▸ hPx)
  have hQR : Q ≠ R := fun he => hRx (he ▸ hQx)
  obtain ⟨hPRlt,hRn,hRs⟩ := TwoLevelTwoAux.lt_of_mem_users C hR
  obtain ⟨⟨S,hS⟩,hF5R⟩ := h.const_users x b hRn hRs hRc
  have hRSlt := (TwoLevelTwoAux.lt_of_mem_users C hS).1
  have hQS : Q ≠ S := by
    intro he
    rw [← he] at hS
    have hxR : x.val ≠ R := by have := x.isLt; omega
    have hxc : (C.resAt (singleRes x b) x.val).isConst = true := by
      rw [C.resAt_single_input x b x]
      simp [Res.isConst]
    exact hQc (TwoLevelTwoAux.const_of_reads_two C (singleRes x b) hxR hQx hS hxc hRc)
  exact h.four_named_eliminated_drop x b hx2 P Q R S hPQ hPR (by omega)
    hQR hQS (by omega) hPx hQx (halias P hPx) (halias Q hQx) (hF5P R hR) (hF5R S hS)

/-- If a blocked nonlinear reader has a parity companion, or a parity
successor, the three eliminations give the paper's fourteen-unit drop. -/
theorem case_blocked_with_parity_twoLevel {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x : Fin n) (b : Bool)
    (hx2 : 2 ≤ C.refCount x.val) {P Q : Nat}
    (hPQ : P ≠ Q) (hPx : P ∈ C.users x.val) (hQx : Q ∈ C.users x.val)
    (hPpar : (C.tableAt P).parity = false)
    (hPc : (C.resAt (singleRes x b) P).isConst = true)
    (hpar : (C.tableAt Q).parity = true ∨
      ∃ R ∈ C.users P, (C.tableAt R).parity = true) :
    (C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2 := by
  obtain ⟨gP,aP,dP,hgP,_⟩ := C.mem_users.mp hPx
  have hPb := C.gateAt_bounds hgP
  obtain ⟨hne,hF5⟩ := h.const_users x b hPb.1 hPb.2.1 hPc
  obtain ⟨R,hR,hpar'⟩ : ∃ R ∈ C.users P,
      (C.tableAt Q).parity = true ∨ (C.tableAt R).parity = true := by
    rcases hpar with hq | ⟨R,hR,hr⟩
    · obtain ⟨R,hR⟩ := hne
      exact ⟨R,hR,Or.inl hq⟩
    · exact ⟨R,hR,Or.inr hr⟩
  have hRx : R ∉ C.users x.val := h.no_triangle x.isLt hPx hR
  have hPR : P ≠ R := fun he => hRx (he ▸ hPx)
  have hQR : Q ≠ R := fun he => hRx (he ▸ hQx)
  have halias : ∀ k ∈ C.users x.val, C.isAliased (singleRes x b) k = true := by
    intro k hk
    obtain ⟨g,a,d,hg,had⟩ := C.mem_users.mp hk
    apply C.isAliased_of_const _ hg
    have hxres : C.resAt (singleRes x b) x.val = .const b := by
      rw [C.resAt_single_input x b x]
      simp
    rcases had with ha | hd
    · left; rw [ha, hxres]; rfl
    · right; rw [hd, hxres]; rfl
  have hEsub : ({P,Q,R} : Finset Nat) ⊆ Finset.range (n + C.size) := by
    intro k hk
    simp only [Finset.mem_insert, Finset.mem_singleton] at hk
    have hbound : ∀ a k, k ∈ C.users a → k < n + C.size := by
      intro a k hk'
      obtain ⟨g,u,v,hg,_⟩ := C.mem_users.mp hk'
      exact (C.gateAt_bounds hg).2.1
    rcases hk with he | he | he
    · rw [he]; exact Finset.mem_range.mpr (hbound x.val P hPx)
    · rw [he]; exact Finset.mem_range.mpr (hbound x.val Q hQx)
    · rw [he]; exact Finset.mem_range.mpr (hbound P R hR)
  have hEalias : ∀ k ∈ ({P,Q,R} : Finset Nat), C.isAliased (singleRes x b) k = true := by
    intro k hk
    simp only [Finset.mem_insert, Finset.mem_singleton] at hk
    rcases hk with he | he | he
    · simpa [he] using halias P hPx
    · simpa [he] using halias Q hQx
    · simpa [he] using hF5 R hR
  have hcount := C.aliasedCount_ge_card (singleRes x b) {P,Q,R} hEsub hEalias
  simp [hPQ,hPR,hQR] at hcount
  obtain ⟨K,hK,hKpar⟩ : ∃ K ∈ ({P,Q,R} : Finset Nat),
      (C.tableAt K).parity = true := by
    rcases hpar' with hq | hr
    · exact ⟨Q, by simp, hq⟩
    · exact ⟨R, by simp, hr⟩
  have hKsub : ({K} : Finset Nat) ⊆ Finset.range (n + C.size) := by
    intro k hk
    rw [Finset.mem_singleton.mp hk]
    exact hEsub hK
  have hpc := C.aliasedParityCount_ge_card (singleRes x b) {K} hKsub (by
    intro k hk
    rw [Finset.mem_singleton.mp hk]
    exact ⟨hEalias K hK,hKpar⟩)
  simp at hpc
  have hd := h.twoLevel_single_drop_with_readers x b hx2 {P} (by
    intro k hk
    rw [Finset.mem_singleton.mp hk]
    exact ⟨hPx,halias P hPx,hPpar⟩)
  simp only [Finset.card_singleton, Nat.cast_one] at hd
  omega

/-- A blocked nonlinear reader with two distinct successors gives the
four-gate drop. The companion reader may be parity or nonlinear. -/
theorem case_blocked_two_successors_twoLevel {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x : Fin n) (b : Bool)
    (hx2 : 2 ≤ C.refCount x.val) {P Q : Nat}
    (hPQ : P ≠ Q) (hPx : P ∈ C.users x.val) (hQx : Q ∈ C.users x.val)
    (hPpar : (C.tableAt P).parity = false)
    (hPc : (C.resAt (singleRes x b) P).isConst = true)
    (hcard : 1 < (C.users P).card) :
    (C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2 := by
  cases hQpar : (C.tableAt Q).parity with
  | true =>
    exact h.case_blocked_with_parity_twoLevel x b hx2 hPQ hPx hQx hPpar hPc (Or.inl hQpar)
  | false =>
    obtain ⟨R,hR,S,hS,hRS⟩ := Finset.one_lt_card.mp hcard
    have hRx : R ∉ C.users x.val := h.no_triangle x.isLt hPx hR
    have hSx : S ∉ C.users x.val := h.no_triangle x.isLt hPx hS
    have hPR : P ≠ R := fun he => hRx (he ▸ hPx)
    have hPS : P ≠ S := fun he => hSx (he ▸ hPx)
    have hQR : Q ≠ R := fun he => hRx (he ▸ hQx)
    have hQS : Q ≠ S := fun he => hSx (he ▸ hQx)
    have halias : ∀ k ∈ C.users x.val, C.isAliased (singleRes x b) k = true := by
      intro k hk
      obtain ⟨g,a,d,hg,had⟩ := C.mem_users.mp hk
      apply C.isAliased_of_const _ hg
      have hxres : C.resAt (singleRes x b) x.val = .const b := by
        rw [C.resAt_single_input x b x]
        simp
      rcases had with ha | hd
      · left; rw [ha, hxres]; rfl
      · right; rw [hd, hxres]; rfl
    obtain ⟨gP,aP,dP,hgP,_⟩ := C.mem_users.mp hPx
    have hPb := C.gateAt_bounds hgP
    have hF5 := (h.const_users x b hPb.1 hPb.2.1 hPc).2
    let E : Finset Nat := {P,Q,R,S}
    have hEsub : E ⊆ Finset.range (n + C.size) := by
      intro k hk
      simp only [E, Finset.mem_insert, Finset.mem_singleton] at hk
      have hbound : ∀ a k, k ∈ C.users a → k < n + C.size := by
        intro a k hk'
        obtain ⟨g,u,v,hg,_⟩ := C.mem_users.mp hk'
        exact (C.gateAt_bounds hg).2.1
      rcases hk with he | he | he | he
      · rw [he]; exact Finset.mem_range.mpr (hbound x.val P hPx)
      · rw [he]; exact Finset.mem_range.mpr (hbound x.val Q hQx)
      · rw [he]; exact Finset.mem_range.mpr (hbound P R hR)
      · rw [he]; exact Finset.mem_range.mpr (hbound P S hS)
    have hEalias : ∀ k ∈ E, C.isAliased (singleRes x b) k = true := by
      intro k hk
      simp only [E, Finset.mem_insert, Finset.mem_singleton] at hk
      rcases hk with he | he | he | he
      · simpa [he] using halias P hPx
      · simpa [he] using halias Q hQx
      · simpa [he] using hF5 R hR
      · simpa [he] using hF5 S hS
    have hcount := C.aliasedCount_ge_card (singleRes x b) E hEsub hEalias
    have hEcard : E.card = 4 := by simp [E,hPQ,hPR,hPS,hQR,hQS,hRS]
    rw [hEcard] at hcount
    have hd := h.twoLevel_single_drop_with_readers x b hx2 {P,Q} (by
      intro k hk
      simp only [Finset.mem_insert, Finset.mem_singleton] at hk
      rcases hk with he | he
      · rw [he]; exact ⟨hPx,halias P hPx,hPpar⟩
      · rw [he]; exact ⟨hQx,halias Q hQx,hQpar⟩)
    simp only [Finset.card_pair hPQ, Nat.cast_ofNat] at hd
    omega

/-- Nonlinear first-gate branch when the other reader of an operand, or a
successor of the first gate, is parity. -/
theorem case_nonlinear_parity_twoLevel {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) {t : Table} {i j : Fin n}
    {rest : OpenCircuit (n + 1)} (hC : C = .gate t i j rest)
    (hnl : t.nonlinear = true) (v : Fin n) (hv : v = i ∨ v = j)
    (h2 : 2 ≤ C.refCount v.val) (Q : Nat) (hQn : Q ≠ n)
    (hQ : Q ∈ C.users v.val)
    (hpar : (C.tableAt Q).parity = true ∨
      ∃ R ∈ C.users n, (C.tableAt R).parity = true) :
    ∃ b, (C.restrict (singleSubst v b)).psi2 + 14 ≤ C.psi2 := by
  have hT : C.gateAt n = some (t,i.val,j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hTv : n ∈ C.users v.val := by
    rw [C.mem_users]
    refine ⟨t,i.val,j.val,hT,?_⟩
    rcases hv with he | he
    · rw [he]; exact Or.inl rfl
    · rw [he]; exact Or.inr rfl
  have hTpar : (C.tableAt n).parity = false := by
    have ht : t.parity = false := by
      unfold Table.nonlinear at hnl
      cases hp : t.parity <;> simp [hp] at hnl ⊢
    simp [tableAt,hT,ht]
  have hvres : ∀ b : Bool, C.resAt (singleRes v b) v.val = .const b := by
    intro b
    rw [C.resAt_single_input v b v]
    simp
  obtain ⟨b,hbc⟩ : ∃ b, (C.resAt (singleRes v b) n).isConst = true := by
    rcases hv with he | he
    · obtain ⟨b,hb,_⟩ := t.nonlinear_exists_blocksLeft hnl
      refine ⟨b, ?_⟩
      rw [C.resAt_gate _ hT, ← he, hvres b, Res.step_blocked_left t b _ hb]
      rfl
    · obtain ⟨b,hb,_⟩ := t.nonlinear_exists_blocksRight hnl
      refine ⟨b, ?_⟩
      rw [C.resAt_gate _ hT, ← he, hvres b, Res.step_blocked_right t _ b hb]
      rfl
  exact ⟨b, h.case_blocked_with_parity_twoLevel v b h2 (Ne.symm hQn)
    hTv hQ hTpar hbc hpar⟩

end MAContext
end SatLowerBound
