import Credit.TwoLevel.Roles
import Credit.TwoLevel.Correspondence

/-! Disconnection through a two-gate chain, used by the manuscript's role lemma. -/
namespace SatLowerBound
namespace OpenCircuit

/-- If `z` feeds only `W`, and `W` feeds only `G`, then two inputs that agree
outside `z` and agree at `G` yield the same output, provided the output is
neither `z` nor `W`. No restriction on the positions of intervening gates. -/
theorem eval_eq_of_chain_cut {n : Nat} (C : OpenCircuit n)
    (z : Fin n) (W G : Nat) (x y : Fin n → Bool)
    (hinput : ∀ v, v ≠ z → x v = y v)
    (hz : ∀ k ∈ C.users z.val, k = W)
    (hW : ∀ k ∈ C.users W, k = G)
    (hG : C.valueAt x G = C.valueAt y G)
    (hout : ∀ k b, C.outWire = some (k,b) → k ≠ z.val ∧ k ≠ W) :
    C.eval x = C.eval y := by
  have hsig : ∀ k, k < n + C.size → k ≠ z.val → k ≠ W →
      C.valueAt x k = C.valueAt y k := by
    intro k
    induction k using Nat.strong_induction_on with
    | h k ih =>
      intro hk hkz hkW
      by_cases hkn : k < n
      · let v : Fin n := ⟨k,hkn⟩
        have hvz : v ≠ z := fun he => hkz (congrArg Fin.val he)
        change C.valueAt x v.val = C.valueAt y v.val
        exact (C.valueAt_input x v).trans ((hinput v hvz).trans (C.valueAt_input y v).symm)
      · by_cases hkG : k = G
        · simpa [hkG] using hG
        · obtain ⟨g,a,b,hgate⟩ := C.gateAt_exists (by omega) hk
          have hb := C.gateAt_bounds hgate
          have haZ : a ≠ z.val := by
            intro ha
            have hm : k ∈ C.users z.val := C.mem_users.mpr ⟨g,a,b,hgate,Or.inl ha⟩
            exact hkW (hz k hm)
          have haW : a ≠ W := by
            intro ha
            have hm : k ∈ C.users W := C.mem_users.mpr ⟨g,a,b,hgate,Or.inl ha⟩
            exact hkG (hW k hm)
          have hbZ : b ≠ z.val := by
            intro he
            have hm : k ∈ C.users z.val := C.mem_users.mpr ⟨g,a,b,hgate,Or.inr he⟩
            exact hkW (hz k hm)
          have hbW : b ≠ W := by
            intro he
            have hm : k ∈ C.users W := C.mem_users.mpr ⟨g,a,b,hgate,Or.inr he⟩
            exact hkG (hW k hm)
          rw [C.valueAt_gate x hgate, C.valueAt_gate y hgate,
            ih a hb.2.2.1 (by omega) haZ haW, ih b hb.2.2.2 (by omega) hbZ hbW]
  cases hw : C.outWire with
  | none => exact C.eval_const_of_outWire_none hw x y
  | some pair =>
    obtain ⟨k, neg⟩ := pair
    have hk := C.outWire_bound hw
    obtain ⟨hkz,hkW⟩ := hout k neg hw
    rw [C.eval_of_outWire x hw, C.eval_of_outWire y hw, hsig k hk hkz hkW]

/-- Paper Lemma "Roles" (a), first part: an original second-credit gate
cannot have any primary input as an operand under (E1). -/
theorem second_role_has_no_primary {n : Nat} (C : OpenCircuit n) (hr : C.Reduced)
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (z : Fin n) (hzEss : Essential f z) (W G : Nat)
    (hstar : C.isDStar z.val = true) (hW : W ∈ C.users z.val)
    (hG : G ∈ C.users W) (g : Table) (a b : Nat)
    (hgate : C.gateAt G = some (g,a,b)) (x : Fin n) (hoperand : a = x.val ∨ b = x.val) : False := by
  have hDz := C.isD_of_isDStar z.val hstar
  have huz := C.users_singleton_of_isD z.val W hDz hW
  have hDW : C.isD W = true := by
    obtain ⟨_, w, hw, hd⟩ := (C.isDStar_iff z.val).mp hstar
    rw [huz, Finset.mem_singleton] at hw
    simpa [hw] using hd
  have huW := C.users_singleton_of_isD W G hDW hG
  have hgnl : g.nonlinear = true := by
    obtain ⟨_, k, g', a', b', hk, hab, hnl⟩ := (C.isD_iff W).mp hDW
    have hkW : k ∈ C.users W := C.mem_users.mpr ⟨g',a',b',hk,hab⟩
    rw [huW, Finset.mem_singleton] at hkW
    rw [hkW, hgate] at hk
    cases hk
    exact hnl
  have hGW : W < G := by
    obtain ⟨g',a',b',hg',hab⟩ := C.mem_users.mp hG
    have hb := C.gateAt_bounds hg'
    rcases hab with he | he <;> omega
  have hzx : z ≠ x := by
    intro he
    have hGz : G ∈ C.users z.val := C.mem_users.mpr ⟨g,a,b,hgate,by
      rcases hoperand with ha | hb
      · exact Or.inl (by rw [ha, ← he])
      · exact Or.inr (by rw [hb, ← he])⟩
    rw [huz, Finset.mem_singleton] at hGz
    omega
  have houtz := C.reduced_outIs_zero_of_user hr z.val (Finset.ne_empty_of_mem hW)
  have houtW := C.reduced_outIs_zero_of_user hr W (Finset.ne_empty_of_mem hG)
  have hout : ∀ k neg, C.outWire = some (k,neg) → k ≠ z.val ∧ k ≠ W := by
    intro k neg hk
    constructor <;> intro he
    · simp [outIs, hk, he] at houtz
    · simp [outIs, hk, he] at houtW
  have hchainz : ∀ k ∈ C.users z.val, k = W := by
    intro k hk; simpa [huz] using hk
  have hchainW : ∀ k ∈ C.users W, k = G := by
    intro k hk; simpa [huW] using hk
  have hblock : ∃ β value : Bool, ∀ v,
      C.valueAt (fixBit x β v) G = value := by
    rcases hoperand with ha | hb
    · obtain ⟨β,hβ,_⟩ := g.nonlinear_exists_blocksLeft hgnl
      refine ⟨β, g.eval β false, ?_⟩
      intro v
      rw [C.valueAt_gate _ hgate, ha, C.valueAt_input]
      have hfixed : fixBit x β v x = β := by simp [fixBit]
      rw [hfixed, g.blocksLeft_eval β hβ]
    · obtain ⟨β,hβ,_⟩ := g.nonlinear_exists_blocksRight hgnl
      refine ⟨β, g.eval false β, ?_⟩
      intro v
      rw [C.valueAt_gate _ hgate, hb, C.valueAt_input]
      have hfixed : fixBit x β v x = β := by simp [fixBit]
      rw [hfixed, g.blocksRight_eval β hβ]
  obtain ⟨β,value,hvalue⟩ := hblock
  obtain ⟨p,q,hagree,hdiff⟩ := hE1 x β z hzx hzEss
  apply hdiff
  have hinputs : ∀ v, v ≠ z → fixBit x β p v = fixBit x β q v := by
    intro v hv
    simp [fixBit, hagree v hv]
  have hGvalue : C.valueAt (fixBit x β p) G = C.valueAt (fixBit x β q) G := by
    rw [hvalue, hvalue]
  have heval := C.eval_eq_of_chain_cut z W G (fixBit x β p) (fixBit x β q)
    hinputs hchainz hchainW hGvalue hout
  simpa only [hc] using heval

end OpenCircuit
end SatLowerBound
