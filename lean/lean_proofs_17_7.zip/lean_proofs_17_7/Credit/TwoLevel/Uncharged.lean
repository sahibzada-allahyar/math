import Credit.TwoLevel.ParityDrop

/-! The extra unit from eliminated nonlinear gates that play no credit role. -/
namespace SatLowerBound
namespace OpenCircuit

/-- An original gate that plays neither credit role receives no charge. -/
theorem free_gate_charge_zero_of_no_role {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (k : Nat) (hfirst : ∀ z, C.isD z.val = true → W z ≠ k)
    (hsecond : ∀ z, C.isDStar z.val = true → V z ≠ k) :
    C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k +
      C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V k = 0 := by
  have h1 : C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k = 0 := by
    unfold gateFirstCharge
    apply Finset.sum_eq_zero
    intro z hz
    have he := (Finset.mem_filter.mp hz).2
    have hd : C.isD z.val = false := by
      apply Bool.eq_false_iff.mpr
      intro h
      exact (hfirst z h) he
    have hb := C.first_charge_bound (C.restrict (fixSubst P c)) (fixRes P c) W z
    simp [indicator, hd] at hb
    exact hb
  have h2 : C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V k = 0 := by
    unfold gateSecondCharge
    apply Finset.sum_eq_zero
    intro z hz
    have he := (Finset.mem_filter.mp hz).2
    have hs : C.isDStar z.val = false := by
      apply Bool.eq_false_iff.mpr
      intro h
      exact (hsecond z h) he
    have hb := C.free_second_charge_bound P c hr W V hfree hw hv hess z
    simp [indicator, hs] at hb
    exact hb
  rw [h1, h2]

/-- Aggregate charge accounting with one extra unit for each designated
eliminated, non-parity gate known to carry no credit role. -/
theorem free_loss_add_parity_uncharged_le_aliased {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (hsafe : C.DGateSafe)
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (horig : ∀ z, C.isDStar z.val = true → Essential f z)
    (E : Finset Nat) (hErange : E ⊆ Finset.range (n + C.size))
    (hE : ∀ k ∈ E, C.isAliased (fixRes P c) k = true ∧
      (C.tableAt k).parity = false ∧
      (∀ z, C.isD z.val = true → W z ≠ k) ∧
      (∀ z, C.isDStar z.val = true → V z ≠ k)) :
    C.credit2Lost (C.restrict (fixSubst P c)) + C.aliasedParityCount (fixRes P c) + E.card ≤
      C.aliasedCount (fixRes P c) := by
  have hcard : E.card = ∑ k ∈ Finset.range (n + C.size), if k ∈ E then 1 else 0 := by
    rw [← Finset.sum_filter]
    have heq : (Finset.range (n + C.size)).filter (fun k => k ∈ E) = E := by
      ext k
      simp only [Finset.mem_filter]
      exact ⟨fun h => h.2, fun h => ⟨hErange h, h⟩⟩
    rw [heq]
    simp
  rw [C.free_credit_loss_eq_gate_charges P c hr W V hfree hw hv hess,
    C.aliasedParityCount_eq_sum, C.aliasedCount_eq_sum, hcard,
    ← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
  apply Finset.sum_le_sum
  intro k hk
  by_cases hkE : k ∈ E
  · obtain ⟨ha,hp,hfirst,hsecond⟩ := hE k hkE
    have hz := C.free_gate_charge_zero_of_no_role P c hr W V hfree hw hv hess k hfirst hsecond
    simp [hkE, ha, hp, Table.parityCount, indicator, hz]
  · have hcharge := C.free_gate_charge_le_alias P c hr hsafe f hc hE1 W V hfree hw hv hess horig k
    cases ha : C.isAliased (fixRes P c) k with
    | false => simp [hkE, ha, indicator] at hcharge ⊢; omega
    | true =>
      cases hp : (C.tableAt k).parity with
      | false => simpa [hkE, ha, hp, indicator, Table.parityCount] using hcharge
      | true =>
        have hnl : (C.tableAt k).nonlinear = false := by simp [Table.nonlinear, hp]
        have h1 := C.first_charge_zero_of_not_nonlinear (C.restrict (fixSubst P c))
          (fixRes P c) W hw k hnl
        have h2 := C.second_charge_zero_of_not_nonlinear P c hr W V hfree hw hv hess k hnl
        simp [hkE, hp, indicator, Table.parityCount, h1, h2]

/-- The potential drop includes an extra unit for every designated
eliminated nonlinear gate carrying neither kind of credit role. -/
theorem psi2_free_drop_with_uncharged {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (hsafe : C.DGateSafe)
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (horig : ∀ z, C.isDStar z.val = true → Essential f z)
    (E : Finset Nat) (hErange : E ⊆ Finset.range (n + C.size))
    (hE : ∀ k ∈ E, C.isAliased (fixRes P c) k = true ∧
      (C.tableAt k).parity = false ∧
      (∀ z, C.isD z.val = true → W z ≠ k) ∧
      (∀ z, C.isDStar z.val = true → V z ≠ k)) :
    (C.restrict (fixSubst P c)).psi2 +
      3 * (C.aliasedCount (fixRes P c) : Int) +
      4 * (C.aliasedParityCount (fixRes P c) : Int) +
      (E.card : Int) + C.credit2Gained (C.restrict (fixSubst P c)) ≤ C.psi2 := by
  have hlost := C.free_loss_add_parity_uncharged_le_aliased P c hr hsafe f hc hE1 W V
    hfree hw hv hess horig E hErange hE
  have hweight := C.aliasedPsi2Weight_eq_count_parity (fixRes P c) (C.reduced_essential hr)
  have hbalance := C.psi2_restriction_gain_loss P c
  omega

end OpenCircuit
end SatLowerBound
