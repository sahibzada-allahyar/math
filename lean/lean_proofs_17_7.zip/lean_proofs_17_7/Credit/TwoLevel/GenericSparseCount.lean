import Credit.TwoLevel.GenericSparse
import SatLowerBound.RestrictionCount

/-! Counting fixed and free coordinates of the arbitrary-block SAT restriction. -/
namespace SatLowerBound

def genericFixedMask (w r : Nat) {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g)
    (i : Fin (inputBits w)) : Bool := (genericSparseRestriction w r B i).isConstant

def genericFreeEmbedding (w r : Nat) (hr : r < w) (hr0 : 0 < r)
    {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g)
    (i : Fin (genericFreeBits w B)) : Fin (inputBits w) :=
  let a := unpairIndex hr0 i
  let cs := unpairIndex (by decide : 0 < 3) a.1
  coordinate w (genericFreeClause w B cs.1) cs.2
    ⟨a.2.val,by have := a.2.isLt; omega⟩

theorem genericFreeEmbedding_index (w r : Nat) (hr : r < w) (hr0 : 0 < r)
    {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g)
    (c : Fin (genericRemainingClauses w B)) (s : Fin 3) (b : Fin r) :
    genericFreeEmbedding w r hr hr0 B (genericFreeBitIndex c s b) =
      coordinate w (genericFreeClause w B c) s ⟨b.val,by have := b.isLt; omega⟩ := by
  simp only [genericFreeEmbedding,genericFreeBitIndex,unpair_pair]

theorem genericRestriction_free_coordinate (w r : Nat) (hr : r < w)
    {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g)
    (j : Fin (genericRemainingClauses w B)) (s : Fin 3) (b : Fin r) :
    genericSparseRestriction w r B (coordinate w (genericFreeClause w B j) s
      ⟨b.val,by have := b.isLt; omega⟩) = .wire (genericFreeBitIndex j s b) false := by
  have hc : ¬ B.count+j.val < B.count := by omega
  simp only [genericSparseRestriction,packFields_coordinate,genericSparseFieldSignal,genericFreeClause,
    hc,↓reduceDIte,b.isLt,Nat.add_sub_cancel_left]

theorem genericRestriction_freeEmbedding (w r : Nat) (hr : r < w) (hr0 : 0 < r)
    {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g) (i : Fin (genericFreeBits w B)) :
    genericSparseRestriction w r B (genericFreeEmbedding w r hr hr0 B i) = .wire i false := by
  unfold genericFreeEmbedding
  rw [genericRestriction_free_coordinate w r hr]
  unfold genericFreeBitIndex
  rw [pair_unpair,pair_unpair]

theorem genericFreeEmbedding_injective (w r : Nat) (hr : r < w) (hr0 : 0 < r)
    {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g) :
    Function.Injective (genericFreeEmbedding w r hr hr0 B) := by
  intro i j h
  have he := congrArg (genericSparseRestriction w r B) h
  rw [genericRestriction_freeEmbedding,genericRestriction_freeEmbedding] at he
  exact (Signal.wire.inj he).1

theorem genericFixedMask_false_iff (w r : Nat) (hr : r < w) (hr0 : 0 < r)
    {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g) (i : Fin (inputBits w)) :
    genericFixedMask w r B i = false ↔ ∃ j, genericFreeEmbedding w r hr hr0 B j = i := by
  constructor
  · intro h
    obtain ⟨c,s,b,rfl⟩ := coordinate_surjective w i
    simp only [genericFixedMask,genericSparseRestriction,packFields_coordinate,genericSparseFieldSignal] at h
    split at h
    · contradiction
    · rename_i hc
      split at h
      · rename_i hb
        let d : Fin (genericRemainingClauses w B) := ⟨c.val-B.count,by
          have hh := c.isLt; change c.val < variableCount w at hh
          unfold genericRemainingClauses; omega⟩
        refine ⟨genericFreeBitIndex d s ⟨b.val,hb⟩,?_⟩
        rw [genericFreeEmbedding_index]
        have hd : genericFreeClause w B d = c := by
          apply Fin.ext
          change B.count+(c.val-B.count) = c.val
          omega
        rw [hd]
      · contradiction
  · rintro ⟨j,rfl⟩
    unfold genericFixedMask
    rw [genericRestriction_freeEmbedding]
    rfl

theorem genericFixed_coordinate_count (w r : Nat) (hr : r < w) (hr0 : 0 < r)
    {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g) :
    (∑ i : Fin (inputBits w), indicator (genericFixedMask w r B i)) = inputBits w-genericFreeBits w B := by
  have hfree : (Finset.univ.filter (fun i : Fin (inputBits w) => genericFixedMask w r B i = false)).card =
      genericFreeBits w B := by
    have he : Finset.univ.filter (fun i : Fin (inputBits w) => genericFixedMask w r B i = false) =
        Finset.univ.image (genericFreeEmbedding w r hr hr0 B) := by
      ext i
      simp only [Finset.mem_filter,Finset.mem_univ,true_and,Finset.mem_image,
        genericFixedMask_false_iff w r hr hr0 B]
    rw [he,Finset.card_image_of_injective _ (genericFreeEmbedding_injective w r hr hr0 B),
      Finset.card_univ,Fintype.card_fin]
  have htotal := Finset.card_filter_add_card_filter_not
    (s := Finset.univ) (fun i : Fin (inputBits w) => genericFixedMask w r B i = true)
  have hcomp (i : Fin (inputBits w)) : (¬ genericFixedMask w r B i = true) ↔
      genericFixedMask w r B i = false := by cases genericFixedMask w r B i <;> simp
  simp only [hcomp,hfree,Finset.card_univ,Fintype.card_fin] at htotal
  rw [Finset.card_filter] at htotal
  change (∑ i : Fin (inputBits w), indicator (genericFixedMask w r B i)) + genericFreeBits w B = inputBits w at htotal
  omega

theorem genericRestriction_marks (w r : Nat) {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g) :
    OpenCircuit.MarksConstants (genericFixedMask w r B) (genericSparseRestriction w r B) := by
  intro i hi
  cases hs : genericSparseRestriction w r B i with
  | constant b => exact ⟨b,rfl⟩
  | wire j b => simp [genericFixedMask,hs,Signal.isConstant] at hi

end SatLowerBound
