import Credit.TwoLevel.Uncharged

/-! The final clause of Lemma 6.11: if credited inputs remain essential,
a charged gate cannot become constant under the restriction. -/
namespace SatLowerBound
namespace OpenCircuit

/-- A second credited gate becoming constant cuts all dependence on its
credited primary input. The retained-essentiality premise rules this out. -/
theorem second_credit_gate_not_constant {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (z : Fin n) (W G : Nat)
    (hstar : C.isDStar z.val = true) (hW : W ∈ C.users z.val)
    (hG : G ∈ C.users W)
    (hess : Essential (C.restrict (fixSubst P c)).eval z) :
    (C.resAt (fixRes P c) G).isConst = false := by
  have hd := C.isD_of_isDStar z.val hstar
  have huz := C.users_singleton_of_isD z.val W hd hW
  obtain ⟨_,w,hw,hdw⟩ := (C.isDStar_iff z.val).mp hstar
  rw [huz,Finset.mem_singleton] at hw
  subst w
  have huW := C.users_singleton_of_isD W G hdw hG
  obtain ⟨g,a,b,hgate,_⟩ := C.mem_users.mp hG
  have hbound := (C.gateAt_bounds hgate).2.1
  have houtz := C.reduced_outIs_zero_of_user hr z.val (Finset.ne_empty_of_mem hW)
  have houtW := C.reduced_outIs_zero_of_user hr W (Finset.ne_empty_of_mem hG)
  have hout : ∀ k neg, C.outWire = some (k,neg) → k ≠ z.val ∧ k ≠ W := by
    intro k neg hk
    constructor <;> intro he
    · simp [outIs,hk,he] at houtz
    · simp [outIs,hk,he] at houtW
  cases hres : C.resAt (fixRes P c) G with
  | lit s neg => rfl
  | const value =>
    exfalso
    obtain ⟨x,y,hxy,hne⟩ := hess
    let X : Fin n → Bool := fun v => if P v then c v else x v
    let Y : Fin n → Bool := fun v => if P v then c v else y v
    have hX : ∀ v, P v = true → X v = c v := by intro v hv; simp [X,hv]
    have hY : ∀ v, P v = true → Y v = c v := by intro v hv; simp [Y,hv]
    have hxg := C.resAt_sound (fixRes P c) X (C.fixRes_denotes P c X hX) G hbound
    have hyg := C.resAt_sound (fixRes P c) Y (C.fixRes_denotes P c Y hY) G hbound
    rw [hres] at hxg hyg
    have hg : C.valueAt X G = C.valueAt Y G := hxg.trans hyg.symm
    have he := C.eval_eq_of_chain_cut z W G X Y (by
      intro v hv
      simp [X,Y,hxy v hv])
      (fun k hk => by simpa [huz] using hk)
      (fun k hk => by simpa [huW] using hk) hg hout
    apply hne
    have hsubst (v : Fin n → Bool) :
        (fun i => (fixSubst P c i).eval v) = (fun i => if P i then c i else v i) := by
      funext i
      cases hP : P i <;> simp [fixSubst,hP,Signal.eval]
    simpa only [restrict_eval,hsubst] using he

/-- A first credited gate cannot become constant while its input remains
essential; this is the first half of the manuscript's no-constant-charge clause. -/
theorem first_credit_gate_not_constant {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (z : Fin n) (W : Nat)
    (hd : C.isD z.val = true) (hW : W ∈ C.users z.val)
    (hess : Essential (C.restrict (fixSubst P c)).eval z) :
    (C.resAt (fixRes P c) W).isConst = false := by
  obtain ⟨s,neg,hres,_⟩ := C.first_credit_gate_resolution P c hr z W hd hW hess
  rw [hres]
  rfl

/-- The free-input allocation gives zero charge to every gate that becomes
constant, as claimed in the last sentence of Lemma 6.11. -/
theorem free_constant_gate_charge_zero {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isD z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (G : Nat) (hconst : (C.resAt (fixRes P c) G).isConst = true) :
    C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W G +
      C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V G = 0 := by
  have hs : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z :=
    fun z hz => hess z (C.isD_of_isDStar z.val hz)
  apply C.free_gate_charge_zero_of_no_role P c hr W V hfree hw hv hs G
  · intro z hd he
    have hh := C.first_credit_gate_not_constant P c hr z (W z) hd (hw z hd) (hess z hd)
    rw [he,hconst] at hh
    contradiction
  · intro z hz he
    have hh := C.second_credit_gate_not_constant P c hr z (W z) (V z) hz
      (hw z (C.isD_of_isDStar z.val hz)) (hv z hz) (hs z hz)
    rw [he,hconst] at hh
    contradiction

end OpenCircuit
end SatLowerBound
