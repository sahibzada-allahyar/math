import Credit.TwoLevel.GenericSparseCount
import SatLowerBound.SatTransfer

/-! Transfer from actual binary-encoded 3-SAT to an arbitrary embedded block. -/
namespace SatLowerBound

def genericFlattenSuffixes (w r : Nat) (hr0 : 0 < r)
    {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g)
    (x : GenericSuffixAssignment w B) : Fin (genericFreeBits w B) → Bool := fun i =>
  let a := unpairIndex hr0 i
  let cs := unpairIndex (by decide : 0 < 3) a.1
  x cs.1 cs.2 a.2

theorem genericSuffixAssignment_flatten (w r : Nat) (hr0 : 0 < r)
    {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g) (x : GenericSuffixAssignment w B) :
    genericSuffixAssignmentOf (genericFlattenSuffixes w r hr0 B x) = x := by
  funext c s b
  simp only [genericSuffixAssignmentOf,genericFlattenSuffixes,genericFreeBitIndex,unpair_pair]

theorem genericSparseFunction_nonconstant (w r : Nat) (hr0 : 0 < r)
    {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g)
    (hblock : Nonconstant g) (hM : 0 < genericRemainingClauses w B) :
    Nonconstant (genericSparseFunction w B) := by
  obtain ⟨⟨u,hu⟩,⟨v,hv⟩⟩ := nonconstant_values _ hblock
  let x := genericFlattenSuffixes w r hr0 B (fun _ _ => u)
  let y := genericFlattenSuffixes w r hr0 B (fun _ _ => v)
  have hx : genericSparseFunction w B x = false := by
    classical
    simp only [genericSparseFunction,x,genericSuffixAssignment_flatten,hu,Bool.false_eq_true,
      exists_false,decide_eq_false_iff_not]
    intro h
    exact h ⟨0,hM⟩
  have hy : genericSparseFunction w B y = true := by
    classical
    simp only [genericSparseFunction,y,genericSuffixAssignment_flatten,hv,decide_eq_true_eq]
    intro j
    exact ⟨0,True.intro⟩
  exact ⟨x,y,by rw [hx,hy]; decide⟩

/-- The canonical false-input enumeration always fits, with at least one
free clause, whenever `0 < r < w`. -/
theorem genericRemaining_pos_of_count (w r : Nat) (hr : r < w) (hr0 : 0 < r)
    {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g) (hcount : B.count ≤ 2^r) :
    B.count ≤ variableCount w ∧ 0 < genericRemainingClauses w B := by
  have hp : 2^(r+1) ≤ 2^w := Nat.pow_le_pow_right (by decide) hr
  have hp0 : 1 < 2^r := Nat.one_lt_two_pow (Nat.ne_of_gt hr0)
  rw [Nat.pow_succ] at hp
  unfold genericRemainingClauses variableCount
  omega

/-- Sparse-helper restriction of an actual 3-SAT circuit, with the exact
number of fixed input bits paid for in the size bound. -/
theorem generic_sat_sparse_transfer (w r : Nat) (hw : 2 ≤ w) (hr : r < w) (hr0 : 0 < r)
    {g : (Fin r → Bool) → Bool} (B : ForbiddenFamily r g)
    (hfit : B.count ≤ variableCount w) (hM : 0 < genericRemainingClauses w B)
    (hblock : Nonconstant g) (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    ∃ D : OpenCircuit (genericFreeBits w B),
      (∀ x, D.eval x = genericSparseFunction w B x) ∧
      D.size + (inputBits w-genericFreeBits w B) ≤ C.size := by
  obtain ⟨N,hl,hg,hs,hweight,heval⟩ := OpenCircuit.normalize_basic C
  let D := N.restrict (genericSparseRestriction w r B)
  have he (x : Fin (genericFreeBits w B) → Bool) : D.eval x = genericSparseFunction w B x := by
    rw [OpenCircuit.restrict_eval,heval,hc,genericSparseRestriction_sat w r hr B hfit x]
  have hN : N.eval = satFunction w := by
    funext x
    exact (heval x).trans (hc x)
  have hnc : Nonconstant D.eval := by
    have heq : D.eval = genericSparseFunction w B := funext he
    rw [heq]
    exact genericSparseFunction_nonconstant w r hr0 B hblock hM
  have hdel := N.restriction_transfer (genericFixedMask w r B) (genericSparseRestriction w r B)
    (genericRestriction_marks w r B) hl
    (by rw [hN]; exact tex_every_encoding_bit_essential w hw) hnc
  rw [genericFixed_coordinate_count w r hr hr0 B] at hdel
  exact ⟨D,he,Nat.le_trans hdel hs⟩

end SatLowerBound
