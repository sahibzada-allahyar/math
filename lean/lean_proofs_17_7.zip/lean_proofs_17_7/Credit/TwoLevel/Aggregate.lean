import Credit.TwoLevel.TwoChain

/-! Regroup the input-indexed credit ledger by original gate index. -/
namespace SatLowerBound
namespace OpenCircuit

/-- A reader is within the original circuit's gate index range. -/
theorem reader_index_lt {n : Nat} (C : OpenCircuit n) {s k : Nat}
    (h : k ∈ C.users s) : k < n + C.size := by
  obtain ⟨g,a,b,hgate,_⟩ := C.mem_users.mp h
  exact (C.gateAt_bounds hgate).2.1

/-- The exact loss equals the sum of per-gate charges, with arbitrary gate
choices allowed for uncredited inputs because those inputs contribute zero. -/
theorem free_credit_loss_eq_gate_charges {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z) :
    C.credit2Lost (C.restrict (fixSubst P c)) =
      ∑ k ∈ Finset.range (n + C.size),
        (C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k +
          C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V k) := by
  let D := C.restrict (fixSubst P c)
  let ρ := fixRes P c
  let R := Finset.range (n + C.size)
  have hf : (∑ z : Fin n, C.firstGateCharge D ρ W z) =
      ∑ k ∈ R, C.gateFirstCharge D ρ W k := by
    unfold gateFirstCharge
    rw [Finset.sum_fiberwise_eq_sum_filter]
    symm
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro z _ hz
    have hnot : W z ∉ R := by simpa using hz
    have hd : C.isD z.val = false := by
      apply Bool.eq_false_iff.mpr
      intro hd
      have hb := C.reader_index_lt (hw z hd)
      exact hnot (Finset.mem_range.mpr hb)
    have hbound := C.first_charge_bound D ρ W z
    simp [indicator, hd] at hbound
    exact hbound
  have hs : (∑ z : Fin n, C.secondGateCharge D ρ W z) =
      ∑ k ∈ R, C.gateSecondCharge D ρ W V k := by
    unfold gateSecondCharge
    rw [Finset.sum_fiberwise_eq_sum_filter]
    symm
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro z _ hz
    have hnot : V z ∉ R := by simpa using hz
    have hd : C.isDStar z.val = false := by
      apply Bool.eq_false_iff.mpr
      intro hd
      have hb := C.reader_index_lt (hv z hd)
      exact hnot (Finset.mem_range.mpr hb)
    have hbound := C.free_second_charge_bound P c hr W V hfree hw hv hess z
    simp [indicator, hd] at hbound
    exact hbound
  have htotal := C.credit2Lost_eq_allocated D ρ W
  rw [Finset.sum_add_distrib, hf, hs, ← Finset.sum_add_distrib] at htotal
  exact htotal

/-- A retained gate receives no charges in the free-input allocation. -/
theorem free_gate_charge_zero_of_not_aliased {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (k : Nat) (halias : C.isAliased (fixRes P c) k = false) :
    C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k +
      C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V k = 0 := by
  have hfirst : C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k = 0 := by
    unfold gateFirstCharge
    apply Finset.sum_eq_zero
    intro z hz
    have he := (Finset.mem_filter.mp hz).2
    have hb := C.first_charge_bound (C.restrict (fixSubst P c)) (fixRes P c) W z
    rw [he, halias] at hb
    simp [indicator] at hb
    exact hb
  have hsecond : C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V k = 0 := by
    unfold gateSecondCharge
    apply Finset.sum_eq_zero
    intro z hz
    have he := (Finset.mem_filter.mp hz).2
    have hb := C.free_second_charge_bound P c hr W V hfree hw hv hess z
    rw [he, halias] at hb
    simp [indicator] at hb
    exact hb
  rw [hfirst, hsecond]

/-- Each gate's total charge is bounded by its elimination indicator. -/
theorem free_gate_charge_le_alias {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (hsafe : C.DGateSafe)
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (horig : ∀ z, C.isDStar z.val = true → Essential f z) (k : Nat) :
    C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k +
      C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V k ≤
        indicator (C.isAliased (fixRes P c) k) := by
  cases ha : C.isAliased (fixRes P c) k with
  | false =>
    rw [C.free_gate_charge_zero_of_not_aliased P c hr W V hfree hw hv hess k ha]
    simp [indicator]
  | true =>
    cases hk : C.gateAt k with
    | none => simp [isAliased, hk] at ha
    | some p =>
      obtain ⟨g,a,b⟩ := p
      have h := C.free_eliminated_gate_total_charge_le_one P c hr hsafe f hc hE1
        W V hfree hw hv hess horig k g a b hk ha
      simpa [indicator] using h

/-- Free-input total loss is at most the number of eliminated gates. This is
the aggregate one-charge bound, prior to proving the more refined gate-weight
and nonconstant-charge clauses of the manuscript. -/
theorem free_credit_loss_le_aliasedCount {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (hsafe : C.DGateSafe)
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (horig : ∀ z, C.isDStar z.val = true → Essential f z) :
    C.credit2Lost (C.restrict (fixSubst P c)) ≤ C.aliasedCount (fixRes P c) := by
  rw [C.free_credit_loss_eq_gate_charges P c hr W V hfree hw hv hess,
    C.aliasedCount_eq_sum]
  apply Finset.sum_le_sum
  intro k _
  exact C.free_gate_charge_le_alias P c hr hsafe f hc hE1 W V hfree hw hv hess horig k

private theorem psi2W_ge_four (g : Table) (h : g.essential = true) : 4 ≤ g.psi2W := by
  revert h
  rcases g with ⟨a,b,c,d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

/-- Every eliminated gate contributes at least four weight units if all gates
in the original circuit are essential. -/
theorem aliasedPsi2Weight_ge_four {n : Nat} (C : OpenCircuit n)
    (ρ : Fin n → Res) (he : C.EssentialGates) :
    4 * C.aliasedCount ρ ≤ C.aliasedPsi2Weight ρ := by
  induction C with
  | output o => simp [aliasedCount, aliasedPsi2Weight]
  | @gate n g i j rest ih =>
    simp only [aliasedCount, aliasedPsi2Weight]
    cases hs : Res.step g (ρ i) (ρ j) with
    | none =>
      have h := ih (appendValue ρ (.lit n false)) he.2
      exact h
    | some r =>
      have h := ih (appendValue ρ r) he.2
      have hg := psi2W_ge_four g he.1
      simp only
      omega

/-- Quantitative free-input potential drop: each eliminated essential gate
contributes at least three after accounting for credit loss, plus all gains. -/
theorem psi2_free_restriction_drop {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (hsafe : C.DGateSafe)
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (horig : ∀ z, C.isDStar z.val = true → Essential f z) :
    (C.restrict (fixSubst P c)).psi2 +
      3 * (C.aliasedCount (fixRes P c) : Int) +
        C.credit2Gained (C.restrict (fixSubst P c)) ≤ C.psi2 := by
  have hlost := C.free_credit_loss_le_aliasedCount P c hr hsafe f hc hE1 W V hfree hw hv hess horig
  have hweight := C.aliasedPsi2Weight_ge_four (fixRes P c) (C.reduced_essential hr)
  have hbalance := C.psi2_restriction_gain_loss P c
  omega

end OpenCircuit
end SatLowerBound
