import Credit.TwoLevel.EmbeddedRobust
import Credit.TwoLevel.RobustDegree
import SatLowerBound.SparseTree
import Credit.TwoLevel.EmbeddedDegree
import Mathlib.Algebra.BigOperators.Fin

namespace SatLowerBound

/-- A nonempty finite family of trees joined by the indicated Boolean operation. -/
def robustJoinTrees {n : Nat} (p : Bool) : (k : Nat) → (Fin (k + 1) → RobustTree n) → RobustTree n
  | 0, f => f 0
  | k + 1, f => .branch p (f 0) (robustJoinTrees p k (fun i => f i.succ))

theorem robustJoinTrees_mem {n : Nat} (p : Bool) (k : Nat) (f : Fin (k + 1) → RobustTree n) (x : Fin n) :
    x ∈ (robustJoinTrees p k f).support ↔ ∃ i, x ∈ (f i).support := by
  induction k with
  | zero =>
    constructor
    · exact fun h => ⟨0, h⟩
    · rintro ⟨i, hi⟩
      have he : i = 0 := Fin.ext (by have := i.isLt; omega)
      simpa only [robustJoinTrees, he] using hi
  | succ k ih =>
    simp only [robustJoinTrees, RobustTree.support, Finset.mem_union, ih]
    constructor
    · rintro (h | ⟨i, hi⟩)
      · exact ⟨0, h⟩
      · exact ⟨i.succ, hi⟩
    · rintro ⟨i, hi⟩
      induction i using Fin.cases with
      | zero => exact Or.inl hi
      | succ i => exact Or.inr ⟨i, hi⟩

theorem robustJoinTrees_valid {n : Nat} (p : Bool) (k q : Nat) (ρ : Fin n → Option Bool) (f : Fin (k + 1) → RobustTree n)
    (hv : ∀ i, (f i).Valid q ρ) (hd : ∀ i j, i ≠ j → Disjoint (f i).support (f j).support) :
    (robustJoinTrees p k f).Valid q ρ := by
  induction k with
  | zero => exact hv 0
  | succ k ih =>
    refine ⟨hv 0, ih (fun i => f i.succ) (fun i => hv i.succ)
      (fun i j hij => hd i.succ j.succ (fun h => hij (Fin.succ_inj.mp h))), ?_⟩
    apply Finset.disjoint_left.mpr
    intro x hx hy
    obtain ⟨i, hi⟩ := (robustJoinTrees_mem p k (fun i => f i.succ) x).mp hy
    exact Finset.disjoint_left.mp (hd 0 i.succ (by intro he; have hv := congrArg Fin.val he; simp at hv)) hx hi

theorem robustJoinTrees_inputs {n : Nat} (p : Bool) (k : Nat) (f : Fin (k + 1) → RobustTree n) :
    (robustJoinTrees p k f).inputs = ∑ i, (f i).inputs := by
  induction k with
  | zero => simp [robustJoinTrees]
  | succ k ih =>
    rw [robustJoinTrees, RobustTree.inputs, ih]
    exact (Fin.sum_univ_succ (fun i => (f i).inputs)).symm

theorem robustJoinTrees_blocks {n : Nat} (p : Bool) (k : Nat) (f : Fin (k + 1) → RobustTree n) :
    (robustJoinTrees p k f).blocks = ∑ i, (f i).blocks := by
  induction k with
  | zero => simp [robustJoinTrees]
  | succ k ih =>
    rw [robustJoinTrees, RobustTree.blocks, ih]
    exact (Fin.sum_univ_succ (fun i => (f i).blocks)).symm

theorem robustJoinTrees_all {n : Nat} (k : Nat) (f : Fin (k + 1) → RobustTree n) (v : Fin n → Bool) :
    (robustJoinTrees false k f).eval v = true ↔ ∀ i, (f i).eval v = true := by
  induction k with
  | zero =>
    constructor
    · intro h i
      have he : i = 0 := Fin.ext (by have := i.isLt; omega)
      simpa only [robustJoinTrees, he] using h
    · exact fun h => h 0
  | succ k ih =>
    simp only [robustJoinTrees, RobustTree.eval, combine, Bool.false_eq_true, ↓reduceIte, Bool.and_eq_true, ih]
    constructor
    · rintro ⟨h0, hs⟩ i
      exact Fin.cases h0 hs i
    · intro h
      exact ⟨h 0, fun i => h i.succ⟩

theorem robustJoinTrees_any {n : Nat} (k : Nat) (f : Fin (k + 1) → RobustTree n) (v : Fin n → Bool) :
    (robustJoinTrees true k f).eval v = true ↔ ∃ i, (f i).eval v = true := by
  induction k with
  | zero =>
    constructor
    · exact fun h => ⟨0, h⟩
    · rintro ⟨i, hi⟩
      have he : i = 0 := Fin.ext (by have := i.isLt; omega)
      simpa only [robustJoinTrees, he] using hi
  | succ k ih =>
    simp only [robustJoinTrees, RobustTree.eval, combine, ↓reduceIte, Bool.or_eq_true, ih]
    constructor
    · rintro (h | ⟨i, hi⟩)
      · exact ⟨0, h⟩
      · exact ⟨i.succ, hi⟩
    · rintro ⟨i, hi⟩
      induction i using Fin.cases with
      | zero => exact Or.inl hi
      | succ i => exact Or.inr ⟨i, hi⟩

/-- Full-degree leaves are preserved by joining trees. -/
theorem robustJoinTrees_full {n : Nat} (p : Bool) (k : Nat)
    (f : Fin (k+1) → RobustTree n) (hf : ∀ i, (f i).FullLeaves) :
    (robustJoinTrees p k f).FullLeaves := by
  induction k with
  | zero => exact hf 0
  | succ k ih => exact ⟨hf 0,ih (fun i => f i.succ) (fun i => hf i.succ)⟩

/-- A local Boolean block placed in one of the sparse 3-SAT fields. -/
def genericSparseLeaf (m r : Nat) (g : (Fin r → Bool) → Bool) (c : Fin m) (s : Fin 3) :
    RobustTree (m*3*r) :=
  .leaf (fun v => g (fun b => v (pairIndex (pairIndex c s) b))) (blockSupport m r c s)

def genericSparseClauseTree (m r : Nat) (g : (Fin r → Bool) → Bool) (c : Fin m) :
    RobustTree (m*3*r) := robustJoinTrees true 2 (fun s => genericSparseLeaf m r g c s)

def genericSparseTree (m r : Nat) (g : (Fin r → Bool) → Bool) : RobustTree ((m+1)*3*r) :=
  robustJoinTrees false m (fun c => genericSparseClauseTree (m+1) r g c)

theorem genericSparseLeaf_valid (m r k : Nat) (hr : 0 < r) (hkr : k+2 ≤ r)
    (g : (Fin r → Bool) → Bool) (hrobust : Robust k g) (c : Fin m) (s : Fin 3) :
    (genericSparseLeaf m r g c s).Valid k (fun _ => none) := by
  have he : Function.Injective (fun b : Fin r => pairIndex (pairIndex c s) b) :=
    fun _ _ h => (packed_block_injective hr c c s s _ _ h).2.2
  constructor
  · exact hrobust.embedded _ he
  · change k+2 ≤ (freeOn (blockSupport m r c s) (fun _ => none)).card
    simp [freeOn,blockSupport_card m r hr,hkr]

theorem genericSparseClause_disjoint (m r : Nat) (hr : 0 < r) (g : (Fin r → Bool) → Bool)
    (c d : Fin m) (hcd : c ≠ d) :
    Disjoint (genericSparseClauseTree m r g c).support (genericSparseClauseTree m r g d).support := by
  apply Finset.disjoint_left.mpr
  intro i hi hj
  obtain ⟨s,hs⟩ := (robustJoinTrees_mem true 2 (fun s => genericSparseLeaf m r g c s) i).mp hi
  obtain ⟨t,ht⟩ := (robustJoinTrees_mem true 2 (fun t => genericSparseLeaf m r g d t) i).mp hj
  exact Finset.disjoint_left.mp (blockSupport_disjoint m r hr c d s t (Or.inl hcd)) hs ht

theorem genericSparseTree_valid (m r k : Nat) (hr : 0 < r) (hkr : k+2 ≤ r)
    (g : (Fin r → Bool) → Bool) (hrobust : Robust k g) :
    (genericSparseTree m r g).Valid k (fun _ => none) := by
  apply robustJoinTrees_valid
  · intro c
    apply robustJoinTrees_valid
    · exact genericSparseLeaf_valid (m+1) r k hr hkr g hrobust c
    · intro s t hst
      exact blockSupport_disjoint (m+1) r hr c c s t (Or.inr hst)
  · intro c d hcd
    exact genericSparseClause_disjoint (m+1) r hr g c d hcd

theorem genericSparseTree_blocks (m r : Nat) (g : (Fin r → Bool) → Bool) :
    (genericSparseTree m r g).blocks = (m+1)*3 := by
  simp [genericSparseTree,genericSparseClauseTree,robustJoinTrees_blocks,genericSparseLeaf,RobustTree.blocks]

theorem genericSparseTree_support (m r : Nat) (hr : 0 < r) (g : (Fin r → Bool) → Bool) :
    (genericSparseTree m r g).support = Finset.univ := by
  apply Finset.eq_univ_iff_forall.mpr
  intro x
  let ab := unpairIndex hr x
  let cs := unpairIndex (by decide : 0 < 3) ab.1
  have he : pairIndex (pairIndex cs.1 cs.2) ab.2 = x := by
    dsimp [cs,ab]
    rw [pair_unpair,pair_unpair]
  apply (robustJoinTrees_mem false m (fun c => genericSparseClauseTree (m+1) r g c) x).mpr
  refine ⟨cs.1,?_⟩
  apply (robustJoinTrees_mem true 2 (fun s => genericSparseLeaf (m+1) r g cs.1 s) x).mpr
  refine ⟨cs.2,?_⟩
  change x ∈ blockSupport (m+1) r cs.1 cs.2
  exact Finset.mem_image.mpr ⟨ab.2,Finset.mem_univ _,he⟩

theorem genericSparseTree_eval (m r : Nat) (g : (Fin r → Bool) → Bool)
    (v : Fin ((m+1)*3*r) → Bool) :
    (genericSparseTree m r g).eval v = decide (∀ c : Fin (m+1), ∃ s : Fin 3,
      g (fun b => v (pairIndex (pairIndex c s) b)) = true) := by
  apply Bool.eq_iff_iff.mpr
  simp only [genericSparseTree,robustJoinTrees_all,genericSparseClauseTree,robustJoinTrees_any,
    genericSparseLeaf,RobustTree.eval,decide_eq_true_eq]

theorem genericSparseLeaf_full (m r : Nat) (hr : 0 < r)
    (g : (Fin r → Bool) → Bool) (hfull : (BPoly.ofFunction r g).topCoefficient = true)
    (c : Fin m) (s : Fin 3) : (genericSparseLeaf m r g c s).FullLeaves := by
  have he : Function.Injective (fun b : Fin r => pairIndex (pairIndex c s) b) :=
    fun _ _ h => (packed_block_injective hr c c s s _ _ h).2.2
  constructor
  · rw [blockSupport_card m r hr]
    exact hr
  · exact embedded_leaf_full_degree _ he g hfull

theorem genericSparseTree_full (m r : Nat) (hr : 0 < r)
    (g : (Fin r → Bool) → Bool) (hfull : (BPoly.ofFunction r g).topCoefficient = true) :
    (genericSparseTree m r g).FullLeaves := by
  apply robustJoinTrees_full
  intro c
  apply robustJoinTrees_full
  exact genericSparseLeaf_full (m+1) r hr g hfull c

/-- Sparse tree indexed by a positive number of remaining clauses. -/
def positiveSparseTree (M r : Nat) (hM : 0 < M) (g : (Fin r → Bool) → Bool) : RobustTree (M*3*r) := by
  cases M with
  | zero => omega
  | succ m => exact genericSparseTree m r g

theorem positiveSparseTree_valid (M r k : Nat) (hM : 0 < M) (hr : 0 < r) (hkr : k+2 ≤ r)
    (g : (Fin r → Bool) → Bool) (hrobust : Robust k g) :
    (positiveSparseTree M r hM g).Valid k (fun _ => none) := by
  cases M with
  | zero => omega
  | succ m => exact genericSparseTree_valid m r k hr hkr g hrobust

theorem positiveSparseTree_support (M r : Nat) (hM : 0 < M) (hr : 0 < r)
    (g : (Fin r → Bool) → Bool) : (positiveSparseTree M r hM g).support = Finset.univ := by
  cases M with
  | zero => omega
  | succ m => exact genericSparseTree_support m r hr g

theorem positiveSparseTree_full (M r : Nat) (hM : 0 < M) (hr : 0 < r)
    (g : (Fin r → Bool) → Bool) (hfull : (BPoly.ofFunction r g).topCoefficient = true) :
    (positiveSparseTree M r hM g).FullLeaves := by
  cases M with
  | zero => omega
  | succ m => exact genericSparseTree_full m r hr g hfull

theorem positiveSparseTree_blocks (M r : Nat) (hM : 0 < M) (g : (Fin r → Bool) → Bool) :
    (positiveSparseTree M r hM g).blocks = 3*M := by
  cases M with
  | zero => omega
  | succ m =>
    have hh := genericSparseTree_blocks m r g
    change (genericSparseTree m r g).blocks = _
    omega

theorem positiveSparseTree_eval (M r : Nat) (hM : 0 < M) (g : (Fin r → Bool) → Bool)
    (v : Fin (M*3*r) → Bool) :
    (positiveSparseTree M r hM g).eval v = decide (∀ c : Fin M, ∃ s : Fin 3,
      g (fun b => v (pairIndex (pairIndex c s) b)) = true) := by
  cases M with
  | zero => omega
  | succ m => exact genericSparseTree_eval m r g v

end SatLowerBound
