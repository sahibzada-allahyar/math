import Credit.TwoLevel.ChainCut

/-! Combined structural cap on free-input two-level charges. -/
namespace SatLowerBound
namespace OpenCircuit

/-- A gate cannot serve as a first credit for one input and a second credit for
another under the manuscript's E1 hypothesis. -/
theorem first_second_roles_disjoint {n : Nat} (C : OpenCircuit n) (hr : C.Reduced)
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (z₁ z₂ : Fin n) (W G : Nat) (hz₂ : Essential f z₂)
    (hfirst : G ∈ C.users z₁.val)
    (hstar : C.isDStar z₂.val = true) (hW : W ∈ C.users z₂.val)
    (hsecond : G ∈ C.users W) : False := by
  obtain ⟨g,a,b,hgate,hab⟩ := C.mem_users.mp hfirst
  exact C.second_role_has_no_primary hr f hc hE1 z₂ hz₂ W G hstar hW hsecond
    g a b hgate z₁ hab

/-- The free-input allocation assigns at most two total charges to one gate.
This is the general role-count bound; the manuscript's stronger one-charge
bound for eliminated gates requires the two-chain survival argument. -/
theorem free_gate_total_charge_le_two {n : Nat} (C : OpenCircuit n)
    (P c : Fin n → Bool) (hr : C.Reduced) (hsafe : C.DGateSafe)
    (f : (Fin n → Bool) → Bool) (hc : ∀ x, C.eval x = f x) (hE1 : E1 f)
    (W V : Fin n → Nat)
    (hfree : ∀ z, C.isD z.val = true → P z = false)
    (hw : ∀ z, C.isD z.val = true → W z ∈ C.users z.val)
    (hv : ∀ z, C.isDStar z.val = true → V z ∈ C.users (W z))
    (hess : ∀ z, C.isDStar z.val = true → Essential (C.restrict (fixSubst P c)).eval z)
    (horig : ∀ z, C.isDStar z.val = true → Essential f z)
    (k : Nat) (g : Table) (a b : Nat) (hk : C.gateAt k = some (g,a,b)) :
    C.gateFirstCharge (C.restrict (fixSubst P c)) (fixRes P c) W k +
      C.gateSecondCharge (C.restrict (fixSubst P c)) (fixRes P c) W V k ≤ 2 := by
  let D := C.restrict (fixSubst P c)
  let ρ := fixRes P c
  change C.gateFirstCharge D ρ W k + C.gateSecondCharge D ρ W V k ≤ 2
  by_cases hf : ∃ z, C.isD z.val = true ∧ W z = k
  · obtain ⟨z₁, hz₁, hkW⟩ := hf
    have hsecondZero : C.gateSecondCharge D ρ W V k = 0 := by
      unfold gateSecondCharge
      apply Finset.sum_eq_zero
      intro z hz
      have hVk : V z = k := (Finset.mem_filter.mp hz).2
      have hstar : C.isDStar z.val = false := by
        cases hs : C.isDStar z.val with
        | false => rfl
        | true =>
          exfalso
          have hfirst : k ∈ C.users z₁.val := by simpa [hkW] using hw z₁ hz₁
          have hsecond : k ∈ C.users (W z) := by simpa [hVk] using hv z hs
          exact C.first_second_roles_disjoint hr f hc hE1 z₁ z (W z) k (horig z hs)
            hfirst hs (hw z (C.isD_of_isDStar z.val hs)) hsecond
      have hbound := C.free_second_charge_bound P c hr W V hfree hw hv hess z
      simp [indicator, hstar] at hbound
      exact hbound
    have hfirst := C.gateFirstCharge_le_one D ρ hsafe W hw k
    rw [hsecondZero]
    omega
  · have hfirstZero : C.gateFirstCharge D ρ W k = 0 := by
      unfold gateFirstCharge
      apply Finset.sum_eq_zero
      intro z hz
      have hWk : W z = k := (Finset.mem_filter.mp hz).2
      have hDz : C.isD z.val = false := by
        apply Bool.eq_false_iff.mpr
        intro hd
        exact hf ⟨z,hd,hWk⟩
      have hbound := C.first_charge_bound D ρ W z
      simp [indicator, hDz] at hbound
      exact hbound
    have hsecond := C.gateSecondCharge_le_two P c hr hsafe W V hfree hw hv hess k g a b hk
    change C.gateFirstCharge D ρ W k + C.gateSecondCharge D ρ W V k ≤ 2
    rw [hfirstZero]
    simpa only [Nat.zero_add] using hsecond

end OpenCircuit
end SatLowerBound
