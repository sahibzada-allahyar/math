import Credit.TwoLevel.TightGain

/-! The first both-bad branch of Main Lemma B: either a fourth gate is
eliminated or the surviving nonlinear chain yields both new credits. -/
namespace SatLowerBound
namespace MAContext
open OpenCircuit

/-- When the two gates in the other chain are outside the three-gate set,
one of them being eliminated gives four eliminations; if both are kept,
their chain provides the two gains. -/
theorem tight_distinct_chain_or_four {n : Nat} {f : (Fin n → Bool) → Bool}
    {C : OpenCircuit n} (h : MAContext f C) (x y : Fin n) (hxy : x ≠ y) (b : Bool)
    (hx2 : 2 ≤ C.refCount x.val) (T U R V V₂ : Nat)
    (hTU : T ≠ U) (hTx : T ∈ C.users x.val) (hUx : U ∈ C.users x.val)
    {gT : Table} {aT dT : Nat} (hgT : C.gateAt T = some (gT,aT,dT))
    (haT : aT < n) (hdT : dT < n) (hTc : (C.resAt (singleRes x b) T).isConst = true)
    (hRT : R ∈ C.users T)
    (hTpar : (C.tableAt T).parity = false) (hUpar : (C.tableAt U).parity = false)
    (hRpar : (C.tableAt R).parity = false)
    (hTV : T ≠ V) (husersY : C.users y.val = {T,V})
    {gV : Table} {aV dV : Nat} (hgV : C.gateAt V = some (gV,aV,dV))
    (hVnl : gV.nonlinear = true) (husersV : C.users V = {V₂})
    {g₂ : Table} {a₂ d₂ : Nat} (hg₂ : C.gateAt V₂ = some (g₂,a₂,d₂))
    (hg₂nl : g₂.nonlinear = true)
    (hVout : V ∉ ({T,U,R} : Finset Nat)) (hV₂out : V₂ ∉ ({T,U,R} : Finset Nat)) :
    (C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2 := by
  have hRx : R ∉ C.users x.val := h.no_triangle x.isLt hTx hRT
  have hTR : T ≠ R := fun he => hRx (he ▸ hTx)
  have hUR : U ≠ R := fun he => hRx (he ▸ hUx)
  have halias : ∀ k ∈ C.users x.val, C.isAliased (singleRes x b) k = true := by
    intro k hk
    obtain ⟨g,a,d,hg,had⟩ := C.mem_users.mp hk
    apply C.isAliased_of_const _ hg
    have hxres : C.resAt (singleRes x b) x.val = .const b := by
      rw [C.resAt_single_input x b x]
      simp
    rcases had with ha | hd
    · left; rw [ha, hxres]; rfl
    · right; rw [hd, hxres]; rfl
  obtain ⟨gR,aR,dR,hgR,habR⟩ := C.mem_users.mp hRT
  have halR : C.isAliased (singleRes x b) R = true := by
    apply C.isAliased_of_const _ hgR
    rcases habR with ha | hd
    · left; rw [ha]; exact hTc
    · right; rw [hd]; exact hTc
  let B : Finset Nat := {T,U,R}
  have hBcard : B.card = 3 := by simp [B,hTU,hTR,hUR]
  have hBal : ∀ k ∈ B, C.isAliased (singleRes x b) k = true := by
    intro k hk
    simp only [B, Finset.mem_insert, Finset.mem_singleton] at hk
    rcases hk with he | he | he
    · simpa [he] using halias T hTx
    · simpa [he] using halias U hUx
    · simpa [he] using halR
  have hBrole : ∀ k ∈ B, C.isAliased (singleRes x b) k = true ∧
      (C.tableAt k).parity = false ∧
      (k ∈ C.users x.val ∨ ∃ P g a d, C.gateAt P = some (g,a,d) ∧
        a < n ∧ d < n ∧ k ∈ C.users P) := by
    intro k hk
    have hal := hBal k hk
    simp only [B, Finset.mem_insert, Finset.mem_singleton] at hk
    rcases hk with he | he | he
    · rw [he] at hal ⊢; exact ⟨hal,hTpar,Or.inl hTx⟩
    · rw [he] at hal ⊢; exact ⟨hal,hUpar,Or.inl hUx⟩
    · rw [he] at hal ⊢; exact ⟨hal,hRpar,Or.inr ⟨T,gT,aT,dT,hgT,haT,hdT,hRT⟩⟩
  have hfour : ∀ S, S ∉ B → C.isAliased (singleRes x b) S = true →
      (C.restrict (singleSubst x b)).psi2 + 14 ≤ C.psi2 := by
    intro S hSout hSal
    apply h.four_eliminated_two_readers_drop x b hx2 (insert S B)
      (by rw [Finset.card_insert_of_notMem hSout, hBcard]) ?_ T U hTU ?_ ?_ hTx hUx
    · intro k hk
      rcases Finset.mem_insert.mp hk with he | hk
      · simpa [he] using hSal
      · exact hBal k hk
    · simp [B]
    · simp [B]
  cases hVal : C.isAliased (singleRes x b) V with
  | true => exact hfour V hVout hVal
  | false =>
    cases hV₂al : C.isAliased (singleRes x b) V₂ with
    | true => exact hfour V₂ hV₂out hV₂al
    | false =>
      have hVkept : C.isKept (singleRes x b) V = true := by
        rw [C.isKept_eq_not_isAliased _ hgV, hVal]
        rfl
      have hV₂kept : C.isKept (singleRes x b) V₂ = true := by
        rw [C.isKept_eq_not_isAliased _ hg₂, hV₂al]
        rfl
      exact h.tight_surviving_chain_drop x y hxy b hx2 B (by omega) hBrole
        T V V₂ hTV husersY hTc hgV hVnl hVkept husersV hg₂ hg₂nl hV₂kept

end MAContext
end SatLowerBound
