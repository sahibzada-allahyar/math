import Credit.TwoLevel.AsymptoticFidelity

/-! A finite network given by an explicit topological order, independent of
the inductive `Circuit` syntax. -/
namespace SatLowerBound

/-- A binary node whose predecessors are among the currently available wires. -/
structure NetworkNode (n : Nat) where
  table : Table
  left : Fin n
  right : Fin n

/-- A zero-operand gate can be represented using any available wire and a
constant binary truth table, without changing the gate count. -/
def NetworkNode.constant {n : Nat} (wire : Fin n) (b : Bool) : NetworkNode n :=
  ⟨Table.ofFunction (fun _ _ => b), wire, wire⟩

/-- A unary gate can be represented using the same available wire twice. -/
def NetworkNode.unary {n : Nat} (wire : Fin n) (f : Bool → Bool) : NetworkNode n :=
  ⟨Table.ofFunction (fun a _ => f a), wire, wire⟩

theorem NetworkNode.constant_eval {n : Nat} (wire : Fin n) (b : Bool) (v : Fin n → Bool) :
    (NetworkNode.constant wire b).table.eval
      (v (NetworkNode.constant wire b).left) (v (NetworkNode.constant wire b).right) = b := by
  simp [NetworkNode.constant,Table.eval_ofFunction]

theorem NetworkNode.unary_eval {n : Nat} (wire : Fin n) (f : Bool → Bool) (v : Fin n → Bool) :
    (NetworkNode.unary wire f).table.eval
      (v (NetworkNode.unary wire f).left) (v (NetworkNode.unary wire f).right) = f (v wire) := by
  simp [NetworkNode.unary,Table.eval_ofFunction]

/-- Reindex a node when the number of available wires is propositionally equal. -/
def NetworkNode.cast {n m : Nat} (h : n = m) (g : NetworkNode n) : NetworkNode m :=
  { table := g.table, left := Fin.cast h g.left, right := Fin.cast h g.right }

/-- A network with `s` topologically ordered gates, each reading only primary
inputs or earlier gates, and an arbitrary designated output wire. -/
structure OrderedNetwork (n s : Nat) where
  node : (i : Fin s) → NetworkNode (n + i.val)
  output : Fin (n + s)

/-- Remove the first gate, treating its output as an additional input of the
remaining network. -/
def OrderedNetwork.tail {n s : Nat} (N : OrderedNetwork n (s + 1)) : OrderedNetwork (n + 1) s where
  node i := (N.node i.succ).cast (by simp; omega)
  output := Fin.cast (by omega) N.output

/-- Direct evaluation of the ordered network by processing its nodes in order. -/
def OrderedNetwork.eval : {n s : Nat} → OrderedNetwork n s → (Fin n → Bool) → Bool
  | _, 0, N, v => v (Fin.cast (by omega) N.output)
  | _, _ + 1, N, v =>
    let first := N.node 0
    N.tail.eval (extend v (first.table.eval (v first.left) (v first.right)))

/-- Compile the ordered network into the circuit syntax used in the bound. -/
def OrderedNetwork.toCircuit : {n s : Nat} → OrderedNetwork n s → Circuit n
  | _, 0, N => .output (Fin.cast (by omega) N.output)
  | _, _ + 1, N =>
    let first := N.node 0
    .gate first.table first.left first.right N.tail.toCircuit

theorem OrderedNetwork.toCircuit_eval {n s : Nat} (N : OrderedNetwork n s) (v : Fin n → Bool) :
    N.toCircuit.eval v = N.eval v := by
  induction s generalizing n with
  | zero => rfl
  | succ s ih =>
    change N.tail.toCircuit.eval _ = N.tail.eval _
    exact ih N.tail _

theorem OrderedNetwork.toCircuit_size {n s : Nat} (N : OrderedNetwork n s) :
    N.toCircuit.size = s := by
  induction s generalizing n with
  | zero => rfl
  | succ s ih =>
    change N.tail.toCircuit.size + 1 = s + 1
    rw [ih N.tail]

/-- The checked asymptotic theorem applies directly to topologically ordered
networks, with `s` counting all internal nodes. -/
theorem seventeen_sevenths_epsilon_ordered_network (ε : ℝ) (hε : 0 < ε) :
    ∃ w₀ : Nat, ∀ w ≥ w₀, ∀ s : Nat, ∀ N : OrderedNetwork (inputBits w) s,
      (∀ v, N.eval v = satFunction w v) →
      ((17 / 7 : ℝ) - ε) * inputBits w ≤ (s : ℝ) := by
  obtain ⟨w₀,hw₀⟩ := seventeen_sevenths_epsilon ε hε
  refine ⟨w₀, ?_⟩
  intro w hw s N hN
  have hc : N.toCircuit.Computes (satFunction w) := by
    intro v
    rw [N.toCircuit_eval]
    exact hN v
  simpa [N.toCircuit_size] using hw₀ w hw N.toCircuit hc

end SatLowerBound
