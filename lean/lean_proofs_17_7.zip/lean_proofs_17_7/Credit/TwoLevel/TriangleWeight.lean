import Credit.TwoLevel.DeadRolesGeneral
import Credit.PsiTriangle

/-! Gate-weight part of the two-level input-triangle rewrite. -/
namespace SatLowerBound
namespace Table

set_option maxRecDepth 4096 in
theorem triangle_psi2W (p q : Table) (hq : q.essential = true) :
    (triangle p q).psi2W ≤ q.psi2W := by
  revert hq
  rcases p with ⟨a, b, c, d⟩
  rcases q with ⟨e, f, g, h⟩
  cases a <;> cases b <;> cases c <;> cases d <;>
    cases e <;> cases f <;> cases g <;> cases h <;> decide

theorem swap_psi2W (g : Table) : g.swap.psi2W = g.psi2W := by
  rcases g with ⟨a,b,c,d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

end Table
namespace OpenCircuit
namespace PsiTriangleAux

theorem replaceAt_psi2Weight {n : Nat} (C : OpenCircuit n) {q : Nat} {g f : Table}
    {i j a b : Nat} (hq : C.gateAt q = some (g, i, j)) (ha : a < q) (hb : b < q) :
    (replaceAt C q f a b).psi2Weight + g.psi2W = C.psi2Weight + f.psi2W := by
  induction C with
  | output s => simp [gateAt] at hq
  | @gate n g' i' j' rest ih =>
    by_cases hqn : q = n
    · rw [hqn] at hq ha hb
      rw [hqn, replaceAt_head g' f i' j' rest ha hb]
      simp only [gateAt_head, Option.some.injEq, Prod.mk.injEq] at hq
      obtain ⟨hg, -, -⟩ := hq
      have e1 : (gate f ⟨a, ha⟩ ⟨b, hb⟩ rest).psi2Weight = f.psi2W + rest.psi2Weight := rfl
      have e2 : (gate g' i' j' rest).psi2Weight = g'.psi2W + rest.psi2Weight := rfl
      rw [e1, e2, hg]
      omega
    · rw [replaceAt_tail g' f i' j' rest hqn]
      rw [gateAt_tail g' i' j' rest hqn] at hq
      have h1 := ih hq
      have e1 : (gate g' i' j' (replaceAt rest q f a b)).psi2Weight =
          g'.psi2W + (replaceAt rest q f a b).psi2Weight := rfl
      have e2 : (gate g' i' j' rest).psi2Weight = g'.psi2W + rest.psi2Weight := rfl
      rw [e1, e2]
      omega

/-- Replacing one instruction leaves every other gate instruction unchanged. -/
theorem replaceAt_gateAt_of_ne {n : Nat} (C : OpenCircuit n) (q : Nat)
    (f : Table) (a b k : Nat) (hkq : k ≠ q) :
    (replaceAt C q f a b).gateAt k = C.gateAt k := by
  induction C with
  | output o => rfl
  | @gate n g i j rest ih =>
    by_cases hqn : q = n ∧ a < n ∧ b < n
    · rw [hqn.1, replaceAt_head g f i j rest hqn.2.1 hqn.2.2]
      have hkn : k ≠ n := by omega
      rw [gateAt_tail f ⟨a,hqn.2.1⟩ ⟨b,hqn.2.2⟩ rest hkn,
        gateAt_tail g i j rest hkn]
    · have hrep : replaceAt (gate g i j rest) q f a b =
          gate g i j (replaceAt rest q f a b) := dite_eq_right hqn
      rw [hrep]
      by_cases hkn : k = n
      · subst k
        rw [gateAt_head,gateAt_head]
      · rw [gateAt_tail g i j (replaceAt rest q f a b) hkn,
          gateAt_tail g i j rest hkn,ih]

/-- The triangle rewrite preserves each first credit, under the same
forbidden-primary-pair condition used in Lemma 6.12. -/
theorem replaceAt_preserves_D_triangle {n : Nat} (C : OpenCircuit n) (hsafe : C.DGateSafe)
    {q x P u : Nat} {g p f : Table} {i j c d : Nat}
    (hq : C.gateAt q = some (g,i,j)) (hij : (i = x ∧ j = P) ∨ (i = P ∧ j = x))
    (hx : x < n) (hP : C.gateAt P = some (p,c,d))
    (hcd : (c = x ∧ d = u) ∨ (c = u ∧ d = x)) :
    ∀ z : Fin n, C.isD z.val = true → (replaceAt C q f x u).isD z.val = true := by
  obtain ⟨_,_,hiq,hjq⟩ := gateAt_bounds C hq
  obtain ⟨hnP,_,hcP,hdP⟩ := gateAt_bounds C hP
  have hPq : P < q := by rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have hxq : x < q := by rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have huP : u < P := by rcases hcd with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have huq : u < q := by omega
  intro z hCz
  have hzn := z.isLt
  by_cases hzu : z.val = u
  · exfalso
    have hcn : c < n := by rcases hcd with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
    have hdn : d < n := by rcases hcd with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
    obtain ⟨hc',hd'⟩ := hsafe P p c d hP hcn hdn
    rcases hcd with ⟨_,h2⟩ | ⟨h1,_⟩
    · rw [h2,← hzu,hCz] at hd'
      exact Bool.noConfusion hd'
    · rw [h1,← hzu,hCz] at hc'
      exact Bool.noConfusion hc'
  · have hzP : z.val ≠ P := by omega
    have href : (replaceAt C q f x u).refCount z.val = C.refCount z.val := by
      have hr := replaceAt_refCount C (f := f) hq hxq huq z.val
      rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> split_ifs at hr <;> omega
    have hfirst : (replaceAt C q f x u).firstUserNL z.val = C.firstUserNL z.val := by
      by_cases hzx : z.val = x
      · rw [hzx]
        apply replaceAt_firstUserNL_of_early C f x u hP hPq
        rcases hcd with ⟨h1,_⟩ | ⟨_,h2⟩
        · exact Or.inl h1
        · exact Or.inr h2
      · apply replaceAt_firstUserNL_of_ne C hq hxq huq
        · rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
        · rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
        · omega
        · omega
    unfold isD at hCz ⊢
    rw [href,hfirst]
    exact hCz

/-- The second credit also survives the triangle rewrite, following the
successor-role argument of Lemma 6.12. -/
theorem replaceAt_preserves_DStar_triangle {n : Nat} (C : OpenCircuit n)
    (hsafe : C.DGateSafe) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z)
    {q x P u : Nat} {g p f : Table} {i j c d : Nat}
    (hq : C.gateAt q = some (g,i,j)) (hij : (i = x ∧ j = P) ∨ (i = P ∧ j = x))
    (hx : x < n) (hP : C.gateAt P = some (p,c,d))
    (hcd : (c = x ∧ d = u) ∨ (c = u ∧ d = x)) :
    ∀ z : Fin n, C.isDStar z.val = true → (replaceAt C q f x u).isDStar z.val = true := by
  obtain ⟨_,_,hiq,hjq⟩ := C.gateAt_bounds hq
  obtain ⟨hnP,_,hcP,hdP⟩ := C.gateAt_bounds hP
  have hPq : P < q := by rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have hxq : x < q := by rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have huP : u < P := by rcases hcd with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have huq : u < q := by omega
  have hPx : P ∈ C.users x := C.mem_users.mpr ⟨p,c,d,hP,by
    rcases hcd with ⟨h1,_⟩ | ⟨_,h2⟩
    · exact Or.inl h1
    · exact Or.inr h2⟩
  have hqx : q ∈ C.users x := C.mem_users.mpr ⟨g,i,j,hq,by
    rcases hij with ⟨h1,_⟩ | ⟨_,h2⟩
    · exact Or.inl h1
    · exact Or.inr h2⟩
  intro z hz
  have hDz := C.isD_of_isDStar z.val hz
  obtain ⟨_,W,hW,hDW⟩ := (C.isDStar_iff z.val).mp hz
  have huz := C.users_singleton_of_isD z.val W hDz hW
  have hzx : z.val ≠ x := by
    intro he
    rw [← he,huz,Finset.mem_singleton] at hPx hqx
    omega
  have hzu : z.val ≠ u := by
    intro he
    have hc : c < n := by rcases hcd with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> have := z.isLt <;> omega
    have hd : d < n := by rcases hcd with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> have := z.isLt <;> omega
    obtain ⟨hc',hd'⟩ := hsafe P p c d hP hc hd
    rcases hcd with ⟨_,h2⟩ | ⟨h1,_⟩
    · rw [h2,← he,hDz] at hd'; contradiction
    · rw [h1,← he,hDz] at hc'; contradiction
  obtain ⟨w,a',b',hw,hwz⟩ := C.mem_users.mp hW
  have hWge := (C.gateAt_bounds hw).1
  have hWx : W ≠ x := by omega
  have hWP : W ≠ P := by
    intro he
    rw [he,hP] at hw
    cases hw
    rcases hcd with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> rcases hwz with h3 | h3 <;> omega
  have hWq : W ≠ q := by
    intro he
    rw [he,hq] at hw
    cases hw
    rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> rcases hwz with h3 | h3 <;> have := z.isLt <;> omega
  have hzEss : Essential C.eval z := hused z (by
    rw [C.usage_singleUse]
    have := ((C.isD_iff z.val).mp hDz).1
    omega)
  have hWu : W ≠ u := by
    intro he
    have hPW : P ∈ C.users W := C.mem_users.mpr ⟨p,c,d,hP,by
      rcases hcd with ⟨_,h2⟩ | ⟨h1,_⟩
      · exact Or.inr (h2.trans he.symm)
      · exact Or.inl (h1.trans he.symm)⟩
    have hoperand : c = (⟨x,hx⟩ : Fin n).val ∨ d = (⟨x,hx⟩ : Fin n).val := by
      rcases hcd with ⟨h1,_⟩ | ⟨_,h2⟩
      · exact Or.inl h1
      · exact Or.inr h2
    exact C.second_role_has_no_primary_unreduced C.eval (fun _ => rfl) hE1
      z hzEss W P hz hW hPW p c d hP ⟨x,hx⟩ hoperand
  have href : (replaceAt C q f x u).refCount W = C.refCount W := by
    have hr := replaceAt_refCount C (f := f) hq hxq huq W
    rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> split_ifs at hr <;> omega
  have hfirst : (replaceAt C q f x u).firstUserNL W = C.firstUserNL W := by
    apply replaceAt_firstUserNL_of_ne C hq hxq huq <;>
      (rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega)
  have hDW' : (replaceAt C q f x u).isD W = true := by
    unfold isD at hDW ⊢
    rw [href,hfirst]
    exact hDW
  have hWnew : W ∈ (replaceAt C q f x u).users z.val := by
    apply (replaceAt C q f x u).mem_users.mpr
    refine ⟨w,a',b',?_,hwz⟩
    rw [replaceAt_gateAt_of_ne C q f x u W hWq]
    exact hw
  exact ((replaceAt C q f x u).isDStar_iff z.val).mpr
    ⟨replaceAt_preserves_D_triangle C hsafe hq hij hx hP hcd z hDz,W,hWnew,hDW'⟩

/-- A triangle rewrite preserves the function and cannot increase the
 two-level potential before resolving any degenerate replacement gate. -/
theorem twoLevel_triangle_core {n : Nat} (C : OpenCircuit n)
    (hsafe : C.DGateSafe) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z)
    {q x P u : Nat} {g p f : Table} {i j c d : Nat}
    (hq : C.gateAt q = some (g,i,j)) (hij : (i = x ∧ j = P) ∨ (i = P ∧ j = x))
    (hx : x < n) (hP : C.gateAt P = some (p,c,d))
    (hcd : (c = x ∧ d = u) ∨ (c = u ∧ d = x)) (hw : f.psi2W ≤ g.psi2W)
    (hv : ∀ v, f.eval (C.valueAt v x) (C.valueAt v u) =
      g.eval (C.valueAt v i) (C.valueAt v j)) :
    ∃ D : OpenCircuit n, D.size = C.size ∧ D.predecessorSum < C.predecessorSum ∧
      D.psi2 ≤ C.psi2 ∧ ∀ v, D.eval v = C.eval v := by
  obtain ⟨_,_,hiq,hjq⟩ := C.gateAt_bounds hq
  obtain ⟨_,_,hcP,hdP⟩ := C.gateAt_bounds hP
  have hPq : P < q := by rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have hxq : x < q := by rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have huP : u < P := by rcases hcd with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  have huq : u < q := by omega
  refine ⟨replaceAt C q f x u,replaceAt_size C q f x u,?_,?_,
    fun v => replaceAt_eval C hq hxq huq v (hv v)⟩
  · have hh := replaceAt_predecessorSum C (f := f) hq hxq huq
    rcases hij with ⟨h1,h2⟩ | ⟨h1,h2⟩ <;> omega
  · have hweight := replaceAt_psi2Weight C (f := f) hq hxq huq
    have hd : C.dCount ≤ (replaceAt C q f x u).dCount :=
      dCount_mono C _ (replaceAt_preserves_D_triangle C hsafe hq hij hx hP hcd)
    have hstar : C.dStarCount ≤ (replaceAt C q f x u).dStarCount := by
      unfold dStarCount
      refine Finset.sum_le_sum fun z _ => ?_
      show indicator (C.isDStar z.val) ≤ indicator ((replaceAt C q f x u).isDStar z.val)
      cases hz : C.isDStar z.val with
      | false => exact Nat.zero_le _
      | true => exact Nat.le_of_eq (by rw [replaceAt_preserves_DStar_triangle C hsafe hE1 hused hq hij hx hP hcd z hz])
    unfold psi2
    omega

end PsiTriangleAux

/-- The triangle step in Lemma 6.12, before resolving degenerate gates. -/
theorem twoLevel_triangle_step {n : Nat} (C : OpenCircuit n) (hr : C.Reduced)
    (hsafe : C.DGateSafe) (hE1 : E1 C.eval)
    (hused : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential C.eval z)
    (ht : ¬ C.NoInputTriangles (fun _ => none)) :
    ∃ D : OpenCircuit n, D.size = C.size ∧ D.predecessorSum < C.predecessorSum ∧
      D.psi2 ≤ C.psi2 ∧ ∀ x, D.eval x = C.eval x := by
  obtain ⟨q,g,i,j,hq,htr⟩ := PsiTriangleAux.exists_flat_triangle C ht
  have hg : g.essential = true := C.essentialGates_gate (C.reduced_essential hr) hq
  have hgs : g.swap.essential = true := by rw [Table.swap_essential]; exact hg
  rcases htr with ⟨hin,t,c,d,hjP,hcd⟩ | ⟨hjn,t,c,d,hiP,hcd⟩
  · rcases hcd with hc | hd
    · refine PsiTriangleAux.twoLevel_triangle_core C hsafe hE1 hused (x := i) (P := j) (u := d)
        (f := Table.triangle t g) hq (Or.inl ⟨rfl,rfl⟩) hin hjP (Or.inl ⟨hc,rfl⟩)
        (Table.triangle_psi2W t g hg) ?_
      intro v
      rw [Table.triangle_eval,valueAt_gate C v hjP,hc]
    · refine PsiTriangleAux.twoLevel_triangle_core C hsafe hE1 hused (x := i) (P := j) (u := c)
        (f := Table.triangle t.swap g) hq (Or.inl ⟨rfl,rfl⟩) hin hjP (Or.inr ⟨rfl,hd⟩)
        (Table.triangle_psi2W t.swap g hg) ?_
      intro v
      rw [Table.triangle_eval,Table.swap_eval,valueAt_gate C v hjP,hd]
  · rcases hcd with hc | hd
    · refine PsiTriangleAux.twoLevel_triangle_core C hsafe hE1 hused (x := j) (P := i) (u := d)
        (f := Table.triangle t g.swap) hq (Or.inr ⟨rfl,rfl⟩) hjn hiP (Or.inl ⟨hc,rfl⟩)
        (Nat.le_trans (Table.triangle_psi2W t g.swap hgs) (Nat.le_of_eq (Table.swap_psi2W g))) ?_
      intro v
      rw [Table.triangle_eval,Table.swap_eval,valueAt_gate C v hiP,hc]
    · refine PsiTriangleAux.twoLevel_triangle_core C hsafe hE1 hused (x := j) (P := i) (u := c)
        (f := Table.triangle t.swap g.swap) hq (Or.inr ⟨rfl,rfl⟩) hjn hiP (Or.inr ⟨rfl,hd⟩)
        (Nat.le_trans (Table.triangle_psi2W t.swap g.swap hgs) (Nat.le_of_eq (Table.swap_psi2W g))) ?_
      intro v
      rw [Table.triangle_eval,Table.swap_eval,Table.swap_eval,valueAt_gate C v hiP,hd]

end OpenCircuit
end SatLowerBound
