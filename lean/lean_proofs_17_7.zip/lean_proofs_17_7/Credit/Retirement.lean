import Credit.PsiMinimal
import Credit.Hypotheses

/-!
# Credit.Retirement: the final 3-block and retirement of a 3-block (Lemma 4.7, Theorem 4.8)

Complete proofs modulo the statements of packages A–F.
-/

namespace SatLowerBound

namespace OpenCircuit

/-- A circuit with at most one gate is determined by (at most) two inputs. -/
theorem eval_determined_of_size_le_one {n : Nat} (C : OpenCircuit n) (h : C.size ≤ 1)
    (w : Fin n) : ∃ i j : Fin n, ∀ u v : Fin n → Bool, u i = v i → u j = v j →
      C.eval u = C.eval v := by
  match C, h with
  | .output (.constant b), _ => exact ⟨w, w, fun _ _ _ _ => rfl⟩
  | .output (.wire k neg), _ =>
    refine ⟨k, k, fun u v hu _ => ?_⟩
    simp [eval, Signal.eval, hu]
  | .gate g i j (.output (.constant b)), _ => exact ⟨w, w, fun _ _ _ _ => rfl⟩
  | .gate g i j (.output (.wire k neg)), _ =>
    by_cases hk : k.val < n
    · refine ⟨⟨k.val, hk⟩, ⟨k.val, hk⟩, fun u v hu _ => ?_⟩
      simp [eval, Signal.eval, extend, hk, hu]
    · refine ⟨i, j, fun u v hu hv => ?_⟩
      simp [eval, Signal.eval, extend, hk, hu, hv]
  | .gate _ _ _ (.gate _ _ _ _), h => simp [size] at h

/-- A circuit for a function with three essential inputs has at least two gates. -/
theorem two_le_size_of_essential3 {n : Nat} (C : OpenCircuit n) (x y z : Fin n)
    (hxy : x ≠ y) (hxz : x ≠ z) (hyz : y ≠ z) (hx : Essential C.eval x)
    (hy : Essential C.eval y) (hz : Essential C.eval z) : 2 ≤ C.size := by
  by_contra hs'
  have hs : C.size < 2 := Nat.lt_of_not_le hs'
  obtain ⟨i, j, hij⟩ := C.eval_determined_of_size_le_one (by omega) x
  have key : ∀ w : Fin n, w ≠ i → w ≠ j → ¬ Essential C.eval w := by
    rintro w hwi hwj ⟨u, v, huv, hne⟩
    exact hne (hij u v (huv i (Ne.symm hwi)) (huv j (Ne.symm hwj)))
  by_cases hxi : x = i
  · by_cases hyj : y = j
    · exact key z (fun h => hxz (hxi.trans h.symm)) (fun h => hyz (hyj.trans h.symm)) hz
    · by_cases hyi : y = i
      · exact hxy (hxi.trans hyi.symm)
      · exact key y hyi hyj hy
  · by_cases hxj : x = j
    · by_cases hyi : y = i
      · exact key z (fun h => hyz (hyi.trans h.symm)) (fun h => hxz (hxj.trans h.symm)) hz
      · by_cases hyj : y = j
        · exact hxy (hxj.trans hyj.symm)
        · exact key y hyi hyj hy
    · exact key x hxi hxj hx

end OpenCircuit

open OpenCircuit

/-- The final block (manuscript, proof of Theorem 4.8, case `ℓ = 4`, `B = 1`): every circuit for
a MOD-3 block of length three has `Ψ ≥ 4`. -/
theorem psi_three_block {n : Nat} (S : Finset (Fin n)) (t : Fin 3) (c : Bool) (hS : S.card = 3)
    (C : OpenCircuit n) (hc : ∀ v, C.eval v = modularBlock S t c v) : 4 ≤ C.psi := by
  have hT : (ModularTree.leaf S t c : ModularTree n).Valid 3 := by
    show 3 ≤ S.card
    omega
  have hTe : ∀ v, C.eval v = (ModularTree.leaf S t c : ModularTree n).eval v := hc
  obtain ⟨D, hD, hDpsi⟩ := exists_psiMinimal C
  have hfun : C.eval = (ModularTree.leaf S t c : ModularTree n).eval := funext hTe
  rw [hfun] at hD
  have hnc := (ModularTree.leaf S t c : ModularTree n).nonconstant (hT.mono (by omega))
  have hr := hD.reduced
  have hsafe := hD.dGateSafe hnc ((ModularTree.leaf S t c : ModularTree n).e1 hT)
  have hDfun : D.eval = (ModularTree.leaf S t c : ModularTree n).eval := funext hD.1
  obtain ⟨x, y, z, hxy, hxz, hyz, hset⟩ := Finset.card_eq_three.mp hS
  have hess (w : Fin n) (hw : w ∈ S) : Essential D.eval w := by
    rw [hDfun]
    exact (ModularTree.leaf S t c : ModularTree n).essential (hT.mono (by omega)) w hw
  have hsize := D.two_le_size_of_essential3 x y z hxy hxz hyz
    (hess x (by rw [hset]; simp)) (hess y (by rw [hset]; simp)) (hess z (by rw [hset]; simp))
  have hd := D.dCount_le_nonlinearCount hsafe
  have hsz := D.size_eq_counts (D.reduced_essential hr)
  have hpw := D.psiWeight_eq
  have hpsi : D.psi = (D.psiWeight : Int) - D.dCount := rfl
  omega

/-- Retirement of a three-input block (manuscript Lemma 4.7): fixing its three inputs to a
neutral assignment leaves the retired composition and lowers `Ψ` by at least `6`. -/
theorem psi_retire {n : Nat} (K : ModularContext n) (S : Finset (Fin n)) (hf : K.Fits 4 S)
    (R : ModularTree n) (hr : K.retire = some R) (t : Fin 3) (c : Bool) (hS : S.card = 3)
    (C : OpenCircuit n) (hc : ∀ v, C.eval v = (K.plug (.leaf S t c)).eval v) :
    ∃ D : OpenCircuit n, (∀ v, D.eval v = R.eval v) ∧ D.psi + 6 ≤ C.psi := by
  have hf3 : K.Fits 3 S := hf.mono (by omega)
  have hT3 : (K.plug (.leaf S t c)).Valid 3 :=
    K.plug_valid S hf3 (.leaf S t c) (by show 3 ≤ S.card; omega) (Finset.Subset.refl S)
  have hRv : R.Valid 4 := K.retire_valid S hf R hr
  obtain ⟨D, hD, hDpsi⟩ := exists_psiMinimal C
  have hfun : C.eval = (K.plug (.leaf S t c)).eval := funext hc
  rw [hfun] at hD
  have hnc := (K.plug (.leaf S t c)).nonconstant (hT3.mono (by omega))
  have hred := hD.reduced
  have hsafe := hD.dGateSafe hnc ((K.plug (.leaf S t c)).e1 hT3)
  obtain ⟨u, hu⟩ := (modularBlock_nonconstant S t c (by omega)).has_value K.neutral
  let P : Fin n → Bool := fun w => decide (w ∈ S)
  have hdis : Disjoint S K.support := K.fits_disjoint S hf
  have hRsupp : R.support = K.support := (K.retire_stats R hr).1
  have heval : ∀ v, (D.restrict (fixSubst P u)).eval v = R.eval v := by
    intro v
    rw [restrict_eval, hD.1]
    let w : Fin n → Bool := fun i => (fixSubst P u i).eval v
    have hw_S : ∀ i ∈ S, w i = u i := by
      intro i hi
      simp [w, fixSubst, P, hi, Signal.eval]
    have hw_out : ∀ i, i ∉ S → w i = v i := by
      intro i hi
      simp [w, fixSubst, P, hi, Signal.eval]
    have hblock : (ModularTree.leaf S t c : ModularTree n).eval w = K.neutral := by
      rw [← hu]
      exact modularBlock_supported S t c w u hw_S
    show (K.plug (.leaf S t c)).eval w = R.eval v
    rw [K.retire_eval R (.leaf S t c) hr w hblock]
    apply R.supported
    intro i hi
    rw [hRsupp] at hi
    exact hw_out i (fun hS' => Finset.disjoint_left.mp hdis hS' hi)
  have hmarks : MarksConstants P (fixSubst P u) := by
    intro i hi
    exact ⟨u i, by simp [fixSubst, hi]⟩
  have hnonR : Nonconstant (D.restrict (fixSubst P u)).eval := by
    obtain ⟨a, b, hab⟩ := R.nonconstant (hRv.mono (by omega))
    exact ⟨a, b, by rwa [heval, heval]⟩
  have hclose := D.closureOutput_false P (fixSubst P u) hmarks hnonR
  have hdel := D.constant_closure_deletion P (fixSubst P u) hmarks (D.reduced_live hred) hclose
  have hDfun : D.eval = (K.plug (.leaf S t c)).eval := funext hD.1
  have hused : ∀ i ∈ S, 1 ≤ D.usage (singleUse i) := by
    intro i hi
    apply D.essential_has_use i
    rw [hDfun]
    apply (K.plug (.leaf S t c)).essential (hT3.mono (by omega)) i
    rw [ModularContext.plug_support]
    exact Finset.mem_union_left _ hi
  have hmu : 3 ≤ D.markedUses P := by
    rw [D.markedUses_eq_sum P]
    have hsum : (∑ i : Fin n, if P i = true then D.usage (singleUse i) else 0) =
        ∑ i ∈ S, D.usage (singleUse i) := by
      rw [← Finset.sum_filter]
      congr 1
      ext i
      simp [P]
    rw [hsum]
    calc 3 = ∑ _i ∈ S, 1 := by rw [Finset.sum_const, smul_eq_mul, mul_one, hS]
      _ ≤ ∑ i ∈ S, D.usage (singleUse i) := Finset.sum_le_sum hused
  have hcharge := D.psi_restrict_essential (D.reduced_essential hred) hsafe P u
  refine ⟨D.restrict (fixSubst P u), heval, ?_⟩
  omega

end SatLowerBound
