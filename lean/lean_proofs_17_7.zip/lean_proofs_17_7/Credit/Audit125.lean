import Credit.Main
import Lean

/-!
# Credit.Audit125: axiom audit of the 12/5 certificate

Run with `lake env lean Credit/Audit125.lean` after `lake build Credit`.

* checks that `main_lower_bound_125` has exactly the type `ExactCertificate125`;
* prints the statement and the axioms of `main_lower_bound_125`;
* fails (with an error) if the axioms are anything other than a subset of
  `propext`, `Classical.choice`, `Quot.sound` (in particular, if `sorryAx` appears).

This file is deliberately not imported by `Credit.lean`, so `lake build Credit` does not print
its messages; it is a standalone audit script.
-/

open SatLowerBound

/-- Type check: the theorem proves exactly the certificate. -/
example : ExactCertificate125 := main_lower_bound_125

#print ExactCertificate125

#print axioms main_lower_bound_125

open Lean Elab Command in
run_cmd do
  let allowed : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let axioms ← collectAxioms ``SatLowerBound.main_lower_bound_125
  for ax in axioms do
    unless allowed.contains ax do
      throwError "forbidden axiom in main_lower_bound_125: {ax}"
  logInfo m!"AXIOM AUDIT PASSED: main_lower_bound_125 uses only {axioms.toList}"

/-- Independent restatement of the paper's complete parameter range. -/
example : ∀ (w r : Nat), 4 ≤ r → r < w →
    ∀ C : Circuit (inputBits w), C.Computes (satFunction w) →
      5 * inputBits w + (21 * r - 72) * remainingClauses w r ≤ 5 * C.size + 5 :=
  main_lower_bound_125_full_range

#print axioms main_lower_bound_125_full_range

open Lean Elab Command in
run_cmd do
  let allowed : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let axs ← collectAxioms ``SatLowerBound.main_lower_bound_125_full_range
  for ax in axs do
    unless allowed.contains ax do
      throwError "forbidden axiom in main_lower_bound_125_full_range: {ax}"
  logInfo m!"AXIOM AUDIT PASSED: full-range 12/5 certificate uses only {axs.toList}"
