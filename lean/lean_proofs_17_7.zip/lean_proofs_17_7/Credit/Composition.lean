import Credit.Retirement
import Credit.MainA.Main

/-!
# Credit.Composition: the one-level composition theorem (manuscript Theorem 4.8)

For every read-once AND/OR composition `T` of MOD-3 blocks of length at least four and every
circuit `C` computing it, `Ψ(C) ≥ 10 L - 24 B - 3`.  Complete proof modulo the open packages.
-/

namespace SatLowerBound

namespace ModularContext

theorem Fits.subset {n k : Nat} {K : ModularContext n} {S S' : Finset (Fin n)}
    (h : K.Fits k S) (hs : S' ⊆ S) : K.Fits k S' := by
  induction K with
  | hole => trivial
  | left p K R ih =>
    exact ⟨ih h.1, h.2.1,
      Finset.disjoint_of_subset_left (Finset.union_subset_union hs (Finset.Subset.refl _)) h.2.2⟩
  | right p L K ih =>
    exact ⟨h.1, ih h.2.1,
      Finset.disjoint_of_subset_right (Finset.union_subset_union hs (Finset.Subset.refl _)) h.2.2⟩

end ModularContext

open OpenCircuit

/-- The induction statement of Theorem 4.8, for all circuits (no normalization needed). -/
def PsiTree {n : Nat} (T : ModularTree n) : Prop :=
  ∀ C : OpenCircuit n, (∀ v, C.eval v = T.eval v) →
    10 * (T.inputs : Int) - 24 * (T.blocks : Int) - 3 ≤ C.psi

theorem psi_modular_composition {n : Nat} (T : ModularTree n) (hT : T.Valid 4) : PsiTree T := by
  suffices main : ∀ l, ∀ U : ModularTree n, U.inputs = l → U.Valid 4 → PsiTree U from
    main T.inputs T rfl hT
  intro l
  induction l using Nat.strong_induction_on with
  | h l ih =>
    intro U hU hvalid C hc
    obtain ⟨D, hD, hDpsi⟩ := exists_psiMinimal C
    have hfun : C.eval = U.eval := funext hc
    rw [hfun] at hD
    obtain ⟨x, b, hx, hdrop⟩ := (hD.context (U.goodFn hvalid)).main_lemma_A
    have hxs : x ∈ U.support := U.supported.essential_mem x hx
    obtain ⟨K, S, t, c, hplug, hxS⟩ := U.locate x hxs
    subst hplug
    obtain ⟨hSmin, hK⟩ := K.fits_of_plug (.leaf S t c) hvalid
    change 4 ≤ S.card at hSmin
    have hK3 : K.Fits 3 S := hK.mono (by omega)
    have hcomp : ∀ v, D.eval v = (K.plug (.leaf S t c)).eval v := hD.1
    have hres := K.restrict_leaf_computes S hK3 t c x hxS D hcomp b
    have hcard := Finset.card_erase_of_mem hxS
    unfold DropsAt at hdrop
    have hgoal : (K.plug (.leaf S t c)).inputs = S.card + K.inputs := by
      simp only [ModularContext.plug_inputs, ModularTree.inputs]
    have hblocks : (K.plug (.leaf S t c)).blocks = 1 + K.blocks := by
      simp only [ModularContext.plug_blocks, ModularTree.blocks]
    rw [hgoal, hblocks]
    by_cases hS5 : 5 ≤ S.card
    · have hvalid' : (K.plug (.leaf (S.erase x) (lowerResidue t b) c)).Valid 4 := by
        apply K.plug_valid S hK
        · show 4 ≤ (S.erase x).card
          omega
        · exact Finset.erase_subset x S
      have hlt : (K.plug (.leaf (S.erase x) (lowerResidue t b) c)).inputs < l := by
        rw [← hU, K.plug_inputs, K.plug_inputs]
        show (S.erase x).card + K.inputs < S.card + K.inputs
        omega
      have hnext := ih _ hlt (K.plug (.leaf (S.erase x) (lowerResidue t b) c)) rfl hvalid'
        (D.restrict (singleSubst x b)) hres
      rw [K.plug_inputs, K.plug_blocks] at hnext
      change 10 * (((S.erase x).card + K.inputs : Nat) : Int) - 24 * ((1 + K.blocks : Nat) : Int)
        - 3 ≤ (D.restrict (singleSubst x b)).psi at hnext
      omega
    · have hS4 : S.card = 4 := by omega
      cases hr : K.retire with
      | none =>
        have hk := K.retire_none.mp hr
        subst hk
        have hres' : ∀ v, (D.restrict (singleSubst x b)).eval v =
            modularBlock (S.erase x) (lowerResidue t b) c v := hres
        have hbase := psi_three_block (S.erase x) (lowerResidue t b) c (by omega)
          (D.restrict (singleSubst x b)) hres'
        simp only [ModularContext.inputs, ModularContext.blocks]
        omega
      | some R =>
        obtain ⟨E, hE, hEpsi⟩ := psi_retire K (S.erase x) (hK.subset (Finset.erase_subset x S))
          R hr (lowerResidue t b) c (by omega) (D.restrict (singleSubst x b)) hres
        have hRvalid := K.retire_valid S hK R hr
        obtain ⟨_, hRi, hRb, _⟩ := K.retire_stats R hr
        have hlt : R.inputs < l := by
          rw [hRi, ← hU, hgoal]
          omega
        have hbound := ih R.inputs hlt R rfl hRvalid E hE
        rw [hRi, hRb] at hbound
        omega

end SatLowerBound
