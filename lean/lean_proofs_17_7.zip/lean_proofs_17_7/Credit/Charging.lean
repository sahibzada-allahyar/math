import Credit.FlatKept
import Credit.Transfer



namespace SatLowerBound
namespace OpenCircuit

/-! ### Auxiliary facts -/

private theorem psiW_of_nonlinear (g : Table) (h : g.nonlinear = true) : g.psiW = 3 := by
  revert h
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

/-- Both operand slots of a gate are counted by `refCount`. -/
private theorem slots_le_refCount {n : Nat} (C : OpenCircuit n) {k : Nat} {g : Table}
    {a b : Nat} (h : C.gateAt k = some (g, a, b)) (s : Nat) :
    (if a = s then 1 else 0) + (if b = s then 1 else 0) ≤ C.refCount s := by
  induction C with
  | output s' => simp [gateAt] at h
  | @gate n g' i j rest ih =>
    simp only [gateAt] at h
    simp only [refCount]
    split at h
    · simp only [Option.some.injEq, Prod.mk.injEq] at h
      obtain ⟨-, ha, hb⟩ := h
      rw [← ha, ← hb]
      omega
    · have := ih h
      omega

/-- The unique reader of a D-variable. -/
private theorem isD_reader {n : Nat} (C : OpenCircuit n) {s : Nat} (hD : C.isD s = true) :
    ∃ W g a b, C.gateAt W = some (g, a, b) ∧ (a = s ∨ b = s) ∧ g.nonlinear = true ∧
      C.users s = {W} ∧ C.outIs s = 0 ∧ C.refCount s = 1 := by
  obtain ⟨hr, W, g, a, b, hW, hab, hnl⟩ := (C.isD_iff s).mp hD
  have hmem : W ∈ C.users s := C.mem_users.mpr ⟨g, a, b, hW, hab⟩
  have hge := C.refCount_ge s
  have hpos : 0 < (C.users s).card := Finset.card_pos.mpr ⟨W, hmem⟩
  have hcard : (C.users s).card = 1 := by omega
  obtain ⟨W', hW'⟩ := Finset.card_eq_one.mp hcard
  have hWW : W = W' := by
    rw [hW'] at hmem
    exact Finset.mem_singleton.mp hmem
  refine ⟨W, g, a, b, hW, hab, hnl, ?_, by omega, hr⟩
  rw [hW', hWW]

/-- Every gate reading a D-variable is nonlinear (it is its unique reader). -/
private theorem reader_nonlinear {n : Nat} (C : OpenCircuit n) {s k : Nat} {g : Table}
    {a b : Nat} (hD : C.isD s = true) (hk : C.gateAt k = some (g, a, b)) (hab : a = s ∨ b = s) :
    g.nonlinear = true := by
  obtain ⟨W, g', a', b', hW, -, hnl, husers, -, -⟩ := isD_reader C hD
  have hmem : k ∈ C.users s := C.mem_users.mpr ⟨g, a, b, hk, hab⟩
  rw [husers, Finset.mem_singleton] at hmem
  rw [hmem, hW] at hk
  simp only [Option.some.injEq, Prod.mk.injEq] at hk
  rw [← hk.1]
  exact hnl

/-- A D-gate is nonlinear, so its weight is `3`. -/
private theorem gatePsiW_of_isDGate {n : Nat} (C : OpenCircuit n) {k : Nat}
    (h : C.isDGate k = true) : C.gatePsiW k = 3 := by
  obtain ⟨g, a, b, hg, hab⟩ := (C.isDGate_iff k).mp h
  have hnl : g.nonlinear = true := by
    rcases hab with ⟨-, hD⟩ | ⟨-, hD⟩
    · exact reader_nonlinear C hD hg (Or.inl rfl)
    · exact reader_nonlinear C hD hg (Or.inr rfl)
  simp only [gatePsiW, hg]
  exact psiW_of_nonlinear g hnl

/-- D-preservation: a free D-variable whose D-gate survives stays a D-variable. -/
theorem keptIsD_of_isD {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool) (z : Fin n)
    (hz : P z = false) (hD : C.isD z.val = true)
    (hW : ∀ k ∈ C.users z.val, C.isKept (fixRes P c) k = true) :
    C.keptIsD (fixRes P c) z.val = true := by
  obtain ⟨W, g, a, b, hgW, hab, hnl, husers, hout, hr⟩ := isD_reader C hD
  -- no gate passes `z`: its only reader is kept
  have hpass : ∀ k, n ≤ k → k < n + C.size →
      (C.resAt (fixRes P c) k).hits z.val = true → k ∈ (∅ : Finset Nat) := by
    apply C.passers_subset (fixRes P c) z.val z.isLt (fixRes_hits P c z.val) ∅ (n + C.size)
    intro k g' a' b' _ hk _ hread
    have hkz : k ∈ C.users z.val := by
      rcases hread with h | h | h | h
      · exact C.mem_users.mpr ⟨g', a', b', hk, Or.inl h⟩
      · simp at h
      · exact C.mem_users.mpr ⟨g', a', b', hk, Or.inr h⟩
      · simp at h
    rw [C.resAt_kept _ (hW k hkz), Bool.eq_false_iff]
    intro h
    rw [Res.hits_lit] at h
    have := (C.gateAt_bounds hk).1
    have := z.isLt
    omega
  -- every other signal does not resolve to `z`
  have hother : ∀ o, o < n + C.size → o ≠ z.val →
      (C.resAt (fixRes P c) o).hits z.val = false := by
    intro o ho hne
    rw [Bool.eq_false_iff]
    intro h
    by_cases hon : o < n
    · have hin : C.resAt (fixRes P c) o = fixRes P c ⟨o, hon⟩ :=
        C.resAt_input (fixRes P c) ⟨o, hon⟩
      rw [hin] at h
      exact hne (fixRes_hits P c z.val ⟨o, hon⟩ h)
    · have := hpass o (by omega) ho h
      simp at this
  have hzres : C.resAt (fixRes P c) z.val = .lit z.val false := by
    rw [C.resAt_input]
    simp [fixRes, hz]
  have hzhit : (C.resAt (fixRes P c) z.val).hits z.val = true := by
    rw [hzres]
    exact (Res.hits_lit _ _ _).mpr rfl
  have hWk : W ∈ C.users z.val := by
    rw [husers]
    exact Finset.mem_singleton_self W
  have hbW := C.gateAt_bounds hgW
  have hslots := slots_le_refCount C hgW z.val
  rw [hr] at hslots
  apply C.keptIsD_of_unique_slot (fixRes P c) z.val W g a b hgW (hW W hWk) hnl
  · rcases hab with ha | hb
    · have hb : b ≠ z.val := by
        intro hb
        split_ifs at hslots
        omega
      rw [ha, hzhit, hother b (by omega) hb]
      rfl
    · have ha : a ≠ z.val := by
        intro ha
        split_ifs at hslots
        omega
      rw [hb, hzhit, hother a (by omega) ha]
      rfl
  · intro k g' a' b' hkW hk _
    have ha' : a' ≠ z.val := by
      intro h
      have hk' : k ∈ C.users z.val := C.mem_users.mpr ⟨g', a', b', hk, Or.inl h⟩
      rw [husers, Finset.mem_singleton] at hk'
      exact hkW hk'
    have hb' : b' ≠ z.val := by
      intro h
      have hk' : k ∈ C.users z.val := C.mem_users.mpr ⟨g', a', b', hk, Or.inr h⟩
      rw [husers, Finset.mem_singleton] at hk'
      exact hkW hk'
    have hbk := C.gateAt_bounds hk
    exact ⟨hother a' (by omega) ha', hother b' (by omega) hb'⟩
  · intro k neg hk
    have hkz : k ≠ z.val := by
      intro h
      have h' : C.outIs z.val = 1 := by
        unfold outIs
        rw [hk]
        simp [h]
      omega
    exact hother k (C.outWire_bound hk) hkz

/-- No signal resolves to a literal of a fixed input. -/
private theorem fixed_not_hit {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool) (z : Fin n)
    (hz : P z = true) (k : Nat) : (C.resAt (fixRes P c) k).hits z.val = false := by
  induction k using Nat.strong_induction_on with
  | _ k ih =>
    rw [Bool.eq_false_iff]
    intro h
    rcases C.resAt_hits_cases (fixRes P c) h with ⟨w, -, hwz⟩ | ⟨g, a, b, hg, hcase⟩
    · have hw : w = z := Fin.ext (fixRes_hits P c z.val w hwz)
      rw [hw] at hwz
      simp [fixRes, hz, Res.hits] at hwz
    · have hb := C.gateAt_bounds hg
      rcases hcase with ⟨-, hk⟩ | ⟨-, ha | hb'⟩
      · have := z.isLt
        omega
      · rw [ih a hb.2.2.1] at ha
        exact Bool.false_ne_true ha
      · rw [ih b hb.2.2.2] at hb'
        exact Bool.false_ne_true hb'

/-- A fixed input is never a D-variable of the restricted circuit. -/
theorem keptIsD_of_fixed {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool) (z : Fin n)
    (hz : P z = true) : C.keptIsD (fixRes P c) z.val = false := by
  have hnh := fixed_not_hit C P c z hz
  have h0 : C.keptRefs (fixRes P c) z.val = 0 := by
    rw [C.keptRefs_eq_sum]
    have hs : ∀ k ∈ Finset.range (n + C.size), C.keptSlotHits (fixRes P c) k z.val = 0 := by
      intro k _
      unfold keptSlotHits
      split
      · simp [hnh, indicator]
      · rfl
    have ho : C.outHits (fixRes P c) z.val = 0 := by
      unfold outHits
      split
      · simp [hnh, indicator]
      · rfl
    rw [Finset.sum_eq_zero hs, ho]
  unfold keptIsD
  rw [h0]
  rfl

/-! ### Counting lost D-variables -/

/-- A D-variable that is lost has an eliminated reader. -/
private theorem lost_reader {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool) (z : Fin n)
    (hD : C.isD z.val = true) (hk : C.keptIsD (fixRes P c) z.val = false) :
    ∃ k, k ∈ C.users z.val ∧ C.isAliased (fixRes P c) k = true := by
  cases hP : P z with
  | true =>
    obtain ⟨W, g, a, b, hW, hab, -, -, -, -⟩ := isD_reader C hD
    refine ⟨W, C.mem_users.mpr ⟨g, a, b, hW, hab⟩, ?_⟩
    have hz : (C.resAt (fixRes P c) z.val).isConst = true := by
      rw [C.resAt_input]
      simp [fixRes, hP, Res.isConst]
    apply C.isAliased_of_const _ hW
    rcases hab with h | h
    · rw [h]
      exact Or.inl hz
    · rw [h]
      exact Or.inr hz
  | false =>
    by_contra hcon
    have hall : ∀ k ∈ C.users z.val, C.isKept (fixRes P c) k = true := by
      intro k hku
      obtain ⟨g, a, b, hg, -⟩ := C.mem_users.mp hku
      rw [C.isKept_eq_not_isAliased _ hg]
      cases hal : C.isAliased (fixRes P c) k with
      | false => rfl
      | true => exact absurd ⟨k, hku, hal⟩ hcon
    have := C.keptIsD_of_isD P c z hP hD hall
    rw [hk] at this
    exact Bool.false_ne_true this

/-- A lost D-variable has a reader among the eliminated D-gates. -/
private theorem lost_reader_mem {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool) (z : Fin n)
    (hz : z ∈ Finset.univ.filter
        (fun z : Fin n => (C.isD z.val && !C.keptIsD (fixRes P c) z.val) = true)) :
    ∃ k, k ∈ ((Finset.range (n + C.size)).filter
        (fun k => C.isAliased (fixRes P c) k = true)).filter (fun k => C.isDGate k = true) ∧
      k ∈ C.users z.val := by
  simp only [Finset.mem_filter, Finset.mem_univ, true_and, Bool.and_eq_true,
    Bool.not_eq_true'] at hz
  obtain ⟨hD, hk⟩ := hz
  obtain ⟨k, hku, hal⟩ := lost_reader C P c z hD hk
  obtain ⟨g, a, b, hg, hab⟩ := C.mem_users.mp hku
  refine ⟨k, ?_, hku⟩
  rw [Finset.mem_filter, Finset.mem_filter, Finset.mem_range]
  refine ⟨⟨(C.gateAt_bounds hg).2.1, hal⟩, ?_⟩
  rw [C.isDGate_iff]
  refine ⟨g, a, b, hg, ?_⟩
  rcases hab with h | h
  · rw [h]
    exact Or.inl ⟨z.isLt, hD⟩
  · rw [h]
    exact Or.inr ⟨z.isLt, hD⟩

/-- Under `DGateSafe` a gate reads at most one D-variable. -/
private theorem dvar_reader_unique {n : Nat} (C : OpenCircuit n) (hsafe : C.DGateSafe) {k : Nat}
    {z₁ z₂ : Fin n} (h₁ : C.isD z₁.val = true) (h₂ : C.isD z₂.val = true)
    (hk₁ : k ∈ C.users z₁.val) (hk₂ : k ∈ C.users z₂.val) : z₁ = z₂ := by
  obtain ⟨g, a, b, hg, hab₁⟩ := C.mem_users.mp hk₁
  obtain ⟨g', a', b', hg', hab₂⟩ := C.mem_users.mp hk₂
  rw [hg] at hg'
  simp only [Option.some.injEq, Prod.mk.injEq] at hg'
  obtain ⟨-, ha, hb⟩ := hg'
  rw [← ha, ← hb] at hab₂
  apply Fin.ext
  have hz₁ := z₁.isLt
  have hz₂ := z₂.isLt
  rcases hab₁ with ha₁ | hb₁ <;> rcases hab₂ with ha₂ | hb₂
  · omega
  · have := (hsafe k g a b hg (by omega) (by omega)).1
    rw [ha₁, h₁] at this
    exact Bool.noConfusion this
  · have := (hsafe k g a b hg (by omega) (by omega)).1
    rw [ha₂, h₂] at this
    exact Bool.noConfusion this
  · omega

/-! ### Two counting principles

Local replacements for `Finset.card_le_card_of_forall_subsingleton` and
`Finset.card_mul_le_card_mul` (from `Mathlib.Combinatorics.Enumerative.DoubleCounting`), so that
`Credit` imports no Mathlib module directly. -/

/-- Every element of `s` is related to some element of `t`, and every element of `t` to at most
one element of `s`: then `#s ≤ #t`. -/
private theorem card_le_card_of_unique_rel {α β : Type} [Nonempty β] (s : Finset α)
    (t : Finset β) (r : α → β → Prop) (hs : ∀ a ∈ s, ∃ b, b ∈ t ∧ r a b)
    (ht : ∀ b ∈ t, ∀ a₁ ∈ s, ∀ a₂ ∈ s, r a₁ b → r a₂ b → a₁ = a₂) : s.card ≤ t.card := by
  choose! f hft hfr using hs
  apply Finset.card_le_card_of_injOn f
  · intro a ha
    exact hft a ha
  · intro a₁ ha₁ a₂ ha₂ he
    have h₂ : r a₂ (f a₁) := by
      rw [he]
      exact hfr a₂ ha₂
    exact ht (f a₁) (hft a₁ ha₁) a₁ ha₁ a₂ ha₂ (hfr a₁ ha₁) h₂

/-- Every element of `s` is related to some element of `t`, and every element of `t` to at most
two elements of `s`: then `#s ≤ 2 · #t`. -/
private theorem card_le_two_mul_of_rel {α β : Type} [DecidableEq β] [Nonempty β] (s : Finset α)
    (t : Finset β) (r : α → β → Prop) (hs : ∀ a ∈ s, ∃ b, b ∈ t ∧ r a b)
    (ht : ∀ b ∈ t, ∀ u : Finset α, (∀ a ∈ u, r a b) → u.card ≤ 2) :
    s.card ≤ 2 * t.card := by
  choose! f hft hfr using hs
  apply Finset.card_le_mul_card_image_of_maps_to hft 2
  intro b hb
  apply ht b hb
  intro a ha
  obtain ⟨ha₁, ha₂⟩ := Finset.mem_filter.mp ha
  rw [← ha₂]
  exact hfr a ha₁

/-- In general a gate reads at most two lost D-variables. -/
private theorem lost_card_le_two {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool) :
    (Finset.univ.filter
        (fun z : Fin n => (C.isD z.val && !C.keptIsD (fixRes P c) z.val) = true)).card * 1 ≤
      (((Finset.range (n + C.size)).filter (fun k => C.isAliased (fixRes P c) k = true)).filter
        (fun k => C.isDGate k = true)).card * 2 := by
  rw [Nat.mul_one, Nat.mul_comm _ 2]
  apply card_le_two_mul_of_rel _ _ (fun (z : Fin n) (k : Nat) => k ∈ C.users z.val)
  · intro z hz
    exact lost_reader_mem C P c z hz
  · intro k hk u hu
    obtain ⟨g, a, b, hg, -⟩ := (C.isDGate_iff k).mp (Finset.mem_filter.mp hk).2
    calc u.card ≤ ({a, b} : Finset Nat).card := by
          apply Finset.card_le_card_of_injOn (fun z : Fin n => z.val)
          · intro z hz
            obtain ⟨g', a', b', hg', hab⟩ := C.mem_users.mp (hu z hz)
            rw [hg] at hg'
            simp only [Option.some.injEq, Prod.mk.injEq] at hg'
            obtain ⟨-, ha, hb⟩ := hg'
            rw [Finset.mem_coe, Finset.mem_insert, Finset.mem_singleton]
            rcases hab with h | h
            · exact Or.inl (by rw [ha, h])
            · exact Or.inr (by rw [hb, h])
          · intro z₁ _ z₂ _ h
            exact Fin.ext h
      _ ≤ 2 := Finset.card_le_two

/-- Under `DGateSafe` the lost D-variables inject into the eliminated D-gates. -/
private theorem lost_card_le_safe {n : Nat} (C : OpenCircuit n) (hsafe : C.DGateSafe)
    (P c : Fin n → Bool) :
    (Finset.univ.filter
        (fun z : Fin n => (C.isD z.val && !C.keptIsD (fixRes P c) z.val) = true)).card ≤
      (((Finset.range (n + C.size)).filter (fun k => C.isAliased (fixRes P c) k = true)).filter
        (fun k => C.isDGate k = true)).card := by
  apply card_le_card_of_unique_rel _ _ (fun (z : Fin n) (k : Nat) => k ∈ C.users z.val)
  · intro z hz
    exact lost_reader_mem C P c z hz
  · intro k _ z₁ hz₁ z₂ hz₂ hk₁ hk₂
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Bool.and_eq_true] at hz₁ hz₂
    exact dvar_reader_unique C hsafe hz₁.1 hz₂.1 hk₁ hk₂

/-- Eliminated D-gates weigh `3` each. -/
private theorem card_dGates_mul_three_le {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) :
    3 * (((Finset.range (n + C.size)).filter (fun k => C.isAliased ρ k = true)).filter
        (fun k => C.isDGate k = true)).card ≤ C.aliasedPsiWeight ρ := by
  rw [C.aliasedPsiWeight_eq_sum, ← Finset.sum_filter, Finset.card_eq_sum_ones, Finset.mul_sum,
    mul_one]
  calc ∑ k ∈ ((Finset.range (n + C.size)).filter (fun k => C.isAliased ρ k = true)).filter
          (fun k => C.isDGate k = true), 3
        = ∑ k ∈ ((Finset.range (n + C.size)).filter (fun k => C.isAliased ρ k = true)).filter
          (fun k => C.isDGate k = true), C.gatePsiW k := by
          apply Finset.sum_congr rfl
          intro k hk
          rw [gatePsiW_of_isDGate C (Finset.mem_filter.mp hk).2]
    _ ≤ ∑ k ∈ (Finset.range (n + C.size)).filter (fun k => C.isAliased ρ k = true),
          C.gatePsiW k :=
        Finset.sum_le_sum_of_subset (Finset.filter_subset _ _)

/-- Per-input bookkeeping: `|D(C)| + gained = |D(C')| + lost`. -/
private theorem dcount_identity {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) :
    (∑ z : Fin n, indicator (C.isD z.val)) +
        (∑ z : Fin n, indicator (C.keptIsD ρ z.val && !C.isD z.val)) =
      (∑ z : Fin n, indicator (C.keptIsD ρ z.val)) +
        (Finset.univ.filter
          (fun z : Fin n => (C.isD z.val && !C.keptIsD ρ z.val) = true)).card := by
  rw [Finset.card_filter, ← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro z _
  cases C.isD z.val <;> cases C.keptIsD ρ z.val <;> rfl

private theorem gained_eq {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool) :
    gainedCount C (C.restrict (fixSubst P c)) =
      ∑ z : Fin n, indicator (C.keptIsD (fixRes P c) z.val && !C.isD z.val) := by
  unfold gainedCount
  apply Finset.sum_congr rfl
  intro z _
  rw [(C.fix_transfer P c).2.2.2 z]

/-- Restriction never increases `Ψ` (no hypothesis on the circuit). -/
theorem psi_restrict_le {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool) :
    (C.restrict (fixSubst P c)).psi ≤ C.psi := by
  have hsplit := C.psiWeight_split (fixRes P c)
  have hid := dcount_identity C (fixRes P c)
  have hlost := lost_card_le_two C P c
  have hthree := card_dGates_mul_three_le C (fixRes P c)
  rw [C.psi_restrict_fix P c]
  unfold psi dCount
  omega

/-- The charging lemma: for any set `E` of eliminated gates,
`Ψ(C') + Σ_E psiW + gained ≤ Ψ(C) + #(D-gates in E)`. -/
theorem psi_restrict_charge {n : Nat} (C : OpenCircuit n) (hsafe : C.DGateSafe)
    (P c : Fin n → Bool) (E : Finset Nat)
    (hE : ∀ k ∈ E, C.isAliased (fixRes P c) k = true) :
    (C.restrict (fixSubst P c)).psi + ((∑ k ∈ E, C.gatePsiW k : Nat) : Int) +
        (gainedCount C (C.restrict (fixSubst P c)) : Int) ≤
      C.psi + ((E.filter (fun k => C.isDGate k = true)).card : Int) := by
  have hsplit := C.psiWeight_split (fixRes P c)
  have hid := dcount_identity C (fixRes P c)
  have hgain := gained_eq C P c
  have hlost := lost_card_le_safe C hsafe P c
  have hEA : E ⊆ (Finset.range (n + C.size)).filter
      (fun k => C.isAliased (fixRes P c) k = true) := by
    intro k hk
    have hal := hE k hk
    rw [Finset.mem_filter, Finset.mem_range]
    refine ⟨?_, hal⟩
    cases hg : C.gateAt k with
    | none => simp [isAliased, hg] at hal
    | some p =>
      obtain ⟨g, a, b⟩ := p
      exact (C.gateAt_bounds hg).2.1
  have hA1 : (((Finset.range (n + C.size)).filter
        (fun k => C.isAliased (fixRes P c) k = true)).filter (fun k => C.isDGate k = true)).card =
      (∑ k ∈ (Finset.range (n + C.size)).filter
        (fun k => C.isAliased (fixRes P c) k = true) \ E, indicator (C.isDGate k)) +
        (E.filter (fun k => C.isDGate k = true)).card := by
    rw [Finset.card_filter, Finset.card_filter, ← Finset.sum_sdiff hEA]
    rfl
  have hA2 : (∑ k ∈ (Finset.range (n + C.size)).filter
        (fun k => C.isAliased (fixRes P c) k = true) \ E, indicator (C.isDGate k)) ≤
      ∑ k ∈ (Finset.range (n + C.size)).filter
        (fun k => C.isAliased (fixRes P c) k = true) \ E, C.gatePsiW k := by
    apply Finset.sum_le_sum
    intro k _
    cases h : C.isDGate k with
    | false => exact Nat.zero_le _
    | true =>
      rw [gatePsiW_of_isDGate C h]
      decide
  have hA3 : C.aliasedPsiWeight (fixRes P c) =
      (∑ k ∈ (Finset.range (n + C.size)).filter
        (fun k => C.isAliased (fixRes P c) k = true) \ E, C.gatePsiW k) +
        ∑ k ∈ E, C.gatePsiW k := by
    rw [Finset.sum_sdiff hEA, C.aliasedPsiWeight_eq_sum, ← Finset.sum_filter]
  rw [C.psi_restrict_fix P c, hgain]
  unfold psi dCount
  omega

/-- Under `DGateSafe`, distinct D-variables have distinct (nonlinear) D-gates. -/
theorem dCount_le_nonlinearCount {n : Nat} (C : OpenCircuit n) (hsafe : C.DGateSafe) :
    C.dCount ≤ C.nonlinearCount := by
  have h1 : C.dCount = (Finset.univ.filter (fun z : Fin n => C.isD z.val = true)).card := by
    rw [Finset.card_filter]
    rfl
  have h2 : C.nonlinearCount = ((Finset.range (n + C.size)).filter
      (fun k => (C.tableAt k).nonlinear = true)).card := by
    rw [Finset.card_filter, C.nonlinearCount_eq_sum]
    rfl
  rw [h1, h2]
  apply card_le_card_of_unique_rel _ _ (fun (z : Fin n) (k : Nat) => k ∈ C.users z.val)
  · intro z hz
    have hD := (Finset.mem_filter.mp hz).2
    obtain ⟨W, g, a, b, hW, hab, hnl, -, -, -⟩ := isD_reader C hD
    refine ⟨W, ?_, C.mem_users.mpr ⟨g, a, b, hW, hab⟩⟩
    rw [Finset.mem_filter, Finset.mem_range]
    refine ⟨(C.gateAt_bounds hW).2.1, ?_⟩
    simp only [tableAt, hW]
    exact hnl
  · intro k _ z₁ hz₁ z₂ hz₂ hk₁ hk₂
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hz₁ hz₂
    exact dvar_reader_unique C hsafe hz₁ hz₂ hk₁ hk₂

/-! ### Proved consequences -/

theorem one_le_gainedCount {n : Nat} (C D : OpenCircuit n) (z : Fin n)
    (h₁ : D.isD z.val = true) (h₂ : C.isD z.val = false) : 1 ≤ gainedCount C D := by
  unfold gainedCount
  have hz : indicator (D.isD z.val && !C.isD z.val) = 1 := by simp [h₁, h₂, indicator]
  calc 1 = indicator (D.isD z.val && !C.isD z.val) := hz.symm
    _ ≤ ∑ w : Fin n, indicator (D.isD w.val && !C.isD w.val) :=
        Finset.single_le_sum (f := fun w : Fin n => indicator (D.isD w.val && !C.isD w.val))
          (fun _ _ => Nat.zero_le _) (Finset.mem_univ z)

/-- Every eliminated gate of an essential-gate circuit is worth at least `2`:
`Ψ(C') + 2 (|C| - |C'|) ≤ Ψ(C)`. -/
theorem psi_restrict_essential {n : Nat} (C : OpenCircuit n) (he : C.EssentialGates)
    (hsafe : C.DGateSafe) (P c : Fin n → Bool) :
    (C.restrict (fixSubst P c)).psi +
        2 * ((C.size : Int) - ((C.restrict (fixSubst P c)).size : Int)) ≤ C.psi := by
  have hE : ∀ k ∈ (Finset.range (n + C.size)).filter
      (fun k => C.isAliased (fixRes P c) k = true), C.isAliased (fixRes P c) k = true :=
    fun k hk => (Finset.mem_filter.mp hk).2
  have hcharge := C.psi_restrict_charge hsafe P c _ hE
  have hcard : ((Finset.range (n + C.size)).filter
      (fun k => C.isAliased (fixRes P c) k = true)).card = C.aliasedCount (fixRes P c) := by
    rw [C.aliasedCount_eq_sum (fixRes P c), Finset.card_filter]
    rfl
  have hsize : (C.restrict (fixSubst P c)).size + C.aliasedCount (fixRes P c) = C.size := by
    rw [(C.fix_transfer P c).1, C.size_split (fixRes P c)]
  have hthree : 3 * ((Finset.range (n + C.size)).filter
      (fun k => C.isAliased (fixRes P c) k = true)).card ≤
      ∑ k ∈ (Finset.range (n + C.size)).filter (fun k => C.isAliased (fixRes P c) k = true),
        C.gatePsiW k := by
    rw [Finset.card_eq_sum_ones, Finset.mul_sum]
    apply Finset.sum_le_sum
    intro k hk
    have hal := hE k hk
    cases hg : C.gateAt k with
    | none => simp [isAliased, hg] at hal
    | some p =>
      obtain ⟨g, a, b⟩ := p
      have hess := C.essentialGates_gate he hg
      simp only [gatePsiW, hg, g.psiW_essential hess]
      omega
  have hfilter := Finset.card_filter_le ((Finset.range (n + C.size)).filter
      (fun k => C.isAliased (fixRes P c) k = true)) (fun k => C.isDGate k = true)
  have hgain := Nat.zero_le (gainedCount C (C.restrict (fixSubst P c)))
  omega

end OpenCircuit
end SatLowerBound
