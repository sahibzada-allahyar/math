import Credit.MainA.Toolkit



namespace SatLowerBound

namespace TightEqualAux

/-- `Res.step` of two resolutions hitting the same source is never `none`. -/
theorem step_isSome_of_hits (g : Table) (r₁ r₂ : Res) (s : Nat)
    (h₁ : r₁.hits s = true) (h₂ : r₂.hits s = true) : (Res.step g r₁ r₂).isSome = true := by
  cases r₁ with
  | const _ => simp [Res.hits] at h₁
  | lit i na =>
    cases r₂ with
    | const _ => simp [Res.hits] at h₂
    | lit j nb =>
      rw [Res.hits_lit] at h₁ h₂
      rw [h₁, h₂]
      exact Res.step_same_isSome g s na nb

/-- A kept gate has at most one operand slot hitting a given source (left slot hits). -/
theorem not_hits_right_of_kept (g : Table) (r₁ r₂ : Res) (s : Nat)
    (hk : (Res.step g r₁ r₂).isNone = true) (h₁ : r₁.hits s = true) : r₂.hits s = false := by
  rw [Bool.eq_false_iff]
  intro h₂
  have hs := step_isSome_of_hits g r₁ r₂ s h₁ h₂
  cases hst : Res.step g r₁ r₂ with
  | none =>
    rw [hst] at hs
    simp at hs
  | some _ =>
    rw [hst] at hk
    simp at hk

/-- A kept gate has at most one operand slot hitting a given source (right slot hits). -/
theorem not_hits_left_of_kept (g : Table) (r₁ r₂ : Res) (s : Nat)
    (hk : (Res.step g r₁ r₂).isNone = true) (h₂ : r₂.hits s = true) : r₁.hits s = false := by
  rw [Bool.eq_false_iff]
  intro h₁
  exact Bool.false_ne_true ((not_hits_right_of_kept g r₁ r₂ s hk h₁).symm.trans h₂)

/-- A constant resolution hits nothing. -/
theorem hits_false_of_isConst (r : Res) (s : Nat) (h : r.isConst = true) : r.hits s = false := by
  cases r with
  | const _ => rfl
  | lit _ _ => simp [Res.isConst] at h

end TightEqualAux

namespace MAContext

open OpenCircuit

theorem tight_equal {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (x y : Fin n) (hxy : x ≠ y) (U R S : Nat) (ε : Bool) (hUn : U ≠ n)
    (hux : C.users x.val = {n, U}) (huy : C.users y.val = {n, U})
    (hR : C.users n = {R}) (hS : C.users U = {S})
    (hUout : ∀ k neg, C.outWire = some (k, neg) → k ≠ U)
    (hTc : (C.resAt (singleRes x ε) n).isConst = true)
    (hUc : (C.resAt (singleRes x ε) U).isConst = false)
    (_hRc : (C.resAt (singleRes x ε) R).isConst = false)
    (hSnl : (C.tableAt S).nonlinear = true) :
    C.DropsAt x ε 10 := by
  have hxlt := x.isLt
  have hylt := y.isLt
  have hxy' : x.val ≠ y.val := fun he => hxy (Fin.ext he)
  have hnU : n ≠ U := Ne.symm hUn
  -- membership facts
  have hTx : n ∈ C.users x.val := by
    rw [hux]
    exact Finset.mem_insert_self n {U}
  have hUx : U ∈ C.users x.val := by
    rw [hux]
    exact Finset.mem_insert_of_mem (Finset.mem_singleton_self U)
  have hUy : U ∈ C.users y.val := by
    rw [huy]
    exact Finset.mem_insert_of_mem (Finset.mem_singleton_self U)
  have hRT : R ∈ C.users n := by
    rw [hR]
    exact Finset.mem_singleton_self R
  have hSU : S ∈ C.users U := by
    rw [hS]
    exact Finset.mem_singleton_self S
  have hyonly : ∀ k ∈ C.users y.val, k = n ∨ k = U := by
    intro k hk
    rw [huy, Finset.mem_insert, Finset.mem_singleton] at hk
    exact hk
  have hUonly : ∀ k ∈ C.users U, k = S := by
    intro k hk
    rw [hS] at hk
    exact Finset.mem_singleton.mp hk
  -- `x` and `y` are read exactly twice
  have hcx : C.refCount x.val = 2 := by
    rw [h.refCount_input x, hux, Finset.card_pair hnU]
  have hcy : C.refCount y.val = 2 := by
    rw [h.refCount_input y, huy, Finset.card_pair hnU]
  -- the gates `T = n`, `U`, `R`, `S`
  obtain ⟨gT, aT, bT, hgT, -⟩ := C.mem_users.mp hTx
  obtain ⟨gU, aU, bU, hgU, habUx⟩ := C.mem_users.mp hUx
  obtain ⟨gR, aR, bR, hgR, habR⟩ := C.mem_users.mp hRT
  obtain ⟨gS, aS, bS, hgS, habS⟩ := C.mem_users.mp hSU
  obtain ⟨-, -, haT, hbT⟩ := C.gateAt_bounds hgT
  obtain ⟨hnU', -, -, -⟩ := C.gateAt_bounds hgU
  obtain ⟨-, -, haR, hbR⟩ := C.gateAt_bounds hgR
  obtain ⟨-, -, haS, hbS⟩ := C.gateAt_bounds hgS
  -- `U` reads exactly `x` and `y`
  have hUxy : (aU = x.val ∧ bU = y.val) ∨ (aU = y.val ∧ bU = x.val) := by
    obtain ⟨g', a', b', hg', haby⟩ := C.mem_users.mp hUy
    rw [hgU] at hg'
    simp only [Option.some.injEq, Prod.mk.injEq] at hg'
    obtain ⟨-, ha', hb'⟩ := hg'
    rcases habUx with h1 | h1 <;> rcases haby with h2 | h2 <;> omega
  -- distinctness of `T, U, R, S`
  have hRn : n < R := by
    rcases habR with hab | hab <;> omega
  have hUS : U < S := by
    rcases habS with hab | hab <;> omega
  have hRU : R ≠ U := by
    intro he
    have hR' := h.no_triangle x.isLt hTx hRT
    rw [he] at hR'
    exact hR' hUx
  -- (S3): `S ≠ R`, since otherwise all dependence on `(x, y)` passes through `R`
  have hSR : S ≠ R := by
    intro he
    refine h.funnel_not_separated x y hxy n U R hnU (Nat.le_refl n) hnU' hux huy hR
      (by rw [hS, he]) ?_ (h.good.s3 x y hxy
        (h.usedEssential x (by rw [C.usage_singleUse]; omega))
        (h.usedEssential y (by rw [C.usage_singleUse]; omega)))
    intro k neg hw
    exact ⟨h.out_ne_of_const x ε hTc k neg hw, hUout k neg hw⟩
  -- no charges: F1 for `T, U` (readers of `x`), F2 for `R` (reader of `T`) and `S` (reader of
  -- `U`); both `T` and `U` read two primary inputs
  have hDT : C.isDGate n = false := h.not_dGate_of_multi x (by omega) hTx
  have hDU : C.isDGate U = false := h.not_dGate_of_multi x (by omega) hUx
  have hDR : C.isDGate R = false := h.not_dGate_of_primary_pred hgT haT hbT hRT
  have hDS : C.isDGate S = false :=
    h.not_dGate_of_primary_pred hgU (by omega) (by omega) hSU
  -- weights
  have h3T := (h.psiW_ge hgT).1
  have h3U := (h.psiW_ge hgU).1
  have h3R := (h.psiW_ge hgR).1
  have h3S := (h.psiW_ge hgS).1
  -- resolutions of the inputs
  have hxres : C.resAt (singleRes x ε) x.val = .const ε := by
    rw [C.resAt_single_input x ε x]
    simp
  have hyres : C.resAt (singleRes x ε) y.val = .lit y.val false := by
    rw [C.resAt_single_input x ε y]
    simp [Ne.symm hxy]
  -- `T` (constant), `U` (reads the constant `x`) and `R` (reads the constant `T`) are eliminated
  have halT : C.isAliased (singleRes x ε) n = true := C.isAliased_of_resAt_const _ hgT hTc
  have halU : C.isAliased (singleRes x ε) U = true := by
    apply C.isAliased_of_const _ hgU
    rcases habUx with hab | hab
    · left
      rw [hab, hxres]
      rfl
    · right
      rw [hab, hxres]
      rfl
  have halR : C.isAliased (singleRes x ε) R = true := by
    apply C.isAliased_of_const _ hgR
    rcases habR with hab | hab
    · left
      rw [hab]
      exact hTc
    · right
      rw [hab]
      exact hTc
  cases hSal : C.isAliased (singleRes x ε) S with
  | true =>
    -- `S` is eliminated as well: `E = {T, U, R, S}`, drop `≥ 12`
    have hn : n ∉ ({U, R, S} : Finset Nat) := by
      simp only [Finset.mem_insert, Finset.mem_singleton]
      omega
    have hU' : U ∉ ({R, S} : Finset Nat) := by
      simp only [Finset.mem_insert, Finset.mem_singleton]
      omega
    have hR' : R ∉ ({S} : Finset Nat) := by
      rw [Finset.mem_singleton]
      exact Ne.symm hSR
    refine h.drops x ε {n, U, R, S} ?_ 0 (Nat.zero_le _) 10 ?_
    · intro k hk
      simp only [Finset.mem_insert, Finset.mem_singleton] at hk
      rcases hk with hk | hk | hk | hk <;> rw [hk]
      · exact halT
      · exact halU
      · exact halR
      · exact hSal
    · have hsum : ∑ k ∈ ({n, U, R, S} : Finset Nat), C.gatePsiW k =
          C.gatePsiW n + (C.gatePsiW U + (C.gatePsiW R + C.gatePsiW S)) := by
        rw [Finset.sum_insert hn, Finset.sum_insert hU', Finset.sum_insert hR',
          Finset.sum_singleton]
      have hfil : (({n, U, R, S} : Finset Nat).filter (fun k => C.isDGate k = true)).card
          = 0 := by
        rw [Finset.card_eq_zero]
        apply Finset.filter_false_of_mem
        intro k hk
        simp only [Finset.mem_insert, Finset.mem_singleton] at hk
        rcases hk with hk | hk | hk | hk <;> rw [hk]
        · rw [hDT]
          exact Bool.false_ne_true
        · rw [hDU]
          exact Bool.false_ne_true
        · rw [hDR]
          exact Bool.false_ne_true
        · rw [hDS]
          exact Bool.false_ne_true
      rw [hsum, hfil]
      omega
  | false =>
    -- `S` survives; it becomes the unique reader of `y`, so `y` is gained: drop `≥ 9 + 1`
    have hSkept : C.isKept (singleRes x ε) S = true := by
      rw [C.isKept_eq_not_isAliased _ hgS, hSal, Bool.not_false]
    have hSres : C.resAt (singleRes x ε) S = .lit S false := C.resAt_kept _ hSkept
    have hSstep : (Res.step gS (C.resAt (singleRes x ε) aS)
        (C.resAt (singleRes x ε) bS)).isNone = true := by
      have hk := hSkept
      simp only [isKept, hgS] at hk
      exact hk
    -- `U` passes `y`: it is eliminated, not constant, and its operands are `x` and `y`
    have hUhit : (C.resAt (singleRes x ε) U).hits y.val = true := by
      have hstep := C.resAt_aliased _ hgU halU
      have hop : ∀ o s, (o = x.val ∨ o = y.val) →
          (C.resAt (singleRes x ε) o).hits s = true → y.val = s := by
        intro o s ho hh
        rcases ho with ho | ho
        · rw [ho, hxres] at hh
          simp [Res.hits] at hh
        · rw [ho, hyres] at hh
          exact (Res.hits_lit _ _ _).mp hh
      cases hU : C.resAt (singleRes x ε) U with
      | const _ =>
        rw [hU] at hUc
        simp [Res.isConst] at hUc
      | lit s neg =>
        rw [hU] at hstep
        rw [Res.hits_lit]
        rcases Res.step_hits gU _ _ s _ hstep ((Res.hits_lit s s neg).mpr rfl) with hh | hh
        · exact (hop aU s (by omega) hh).symm
        · exact (hop bU s (by omega) hh).symm
    -- the gates resolving to a literal of `y` are exactly `U` (`T` is constant, `S` is kept)
    have hpass : ∀ k, n ≤ k → k < n + C.size →
        (C.resAt (singleRes x ε) k).hits y.val = true → k ∈ ({U} : Finset Nat) := by
      apply C.passers_subset (singleRes x ε) y.val y.isLt (singleRes_hits x ε y.val) {U}
        (n + C.size)
      intro k g a b _ hk hkU hread
      have hkU' : k ≠ U := fun he => hkU (Finset.mem_singleton.mpr he)
      have hreadU : (a = U ∨ b = U) → (C.resAt (singleRes x ε) k).hits y.val = false := by
        intro hu
        rw [hUonly k (C.mem_users.mpr ⟨g, a, b, hk, hu⟩), hSres, Bool.eq_false_iff]
        intro hh
        rw [Res.hits_lit] at hh
        omega
      have hready : (a = y.val ∨ b = y.val) →
          (C.resAt (singleRes x ε) k).hits y.val = false := by
        intro hu
        rcases hyonly k (C.mem_users.mpr ⟨g, a, b, hk, hu⟩) with hkn | hkn
        · rw [hkn]
          exact TightEqualAux.hits_false_of_isConst _ _ hTc
        · exact absurd hkn hkU'
      rcases hread with hr | hr | hr | hr
      · exact hready (Or.inl hr)
      · exact hreadU (Or.inl (Finset.mem_singleton.mp hr))
      · exact hready (Or.inr hr)
      · exact hreadU (Or.inr (Finset.mem_singleton.mp hr))
    -- hence only `y` and `U` resolve to literals of `y`
    have hsig : ∀ o, o < n + C.size → (C.resAt (singleRes x ε) o).hits y.val = true →
        o = y.val ∨ o = U := by
      intro o ho hh
      by_cases hon : o < n
      · left
        have hin : C.resAt (singleRes x ε) o = singleRes x ε ⟨o, hon⟩ :=
          C.resAt_input (singleRes x ε) ⟨o, hon⟩
        rw [hin] at hh
        exact singleRes_hits x ε y.val ⟨o, hon⟩ hh
      · right
        exact Finset.mem_singleton.mp (hpass o (by omega) ho hh)
    -- exactly one slot of `S` hits `y`: the `U`-slot
    have hslot : indicator ((C.resAt (singleRes x ε) aS).hits y.val) +
        indicator ((C.resAt (singleRes x ε) bS).hits y.val) = 1 := by
      rcases habS with hab | hab
      · have ha : (C.resAt (singleRes x ε) aS).hits y.val = true := by
          rw [hab]
          exact hUhit
        rewrite [ha, TightEqualAux.not_hits_right_of_kept gS _ _ y.val hSstep ha]
        rfl
      · have hb : (C.resAt (singleRes x ε) bS).hits y.val = true := by
          rw [hab]
          exact hUhit
        rewrite [hb, TightEqualAux.not_hits_left_of_kept gS _ _ y.val hSstep hb]
        rfl
    -- no other kept gate reads a literal of `y`: the readers of `y` and `U` are `T, U, S`
    have hothers : ∀ k g' a' b', k ≠ S → C.gateAt k = some (g', a', b') →
        C.isKept (singleRes x ε) k = true →
        (C.resAt (singleRes x ε) a').hits y.val = false ∧
        (C.resAt (singleRes x ε) b').hits y.val = false := by
      intro k g' a' b' hkS hk hkk
      obtain ⟨-, hks, hak, hbk⟩ := C.gateAt_bounds hk
      have hkn : k ≠ n := by
        intro he
        rw [he, C.isKept_eq_not_isAliased _ hgT, halT] at hkk
        simp at hkk
      have hkU : k ≠ U := by
        intro he
        rw [he, C.isKept_eq_not_isAliased _ hgU, halU] at hkk
        simp at hkk
      have hop : ∀ o, (a' = o ∨ b' = o) → o < k →
          (C.resAt (singleRes x ε) o).hits y.val = false := by
        intro o ho hok
        rw [Bool.eq_false_iff]
        intro hh
        rcases hsig o (by omega) hh with hoy | hoU
        · rw [hoy] at ho
          rcases hyonly k (C.mem_users.mpr ⟨g', a', b', hk, ho⟩) with he | he
          · exact hkn he
          · exact hkU he
        · rw [hoU] at ho
          exact hkS (hUonly k (C.mem_users.mpr ⟨g', a', b', hk, ho⟩))
      exact ⟨hop a' (Or.inl rfl) hak, hop b' (Or.inr rfl) hbk⟩
    -- the output is not a literal of `y`: it is a gate, and not `U`
    have hout : ∀ k neg, C.outWire = some (k, neg) →
        (C.resAt (singleRes x ε) k).hits y.val = false := by
      intro k neg hw
      rw [Bool.eq_false_iff]
      intro hh
      obtain ⟨k', neg', hw', hk'⟩ := h.out_gate
      rw [hw] at hw'
      simp only [Option.some.injEq, Prod.mk.injEq] at hw'
      obtain ⟨hkk', -⟩ := hw'
      rcases hsig k (C.outWire_bound hw) hh with hky | hkU
      · omega
      · exact hUout k neg hw hkU
    -- `y` is gained
    have hnlS : gS.nonlinear = true := by
      simp only [tableAt, hgS] at hSnl
      exact hSnl
    have hkD : C.keptIsD (singleRes x ε) y.val = true :=
      C.keptIsD_of_unique_slot (singleRes x ε) y.val S gS aS bS hgS hSkept hnlS hslot hothers
        hout
    have hDy : C.isD y.val = false := by
      simp [isD, hcy]
    have hgain := C.gained_of_keptIsD x ε y hDy hkD
    -- `E = {T, U, R}`, drop `≥ 9 + 1`
    have hn : n ∉ ({U, R} : Finset Nat) := by
      simp only [Finset.mem_insert, Finset.mem_singleton]
      omega
    have hU' : U ∉ ({R} : Finset Nat) := by
      rw [Finset.mem_singleton]
      exact Ne.symm hRU
    refine h.drops x ε {n, U, R} ?_ 1 hgain 10 ?_
    · intro k hk
      simp only [Finset.mem_insert, Finset.mem_singleton] at hk
      rcases hk with hk | hk | hk <;> rw [hk]
      · exact halT
      · exact halU
      · exact halR
    · have hsum : ∑ k ∈ ({n, U, R} : Finset Nat), C.gatePsiW k =
          C.gatePsiW n + (C.gatePsiW U + C.gatePsiW R) := by
        rw [Finset.sum_insert hn, Finset.sum_insert hU', Finset.sum_singleton]
      have hfil : (({n, U, R} : Finset Nat).filter (fun k => C.isDGate k = true)).card
          = 0 := by
        rw [Finset.card_eq_zero]
        apply Finset.filter_false_of_mem
        intro k hk
        simp only [Finset.mem_insert, Finset.mem_singleton] at hk
        rcases hk with hk | hk | hk <;> rw [hk]
        · rw [hDT]
          exact Bool.false_ne_true
        · rw [hDU]
          exact Bool.false_ne_true
        · rw [hDR]
          exact Bool.false_ne_true
      rw [hsum, hfil]
      omega

end MAContext
end SatLowerBound
