import Credit.MainA.Toolkit



namespace SatLowerBound
namespace MAContext

open OpenCircuit

theorem tight_distinct {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (x y : Fin n) (hxy : x ≠ y) (U V R : Nat) (ε : Bool)
    (hUn : U ≠ n) (hVn : V ≠ n) (hUV : U ≠ V)
    (hux : C.users x.val = {n, U}) (hvy : C.users y.val = {n, V}) (hR : C.users n = {R})
    (hTc : (C.resAt (singleRes x ε) n).isConst = true)
    (_hUc : (C.resAt (singleRes x ε) U).isConst = false)
    (_hRc : (C.resAt (singleRes x ε) R).isConst = false)
    (hVnl : (C.tableAt V).nonlinear = true) :
    C.DropsAt x ε 10 := by
  -- membership facts
  have hTx : n ∈ C.users x.val := by
    rw [hux]
    exact Finset.mem_insert_self n {U}
  have hUx : U ∈ C.users x.val := by
    rw [hux]
    exact Finset.mem_insert_of_mem (Finset.mem_singleton_self U)
  have hTy : n ∈ C.users y.val := by
    rw [hvy]
    exact Finset.mem_insert_self n {V}
  have hVy : V ∈ C.users y.val := by
    rw [hvy]
    exact Finset.mem_insert_of_mem (Finset.mem_singleton_self V)
  have hRT : R ∈ C.users n := by
    rw [hR]
    exact Finset.mem_singleton_self R
  -- `x` and `y` are read exactly twice
  have hcx : C.refCount x.val = 2 := by
    rw [h.refCount_input x, hux, Finset.card_pair (Ne.symm hUn)]
  have hcy : C.refCount y.val = 2 := by
    rw [h.refCount_input y, hvy, Finset.card_pair (Ne.symm hVn)]
  -- the gates `T = n`, `U`, `R`, `V`
  obtain ⟨gT, aT, bT, hgT, -⟩ := C.mem_users.mp hTx
  obtain ⟨gU, aU, bU, hgU, -⟩ := C.mem_users.mp hUx
  obtain ⟨gR, aR, bR, hgR, habR⟩ := C.mem_users.mp hRT
  obtain ⟨gV, aV, bV, hgV, habV⟩ := C.mem_users.mp hVy
  obtain ⟨-, -, haT, hbT⟩ := C.gateAt_bounds hgT
  obtain ⟨-, -, haR, hbR⟩ := C.gateAt_bounds hgR
  obtain ⟨hVn', hVs, haV, hbV⟩ := C.gateAt_bounds hgV
  -- distinctness of `T, U, R, V`
  have hRn : R ≠ n := by
    rcases habR with hab | hab <;> omega
  have hRU : R ≠ U := by
    intro he
    have hR' := h.no_triangle x.isLt hTx hRT
    rw [he] at hR'
    exact hR' hUx
  have hRV : R ≠ V := by
    intro he
    have hR' := h.no_triangle y.isLt hTy hRT
    rw [he] at hR'
    exact hR' hVy
  -- no charges: F1 for the readers `T, U` of `x` and `V` of `y`, F2 for the reader `R` of `T`
  have hDT : C.isDGate n = false := h.not_dGate_of_multi x (by omega) hTx
  have hDU : C.isDGate U = false := h.not_dGate_of_multi x (by omega) hUx
  have hDV : C.isDGate V = false := h.not_dGate_of_multi y (by omega) hVy
  have hDR : C.isDGate R = false := h.not_dGate_of_primary_pred hgT haT hbT hRT
  -- weights
  have h3T := (h.psiW_ge hgT).1
  have h3U := (h.psiW_ge hgU).1
  have h3R := (h.psiW_ge hgR).1
  have h3V := (h.psiW_ge hgV).1
  -- `T`, `U` (readers of the constant `x`) and `R` (reader of the constant `T`) are eliminated
  have hxres : C.resAt (singleRes x ε) x.val = .const ε := by
    rw [C.resAt_single_input x ε x]
    simp
  have halx : ∀ k ∈ C.users x.val, C.isAliased (singleRes x ε) k = true := by
    intro k hk
    obtain ⟨g, a, b, hg, hab⟩ := C.mem_users.mp hk
    apply C.isAliased_of_const _ hg
    rcases hab with hab | hab
    · left
      rw [hab, hxres]
      rfl
    · right
      rw [hab, hxres]
      rfl
  have halR : C.isAliased (singleRes x ε) R = true := by
    apply C.isAliased_of_const _ hgR
    rcases habR with hab | hab
    · left
      rw [hab]
      exact hTc
    · right
      rw [hab]
      exact hTc
  cases hVal : C.isAliased (singleRes x ε) V with
  | true =>
    -- `V` is eliminated as well: `E = {T, U, R, V}`, drop `≥ 12`
    have hn : n ∉ ({U, R, V} : Finset Nat) := by
      simp only [Finset.mem_insert, Finset.mem_singleton, not_or]
      exact ⟨Ne.symm hUn, Ne.symm hRn, Ne.symm hVn⟩
    have hU' : U ∉ ({R, V} : Finset Nat) := by
      simp only [Finset.mem_insert, Finset.mem_singleton, not_or]
      exact ⟨Ne.symm hRU, hUV⟩
    have hR' : R ∉ ({V} : Finset Nat) := by
      rw [Finset.mem_singleton]
      exact hRV
    refine h.drops x ε {n, U, R, V} ?_ 0 (Nat.zero_le _) 10 ?_
    · intro k hk
      simp only [Finset.mem_insert, Finset.mem_singleton] at hk
      rcases hk with hk | hk | hk | hk <;> rw [hk]
      · exact halx n hTx
      · exact halx U hUx
      · exact halR
      · exact hVal
    · have hsum : ∑ k ∈ ({n, U, R, V} : Finset Nat), C.gatePsiW k =
          C.gatePsiW n + (C.gatePsiW U + (C.gatePsiW R + C.gatePsiW V)) := by
        rw [Finset.sum_insert hn, Finset.sum_insert hU', Finset.sum_insert hR',
          Finset.sum_singleton]
      have hfil : (({n, U, R, V} : Finset Nat).filter (fun k => C.isDGate k = true)).card
          = 0 := by
        rw [Finset.card_eq_zero]
        apply Finset.filter_false_of_mem
        intro k hk
        simp only [Finset.mem_insert, Finset.mem_singleton] at hk
        rcases hk with hk | hk | hk | hk <;> rw [hk]
        · rw [hDT]
          exact Bool.false_ne_true
        · rw [hDU]
          exact Bool.false_ne_true
        · rw [hDR]
          exact Bool.false_ne_true
        · rw [hDV]
          exact Bool.false_ne_true
      rw [hsum, hfil]
      omega
  | false =>
    -- `V` survives; it becomes the unique reader of `y`, so `y` is gained: drop `≥ 9 + 1`
    have hVkept : C.isKept (singleRes x ε) V = true := by
      rw [C.isKept_eq_not_isAliased _ hgV, hVal]
      rfl
    have hVres : C.resAt (singleRes x ε) V = .lit V false := C.resAt_kept _ hVkept
    have hyres : C.resAt (singleRes x ε) y.val = .lit y.val false := by
      rw [C.resAt_single_input x ε y]
      simp [Ne.symm hxy]
    have hyhit : (C.resAt (singleRes x ε) y.val).hits y.val = true := by
      rw [hyres]
      exact (Res.hits_lit _ _ _).mpr rfl
    -- no gate resolves to a literal of `y`: its readers are `T` (constant) and `V` (kept)
    have hnopass : ∀ k, n ≤ k → k < n + C.size →
        (C.resAt (singleRes x ε) k).hits y.val = true → k ∈ (∅ : Finset Nat) := by
      apply C.passers_subset (singleRes x ε) y.val y.isLt (singleRes_hits x ε y.val) ∅
        (n + C.size)
      intro k g a b _ hk _ hread
      have hky : k ∈ C.users y.val := by
        rcases hread with hr | hr | hr | hr
        · exact C.mem_users.mpr ⟨g, a, b, hk, Or.inl hr⟩
        · simp at hr
        · exact C.mem_users.mpr ⟨g, a, b, hk, Or.inr hr⟩
        · simp at hr
      rw [hvy, Finset.mem_insert, Finset.mem_singleton] at hky
      rcases hky with hky | hky
      · rw [hky]
        cases hres : C.resAt (singleRes x ε) n with
        | const c => rfl
        | lit s neg =>
          rw [hres] at hTc
          simp [Res.isConst] at hTc
      · rw [hky, hVres, Bool.eq_false_iff]
        intro hh
        rw [Res.hits_lit] at hh
        have := y.isLt
        omega
    -- hence no signal other than `y` itself resolves to a literal of `y`
    have hother : ∀ o, o < n + C.size → o ≠ y.val →
        (C.resAt (singleRes x ε) o).hits y.val = false := by
      intro o ho hne
      rw [Bool.eq_false_iff]
      intro hh
      by_cases hon : o < n
      · have hin : C.resAt (singleRes x ε) o = singleRes x ε ⟨o, hon⟩ :=
          C.resAt_input (singleRes x ε) ⟨o, hon⟩
        rw [hin] at hh
        exact hne (singleRes_hits x ε y.val ⟨o, hon⟩ hh)
      · have := hnopass o (by omega) ho hh
        simp at this
    have hgVnl : gV.nonlinear = true := by
      simp only [OpenCircuit.tableAt, hgV] at hVnl
      exact hVnl
    -- `y` is a D-variable of the restricted circuit, with D-gate `V`
    have hkD : C.keptIsD (singleRes x ε) y.val = true := by
      obtain ⟨-, hne, -⟩ := h.gate_facts hgV
      apply C.keptIsD_of_unique_slot (singleRes x ε) y.val V gV aV bV hgV hVkept hgVnl
      · rcases habV with ha | hb
        · have hb : bV ≠ y.val := by
            rw [← ha]
            exact Ne.symm hne
          rw [ha, hyhit, hother bV (by omega) hb]
          rfl
        · have ha : aV ≠ y.val := by
            rw [← hb]
            exact hne
          rw [hb, hyhit, hother aV (by omega) ha]
          rfl
      · intro k g' a' b' hkV hk hkk
        have hkn : k ≠ n := by
          intro hkn
          rw [hkn] at hkk
          rw [C.resAt_kept _ hkk] at hTc
          simp [Res.isConst] at hTc
        obtain ⟨-, hks, ha', hb'⟩ := C.gateAt_bounds hk
        have hnot : ∀ o, (a' = o ∨ b' = o) → o ≠ y.val := by
          intro o ho hoy
          rw [hoy] at ho
          have hmem : k ∈ C.users y.val := C.mem_users.mpr ⟨g', a', b', hk, ho⟩
          rw [hvy, Finset.mem_insert, Finset.mem_singleton] at hmem
          rcases hmem with hm | hm
          · exact hkn hm
          · exact hkV hm
        exact ⟨hother a' (by omega) (hnot a' (Or.inl rfl)),
          hother b' (by omega) (hnot b' (Or.inr rfl))⟩
      · intro k neg hk
        obtain ⟨k₀, neg₀, hw, hk₀⟩ := h.out_gate
        have hkk : k₀ = k := by
          rw [hw] at hk
          simp only [Option.some.injEq, Prod.mk.injEq] at hk
          exact hk.1
        exact hother k (C.outWire_bound hk) (by have := y.isLt; omega)
    have hDy : C.isD y.val = false := by
      simp [OpenCircuit.isD, hcy]
    have hgain := C.gained_of_keptIsD x ε y hDy hkD
    have hn : n ∉ ({U, R} : Finset Nat) := by
      simp only [Finset.mem_insert, Finset.mem_singleton, not_or]
      exact ⟨Ne.symm hUn, Ne.symm hRn⟩
    have hU' : U ∉ ({R} : Finset Nat) := by
      rw [Finset.mem_singleton]
      exact Ne.symm hRU
    refine h.drops x ε {n, U, R} ?_ 1 hgain 10 ?_
    · intro k hk
      simp only [Finset.mem_insert, Finset.mem_singleton] at hk
      rcases hk with hk | hk | hk <;> rw [hk]
      · exact halx n hTx
      · exact halx U hUx
      · exact halR
    · have hsum : ∑ k ∈ ({n, U, R} : Finset Nat), C.gatePsiW k =
          C.gatePsiW n + (C.gatePsiW U + C.gatePsiW R) := by
        rw [Finset.sum_insert hn, Finset.sum_insert hU', Finset.sum_singleton]
      have hfil : (({n, U, R} : Finset Nat).filter (fun k => C.isDGate k = true)).card = 0 := by
        rw [Finset.card_eq_zero]
        apply Finset.filter_false_of_mem
        intro k hk
        simp only [Finset.mem_insert, Finset.mem_singleton] at hk
        rcases hk with hk | hk | hk <;> rw [hk]
        · rw [hDT]
          exact Bool.false_ne_true
        · rw [hDU]
          exact Bool.false_ne_true
        · rw [hDR]
          exact Bool.false_ne_true
      rw [hsum, hfil]
      omega

end MAContext
end SatLowerBound
