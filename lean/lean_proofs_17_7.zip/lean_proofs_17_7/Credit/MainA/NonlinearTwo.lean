import Credit.MainA.TightDistinct
import Credit.MainA.TightEqual



namespace SatLowerBound
namespace MAContext

open OpenCircuit

namespace NonlinearTwoAux

/-! ### Local facts about gates and resolutions -/

/-- An eliminated signal is a gate, so its weight is at least `3`. -/
private theorem three_le_psiW {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (ρ : Fin n → Res) {k : Nat} (hk : C.isAliased ρ k = true) :
    3 ≤ C.gatePsiW k := by
  cases hg : C.gateAt k with
  | none => simp [OpenCircuit.isAliased, hg] at hk
  | some p =>
    obtain ⟨g, a, b⟩ := p
    exact (h.psiW_ge hg).1

/-- A gate whose weight is not `5` has a nonlinear table. -/
private theorem nonlinear_of_ne_five {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) {k : Nat} {g : Table} {a b : Nat} (hk : C.gateAt k = some (g, a, b))
    (h5 : ¬ C.gatePsiW k = 5) : g.nonlinear = true := by
  rcases g.essential_parity_or_nonlinear (h.gate_facts hk).1 with hp | hp
  · exact absurd ((h.psiW_ge hk).2 hp) h5
  · exact hp

private theorem tableAt_eq {n : Nat} (C : OpenCircuit n) {k : Nat} {g : Table} {a b : Nat}
    (hk : C.gateAt k = some (g, a, b)) : C.tableAt k = g := by
  simp only [OpenCircuit.tableAt, hk]

/-- The fixed input resolves to its value. -/
private theorem resAt_fixed {n : Nat} (C : OpenCircuit n) (x : Fin n) (b : Bool) :
    C.resAt (singleRes x b) x.val = .const b := by
  rw [C.resAt_single_input x b x]
  simp

private theorem fixed_isConst {n : Nat} (C : OpenCircuit n) (x : Fin n) (b : Bool) :
    (C.resAt (singleRes x b) x.val).isConst = true := by
  rw [resAt_fixed C x b]
  rfl

/-- Another input stays free. -/
private theorem resAt_free {n : Nat} (C : OpenCircuit n) (x y : Fin n) (hxy : x ≠ y)
    (b : Bool) : C.resAt (singleRes x b) y.val = .lit y.val false := by
  rw [C.resAt_single_input x b y]
  simp [Ne.symm hxy]

/-- Every reader of the fixed input is eliminated. -/
private theorem alias_of_user {n : Nat} (C : OpenCircuit n) (x : Fin n) (b : Bool) {k : Nat}
    (hk : k ∈ C.users x.val) : C.isAliased (singleRes x b) k = true := by
  obtain ⟨g, a, a', hg, hax⟩ := C.mem_users.mp hk
  apply C.isAliased_of_const _ hg
  rcases hax with hax | hax
  · left
    rw [hax]
    exact fixed_isConst C x b
  · right
    rw [hax]
    exact fixed_isConst C x b

/-- A reader of `s` is a gate after `s`. -/
private theorem lt_of_mem_users {n : Nat} (C : OpenCircuit n) {s k : Nat}
    (hk : k ∈ C.users s) : s < k ∧ n ≤ k ∧ k < n + C.size := by
  obtain ⟨g, a, b, hg, hab⟩ := C.mem_users.mp hk
  have hb := C.gateAt_bounds hg
  rcases hab with hab | hab <;> omega

/-- A gate reading the two different signals `s, s'` reads exactly them. -/
private theorem operands_of_two {n : Nat} (C : OpenCircuit n) {s s' k : Nat} (hss : s ≠ s')
    (hs : k ∈ C.users s) (hs' : k ∈ C.users s') :
    ∃ g a b, C.gateAt k = some (g, a, b) ∧ ((a = s ∧ b = s') ∨ (a = s' ∧ b = s)) := by
  obtain ⟨g, a, b, hk, hab⟩ := C.mem_users.mp hs
  obtain ⟨g', a', b', hk', hab'⟩ := C.mem_users.mp hs'
  rw [hk] at hk'
  simp only [Option.some.injEq, Prod.mk.injEq] at hk'
  obtain ⟨-, ha, hb⟩ := hk'
  rw [← ha, ← hb] at hab'
  exact ⟨g, a, b, hk, by omega⟩

/-- A gate both of whose operands resolve to constants resolves to a constant. -/
private theorem const_of_operands {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) {k : Nat}
    {g : Table} {a b : Nat} (hk : C.gateAt k = some (g, a, b))
    (ha : (C.resAt ρ a).isConst = true) (hb : (C.resAt ρ b).isConst = true) :
    (C.resAt ρ k).isConst = true := by
  rw [C.resAt_gate ρ hk]
  cases hra : C.resAt ρ a with
  | lit s neg =>
    rw [hra] at ha
    simp [Res.isConst] at ha
  | const c₁ =>
    cases hrb : C.resAt ρ b with
    | lit s neg =>
      rw [hrb] at hb
      simp [Res.isConst] at hb
    | const c₂ => rfl

/-- A gate reading two different constant signals is constant. -/
private theorem const_of_reads_two {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res)
    {k s s' : Nat} (hss : s ≠ s') (hs : k ∈ C.users s) (hs' : k ∈ C.users s')
    (hcs : (C.resAt ρ s).isConst = true) (hcs' : (C.resAt ρ s').isConst = true) :
    (C.resAt ρ k).isConst = true := by
  obtain ⟨g, a, b, hk, hab⟩ := operands_of_two C hss hs hs'
  rcases hab with ⟨ha, hb⟩ | ⟨ha, hb⟩
  · rw [← ha] at hcs
    rw [← hb] at hcs'
    exact const_of_operands C ρ hk hcs hcs'
  · rw [← ha] at hcs'
    rw [← hb] at hcs
    exact const_of_operands C ρ hk hcs' hcs

/-- Nonlinear tables: if `e` does not block the left side, `!e` does. -/
private theorem blocksLeft_flip (g : Table) (hg : g.nonlinear = true) (e : Bool)
    (he : g.blocksLeft e = false) : g.blocksLeft (!e) = true := by
  revert hg he
  rcases g with ⟨a, b, c, d⟩
  cases e <;> cases a <;> cases b <;> cases c <;> cases d <;> decide

/-- Nonlinear tables: if `e` does not block the right side, `!e` does. -/
private theorem blocksRight_flip (g : Table) (hg : g.nonlinear = true) (e : Bool)
    (he : g.blocksRight e = false) : g.blocksRight (!e) = true := by
  revert hg he
  rcases g with ⟨a, b, c, d⟩
  cases e <;> cases a <;> cases b <;> cases c <;> cases d <;> decide

/-- A nonlinear gate reading the fixed input `x` and the free input `y`: if `x := e` does not
make it constant, then `x := !e` does. -/
private theorem const_flip {n : Nat} (C : OpenCircuit n) (x y : Fin n) (hxy : x ≠ y) {k : Nat}
    {g : Table} {a b : Nat} (hk : C.gateAt k = some (g, a, b))
    (hab : (a = x.val ∧ b = y.val) ∨ (a = y.val ∧ b = x.val)) (hg : g.nonlinear = true)
    (e : Bool) (hnc : (C.resAt (singleRes x e) k).isConst = false) :
    (C.resAt (singleRes x (!e)) k).isConst = true := by
  rw [C.resAt_gate _ hk] at hnc ⊢
  rcases hab with ⟨ha, hb⟩ | ⟨ha, hb⟩
  · rw [ha, hb, resAt_fixed C x e, resAt_free C x y hxy e] at hnc
    rw [ha, hb, resAt_fixed C x (!e), resAt_free C x y hxy (!e)]
    cases hbl : g.blocksLeft e with
    | true =>
      rw [Res.step_blocked_left g e _ hbl] at hnc
      simp [Res.isConst] at hnc
    | false =>
      rw [Res.step_blocked_left g (!e) _ (blocksLeft_flip g hg e hbl)]
      rfl
  · rw [ha, hb, resAt_fixed C x e, resAt_free C x y hxy e] at hnc
    rw [ha, hb, resAt_fixed C x (!e), resAt_free C x y hxy (!e)]
    cases hbr : g.blocksRight e with
    | true =>
      rw [Res.step_blocked_right g _ e hbr] at hnc
      simp [Res.isConst] at hnc
    | false =>
      rw [Res.step_blocked_right g _ (!e) (blocksRight_flip g hg e hbr)]
      rfl

/-! ### Counting eliminated gates -/

/-- Three distinct uncharged eliminated gates, one of them parity: drop `≥ 3 + 3 + 5`. -/
private theorem drops_three {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (x : Fin n) (b : Bool) (k₁ k₂ k₃ : Nat)
    (h12 : k₁ ≠ k₂) (h13 : k₁ ≠ k₃) (h23 : k₂ ≠ k₃)
    (ha₁ : C.isAliased (singleRes x b) k₁ = true) (ha₂ : C.isAliased (singleRes x b) k₂ = true)
    (ha₃ : C.isAliased (singleRes x b) k₃ = true)
    (hd₁ : C.isDGate k₁ = false) (hd₂ : C.isDGate k₂ = false) (hd₃ : C.isDGate k₃ = false)
    (h5 : C.gatePsiW k₂ = 5 ∨ C.gatePsiW k₃ = 5) : C.DropsAt x b 10 := by
  have w₁ := three_le_psiW h _ ha₁
  have w₂ := three_le_psiW h _ ha₂
  have w₃ := three_le_psiW h _ ha₃
  have hn₁ : k₁ ∉ ({k₂, k₃} : Finset Nat) := by
    simp only [Finset.mem_insert, Finset.mem_singleton]
    omega
  have hn₂ : k₂ ∉ ({k₃} : Finset Nat) := by
    simp only [Finset.mem_singleton]
    omega
  refine h.drops x b {k₁, k₂, k₃} ?_ 0 (Nat.zero_le _) 10 ?_
  · intro k hk
    simp only [Finset.mem_insert, Finset.mem_singleton] at hk
    rcases hk with hk | hk | hk
    · rw [hk]
      exact ha₁
    · rw [hk]
      exact ha₂
    · rw [hk]
      exact ha₃
  · have hsum : ∑ k ∈ ({k₁, k₂, k₃} : Finset Nat), C.gatePsiW k =
        C.gatePsiW k₁ + (C.gatePsiW k₂ + C.gatePsiW k₃) := by
      rw [Finset.sum_insert hn₁, Finset.sum_insert hn₂, Finset.sum_singleton]
    have hfil : (({k₁, k₂, k₃} : Finset Nat).filter
        (fun k => C.isDGate k = true)).card = 0 := by
      rw [Finset.card_eq_zero]
      apply Finset.filter_false_of_mem
      intro k hk
      simp only [Finset.mem_insert, Finset.mem_singleton] at hk
      rcases hk with hk | hk | hk
      · rw [hk, hd₁]
        exact Bool.false_ne_true
      · rw [hk, hd₂]
        exact Bool.false_ne_true
      · rw [hk, hd₃]
        exact Bool.false_ne_true
    rw [hsum, hfil]
    omega

/-- Four distinct eliminated gates, the first three uncharged: drop `≥ 3 + 3 + 3 + 2`. -/
private theorem drops_four {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (x : Fin n) (b : Bool) (k₁ k₂ k₃ k₄ : Nat)
    (h12 : k₁ ≠ k₂) (h13 : k₁ ≠ k₃) (h14 : k₁ ≠ k₄) (h23 : k₂ ≠ k₃) (h24 : k₂ ≠ k₄)
    (h34 : k₃ ≠ k₄)
    (ha₁ : C.isAliased (singleRes x b) k₁ = true) (ha₂ : C.isAliased (singleRes x b) k₂ = true)
    (ha₃ : C.isAliased (singleRes x b) k₃ = true) (ha₄ : C.isAliased (singleRes x b) k₄ = true)
    (hd₁ : C.isDGate k₁ = false) (hd₂ : C.isDGate k₂ = false) (hd₃ : C.isDGate k₃ = false) :
    C.DropsAt x b 10 := by
  have w₁ := three_le_psiW h _ ha₁
  have w₂ := three_le_psiW h _ ha₂
  have w₃ := three_le_psiW h _ ha₃
  have w₄ := three_le_psiW h _ ha₄
  have hn₁ : k₁ ∉ ({k₂, k₃, k₄} : Finset Nat) := by
    simp only [Finset.mem_insert, Finset.mem_singleton]
    omega
  have hn₂ : k₂ ∉ ({k₃, k₄} : Finset Nat) := by
    simp only [Finset.mem_insert, Finset.mem_singleton]
    omega
  have hn₃ : k₃ ∉ ({k₄} : Finset Nat) := by
    simp only [Finset.mem_singleton]
    omega
  refine h.drops x b {k₁, k₂, k₃, k₄} ?_ 0 (Nat.zero_le _) 10 ?_
  · intro k hk
    simp only [Finset.mem_insert, Finset.mem_singleton] at hk
    rcases hk with hk | hk | hk | hk
    · rw [hk]
      exact ha₁
    · rw [hk]
      exact ha₂
    · rw [hk]
      exact ha₃
    · rw [hk]
      exact ha₄
  · have hsum : ∑ k ∈ ({k₁, k₂, k₃, k₄} : Finset Nat), C.gatePsiW k =
        C.gatePsiW k₁ + (C.gatePsiW k₂ + (C.gatePsiW k₃ + C.gatePsiW k₄)) := by
      rw [Finset.sum_insert hn₁, Finset.sum_insert hn₂, Finset.sum_insert hn₃,
        Finset.sum_singleton]
    have hsub : ({k₁, k₂, k₃, k₄} : Finset Nat).filter (fun k => C.isDGate k = true) ⊆
        {k₄} := by
      intro k hk
      rw [Finset.mem_filter] at hk
      obtain ⟨hkE, hkD⟩ := hk
      simp only [Finset.mem_insert, Finset.mem_singleton] at hkE
      rcases hkE with hk | hk | hk | hk
      · rw [hk, hd₁] at hkD
        exact absurd hkD Bool.false_ne_true
      · rw [hk, hd₂] at hkD
        exact absurd hkD Bool.false_ne_true
      · rw [hk, hd₃] at hkD
        exact absurd hkD Bool.false_ne_true
      · rw [hk]
        exact Finset.mem_singleton_self k₄
    have hfil := Finset.card_le_card hsub
    rw [Finset.card_singleton] at hfil
    rw [hsum]
    omega

/-! ### The generic cases

Setting: the step `x := b`, `refCount x ≥ 2`, two different readers `P, Q` of `x`, `P` has
two primary operands and becomes constant.  `P` and `Q` are eliminated and uncharged (F1);
the readers of `P` are eliminated (F5), uncharged (F2) and not readers of `x` (F4). -/

/-- `P` has at least two readers: `E = {P, Q, R₁, R₂}`. -/
private theorem case_two_readers {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (x : Fin n) (b : Bool) (hx2 : 2 ≤ C.refCount x.val) {P Q : Nat}
    (hPQ : P ≠ Q) (hPx : P ∈ C.users x.val) (hQx : Q ∈ C.users x.val) {g : Table}
    {a a' : Nat} (hP : C.gateAt P = some (g, a, a')) (ha : a < n) (ha' : a' < n)
    (hPc : (C.resAt (singleRes x b) P).isConst = true) (hcard : 1 < (C.users P).card) :
    C.DropsAt x b 10 := by
  obtain ⟨R₁, hR₁, R₂, hR₂, hR⟩ := Finset.one_lt_card.mp hcard
  have hPb := C.gateAt_bounds hP
  have hF5 := (h.const_users x b hPb.1 hPb.2.1 hPc).2
  have hR₁x : R₁ ∉ C.users x.val := h.no_triangle x.isLt hPx hR₁
  have hR₂x : R₂ ∉ C.users x.val := h.no_triangle x.isLt hPx hR₂
  exact drops_four h x b P Q R₁ R₂ hPQ (fun he => hR₁x (he ▸ hPx)) (fun he => hR₂x (he ▸ hPx))
    (fun he => hR₁x (he ▸ hQx)) (fun he => hR₂x (he ▸ hQx)) hR
    (alias_of_user C x b hPx) (alias_of_user C x b hQx) (hF5 R₁ hR₁) (hF5 R₂ hR₂)
    (h.not_dGate_of_multi x hx2 hPx) (h.not_dGate_of_multi x hx2 hQx)
    (h.not_dGate_of_primary_pred hP ha ha' hR₁)

/-- `Q` or some reader of `P` is a parity gate: `E = {P, Q, R}`. -/
private theorem case_parity_reader {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (x : Fin n) (b : Bool) (hx2 : 2 ≤ C.refCount x.val) {P Q : Nat}
    (hPQ : P ≠ Q) (hPx : P ∈ C.users x.val) (hQx : Q ∈ C.users x.val) {g : Table}
    {a a' : Nat} (hP : C.gateAt P = some (g, a, a')) (ha : a < n) (ha' : a' < n)
    (hPc : (C.resAt (singleRes x b) P).isConst = true)
    (h5 : C.gatePsiW Q = 5 ∨ ∃ R ∈ C.users P, C.gatePsiW R = 5) : C.DropsAt x b 10 := by
  have hPb := C.gateAt_bounds hP
  obtain ⟨hne, hF5⟩ := h.const_users x b hPb.1 hPb.2.1 hPc
  obtain ⟨R, hR, h5'⟩ : ∃ R ∈ C.users P, C.gatePsiW Q = 5 ∨ C.gatePsiW R = 5 := by
    rcases h5 with h5 | ⟨R, hR, h5⟩
    · obtain ⟨R, hR⟩ := hne
      exact ⟨R, hR, Or.inl h5⟩
    · exact ⟨R, hR, Or.inr h5⟩
  have hRx : R ∉ C.users x.val := h.no_triangle x.isLt hPx hR
  exact drops_three h x b P Q R hPQ (fun he => hRx (he ▸ hPx)) (fun he => hRx (he ▸ hQx))
    (alias_of_user C x b hPx) (alias_of_user C x b hQx) (hF5 R hR)
    (h.not_dGate_of_multi x hx2 hPx) (h.not_dGate_of_multi x hx2 hQx)
    (h.not_dGate_of_primary_pred hP ha ha' hR) h5'

/-- `Q` becomes constant as well: `E = {P, Q, R₁, W}` or `E = {P, Q, R₁, R₂}`. -/
private theorem case_both_const {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (x : Fin n) (b : Bool) (hx2 : 2 ≤ C.refCount x.val) {P Q : Nat}
    (hPQ : P ≠ Q) (hPx : P ∈ C.users x.val) (hQx : Q ∈ C.users x.val) {g : Table}
    {a a' : Nat} (hP : C.gateAt P = some (g, a, a')) (ha : a < n) (ha' : a' < n)
    (hPc : (C.resAt (singleRes x b) P).isConst = true)
    (hQc : (C.resAt (singleRes x b) Q).isConst = true) : C.DropsAt x b 10 := by
  have hPb := C.gateAt_bounds hP
  obtain ⟨⟨R₁, hR₁⟩, hF5P⟩ := h.const_users x b hPb.1 hPb.2.1 hPc
  obtain ⟨-, hQn, hQs⟩ := lt_of_mem_users C hQx
  obtain ⟨⟨W, hW⟩, hF5Q⟩ := h.const_users x b hQn hQs hQc
  have hR₁x : R₁ ∉ C.users x.val := h.no_triangle x.isLt hPx hR₁
  have hWx : W ∉ C.users x.val := h.no_triangle x.isLt hQx hW
  have hdP := h.not_dGate_of_multi x hx2 hPx
  have hdQ := h.not_dGate_of_multi x hx2 hQx
  have hdR₁ := h.not_dGate_of_primary_pred hP ha ha' hR₁
  by_cases hWR : W = R₁
  · -- `R₁` reads the two constants `P` and `Q`, so it is constant and has a reader `R₂`
    rw [hWR] at hW
    have hR₁c := const_of_reads_two C (singleRes x b) hPQ hR₁ hW hPc hQc
    obtain ⟨hPR₁, hR₁n, hR₁s⟩ := lt_of_mem_users C hR₁
    have hQR₁ := (lt_of_mem_users C hW).1
    obtain ⟨⟨R₂, hR₂⟩, hF5R⟩ := h.const_users x b hR₁n hR₁s hR₁c
    have hR₁R₂ := (lt_of_mem_users C hR₂).1
    exact drops_four h x b P Q R₁ R₂ hPQ (fun he => hR₁x (he ▸ hPx)) (by omega)
      (fun he => hR₁x (he ▸ hQx)) (by omega) (by omega)
      (alias_of_user C x b hPx) (alias_of_user C x b hQx) (hF5P R₁ hR₁) (hF5R R₂ hR₂)
      hdP hdQ hdR₁
  · exact drops_four h x b P Q R₁ W hPQ (fun he => hR₁x (he ▸ hPx)) (fun he => hWx (he ▸ hPx))
      (fun he => hR₁x (he ▸ hQx)) (fun he => hWx (he ▸ hQx)) (fun he => hWR he.symm)
      (alias_of_user C x b hPx) (alias_of_user C x b hQx) (hF5P R₁ hR₁) (hF5Q W hW)
      hdP hdQ hdR₁

/-- A reader `R` of `P` becomes constant: `E = {P, Q, R, R₂}` with `R₂ ∈ users R`. -/
private theorem case_reader_const {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) (x : Fin n) (b : Bool) (hx2 : 2 ≤ C.refCount x.val) {P Q : Nat}
    (hPQ : P ≠ Q) (hPx : P ∈ C.users x.val) (hQx : Q ∈ C.users x.val) {g : Table}
    {a a' : Nat} (hP : C.gateAt P = some (g, a, a')) (ha : a < n) (ha' : a' < n)
    (hPc : (C.resAt (singleRes x b) P).isConst = true) {R : Nat} (hR : R ∈ C.users P)
    (hRc : (C.resAt (singleRes x b) R).isConst = true) : C.DropsAt x b 10 := by
  by_cases hQc : (C.resAt (singleRes x b) Q).isConst = true
  · exact case_both_const h x b hx2 hPQ hPx hQx hP ha ha' hPc hQc
  have hPb := C.gateAt_bounds hP
  have hF5P := (h.const_users x b hPb.1 hPb.2.1 hPc).2
  have hRx : R ∉ C.users x.val := h.no_triangle x.isLt hPx hR
  obtain ⟨hPR, hRn, hRs⟩ := lt_of_mem_users C hR
  obtain ⟨⟨R₂, hR₂⟩, hF5R⟩ := h.const_users x b hRn hRs hRc
  have hRR₂ := (lt_of_mem_users C hR₂).1
  have hQR₂ : Q ≠ R₂ := by
    intro he
    rw [← he] at hR₂
    have hxR : x.val ≠ R := by
      have := x.isLt
      omega
    exact hQc (const_of_reads_two C (singleRes x b) hxR hQx hR₂ (fixed_isConst C x b) hRc)
  exact drops_four h x b P Q R R₂ hPQ (fun he => hRx (he ▸ hPx)) (by omega)
    (fun he => hRx (he ▸ hQx)) hQR₂ (by omega)
    (alias_of_user C x b hPx) (alias_of_user C x b hQx) (hF5P R hR) (hF5R R₂ hR₂)
    (h.not_dGate_of_multi x hx2 hPx) (h.not_dGate_of_multi x hx2 hQx)
    (h.not_dGate_of_primary_pred hP ha ha' hR)

end NonlinearTwoAux

/-- Case II with both operands of `T` read exactly twice (includes the calls to the tight
lemmas of packages J1/J2). -/
theorem case_nonlinear_two {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) {t : Table} {i j : Fin n} {rest : OpenCircuit (n + 1)}
    (hC : C = .gate t i j rest) (hnl : t.nonlinear = true) (hi : C.refCount i.val = 2)
    (hj : C.refCount j.val = 2) : ∃ x b, (x = i ∨ x = j) ∧ C.DropsAt x b 10 := by
  -- the first gate `T = n` reads `i` and `j`
  have hT : C.gateAt n = some (t, i.val, j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have hin := i.isLt
  have hjn := j.isLt
  have hij : i ≠ j := fun he => (h.gate_facts hT).2.1 (congrArg Fin.val he)
  have hij' : i.val ≠ j.val := fun he => hij (Fin.ext he)
  have hTi : n ∈ C.users i.val := C.mem_users.mpr ⟨t, i.val, j.val, hT, Or.inl rfl⟩
  have hTj : n ∈ C.users j.val := C.mem_users.mpr ⟨t, i.val, j.val, hT, Or.inr rfl⟩
  have hi2 : 2 ≤ C.refCount i.val := by omega
  have hj2 : 2 ≤ C.refCount j.val := by omega
  -- the second readers `U` of `i` and `V` of `j`
  obtain ⟨U, hUn, hUi⟩ := h.users_two i hi hTi
  obtain ⟨V, hVn, hVj⟩ := h.users_two j hj hTj
  have hUi' : U ∈ C.users i.val := by
    rw [hUi]
    exact Finset.mem_insert_of_mem (Finset.mem_singleton_self U)
  have hVj' : V ∈ C.users j.val := by
    rw [hVj]
    exact Finset.mem_insert_of_mem (Finset.mem_singleton_self V)
  obtain ⟨gV, vA, vB, hVg, -⟩ := C.mem_users.mp hVj'
  -- the `i`-step `ε` and the `j`-step `δ` make `T` constant
  obtain ⟨ε, hε, -⟩ := t.nonlinear_exists_blocksLeft hnl
  obtain ⟨δ, hδ, -⟩ := t.nonlinear_exists_blocksRight hnl
  have hTε : (C.resAt (singleRes i ε) n).isConst = true := by
    rw [C.resAt_gate _ hT, NonlinearTwoAux.resAt_fixed C i ε, Res.step_blocked_left t ε _ hε]
    rfl
  have hTδ : (C.resAt (singleRes j δ) n).isConst = true := by
    rw [C.resAt_gate _ hT, NonlinearTwoAux.resAt_fixed C j δ, Res.step_blocked_right t _ δ hδ]
    rfl
  -- `V` parity: the `j`-step, `E = {T, V, R₁}`
  by_cases hV5 : C.gatePsiW V = 5
  · exact ⟨j, δ, Or.inr rfl, NonlinearTwoAux.case_parity_reader h j δ hj2 (Ne.symm hVn) hTj
      hVj' hT hin hjn hTδ (Or.inl hV5)⟩
  have hVnl : (C.tableAt V).nonlinear = true := by
    rw [NonlinearTwoAux.tableAt_eq C hVg]
    exact NonlinearTwoAux.nonlinear_of_ne_five h hVg hV5
  -- from now on `x = i`
  suffices hsuff : ∃ b, C.DropsAt i b 10 by
    obtain ⟨b, hb⟩ := hsuff
    exact ⟨i, b, Or.inl rfl, hb⟩
  -- `U` parity: the `i`-step, `E = {T, U, R₁}`
  by_cases hU5 : C.gatePsiW U = 5
  · exact ⟨ε, NonlinearTwoAux.case_parity_reader h i ε hi2 (Ne.symm hUn) hTi hUi' hT hin hjn
      hTε (Or.inl hU5)⟩
  -- `U` constant under the `i`-step
  by_cases hUc' : (C.resAt (singleRes i ε) U).isConst = true
  · exact ⟨ε, NonlinearTwoAux.case_both_const h i ε hi2 (Ne.symm hUn) hTi hUi' hT hin hjn hTε
      hUc'⟩
  have hUc : (C.resAt (singleRes i ε) U).isConst = false := by simpa using hUc'
  -- `T` has at least two readers
  have hTb := C.gateAt_bounds hT
  obtain ⟨hTne, -⟩ := h.const_users i ε hTb.1 hTb.2.1 hTε
  by_cases hT2 : 1 < (C.users n).card
  · exact ⟨ε, NonlinearTwoAux.case_two_readers h i ε hi2 (Ne.symm hUn) hTi hUi' hT hin hjn hTε
      hT2⟩
  -- `T` has the single reader `R`
  obtain ⟨R, hR⟩ : ∃ R, C.users n = {R} := by
    apply Finset.card_eq_one.mp
    have := Finset.card_pos.mpr hTne
    omega
  have hRT : R ∈ C.users n := by
    rw [hR]
    exact Finset.mem_singleton_self R
  -- `R` constant under the `i`-step
  by_cases hRc' : (C.resAt (singleRes i ε) R).isConst = true
  · exact ⟨ε, NonlinearTwoAux.case_reader_const h i ε hi2 (Ne.symm hUn) hTi hUi' hT hin hjn
      hTε hRT hRc'⟩
  have hRc : (C.resAt (singleRes i ε) R).isConst = false := by simpa using hRc'
  -- the tight branch
  by_cases hUV : U = V
  · -- `U = V` reads `i` and `j`; the step `i := !ε` makes `U` constant
    have hUj : C.users j.val = {n, U} := by
      rw [hUV]
      exact hVj
    have hUj' : U ∈ C.users j.val := by
      rw [hUV]
      exact hVj'
    obtain ⟨g₀, a₀, b₀, hU₀, hab₀⟩ := NonlinearTwoAux.operands_of_two C hij' hUi' hUj'
    have hg₀ := NonlinearTwoAux.nonlinear_of_ne_five h hU₀ hU5
    have hUc₂ : (C.resAt (singleRes i (!ε)) U).isConst = true :=
      NonlinearTwoAux.const_flip C i j hij hU₀ hab₀ hg₀ ε hUc
    have ha₀ : a₀ < n := by
      rcases hab₀ with ⟨h1, -⟩ | ⟨h1, -⟩ <;> omega
    have hb₀ : b₀ < n := by
      rcases hab₀ with ⟨-, h1⟩ | ⟨-, h1⟩ <;> omega
    have hUout := h.out_ne_of_const i (!ε) hUc₂
    obtain ⟨-, hUn', hUs⟩ := NonlinearTwoAux.lt_of_mem_users C hUi'
    obtain ⟨hUne, -⟩ := h.const_users i (!ε) hUn' hUs hUc₂
    -- `U` has at least two readers
    by_cases hU2 : 1 < (C.users U).card
    · exact ⟨!ε, NonlinearTwoAux.case_two_readers h i (!ε) hi2 hUn hUi' hTi hU₀ ha₀ hb₀ hUc₂
        hU2⟩
    -- `U` has the single reader `S`
    obtain ⟨S, hS⟩ : ∃ S, C.users U = {S} := by
      apply Finset.card_eq_one.mp
      have := Finset.card_pos.mpr hUne
      omega
    have hSU : S ∈ C.users U := by
      rw [hS]
      exact Finset.mem_singleton_self S
    obtain ⟨gS, sA, sB, hSg, -⟩ := C.mem_users.mp hSU
    by_cases hS5 : C.gatePsiW S = 5
    · exact ⟨!ε, NonlinearTwoAux.case_parity_reader h i (!ε) hi2 hUn hUi' hTi hU₀ ha₀ hb₀ hUc₂
        (Or.inr ⟨S, hSU, hS5⟩)⟩
    have hSnl : (C.tableAt S).nonlinear = true := by
      rw [NonlinearTwoAux.tableAt_eq C hSg]
      exact NonlinearTwoAux.nonlinear_of_ne_five h hSg hS5
    exact ⟨ε, h.tight_equal i j hij U R S ε hUn hUi hUj hR hS hUout hTε hUc hRc hSnl⟩
  · exact ⟨ε, h.tight_distinct i j hij U V R ε hUn hVn hUV hUi hVj hR hTε hUc hRc hVnl⟩

end MAContext
end SatLowerBound
