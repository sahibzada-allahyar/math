import Credit.MainA.Parity
import Credit.MainA.Nonlinear

/-!
# Credit.MainA.Main: Main Lemma A (manuscript Lemma 4.6), assembled from the two cases
-/

namespace SatLowerBound
namespace MAContext

open OpenCircuit

/-- **Main Lemma A.**  Some essential input `x` and bit `b` lower `Ψ` by at least `10`
(without renormalizing the restricted circuit). -/
theorem main_lemma_A {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) : ∃ x b, Essential f x ∧ C.DropsAt x b 10 := by
  obtain ⟨t, i, j, rest, hC⟩ := h.exists_first_gate
  have hr := h.reduced
  rw [hC] at hr
  have hij : i ≠ j := hr.2.1
  have hte : t.essential = true := hr.1
  have hiu : 0 < C.usage (singleUse i) := by
    rw [C.usage_singleUse, hC]
    simp only [refCount, ↓reduceIte]
    omega
  have hju : 0 < C.usage (singleUse j) := by
    rw [C.usage_singleUse, hC]
    simp only [refCount, ↓reduceIte]
    omega
  have hie := h.usedEssential i hiu
  have hje := h.usedEssential j hju
  rcases t.essential_parity_or_nonlinear hte with hpar | hnl
  · have hfun : (OpenCircuit.gate t i j rest).eval = f := by
      rw [← hC]
      exact funext h.computes
    have hsep : PairSeparated (OpenCircuit.gate t i j rest).eval i j := by
      rw [hfun]
      exact h.good.s3 i j hij hie hje
    rcases OpenCircuit.first_gate_multiple_use t i j rest hij hsep with hu | hu
    · obtain ⟨b, hb⟩ := h.case_parity hC hpar i (Or.inl rfl)
        (by rw [← C.usage_singleUse, hC]; exact hu)
      exact ⟨i, b, hie, hb⟩
    · obtain ⟨b, hb⟩ := h.case_parity hC hpar j (Or.inr rfl)
        (by rw [← C.usage_singleUse, hC]; exact hu)
      exact ⟨j, b, hje, hb⟩
  · obtain ⟨x, b, hx, hb⟩ := h.case_nonlinear hC hnl
    rcases hx with rfl | rfl
    · exact ⟨_, b, hie, hb⟩
    · exact ⟨_, b, hje, hb⟩

end MAContext
end SatLowerBound
