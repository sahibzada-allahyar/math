import Credit.Forbid



namespace SatLowerBound

namespace OpenCircuit

theorem gained_of_keptIsD {n : Nat} (C : OpenCircuit n) (x : Fin n) (b : Bool) (z : Fin n)
    (hD : C.isD z.val = false) (hk : C.keptIsD (singleRes x b) z.val = true) :
    1 ≤ gainedCount C (C.restrict (singleSubst x b)) := by
  apply one_le_gainedCount C _ z _ hD
  rw [singleSubst_eq_fixSubst, (C.fix_transfer _ _).2.2.2 z]
  exact hk

end OpenCircuit

namespace MAContext

open OpenCircuit

variable {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}

theorem dGateSafe (h : MAContext f C) : C.DGateSafe :=
  forbid_a f C h.reduced h.computes h.good.e1 h.usedEssential

theorem distinct (h : MAContext f C) : C.DistinctOperands := C.reduced_distinct h.reduced

theorem exists_first_gate (h : MAContext f C) :
    ∃ (t : Table) (i j : Fin n) (rest : OpenCircuit (n + 1)), C = .gate t i j rest := by
  obtain ⟨x, y, hxy, hx, hy⟩ := h.good.two_essential
  have hfun : C.eval = f := funext h.computes
  have hpos := C.positive_size_of_two_essential x y hxy (by rw [hfun]; exact hx)
    (by rw [hfun]; exact hy)
  cases C with
  | output s => simp [OpenCircuit.size] at hpos
  | gate t i j rest => exact ⟨t, i, j, rest, rfl⟩

/-- The output is a gate (the function has two essential inputs). -/
theorem out_gate (h : MAContext f C) : ∃ k neg, C.outWire = some (k, neg) ∧ n ≤ k := by
  cases hw : C.outWire with
  | none =>
    exfalso
    obtain ⟨u, v, huv⟩ := h.good.nonconstant
    apply huv
    rw [← h.computes u, ← h.computes v]
    exact C.eval_const_of_outWire_none hw u v
  | some p =>
    obtain ⟨k, neg⟩ := p
    refine ⟨k, neg, rfl, ?_⟩
    by_contra hk'
    have hk : k < n := Nat.lt_of_not_le hk'
    obtain ⟨x, y, hxy, hx, hy⟩ := h.good.two_essential
    have key : ∀ z : Fin n, z.val ≠ k → ¬ Essential f z := by
      rintro z hz ⟨u, v, huv, hne⟩
      apply hne
      rw [← h.computes u, ← h.computes v, C.eval_of_outWire u hw, C.eval_of_outWire v hw]
      have hu : C.valueAt u k = u ⟨k, hk⟩ := C.valueAt_input u ⟨k, hk⟩
      have hv : C.valueAt v k = v ⟨k, hk⟩ := C.valueAt_input v ⟨k, hk⟩
      have hne' : (⟨k, hk⟩ : Fin n) ≠ z := fun he => hz (by rw [← he])
      rw [hu, hv, huv ⟨k, hk⟩ hne']
    by_cases hxk : x.val = k
    · exact key y (fun hyk => hxy (Fin.ext (hxk.trans hyk.symm))) hy
    · exact key x hxk hx

theorem outIs_input (h : MAContext f C) (z : Fin n) : C.outIs z.val = 0 := by
  obtain ⟨k, neg, hw, hk⟩ := h.out_gate
  have hz := z.isLt
  simp only [OpenCircuit.outIs, hw]
  split
  · omega
  · rfl

theorem refCount_input (h : MAContext f C) (z : Fin n) :
    C.refCount z.val = (C.users z.val).card := by
  rw [C.refCount_eq h.distinct, h.outIs_input z, Nat.add_zero]

theorem gate_facts (h : MAContext f C) {k : Nat} {g : Table} {a b : Nat}
    (hk : C.gateAt k = some (g, a, b)) :
    g.essential = true ∧ a ≠ b ∧ 1 ≤ C.refCount k ∧ n ≤ k ∧ k < n + C.size ∧ a < k ∧ b < k := by
  obtain ⟨h1, h2, h3⟩ := C.reduced_gate h.reduced hk
  obtain ⟨h4, h5, h6, h7⟩ := C.gateAt_bounds hk
  exact ⟨h1, h2, h3, h4, h5, h6, h7⟩

theorem psiW_ge (h : MAContext f C) {k : Nat} {g : Table} {a b : Nat}
    (hk : C.gateAt k = some (g, a, b)) :
    3 ≤ C.gatePsiW k ∧ (g.parity = true → C.gatePsiW k = 5) := by
  have he := (h.gate_facts hk).1
  simp only [OpenCircuit.gatePsiW, hk, g.psiW_essential he]
  refine ⟨by omega, fun hp => ?_⟩
  simp [Table.parityCount, hp]

/-- If an input has exactly two readers and one of them is gate `n`, name the other one. -/
theorem users_two (h : MAContext f C) (x : Fin n) (h2 : C.refCount x.val = 2)
    (hn : n ∈ C.users x.val) : ∃ U, U ≠ n ∧ C.users x.val = {n, U} := by
  rw [h.refCount_input x] at h2
  obtain ⟨a, b, hab, hset⟩ := Finset.card_eq_two.mp h2
  rw [hset] at hn ⊢
  rcases Finset.mem_insert.mp hn with ha | hb
  · refine ⟨b, fun hbn => hab (ha.symm.trans hbn.symm), ?_⟩
    rw [← ha]
  · rw [Finset.mem_singleton] at hb
    refine ⟨a, fun han => hab (han.trans hb), ?_⟩
    rw [← hb, Finset.pair_comm]

/-- F1: a direct successor of an input with at least two readers is not a D-gate. -/
theorem not_dGate_of_multi (h : MAContext f C) (x : Fin n) (h2 : 2 ≤ C.refCount x.val)
    {k : Nat} (hk : k ∈ C.users x.val) : C.isDGate k = false := by
  cases hd : C.isDGate k with
  | false => rfl
  | true =>
    exfalso
    obtain ⟨g, a, b, hg, hab⟩ := (C.isDGate_iff k).mp hd
    obtain ⟨g', a', b', hg', hx⟩ := C.mem_users.mp hk
    rw [hg] at hg'
    cases hg'
    have hsafe := h.dGateSafe
    have hnotD (s : Nat) (hs : C.isD s = true) (hsx : s = x.val) : False := by
      rw [hsx] at hs
      have := ((C.isD_iff x.val).mp hs).1
      omega
    rcases hab with ⟨ha, hDa⟩ | ⟨hb, hDb⟩
    · rcases hx with hax | hbx
      · exact hnotD a hDa hax
      · have hfa := (hsafe k g a b hg ha (by rw [hbx]; exact x.isLt)).1
        rw [hfa] at hDa
        contradiction
    · rcases hx with hax | hbx
      · have hfb := (hsafe k g a b hg (by rw [hax]; exact x.isLt) hb).2
        rw [hfb] at hDb
        contradiction
      · exact hnotD b hDb hbx

/-- F2: a direct successor of a gate with two primary operands is not a D-gate. -/
theorem not_dGate_of_primary_pred (h : MAContext f C) {k : Nat} {g : Table} {a b : Nat}
    (hk : C.gateAt k = some (g, a, b)) (ha : a < n) (hb : b < n) {k₂ : Nat}
    (hk₂ : k₂ ∈ C.users k) : C.isDGate k₂ = false :=
  forbid_b f C h.reduced h.computes h.good.e2 h.usedEssential hk ha hb hk₂

/-- F3: a gate that becomes constant is not a D-gate (if `x` is not a D-variable). -/
theorem not_dGate_of_const (h : MAContext f C) (x : Fin n) (b : Bool)
    (hx : C.isD x.val = false) {k : Nat} (hk : (C.resAt (singleRes x b) k).isConst = true) :
    C.isDGate k = false :=
  forbid_const f C h.computes h.good.e1 h.usedEssential x b hx hk

/-- F4: input-triangle freeness. -/
theorem no_triangle (h : MAContext f C) {x k k₂ : Nat} (hx : x < n) (hk : k ∈ C.users x)
    (hk₂ : k₂ ∈ C.users k) : k₂ ∉ C.users x :=
  C.noInputTriangles_flat h.noTriangles hx hk hk₂

/-- Connectivity: an essential input other than `x` keeps a non-constant direct successor. -/
theorem connected (h : MAContext f C) (x : Fin n) (b : Bool) (z : Fin n) (hzx : z ≠ x)
    (hz : 0 < C.refCount z.val) :
    ∃ k ∈ C.users z.val, (C.resAt (singleRes x b) k).isConst = false := by
  obtain ⟨k, neg, hw, hkn⟩ := h.out_gate
  apply OpenCircuit.connected f C h.computes h.good.e1 x b z hzx
  · exact h.usedEssential z (by rw [C.usage_singleUse]; exact hz)
  · intro k' neg' hw' heq
    rw [hw] at hw'
    cases hw'
    have := z.isLt
    omega

/-- A signal that becomes constant is not the output. -/
theorem out_ne_of_const (h : MAContext f C) (x : Fin n) (b : Bool) {k : Nat}
    (hc : (C.resAt (singleRes x b) k).isConst = true) :
    ∀ k' neg, C.outWire = some (k', neg) → k' ≠ k := by
  intro k' neg hw hkk
  rw [hkk] at hw
  obtain ⟨u, v, huv⟩ := h.good.cofactor_nonconstant x b
  apply huv
  show f (fixBit x b u) = f (fixBit x b v)
  have hk' := C.outWire_bound hw
  have hden (w : Fin n → Bool) : (C.resAt (singleRes x b) k).Denotes
      (C.valueAt (fixBit x b w)) (C.valueAt (fixBit x b w) k) := by
    apply C.resAt_sound (singleRes x b) (fixBit x b w) _ k hk'
    intro z
    apply C.fixRes_denotes
    intro z' hz'
    have hzx : z' = x := by simpa using hz'
    rw [hzx]
    simp [fixBit]
  cases hres : C.resAt (singleRes x b) k with
  | lit s neg' =>
    rw [hres] at hc
    simp [Res.isConst] at hc
  | const c =>
    have hu := hden u
    have hv := hden v
    rw [hres] at hu hv
    change C.valueAt (fixBit x b u) k = c at hu
    change C.valueAt (fixBit x b v) k = c at hv
    rw [← h.computes, ← h.computes, C.eval_of_outWire _ hw, C.eval_of_outWire _ hw, hu, hv]

/-- F5: a gate that becomes constant has a direct successor, and all its direct successors
are eliminated. -/
theorem const_users (h : MAContext f C) (x : Fin n) (b : Bool) {k : Nat} (hkn : n ≤ k)
    (hks : k < n + C.size) (hc : (C.resAt (singleRes x b) k).isConst = true) :
    (C.users k).Nonempty ∧ ∀ k₂ ∈ C.users k, C.isAliased (singleRes x b) k₂ = true := by
  constructor
  · obtain ⟨g, a, b', hg⟩ := C.gateAt_exists hkn hks
    have h1 := (h.gate_facts hg).2.2.1
    rw [C.refCount_eq h.distinct] at h1
    have hout : C.outIs k = 0 := by
      unfold OpenCircuit.outIs
      cases hw : C.outWire with
      | none => rfl
      | some p =>
        obtain ⟨k', neg⟩ := p
        simp only
        split
        · rename_i he
          exact absurd he (h.out_ne_of_const x b hc k' neg hw)
        · rfl
    rw [Finset.nonempty_iff_ne_empty]
    intro he
    rw [he, Finset.card_empty] at h1
    omega
  · intro k₂ hk₂
    obtain ⟨g₂, a₂, b₂, hg₂, hab⟩ := C.mem_users.mp hk₂
    apply C.isAliased_of_const _ hg₂
    rcases hab with rfl | rfl
    · exact Or.inl hc
    · exact Or.inr hc

/-- The charging lemma for one fixed input: eliminated gates `E`, plus `gain` new D-variables. -/
theorem drops (h : MAContext f C) (x : Fin n) (b : Bool) (E : Finset Nat)
    (hE : ∀ k ∈ E, C.isAliased (singleRes x b) k = true) (gain : Nat)
    (hgain : gain ≤ gainedCount C (C.restrict (singleSubst x b))) (d : Int)
    (hd : d ≤ ((∑ k ∈ E, C.gatePsiW k : Nat) : Int) -
        ((E.filter (fun k => C.isDGate k = true)).card : Int) + gain) :
    C.DropsAt x b d := by
  have hc := C.psi_restrict_charge h.dGateSafe (fun z => decide (z = x)) (fun _ => b) E hE
  unfold OpenCircuit.DropsAt
  rw [singleSubst_eq_fixSubst] at hgain ⊢
  omega

end MAContext

/-! ### Package G: helpers for `funnel_not_separated`

They use only the definitions of `users`/`usesAt` and the proved flat lemmas `gateAt_bounds`,
`gateAt_exists`, `valueAt_input`, `valueAt_gate`, so package G depends on no open lemma. -/

namespace FunnelAux

/-- A gate one of whose operands is `s` is a user of `s`. -/
private theorem mem_users_of_gateAt {n : Nat} (C : OpenCircuit n) {k : Nat} {g : Table}
    {a b : Nat} (hk : C.gateAt k = some (g, a, b)) {s : Nat} (hs : a = s ∨ b = s) :
    k ∈ C.users s := by
  have hus : C.usesAt k s = true := by
    unfold OpenCircuit.usesAt
    rw [hk]
    rcases hs with hs | hs <;> simp [hs]
  exact Finset.mem_filter.mpr ⟨Finset.mem_range.mpr (C.gateAt_bounds hk).2.1, hus⟩

/-- A user of `s` is a gate one of whose operands is `s`. -/
private theorem gateAt_of_mem_users {n : Nat} (C : OpenCircuit n) {k s : Nat}
    (hk : k ∈ C.users s) : ∃ g a b, C.gateAt k = some (g, a, b) ∧ (a = s ∨ b = s) := by
  have hu : C.usesAt k s = true := (Finset.mem_filter.mp hk).2
  unfold OpenCircuit.usesAt at hu
  cases hg : C.gateAt k with
  | none => simp [hg] at hu
  | some p =>
    obtain ⟨g, a, b⟩ := p
    exact ⟨g, a, b, rfl, by simpa [hg] using hu⟩

/-- A gate reading two distinct signals `s` and `t` reads nothing else, so its value is
determined by theirs. -/
private theorem value_eq_of_reads_two {n : Nat} (C : OpenCircuit n) {k s t : Nat}
    (hst : s ≠ t) (hks : k ∈ C.users s) (hkt : k ∈ C.users t) (u w : Fin n → Bool)
    (hs : C.valueAt u s = C.valueAt w s) (ht : C.valueAt u t = C.valueAt w t) :
    C.valueAt u k = C.valueAt w k := by
  obtain ⟨g, a, b, hg, has⟩ := gateAt_of_mem_users C hks
  obtain ⟨g', a', b', hg', hat⟩ := gateAt_of_mem_users C hkt
  rw [hg] at hg'
  simp only [Option.some.injEq, Prod.mk.injEq] at hg'
  obtain ⟨-, ha, hb⟩ := hg'
  rw [← ha, ← hb] at hat
  have hval : ∀ o, (o = s ∨ o = t) → C.valueAt u o = C.valueAt w o := by
    intro o ho
    rcases ho with ho | ho
    · rw [ho]
      exact hs
    · rw [ho]
      exact ht
  rw [C.valueAt_gate u hg, C.valueAt_gate w hg, hval a (by omega), hval b (by omega)]

/-- Funnel configuration: `x, y` are read only by `T, U`, and `T, U` only by `R`.  Then, away
from `x, y, T, U`, every signal value is determined by the inputs other than `x, y` together
with the value of `R`. -/
private theorem funnel_values_agree {n : Nat} (C : OpenCircuit n) (x y : Fin n) (T U R : Nat)
    (hux : ∀ k ∈ C.users x.val, k = T ∨ k = U) (huy : ∀ k ∈ C.users y.val, k = T ∨ k = U)
    (hTR : ∀ k ∈ C.users T, k = R) (hUR : ∀ k ∈ C.users U, k = R)
    (u w : Fin n → Bool) (huw : ∀ z : Fin n, z ≠ x → z ≠ y → u z = w z)
    (hR : C.valueAt u R = C.valueAt w R) :
    ∀ k, k < n + C.size → k ≠ x.val → k ≠ y.val → k ≠ T → k ≠ U →
      C.valueAt u k = C.valueAt w k := by
  intro k
  induction k using Nat.strong_induction_on with
  | h k ih =>
    intro hks hkx hky hkT hkU
    by_cases hkR : k = R
    · rw [hkR]
      exact hR
    by_cases hkn : k < n
    · have h1 : C.valueAt u k = u ⟨k, hkn⟩ := C.valueAt_input u ⟨k, hkn⟩
      have h2 : C.valueAt w k = w ⟨k, hkn⟩ := C.valueAt_input w ⟨k, hkn⟩
      rw [h1, h2]
      exact huw ⟨k, hkn⟩ (fun he => hkx (congrArg Fin.val he))
        (fun he => hky (congrArg Fin.val he))
    obtain ⟨g, a, b, hg⟩ := C.gateAt_exists (by omega) hks
    obtain ⟨-, -, hak, hbk⟩ := C.gateAt_bounds hg
    have hop : ∀ o, (a = o ∨ b = o) → o < k → C.valueAt u o = C.valueAt w o := by
      intro o ho hok
      have hmem : k ∈ C.users o := mem_users_of_gateAt C hg ho
      refine ih o hok (by omega) ?_ ?_ ?_ ?_
      · intro hox
        rw [hox] at hmem
        rcases hux k hmem with h' | h'
        · exact hkT h'
        · exact hkU h'
      · intro hoy
        rw [hoy] at hmem
        rcases huy k hmem with h' | h'
        · exact hkT h'
        · exact hkU h'
      · intro hoT
        rw [hoT] at hmem
        exact hkR (hTR k hmem)
      · intro hoU
        rw [hoU] at hmem
        exact hkR (hUR k hmem)
    rw [C.valueAt_gate u hg, C.valueAt_gate w hg, hop a (Or.inl rfl) hak,
      hop b (Or.inr rfl) hbk]

end FunnelAux

namespace MAContext

open OpenCircuit

variable {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}

/-- (S3) contradiction for the funnel configuration of the tight branch: if `x` and `y` feed
only `T` and `U`, and `T` and `U` feed only `R`, all dependence on `(x, y)` passes through the
single signal `R`. -/
theorem funnel_not_separated (h : MAContext f C) (x y : Fin n) (hxy : x ≠ y) (T U R : Nat)
    (hTU : T ≠ U) (_hT : n ≤ T) (_hU : n ≤ U)
    (hux : C.users x.val = {T, U}) (huy : C.users y.val = {T, U})
    (hRT : C.users T = {R}) (hRU : C.users U = {R})
    (hout : ∀ k neg, C.outWire = some (k, neg) → k ≠ T ∧ k ≠ U) :
    ¬ PairSeparated f x y := by
  intro hsep
  have hxy' : x.val ≠ y.val := fun he => hxy (Fin.ext he)
  have hpair (s : Nat) (hs : C.users s = {T, U}) :
      (∀ k ∈ C.users s, k = T ∨ k = U) ∧ T ∈ C.users s ∧ U ∈ C.users s := by
    rw [hs]
    refine ⟨fun k hk => ?_, Finset.mem_insert_self T {U},
      Finset.mem_insert_of_mem (Finset.mem_singleton_self U)⟩
    rw [Finset.mem_insert, Finset.mem_singleton] at hk
    exact hk
  have hsingle (s : Nat) (hs : C.users s = {R}) :
      (∀ k ∈ C.users s, k = R) ∧ R ∈ C.users s := by
    rw [hs]
    exact ⟨fun k hk => Finset.mem_singleton.mp hk, Finset.mem_singleton_self R⟩
  obtain ⟨hxonly, hTx, hUx⟩ := hpair x.val hux
  obtain ⟨hyonly, hTy, hUy⟩ := hpair y.val huy
  obtain ⟨hTonly, hRT'⟩ := hsingle T hRT
  obtain ⟨hUonly, hRU'⟩ := hsingle U hRU
  -- `T` and `U` read exactly `x` and `y`, and `R` reads exactly `T` and `U`: the value of `R`
  -- depends only on the values of `x` and `y`.
  have hRdep : ∀ u w : Fin n → Bool, u x = w x → u y = w y →
      C.valueAt u R = C.valueAt w R := by
    intro u w hx hy
    have hx' : C.valueAt u x.val = C.valueAt w x.val := by
      rw [C.valueAt_input, C.valueAt_input]
      exact hx
    have hy' : C.valueAt u y.val = C.valueAt w y.val := by
      rw [C.valueAt_input, C.valueAt_input]
      exact hy
    exact FunnelAux.value_eq_of_reads_two C hTU hRT' hRU' u w
      (FunnelAux.value_eq_of_reads_two C hxy' hTx hTy u w hx' hy')
      (FunnelAux.value_eq_of_reads_two C hxy' hUx hUy u w hx' hy')
  obtain ⟨G, hG⟩ : ∃ G : Bool → Bool → Bool,
      ∀ v a b, C.valueAt (setPair v x y a b) R = G a b := by
    refine ⟨fun a b => C.valueAt (setPair (fun _ => false) x y a b) R, fun v a b => ?_⟩
    apply hRdep
    · rw [setPair_left, setPair_left]
    · rw [setPair_right _ _ _ _ _ hxy, setPair_right _ _ _ _ _ hxy]
  -- The output is a gate outside `{x, y, T, U}`, so `f` factors through `G`.
  obtain ⟨k, neg, hw, hkn⟩ := h.out_gate
  obtain ⟨hkT, hkU⟩ := hout k neg hw
  have hks := C.outWire_bound hw
  have hkx : k ≠ x.val := by
    have := x.isLt
    omega
  have hky : k ≠ y.val := by
    have := y.isLt
    omega
  have hfac : ∀ v a b a' b', G a b = G a' b' →
      f (setPair v x y a b) = f (setPair v x y a' b') := by
    intro v a b a' b' hGG
    have e1 := h.computes (setPair v x y a b)
    have e2 := h.computes (setPair v x y a' b')
    rw [C.eval_of_outWire _ hw] at e1
    rw [C.eval_of_outWire _ hw] at e2
    rw [← e1, ← e2, FunnelAux.funnel_values_agree C x y T U R hxonly hyonly hTonly hUonly
      (setPair v x y a b) (setPair v x y a' b') (fun z hzx hzy => by simp [setPair, hzx, hzy])
      (by rw [hG, hG, hGG]) k hks hkx hky hkT hkU]
  refine no_single_signal _ hsep ⟨G, fun ζ v => f (setPair v x y
    (Classical.epsilon (fun p : Bool × Bool => G p.1 p.2 = ζ)).1
    (Classical.epsilon (fun p : Bool × Bool => G p.1 p.2 = ζ)).2), ?_⟩
  intro a b v
  have hspec : G (Classical.epsilon (fun p : Bool × Bool => G p.1 p.2 = G a b)).1
      (Classical.epsilon (fun p : Bool × Bool => G p.1 p.2 = G a b)).2 = G a b :=
    Classical.epsilon_spec (p := fun p : Bool × Bool => G p.1 p.2 = G a b) ⟨(a, b), rfl⟩
  exact hfac v a b _ _ hspec.symm

end MAContext
end SatLowerBound
