import Credit.MainA.NonlinearDeg
import Credit.MainA.NonlinearTwo

/-!
# Credit.MainA.Nonlinear: case II of Main Lemma A, assembled from packages I1 and I2
-/

namespace SatLowerBound
namespace MAContext

open OpenCircuit

theorem case_nonlinear {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) {t : Table} {i j : Fin n} {rest : OpenCircuit (n + 1)}
    (hC : C = .gate t i j rest) (hnl : t.nonlinear = true) :
    ∃ x b, (x = i ∨ x = j) ∧ C.DropsAt x b 10 := by
  obtain ⟨hi2, hj2⟩ := h.degrees_of_nonlinear hC hnl
  by_cases hi3 : 3 ≤ C.refCount i.val
  · obtain ⟨b, hb⟩ := h.case_nonlinear_three hC hnl i (Or.inl rfl) hi3
    exact ⟨i, b, Or.inl rfl, hb⟩
  · by_cases hj3 : 3 ≤ C.refCount j.val
    · obtain ⟨b, hb⟩ := h.case_nonlinear_three hC hnl j (Or.inr rfl) hj3
      exact ⟨j, b, Or.inr rfl, hb⟩
    · exact h.case_nonlinear_two hC hnl (by omega) (by omega)

end MAContext
end SatLowerBound
