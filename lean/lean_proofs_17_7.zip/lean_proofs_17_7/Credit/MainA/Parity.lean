import Credit.MainA.Toolkit



namespace SatLowerBound
namespace MAContext

open OpenCircuit

theorem case_parity {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}
    (h : MAContext f C) {t : Table} {i j : Fin n} {rest : OpenCircuit (n + 1)}
    (hC : C = .gate t i j rest) (hpar : t.parity = true) (x : Fin n) (hx : x = i ∨ x = j)
    (h2 : 2 ≤ C.refCount x.val) : ∃ b, C.DropsAt x b 10 := by
  -- the first gate `T = n` reads `x`
  have hT : C.gateAt n = some (t, i.val, j.val) := by
    rw [hC]
    exact gateAt_head t i j rest
  have h5 : C.gatePsiW n = 5 := (h.psiW_ge hT).2 hpar
  have hTx : n ∈ C.users x.val := by
    rw [C.mem_users]
    refine ⟨t, i.val, j.val, hT, ?_⟩
    rcases hx with hx | hx
    · rw [hx]
      exact Or.inl rfl
    · rw [hx]
      exact Or.inr rfl
  -- `x` itself resolves to the constant `b`, so every reader of `x` is eliminated
  have hxres : ∀ b : Bool, C.resAt (singleRes x b) x.val = .const b := by
    intro b
    rw [C.resAt_single_input x b x]
    simp
  have halias : ∀ b : Bool, ∀ k ∈ C.users x.val, C.isAliased (singleRes x b) k = true := by
    intro b k hk
    obtain ⟨g, a, a', hg, hax⟩ := C.mem_users.mp hk
    apply C.isAliased_of_const _ hg
    rcases hax with hax | hax
    · left
      rw [hax, hxres b]
      rfl
    · right
      rw [hax, hxres b]
      rfl
  have hcard : 2 ≤ (C.users x.val).card := by
    rw [← h.refCount_input x]
    exact h2
  by_cases hall : ∀ k ∈ C.users x.val, C.gatePsiW k = 5
  · -- all readers of `x` are parity gates: `E = users x`
    refine ⟨false, h.drops x false (C.users x.val) (halias false) 0 (Nat.zero_le _) 10 ?_⟩
    have hsum : ∑ k ∈ C.users x.val, C.gatePsiW k = (C.users x.val).card * 5 :=
      Finset.sum_const_nat hall
    have hfil : ((C.users x.val).filter (fun k => C.isDGate k = true)).card = 0 := by
      rw [Finset.card_eq_zero]
      apply Finset.filter_false_of_mem
      intro k hk
      rw [h.not_dGate_of_multi x h2 hk]
      exact Bool.false_ne_true
    rw [hsum, hfil]
    omega
  · -- a reader `P` of `x` that is not a parity gate
    obtain ⟨P, hP, hP5⟩ : ∃ P ∈ C.users x.val, C.gatePsiW P ≠ 5 := by
      by_contra hne
      apply hall
      intro k hk
      by_contra hk5
      exact hne ⟨k, hk, hk5⟩
    obtain ⟨g, a, a', hgP, hax⟩ := C.mem_users.mp hP
    have hPn : P ≠ n := by
      intro hPn
      rw [hPn] at hP5
      exact hP5 h5
    have hgnl : g.nonlinear = true := by
      rcases g.essential_parity_or_nonlinear (h.gate_facts hgP).1 with hp | hp
      · exact absurd ((h.psiW_ge hgP).2 hp) hP5
      · exact hp
    -- fix `x` to the value blocking `P`: `P` becomes constant
    obtain ⟨b, hbc⟩ : ∃ b, (C.resAt (singleRes x b) P).isConst = true := by
      rcases hax with hax | hax
      · obtain ⟨b, hb, -⟩ := g.nonlinear_exists_blocksLeft hgnl
        refine ⟨b, ?_⟩
        rw [C.resAt_gate _ hgP, hax, hxres b, Res.step_blocked_left g b _ hb]
        rfl
      · obtain ⟨b, hb, -⟩ := g.nonlinear_exists_blocksRight hgnl
        refine ⟨b, ?_⟩
        rw [C.resAt_gate _ hgP, hax, hxres b, Res.step_blocked_right g _ b hb]
        rfl
    have hPb := C.gateAt_bounds hgP
    -- `P` has a reader `P₂`, which is eliminated (F5)
    obtain ⟨⟨P₂, hP₂⟩, hP₂al⟩ := h.const_users x b hPb.1 hPb.2.1 hbc
    obtain ⟨g₂, c₁, c₂, hg₂, hc⟩ := C.mem_users.mp hP₂
    have hP₂b := C.gateAt_bounds hg₂
    have hPP₂ : P < P₂ := by omega
    have hnP : n ∉ ({P, P₂} : Finset Nat) := by
      simp only [Finset.mem_insert, Finset.mem_singleton]
      omega
    have hPP : P ∉ ({P₂} : Finset Nat) := by
      simp only [Finset.mem_singleton]
      omega
    refine ⟨b, h.drops x b {n, P, P₂} ?_ 0 (Nat.zero_le _) 10 ?_⟩
    · intro k hk
      simp only [Finset.mem_insert, Finset.mem_singleton] at hk
      rcases hk with hk | hk | hk
      · rw [hk]
        exact halias b n hTx
      · rw [hk]
        exact halias b P hP
      · rw [hk]
        exact hP₂al P₂ hP₂
    · have hsum : ∑ k ∈ ({n, P, P₂} : Finset Nat), C.gatePsiW k =
          C.gatePsiW n + (C.gatePsiW P + C.gatePsiW P₂) := by
        rw [Finset.sum_insert hnP, Finset.sum_insert hPP, Finset.sum_singleton]
      have hsub : ({n, P, P₂} : Finset Nat).filter (fun k => C.isDGate k = true) ⊆ {P₂} := by
        intro k hk
        rw [Finset.mem_filter] at hk
        obtain ⟨hkE, hkD⟩ := hk
        simp only [Finset.mem_insert, Finset.mem_singleton] at hkE
        rcases hkE with hk | hk | hk
        · rw [hk, h.not_dGate_of_multi x h2 hTx] at hkD
          exact absurd hkD Bool.false_ne_true
        · rw [hk, h.not_dGate_of_multi x h2 hP] at hkD
          exact absurd hkD Bool.false_ne_true
        · rw [hk]
          exact Finset.mem_singleton_self P₂
      have hfil := Finset.card_le_card hsub
      rw [Finset.card_singleton] at hfil
      have h3P := (h.psiW_ge hgP).1
      have h3P₂ := (h.psiW_ge hg₂).1
      rw [hsum]
      omega

end MAContext
end SatLowerBound
