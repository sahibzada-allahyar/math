import Credit.Basic

/-!
# Credit.ResLemmas: elementary facts about truth tables and `Res.step`

Pure, finite case analyses.  No circuit appears here.
-/

namespace SatLowerBound

namespace Table

theorem nonlinear_blocksLeft (g : Table) (h : g.nonlinear = true) :
    g.blocksLeft true = !g.blocksLeft false := by
  revert h
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem nonlinear_blocksRight (g : Table) (h : g.nonlinear = true) :
    g.blocksRight true = !g.blocksRight false := by
  revert h
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem nonlinear_exists_blocksLeft (g : Table) (h : g.nonlinear = true) :
    ∃ a, g.blocksLeft a = true ∧ g.blocksLeft (!a) = false := by
  have hb := g.nonlinear_blocksLeft h
  cases hf : g.blocksLeft false
  · exact ⟨true, by rw [hb, hf]; rfl, hf⟩
  · exact ⟨false, hf, by simpa [hf] using hb⟩

theorem nonlinear_exists_blocksRight (g : Table) (h : g.nonlinear = true) :
    ∃ b, g.blocksRight b = true ∧ g.blocksRight (!b) = false := by
  have hb := g.nonlinear_blocksRight h
  cases hf : g.blocksRight false
  · exact ⟨true, by rw [hb, hf]; rfl, hf⟩
  · exact ⟨false, hf, by simpa [hf] using hb⟩

theorem parity_not_blocksLeft (g : Table) (h : g.parity = true) (a : Bool) :
    g.blocksLeft a = false := by
  revert h a
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem parity_not_blocksRight (g : Table) (h : g.parity = true) (b : Bool) :
    g.blocksRight b = false := by
  revert h b
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

/-- The constant produced by blocking a nonlinear gate is the same on both sides. -/
theorem nonlinear_blocked_value (g : Table) (h : g.nonlinear = true) (a b : Bool)
    (ha : g.blocksLeft a = true) (hb : g.blocksRight b = true) :
    g.eval a false = g.eval false b := by
  revert h a b
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

/-- An essential table attains every output value. -/
theorem essential_attains (g : Table) (h : g.essential = true) (v : Bool) :
    ∃ a b, g.eval a b = v := by
  revert h v
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem blocksLeft_eval (g : Table) (a : Bool) (h : g.blocksLeft a = true) (b : Bool) :
    g.eval a b = g.eval a false := by
  have he : g.eval a false = g.eval a true := by simpa [blocksLeft] using h
  cases b
  · rfl
  · exact he.symm

theorem blocksRight_eval (g : Table) (b : Bool) (h : g.blocksRight b = true) (a : Bool) :
    g.eval a b = g.eval false b := by
  have he : g.eval false b = g.eval true b := by simpa [blocksRight] using h
  cases a
  · rfl
  · exact he.symm

theorem essential_not_degenerate (g : Table) (h : g.essential = true) :
    ¬ (g.ff = g.tf ∧ g.ft = g.tt) ∧ ¬ (g.ff = g.ft ∧ g.tf = g.tt) := by
  revert h
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem eval_of_left_degenerate (g : Table) (h : g.ff = g.tf ∧ g.ft = g.tt) (x y : Bool) :
    g.eval x y = g.eval false y := by
  rcases g with ⟨a, b, c, d⟩
  obtain ⟨h1, h2⟩ := h
  cases x <;> cases y <;> simp_all [eval]

theorem eval_of_right_degenerate (g : Table) (h : g.ff = g.ft ∧ g.tf = g.tt) (x y : Bool) :
    g.eval x y = g.eval x false := by
  rcases g with ⟨a, b, c, d⟩
  obtain ⟨h1, h2⟩ := h
  cases x <;> cases y <;> simp_all [eval]

end Table

theorem twist_eval (g : Table) (a b x y : Bool) :
    (twist g a b).eval x y = g.eval (Bool.xor x a) (Bool.xor y b) :=
  Table.eval_ofFunction _ _ _

namespace Res

/-- `r` describes the Boolean value `v` relative to the source values `val`. -/
def Denotes (val : Nat → Bool) : Res → Bool → Prop
  | .const c, v => v = c
  | .lit s neg, v => v = Bool.xor (val s) neg

theorem unary_denotes (f : Bool → Bool) (s : Nat) (val : Nat → Bool) :
    (unary f s).Denotes val (f (val s)) := by
  unfold unary
  split
  · rename_i h
    change f (val s) = f false
    cases hv : val s
    · rfl
    · exact h.symm
  · rename_i h
    change f (val s) = Bool.xor (val s) (f false)
    cases hv : val s
    · simp
    · cases h0 : f false <;> cases h1 : f true <;> simp_all

theorem step_sound (g : Table) (r₁ r₂ r : Res) (h : step g r₁ r₂ = some r)
    (val : Nat → Bool) (a b : Bool) (ha : r₁.Denotes val a) (hb : r₂.Denotes val b) :
    r.Denotes val (g.eval a b) := by
  cases r₁ with
  | const a' =>
    change a = a' at ha
    subst ha
    cases r₂ with
    | const b' =>
      change b = b' at hb
      subst hb
      simp only [step, Option.some.injEq] at h
      subst h
      rfl
    | lit j nb =>
      change b = Bool.xor (val j) nb at hb
      subst hb
      simp only [step, Option.some.injEq] at h
      subst h
      exact unary_denotes (fun y => g.eval a (Bool.xor y nb)) j val
  | lit i na =>
    change a = Bool.xor (val i) na at ha
    subst ha
    cases r₂ with
    | const b' =>
      change b = b' at hb
      subst hb
      simp only [step, Option.some.injEq] at h
      subst h
      exact unary_denotes (fun x => g.eval (Bool.xor x na) b) i val
    | lit j nb =>
      change b = Bool.xor (val j) nb at hb
      subst hb
      simp only [step] at h
      split at h
      · rename_i hij
        subst hij
        simp only [Option.some.injEq] at h
        subst h
        exact unary_denotes (fun x => g.eval (Bool.xor x na) (Bool.xor x nb)) i val
      · split at h
        · rename_i hd
          simp only [Option.some.injEq] at h
          subst h
          have hu := unary_denotes (fun y => (twist g na nb).eval false y) j val
          have he : (twist g na nb).eval false (val j) = g.eval (Bool.xor (val i) na)
              (Bool.xor (val j) nb) := by
            rw [← Table.eval_of_left_degenerate _ hd (val i) (val j), twist_eval]
          rw [he] at hu
          exact hu
        · split at h
          · rename_i _ hd
            simp only [Option.some.injEq] at h
            subst h
            have hu := unary_denotes (fun x => (twist g na nb).eval x false) i val
            have he : (twist g na nb).eval (val i) false = g.eval (Bool.xor (val i) na)
                (Bool.xor (val j) nb) := by
              rw [← Table.eval_of_right_degenerate _ hd (val i) (val j), twist_eval]
            rw [he] at hu
            exact hu
          · contradiction

theorem step_const_left_isSome (g : Table) (a : Bool) (r : Res) :
    (step g (.const a) r).isSome = true := by
  cases r <;> rfl

theorem step_const_right_isSome (g : Table) (r : Res) (b : Bool) :
    (step g r (.const b)).isSome = true := by
  cases r <;> rfl

theorem step_blocked_left (g : Table) (a : Bool) (r : Res) (h : g.blocksLeft a = true) :
    step g (.const a) r = some (.const (g.eval a false)) := by
  cases r with
  | const b => simp only [step, g.blocksLeft_eval a h b]
  | lit j nb =>
    simp only [step, unary, g.blocksLeft_eval a h, ↓reduceIte]

theorem step_blocked_right (g : Table) (r : Res) (b : Bool) (h : g.blocksRight b = true) :
    step g r (.const b) = some (.const (g.eval false b)) := by
  cases r with
  | const a => simp only [step, g.blocksRight_eval b h a]
  | lit i na =>
    simp only [step, unary, g.blocksRight_eval b h, ↓reduceIte]

theorem step_unblocked_left (g : Table) (a : Bool) (s : Nat) (ns : Bool)
    (h : g.blocksLeft a = false) : ∃ neg, step g (.const a) (.lit s ns) = some (.lit s neg) := by
  have hne : g.eval a false ≠ g.eval a true := by simpa [Table.blocksLeft] using h
  refine ⟨g.eval a (Bool.xor false ns), ?_⟩
  simp only [step, unary]
  split
  · exfalso
    apply hne
    cases ns <;> simp_all
  · rfl

theorem step_unblocked_right (g : Table) (i : Nat) (ni : Bool) (b : Bool)
    (h : g.blocksRight b = false) : ∃ neg, step g (.lit i ni) (.const b) = some (.lit i neg) := by
  have hne : g.eval false b ≠ g.eval true b := by simpa [Table.blocksRight] using h
  refine ⟨g.eval (Bool.xor false ni) b, ?_⟩
  simp only [step, unary]
  split
  · exfalso
    apply hne
    cases ni <;> simp_all
  · rfl

theorem step_kept (g : Table) (hg : g.essential = true) (s t : Nat) (hst : s ≠ t)
    (ns nt : Bool) : step g (.lit s ns) (.lit t nt) = none := by
  have hd := (twist g ns nt).essential_not_degenerate (by rw [twist_essential]; exact hg)
  simp only [step, hst, ↓reduceIte, hd.1, hd.2]

theorem step_same_isSome (g : Table) (s : Nat) (n₁ n₂ : Bool) :
    (step g (.lit s n₁) (.lit s n₂)).isSome = true := by
  simp [step]

theorem unary_hits (f : Bool → Bool) (s t : Nat) (h : (unary f s).hits t = true) : s = t := by
  unfold unary at h
  split at h
  · simp [hits] at h
  · simpa [hits] using h

theorem step_hits (g : Table) (r₁ r₂ : Res) (t : Nat) (r : Res) (h : step g r₁ r₂ = some r)
    (hr : r.hits t = true) : r₁.hits t = true ∨ r₂.hits t = true := by
  cases r₁ with
  | const a =>
    cases r₂ with
    | const b =>
      simp only [step, Option.some.injEq] at h
      subst h
      simp [hits] at hr
    | lit j nb =>
      simp only [step, Option.some.injEq] at h
      subst h
      right
      simpa [hits] using unary_hits _ _ _ hr
  | lit i na =>
    cases r₂ with
    | const b =>
      simp only [step, Option.some.injEq] at h
      subst h
      left
      simpa [hits] using unary_hits _ _ _ hr
    | lit j nb =>
      simp only [step] at h
      split at h
      · simp only [Option.some.injEq] at h
        subst h
        left
        simpa [hits] using unary_hits _ _ _ hr
      · split at h
        · simp only [Option.some.injEq] at h
          subst h
          right
          simpa [hits] using unary_hits _ _ _ hr
        · split at h
          · simp only [Option.some.injEq] at h
            subst h
            left
            simpa [hits] using unary_hits _ _ _ hr
          · contradiction

theorem hits_lit (s t : Nat) (neg : Bool) : (Res.lit s neg).hits t = true ↔ s = t := by
  simp [hits]

theorem hits_const (b : Bool) (t : Nat) : (Res.const b).hits t = false := rfl

end Res
end SatLowerBound
