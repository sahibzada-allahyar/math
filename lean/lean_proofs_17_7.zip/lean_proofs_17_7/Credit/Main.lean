import Credit.Assembly

/-!
# Credit.Main: the 12/5 certificate (Theorem 1.1 of `binary_3sat_twelve_fifths.tex`)

`C ≥ n + ⌈((21r - 72) M_r - 5)/5⌉`, stated without division.
-/

namespace SatLowerBound

/-- The exact finite 12/5 certificate. -/
def ExactCertificate125 : Prop :=
  ∀ (w r : Nat), 8 ≤ w → 4 ≤ r → r < w →
    ∀ C : Circuit (inputBits w), C.Computes (satFunction w) →
      5 * inputBits w + (21 * r - 72) * remainingClauses w r ≤ 5 * C.size + 5

theorem main_lower_bound_125 : ExactCertificate125 := by
  intro w r hw hr4 hr C hc
  exact certificate_of_psi w r hw hr4 hr (psi_sparse_bound w r hr4 hr) C hc

/-- Theorem 1.1 on the manuscript's full range, `4 ≤ r < w`.
This does not assume the stronger `8 ≤ w` used in `ExactCertificate125`. -/
theorem main_lower_bound_125_full_range (w r : Nat) (hr4 : 4 ≤ r) (hr : r < w)
    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    5 * inputBits w + (21 * r - 72) * remainingClauses w r ≤ 5 * C.size + 5 := by
  obtain ⟨D, hD, hdel⟩ := sat_sparse_transfer w r (by omega) hr (by omega) C hc
  have hsize := sparse_size_of_psi w r (by omega) (psi_sparse_bound w r hr4 hr) D hD
  have hL := freeBits_le_inputBits w r hr
  have hdim : freeBits w r = 3 * (r * remainingClauses w r) := by
    rw [freeBits_eq, Nat.mul_assoc, Nat.mul_comm (remainingClauses w r) r]
  have hcharge : (21 * r - 72) * remainingClauses w r + 72 * remainingClauses w r =
      21 * (r * remainingClauses w r) := by
    rw [← Nat.add_mul, Nat.sub_add_cancel (by omega : 72 ≤ 21 * r), Nat.mul_assoc]
  omega

end SatLowerBound
