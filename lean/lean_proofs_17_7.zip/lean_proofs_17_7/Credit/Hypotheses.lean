import Credit.Basic

/-!
# Credit.Hypotheses: (E1), (E2), (S3) for modular compositions (manuscript Lemma 4.1)

Complete proofs, from the 7/3 development's `ModularTree` lemmas.
-/

namespace SatLowerBound
namespace ModularTree

theorem valid_inputs_ge {n k : Nat} (T : ModularTree n) (h : T.Valid k) : k ≤ T.inputs := by
  induction T with
  | leaf S t c => exact h
  | branch p a b iha ihb =>
    have := iha h.1
    simp only [inputs]
    omega

theorem restrict_essential_mem {n : Nat} (T : ModularTree n) (h : T.Valid 3) (x : Fin n)
    (b : Bool) (z : Fin n) (hzx : z ≠ x) (hz : z ∈ T.support) :
    Essential (fun v => T.eval (fixBit x b v)) z := by
  have hv := T.restrict_valid x b h
  have hmem : z ∈ (T.restrict x b).support := by
    rw [restrict_support]
    exact Finset.mem_erase.mpr ⟨hzx, hz⟩
  have he := (T.restrict x b).essential hv z hmem
  have hfun : (T.restrict x b).eval = fun v => T.eval (fixBit x b v) :=
    funext (T.restrict_eval x b)
  rwa [hfun] at he

theorem e1 {n : Nat} (T : ModularTree n) (h : T.Valid 3) : E1 T.eval := by
  intro x b z hzx hz
  exact T.restrict_essential_mem h x b z hzx (T.supported.essential_mem z hz)

theorem setPair_eq_fixBit {n : Nat} (v : Fin n → Bool) (x y : Fin n) (a b : Bool) :
    setPair v x y a b = fixBit x a (fixBit y b v) := by
  funext k
  rfl

theorem e2 {n : Nat} (T : ModularTree n) (h : T.Valid 4) : E2 T.eval := by
  intro x y a b z _hxy hzx hzy hz
  have hzs := T.supported.essential_mem z hz
  have h3 : (T.restrict x a).Valid 3 := T.restrict_valid x a h
  have hz' : z ∈ (T.restrict x a).support := by
    rw [restrict_support]
    exact Finset.mem_erase.mpr ⟨hzx, hzs⟩
  have he := (T.restrict x a).restrict_essential_mem h3 y b z hzy hz'
  have hfun : (fun v => (T.restrict x a).eval (fixBit y b v)) =
      (fun v => T.eval (setPair v x y a b)) := by
    funext v
    rw [restrict_eval, setPair_eq_fixBit]
  rwa [hfun] at he

theorem s3 {n : Nat} (T : ModularTree n) (h : T.Valid 3) : S3 T.eval := by
  intro x y hxy hx hy
  exact T.pairSeparated h x y hxy (T.supported.essential_mem x hx) (T.supported.essential_mem y hy)

theorem goodFn {n : Nat} (T : ModularTree n) (h : T.Valid 4) : GoodFn T.eval where
  two_essential := by
    have hcard : 4 ≤ T.support.card := by
      rw [← T.inputs_eq_card (h.mono (by omega))]
      exact T.valid_inputs_ge h
    obtain ⟨x, hx, y, hy, hxy⟩ := Finset.one_lt_card.mp (show 1 < T.support.card by omega)
    exact ⟨x, y, hxy, T.essential (h.mono (by omega)) x hx, T.essential (h.mono (by omega)) y hy⟩
  e1 := T.e1 (h.mono (by omega))
  e2 := T.e2 h
  s3 := T.s3 (h.mono (by omega))
  cofactor_nonconstant := fun x b => T.cofactor_nonconstant (h.mono (by omega)) x b

end ModularTree
end SatLowerBound
