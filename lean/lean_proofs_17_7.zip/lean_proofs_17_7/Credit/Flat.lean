import Credit.ResLemmas



namespace SatLowerBound
namespace OpenCircuit

@[simp] theorem gateAt_head {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1)) :
    (gate g i j rest).gateAt n = some (g, i.val, j.val) := by
  simp [gateAt]

theorem gateAt_tail {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1)) {k : Nat}
    (hk : k ≠ n) : (gate g i j rest).gateAt k = rest.gateAt k := by
  simp [gateAt, hk]

/-- Gates have indices in `[n, n + size)` and read strictly earlier signals. -/
theorem gateAt_bounds {n : Nat} (C : OpenCircuit n) {k : Nat} {g : Table} {a b : Nat}
    (h : C.gateAt k = some (g, a, b)) : n ≤ k ∧ k < n + C.size ∧ a < k ∧ b < k := by
  induction C with
  | output s => simp [gateAt] at h
  | @gate n g' i j rest ih =>
    have hi := i.isLt
    have hj := j.isLt
    simp only [gateAt] at h
    split at h
    · rename_i hk
      simp only [Option.some.injEq, Prod.mk.injEq] at h
      obtain ⟨-, rfl, rfl⟩ := h
      simp only [size]
      omega
    · obtain ⟨h1, h2, h3, h4⟩ := ih h
      simp only [size]
      omega

theorem gateAt_of_lt {n : Nat} (C : OpenCircuit n) {k : Nat} (hk : k < n) : C.gateAt k = none := by
  cases h : C.gateAt k with
  | none => rfl
  | some p =>
    obtain ⟨g, a, b⟩ := p
    have := (C.gateAt_bounds h).1
    omega

theorem gateAt_of_ge {n : Nat} (C : OpenCircuit n) {k : Nat} (hk : n + C.size ≤ k) :
    C.gateAt k = none := by
  cases h : C.gateAt k with
  | none => rfl
  | some p =>
    obtain ⟨g, a, b⟩ := p
    have := (C.gateAt_bounds h).2.1
    omega

theorem gateAt_exists {n : Nat} (C : OpenCircuit n) {k : Nat} (h₁ : n ≤ k)
    (h₂ : k < n + C.size) : ∃ g a b, C.gateAt k = some (g, a, b) := by
  induction C with
  | output s =>
    simp only [size] at h₂
    omega
  | @gate n g i j rest ih =>
    by_cases hk : k = n
    · exact ⟨g, i.val, j.val, by simp [gateAt, hk]⟩
    · obtain ⟨g', a, b, h⟩ := ih (by omega) (by simp only [size] at h₂; omega)
      exact ⟨g', a, b, by simp [gateAt, hk, h]⟩

theorem outWire_bound {n : Nat} (C : OpenCircuit n) {k : Nat} {b : Bool}
    (h : C.outWire = some (k, b)) : k < n + C.size := by
  induction C with
  | output s =>
    cases s with
    | constant c => simp [outWire] at h
    | wire i c =>
      have hi := i.isLt
      simp only [outWire, Option.some.injEq, Prod.mk.injEq] at h
      obtain ⟨rfl, -⟩ := h
      simp only [size]
      omega
  | @gate n g i j rest ih =>
    have := ih h
    simp only [size]
    omega

/-! ### Values -/

theorem valueAt_input {n : Nat} (C : OpenCircuit n) (x : Fin n → Bool) (z : Fin n) :
    C.valueAt x z.val = x z := by
  induction C with
  | output s => simp [valueAt, z.isLt]
  | @gate n g i j rest ih =>
    have h := ih (extend x (g.eval (x i) (x j))) z.castSucc
    simp only [Fin.val_castSucc, extend_old] at h
    simp only [valueAt, h]

theorem valueAt_gate {n : Nat} (C : OpenCircuit n) (x : Fin n → Bool) {k : Nat} {g : Table}
    {a b : Nat} (h : C.gateAt k = some (g, a, b)) :
    C.valueAt x k = g.eval (C.valueAt x a) (C.valueAt x b) := by
  induction C with
  | output s => simp [gateAt] at h
  | @gate n g' i j rest ih =>
    simp only [gateAt] at h
    split at h
    · rename_i hk
      simp only [Option.some.injEq, Prod.mk.injEq] at h
      obtain ⟨hg, ha, hb⟩ := h
      rw [← hg, ← ha, ← hb, hk]
      have h1 := rest.valueAt_input (extend x (g'.eval (x i) (x j))) (Fin.last n)
      have h2 := rest.valueAt_input (extend x (g'.eval (x i) (x j))) i.castSucc
      have h3 := rest.valueAt_input (extend x (g'.eval (x i) (x j))) j.castSucc
      simp only [Fin.val_last, Fin.val_castSucc, extend_last, extend_old] at h1 h2 h3
      simp only [valueAt, h1, h2, h3]
    · exact ih _ h

theorem eval_of_outWire {n : Nat} (C : OpenCircuit n) (x : Fin n → Bool) {k : Nat} {neg : Bool}
    (h : C.outWire = some (k, neg)) : C.eval x = Bool.xor (C.valueAt x k) neg := by
  induction C with
  | output s =>
    cases s with
    | constant c => simp [outWire] at h
    | wire i c =>
      simp only [outWire, Option.some.injEq, Prod.mk.injEq] at h
      obtain ⟨rfl, rfl⟩ := h
      simp [eval, Signal.eval, valueAt, i.isLt]
  | @gate n g i j rest ih => exact ih _ h

theorem eval_const_of_outWire_none {n : Nat} (C : OpenCircuit n) (h : C.outWire = none)
    (x y : Fin n → Bool) : C.eval x = C.eval y := by
  induction C with
  | output s =>
    cases s with
    | constant c => rfl
    | wire i c => simp [outWire] at h
  | @gate n g i j rest ih => exact ih h _ _

/-! ### References and users -/

theorem usage_singleUse {n : Nat} (C : OpenCircuit n) (z : Fin n) :
    C.usage (singleUse z) = C.refCount z.val := by
  induction C with
  | output s =>
    cases s with
    | constant c => rfl
    | wire i c => simp only [usage, refCount, singleUse, Fin.ext_iff]
  | @gate n g i j rest ih =>
    simp only [usage, refCount]
    rw [singleUse_append, ih z.castSucc]
    simp only [Fin.val_castSucc, singleUse, Fin.ext_iff]

namespace FlatA

/-- `usesAt` in terms of `gateAt`. -/
theorem usesAt_eq_true {n : Nat} (C : OpenCircuit n) (k s : Nat) :
    C.usesAt k s = true ↔ ∃ g a b, C.gateAt k = some (g, a, b) ∧ (a = s ∨ b = s) := by
  unfold usesAt
  cases C.gateAt k with
  | none => simp
  | some p =>
    obtain ⟨g, a, b⟩ := p
    constructor
    · intro h
      exact ⟨g, a, b, rfl, by simpa using h⟩
    · rintro ⟨g', a', b', h, hab⟩
      simp only [Option.some.injEq, Prod.mk.injEq] at h
      obtain ⟨rfl, rfl, rfl⟩ := h
      simpa using hab

end FlatA

theorem mem_users {n : Nat} (C : OpenCircuit n) {s k : Nat} :
    k ∈ C.users s ↔ ∃ g a b, C.gateAt k = some (g, a, b) ∧ (a = s ∨ b = s) := by
  unfold users
  rw [Finset.mem_filter, Finset.mem_range, FlatA.usesAt_eq_true]
  constructor
  · rintro ⟨-, h⟩
    exact h
  · intro h
    refine ⟨?_, h⟩
    obtain ⟨g, a, b, hk, -⟩ := h
    exact (C.gateAt_bounds hk).2.1

namespace FlatA

/-- An output-only circuit has no gates, hence no users. -/
theorem users_output {n : Nat} (o : Signal n) (s : Nat) :
    (output o : OpenCircuit n).users s = ∅ := by
  ext k
  rw [mem_users]
  simp [gateAt]

/-- The head gate `n` of `gate g i j rest` is not a gate of `rest`. -/
theorem head_not_mem_users {n : Nat} (rest : OpenCircuit (n + 1)) (s : Nat) :
    n ∉ rest.users s := by
  rw [mem_users]
  rintro ⟨g', a, b, h, -⟩
  rw [rest.gateAt_of_lt (k := n) (by omega)] at h
  simp at h

theorem users_gate_reads {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (s : Nat) (hij : i.val = s ∨ j.val = s) :
    (gate g i j rest).users s = insert n (rest.users s) := by
  ext k
  rw [Finset.mem_insert, mem_users, mem_users]
  by_cases hk : k = n
  · rw [hk, gateAt_head]
    exact ⟨fun _ => Or.inl rfl, fun _ => ⟨g, i.val, j.val, rfl, hij⟩⟩
  · rw [gateAt_tail g i j rest hk]
    exact ⟨fun h => Or.inr h, fun h => h.resolve_left hk⟩

theorem users_gate_not_reads {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (s : Nat) (hij : ¬ (i.val = s ∨ j.val = s)) :
    (gate g i j rest).users s = rest.users s := by
  ext k
  rw [mem_users, mem_users]
  by_cases hk : k = n
  · rw [hk, gateAt_head, rest.gateAt_of_lt (k := n) (by omega)]
    constructor
    · rintro ⟨g', a, b, h, hab⟩
      simp only [Option.some.injEq, Prod.mk.injEq] at h
      obtain ⟨-, rfl, rfl⟩ := h
      exact absurd hab hij
    · rintro ⟨g', a, b, h, -⟩
      simp at h
  · rw [gateAt_tail g i j rest hk]

theorem users_gate_card {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (s : Nat) : ((gate g i j rest).users s).card =
      (if (i.val = s ∨ j.val = s) then 1 else 0) + (rest.users s).card := by
  by_cases hij : (i.val = s ∨ j.val = s)
  · rw [users_gate_reads g i j rest s hij, Finset.card_insert_of_notMem (head_not_mem_users rest s),
      ite_eq_left hij]
    omega
  · rw [users_gate_not_reads g i j rest s hij, ite_eq_right hij, Nat.zero_add]

theorem outIs_gate {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1)) (s : Nat) :
    (gate g i j rest).outIs s = rest.outIs s := rfl

theorem distinct_rest {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (hd : (gate g i j rest).DistinctOperands) : rest.DistinctOperands := by
  intro k g' a b h
  have hk : k ≠ n := by
    have := (rest.gateAt_bounds h).1
    omega
  exact hd k g' a b ((gateAt_tail g i j rest hk).trans h)

end FlatA

theorem refCount_ge {n : Nat} (C : OpenCircuit n) (s : Nat) :
    (C.users s).card + C.outIs s ≤ C.refCount s := by
  induction C with
  | output o =>
    rw [FlatA.users_output, Finset.card_empty, Nat.zero_add]
    cases o with
    | constant c => exact Nat.le_refl 0
    | wire w c => exact Nat.le_refl _
  | @gate n g i j rest ih =>
    rw [FlatA.users_gate_card, FlatA.outIs_gate]
    simp only [refCount]
    split_ifs <;> omega

theorem refCount_eq {n : Nat} (C : OpenCircuit n) (hd : C.DistinctOperands) (s : Nat) :
    C.refCount s = (C.users s).card + C.outIs s := by
  induction C with
  | output o =>
    rw [FlatA.users_output, Finset.card_empty, Nat.zero_add]
    cases o with
    | constant c => rfl
    | wire w c => rfl
  | @gate n g i j rest ih =>
    have : i.val ≠ j.val := hd n g i.val j.val (gateAt_head g i j rest)
    rw [FlatA.users_gate_card, FlatA.outIs_gate]
    simp only [refCount]
    rw [ih (FlatA.distinct_rest g i j rest hd)]
    split_ifs <;> omega

namespace FlatA

theorem appendValue_zero_one (n : Nat) :
    appendValue (fun _ : Fin n => (0 : Nat)) 1 = singleUse (Fin.last n) := by
  funext t
  have := t.isLt
  simp only [appendValue, singleUse, Fin.ext_iff, Fin.val_last]
  split_ifs <;> omega

theorem lastUses_eq {n : Nat} (rest : OpenCircuit (n + 1)) : rest.lastUses = rest.refCount n := by
  unfold lastUses
  rw [appendValue_zero_one, usage_singleUse, Fin.val_last]

end FlatA

/-- Flat reading of `Reduced`: essential tables, distinct operands, at least one reader. -/
theorem reduced_gate {n : Nat} (C : OpenCircuit n) (hr : C.Reduced) {k : Nat} {g : Table}
    {a b : Nat} (h : C.gateAt k = some (g, a, b)) :
    g.essential = true ∧ a ≠ b ∧ 1 ≤ C.refCount k := by
  induction C with
  | output s => simp [gateAt] at h
  | @gate n g' i j rest ih =>
    obtain ⟨hess, hij, hlast, hrest⟩ := hr
    by_cases hk : k = n
    · rw [hk, gateAt_head] at h
      simp only [Option.some.injEq, Prod.mk.injEq] at h
      obtain ⟨rfl, rfl, rfl⟩ := h
      refine ⟨hess, fun he => hij (Fin.ext he), ?_⟩
      have := FlatA.lastUses_eq rest
      rw [hk]
      simp only [refCount]
      omega
    · rw [gateAt_tail g' i j rest hk] at h
      obtain ⟨h1, h2, h3⟩ := ih hrest h
      refine ⟨h1, h2, ?_⟩
      simp only [refCount]
      omega

theorem reduced_distinct {n : Nat} (C : OpenCircuit n) (hr : C.Reduced) : C.DistinctOperands :=
  fun _ _ _ _ h => (C.reduced_gate hr h).2.1

theorem essentialGates_gate {n : Nat} (C : OpenCircuit n) (he : C.EssentialGates) {k : Nat}
    {g : Table} {a b : Nat} (h : C.gateAt k = some (g, a, b)) : g.essential = true := by
  induction C with
  | output s => simp [gateAt] at h
  | @gate n g' i j rest ih =>
    simp only [gateAt] at h
    split at h
    · simp only [Option.some.injEq, Prod.mk.injEq] at h
      obtain ⟨rfl, -, -⟩ := h
      exact he.1
    · exact ih he.2 h

namespace FlatA

theorem firstUserNL_exists {n : Nat} (C : OpenCircuit n) (s : Nat)
    (h : C.firstUserNL s = true) :
    ∃ k g a b, C.gateAt k = some (g, a, b) ∧ (a = s ∨ b = s) ∧ g.nonlinear = true := by
  induction C with
  | output o => simp [firstUserNL] at h
  | @gate n g i j rest ih =>
    simp only [firstUserNL] at h
    split_ifs at h with hij
    · exact ⟨n, g, i.val, j.val, gateAt_head g i j rest, hij, h⟩
    · obtain ⟨k, g', a, b, hk, hab, hnl⟩ := ih h
      have hkn : k ≠ n := by
        have := (rest.gateAt_bounds hk).1
        omega
      exact ⟨k, g', a, b, (gateAt_tail g i j rest hkn).trans hk, hab, hnl⟩

theorem firstUserNL_of_exists {n : Nat} (C : OpenCircuit n) (s : Nat) (h1 : C.refCount s = 1)
    (h : ∃ k g a b, C.gateAt k = some (g, a, b) ∧ (a = s ∨ b = s) ∧ g.nonlinear = true) :
    C.firstUserNL s = true := by
  induction C with
  | output o =>
    obtain ⟨k, g, a, b, hk, -, -⟩ := h
    simp [gateAt] at hk
  | @gate n g i j rest ih =>
    obtain ⟨k, g', a, b, hk, hab, hnl⟩ := h
    simp only [refCount] at h1
    simp only [firstUserNL]
    by_cases hij : (i.val = s ∨ j.val = s)
    · rw [ite_eq_left hij]
      by_cases hkn : k = n
      · rw [hkn, gateAt_head] at hk
        simp only [Option.some.injEq, Prod.mk.injEq] at hk
        obtain ⟨rfl, -, -⟩ := hk
        exact hnl
      · exfalso
        rw [gateAt_tail g i j rest hkn] at hk
        have hmem : k ∈ rest.users s := (mem_users rest).mpr ⟨g', a, b, hk, hab⟩
        have := Finset.card_pos.mpr ⟨k, hmem⟩
        have := rest.refCount_ge s
        rcases hij with hi | hj
        · rw [ite_eq_left hi] at h1
          omega
        · rw [ite_eq_left hj] at h1
          omega
    · rw [ite_eq_right hij]
      have hi : ¬ i.val = s := fun he => hij (Or.inl he)
      have hj : ¬ j.val = s := fun he => hij (Or.inr he)
      rw [ite_eq_right hi, ite_eq_right hj] at h1
      have hkn : k ≠ n := by
        intro hkn
        rw [hkn, gateAt_head] at hk
        simp only [Option.some.injEq, Prod.mk.injEq] at hk
        obtain ⟨-, rfl, rfl⟩ := hk
        exact hij hab
      rw [gateAt_tail g i j rest hkn] at hk
      exact ih (by omega) ⟨k, g', a, b, hk, hab, hnl⟩

end FlatA

theorem isD_iff {n : Nat} (C : OpenCircuit n) (s : Nat) :
    C.isD s = true ↔ C.refCount s = 1 ∧
      ∃ k g a b, C.gateAt k = some (g, a, b) ∧ (a = s ∨ b = s) ∧ g.nonlinear = true := by
  unfold isD
  rw [Bool.and_eq_true, decide_eq_true_iff]
  constructor
  · rintro ⟨h1, h2⟩
    exact ⟨h1, FlatA.firstUserNL_exists C s h2⟩
  · rintro ⟨h1, h2⟩
    exact ⟨h1, FlatA.firstUserNL_of_exists C s h1 h2⟩

theorem isDGate_iff {n : Nat} (C : OpenCircuit n) (k : Nat) :
    C.isDGate k = true ↔ ∃ g a b, C.gateAt k = some (g, a, b) ∧
      ((a < n ∧ C.isD a = true) ∨ (b < n ∧ C.isD b = true)) := by
  unfold isDGate
  cases hk : C.gateAt k with
  | none => simp
  | some p =>
    obtain ⟨g, a, b⟩ := p
    simp

/-! ### Resolution -/

theorem resAt_input {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) (z : Fin n) :
    C.resAt ρ z.val = ρ z := by
  induction C with
  | output s => simp [resAt, z.isLt]
  | @gate n g i j rest ih =>
    have h := ih (appendValue ρ ((Res.step g (ρ i) (ρ j)).getD (.lit n false))) z.castSucc
    simp only [Fin.val_castSucc] at h
    simp [resAt, h, appendValue, z.isLt]

theorem resAt_gate {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) {k : Nat} {g : Table}
    {a b : Nat} (h : C.gateAt k = some (g, a, b)) :
    C.resAt ρ k = (Res.step g (C.resAt ρ a) (C.resAt ρ b)).getD (.lit k false) := by
  induction C with
  | output s => simp [gateAt] at h
  | @gate n g' i j rest ih =>
    simp only [gateAt] at h
    split at h
    · rename_i hk
      simp only [Option.some.injEq, Prod.mk.injEq] at h
      obtain ⟨hg, ha, hb⟩ := h
      rw [← hg, ← ha, ← hb, hk]
      have h1 := (gate g' i j rest).resAt_input ρ i
      have h2 := (gate g' i j rest).resAt_input ρ j
      have h3 := rest.resAt_input
        (appendValue ρ ((Res.step g' (ρ i) (ρ j)).getD (.lit n false))) (Fin.last n)
      simp only [Fin.val_last] at h3
      rw [h1, h2]
      simp only [resAt]
      rw [h3]
      simp [appendValue]
    · exact ih _ h

theorem resAt_kept {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) {k : Nat}
    (h : C.isKept ρ k = true) : C.resAt ρ k = .lit k false := by
  cases hk : C.gateAt k with
  | none => simp [isKept, hk] at h
  | some p =>
    obtain ⟨g, a, b⟩ := p
    simp only [isKept, hk] at h
    rw [C.resAt_gate ρ hk]
    cases hs : Res.step g (C.resAt ρ a) (C.resAt ρ b) with
    | none => rfl
    | some r => simp [hs] at h

theorem resAt_aliased {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) {k : Nat} {g : Table}
    {a b : Nat} (hk : C.gateAt k = some (g, a, b)) (h : C.isAliased ρ k = true) :
    Res.step g (C.resAt ρ a) (C.resAt ρ b) = some (C.resAt ρ k) := by
  simp only [isAliased, hk] at h
  rw [C.resAt_gate ρ hk]
  cases hs : Res.step g (C.resAt ρ a) (C.resAt ρ b) with
  | none => simp [hs] at h
  | some r => rfl

theorem isKept_eq_not_isAliased {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) {k : Nat}
    {g : Table} {a b : Nat} (hk : C.gateAt k = some (g, a, b)) :
    C.isKept ρ k = !C.isAliased ρ k := by
  simp only [isKept, isAliased, hk]
  cases Res.step g (C.resAt ρ a) (C.resAt ρ b) <;> rfl

/-- A gate with an operand resolving to a constant is eliminated. -/
theorem isAliased_of_const {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) {k : Nat}
    {g : Table} {a b : Nat} (hk : C.gateAt k = some (g, a, b))
    (hc : (C.resAt ρ a).isConst = true ∨ (C.resAt ρ b).isConst = true) :
    C.isAliased ρ k = true := by
  simp only [isAliased, hk]
  rcases hc with hc | hc
  · cases ha : C.resAt ρ a with
    | const x => exact Res.step_const_left_isSome g x _
    | lit s neg => simp [ha, Res.isConst] at hc
  · cases hb : C.resAt ρ b with
    | const x => exact Res.step_const_right_isSome g _ x
    | lit s neg => simp [hb, Res.isConst] at hc

/-- A gate resolving to a constant is eliminated. -/
theorem isAliased_of_resAt_const {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) {k : Nat}
    {g : Table} {a b : Nat} (hk : C.gateAt k = some (g, a, b))
    (hc : (C.resAt ρ k).isConst = true) : C.isAliased ρ k = true := by
  have he := C.isKept_eq_not_isAliased ρ hk
  cases hal : C.isAliased ρ k
  · rw [hal] at he
    have hkept : C.isKept ρ k = true := by simpa using he
    rw [C.resAt_kept ρ hkept] at hc
    simp [Res.isConst] at hc
  · rfl

namespace FlatA

/-- Beyond the last gate, `resAt` is the default constant. -/
theorem resAt_of_ge {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) {k : Nat}
    (hk : n + C.size ≤ k) : C.resAt ρ k = .const false := by
  induction C with
  | @output n o =>
    have hk' : ¬ k < n := by
      simp only [size] at hk
      omega
    simp only [resAt]
    exact dite_eq_right hk'
  | @gate n g i j rest ih =>
    simp only [resAt]
    exact ih _ (by simp only [size] at hk; omega)

end FlatA

/-- How a resolution can be a literal of `s`: an input resolved so by `ρ`, a kept gate
(`s = k`), or an eliminated gate one of whose operands already resolves to `s`. -/
theorem resAt_hits_cases {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) {k s : Nat}
    (h : (C.resAt ρ k).hits s = true) :
    (∃ z : Fin n, z.val = k ∧ (ρ z).hits s = true) ∨
    (∃ g a b, C.gateAt k = some (g, a, b) ∧
      ((C.isKept ρ k = true ∧ s = k) ∨
       (C.isAliased ρ k = true ∧
         ((C.resAt ρ a).hits s = true ∨ (C.resAt ρ b).hits s = true)))) := by
  by_cases hkn : k < n
  · left
    have e : C.resAt ρ k = ρ ⟨k, hkn⟩ := C.resAt_input ρ ⟨k, hkn⟩
    rw [e] at h
    exact ⟨⟨k, hkn⟩, rfl, h⟩
  · right
    cases hg : C.gateAt k with
    | none =>
      exfalso
      have hge : n + C.size ≤ k := by
        by_contra hlt
        obtain ⟨g, a, b, hk⟩ := C.gateAt_exists (k := k) (by omega) (by omega)
        rw [hg] at hk
        simp at hk
      rw [FlatA.resAt_of_ge C ρ hge, Res.hits_const] at h
      simp at h
    | some p =>
      obtain ⟨g, a, b⟩ := p
      refine ⟨g, a, b, rfl, ?_⟩
      rw [C.resAt_gate ρ hg] at h
      cases hs : Res.step g (C.resAt ρ a) (C.resAt ρ b) with
      | none =>
        left
        rw [hs] at h
        change (Res.lit k false).hits s = true at h
        rw [Res.hits_lit] at h
        refine ⟨?_, h.symm⟩
        simp only [isKept, hg, hs, Option.isNone_none]
      | some r =>
        right
        rw [hs] at h
        change r.hits s = true at h
        refine ⟨?_, Res.step_hits g _ _ s r hs h⟩
        simp only [isAliased, hg, hs, Option.isSome_some]

/-- Soundness of the abstract trace: if `ρ` describes the input values correctly, `resAt`
describes every signal value correctly. -/
theorem resAt_sound {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) (x : Fin n → Bool)
    (hρ : ∀ z, (ρ z).Denotes (C.valueAt x) (x z)) (k : Nat) (hk : k < n + C.size) :
    (C.resAt ρ k).Denotes (C.valueAt x) (C.valueAt x k) := by
  induction k using Nat.strong_induction_on with
  | h k ih =>
    by_cases hkn : k < n
    · have e1 : C.resAt ρ k = ρ ⟨k, hkn⟩ := C.resAt_input ρ ⟨k, hkn⟩
      have e2 : C.valueAt x k = x ⟨k, hkn⟩ := C.valueAt_input x ⟨k, hkn⟩
      rw [e1, e2]
      exact hρ ⟨k, hkn⟩
    · obtain ⟨g, a, b, hg⟩ := C.gateAt_exists (k := k) (by omega) hk
      obtain ⟨-, -, ha, hb⟩ := C.gateAt_bounds hg
      have iha := ih a ha (by omega)
      have ihb := ih b hb (by omega)
      rw [C.resAt_gate ρ hg]
      cases hs : Res.step g (C.resAt ρ a) (C.resAt ρ b) with
      | none =>
        change C.valueAt x k = Bool.xor (C.valueAt x k) false
        rw [Bool.xor_false]
      | some r =>
        change r.Denotes (C.valueAt x) (C.valueAt x k)
        rw [C.valueAt_gate x hg]
        exact Res.step_sound g _ _ r hs (C.valueAt x) _ _ iha ihb

theorem fixRes_denotes {n : Nat} (C : OpenCircuit n) (P c x : Fin n → Bool)
    (hx : ∀ z, P z = true → x z = c z) (z : Fin n) :
    (fixRes P c z).Denotes (C.valueAt x) (x z) := by
  unfold fixRes
  split
  · rename_i h
    exact hx z h
  · change x z = Bool.xor (C.valueAt x z.val) false
    rw [C.valueAt_input x z, Bool.xor_false]

/-! ### Triangles and sums -/

namespace FlatA

/-- Generalization of `noInputTriangles_flat` to an arbitrary history `Γ`: the signal `k`
reads the primary input `x` either as an earlier gate recorded in `Γ` or as a gate of `C`. -/
theorem noTri_aux (x k k₂ : Nat) {m : Nat} (C : OpenCircuit m) (Γ : History m)
    (ht : C.NoInputTriangles Γ) (hxm : x < m) (hx : Γ ⟨x, hxm⟩ = none)
    (hk : (∃ (hkm : k < m) (p : GateRecipe m), Γ ⟨k, hkm⟩ = some p ∧
        (p.left.val = x ∨ p.right.val = x)) ∨ k ∈ C.users x)
    (hk₂ : k₂ ∈ C.users k) : k₂ ∉ C.users x := by
  induction C with
  | output o =>
    rw [users_output] at hk₂
    simp at hk₂
  | @gate m g i j rest ih =>
    obtain ⟨hnt, ht'⟩ := ht
    intro hk₂x
    rw [mem_users] at hk₂ hk₂x
    obtain ⟨g₁, a₁, b₁, h₁, hab₁⟩ := hk₂
    obtain ⟨g₂, a₂, b₂, h₂, hab₂⟩ := hk₂x
    rw [h₁] at h₂
    simp only [Option.some.injEq, Prod.mk.injEq] at h₂
    obtain ⟨-, rfl, rfl⟩ := h₂
    by_cases hkm₂ : k₂ = m
    · rw [hkm₂, gateAt_head] at h₁
      simp only [Option.some.injEq, Prod.mk.injEq] at h₁
      obtain ⟨-, rfl, rfl⟩ := h₁
      rcases hk with ⟨hkm, p, hp, hpx⟩ | hkC
      · apply hnt
        unfold History.TriangleAt
        have hkx : k ≠ x := by
          intro e
          have e' : (⟨k, hkm⟩ : Fin m) = ⟨x, hxm⟩ := Fin.ext e
          rw [e', hx] at hp
          simp at hp
        rcases hab₁ with hik | hjk
        · have hjx : j.val = x := by
            rcases hab₂ with h | h
            · omega
            · exact h
          right
          refine ⟨?_, p, ?_, ?_⟩
          · rw [show j = ⟨x, hxm⟩ from Fin.ext hjx]
            exact hx
          · rw [show i = ⟨k, hkm⟩ from Fin.ext hik]
            exact hp
          · rcases hpx with h | h
            · exact Or.inl (Fin.ext (h.trans hjx.symm))
            · exact Or.inr (Fin.ext (h.trans hjx.symm))
        · have hix : i.val = x := by
            rcases hab₂ with h | h
            · exact h
            · omega
          left
          refine ⟨?_, p, ?_, ?_⟩
          · rw [show i = ⟨x, hxm⟩ from Fin.ext hix]
            exact hx
          · rw [show j = ⟨k, hkm⟩ from Fin.ext hjk]
            exact hp
          · rcases hpx with h | h
            · exact Or.inl (Fin.ext (h.trans hix.symm))
            · exact Or.inr (Fin.ext (h.trans hix.symm))
      · rw [mem_users] at hkC
        obtain ⟨g₃, a₃, b₃, h₃, -⟩ := hkC
        obtain ⟨hb1, -, -, -⟩ := (gate g i j rest).gateAt_bounds h₃
        have := i.isLt
        have := j.isLt
        omega
    · rw [gateAt_tail g i j rest hkm₂] at h₁
      have hx' : (Γ.extend g i j) ⟨x, Nat.lt_succ_of_lt hxm⟩ = none := by
        have e := History.extend_old Γ g i j ⟨x, hxm⟩
        rw [hx] at e
        exact e
      have hk' : (∃ (hkm : k < m + 1) (p : GateRecipe (m + 1)),
          (Γ.extend g i j) ⟨k, hkm⟩ = some p ∧ (p.left.val = x ∨ p.right.val = x)) ∨
          k ∈ rest.users x := by
        rcases hk with ⟨hkm, p, hp, hpx⟩ | hkC
        · left
          refine ⟨Nat.lt_succ_of_lt hkm, p.lift, ?_, hpx⟩
          have e := History.extend_old Γ g i j ⟨k, hkm⟩
          rw [hp] at e
          exact e
        · rw [mem_users] at hkC
          obtain ⟨g₃, a₃, b₃, h₃, hab₃⟩ := hkC
          by_cases hkm : k = m
          · left
            rw [hkm, gateAt_head] at h₃
            simp only [Option.some.injEq, Prod.mk.injEq] at h₃
            obtain ⟨-, rfl, rfl⟩ := h₃
            have hk1 : k < m + 1 := by omega
            refine ⟨hk1, ⟨g, i.castSucc, j.castSucc⟩, ?_, hab₃⟩
            have e : (⟨k, hk1⟩ : Fin (m + 1)) = Fin.last m := Fin.ext hkm
            rw [e]
            exact History.extend_last Γ g i j
          · right
            rw [gateAt_tail g i j rest hkm] at h₃
            exact (mem_users rest).mpr ⟨g₃, a₃, b₃, h₃, hab₃⟩
      exact ih (Γ.extend g i j) ht' (Nat.lt_succ_of_lt hxm) hx' hk'
        ((mem_users rest).mpr ⟨g₁, _, _, h₁, hab₁⟩) ((mem_users rest).mpr ⟨g₁, _, _, h₁, hab₂⟩)

end FlatA

/-- Flat reading of `NoInputTriangles`: a gate reading a primary input `x` and a direct
successor `k` of `x` does not exist. -/
theorem noInputTriangles_flat {n : Nat} (C : OpenCircuit n)
    (ht : C.NoInputTriangles (fun _ => none)) {x k k₂ : Nat} (hx : x < n)
    (hk : k ∈ C.users x) (hk₂ : k₂ ∈ C.users k) : k₂ ∉ C.users x :=
  FlatA.noTri_aux x k k₂ C (fun _ => none) ht hx rfl (Or.inr hk) hk₂

namespace FlatA

/-- Isolate the term at index `m` of a sum over `range N`, replacing the other terms. -/
theorem sum_range_split {N m : Nat} (hm : m < N) (F G : Nat → Nat)
    (hFG : ∀ k, k ≠ m → F k = G k) (hG : G m = 0) :
    ∑ k ∈ Finset.range N, F k = F m + ∑ k ∈ Finset.range N, G k := by
  have hmem : m ∈ Finset.range N := Finset.mem_range.mpr hm
  rw [← Finset.add_sum_erase _ F hmem, ← Finset.add_sum_erase _ G hmem, hG, Nat.zero_add]
  congr 1
  exact Finset.sum_congr rfl (fun k hk => hFG k (Finset.ne_of_mem_erase hk))

/-- Splitting a sum over the global indices of `gate g i j rest` into the head gate `n` and the
sum over the global indices of `rest` (for summands that agree away from `n` and vanish at `n`
on the `rest` side).  Intended for every `*_eq_sum` lemma of packages A and A2. -/
theorem sum_gate_split {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (F G : Nat → Nat) (hFG : ∀ k, k ≠ n → F k = G k) (hG : G n = 0) :
    ∑ k ∈ Finset.range (n + (gate g i j rest).size), F k =
      F n + ∑ k ∈ Finset.range (n + 1 + rest.size), G k := by
  have e : n + (gate g i j rest).size = n + 1 + rest.size := by
    simp only [size]
    omega
  rw [e]
  exact sum_range_split (by omega) F G hFG hG

theorem tableAt_head {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1)) :
    (gate g i j rest).tableAt n = g := by
  simp only [tableAt, gateAt_head]

theorem tableAt_tail {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1)) {k : Nat}
    (hk : k ≠ n) : (gate g i j rest).tableAt k = rest.tableAt k := by
  simp only [tableAt, gateAt_tail g i j rest hk]

theorem tableAt_none_nonlinearCount {n : Nat} (C : OpenCircuit n) {k : Nat}
    (h : C.gateAt k = none) : (C.tableAt k).nonlinearCount = 0 := by
  have e : C.tableAt k = ⟨false, false, false, false⟩ := by simp only [tableAt, h]
  rw [e]
  rfl

theorem gatePsiW_head {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1)) :
    (gate g i j rest).gatePsiW n = g.psiW := by
  simp only [gatePsiW, gateAt_head]

theorem gatePsiW_tail {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1)) {k : Nat}
    (hk : k ≠ n) : (gate g i j rest).gatePsiW k = rest.gatePsiW k := by
  simp only [gatePsiW, gateAt_tail g i j rest hk]

theorem gatePsiW_none {n : Nat} (C : OpenCircuit n) {k : Nat} (h : C.gateAt k = none) :
    C.gatePsiW k = 0 := by
  simp only [gatePsiW, h]

end FlatA

theorem nonlinearCount_eq_sum {n : Nat} (C : OpenCircuit n) :
    C.nonlinearCount = ∑ k ∈ Finset.range (n + C.size), (C.tableAt k).nonlinearCount := by
  induction C with
  | output o => exact (Finset.sum_eq_zero (fun k _ => rfl)).symm
  | @gate n g i j rest ih =>
    simp only [nonlinearCount]
    rw [FlatA.sum_gate_split g i j rest (fun k => ((gate g i j rest).tableAt k).nonlinearCount)
      (fun k => (rest.tableAt k).nonlinearCount)
      (fun k hk => by simp only [FlatA.tableAt_tail g i j rest hk])
      (FlatA.tableAt_none_nonlinearCount rest (rest.gateAt_of_lt (k := n) (by omega))),
      ← ih, FlatA.tableAt_head]

theorem psiWeight_eq_sum {n : Nat} (C : OpenCircuit n) :
    C.psiWeight = ∑ k ∈ Finset.range (n + C.size), C.gatePsiW k := by
  induction C with
  | output o => exact (Finset.sum_eq_zero (fun k _ => rfl)).symm
  | @gate n g i j rest ih =>
    simp only [psiWeight]
    rw [FlatA.sum_gate_split g i j rest _ _ (fun k hk => FlatA.gatePsiW_tail g i j rest hk)
      (FlatA.gatePsiW_none rest (rest.gateAt_of_lt (k := n) (by omega))), ← ih,
      FlatA.gatePsiW_head]

end OpenCircuit
end SatLowerBound
