import Credit.PsiReduce
import Credit.PsiTriangle
import Credit.Forbid

/-!
# Credit.PsiMinimal: `Ψ`-minimal circuits

Replaces explicit renormalization: a circuit minimizing `(Ψ, size, predecessorSum)`
lexicographically among *all* circuits computing `f` is reduced, uses only essential inputs,
satisfies `DGateSafe`, and has no input triangles.  Hence it satisfies the hypotheses of
Main Lemma A.  All proofs here are complete modulo the statements of packages C–F.
-/

namespace SatLowerBound
namespace OpenCircuit

/-- `C` computes `f` and is lexicographically minimal for `(Ψ, size, predecessorSum)`. -/
def PsiMinimal {n : Nat} (f : (Fin n → Bool) → Bool) (C : OpenCircuit n) : Prop :=
  (∀ x, C.eval x = f x) ∧ ∀ D : OpenCircuit n, (∀ x, D.eval x = f x) →
    C.psi < D.psi ∨ (C.psi = D.psi ∧
      (C.size < D.size ∨ (C.size = D.size ∧ C.predecessorSum ≤ D.predecessorSum)))

theorem exists_psiMinimal {n : Nat} (C : OpenCircuit n) :
    ∃ D : OpenCircuit n, PsiMinimal C.eval D ∧ D.psi ≤ C.psi := by
  classical
  have hnn (D : OpenCircuit n) : 0 ≤ D.psi + n := by
    have := D.neg_le_psi
    omega
  have h1 : ∃ t : Nat, ∃ D : OpenCircuit n, (∀ x, D.eval x = C.eval x) ∧ D.psi + n = t :=
    ⟨(C.psi + n).toNat, C, fun _ => rfl, (Int.toNat_of_nonneg (hnn C)).symm⟩
  obtain ⟨D₁, hD₁e, hD₁t⟩ := Nat.find_spec h1
  have hmin1 (E : OpenCircuit n) (hE : ∀ x, E.eval x = C.eval x) : D₁.psi ≤ E.psi := by
    have hle := Nat.find_min' h1 ⟨E, hE, (Int.toNat_of_nonneg (hnn E)).symm⟩
    have hcast : ((Nat.find h1 : Nat) : Int) ≤ ((E.psi + n).toNat : Int) := by exact_mod_cast hle
    rw [Int.toNat_of_nonneg (hnn E)] at hcast
    omega
  have h2 : ∃ s : Nat, ∃ D : OpenCircuit n, (∀ x, D.eval x = C.eval x) ∧ D.psi = D₁.psi ∧
      D.size = s := ⟨D₁.size, D₁, hD₁e, rfl, rfl⟩
  obtain ⟨D₂, hD₂e, hD₂p, hD₂s⟩ := Nat.find_spec h2
  have h3 : ∃ p : Nat, ∃ D : OpenCircuit n, (∀ x, D.eval x = C.eval x) ∧ D.psi = D₁.psi ∧
      D.size = Nat.find h2 ∧ D.predecessorSum = p :=
    ⟨D₂.predecessorSum, D₂, hD₂e, hD₂p, hD₂s, rfl⟩
  obtain ⟨D₃, hD₃e, hD₃p, hD₃s, hD₃q⟩ := Nat.find_spec h3
  refine ⟨D₃, ⟨hD₃e, ?_⟩, ?_⟩
  · intro E hE
    have hp := hmin1 E hE
    by_cases hlt : D₁.psi < E.psi
    · left
      omega
    · right
      have hpe : E.psi = D₁.psi := by omega
      refine ⟨by omega, ?_⟩
      have hs := Nat.find_min' h2 ⟨E, hE, hpe, rfl⟩
      by_cases hslt : Nat.find h2 < E.size
      · left
        omega
      · right
        have hse : E.size = Nat.find h2 := by omega
        refine ⟨by omega, ?_⟩
        have hq := Nat.find_min' h3 ⟨E, hE, hpe, hse, rfl⟩
        omega
  · have := hmin1 C (fun _ => rfl)
    omega

namespace PsiMinimal

variable {n : Nat} {f : (Fin n → Bool) → Bool} {C : OpenCircuit n}

theorem computes (h : PsiMinimal f C) : ∀ x, C.eval x = f x := h.1

theorem reduced (h : PsiMinimal f C) : C.Reduced := by
  by_contra hn
  obtain ⟨D, hs, hp, he⟩ := psi_smaller_of_not_reduced C hn
  rcases h.2 D (fun x => (he x).trans (h.1 x)) with h1 | ⟨h1, h2 | ⟨h2, _⟩⟩ <;> omega

theorem usedEssential (h : PsiMinimal f C) (hf : Nonconstant f) (z : Fin n)
    (hu : 0 < C.usage (singleUse z)) : Essential f z := by
  by_contra he
  have hr := h.reduced
  have hD : ∀ v, (C.restrict (singleSubst z false)).eval v = f v := by
    intro v
    rw [restrict_single_eval, h.1]
    exact fixBit_of_not_essential f z he false v
  have hnon : Nonconstant (C.restrict (singleSubst z false)).eval := by
    obtain ⟨u, v, huv⟩ := hf
    exact ⟨u, v, by rwa [hD, hD]⟩
  have hmarks : MarksConstants (singlePartial z false).mask (singleSubst z false) := by
    intro k hk
    by_cases hkz : k = z
    · subst k
      exact ⟨false, by simp [singleSubst]⟩
    · simp [singlePartial, PartialState.mask, hkz] at hk
  have hclose := C.closureOutput_false _ _ hmarks hnon
  have hsize := C.constant_closure_deletion _ _ hmarks (C.reduced_live hr) hclose
  rw [singlePartial_uses] at hsize
  have hpsi : (C.restrict (singleSubst z false)).psi ≤ C.psi := by
    rw [singleSubst_eq_fixSubst]
    exact psi_restrict_le C _ _
  rcases h.2 (C.restrict (singleSubst z false)) hD with h1 | ⟨h1, h2 | ⟨h2, _⟩⟩ <;> omega

theorem dGateSafe (h : PsiMinimal f C) (hf : Nonconstant f) (hE1 : E1 f) : C.DGateSafe :=
  forbid_a f C h.reduced h.1 hE1 (h.usedEssential hf)

theorem noTriangles (h : PsiMinimal f C) (hf : Nonconstant f) (hE1 : E1 f) :
    C.NoInputTriangles (fun _ => none) := by
  by_contra ht
  obtain ⟨D, hs, hp, hpsi, he⟩ := psi_triangle_step C h.reduced (h.dGateSafe hf hE1) ht
  rcases h.2 D (fun x => (he x).trans (h.1 x)) with h1 | ⟨h1, h2 | ⟨h2, h3⟩⟩ <;> omega

theorem context (h : PsiMinimal f C) (hg : GoodFn f) : MAContext f C :=
  ⟨hg, h.reduced, h.noTriangles hg.nonconstant hg.e1, h.1, h.usedEssential hg.nonconstant⟩

end PsiMinimal
end OpenCircuit
end SatLowerBound
