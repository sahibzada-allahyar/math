import Credit.Charging



namespace SatLowerBound
namespace OpenCircuit

/-- Disconnection, contrapositive form: if `z` stays essential for the restricted circuit,
some direct successor of `z` does not become a constant. -/
theorem exists_nonconst_user {n : Nat} (C : OpenCircuit n) (P c : Fin n → Bool) (z : Fin n)
    (hout : ∀ k neg, C.outWire = some (k, neg) → k ≠ z.val)
    (hess : Essential (C.restrict (fixSubst P c)).eval z) :
    ∃ k ∈ C.users z.val, (C.resAt (fixRes P c) k).isConst = false := by
  by_contra hcon
  have hall : ∀ k ∈ C.users z.val, (C.resAt (fixRes P c) k).isConst = true := by
    intro k hk
    cases hck : (C.resAt (fixRes P c) k).isConst with
    | false => exact absurd ⟨k, hk, hck⟩ hcon
    | true => rfl
  have h0 : C.keptRefs (fixRes P c) z.val = 0 := by
    apply C.keptRefs_eq_zero (fixRes P c) z.val z.isLt
    · intro w hw
      exact fixRes_hits P c z.val w hw
    · exact hall
    · exact hout
  exact C.not_essential_of_keptRefs_zero P c z h0 hess

/-- Connectivity under a one-input restriction: an essential input other than the fixed one
keeps a direct successor that does not become constant. -/
theorem connected {n : Nat} (f : (Fin n → Bool) → Bool) (C : OpenCircuit n)
    (hc : ∀ v, C.eval v = f v) (hE1 : E1 f) (x : Fin n) (b : Bool) (z : Fin n) (hzx : z ≠ x)
    (hz : Essential f z) (hout : ∀ k neg, C.outWire = some (k, neg) → k ≠ z.val) :
    ∃ k ∈ C.users z.val, (C.resAt (singleRes x b) k).isConst = false := by
  have hfun : (C.restrict (fixSubst (fun w => decide (w = x)) (fun _ => b))).eval =
      fun v => f (fixBit x b v) := by
    funext v
    rw [← singleSubst_eq_fixSubst, restrict_single_eval, hc]
  have hess : Essential (C.restrict (fixSubst (fun w => decide (w = x)) (fun _ => b))).eval z := by
    rw [hfun]
    exact hE1 x b z hzx hz
  exact C.exists_nonconst_user _ _ z hout hess

/-- Core disconnection step: a reader of a D-variable `z` cannot become constant when another
input `x` is fixed (it is the only reader of `z`, and `z` stays essential by (E1)). -/
theorem dvar_reader_not_const {n : Nat} (f : (Fin n → Bool) → Bool) (C : OpenCircuit n)
    (hc : ∀ v, C.eval v = f v) (hE1 : E1 f)
    (hess : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential f z)
    (x : Fin n) (b : Bool) (z : Fin n) (hzx : z ≠ x) (hDz : C.isD z.val = true) {k : Nat}
    (hkz : k ∈ C.users z.val) (hk : (C.resAt (singleRes x b) k).isConst = true) : False := by
  have h1 := ((C.isD_iff z.val).mp hDz).1
  have hge := C.refCount_ge z.val
  have hcard : (C.users z.val).card = 1 := by
    have := Finset.card_pos.mpr ⟨k, hkz⟩
    omega
  have hout0 : C.outIs z.val = 0 := by omega
  have hout : ∀ k' neg, C.outWire = some (k', neg) → k' ≠ z.val := by
    intro k' neg hw he
    simp [outIs, hw, he] at hout0
  have hzess : Essential f z := hess z (by rw [C.usage_singleUse]; omega)
  obtain ⟨k₂, hk₂, hnc⟩ := C.connected f hc hE1 x b z hzx hzess hout
  obtain ⟨u, hu⟩ := Finset.card_eq_one.mp hcard
  rw [hu, Finset.mem_singleton] at hkz hk₂
  rw [hk₂, ← hkz, hk] at hnc
  contradiction

/-- Lemma 4.3(a): a gate whose two operands are primary inputs is not the D-gate of either. -/
theorem forbid_a {n : Nat} (f : (Fin n → Bool) → Bool) (C : OpenCircuit n) (hr : C.Reduced)
    (hc : ∀ v, C.eval v = f v) (hE1 : E1 f)
    (hess : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential f z) : C.DGateSafe := by
  intro k g a b hk ha hb
  have hab : a ≠ b := (C.reduced_gate hr hk).2.1
  -- the table of a D-gate is nonlinear
  have hnl : ∀ z : Nat, C.isD z = true → (a = z ∨ b = z) → g.nonlinear = true := by
    intro z hDz hzk
    obtain ⟨h1, k', g', a', b', hk', hzk', hnl'⟩ := (C.isD_iff z).mp hDz
    have hkz : k ∈ C.users z := C.mem_users.mpr ⟨g, a, b, hk, hzk⟩
    have hk'z : k' ∈ C.users z := C.mem_users.mpr ⟨g', a', b', hk', hzk'⟩
    have hge := C.refCount_ge z
    have hcard : (C.users z).card = 1 := by
      have := Finset.card_pos.mpr ⟨k, hkz⟩
      omega
    obtain ⟨u, hu⟩ := Finset.card_eq_one.mp hcard
    rw [hu, Finset.mem_singleton] at hkz hk'z
    rw [hk'z, ← hkz, hk] at hk'
    cases hk'
    exact hnl'
  constructor
  · cases hDa : C.isD a with
    | false => rfl
    | true =>
      exfalso
      have hg := hnl a hDa (Or.inl rfl)
      obtain ⟨β, hβ, -⟩ := g.nonlinear_exists_blocksRight hg
      have hconst : (C.resAt (singleRes ⟨b, hb⟩ β) k).isConst = true := by
        have hne : (⟨a, ha⟩ : Fin n) ≠ ⟨b, hb⟩ := fun he => hab (congrArg Fin.val he)
        have hra : C.resAt (singleRes ⟨b, hb⟩ β) a = .lit a false := by
          have h0 := C.resAt_single_input ⟨b, hb⟩ β ⟨a, ha⟩
          simpa [hne] using h0
        have hrb : C.resAt (singleRes ⟨b, hb⟩ β) b = .const β := by
          have h0 := C.resAt_single_input ⟨b, hb⟩ β ⟨b, hb⟩
          simpa using h0
        rw [C.resAt_gate _ hk, hra, hrb, Res.step_blocked_right g _ β hβ]
        rfl
      exact dvar_reader_not_const f C hc hE1 hess ⟨b, hb⟩ β ⟨a, ha⟩
        (fun he => hab (congrArg Fin.val he)) hDa (C.mem_users.mpr ⟨g, a, b, hk, Or.inl rfl⟩)
        hconst
  · cases hDb : C.isD b with
    | false => rfl
    | true =>
      exfalso
      have hg := hnl b hDb (Or.inr rfl)
      obtain ⟨α, hα, -⟩ := g.nonlinear_exists_blocksLeft hg
      have hconst : (C.resAt (singleRes ⟨a, ha⟩ α) k).isConst = true := by
        have hne : (⟨b, hb⟩ : Fin n) ≠ ⟨a, ha⟩ := fun he => hab (congrArg Fin.val he).symm
        have hra : C.resAt (singleRes ⟨a, ha⟩ α) a = .const α := by
          have h0 := C.resAt_single_input ⟨a, ha⟩ α ⟨a, ha⟩
          simpa using h0
        have hrb : C.resAt (singleRes ⟨a, ha⟩ α) b = .lit b false := by
          have h0 := C.resAt_single_input ⟨a, ha⟩ α ⟨b, hb⟩
          simpa [hne] using h0
        rw [C.resAt_gate _ hk, hra, hrb, Res.step_blocked_left g α _ hα]
        rfl
      exact dvar_reader_not_const f C hc hE1 hess ⟨a, ha⟩ α ⟨b, hb⟩
        (fun he => hab (congrArg Fin.val he).symm) hDb
        (C.mem_users.mpr ⟨g, a, b, hk, Or.inr rfl⟩) hconst

/-- Core of Lemma 4.3(b), for one orientation of the successor `k₂ = g₂(k, o)` or `g₂(o, k)`. -/
theorem forbid_b_core {n : Nat} (f : (Fin n → Bool) → Bool) (C : OpenCircuit n) (hr : C.Reduced)
    (hc : ∀ v, C.eval v = f v) (hE2 : E2 f)
    (hess : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential f z)
    {k : Nat} {g : Table} {a b : Nat} (hk : C.gateAt k = some (g, a, b)) (ha : a < n)
    (hb : b < n) {k₂ : Nat} {g₂ : Table} (o : Fin n) (hDo : C.isD o.val = true)
    (horient : C.gateAt k₂ = some (g₂, k, o.val) ∨ C.gateAt k₂ = some (g₂, o.val, k)) : False := by
  have hab : a ≠ b := (C.reduced_gate hr hk).2.1
  have hgess : g.essential = true := (C.reduced_gate hr hk).1
  have hk₂o : k₂ ∈ C.users o.val := by
    rcases horient with h | h
    · exact C.mem_users.mpr ⟨g₂, k, o.val, h, Or.inr rfl⟩
    · exact C.mem_users.mpr ⟨g₂, o.val, k, h, Or.inl rfl⟩
  have hk₂gt : k < k₂ := by
    rcases horient with h | h
    · exact (C.gateAt_bounds h).2.2.1
    · exact (C.gateAt_bounds h).2.2.2
  obtain ⟨h1, k', g', a', b', hk', hzk', hnl'⟩ := (C.isD_iff o.val).mp hDo
  have hge := C.refCount_ge o.val
  have hcard : (C.users o.val).card = 1 := by
    have := Finset.card_pos.mpr ⟨k₂, hk₂o⟩
    omega
  obtain ⟨u, hu⟩ := Finset.card_eq_one.mp hcard
  have hk'o : k' ∈ C.users o.val := C.mem_users.mpr ⟨g', a', b', hk', hzk'⟩
  have hk₂u : k₂ = u := by rw [hu, Finset.mem_singleton] at hk₂o; exact hk₂o
  have hk'u : k' = u := by rw [hu, Finset.mem_singleton] at hk'o; exact hk'o
  have hg₂nl : g₂.nonlinear = true := by
    rw [hk'u, ← hk₂u] at hk'
    rcases horient with h | h <;> rw [h] at hk' <;> cases hk' <;> exact hnl'
  have hout0 : C.outIs o.val = 0 := by omega
  have hout : ∀ k'' neg, C.outWire = some (k'', neg) → k'' ≠ o.val := by
    intro k'' neg hw he
    simp [outIs, hw, he] at hout0
  -- o is neither a nor b
  have hoa : o.val ≠ a := by
    intro he
    have hkin : k ∈ C.users o.val := C.mem_users.mpr ⟨g, a, b, hk, Or.inl he.symm⟩
    rw [hu, Finset.mem_singleton] at hkin
    omega
  have hob : o.val ≠ b := by
    intro he
    have hkin : k ∈ C.users o.val := C.mem_users.mpr ⟨g, a, b, hk, Or.inr he.symm⟩
    rw [hu, Finset.mem_singleton] at hkin
    omega
  have hko : k ≠ o.val := by
    have := o.isLt
    have := (C.gateAt_bounds hk).1
    omega
  -- the value of k that blocks k₂ on k's side
  obtain ⟨γ, hγ⟩ : ∃ γ : Bool, ∀ r : Res,
      (C.gateAt k₂ = some (g₂, k, o.val) → ∃ c', Res.step g₂ (.const γ) r = some (.const c')) ∧
      (C.gateAt k₂ = some (g₂, o.val, k) → ∃ c', Res.step g₂ r (.const γ) = some (.const c')) := by
    rcases horient with h | h
    · obtain ⟨γ, hγ, -⟩ := g₂.nonlinear_exists_blocksLeft hg₂nl
      refine ⟨γ, fun r => ⟨fun _ => ⟨_, Res.step_blocked_left g₂ γ r hγ⟩, fun h' => ?_⟩⟩
      have hkk := (Prod.mk.inj (Prod.mk.inj (Option.some.inj (h.symm.trans h'))).2).1
      exact absurd hkk hko
    · obtain ⟨γ, hγ, -⟩ := g₂.nonlinear_exists_blocksRight hg₂nl
      refine ⟨γ, fun r => ⟨fun h' => ?_, fun _ => ⟨_, Res.step_blocked_right g₂ r γ hγ⟩⟩⟩
      have hkk := (Prod.mk.inj (Prod.mk.inj (Option.some.inj (h.symm.trans h'))).2).1
      exact absurd hkk.symm hko
  obtain ⟨α, β, hαβ⟩ := g.essential_attains hgess γ
  let x : Fin n := ⟨a, ha⟩
  let y : Fin n := ⟨b, hb⟩
  have hxy : x ≠ y := fun he => hab (congrArg Fin.val he)
  let P : Fin n → Bool := fun z => decide (z = x) || decide (z = y)
  let c : Fin n → Bool := fun z => if z = x then α else β
  have hrx : C.resAt (fixRes P c) a = .const α := by
    have h0 := C.resAt_input (fixRes P c) x
    simpa [fixRes, P, c, x] using h0
  have hry : C.resAt (fixRes P c) b = .const β := by
    have h0 := C.resAt_input (fixRes P c) y
    have hyx : y ≠ x := fun he => hxy he.symm
    simpa [fixRes, P, c, y, hyx] using h0
  have hro : C.resAt (fixRes P c) o.val = .lit o.val false := by
    have h0 := C.resAt_input (fixRes P c) o
    have hox : o ≠ x := fun he => hoa (congrArg Fin.val he)
    have hoy : o ≠ y := fun he => hob (congrArg Fin.val he)
    simpa [fixRes, P, hox, hoy] using h0
  have hrk : C.resAt (fixRes P c) k = .const γ := by
    rw [C.resAt_gate _ hk, hrx, hry]
    simp [Res.step, hαβ]
  have hrk₂ : (C.resAt (fixRes P c) k₂).isConst = true := by
    rcases horient with h | h
    · rw [C.resAt_gate _ h, hrk, hro]
      obtain ⟨c', hc'⟩ := (hγ (.lit o.val false)).1 h
      rw [hc']
      rfl
    · rw [C.resAt_gate _ h, hro, hrk]
      obtain ⟨c', hc'⟩ := (hγ (.lit o.val false)).2 h
      rw [hc']
      rfl
  have hessR : Essential (C.restrict (fixSubst P c)).eval o := by
    have hfix : fixSubst P c = pairSubst x y α β := (pairSubst_eq_fixSubst x y α β).symm
    have hfun : (C.restrict (fixSubst P c)).eval = fun v => f (setPair v x y α β) := by
      funext v
      rw [hfix, restrict_pair_eval, hc]
    rw [hfun]
    exact hE2 x y α β o hxy (fun he => hoa (congrArg Fin.val he))
      (fun he => hob (congrArg Fin.val he)) (hess o (by rw [C.usage_singleUse]; omega))
  obtain ⟨k₃, hk₃, hnc⟩ := C.exists_nonconst_user P c o hout hessR
  rw [hu, Finset.mem_singleton] at hk₃
  rw [hk₃, ← hk₂u, hrk₂] at hnc
  contradiction

/-- Lemma 4.3(b): no direct successor of a gate with two primary operands is a D-gate. -/
theorem forbid_b {n : Nat} (f : (Fin n → Bool) → Bool) (C : OpenCircuit n) (hr : C.Reduced)
    (hc : ∀ v, C.eval v = f v) (hE2 : E2 f)
    (hess : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential f z)
    {k : Nat} {g : Table} {a b : Nat} (hk : C.gateAt k = some (g, a, b)) (ha : a < n)
    (hb : b < n) {k₂ : Nat} (hk₂ : k₂ ∈ C.users k) : C.isDGate k₂ = false := by
  cases hd : C.isDGate k₂ with
  | false => rfl
  | true =>
    exfalso
    obtain ⟨g₂, a₂, b₂, hg₂, hab₂⟩ := (C.isDGate_iff k₂).mp hd
    obtain ⟨g₂', a₂', b₂', hg₂', hkin⟩ := C.mem_users.mp hk₂
    rw [hg₂] at hg₂'
    cases hg₂'
    have hkn : n ≤ k := (C.gateAt_bounds hk).1
    rcases hab₂ with ⟨ha₂, hDa⟩ | ⟨hb₂, hDb⟩
    · -- the D-operand is the left operand a₂, so k is the right operand
      rcases hkin with hka | hkb
      · omega
      · rw [hkb] at hg₂
        exact forbid_b_core f C hr hc hE2 hess hk ha hb ⟨a₂, ha₂⟩ hDa (Or.inr hg₂)
    · rcases hkin with hka | hkb
      · rw [hka] at hg₂
        exact forbid_b_core f C hr hc hE2 hess hk ha hb ⟨b₂, hb₂⟩ hDb (Or.inl hg₂)
      · omega

/-- F3: under a one-input restriction, a gate that becomes constant is not the D-gate of a
D-variable other than the fixed input. -/
theorem forbid_const {n : Nat} (f : (Fin n → Bool) → Bool) (C : OpenCircuit n)
    (hc : ∀ v, C.eval v = f v) (hE1 : E1 f)
    (hess : ∀ z : Fin n, 0 < C.usage (singleUse z) → Essential f z)
    (x : Fin n) (b : Bool) (hx : C.isD x.val = false) {k : Nat}
    (hk : (C.resAt (singleRes x b) k).isConst = true) : C.isDGate k = false := by
  cases hd : C.isDGate k with
  | false => rfl
  | true =>
    exfalso
    obtain ⟨g, a, b', hg, hab⟩ := (C.isDGate_iff k).mp hd
    have key : ∀ z : Fin n, C.isD z.val = true → (a = z.val ∨ b' = z.val) → False := by
      intro z hDz hzk
      have hzx : z ≠ x := by
        intro he
        rw [he, hx] at hDz
        contradiction
      exact dvar_reader_not_const f C hc hE1 hess x b z hzx hDz
        (C.mem_users.mpr ⟨g, a, b', hg, hzk⟩) hk
    rcases hab with ⟨ha, hDa⟩ | ⟨hb, hDb⟩
    · exact key ⟨a, ha⟩ hDa (Or.inl rfl)
    · exact key ⟨b', hb⟩ hDb (Or.inr rfl)

end OpenCircuit
end SatLowerBound
