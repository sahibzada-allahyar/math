import Credit.Composition

/-!
# Credit.Assembly: from the composition theorem to the sparse SAT restriction

Mirrors `CertificateAssembly.lean` and `Main.lean` of the 7/3 development.
-/

namespace SatLowerBound

theorem sparseLeaf_valid4 (k r : Nat) (hr : 4 ≤ r) (c : Fin k) (s : Fin 3) :
    (sparseLeaf k r c s).Valid 4 := by
  change 4 ≤ (blockSupport k r c s).card
  rw [blockSupport_card k r (by omega)]
  exact hr

theorem sparseClauseTree_valid4 (k r : Nat) (hr : 4 ≤ r) (c : Fin k) :
    (sparseClauseTree k r c).Valid 4 := by
  apply joinTrees_valid
  · exact sparseLeaf_valid4 k r hr c
  · intro s t hst
    exact blockSupport_disjoint k r (by omega) c c s t (Or.inr hst)

theorem sparseTree_valid4 (k r : Nat) (hr : 4 ≤ r) : (sparseTree k r).Valid 4 := by
  apply joinTrees_valid
  · exact sparseClauseTree_valid4 (k + 1) r hr
  · exact sparseClauses_disjoint (k + 1) r (by omega)

/-- The potential bound for the concrete sparse target. -/
def PsiSparseBound (w r : Nat) : Prop :=
  ∀ D : OpenCircuit (freeBits w r), (∀ x, D.eval x = sparseFunction w r x) →
    10 * (freeBits w r : Int) - 24 * (3 * (remainingClauses w r : Int)) - 3 ≤ D.psi

theorem psi_sparse_layout (k r : Nat) (hk : 0 < k) (hr : 4 ≤ r) (C : OpenCircuit (k * 3 * r))
    (hc : ∀ v, C.eval v = decide (∀ c : Fin k, ∃ s : Fin 3,
      helperBlock r (fun b => v (pairIndex (pairIndex c s) b)) = true)) :
    10 * ((k * 3 * r : Nat) : Int) - 24 * (3 * (k : Int)) - 3 ≤ C.psi := by
  obtain ⟨j, hj⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hk)
  rw [Nat.succ_eq_add_one] at hj
  subst hj
  have hcomp (v : Fin ((j + 1) * 3 * r) → Bool) : C.eval v = (sparseTree j r).eval v := by
    rw [sparseTree_eval j r (by omega)]
    exact hc v
  have h := psi_modular_composition (sparseTree j r) (sparseTree_valid4 j r hr) C hcomp
  rw [sparseTree_inputs j r (by omega), sparseTree_blocks] at h
  omega

theorem psi_sparse_bound (w r : Nat) (hr : 4 ≤ r) (hrw : r < w) : PsiSparseBound w r := by
  intro D hD
  have hk := remainingClauses_pos w r hrw (by omega)
  apply psi_sparse_layout (remainingClauses w r) r hk hr D
  intro v
  exact hD v

/-- `5|D| ≥ 12L - 24B - 5` for every circuit computing the sparse target
(normalization, `5|C| = Ψ + 2A + D`, and `A ≥ L - 1`). -/
theorem sparse_size_of_psi (w r : Nat) (hr0 : 0 < r) (hpsi : PsiSparseBound w r)
    (D : OpenCircuit (freeBits w r)) (hD : ∀ x, D.eval x = sparseFunction w r x) :
    12 * (freeBits w r : Int) - 24 * (3 * (remainingClauses w r : Int)) - 5 ≤
      5 * (D.size : Int) := by
  obtain ⟨E, hEr, _, hEs, _, hEe⟩ := OpenCircuit.normalize_by_descent D
  have hE : ∀ x, E.eval x = sparseFunction w r x := fun x => (hEe x).trans (hD x)
  have hb := hpsi E hE
  have hA := E.nonlinear_lower_bound _ hE (sparseFunction_full_degree w r hr0)
  have h5 := E.psi_add_two_nonlinear_le (E.reduced_essential hEr)
  omega

theorem certificate_of_psi (w r : Nat) (hw : 8 ≤ w) (hr4 : 4 ≤ r) (hr : r < w)
    (hpsi : PsiSparseBound w r) (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    5 * inputBits w + (21 * r - 72) * remainingClauses w r ≤ 5 * C.size + 5 := by
  obtain ⟨D, hD, hdel⟩ := sat_sparse_transfer w r (by omega) hr (by omega) C hc
  have hsize := sparse_size_of_psi w r (by omega) hpsi D hD
  have hL := freeBits_le_inputBits w r hr
  have hdim : freeBits w r = 3 * (r * remainingClauses w r) := by
    rw [freeBits_eq, Nat.mul_assoc, Nat.mul_comm (remainingClauses w r) r]
  have hcharge : (21 * r - 72) * remainingClauses w r + 72 * remainingClauses w r =
      21 * (r * remainingClauses w r) := by
    rw [← Nat.add_mul, Nat.sub_add_cancel (by omega : 72 ≤ 21 * r), Nat.mul_assoc]
  omega

end SatLowerBound
