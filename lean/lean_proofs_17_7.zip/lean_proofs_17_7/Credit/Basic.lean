import SatLowerBound.Main
import SatLowerBound.PdfNormalization



namespace SatLowerBound

namespace Table

/-- Gate weight in `Ψ`: `5` for parity gates, `3` for nonlinear gates, `0` otherwise. -/
def psiW (g : Table) : Nat := 5 * g.parityCount + 3 * g.nonlinearCount

theorem psiW_eq_ofWeight (g : Table) :
    g.psiW = if g.weight = 3 then 5 else if g.weight = 2 then 3 else 0 := by
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem weight_cases (g : Table) : g.weight = 0 ∨ g.weight = 2 ∨ g.weight = 3 := by
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem psiW_mono (g h : Table) (hw : g.weight ≤ h.weight) : g.psiW ≤ h.psiW := by
  rw [psiW_eq_ofWeight, psiW_eq_ofWeight]
  rcases weight_cases g with hg | hg | hg <;> rcases weight_cases h with hh | hh | hh <;>
    rw [hg, hh] at hw <;> simp [hg, hh] <;> omega

theorem psiW_essential (g : Table) (h : g.essential = true) :
    g.psiW = 3 + 2 * g.parityCount := by
  revert h
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem psiW_le_five (g : Table) : g.psiW ≤ 5 := by
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem parityCount_add_nonlinearCount (g : Table) (h : g.essential = true) :
    g.parityCount + g.nonlinearCount = 1 := by
  revert h
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem nonlinear_essential (g : Table) (h : g.nonlinear = true) : g.essential = true := by
  revert h
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem parity_essential (g : Table) (h : g.parity = true) : g.essential = true := by
  revert h
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem essential_parity_or_nonlinear (g : Table) (h : g.essential = true) :
    g.parity = true ∨ g.nonlinear = true := by
  revert h
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

end Table

theorem twist_essential (g : Table) (a b : Bool) : (twist g a b).essential = g.essential := by
  rcases g with ⟨c, d, e, f⟩
  cases a <;> cases b <;> cases c <;> cases d <;> cases e <;> cases f <;> decide

theorem twist_parity (g : Table) (a b : Bool) : (twist g a b).parity = g.parity := by
  rcases g with ⟨c, d, e, f⟩
  cases a <;> cases b <;> cases c <;> cases d <;> cases e <;> cases f <;> decide

theorem twist_nonlinear (g : Table) (a b : Bool) : (twist g a b).nonlinear = g.nonlinear := by
  rcases g with ⟨c, d, e, f⟩
  cases a <;> cases b <;> cases c <;> cases d <;> cases e <;> cases f <;> decide

theorem twist_psiW (g : Table) (a b : Bool) : (twist g a b).psiW = g.psiW := by
  rcases g with ⟨c, d, e, f⟩
  cases a <;> cases b <;> cases c <;> cases d <;> cases e <;> cases f <;> decide

/-! ## Semantic hypotheses of the manuscript (Section 4) -/

/-- (E1): fixing one coordinate keeps every other essential coordinate essential. -/
def E1 {n : Nat} (f : (Fin n → Bool) → Bool) : Prop :=
  ∀ (x : Fin n) (b : Bool) (z : Fin n), z ≠ x → Essential f z →
    Essential (fun v => f (fixBit x b v)) z

/-- (E2): fixing two coordinates keeps every other essential coordinate essential. -/
def E2 {n : Nat} (f : (Fin n → Bool) → Bool) : Prop :=
  ∀ (x y : Fin n) (a b : Bool) (z : Fin n), x ≠ y → z ≠ x → z ≠ y → Essential f z →
    Essential (fun v => f (setPair v x y a b)) z

/-- (S3): every pair of essential coordinates has three distinct pair cofactors. -/
def S3 {n : Nat} (f : (Fin n → Bool) → Bool) : Prop :=
  ∀ x y : Fin n, x ≠ y → Essential f x → Essential f y → PairSeparated f x y

/-- The hypotheses of Main Lemma A on the computed function. -/
structure GoodFn {n : Nat} (f : (Fin n → Bool) → Bool) : Prop where
  two_essential : ∃ x y : Fin n, x ≠ y ∧ Essential f x ∧ Essential f y
  e1 : E1 f
  e2 : E2 f
  s3 : S3 f
  cofactor_nonconstant : ∀ (x : Fin n) (b : Bool), Nonconstant (fun v => f (fixBit x b v))

theorem Essential.nonconstant {n : Nat} {f : (Fin n → Bool) → Bool} {x : Fin n}
    (h : Essential f x) : Nonconstant f := by
  obtain ⟨u, v, _, huv⟩ := h
  exact ⟨u, v, huv⟩

theorem GoodFn.nonconstant {n : Nat} {f : (Fin n → Bool) → Bool} (hf : GoodFn f) :
    Nonconstant f := by
  obtain ⟨x, _, _, hx, _⟩ := hf.two_essential
  exact hx.nonconstant

/-! ## Abstract model of the restriction compiler -/

/-- Resolved signal of an original signal: a constant, or a literal of an original source
(a free input or a kept gate, by global index). -/
inductive Res where
  | const (b : Bool)
  | lit (src : Nat) (neg : Bool)
  deriving DecidableEq

namespace Res

/-- Mirror of `Signal.unary`. -/
def unary (f : Bool → Bool) (s : Nat) : Res :=
  if f false = f true then .const (f false) else .lit s (f false)

/-- Mirror of `simplifyGate` followed by `GateStep.classify`: `some r` means the gate is
bypassed and resolves to `r`; `none` means the gate is kept. -/
def step (g : Table) : Res → Res → Option Res
  | .const a, .const b => some (.const (g.eval a b))
  | .const a, .lit j nb => some (unary (fun y => g.eval a (Bool.xor y nb)) j)
  | .lit i na, .const b => some (unary (fun x => g.eval (Bool.xor x na) b) i)
  | .lit i na, .lit j nb =>
      if i = j then some (unary (fun x => g.eval (Bool.xor x na) (Bool.xor x nb)) i)
      else if (twist g na nb).ff = (twist g na nb).tf ∧ (twist g na nb).ft = (twist g na nb).tt then
        some (unary (fun y => (twist g na nb).eval false y) j)
      else if (twist g na nb).ff = (twist g na nb).ft ∧ (twist g na nb).tf = (twist g na nb).tt then
        some (unary (fun x => (twist g na nb).eval x false) i)
      else none

/-- `r` is a literal of the source `s`. -/
def hits : Res → Nat → Bool
  | .const _, _ => false
  | .lit t _, s => t == s

def isConst : Res → Bool
  | .const _ => true
  | .lit _ _ => false

end Res

/-! ## Restrictions fixing a set of inputs -/

/-- Fix the inputs in `P` to the values `c`; keep all other inputs. -/
def fixSubst {n : Nat} (P c : Fin n → Bool) : Fin n → Signal n :=
  fun z => if P z = true then .constant (c z) else .wire z false

/-- The abstract initial resolution matching `fixSubst`. -/
def fixRes {n : Nat} (P c : Fin n → Bool) : Fin n → Res :=
  fun z => if P z = true then .const (c z) else .lit z.val false

/-- The abstract initial resolution matching `singleSubst x b`. -/
def singleRes {n : Nat} (x : Fin n) (b : Bool) : Fin n → Res :=
  fixRes (fun z => decide (z = x)) (fun _ => b)

theorem singleSubst_eq_fixSubst {n : Nat} (x : Fin n) (b : Bool) :
    singleSubst x b = fixSubst (fun z => decide (z = x)) (fun _ => b) := by
  funext z
  by_cases h : z = x <;> simp [singleSubst, fixSubst, h]

theorem pairSubst_eq_fixSubst {n : Nat} (x y : Fin n) (a b : Bool) :
    pairSubst x y a b =
      fixSubst (fun z => decide (z = x) || decide (z = y)) (fun z => if z = x then a else b) := by
  funext z
  by_cases hx : z = x
  · simp [pairSubst, fixSubst, hx]
  · by_cases hy : z = y
    · subst hy
      simp [pairSubst, fixSubst, hx]
    · simp [pairSubst, fixSubst, hx, hy]

namespace OpenCircuit

/-! ## Gate counts and the gate part of the potential -/

def parityCount : {n : Nat} → OpenCircuit n → Nat
  | _, .output _ => 0
  | _, .gate g _ _ rest => g.parityCount + rest.parityCount

/-- `5X + 3A`, counted over all gates (degenerate gates contribute `0`). -/
def psiWeight : {n : Nat} → OpenCircuit n → Nat
  | _, .output _ => 0
  | _, .gate g _ _ rest => g.psiW + rest.psiWeight

/-! ## Flat view with global indices -/

/-- The gate with global index `k`, as `(table, left operand, right operand)`. -/
def gateAt : {n : Nat} → OpenCircuit n → Nat → Option (Table × Nat × Nat)
  | _, .output _, _ => none
  | n, .gate g i j rest, k => if k = n then some (g, i.val, j.val) else rest.gateAt k

/-- The global index and sign of the output wire; `none` for a constant output. -/
def outWire : {n : Nat} → OpenCircuit n → Option (Nat × Bool)
  | _, .output (.constant _) => none
  | _, .output (.wire i b) => some (i.val, b)
  | _, .gate _ _ _ rest => rest.outWire

/-- Number of references to global signal `k`: operand slots of gates and the output. -/
def refCount : {n : Nat} → OpenCircuit n → Nat → Nat
  | _, .output (.constant _), _ => 0
  | _, .output (.wire i _), k => if i.val = k then 1 else 0
  | _, .gate _ i j rest, k =>
      (if i.val = k then 1 else 0) + (if j.val = k then 1 else 0) + rest.refCount k

/-- The first gate reading global signal `k` has a nonlinear table. -/
def firstUserNL : {n : Nat} → OpenCircuit n → Nat → Bool
  | _, .output _, _ => false
  | _, .gate g i j rest, k => if i.val = k ∨ j.val = k then g.nonlinear else rest.firstUserNL k

/-- Gate `k` reads signal `s`. -/
def usesAt {n : Nat} (C : OpenCircuit n) (k s : Nat) : Bool :=
  match C.gateAt k with
  | some (_, a, b) => a == s || b == s
  | none => false

/-- Global indices of the gates reading signal `s` (its direct successors). -/
def users {n : Nat} (C : OpenCircuit n) (s : Nat) : Finset Nat :=
  (Finset.range (n + C.size)).filter (fun k => C.usesAt k s = true)

/-- The table of gate `k` (an arbitrary default if `k` is not a gate). -/
def tableAt {n : Nat} (C : OpenCircuit n) (k : Nat) : Table :=
  match C.gateAt k with
  | some (g, _, _) => g
  | none => ⟨false, false, false, false⟩

/-- `psiW` of gate `k` (`0` if `k` is not a gate). -/
def gatePsiW {n : Nat} (C : OpenCircuit n) (k : Nat) : Nat :=
  match C.gateAt k with
  | some (g, _, _) => g.psiW
  | none => 0

/-- Value of every global signal under the input assignment `x` (`false` beyond the circuit). -/
def valueAt : {n : Nat} → OpenCircuit n → (Fin n → Bool) → Nat → Bool
  | n, .output _, x, k => if h : k < n then x ⟨k, h⟩ else false
  | _, .gate g i j rest, x, k => rest.valueAt (extend x (g.eval (x i) (x j))) k

/-! ## D-variables and the potential -/

/-- Signal `k` has exactly one reference, and it is an operand of a nonlinear gate.
For a primary input this is the manuscript's D-variable. -/
def isD {n : Nat} (C : OpenCircuit n) (k : Nat) : Bool :=
  decide (C.refCount k = 1) && C.firstUserNL k

/-- Number of D-variables among the primary inputs. -/
def dCount {n : Nat} (C : OpenCircuit n) : Nat := ∑ z : Fin n, indicator (C.isD z.val)

/-- The potential `Ψ = 5X + 3A - D`. -/
def psi {n : Nat} (C : OpenCircuit n) : Int := (C.psiWeight : Int) - (C.dCount : Int)

/-- Gate `k` is the D-gate of one of its primary operands. -/
def isDGate {n : Nat} (C : OpenCircuit n) (k : Nat) : Bool :=
  match C.gateAt k with
  | some (_, a, b) => (decide (a < n) && C.isD a) || (decide (b < n) && C.isD b)
  | none => false

/-- Lemma `forbid`(a) of the manuscript as a structural property: a gate both of whose
operands are primary inputs is not the D-gate of either of them. -/
def DGateSafe {n : Nat} (C : OpenCircuit n) : Prop :=
  ∀ (k : Nat) (g : Table) (a b : Nat), C.gateAt k = some (g, a, b) → a < n → b < n →
    C.isD a = false ∧ C.isD b = false

/-- Number of primary inputs that are D-variables of `D` but not of `C`. -/
def gainedCount {n : Nat} (C D : OpenCircuit n) : Nat :=
  ∑ z : Fin n, indicator (D.isD z.val && !C.isD z.val)

/-- Fixing input `x` to `b` lowers `Ψ` by at least `d` (no renormalization is applied). -/
def DropsAt {n : Nat} (C : OpenCircuit n) (x : Fin n) (b : Bool) (d : Int) : Prop :=
  (C.restrict (singleSubst x b)).psi + d ≤ C.psi

/-! ## The abstract restriction trace -/

/-- Resolution of every global signal; inputs are resolved by `ρ`. -/
def resAt : {n : Nat} → OpenCircuit n → (Fin n → Res) → Nat → Res
  | n, .output _, ρ, k => if h : k < n then ρ ⟨k, h⟩ else .const false
  | n, .gate g i j rest, ρ, k =>
      rest.resAt (appendValue ρ ((Res.step g (ρ i) (ρ j)).getD (.lit n false))) k

/-- Gate `k` survives the restriction. -/
def isKept {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) (k : Nat) : Bool :=
  match C.gateAt k with
  | some (g, a, b) => (Res.step g (C.resAt ρ a) (C.resAt ρ b)).isNone
  | none => false

/-- Gate `k` is eliminated (bypassed or constant) by the restriction. -/
def isAliased {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) (k : Nat) : Bool :=
  match C.gateAt k with
  | some (g, a, b) => (Res.step g (C.resAt ρ a) (C.resAt ρ b)).isSome
  | none => false

/-- Number of kept gates. -/
def keptCount : {n : Nat} → OpenCircuit n → (Fin n → Res) → Nat
  | _, .output _, _ => 0
  | n, .gate g i j rest, ρ =>
      match Res.step g (ρ i) (ρ j) with
      | some r => rest.keptCount (appendValue ρ r)
      | none => rest.keptCount (appendValue ρ (.lit n false)) + 1

/-- Number of eliminated gates. -/
def aliasedCount : {n : Nat} → OpenCircuit n → (Fin n → Res) → Nat
  | _, .output _, _ => 0
  | n, .gate g i j rest, ρ =>
      match Res.step g (ρ i) (ρ j) with
      | some r => rest.aliasedCount (appendValue ρ r) + 1
      | none => rest.aliasedCount (appendValue ρ (.lit n false))

/-- `psiW` summed over kept gates. -/
def keptPsiWeight : {n : Nat} → OpenCircuit n → (Fin n → Res) → Nat
  | _, .output _, _ => 0
  | n, .gate g i j rest, ρ =>
      match Res.step g (ρ i) (ρ j) with
      | some r => rest.keptPsiWeight (appendValue ρ r)
      | none => g.psiW + rest.keptPsiWeight (appendValue ρ (.lit n false))

/-- `psiW` summed over eliminated gates. -/
def aliasedPsiWeight : {n : Nat} → OpenCircuit n → (Fin n → Res) → Nat
  | _, .output _, _ => 0
  | n, .gate g i j rest, ρ =>
      match Res.step g (ρ i) (ρ j) with
      | some r => g.psiW + rest.aliasedPsiWeight (appendValue ρ r)
      | none => rest.aliasedPsiWeight (appendValue ρ (.lit n false))

/-- References to the source `s` in the restricted circuit: operand slots of kept gates
and the output whose resolution is a literal of `s`. -/
def keptRefs : {n : Nat} → OpenCircuit n → (Fin n → Res) → Nat → Nat
  | _, .output (.constant _), _, _ => 0
  | _, .output (.wire i _), ρ, s => indicator ((ρ i).hits s)
  | n, .gate g i j rest, ρ, s =>
      match Res.step g (ρ i) (ρ j) with
      | some r => rest.keptRefs (appendValue ρ r) s
      | none => indicator ((ρ i).hits s) + indicator ((ρ j).hits s) +
          rest.keptRefs (appendValue ρ (.lit n false)) s

/-- In the restricted circuit, the first gate reading the source `s` is nonlinear. -/
def keptFirstNL : {n : Nat} → OpenCircuit n → (Fin n → Res) → Nat → Bool
  | _, .output _, _, _ => false
  | n, .gate g i j rest, ρ, s =>
      match Res.step g (ρ i) (ρ j) with
      | some r => rest.keptFirstNL (appendValue ρ r) s
      | none => if ((ρ i).hits s || (ρ j).hits s) = true then g.nonlinear
          else rest.keptFirstNL (appendValue ρ (.lit n false)) s

/-- The source `s` is a D-variable of the restricted circuit. -/
def keptIsD {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) (s : Nat) : Bool :=
  decide (C.keptRefs ρ s = 1) && C.keptFirstNL ρ s

/-- The output contributes one reference to signal `s`. -/
def outIs {n : Nat} (C : OpenCircuit n) (s : Nat) : Nat :=
  match C.outWire with
  | some (k, _) => if k = s then 1 else 0
  | none => 0

/-- Every gate reads two distinct signals. -/
def DistinctOperands {n : Nat} (C : OpenCircuit n) : Prop :=
  ∀ (k : Nat) (g : Table) (a b : Nat), C.gateAt k = some (g, a, b) → a ≠ b

/-- Operand slots of the gate `k`, if kept, whose resolution is a literal of `s`. -/
def keptSlotHits {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) (k s : Nat) : Nat :=
  match C.gateAt k with
  | some (_, a, b) =>
      if C.isKept ρ k = true then
        indicator ((C.resAt ρ a).hits s) + indicator ((C.resAt ρ b).hits s)
      else 0
  | none => 0

/-- The output, after restriction, is a literal of `s`. -/
def outHits {n : Nat} (C : OpenCircuit n) (ρ : Fin n → Res) (s : Nat) : Nat :=
  match C.outWire with
  | some (k, _) => indicator ((C.resAt ρ k).hits s)
  | none => 0

/-! ## Elementary facts -/

theorem psiWeight_eq {n : Nat} (C : OpenCircuit n) :
    C.psiWeight = 5 * C.parityCount + 3 * C.nonlinearCount := by
  induction C with
  | output => rfl
  | gate g i j rest ih =>
    simp only [psiWeight, parityCount, nonlinearCount, Table.psiW, ih]
    omega

theorem size_eq_counts {n : Nat} (C : OpenCircuit n) (he : C.EssentialGates) :
    C.size = C.parityCount + C.nonlinearCount := by
  induction C with
  | output => rfl
  | gate g i j rest ih =>
    have hg := g.parityCount_add_nonlinearCount he.1
    have hr := ih he.2
    simp only [size, parityCount, nonlinearCount]
    omega

theorem five_size {n : Nat} (C : OpenCircuit n) (he : C.EssentialGates) :
    5 * C.size = C.psiWeight + 2 * C.nonlinearCount := by
  rw [psiWeight_eq, size_eq_counts C he]
  omega

theorem dCount_le {n : Nat} (C : OpenCircuit n) : C.dCount ≤ n := by
  unfold dCount
  calc (∑ z : Fin n, indicator (C.isD z.val)) ≤ ∑ _z : Fin n, 1 := by
        apply Finset.sum_le_sum
        intro z _
        unfold indicator
        split <;> omega
    _ = n := by simp

theorem psi_le_psiWeight {n : Nat} (C : OpenCircuit n) : C.psi ≤ C.psiWeight := by
  unfold psi
  omega

theorem neg_le_psi {n : Nat} (C : OpenCircuit n) : -(n : Int) ≤ C.psi := by
  unfold psi
  have h := C.dCount_le
  omega

/-- For an essential-gate circuit, `5|C| ≥ Ψ + 2A`. -/
theorem psi_add_two_nonlinear_le {n : Nat} (C : OpenCircuit n) (he : C.EssentialGates) :
    C.psi + 2 * (C.nonlinearCount : Int) ≤ 5 * (C.size : Int) := by
  have h := C.five_size he
  unfold psi
  omega

end OpenCircuit

/-- The hypotheses of Main Lemma A on a circuit `C` for `f`. -/
structure MAContext {n : Nat} (f : (Fin n → Bool) → Bool) (C : OpenCircuit n) : Prop where
  good : GoodFn f
  reduced : C.Reduced
  noTriangles : C.NoInputTriangles (fun _ => none)
  computes : ∀ v, C.eval v = f v
  usedEssential : ∀ z : Fin n, 0 < C.usage (OpenCircuit.singleUse z) → Essential f z

end SatLowerBound
