Lean proof package: 17/7 circuit lower bound for binary-encoded 3-SAT

Lean 4.35.0; Mathlib and transitive dependencies are pinned in lake-manifest.json.
From this directory, with Lean and Lake installed:

lake exe cache get
lake build Credit
lake env lean -DwarningAsError=true Credit/TwoLevel/AuditBasic.lean
lake env lean -DwarningAsError=true Credit/Audit125.lean

Main statements:
Credit/TwoLevel/ManuscriptTheorem.lean: finite ceiling and logarithmic bounds,
including arbitrary acyclic circuits with graph-equation semantics.
Credit/TwoLevel/WeightedGraphBound.lean: weighted construction bound.
Credit/TwoLevel/ManuscriptConditions.lean: manuscript E2 and elimination interface.
Credit/TwoLevel/WeightedPrimeMachine.lean: uniform construction and cost bounds.

The audit permits only propext, Classical.choice and Quot.sound; it rejects
sorryAx and custom axioms. Algorithm costs use an explicit sequential
Boolean-list/unary-counter model, not native Lean execution timings.
The accompanying 7/3 and 12/5 sources are dependencies of this development.
The manuscript correspondence review used the original mathematical manuscript
SHA-256 3add7ce069dafc22cd13cfc923d596edf43693098a8b67e7a25ede4b82fbcf63.
The public paper includes later editorial and affiliation revisions.
