Lean source package: 7/3

7/3 finite and asymptotic lower bounds; see README-Consolidated.txt for theorem names and exact scope.

Pinned Lean: v4.35.0. Mathlib revision is pinned in lakefile.toml and lake-manifest.json.
Extract this archive and run from this directory:

lake exe cache get
lake build SatLowerBound Audit
lake env lean Consolidated.lean
lake env lean AuditConsolidated.lean

Source snapshot from P_vs_NP on 2026-11-02. The 12/5 package includes its 7/3 source dependencies.
The TwoLevel/17/7 work is deliberately excluded. These archives do not constitute a Lean verification of the 17/7 paper.
Historical verification records remain in the source repository. This distribution contains the proof sources and build instructions, without development diaries or historical logs. Packaging checks cover archive integrity and local imports. A fresh build of this distribution has not been run; use the commands above to verify it with the pinned toolchain.
