import SatLowerBound
import Lean

open Lean Elab Command

/- Audit every declaration in our mathematical namespace, including definitions.
This command adds no declarations and proves no propositions. It only rejects
dependencies outside the explicitly stated foundational allowlist. -/
run_cmd do
  let env ← getEnv
  let allowed : Array Name := #[``propext, ``Quot.sound, ``Classical.choice]
  let mut checked : Nat := 0
  for (name, info) in env.constants.toList do
    let ownModule := match env.getModuleIdxFor? name with
      | some idx => (`SatLowerBound).isPrefixOf env.header.moduleNames[idx]!
      | none => false
    if ownModule then
      if info matches .axiomInfo _ then
        throwError "Custom axiom declaration: {name}"
      let axioms ← collectAxioms name
      for ax in axioms do
        unless allowed.contains ax do
          throwError "Forbidden axiom {ax} in dependency closure of {name}"
      checked := checked + 1
  if checked == 0 then throwError "No project declarations were audited"
  logInfo m!"Axiom audit passed for {checked} project declarations, including private declarations."

/- The completion check compares the exact closed type. An extra weighted-bound
premise cannot pass this check. Absence is reported explicitly, never certified. -/
run_cmd do
  let env ← getEnv
  match env.find? `SatLowerBound.main_lower_bound with
  | none => throwError "The required unconditional finite certificate is missing"
  | some (.thmInfo info) =>
    liftTermElabM do
      unless ← Meta.isDefEq info.type (mkConst ``SatLowerBound.ExactCertificate) do
        throwError "main_lower_bound does not have the exact unconditional certificate type"
    logInfo "FINAL_CERTIFICATE_VERIFIED"
  | some _ => throwError "main_lower_bound must be a proved theorem"

run_cmd do
  let env ← getEnv
  match env.find? `SatLowerBound.asymptotic_leading_coefficient with
  | some (.thmInfo info) =>
    liftTermElabM do
      unless ← Meta.isDefEq info.type (mkConst ``SatLowerBound.AsymptoticCertificate) do
        throwError "The asymptotic theorem does not have the required closed type"
    logInfo "ASYMPTOTIC_CERTIFICATE_VERIFIED"
  | _ => throwError "The proved asymptotic theorem is missing"

run_cmd do
  let env ← getEnv
  for (theoremName, expectedType, marker) in #[
      (`SatLowerBound.logarithmic_lower_bound, ``SatLowerBound.LogarithmicCertificate,
        "LOGARITHMIC_CERTIFICATE_VERIFIED"),
      (`SatLowerBound.logarithmic_asymptotic, ``SatLowerBound.LogarithmicAsymptoticCertificate,
        "LOGARITHMIC_ASYMPTOTIC_VERIFIED")] do
    match env.find? theoremName with
    | some (.thmInfo info) =>
      liftTermElabM do
        unless ← Meta.isDefEq info.type (mkConst expectedType) do
          throwError "{theoremName} does not have the required closed type"
      logInfo m!"{marker}"
    | _ => throwError "The proved logarithmic theorem {theoremName} is missing"

#print axioms SatLowerBound.satFunction_eq_true_iff
#print axioms SatLowerBound.invalid_eq_false
#print axioms SatLowerBound.Table.triangle_weight
#print axioms SatLowerBound.Circuit.resource_le
#print axioms SatLowerBound.Circuit.rename_eval
#print axioms SatLowerBound.helper_count_exact
#print axioms SatLowerBound.every_encoding_bit_essential
#print axioms SatLowerBound.Circuit.nonlinear_lower_bound
#print axioms SatLowerBound.OpenCircuit.nonlinear_lower_bound
#print axioms SatLowerBound.sparseFunction_full_degree
#print axioms SatLowerBound.sparseRestriction_sat
#print axioms SatLowerBound.fixed_coordinate_count
#print axioms SatLowerBound.sat_sparse_transfer
#print axioms SatLowerBound.certificate_of_weighted
#print axioms SatLowerBound.OpenCircuit.first_gate_multiple_use
#print axioms SatLowerBound.circuit_parity_weight_lower_bound
#print axioms SatLowerBound.OpenCircuit.normalize_full
#print axioms SatLowerBound.OpenCircuit.propagation_weight_gain_nonconstant
#print axioms SatLowerBound.OpenCircuit.six_or_seven
#print axioms SatLowerBound.OpenCircuit.two_input_retirement
#print axioms SatLowerBound.OpenCircuit.parity_retirement
#print axioms SatLowerBound.OpenCircuit.minimal_six_or_seven
#print axioms SatLowerBound.weighted_modular_composition
#print axioms SatLowerBound.modularBlock_exact_degree
#print axioms SatLowerBound.ModularTree.defects_eq_algebraicDefects
#print axioms SatLowerBound.weighted_modular_composition_algebraic
#print axioms SatLowerBound.full_modular_composition_ceiling
#print axioms SatLowerBound.mod3_field_product
#print axioms SatLowerBound.tex_every_encoding_bit_essential
#print axioms SatLowerBound.weighted_sparse_bound
#print axioms SatLowerBound.main_lower_bound
#print axioms SatLowerBound.asymptotic_leading_coefficient
#print SatLowerBound.ExactCertificate
#print SatLowerBound.AsymptoticCertificate
#print axioms SatLowerBound.logarithmic_lower_bound
#print axioms SatLowerBound.logarithmic_asymptotic
#print SatLowerBound.LogarithmicCertificate
#print SatLowerBound.LogarithmicAsymptoticCertificate
