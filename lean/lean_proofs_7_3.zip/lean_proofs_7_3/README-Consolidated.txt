SINGLE-FILE PROOF: Consolidated.lean

All 67 project modules and the mathematical statement/nonvacuity appendix are
consolidated into this one file. Only Std/Mathlib libraries are imported.
The modular version is preserved in SatLowerBound/*.lean. Do not import both
versions into one environment: they intentionally use the same names.

READING ORDER

1. Circuit model and exact binary encoding.
2. Definitions, gate classification, polynomial representation, coefficients,
   and numerical degree including degree(0)=0.
3. Descending normalization and restriction accounting, with an explicit
   conversion of normalized auxiliary circuits into ordinary circuits.
4. MOD-3 coefficient recurrence, exact degree, and deficiency correspondence.
5. Essentiality and pair-cofactor separation for compositions.
6. Six-or-seven deletion and two-input/parity retirement.
7. Weighted composition induction.
8. Nonlinear-gate degree and the generic composition ceiling bound.
9. Sparse embedding with helpers in increasing numeric identifier order.
10. The PDF's valid-instance essentiality witnesses.
11. Finite bound and the PDF's asymptotic estimates (30)-(34).
12. Expanded statements, minimum/maximum interpretation, and nonvacuity.

Technical prerequisites appear before use. The earlier finite-field and complex
root calculations remain as extra proved results; the final finite theorem now
uses the coefficient and helper-count recurrences found in the PDF.

PRINCIPAL RESULTS

SatLowerBound.main_lower_bound: exact finite parameter bound.
IndependentAudit.tex_minimum_and_maximum: attained minimum and maximum over r.
SatLowerBound.PdfAsymptotics.pdf_logarithmic_asymptotic: the PDF asymptotic result,
derived through its equations (30)-(34), with a conservative explicit error
496*n/log_2(n). The PDF leaves this constant unspecified.
SatLowerBound.logarithmic_lower_bound: the previously proved stronger explicit
error 32*n/log_2(n), also retained.

Both asymptotic derivations prove the same 7/3 leading coefficient and 4/3
coefficient of n*log_2(log_2(n))/log_2(n). This is not a finite claim of size>=7n/3.

VERIFY

Use pinned Lean 4.35.0 and the standard dependencies in lake-manifest.json.
Mathlib revision: 56a005855ea17e0b0958f73ec801ae140b0a1679.
From this directory run:

  lake exe cache get
  lake build SatLowerBound Audit
  lake env lean Consolidated.lean
  lake env lean AuditConsolidated.lean

Only foundational axioms propext, Classical.choice, Quot.sound are allowed.
AuditConsolidated.lean is a separate audit harness; no mathematical theorem in
Consolidated.lean depends on that harness.

The modular sources are included alongside the consolidated file.
See README.txt for the scope and verification status of this distribution.
