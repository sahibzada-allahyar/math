import Consolidated
import Lean

open Lean Elab Command

-- This external audit adds no mathematical assumptions or proof declarations.
-- It checks module provenance, including private and generated declarations.
run_cmd do
  let env ← getEnv
  let some moduleIdx := env.getModuleIdx? `Consolidated
    | throwError "Consolidated module is missing"
  for moduleName in env.header.moduleNames do
    if (`SatLowerBound).isPrefixOf moduleName then
      throwError "Unexpected custom proof import: {moduleName}"
  let allowed : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let mut checked := 0
  for (name, info) in env.constants.toList do
    if env.getModuleIdxFor? name == some moduleIdx then
      if info matches .axiomInfo _ then
        throwError "Custom axiom declared in consolidated source: {name}"
      for ax in ← collectAxioms name do
        unless allowed.contains ax do
          throwError "Forbidden dependency {ax} in {name}"
      checked := checked + 1
  if checked == 0 then throwError "No consolidated declarations audited"
  logInfo m!"CONSOLIDATED_AXIOM_AUDIT_PASSED: {checked} declarations, including private declarations."

run_cmd do
  let env ← getEnv
  for (root, expectedType) in #[
      (`SatLowerBound.main_lower_bound, ``SatLowerBound.ExactCertificate),
      (`SatLowerBound.asymptotic_leading_coefficient, ``SatLowerBound.AsymptoticCertificate),
      (`SatLowerBound.logarithmic_lower_bound, ``SatLowerBound.LogarithmicCertificate),
      (`SatLowerBound.logarithmic_asymptotic, ``SatLowerBound.LogarithmicAsymptoticCertificate),
      (`SatLowerBound.PdfAsymptotics.pdf_logarithmic_asymptotic, ``SatLowerBound.LogarithmicAsymptoticCertificate)] do
    let some (.thmInfo info) := env.find? root | throwError "Missing proved theorem: {root}"
    liftTermElabM do
      unless ← Meta.isDefEq info.type (mkConst expectedType) do
        throwError "Unexpected theorem type (possibly an extra premise): {root}"
  for root in #[`IndependentAudit.sat_circuit_exists,
      `IndependentAudit.valid_encoding_roundtrip,
      `IndependentAudit.literal_finite_statement,
      `IndependentAudit.no_truncated_subtraction,
      `IndependentAudit.helper_count_not_rounded,
      `IndependentAudit.tex_minimum_and_maximum,
      `IndependentAudit.literal_logarithmic_statement] do
    let some (.thmInfo _) := env.find? root | throwError "Missing statement check: {root}"
  logInfo "CONSOLIDATED_STATEMENT_AUDIT_PASSED"

-- Require both the new general bridges and their actual use by the final SAT proof.
run_cmd do
  let env ← getEnv
  for root in #[`SatLowerBound.mod3_exact_degree,
      `SatLowerBound.modularBlock_exact_degree,
      `SatLowerBound.modularBlock_deficient_iff,
      `SatLowerBound.ModularTree.defects_eq_algebraicDefects,
      `SatLowerBound.weighted_modular_composition_algebraic,
      `SatLowerBound.Circuit.nonlinear_bound_of_exact_degree,
      `SatLowerBound.full_modular_composition_size,
      `SatLowerBound.tex_identifier_value,
      `SatLowerBound.Circuit.normalize_pdf,
      `SatLowerBound.helper_identifiers_strictMono,
      `SatLowerBound.BPoly.representation_subset_sum,
      `SatLowerBound.coefficient_ofFunction_powerset,
      `SatLowerBound.mod3_coefficient_binomial,
      `SatLowerBound.BPoly.algebraicDegree_zero,
      `SatLowerBound.Table.nonlinear_iff,
      `SatLowerBound.Table.card_parity,
      `SatLowerBound.Table.card_nonlinear,
      `SatLowerBound.full_modular_composition_ceiling] do
    let some (.thmInfo _) := env.find? root | throwError "Missing correspondence theorem: {root}"
  let mut pending := #[`SatLowerBound.main_lower_bound]
  let mut visited : NameSet := {}
  while !pending.isEmpty do
    let name := pending.back!
    pending := pending.pop
    unless visited.contains name do
      visited := visited.insert name
      if let some info := env.find? name then
        for dependency in info.getUsedConstantsAsSet do
          if env.getModuleIdxFor? dependency == env.getModuleIdx? `Consolidated && !visited.contains dependency then
            pending := pending.push dependency
  for required in #[`SatLowerBound.ModularTree.defects_eq_algebraicDefects,
      `SatLowerBound.shifted_top_coefficients,
      `SatLowerBound.shiftedCount_balance,
      `SatLowerBound.forbiddenSuffixes,
      `SatLowerBound.tex_every_encoding_bit_essential,
      `SatLowerBound.OpenCircuit.normalize_by_descent] do
    unless visited.contains required do
      throwError "Final theorem bypasses required manuscript argument: {required}"
  logInfo "CONSOLIDATED_CORRESPONDENCE_AUDIT_PASSED"

run_cmd do
  let env ← getEnv
  let mut pending := #[`SatLowerBound.PdfAsymptotics.pdf_logarithmic_asymptotic]
  let mut visited : NameSet := {}
  while !pending.isEmpty do
    let name := pending.back!
    pending := pending.pop
    unless visited.contains name do
      visited := visited.insert name
      if let some info := env.find? name then
        for dependency in info.getUsedConstantsAsSet do
          if env.getModuleIdxFor? dependency == env.getModuleIdx? `Consolidated && !visited.contains dependency then
            pending := pending.push dependency
  for required in #[`SatLowerBound.PdfAsymptotics.q_exact,
      `SatLowerBound.PdfAsymptotics.ratio_expansion_bound,
      `SatLowerBound.PdfAsymptotics.scaled_log_expansion_bound,
      `SatLowerBound.PdfAsymptotics.width_lower_bound,
      `SatLowerBound.main_lower_bound] do
    unless visited.contains required do
      throwError "PDF asymptotic proof bypasses required derivation: {required}"
  logInfo "PDF_ASYMPTOTIC_DEPENDENCY_AUDIT_PASSED"

#print SatLowerBound.ExactCertificate
#print SatLowerBound.LogarithmicCertificate
#print SatLowerBound.LogarithmicAsymptoticCertificate
#print IndependentAudit.literal_finite_statement
#print IndependentAudit.literal_logarithmic_statement
