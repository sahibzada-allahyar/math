import SatLowerBound.Main
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

namespace SatLowerBound

def AsymptoticCertificate : Prop :=
  ∀ q : Nat, 1 ≤ q → ∃ W : Nat, ∀ w, W ≤ w →
    ∀ C : Circuit (inputBits w), C.Computes (satFunction w) →
      (7 * q - 1) * inputBits w ≤ 3 * q * C.size

theorem fixed_offset_helper_bound (q w r : Nat) (hwr : w = r + 8 * q) :
    8 * q * forbiddenCount r ≤ variableCount w := by
  have hz := helper_count_le r
  have hp : 1 ≤ 2 ^ r := Nat.one_le_two_pow
  have hk : 8 * q + 1 ≤ 2 ^ (8 * q) := Nat.lt_two_pow_self
  have hmul := Nat.mul_le_mul_right (2 ^ r) hk
  have hzmul := Nat.mul_le_mul_left (8 * q) hz
  have he : 2 ^ w = 2 ^ (8 * q) * 2 ^ r := by rw [hwr, Nat.pow_add, Nat.mul_comm]
  unfold variableCount
  rw [he]
  have hbound : 8 * q * forbiddenCount r + 1 ≤ 2 ^ (8 * q) * 2 ^ r := by nlinarith
  omega

theorem certificate_ratio (q w r k m z s : Nat)
    (hq : 1 ≤ q) (hr : 3 ≤ r) (hw : w = r + k)
    (hz : 8 * q * z ≤ m) (hk : 2 * q * (4 * k + 11) ≤ w + 1)
    (hcert : 3 * m * (w + 1) + (4 * r - 7) * (m - z) ≤ s) :
    (7 * q - 1) * (3 * m * (w + 1)) ≤ 3 * q * s := by
  have hzm : z ≤ m := by
    calc
      z = 1 * z := by omega
      _ ≤ 8 * q * z := Nat.mul_le_mul_right z (by omega)
      _ ≤ m := hz
  have ha : 4 * r - 7 + 7 = 4 * r := Nat.sub_add_cancel (by omega)
  have hrem : m - z + z = m := Nat.sub_add_cancel hzm
  have hcoef : 7 * q - 1 + 1 = 7 * q := Nat.sub_add_cancel (by omega)
  have haBound : 4 * r - 7 ≤ 4 * (w + 1) := by omega
  have hzBudget := Nat.mul_le_mul_right (w + 1) hz
  have hkBudget := Nat.mul_le_mul_left m hk
  have hterm := Nat.mul_le_mul_left (2 * q * z) haBound
  have hbudget : q * (4 * r - 7) * z + q * m * (4 * k + 11) ≤ m * (w + 1) := by
    nlinarith [hzBudget, hkBudget, hterm]
  have hidentity : q * (4 * r - 7) * (m - z) + q * (4 * r - 7) * z +
      q * m * (4 * k + 11) = 4 * q * m * (w + 1) := by
    calc
      _ = q * m * ((4 * r - 7) + (4 * k + 11)) := by
        rw [← Nat.mul_add, hrem]
        ring
      _ = 4 * q * m * (w + 1) := by
        have he : (4 * r - 7) + (4 * k + 11) = 4 * (w + 1) := by omega
        rw [he]
        ring
  have hscale := Nat.mul_le_mul_left (3 * q) hcert
  have hcoefScale := congrArg (fun a => a * (3 * m * (w + 1))) hcoef
  nlinarith [hbudget, hidentity, hscale, hcoefScale]

/-- For every positive precision parameter q, all sufficiently large encodings
have circuit-size ratio at least 7/3 - 1/(3q), with the finite +1 convention.
The threshold is explicit; no limit or numerical oracle is used. -/
theorem asymptotic_with_output_offset (q : Nat) (hq : 1 ≤ q) :
    ∃ W : Nat, ∀ w, W ≤ w → ∀ C : Circuit (inputBits w), C.Computes (satFunction w) →
      (7 * q - 1) * inputBits w ≤ 3 * q * (C.size + 1) := by
  let W := 2 * q * (32 * q + 11) + 8 * q + 8
  refine ⟨W, ?_⟩
  intro w hw C hc
  let r := w - 8 * q
  have hw8 : 8 ≤ w := by dsimp [W] at hw; omega
  have hr3 : 3 ≤ r := by dsimp [W] at hw; dsimp [r]; omega
  have hrw : r < w := by dsimp [W] at hw; dsimp [r]; omega
  have hwr : w = r + 8 * q := by dsimp [W] at hw; dsimp [r]; omega
  have hk : 2 * q * (4 * (8 * q) + 11) ≤ w + 1 := by dsimp [W] at hw; nlinarith
  have hz := fixed_offset_helper_bound q w r hwr
  have hb := main_lower_bound w r hw8 hr3 hrw C hc
  exact certificate_ratio q w r (8 * q) (variableCount w) (forbiddenCount r) (C.size + 1)
    hq hr3 hwr hz hk hb

/-- The asymptotic coefficient applies to the actual number of gates, with no
additive output offset in the conclusion. -/
theorem asymptotic_leading_coefficient (q : Nat) (hq : 1 ≤ q) :
    ∃ W : Nat, ∀ w, W ≤ w → ∀ C : Circuit (inputBits w), C.Computes (satFunction w) →
      (7 * q - 1) * inputBits w ≤ 3 * q * C.size := by
  obtain ⟨W, hW⟩ := asymptotic_with_output_offset (2 * q) (by omega)
  refine ⟨max W (2 * q), ?_⟩
  intro w hw C hc
  have hwW : W ≤ w := Nat.le_trans (Nat.le_max_left _ _) hw
  have hwq : 2 * q ≤ w := Nat.le_trans (Nat.le_max_right _ _) hw
  have hm : w ≤ variableCount w := by
    have hp : w < 2 ^ w := Nat.lt_two_pow_self
    unfold variableCount
    omega
  have hn : 6 * q ≤ inputBits w := by
    unfold inputBits
    calc
      6 * q ≤ 3 * variableCount w := by omega
      _ = 3 * variableCount w * 1 := by omega
      _ ≤ 3 * variableCount w * (w + 1) := Nat.mul_le_mul_left _ (by omega)
  have hbound := hW w hwW C hc
  have ha : 7 * (2 * q) - 1 + 1 = 14 * q := by omega
  have hb : 7 * q - 1 + 1 = 7 * q := by omega
  have haN := congrArg (fun a => a * inputBits w) ha
  have hbN := congrArg (fun a => a * inputBits w) hb
  nlinarith [hbound, haN, hbN]

end SatLowerBound
