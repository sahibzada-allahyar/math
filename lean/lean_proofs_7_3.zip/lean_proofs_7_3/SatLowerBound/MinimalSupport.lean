import SatLowerBound.SixOrSeven

namespace SatLowerBound

theorem fixBit_of_not_essential {n : Nat} (f : (Fin n → Bool) → Bool) (x : Fin n)
    (h : ¬ Essential f x) (b : Bool) (v : Fin n → Bool) : f (fixBit x b v) = f v := by
  by_contra hn
  apply h
  refine ⟨fixBit x b v, v, ?_, hn⟩
  intro i hi
  simp [fixBit, hi]

namespace OpenCircuit

/-- A size-minimal circuit at fixed weight uses only essential primary inputs. -/
theorem minimal_used_essential {n : Nat} (C : OpenCircuit n) (f : (Fin n → Bool) → Bool)
    (W : Nat) (hm : Minimal f W C) (hf : Nonconstant f) (x : Fin n)
    (hu : 0 < C.usage (singleUse x)) : Essential f x := by
  by_contra he
  let κ := singlePartial x false
  let σ := singleSubst x false
  have hD : ∀ v, (C.restrict σ).eval v = f v := by
    intro v
    rw [restrict_single_eval, hm.2.1]
    exact fixBit_of_not_essential f x he false v
  have hnon : Nonconstant (C.restrict σ).eval := by
    obtain ⟨u, v, huv⟩ := hf
    exact ⟨u, v, by simpa only [hD] using huv⟩
  have hmarks : MarksConstants κ.mask σ := by
    intro k hk
    by_cases hkx : k = x
    · subst k
      exact ⟨false, by simp [σ, singleSubst]⟩
    · simp [κ, singlePartial, PartialState.mask, hkx] at hk
  have hclose := C.closureOutput_false κ.mask σ hmarks hnon
  have hr := C.minimal_reduced f W hm
  have hsize := C.constant_closure_deletion κ.mask σ hmarks (C.reduced_live hr) hclose
  rw [singlePartial_uses] at hsize
  have hweight := C.restrict_weight_le σ
  have hmin := (hm.2.2 (C.restrict σ) (Nat.le_trans hweight hm.1) hD).1
  omega

/-- An ambient set of unused coordinates causes no difficulty: minimality forces
the first gate to use active coordinates, so separation is needed only there. -/
theorem minimal_six_or_seven {n : Nat} (C : OpenCircuit n) (f : (Fin n → Bool) → Bool)
    (W : Nat) (hm : Minimal f W C) (hf : Nonconstant f)
    (hs : ∀ x y, Essential f x → Essential f y → x ≠ y → PairSeparated f x y)
    (hc : ∀ x, Essential f x → ∀ b, Nonconstant (fun v => f (fixBit x b v))) :
    ∃ x, Essential f x ∧
      ((∀ b, (C.restrict (singleSubst x b)).weight + 6 ≤ C.weight) ∨
        (∃ b, (C.restrict (singleSubst x b)).weight + 7 ≤ C.weight)) := by
  have hr := C.minimal_reduced f W hm
  have ht := C.minimal_no_triangles f W hm
  have hfun : C.eval = f := funext hm.2.1
  cases C with
  | output sig =>
    cases sig with
    | constant b =>
      obtain ⟨u, v, huv⟩ := hf
      rw [← hm.2.1 u, ← hm.2.1 v] at huv
      exact False.elim (huv rfl)
    | wire x c =>
      have hx : Essential f x := minimal_used_essential _ f W hm hf x (by simp [usage, singleUse])
      obtain ⟨u, v, huv⟩ := hc x hx false
      change f (fixBit x false u) ≠ f (fixBit x false v) at huv
      rw [← hm.2.1 _, ← hm.2.1 _] at huv
      simp [eval, Signal.eval, fixBit] at huv
  | gate g i j rest =>
    have hi : Essential f i := minimal_used_essential _ f W hm hf i (by simp [usage, singleUse])
    have hj : Essential f j := minimal_used_essential _ f W hm hf j (by simp [usage, singleUse])
    have hsep : PairSeparated (gate g i j rest).eval i j := by rw [hfun]; exact hs i j hi hj hr.2.1
    rcases first_gate_multiple_use g i j rest hr.2.1 hsep with hu | hu
    · refine ⟨i, hi, six_or_seven_at _ i hr ht hu ?_⟩
      intro b
      simpa only [hfun] using hc i hi b
    · refine ⟨j, hj, six_or_seven_at _ j hr ht hu ?_⟩
      intro b
      simpa only [hfun] using hc j hj b

end OpenCircuit
end SatLowerBound
