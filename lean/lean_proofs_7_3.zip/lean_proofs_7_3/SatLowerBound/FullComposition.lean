import SatLowerBound.WeightedComposition
import SatLowerBound.TexDegreeBound
import Mathlib.Algebra.Order.Floor.Ring
import Mathlib.Tactic.Linarith

namespace SatLowerBound
namespace ModularTree

/-- Flatten a modular tree into consecutive, disjoint blocks of coordinates. -/
def packed {n : Nat} : (T : ModularTree n) → ReadOnce T.inputs
  | .leaf S t c => .leaf (fun v => Bool.xor (mod3 S.card t v) c)
  | .branch p a b => .branch p a.packed b.packed

/-- The packed coordinate's original name; no property of a computing circuit is assumed. -/
noncomputable def coordinate {n : Nat} : (T : ModularTree n) → Fin T.inputs → Fin n
  | .leaf S _ _, i => (S.equivFin.symm i).val
  | .branch _ a b, i => Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i

theorem coordinate_mem {n : Nat} (T : ModularTree n) (i : Fin T.inputs) :
    T.coordinate i ∈ T.support := by
  induction T with
  | leaf S t c => exact (S.equivFin.symm i).property
  | branch p a b iha ihb =>
      change Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i ∈ a.support ∪ b.support
      induction i using Fin.addCases with
      | left i => simpa only [Fin.addCases_left] using Finset.mem_union_left b.support (iha i)
      | right i => simpa only [Fin.addCases_right] using Finset.mem_union_right a.support (ihb i)

theorem coordinate_injective {n : Nat} (T : ModularTree n) (hv : T.Valid 0) :
    Function.Injective T.coordinate := by
  induction T with
  | leaf S t c =>
      intro i j h
      exact S.equivFin.symm.injective (Subtype.ext h)
  | branch p a b iha ihb =>
      intro i j h
      change Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i =
        Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate j at h
      induction i using Fin.addCases <;> induction j using Fin.addCases
      · simp only [Fin.addCases_left] at h
        exact congrArg (Fin.castAdd _) (iha hv.1 h)
      · simp only [Fin.addCases_left, Fin.addCases_right] at h
        exact False.elim (Finset.disjoint_left.mp hv.2.2 (a.coordinate_mem _) (h.symm ▸ b.coordinate_mem _))
      · simp only [Fin.addCases_left, Fin.addCases_right] at h
        exact False.elim (Finset.disjoint_left.mp hv.2.2 (h ▸ a.coordinate_mem _) (b.coordinate_mem _))
      · simp only [Fin.addCases_right] at h
        exact congrArg (Fin.natAdd _) (ihb hv.2.1 h)

theorem packed_eval {n : Nat} (T : ModularTree n) (v : Fin n → Bool) :
    T.packed.eval (fun i => v (T.coordinate i)) = T.eval v := by
  induction T with
  | leaf S t c =>
      change Bool.xor (mod3 S.card t (fun i => v (S.equivFin.symm i))) c = modularBlock S t c v
      have he : ones S.card (fun i => v (S.equivFin.symm i)) = tally S v := by
        rw [ones_eq_sum]
        unfold tally
        have h := S.equivFin.symm.sum_comp (fun i => indicator (v i.val))
        exact h.trans (Finset.sum_coe_sort S (fun i => indicator (v i)))
      simp only [mod3, modularBlock, he]
  | branch p a b iha ihb =>
      change (if p then
        a.packed.eval (leftBits (fun i => v (Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i))) ||
          b.packed.eval (rightBits (fun i => v (Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i)))
        else a.packed.eval (leftBits (fun i => v (Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i))) &&
          b.packed.eval (rightBits (fun i => v (Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i)))) = _
      have hl : leftBits (fun i => v ((branch p a b).coordinate i)) =
          (fun i => v (a.coordinate i)) := by
        funext i
        exact congrArg v (Fin.addCases_left i)
      have hr : rightBits (fun i => v ((branch p a b).coordinate i)) =
          (fun i => v (b.coordinate i)) := by
        funext i
        exact congrArg v (Fin.addCases_right i)
      change leftBits (fun i => v (Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i)) = _ at hl
      change rightBits (fun i => v (Fin.addCases (motive := fun _ => Fin n) a.coordinate b.coordinate i)) = _ at hr
      rw [hl, hr, iha, ihb]
      rfl

theorem packed_full {n : Nat} (T : ModularTree n) (hv : T.Valid 3)
    (hd : T.algebraicDefects = 0) : T.packed.FullLeaves := by
  have hz : T.defects = 0 := by rw [T.defects_eq_algebraicDefects (hv.mono (by omega)), hd]
  induction T with
  | leaf S t c =>
      change 3 ≤ S.card at hv
      change indicator (decide ((S.card + t.val) % 3 = 0)) = 0 at hz
      have hn : (S.card + t.val) % 3 ≠ 0 := by
        intro h
        simp [h, indicator] at hz
      change 0 < S.card ∧ (BPoly.ofFunction S.card (fun v => Bool.xor (mod3 S.card t v) c)).topCoefficient = true
      exact ⟨by omega, by simpa [hn] using mod3_top_coefficient S.card (by omega) t c⟩
  | branch p a b iha ihb =>
      change a.algebraicDefects + b.algebraicDefects = 0 at hd
      change a.defects + b.defects = 0 at hz
      exact ⟨iha hv.1 (by omega) (by omega), ihb hv.2.1 (by omega) (by omega)⟩

/-- Full algebraic degree of the entire read-once composition in its own variables. -/
theorem packed_degree {n : Nat} (T : ModularTree n) (hv : T.Valid 3)
    (hd : T.algebraicDefects = 0) :
    (BPoly.ofFunction T.inputs T.packed.eval).HasDegree T.inputs :=
  (BPoly.hasDegree_dimension_iff _).mpr (T.packed.full_degree (T.packed_full hv hd))

end ModularTree

theorem Circuit.rename_nonlinearCount {n m : Nat} (f : Fin n → Fin m) (C : Circuit n) :
    (C.rename f).nonlinearCount = C.nonlinearCount := by
  induction C generalizing m with
  | output => rfl
  | gate g l r rest ih => simp only [Circuit.rename, Circuit.nonlinearCount, ih]

/-- The nonlinear count bound transfers back from the packed coordinates without loss. -/
theorem full_modular_nonlinear_bound {n : Nat} (T : ModularTree n) (hv : T.Valid 3)
    (hd : T.algebraicDefects = 0) (C : Circuit n) (hc : C.Computes T.eval) :
    T.inputs ≤ C.nonlinearCount + 1 := by
  classical
  have hp := T.packed.inputs_positive (T.packed_full hv hd)
  let r : Fin n → Fin T.inputs := fun x =>
    if h : ∃ i, T.coordinate i = x then Classical.choose h else ⟨0, hp⟩
  have hr (i : Fin T.inputs) : r (T.coordinate i) = i := by
    dsimp [r]
    split
    · rename_i h
      exact T.coordinate_injective (hv.mono (by omega)) (Classical.choose_spec h)
    · rename_i h
      exact False.elim (h ⟨i, rfl⟩)
  have he : (C.rename r).Computes T.packed.eval := by
    intro v
    rw [Circuit.rename_eval, hc, ← T.packed_eval (fun x => v (r x))]
    simp only [hr]
  have h := (C.rename r).nonlinear_bound_of_exact_degree _ he (T.packed_degree hv hd)
  simpa only [Circuit.rename_nonlinearCount] using h

/-- TeX Corollary 5.3, with the ceiling expressed first as an exact integer inequality. -/
theorem full_modular_composition_size {n : Nat} (T : ModularTree n) (hv : T.Valid 3)
    (hd : T.algebraicDefects = 0) (C : Circuit n) (hc : C.Computes T.eval) :
    7 * T.inputs ≤ 3 * C.size + 7 * T.blocks + 3 := by
  have hw := weighted_modular_composition_algebraic T hv C hc
  have ha := full_modular_nonlinear_bound T hv hd C hc
  have hs := C.resource_le
  rw [hd] at hw
  omega

/-- The literal ceiling form in the manuscript, without truncating subtraction. -/
theorem full_modular_composition_ceiling {n : Nat} (T : ModularTree n) (hv : T.Valid 3)
    (hd : T.algebraicDefects = 0) (C : Circuit n) (hc : C.Computes T.eval) :
    ⌈((7 * (T.inputs : ℝ) - 7 * (T.blocks : ℝ) - 3) / 3)⌉ ≤ (C.size : ℤ) := by
  apply Int.ceil_le.mpr
  have h : 7 * (T.inputs : ℝ) ≤ 3 * (C.size : ℝ) + 7 * (T.blocks : ℝ) + 3 := by
    exact_mod_cast full_modular_composition_size T hv hd C hc
  norm_num only [Int.cast_natCast]
  linarith

end SatLowerBound
