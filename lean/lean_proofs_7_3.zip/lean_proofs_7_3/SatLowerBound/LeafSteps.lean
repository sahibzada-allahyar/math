import SatLowerBound.TwoLeafRetirement
import SatLowerBound.DefectTransitions

namespace SatLowerBound

def WeightedTree {n : Nat} (T : ModularTree n) : Prop :=
  ∀ C : OpenCircuit n, (∀ v, C.eval v = T.eval v) →
    6 * T.inputs ≤ C.weight + 7 * T.blocks + T.defects + 2

def DeletionAt {n : Nat} (C : OpenCircuit n) (x : Fin n) : Prop :=
  (∀ b, (C.restrict (singleSubst x b)).weight + 6 ≤ C.weight) ∨
    (∃ b, (C.restrict (singleSubst x b)).weight + 7 ≤ C.weight)

namespace ModularContext

theorem restrict_leaf_computes {n : Nat} (K : ModularContext n) (S : Finset (Fin n))
    (hf : K.Fits 3 S) (t : Fin 3) (c : Bool) (x : Fin n) (hx : x ∈ S)
    (C : OpenCircuit n) (hc : ∀ v, C.eval v = (K.plug (.leaf S t c)).eval v) (b : Bool) :
    ∀ v, (C.restrict (singleSubst x b)).eval v =
      (K.plug (.leaf (S.erase x) (lowerResidue t b) c)).eval v := by
  intro v
  rw [OpenCircuit.restrict_single_eval, hc]
  exact (K.plug_fixBit S hf (.leaf S t c) (.leaf (S.erase x) (lowerResidue t b) c)
    x hx b (fun v => (modularBlock_cofactor S t c x hx b v).symm) v).symm

theorem long_leaf_step {n : Nat} (K : ModularContext n) (S : Finset (Fin n))
    (hf : K.Fits 3 S) (t : Fin 3) (c : Bool) (x : Fin n) (hx : x ∈ S) (hS : 4 ≤ S.card)
    (C : OpenCircuit n) (hc : ∀ v, C.eval v = (K.plug (.leaf S t c)).eval v)
    (hd : DeletionAt C x)
    (ih : ∀ b, WeightedTree (K.plug (.leaf (S.erase x) (lowerResidue t b) c))) :
    6 * (K.plug (.leaf S t c)).inputs ≤
      C.weight + 7 * (K.plug (.leaf S t c)).blocks + (K.plug (.leaf S t c)).defects + 2 := by
  have hcard := Finset.card_erase_of_mem hx
  have hstep (b : Bool) := ih b (C.restrict (singleSubst x b)) (K.restrict_leaf_computes S hf t c x hx C hc b)
  simp only [plug_inputs, plug_blocks, plug_defects, ModularTree.inputs, ModularTree.blocks,
    ModularTree.defects] at hstep ⊢
  change ∀ b, 6 * ((S.erase x).card + K.inputs) ≤ (C.restrict (singleSubst x b)).weight +
    7 * (1 + K.blocks) + (residueDefect (S.erase x).card (lowerResidue t b) + K.defects) + 2 at hstep
  change 6 * (S.card + K.inputs) ≤ C.weight + 7 * (1 + K.blocks) + (residueDefect S.card t + K.defects) + 2
  rcases hd with hd | ⟨b, hd⟩
  · obtain ⟨b, hb⟩ := exists_full_cofactor (S.erase x).card t
    have hs := hstep b
    have hw := hd b
    omega
  · have hs := hstep b
    have hb := residueDefect_le_one (S.erase x).card (lowerResidue t b)
    omega

theorem retire_three_leaf {n : Nat} (K : ModularContext n) (S : Finset (Fin n))
    (hf : K.Fits 3 S) (R : ModularTree n) (hr : K.retire = some R)
    (t : Fin 3) (c : Bool) (x : Fin n) (hx : x ∈ S) (hS : S.card = 3)
    (C : OpenCircuit n) (hc : ∀ v, C.eval v = (K.plug (.leaf S t c)).eval v)
    (hd : DeletionAt C x) :
    ∃ D : OpenCircuit n, (∀ v, D.eval v = R.eval v) ∧ D.weight + 11 ≤ C.weight + residueDefect 3 t := by
  have hcard : (S.erase x).card = 2 := by rw [Finset.card_erase_of_mem hx, hS]
  obtain ⟨y, z, hyz, hset⟩ := Finset.card_eq_two.mp hcard
  have hy : y ∈ S := Finset.mem_of_mem_erase (by rw [hset]; simp)
  have hz : z ∈ S := Finset.mem_of_mem_erase (by rw [hset]; simp)
  have hcomp (b : Bool) : ∀ v, (C.restrict (singleSubst x b)).eval v =
      (K.plug (.leaf {y, z} (lowerResidue t b) c)).eval v := by
    simpa only [hset] using K.restrict_leaf_computes S hf t c x hx C hc b
  have four (b : Bool) := K.retire_two_inputs S hf R hr y z hyz hy hz (lowerResidue t b) c
    (C.restrict (singleSubst x b)) (hcomp b)
  have five (b : Bool) (hb : residueDefect 2 (lowerResidue t b) = 1) :
      ∃ D : OpenCircuit n, (∀ v, D.eval v = R.eval v) ∧
        D.weight + 5 ≤ (C.restrict (singleSubst x b)).weight := by
    have he := two_deficient_residue _ hb
    apply K.retire_parity_inputs S hf R hr y z hyz hy hz c (C.restrict (singleSubst x b))
    simpa only [he] using hcomp b
  rcases hd with hd | ⟨b, hd⟩
  · by_cases hfull : residueDefect 3 t = 0
    · obtain ⟨b, hb⟩ := full_has_deficient_cofactor 2 t hfull
      obtain ⟨D, hD, hw⟩ := five b hb
      have hdel := hd b
      exact ⟨D, hD, by omega⟩
    · obtain ⟨D, hD, hw⟩ := four false
      have hdel := hd false
      exact ⟨D, hD, by omega⟩
  · obtain ⟨D, hD, hw⟩ := four b
    exact ⟨D, hD, by omega⟩

end ModularContext

theorem final_three_leaf {n : Nat} (S : Finset (Fin n)) (t : Fin 3) (c : Bool)
    (x : Fin n) (hx : x ∈ S) (hS : S.card = 3)
    (C : OpenCircuit n) (hc : ∀ v, C.eval v = modularBlock S t c v)
    (hd : DeletionAt C x) : 9 ≤ C.weight + residueDefect 3 t := by
  have hcard : (S.erase x).card = 2 := by rw [Finset.card_erase_of_mem hx, hS]
  have hcomp (b : Bool) : ∀ v, (C.restrict (singleSubst x b)).eval v =
      modularBlock (S.erase x) (lowerResidue t b) c v := by
    intro v
    rw [OpenCircuit.restrict_single_eval, hc, modularBlock_cofactor S t c x hx]
  have two (b : Bool) := modularBlock_two_weight (S.erase x) (lowerResidue t b) c hcard
    (C.restrict (singleSubst x b)) (C.restrict_essential _) (hcomp b)
  have three (b : Bool) (hb : residueDefect 2 (lowerResidue t b) = 1) :
      3 ≤ (C.restrict (singleSubst x b)).weight := by
    have he := two_deficient_residue _ hb
    obtain ⟨y, z, _, _, _, hs⟩ := modularBlock_parity_slice (S.erase x) c hcard
    apply OpenCircuit.parity_slice_weight _ y z
    have heq : (C.restrict (singleSubst x b)).eval = modularBlock (S.erase x) 1 c := by
      funext v
      simpa only [he] using hcomp b v
    rwa [heq]
  rcases hd with hd | ⟨b, hd⟩
  · by_cases hfull : residueDefect 3 t = 0
    · obtain ⟨b, hb⟩ := full_has_deficient_cofactor 2 t hfull
      have hbase := three b hb
      have hdel := hd b
      omega
    · have hbase := two false
      have hdel := hd false
      omega
  · have hbase := two b
    omega

end SatLowerBound
