import SatLowerBound.ModularTree
import SatLowerBound.Mod3Degree
import SatLowerBound.FiniteFieldDegree
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Algebra.BigOperators.Fin

namespace SatLowerBound
namespace BPoly

/-- Exact algebraic degree, expressed using the already verified coefficient predicate. -/
def HasDegree {n : Nat} (p : BPoly n) (d : Nat) : Prop :=
  p.DegreeLT (d + 1) ∧ ¬ p.DegreeLT d

theorem degree_dimension {n : Nat} (p : BPoly n) : p.DegreeLT (n + 1) := by
  induction p with
  | constant b => exact Or.inr (by omega)
  | node p q ihp ihq =>
    exact ⟨degree_mono p ihp (by omega), by simpa using ihq⟩

theorem degree_below_dimension_iff {n : Nat} (p : BPoly n) :
    p.DegreeLT n ↔ p.topCoefficient = false := by
  induction p with
  | constant b => cases b <;> simp [DegreeLT, topCoefficient]
  | node p q ihp ihq =>
    change (p.DegreeLT (_ + 1) ∧ q.DegreeLT _) ↔ q.topCoefficient = false
    exact ⟨fun h => ihq.mp h.2, fun h => ⟨degree_dimension p, ihq.mpr h⟩⟩

theorem hasDegree_dimension_iff {n : Nat} (p : BPoly n) :
    p.HasDegree n ↔ p.topCoefficient = true := by
  simp only [HasDegree, degree_dimension, true_and, degree_below_dimension_iff]
  cases p.topCoefficient <;> simp

theorem ofFunction_false_degree {n d : Nat} (f : (Fin (n + 1) → Bool) → Bool)
    (h : (ofFunction (n + 1) f).DegreeLT d) :
    (ofFunction n (fun v => f (extend v false))).DegreeLT d := h.1

theorem top_xor_constant (n : Nat) (hn : 0 < n) (f : (Fin n → Bool) → Bool) (c : Bool) :
    (ofFunction n (fun v => Bool.xor (f v) c)).topCoefficient =
      (ofFunction n f).topCoefficient := by
  obtain ⟨k, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hn)
  cases c
  · simp only [Bool.xor_false]
  · simp only [Bool.xor_true, ofFunction_not, top_add, top_one, Bool.false_xor]

end BPoly

theorem mod3_eq_shifted (n : Nat) (t : Fin 3) :
    mod3 n t = shiftedFunction n ((n + t.val) % 3) := by
  funext v
  simp only [mod3, shiftedFunction, Nat.mod_mod, decide_eq_decide]
  have ht := t.isLt
  omega

theorem mod3_top_coefficient (n : Nat) (hn : 0 < n) (t : Fin 3) (c : Bool) :
    (BPoly.ofFunction n (fun v => Bool.xor (mod3 n t v) c)).topCoefficient =
      decide ((n + t.val) % 3 ≠ 0) := by
  rw [BPoly.top_xor_constant n hn, mod3_eq_shifted]
  obtain ⟨k, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hn)
  obtain ⟨h0, h1, h2⟩ := shifted_top_coefficients k
  have hm : (k + 1 + t.val) % 3 = 0 ∨ (k + 1 + t.val) % 3 = 1 ∨
      (k + 1 + t.val) % 3 = 2 := by omega
  rcases hm with hm | hm | hm <;> simp only [hm] <;> assumption

/-- The full degree formula in TeX Lemma 3.1, including output complements. -/
theorem mod3_exact_degree (n : Nat) (hn : 2 ≤ n) (t : Fin 3) (c : Bool) :
    (BPoly.ofFunction n (fun v => Bool.xor (mod3 n t v) c)).HasDegree
      (n - indicator (decide ((n + t.val) % 3 = 0))) := by
  by_cases hd : (n + t.val) % 3 = 0
  · simp only [hd, decide_true, indicator, ↓reduceIte]
    obtain ⟨k, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : n ≠ 0)
    have hk : 0 < k := by omega
    constructor
    · simpa using (BPoly.degree_below_dimension_iff _).mpr
        (by simpa [hd] using mod3_top_coefficient (k + 1) (by omega) t c)
    · intro h
      have hlo := BPoly.ofFunction_false_degree _ h
      have he : (fun v => Bool.xor (mod3 (k + 1) t (extend v false)) c) =
          (fun v => Bool.xor (mod3 k t v) c) := by
        funext v
        simp [mod3, ones_extend]
      rw [he] at hlo
      have ht := mod3_top_coefficient k hk t c
      have hne : (k + t.val) % 3 ≠ 0 := by omega
      have hf := (BPoly.degree_below_dimension_iff _).mp hlo
      simp [hne] at ht
      rw [ht] at hf
      contradiction
  · simp only [hd, decide_false, indicator, Bool.false_eq_true, ↓reduceIte, Nat.sub_zero]
    apply (BPoly.hasDegree_dimension_iff _).mpr
    simpa [hd] using mod3_top_coefficient n (by omega) t c

theorem ones_eq_sum (n : Nat) (v : Fin n → Bool) :
    ones n v = ∑ i, indicator (v i) := by
  induction n with
  | zero => simp [ones]
  | succ n ih =>
      rw [Fin.sum_univ_succ, ← ih]
      rfl

/-- Restrict to the named support, with an arbitrary enumeration of its variables. -/
def onSupport {n : Nat} (S : Finset (Fin n)) (e : S ≃ Fin S.card)
    (f : (Fin n → Bool) → Bool) (v : Fin S.card → Bool) : Bool :=
  f (fun i => if h : i ∈ S then v (e ⟨i, h⟩) else false)

theorem modularBlock_onSupport {n : Nat} (S : Finset (Fin n)) (e : S ≃ Fin S.card)
    (t : Fin 3) (c : Bool) :
    onSupport S e (modularBlock S t c) = fun v => Bool.xor (mod3 S.card t v) c := by
  funext v
  have hs : tally S (fun i => if h : i ∈ S then v (e ⟨i, h⟩) else false) = ones S.card v := by
    rw [ones_eq_sum]
    unfold tally
    rw [← Finset.sum_attach]
    simpa using e.sum_comp (fun i => indicator (v i))
  simp only [onSupport, modularBlock, mod3, hs]

/-- Exact degree on arbitrary supports and arbitrary variable enumerations. -/
theorem modularBlock_exact_degree {n : Nat} (S : Finset (Fin n))
    (e : S ≃ Fin S.card) (hS : 2 ≤ S.card) (t : Fin 3) (c : Bool) :
    (BPoly.ofFunction S.card (onSupport S e (modularBlock S t c))).HasDegree
      (S.card - indicator (decide ((S.card + t.val) % 3 = 0))) := by
  rw [modularBlock_onSupport]
  exact mod3_exact_degree S.card hS t c

theorem modularBlock_deficient_iff {n : Nat} (S : Finset (Fin n))
    (e : S ≃ Fin S.card) (hS : 2 ≤ S.card) (t : Fin 3) (c : Bool) :
    (BPoly.ofFunction S.card (onSupport S e (modularBlock S t c))).DegreeLT S.card ↔
      (S.card + t.val) % 3 = 0 := by
  rw [modularBlock_onSupport, BPoly.degree_below_dimension_iff,
    mod3_top_coefficient S.card (by omega)]
  simp

namespace ModularTree

/-- Count leaves whose actual algebraic degree is below their number of variables. -/
noncomputable def algebraicDefects {n : Nat} : ModularTree n → Nat
  | .leaf S t c => by
      classical
      exact if (BPoly.ofFunction S.card (onSupport S S.equivFin (modularBlock S t c))).DegreeLT
        S.card then 1 else 0
  | .branch _ a b => a.algebraicDefects + b.algebraicDefects

/-- The arithmetic bookkeeping delta is exactly the TeX degree-deficiency count. -/
theorem defects_eq_algebraicDefects {n : Nat} (T : ModularTree n) (hT : T.Valid 2) :
    T.defects = T.algebraicDefects := by
  induction T with
  | leaf S t c =>
      simp only [defects, algebraicDefects,
        modularBlock_deficient_iff S S.equivFin hT t c, indicator, decide_eq_true_eq]
  | branch p a b iha ihb =>
      exact congrArg₂ Nat.add (iha hT.1) (ihb hT.2.1)

end ModularTree
end SatLowerBound
