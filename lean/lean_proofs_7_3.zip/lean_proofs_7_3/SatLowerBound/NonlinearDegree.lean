import SatLowerBound.BooleanPolynomial

namespace SatLowerBound
namespace BPoly

def varPoly : (n : Nat) → Fin n → BPoly n
  | 0, i => Fin.elim0 i
  | n + 1, i =>
      if h : i.val < n then .node (varPoly n ⟨i.val, h⟩) (zero n)
      else .node (zero n) (one n)

theorem eval_varPoly (n : Nat) (i : Fin n) (x : Fin n → Bool) :
    (varPoly n i).eval x = x i := by
  induction n with
  | zero => exact Fin.elim0 i
  | succ n ih =>
    simp only [varPoly]
    split
    · simp only [eval, eval_zero, Bool.and_false, Bool.xor_false, ih]
      rfl
    · rename_i h
      have hi : i = Fin.last n := Fin.ext (by change i.val = n; have := i.isLt; omega)
      simp only [eval, eval_zero, eval_one, Bool.and_true, Bool.false_xor, hi]

theorem degree_varPoly (n : Nat) (i : Fin n) : (varPoly n i).DegreeLT 2 := by
  induction n with
  | zero => exact Fin.elim0 i
  | succ n ih =>
    simp only [varPoly]
    split
    · exact ⟨ih _, zero_degree _ _⟩
    · exact ⟨zero_degree _ _, one_degree _⟩

def select {n : Nat} (b : Bool) (p : BPoly n) : BPoly n := if b then p else zero n

theorem eval_select {n : Nat} (b : Bool) (p : BPoly n) (x : Fin n → Bool) :
    (select b p).eval x = (b && p.eval x) := by cases b <;> simp [select]

theorem degree_select {n d : Nat} (b : Bool) (p : BPoly n) (h : p.DegreeLT d) :
    (select b p).DegreeLT d := by cases b <;> simp [select, h, zero_degree]

def quadraticCoeff (g : Table) : Bool := Bool.xor (Bool.xor g.ff g.ft) (Bool.xor g.tf g.tt)

theorem quadraticCoeff_nonlin (g : Table) (h : quadraticCoeff g = true) :
    g.nonlinearCount = 1 := by
  revert h
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

def gatePoly {n : Nat} (g : Table) (i j : Fin n) : BPoly n :=
  ((select g.ff (one n)).add (select (Bool.xor g.ff g.tf) (varPoly n i))).add
    ((select (Bool.xor g.ff g.ft) (varPoly n j)).add
      (select (quadraticCoeff g) ((varPoly n i).mul (varPoly n j))))

private theorem gate_identity (g : Table) (x y : Bool) :
    Bool.xor (Bool.xor (g.ff && true) ((Bool.xor g.ff g.tf) && x))
      (Bool.xor ((Bool.xor g.ff g.ft) && y) (quadraticCoeff g && (x && y))) = g.eval x y := by
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> cases x <;> cases y <;> rfl

theorem eval_gatePoly {n : Nat} (g : Table) (i j : Fin n) (x : Fin n → Bool) :
    (gatePoly g i j).eval x = g.eval (x i) (x j) := by
  simp only [gatePoly, eval_add, eval_select, eval_one, eval_varPoly, eval_mul]
  exact gate_identity _ _ _

theorem degree_gatePoly {n : Nat} (g : Table) (i j : Fin n) :
    (gatePoly g i j).DegreeLT (g.nonlinearCount + 2) := by
  unfold gatePoly
  apply degree_add
  · apply degree_add
    · apply degree_select
      exact degree_mono _ (one_degree n) (by omega)
    · apply degree_select
      exact degree_mono _ (degree_varPoly n i) (by omega)
  · apply degree_add
    · apply degree_select
      exact degree_mono _ (degree_varPoly n j) (by omega)
    · cases hc : quadraticCoeff g
      · exact zero_degree _ _
      · have hn := quadraticCoeff_nonlin g hc
        rw [hn]
        exact degree_mul _ _ (degree_varPoly n i) (degree_varPoly n j)

/-- The coefficient of the monomial containing all n variables. -/
def topCoefficient : {n : Nat} → BPoly n → Bool
  | 0, .constant b => b
  | _ + 1, .node _ q => q.topCoefficient

theorem degree_of_topCoefficient {n d : Nat} (p : BPoly n)
    (h : p.topCoefficient = true) (hd : p.DegreeLT d) : n < d := by
  induction p generalizing d with
  | constant b =>
    change b = true at h
    change b = false ∨ 0 < d at hd
    rcases hd with hd | hd
    · rw [h] at hd; contradiction
    · exact hd
  | node p q ihp ihq =>
    have hh := ihq h hd.2
    omega

end BPoly
namespace Circuit

/-- Algebraic normal form built from the actual shared straight-line circuit.
Substitution is performed once per instruction, retaining Boolean idempotence. -/
def polynomial : {n : Nat} → Circuit n → BPoly n
  | n, .output i => BPoly.varPoly n i
  | _, .gate g i j rest =>
      match polynomial rest with
      | .node p q => p.add ((BPoly.gatePoly g i j).mul q)

theorem polynomial_eval {n : Nat} (C : Circuit n) (x : Fin n → Bool) :
    C.polynomial.eval x = C.eval x := by
  induction C with
  | output i => exact BPoly.eval_varPoly _ _ _
  | gate g i j rest ih =>
    cases hp : rest.polynomial with
    | node p q =>
      simp only [polynomial, hp, BPoly.eval_add, BPoly.eval_mul, BPoly.eval_gatePoly]
      have he := ih (extend x (g.eval (x i) (x j)))
      rw [hp, BPoly.eval_node_extend] at he
      exact he

theorem polynomial_degree {n : Nat} (C : Circuit n) :
    C.polynomial.DegreeLT (C.nonlinearCount + 2) := by
  induction C with
  | output i => exact BPoly.degree_varPoly _ _
  | gate g i j rest ih =>
    cases hp : rest.polynomial with
    | node p q =>
      rw [hp] at ih
      obtain ⟨hpdeg, hqdeg⟩ := ih
      change q.DegreeLT (rest.nonlinearCount + 1) at hqdeg
      simp only [polynomial, hp, nonlinearCount]
      apply BPoly.degree_add
      · exact BPoly.degree_mono _ hpdeg (by omega)
      · have h := BPoly.degree_mul _ _ (BPoly.degree_gatePoly g i j) hqdeg
        simpa only [Nat.add_right_comm g.nonlinearCount 1 rest.nonlinearCount,
          Nat.add_assoc] using h

/-- A function with a nonzero full monomial requires at least n-1 nonlinear gates. -/
theorem nonlinear_lower_bound {n : Nat} (C : Circuit n) (f : (Fin n → Bool) → Bool)
    (hc : C.Computes f) (hf : (BPoly.ofFunction n f).topCoefficient = true) :
    n ≤ C.nonlinearCount + 1 := by
  have he : C.polynomial = BPoly.ofFunction n f := by
    apply BPoly.ext
    intro x
    rw [polynomial_eval, BPoly.eval_ofFunction, hc]
  have hd := polynomial_degree C
  rw [he] at hd
  have hn := BPoly.degree_of_topCoefficient _ hf hd
  omega

end Circuit
end SatLowerBound
