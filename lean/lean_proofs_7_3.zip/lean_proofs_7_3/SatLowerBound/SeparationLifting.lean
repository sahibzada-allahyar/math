import SatLowerBound.DisjointFunctions

namespace SatLowerBound

theorem Supported.pair_left {n : Nat} {f : (Fin n → Bool) → Bool} {S : Finset (Fin n)}
    (h : Supported f S) (x y : Fin n) (hy : y ∉ S) (a b : Bool) (v : Fin n → Bool) :
    f (setPair v x y a b) = f (fixBit x a v) :=
  (h.cofactor x a).fixBit_outside y hy b v

theorem Supported.pair_right {n : Nat} {f : (Fin n → Bool) → Bool} {S : Finset (Fin n)}
    (h : Supported f S) (x y : Fin n) (hx : x ∉ S) (a b : Bool) (v : Fin n → Bool) :
    f (setPair v x y a b) = f (fixBit y b v) := h.fixBit_outside x hx a (fixBit y b v)

theorem Supported.pair_patch {n : Nat} {f : (Fin n → Bool) → Bool} {S : Finset (Fin n)}
    (h : Supported f S) (x y : Fin n) (a b : Bool) (u v : Fin n → Bool) :
    f (setPair (patchValues S u v) x y a b) = f (setPair u x y a b) := by
  apply h
  intro i hi
  simp [setPair, patchValues, hi]

theorem threeRows_pullback {α β : Type} (f : Bool → Bool → α → Bool)
    (g : Bool → Bool → β → Bool) (e : α → β)
    (he : ∀ a b u, g a b (e u) = f a b u) (h : ThreeRows f) : ThreeRows g := by
  obtain ⟨p, q, r, hpq, hpr, hqr⟩ := h
  have step (a b : Bool × Bool) (hab : PairRow f a ≠ PairRow f b) : PairRow g a ≠ PairRow g b := by
    intro hh
    apply hab
    funext u
    have hu := congrFun hh (e u)
    simpa only [PairRow, he] using hu
  exact ⟨p, q, r, step p q hpq, step p r hpr, step q r hqr⟩

theorem combine_pair_left {n : Nat} (p : Bool) (f g : (Fin n → Bool) → Bool)
    (S T : Finset (Fin n)) (hf : Supported f S) (hg : Supported g T) (hd : Disjoint S T)
    (hgn : Nonconstant g) (x y : Fin n) (hx : x ∈ S) (hy : y ∈ S)
    (hs : PairSeparated f x y) : PairSeparated (fun v => combine p (f v) (g v)) x y := by
  obtain ⟨z, hz⟩ := hgn.has_value (!p)
  have hxt : x ∉ T := fun ht => Finset.disjoint_left.mp hd hx ht
  have hyt : y ∉ T := fun ht => Finset.disjoint_left.mp hd hy ht
  apply threeRows_pullback _ _ (fun v => patchValues S v z) _ hs
  intro a b v
  change combine p (f (setPair (patchValues S v z) x y a b))
    (g (setPair (patchValues S v z) x y a b)) = f (setPair v x y a b)
  rw [hf.pair_patch, hg.pair_right x y hxt, hg.fixBit_outside y hyt,
    hg.patch_right hd, hz, combine_neutral]

theorem combine_pair_right {n : Nat} (p : Bool) (f g : (Fin n → Bool) → Bool)
    (S T : Finset (Fin n)) (hf : Supported f S) (hg : Supported g T) (hd : Disjoint S T)
    (hfn : Nonconstant f) (x y : Fin n) (hx : x ∈ T) (hy : y ∈ T)
    (hs : PairSeparated g x y) : PairSeparated (fun v => combine p (f v) (g v)) x y := by
  have h := combine_pair_left p g f T S hg hf hd.symm hfn x y hx hy hs
  simpa only [combine_comm p (g _) (f _)] using h

theorem combine_eq_neutral_left (p a b : Bool) (h : combine p a b = !p) : a = !p := by
  cases p <;> cases a <;> cases b <;> simp_all [combine]

theorem combine_product_left_unique {n : Nat} (p : Bool) (f₀ f₁ g₀ g₁ : (Fin n → Bool) → Bool)
    (S T : Finset (Fin n)) (hf₀ : Supported f₀ S) (hf₁ : Supported f₁ S)
    (hg₀ : Supported g₀ T) (hg₁ : Supported g₁ T) (hd : Disjoint S T)
    (hn₀ : Nonconstant g₀) (hn₁ : Nonconstant g₁)
    (he : (fun v => combine p (f₀ v) (g₀ v)) = (fun v => combine p (f₁ v) (g₁ v))) : f₀ = f₁ := by
  obtain ⟨z₀, hz₀⟩ := hn₀.has_value (!p)
  obtain ⟨z₁, hz₁⟩ := hn₁.has_value (!p)
  have forward (v : Fin n → Bool) (hv : f₀ v = !p) : f₁ v = !p := by
    have h := congrFun he (patchValues S v z₀)
    simp only [hf₀.patch_left, hf₁.patch_left, hg₀.patch_right hd, hg₁.patch_right hd,
      hz₀, combine_neutral, hv] at h
    exact combine_eq_neutral_left p _ _ h.symm
  have backward (v : Fin n → Bool) (hv : f₁ v = !p) : f₀ v = !p := by
    have h := congrFun he (patchValues S v z₁)
    simp only [hf₀.patch_left, hf₁.patch_left, hg₀.patch_right hd, hg₁.patch_right hd,
      hz₁, combine_neutral, hv] at h
    exact combine_eq_neutral_left p _ _ h
  funext v
  have h0 := forward v
  have h1 := backward v
  cases p <;> cases hf : f₀ v <;> cases hg : f₁ v <;> simp_all

theorem combine_product_right_unique {n : Nat} (p : Bool) (f₀ f₁ g₀ g₁ : (Fin n → Bool) → Bool)
    (S T : Finset (Fin n)) (hf₀ : Supported f₀ S) (hf₁ : Supported f₁ S)
    (hg₀ : Supported g₀ T) (hg₁ : Supported g₁ T) (hd : Disjoint S T)
    (hn₀ : Nonconstant f₀) (hn₁ : Nonconstant f₁)
    (he : (fun v => combine p (f₀ v) (g₀ v)) = (fun v => combine p (f₁ v) (g₁ v))) : g₀ = g₁ := by
  apply combine_product_left_unique p g₀ g₁ f₀ f₁ T S hg₀ hg₁ hf₀ hf₁ hd.symm hn₀ hn₁
  simpa only [combine_comm p (f₀ _) (g₀ _), combine_comm p (f₁ _) (g₁ _)] using he

theorem combine_pair_cross {n : Nat} (p : Bool) (f g : (Fin n → Bool) → Bool)
    (S T : Finset (Fin n)) (hf : Supported f S) (hg : Supported g T) (hd : Disjoint S T)
    (x y : Fin n) (hx : Essential f x) (hy : Essential g y)
    (hfx : ∀ a, Nonconstant (fun v => f (fixBit x a v)))
    (hgy : ∀ b, Nonconstant (fun v => g (fixBit y b v))) :
    PairSeparated (fun v => combine p (f v) (g v)) x y := by
  have hxs := hf.essential_mem x hx
  have hyt := hg.essential_mem y hy
  have hxt : x ∉ T := fun ht => Finset.disjoint_left.mp hd hxs ht
  have hys : y ∉ S := fun hs => Finset.disjoint_left.mp hd hs hyt
  have hrow (a b : Bool) : PairRow (fun a b v => combine p (f (setPair v x y a b))
      (g (setPair v x y a b))) (a, b) =
      (fun v => combine p (f (fixBit x a v)) (g (fixBit y b v))) := by
    funext v
    simp only [PairRow, hf.pair_left x y hys, hg.pair_right x y hxt]
  have hfd := essential_cofactors_distinct f x hx
  have hgd := essential_cofactors_distinct g y hy
  refine ⟨(false, false), (false, true), (true, true), ?_, ?_, ?_⟩
  · intro he
    rw [hrow, hrow] at he
    exact hgd (combine_product_right_unique p _ _ _ _ S T (hf.cofactor x false) (hf.cofactor x false)
      (hg.cofactor y false) (hg.cofactor y true) hd (hfx false) (hfx false) he)
  · intro he
    rw [hrow, hrow] at he
    exact hfd (combine_product_left_unique p _ _ _ _ S T (hf.cofactor x false) (hf.cofactor x true)
      (hg.cofactor y false) (hg.cofactor y true) hd (hgy false) (hgy true) he)
  · intro he
    rw [hrow, hrow] at he
    exact hfd (combine_product_left_unique p _ _ _ _ S T (hf.cofactor x false) (hf.cofactor x true)
      (hg.cofactor y true) (hg.cofactor y true) hd (hgy true) (hgy true) he)

end SatLowerBound
