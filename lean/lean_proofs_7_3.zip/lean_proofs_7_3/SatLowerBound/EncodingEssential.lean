import SatLowerBound.Dependence
import SatLowerBound.Encoding

namespace SatLowerBound

theorem coordinate_surjective (w : Nat) (i : Fin (inputBits w)) :
    ∃ c s b, coordinate w c s b = i := by
  let i' : Fin ((clauseCount w * 3) * (w + 1)) :=
    ⟨i.val, by simpa [inputBits, clauseCount, Nat.mul_comm 3 (variableCount w)] using i.isLt⟩
  let a := unpairIndex (Nat.zero_lt_succ w) i'
  let cs := unpairIndex (by decide : 0 < 3) a.1
  refine ⟨cs.1, cs.2, a.2, ?_⟩
  have hs : pairIndex cs.1 cs.2 = a.1 := pair_unpair (by decide) a.1
  have ha : pairIndex a.1 a.2 = i' := pair_unpair (Nat.zero_lt_succ w) i'
  apply Fin.ext
  change (pairIndex (pairIndex cs.1 cs.2) a.2).val = i.val
  rw [hs, ha]

theorem encoded_agree_except (w : Nat) (x y : StructuredInput w)
    (c : Fin (clauseCount w)) (s : Fin 3) (b : Fin (w + 1))
    (h : ∀ d t e, coordinate w d t e ≠ coordinate w c s b → x d t e = y d t e) :
    ∀ i, i ≠ coordinate w c s b → encodeBits w x i = encodeBits w y i := by
  intro i hi
  obtain ⟨d, t, e, rfl⟩ := coordinate_surjective w i
  simp only [encode_coordinate]
  exact h d t e hi

theorem binaryValue_pos_of_bit (w : Nat) (x : Fin w → Bool) (j : Fin w)
    (h : x j = true) : 0 < binaryValue w x := by
  by_contra hn
  have hz : binaryValue w x = 0 := Nat.eq_zero_of_not_pos hn
  have he := binaryValue_injective w x (fun _ => false) (by simpa using hz)
  have hh := congrFun he j
  rw [h] at hh
  contradiction

theorem all_positive_valid_sat (w : Nat) (x : Input w) (hv : Valid w x)
    (hs : ∀ c s, negative w x c s = false) : satFunction w x = true := by
  apply (satFunction_eq_true_iff w x).mpr
  change SAT w x
  refine ⟨hv, fun _ => true, ?_⟩
  intro c
  refine ⟨0, ?_⟩
  simp [literalValue, hv c 0, identifier_le w x c 0, hs c 0]

/-- A valid positive instance and an invalid instance differing in one ID bit. -/
theorem identifier_bit_essential (w : Nat) (c : Fin (clauseCount w)) (s : Fin 3)
    (j : Fin w) : Essential (satFunction w) (coordinate w c s j.castSucc) := by
  let x : StructuredInput w := fun d t b =>
    if d = c ∧ t = s then decide (b.val = j.val) else decide (b.val = 0)
  let y : StructuredInput w := fun d t b =>
    if d = c ∧ t = s then false else decide (b.val = 0)
  have hx : satFunction w (encodeBits w x) = true := by
    apply all_positive_valid_sat
    · intro d t
      simp only [identifier, encode_coordinate]
      by_cases h : d = c ∧ t = s
      · apply binaryValue_pos_of_bit w _ j
        simp [x, h]
      · apply binaryValue_pos_of_bit w _ ⟨0, by have := j.isLt; omega⟩
        simp [x, h]
    · intro d t
      have hj : w ≠ j.val := by have := j.isLt; omega
      have hw : w ≠ 0 := by have := j.isLt; omega
      simp [negative, x, hj, hw]
  have hy : satFunction w (encodeBits w y) = false := by
    apply invalid_eq_false w _ c s
    simp [identifier, y]
  refine ⟨encodeBits w x, encodeBits w y, ?_, ?_⟩
  · apply encoded_agree_except
    intro d t b hb
    by_cases h : d = c ∧ t = s
    · have hj : b.val ≠ j.val := by
        intro he
        have heq : b = j.castSucc := Fin.ext he
        apply hb
        rw [h.1, h.2, heq]
      simp [x, y, h, hj]
    · simp only [x, y, h, ↓reduceIte]
  · rw [hx, hy]
    decide

def signWitness (w : Nat) (c : Fin (clauseCount w)) (s : Fin 3) (flip : Bool) :
    StructuredInput w := fun d t =>
  extend (fun b : Fin w => decide (b.val = 0))
    (decide (d ≠ c) || (flip && decide (t = s)))

theorem signWitness_identifier (w : Nat) (hw : 0 < w) (c : Fin (clauseCount w))
    (s : Fin 3) (flip : Bool) (d : Fin (clauseCount w)) (t : Fin 3) :
    identifier w (encodeBits w (signWitness w c s flip)) d t = 1 := by
  simp only [identifier, encode_coordinate, signWitness, extend_old]
  exact binaryValue_one w hw

theorem signWitness_literal (w : Nat) (hw : 0 < w) (hm : 0 < variableCount w)
    (c : Fin (clauseCount w)) (s : Fin 3) (flip : Bool) (a : Assignment w)
    (d : Fin (clauseCount w)) (t : Fin 3) :
    literalValue w (encodeBits w (signWitness w c s flip)) a d t =
      if decide (d ≠ c) || (flip && decide (t = s)) then !(a ⟨0, hm⟩) else a ⟨0, hm⟩ := by
  simp [literalValue, signWitness_identifier w hw, Nat.succ_le_of_lt hm,
    negative, signWitness, extend_last]

/-- The selected clause is positive X₁; another clause forces X₁ false.
Flipping its selected sign turns the selected clause into a tautology. -/
theorem sign_bit_essential (w : Nat) (hw : 0 < w) (hm : 2 ≤ variableCount w)
    (c : Fin (clauseCount w)) (s : Fin 3) :
    Essential (satFunction w) (coordinate w c s (Fin.last w)) := by
  have hm0 : 0 < variableCount w := by omega
  let d : Fin (clauseCount w) :=
    if h : c.val = 0 then ⟨1, by change 1 < variableCount w; omega⟩
    else ⟨0, by change 0 < variableCount w; omega⟩
  have hdc : d ≠ c := by
    intro he
    have hv := congrArg Fin.val he
    dsimp [d] at hv
    split at hv
    · change 1 = c.val at hv
      omega
    · change 0 = c.val at hv
      omega
  have hfalse : satFunction w (encodeBits w (signWitness w c s false)) = false := by
    classical
    have hn : ¬ SAT w (encodeBits w (signWitness w c s false)) := by
      rintro ⟨_, a, ha⟩
      obtain ⟨t, ht⟩ := ha c
      obtain ⟨u, hu⟩ := ha d
      rw [signWitness_literal w hw hm0 c s false a c t] at ht
      rw [signWitness_literal w hw hm0 c s false a d u] at hu
      have hat : a ⟨0, hm0⟩ = true := by simpa using ht
      have haf : !(a ⟨0, hm0⟩) = true := by simpa [hdc] using hu
      rw [hat] at haf
      contradiction
    simp [satFunction, hn]
  have htrue : satFunction w (encodeBits w (signWitness w c s true)) = true := by
    apply (satFunction_eq_true_iff w _).mpr
    change SAT w (encodeBits w (signWitness w c s true))
    constructor
    · intro d t
      rw [signWitness_identifier w hw]
      decide
    · refine ⟨fun _ => false, ?_⟩
      intro d
      refine ⟨s, ?_⟩
      rw [signWitness_literal w hw hm0 c s true (fun _ => false) d s]
      simp
  refine ⟨encodeBits w (signWitness w c s false), encodeBits w (signWitness w c s true), ?_, ?_⟩
  · apply encoded_agree_except
    intro e t b hb
    unfold signWitness extend
    split
    · rfl
    · rename_i h
      have hbw : b = Fin.last w := Fin.ext (by change b.val = w; have := b.isLt; omega)
      have hne : e ≠ c ∨ t ≠ s := by
        by_cases he : e = c
        · right
          intro ht
          exact hb (by rw [he, ht, hbw])
        · exact Or.inl he
      rcases hne with he | ht
      · simp [he]
      · simp [ht]
  · rw [hfalse, htrue]
    decide

theorem every_encoding_bit_essential (w : Nat) (hw : 2 ≤ w) :
    ∀ i : Fin (inputBits w), Essential (satFunction w) i := by
  have hm : 2 ≤ variableCount w := by
    have hp : 2 ^ 2 ≤ 2 ^ w := Nat.pow_le_pow_right (by decide) hw
    unfold variableCount
    omega
  intro i
  obtain ⟨c, s, b, rfl⟩ := coordinate_surjective w i
  by_cases hb : b.val < w
  · have he : b = (⟨b.val, hb⟩ : Fin w).castSucc := rfl
    rw [he]
    exact identifier_bit_essential w c s _
  · have he : b = Fin.last w := Fin.ext (by change b.val = w; have := b.isLt; omega)
    rw [he]
    exact sign_bit_essential w (by omega) hm c s

end SatLowerBound
