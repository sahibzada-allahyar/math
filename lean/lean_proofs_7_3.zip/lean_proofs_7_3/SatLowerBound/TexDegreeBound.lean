import SatLowerBound.DegreeCorrespondence
import SatLowerBound.CompositionDegree

namespace SatLowerBound

/-- TeX Lemma 5.2 for arbitrary degree D, not only the full-degree case. -/
theorem Circuit.nonlinear_bound_of_exact_degree {n d : Nat} (C : Circuit n)
    (f : (Fin n → Bool) → Bool) (hc : C.Computes f)
    (hd : (BPoly.ofFunction n f).HasDegree d) : d ≤ C.nonlinearCount + 1 := by
  have he : C.polynomial = BPoly.ofFunction n f := by
    apply BPoly.ext
    intro v
    rw [Circuit.polynomial_eval, BPoly.eval_ofFunction, hc]
  by_contra h
  apply hd.2
  rw [← he]
  exact BPoly.degree_mono _ C.polynomial_degree (by omega)

theorem OpenCircuit.nonlinear_bound_of_exact_degree {n d : Nat} (C : OpenCircuit n)
    (f : (Fin n → Bool) → Bool) (hc : ∀ v, C.eval v = f v)
    (hd : (BPoly.ofFunction n f).HasDegree d) : d ≤ C.nonlinearCount + 1 := by
  have he : C.polynomial = BPoly.ofFunction n f := by
    apply BPoly.ext
    intro v
    rw [OpenCircuit.polynomial_eval, BPoly.eval_ofFunction, hc]
  by_contra h
  apply hd.2
  rw [← he]
  exact BPoly.degree_mono _ C.polynomial_degree (by omega)

end SatLowerBound
