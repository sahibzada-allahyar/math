import SatLowerBound.DegreeCorrespondence
import Mathlib.Data.ZMod.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Pi
import Mathlib.Algebra.BigOperators.Group.Finset.Powerset

namespace SatLowerBound
namespace BPoly

/-- Read the actual monomial coefficient from the recursive coefficient array. -/
def coefficient : {n : Nat} → BPoly n → (Fin n → Bool) → Bool
  | 0, .constant b, _ => b
  | n + 1, .node p q, s =>
      if s (Fin.last n) then q.coefficient (fun i => s i.castSucc)
      else p.coefficient (fun i => s i.castSucc)

theorem coefficient_extend {n : Nat} (p q : BPoly n) (s : Fin n → Bool) (b : Bool) :
    (node p q).coefficient (extend s b) = if b then q.coefficient s else p.coefficient s := by
  simp only [coefficient, extend_old, extend_last]

theorem coefficient_add {n : Nat} (p q : BPoly n) (s : Fin n → Bool) :
    (p.add q).coefficient s = Bool.xor (p.coefficient s) (q.coefficient s) := by
  induction p with
  | constant b => cases q; rfl
  | node p r ihp ihq =>
      cases q with
      | node u v =>
          simp only [add, coefficient]
          split
          · exact ihq _ _
          · exact ihp _ _

end BPoly

/-- Split the Boolean cube by its last bit, as in Proposition 2.7. -/
def cubeLastEquiv (n : Nat) : Bool × (Fin n → Bool) ≃ (Fin (n + 1) → Bool) where
  toFun z := extend z.2 z.1
  invFun v := (v (Fin.last n), fun i => v i.castSucc)
  left_inv z := by
    apply Prod.ext
    · exact extend_last _ _
    · funext i; exact extend_old _ _ _
  right_inv v := BPoly.extend_reconstruct v

theorem sum_cube_last {R : Type*} [AddCommMonoid R] (n : Nat)
    (f : (Fin (n + 1) → Bool) → R) :
    (∑ v, f v) = (∑ v, f (extend v false)) + ∑ v, f (extend v true) := by
  rw [← (cubeLastEquiv n).sum_comp f, Fintype.sum_prod_type]
  simp [cubeLastEquiv, add_comm]

/-- The squarefree monomial selected by a subset's characteristic vector. -/
def squarefreeMonomial {n : Nat} (s x : Fin n → Bool) : ZMod 2 :=
  Finset.univ.prod (fun i : Fin n => if s i then fieldBit (x i) else 1)

theorem squarefreeMonomial_extend {n : Nat} (s : Fin n → Bool) (b : Bool)
    (x : Fin (n + 1) → Bool) :
    squarefreeMonomial (extend s b) x =
      squarefreeMonomial s (fun i => x i.castSucc) * (if b then fieldBit (x (Fin.last n)) else 1) := by
  simp only [squarefreeMonomial, Fin.prod_univ_castSucc, extend_old, extend_last]

/-- Equation (5): evaluation is the sum of actual coefficients times their squarefree monomials. -/
theorem BPoly.representation_by_coefficients {n : Nat} (p : BPoly n) (x : Fin n → Bool) :
    fieldBit (R := ZMod 2) (p.eval x) =
      ∑ s, fieldBit (R := ZMod 2) (p.coefficient s) * squarefreeMonomial s x := by
  induction p with
  | constant b => simp [BPoly.eval, BPoly.coefficient, squarefreeMonomial]
  | @node n p q ihp ihq =>
      rw [sum_cube_last]
      simp only [BPoly.coefficient_extend, squarefreeMonomial_extend, Bool.false_eq_true,
        ↓reduceIte, mul_one]
      simp only [← mul_assoc]
      rw [← Finset.sum_mul]
      simp only [BPoly.eval, fieldBit_xor]
      have hand : fieldBit (R := ZMod 2) (x (Fin.last n) && q.eval (fun i => x i.castSucc)) =
          fieldBit (R := ZMod 2) (x (Fin.last n)) * fieldBit (R := ZMod 2) (q.eval (fun i => x i.castSucc)) := by
        cases x (Fin.last n) <;> cases q.eval (fun i => x i.castSucc) <;> rfl
      rw [hand, ihp, ihq]
      ring

theorem BPoly.unique_multilinear_representation (n : Nat) (f : (Fin n → Bool) → Bool) :
    ∃! p : BPoly n, ∀ x, p.eval x = f x := by
  refine ⟨BPoly.ofFunction n f, BPoly.eval_ofFunction n f, ?_⟩
  intro p hp
  apply BPoly.ext
  intro x
  rw [hp, BPoly.eval_ofFunction]

/-- A bit vector represents a subset; this relation is subset inclusion. -/
def BitsSubset {n : Nat} (x s : Fin n → Bool) : Prop := ∀ i, x i = true → s i = true

instance {n : Nat} (x s : Fin n → Bool) : Decidable (BitsSubset x s) :=
  inferInstanceAs (Decidable (∀ i, x i = true → s i = true))

theorem bitsSubset_extend {n : Nat} (x : Fin n → Bool) (b : Bool) (t : Fin (n + 1) → Bool) :
    BitsSubset (extend x b) t ↔ BitsSubset x (fun i => t i.castSucc) ∧ (b = true → t (Fin.last n) = true) := by
  constructor
  · intro h
    exact ⟨fun i hi => h i.castSucc (by simpa only [extend_old] using hi),
      fun hb => h (Fin.last n) (by simpa only [extend_last] using hb)⟩
  · rintro ⟨h, hb⟩ i hi
    induction i using Fin.lastCases with
    | last => exact hb (by simpa only [extend_last] using hi)
    | cast i => exact h i (by simpa only [extend_old] using hi)

/-- Proposition 2.7: each coefficient is the F2 sum over assignments below its subset. -/
theorem coefficient_ofFunction_sum (n : Nat) (f : (Fin n → Bool) → Bool) (s : Fin n → Bool) :
    fieldBit (R := ZMod 2) (BPoly.ofFunction n f |>.coefficient s) =
      ∑ x, if BitsSubset x s then fieldBit (R := ZMod 2) (f x) else 0 := by
  induction n with
  | zero =>
      simp only [BPoly.ofFunction, BPoly.coefficient]
      have hs (x : Fin 0 → Bool) : BitsSubset x s := fun i => Fin.elim0 i
      simp only [hs, ↓reduceIte, Fintype.sum_unique]
      congr 2
  | succ n ih =>
      rw [sum_cube_last]
      simp only [bitsSubset_extend, Bool.false_eq_true, false_implies, and_true, true_implies]
      simp only [BPoly.ofFunction, BPoly.coefficient]
      cases hb : s (Fin.last n)
      · simp only [Bool.false_eq_true, ↓reduceIte, and_false, Finset.sum_const_zero, add_zero]
        exact ih _ _
      · simp only [↓reduceIte, and_true]
        rw [ih]
        simp only [fieldBit_xor]
        rw [← Finset.sum_add_distrib]
        apply Finset.sum_congr rfl
        intro x _
        split <;> simp

/-- A concrete bijection between subsets and their characteristic bit vectors. -/
def subsetBitsEquiv (n : Nat) : Finset (Fin n) ≃ (Fin n → Bool) where
  toFun s := fun i => decide (i ∈ s)
  invFun x := Finset.univ.filter (fun i => x i = true)
  left_inv s := by ext i; simp
  right_inv x := by funext i; simp

theorem bitsSubset_characteristic (n : Nat) (s t : Finset (Fin n)) :
    BitsSubset (subsetBitsEquiv n t) (subsetBitsEquiv n s) ↔ t ⊆ s := by
  simp only [BitsSubset, subsetBitsEquiv, Equiv.coe_fn_mk, decide_eq_true_eq]
  rfl

theorem characteristic_ones (n : Nat) (s : Finset (Fin n)) :
    ones n (subsetBitsEquiv n s) = s.card := by
  simp [ones_eq_sum, subsetBitsEquiv, indicator]

theorem squarefreeMonomial_characteristic (n : Nat) (s : Finset (Fin n)) (x : Fin n → Bool) :
    squarefreeMonomial (subsetBitsEquiv n s) x = ∏ i ∈ s, fieldBit (R := ZMod 2) (x i) := by
  simp only [squarefreeMonomial, subsetBitsEquiv, Equiv.coe_fn_mk, decide_eq_true_eq]
  rw [← Finset.prod_filter]
  simp

/-- Equation (5) in literal subset-indexed notation. -/
theorem BPoly.representation_subset_sum {n : Nat} (p : BPoly n) (x : Fin n → Bool) :
    fieldBit (R := ZMod 2) (p.eval x) =
      ∑ s : Finset (Fin n), fieldBit (R := ZMod 2) (p.coefficient (subsetBitsEquiv n s)) *
        ∏ i ∈ s, fieldBit (R := ZMod 2) (x i) := by
  rw [p.representation_by_coefficients, ← (subsetBitsEquiv n).sum_comp]
  simp only [squarefreeMonomial_characteristic]

/-- The literal powerset form a_S = sum_{T subset S} f(1_T) from equation (6). -/
theorem coefficient_ofFunction_powerset (n : Nat) (f : (Fin n → Bool) → Bool)
    (s : Finset (Fin n)) :
    fieldBit (R := ZMod 2) ((BPoly.ofFunction n f).coefficient (subsetBitsEquiv n s)) =
      ∑ t ∈ s.powerset, fieldBit (R := ZMod 2) (f (subsetBitsEquiv n t)) := by
  rw [coefficient_ofFunction_sum, ← (subsetBitsEquiv n).sum_comp]
  simp only [bitsSubset_characteristic, ← Finset.mem_powerset]
  rw [← Finset.sum_filter]
  have he : Finset.univ.filter (fun t : Finset (Fin n) => t ⊆ s) = s.powerset := by
    ext t; simp
  simpa only [Finset.mem_powerset] using congrArg
    (fun u : Finset (Finset (Fin n)) => ∑ t ∈ u, fieldBit (R := ZMod 2) (f (subsetBitsEquiv n t))) he

/-- Equation (9): the coefficient is the residue-selected sum of binomial coefficients mod two. -/
theorem mod3_coefficient_binomial (n : Nat) (t : Fin 3) (s : Finset (Fin n)) :
    fieldBit (R := ZMod 2) ((BPoly.ofFunction n (mod3 n t)).coefficient (subsetBitsEquiv n s)) =
      ∑ j ∈ Finset.range (s.card + 1),
        if j % 3 = t.val then (s.card.choose j : ZMod 2) else 0 := by
  rw [coefficient_ofFunction_powerset]
  simp only [mod3, characteristic_ones]
  rw [Finset.sum_powerset]
  apply Finset.sum_congr rfl
  intro j _
  simpa [fieldBit, nsmul_eq_mul] using
    Finset.sum_powersetCard j s (fun k => fieldBit (R := ZMod 2) (decide (k % 3 = t.val)))

namespace BPoly

/-- DegreeLT means exactly that every nonzero monomial has fewer than d variables. -/
theorem degreeLT_iff_coefficients {n d : Nat} (p : BPoly n) :
    p.DegreeLT d ↔ ∀ s, p.coefficient s = true → ones n s < d := by
  induction p generalizing d with
  | constant b =>
      cases b <;> simp [DegreeLT, coefficient, ones]
  | @node n p q ihp ihq =>
      constructor
      · rintro ⟨hp, hq⟩ s hs
        have he := extend_reconstruct s
        rw [← he, coefficient_extend] at hs
        rw [← he, ones_extend]
        cases hb : s (Fin.last n)
        · simp only [hb, Bool.false_eq_true, ↓reduceIte] at hs ⊢
          exact (ihp.mp hp _ hs)
        · simp only [hb, ↓reduceIte] at hs ⊢
          have h := ihq.mp hq _ hs
          omega
      · intro h
        constructor
        · apply ihp.mpr
          intro s hs
          have hc := h (extend s false)
          simp only [coefficient_extend, Bool.false_eq_true, ↓reduceIte,
            ones_extend, Nat.add_zero] at hc
          exact hc hs
        · apply ihq.mpr
          intro s hs
          have hc := h (extend s true)
          simp only [coefficient_extend, ↓reduceIte, ones_extend] at hc
          have hh := hc hs
          omega

/-- Degree with the PDF's convention that the zero polynomial has degree zero. -/
noncomputable def algebraicDegree {n : Nat} (p : BPoly n) : Nat := by
  classical
  exact Nat.find (show ∃ d, p.DegreeLT (d + 1) from ⟨n, degree_dimension p⟩)

theorem algebraicDegree_spec {n : Nat} (p : BPoly n) : p.DegreeLT (p.algebraicDegree + 1) := by
  classical
  exact Nat.find_spec (show ∃ d, p.DegreeLT (d + 1) from ⟨n, degree_dimension p⟩)

theorem algebraicDegree_le_iff {n d : Nat} (p : BPoly n) :
    p.algebraicDegree ≤ d ↔ p.DegreeLT (d + 1) := by
  classical
  constructor
  · intro h; exact degree_mono p p.algebraicDegree_spec (by omega)
  · intro h
    exact Nat.find_min' (show ∃ d, p.DegreeLT (d + 1) from ⟨n, degree_dimension p⟩) h

theorem algebraicDegree_zero (n : Nat) : (zero n).algebraicDegree = 0 := by
  apply Nat.eq_zero_of_le_zero
  exact (algebraicDegree_le_iff _).mpr (zero_degree _ _)

/-- The numerical degree is the largest nonzero monomial size, with empty maximum zero. -/
theorem algebraicDegree_le_iff_coefficients {n d : Nat} (p : BPoly n) :
    p.algebraicDegree ≤ d ↔ ∀ s, p.coefficient s = true → ones n s ≤ d := by
  rw [algebraicDegree_le_iff, degreeLT_iff_coefficients]
  simp only [Nat.lt_succ_iff]

theorem algebraicDegree_le_iff_subsets {n d : Nat} (p : BPoly n) :
    p.algebraicDegree ≤ d ↔
      ∀ s : Finset (Fin n), p.coefficient (subsetBitsEquiv n s) = true → s.card ≤ d := by
  rw [algebraicDegree_le_iff_coefficients]
  constructor
  · intro h s hs
    simpa only [characteristic_ones] using h (subsetBitsEquiv n s) hs
  · intro h v hv
    have hs := h ((subsetBitsEquiv n).symm v)
    rw [Equiv.apply_symm_apply] at hs
    have hc := characteristic_ones n ((subsetBitsEquiv n).symm v)
    rw [Equiv.apply_symm_apply] at hc
    rw [hc]
    exact hs hv

theorem hasDegree_iff_algebraicDegree {n d : Nat} (p : BPoly n) :
    p.HasDegree d ↔ p ≠ zero n ∧ p.algebraicDegree = d := by
  constructor
  · rintro ⟨hu, hl⟩
    refine ⟨fun he => hl (he ▸ zero_degree n d), ?_⟩
    have hd := (algebraicDegree_le_iff p).mpr hu
    apply Nat.le_antisymm hd
    by_contra h
    exact hl (degree_mono p p.algebraicDegree_spec (by omega))
  · rintro ⟨hn, hd⟩
    refine ⟨by rw [← hd]; exact p.algebraicDegree_spec, ?_⟩
    intro h
    cases d with
    | zero => exact hn ((degree_zero_iff p).mp h)
    | succ d =>
        have hu : p.algebraicDegree ≤ d := (algebraicDegree_le_iff p).mpr h
        omega

theorem positive_degree_iff {n d : Nat} (p : BPoly n) (hd : 0 < d) :
    p.algebraicDegree = d ↔ p.HasDegree d := by
  rw [hasDegree_iff_algebraicDegree]
  constructor
  · intro h
    refine ⟨?_, h⟩
    intro he
    rw [he, algebraicDegree_zero] at h
    omega
  · exact And.right

end BPoly

/-- Lemma 4.1 with the PDF's total numerical-degree convention. -/
theorem mod3_algebraicDegree (n : Nat) (hn : 2 ≤ n) (t : Fin 3) (c : Bool) :
    (BPoly.ofFunction n (fun v => Bool.xor (mod3 n t v) c)).algebraicDegree =
      n - indicator (decide ((n + t.val) % 3 = 0)) :=
  ((BPoly.hasDegree_iff_algebraicDegree _).mp (mod3_exact_degree n hn t c)).2

/-- For every block, "below full degree" means exactly degree k-1, as in Definition 2.8. -/
theorem modularBlock_deficient_degree_iff {n : Nat} (S : Finset (Fin n))
    (e : S ≃ Fin S.card) (hS : 2 ≤ S.card) (t : Fin 3) (c : Bool) :
    (BPoly.ofFunction S.card (onSupport S e (modularBlock S t c))).algebraicDegree = S.card - 1 ↔
      (S.card + t.val) % 3 = 0 := by
  rw [modularBlock_onSupport, mod3_algebraicDegree S.card hS]
  by_cases h : (S.card + t.val) % 3 = 0
  · simp [h, indicator]
  · simp only [h, decide_false, indicator, Bool.false_eq_true, ↓reduceIte, Nat.sub_zero,
      iff_false]
    omega

end SatLowerBound
