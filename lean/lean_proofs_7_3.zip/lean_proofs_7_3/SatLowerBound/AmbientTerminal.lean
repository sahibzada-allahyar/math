import SatLowerBound.ParityRetirement
import SatLowerBound.TerminalBounds
import SatLowerBound.BlockSeparation

namespace SatLowerBound

def pairProjection {n : Nat} (v : Fin n → Bool) (x y : Fin n) : Fin n → Signal 2 :=
  fun i => if i = x then .wire 0 false else if i = y then .wire 1 false else .constant (v i)

theorem pairProjection_eval {n : Nat} (v : Fin n → Bool) (x y : Fin n) (u : Fin 2 → Bool) :
    (fun i => (pairProjection v x y i).eval u) = setPair v x y (u 0) (u 1) := by
  funext i
  by_cases hx : i = x
  · simp [pairProjection, setPair, hx, Signal.eval]
  · by_cases hy : i = y
    · subst i; simp [pairProjection, setPair, hx, Signal.eval]
    · simp [pairProjection, setPair, hx, hy, Signal.eval]

namespace OpenCircuit

theorem parity_slice_weight {n : Nat} (C : OpenCircuit n)
    (x y : Fin n) (hs : PairParitySlice C.eval x y) : 3 ≤ C.weight := by
  obtain ⟨v, c, hv⟩ := hs
  let σ := pairProjection v x y
  have hcomp (u : Fin 2 → Bool) : (C.restrict σ).eval u = parity2 c u := by
    rw [restrict_eval, pairProjection_eval]
    exact hv (u 0) (u 1)
  have hw := (C.restrict σ).parity_weight_lower_bound c (C.restrict_essential σ) hcomp
  exact Nat.le_trans hw (C.restrict_weight_le σ)

theorem two_essential_weight {n : Nat} (C : OpenCircuit n) (he : C.EssentialGates)
    (x y : Fin n) (hxy : x ≠ y) (hx : Essential C.eval x) (hy : Essential C.eval y) : 2 ≤ C.weight := by
  cases C with
  | output sig =>
    have hu := (output sig).essential_has_use x hx
    have hv := (output sig).essential_has_use y hy
    cases sig with
    | constant c => exact False.elim (Nat.not_lt_zero _ hu)
    | wire k c =>
      have hkx : k = x := by by_contra h; simp [usage, singleUse, h] at hu
      have hky : k = y := by by_contra h; simp [usage, singleUse, h] at hv
      exact False.elim (hxy (hkx.symm.trans hky))
  | gate g i j rest =>
    have hw := g.essential_weight he.1
    simp only [weight]
    omega

end OpenCircuit

theorem modularBlock_pair_parity {n : Nat} (x y : Fin n) (hxy : x ≠ y) (c a b : Bool)
    (v : Fin n → Bool) :
    modularBlock {x, y} 1 c (setPair v x y a b) = Bool.xor (Bool.xor a b) c := by
  simp only [modularBlock, tally_setPair {x, y} x y hxy (by simp) (by simp)]
  have he : (({x, y} : Finset (Fin n)).erase x).erase y = ∅ := by
    ext i
    simp only [Finset.mem_erase, Finset.mem_insert, Finset.mem_singleton, Finset.notMem_empty, iff_false]
    tauto
  rw [he]
  cases a <;> cases b <;> cases c <;> simp [tally, indicator]

theorem modularBlock_parity_slice {n : Nat} (S : Finset (Fin n)) (c : Bool) (hS : S.card = 2) :
    ∃ x y, x ≠ y ∧ x ∈ S ∧ y ∈ S ∧ PairParitySlice (modularBlock S 1 c) x y := by
  obtain ⟨x, y, hxy, hS⟩ := Finset.card_eq_two.mp hS
  subst S
  refine ⟨x, y, hxy, by simp, by simp, fun _ => false, c, ?_⟩
  exact fun a b => modularBlock_pair_parity x y hxy c a b _

theorem modularBlock_two_weight {n : Nat} (S : Finset (Fin n)) (t : Fin 3) (c : Bool)
    (hS : S.card = 2) (C : OpenCircuit n) (he : C.EssentialGates)
    (hc : ∀ v, C.eval v = modularBlock S t c v) : 2 ≤ C.weight := by
  obtain ⟨x, y, hxy, hset⟩ := Finset.card_eq_two.mp hS
  have hx : x ∈ S := by rw [hset]; simp
  have hy : y ∈ S := by rw [hset]; simp
  have hfun : C.eval = modularBlock S t c := funext hc
  apply C.two_essential_weight he x y hxy
  · rw [hfun]
    exact modularBlock_essential S t c (by omega) x hx
  · rw [hfun]
    exact modularBlock_essential S t c (by omega) y hy

end SatLowerBound
