import SatLowerBound.PropagationSemantics

namespace SatLowerBound

theorem History.triangle_old {n : Nat} (Γ : History n) (g : Table) (a b i j : Fin n)
    (h : Γ.TriangleAt i j) : (Γ.extend g a b).TriangleAt i.castSucc j.castSucc := by
  rcases h with ⟨hi, p, hp, he⟩ | ⟨hj, p, hp, he⟩
  · left
    refine ⟨by simp [hi], p.lift, by simp [hp], ?_⟩
    rcases he with he | he
    · exact Or.inl (congrArg Fin.castSucc he)
    · exact Or.inr (congrArg Fin.castSucc he)
  · right
    refine ⟨by simp [hj], p.lift, by simp [hp], ?_⟩
    rcases he with he | he
    · exact Or.inl (congrArg Fin.castSucc he)
    · exact Or.inr (congrArg Fin.castSucc he)

theorem History.triangle_symm {n : Nat} (Γ : History n) (i j : Fin n) :
    Γ.TriangleAt i j → Γ.TriangleAt j i := Or.symm

def PartialState.Singleton {n : Nat} (κ : PartialState n) (x : Fin n) : Prop :=
  ∀ k, κ.mask k = true → k = x

/-- Every pair of distinct currently constant signals forms a forbidden triangle. -/
def PartialState.Thin {n : Nat} (κ : PartialState n) (Γ : History n) : Prop :=
  ∀ i j, i ≠ j → κ.mask i = true → κ.mask j = true → Γ.TriangleAt i j

theorem PartialState.singleton_thin {n : Nat} (κ : PartialState n) (x : Fin n)
    (h : κ.Singleton x) (Γ : History n) : κ.Thin Γ := by
  intro i j hij hi hj
  exact False.elim (hij ((h i hi).trans (h j hj).symm))

@[simp] theorem PartialState.next_old {n : Nat} (κ : PartialState n) (g : Table)
    (i j k : Fin n) : κ.next g i j k.castSucc = κ k := by
  simp [PartialState.next, OpenCircuit.appendValue, k.isLt]

@[simp] theorem PartialState.next_last {n : Nat} (κ : PartialState n) (g : Table)
    (i j : Fin n) : κ.next g i j (Fin.last n) = g.partial (κ i) (κ j) := by
  simp [PartialState.next, OpenCircuit.appendValue]

theorem PartialState.thin_next_none {n : Nat} (κ : PartialState n) (Γ : History n)
    (g : Table) (i j : Fin n) (h : κ.Thin Γ) (hz : g.partial (κ i) (κ j) = none) :
    (κ.next g i j).Thin (Γ.extend g i j) := by
  intro a b hab ha hb
  induction a using Fin.lastCases with
  | last => simp [PartialState.mask, hz] at ha
  | cast a =>
    simp only [PartialState.mask, PartialState.next_old] at ha
    induction b using Fin.lastCases with
    | last => simp [PartialState.mask, hz] at hb
    | cast b =>
      simp only [PartialState.mask, PartialState.next_old] at hb
      apply Γ.triangle_old g i j a b
      exact h a b (fun he => hab (congrArg Fin.castSucc he)) ha hb

theorem PartialState.singleton_next_none {n : Nat} (κ : PartialState n) (x : Fin n)
    (g : Table) (i j : Fin n) (h : κ.Singleton x) (hz : g.partial (κ i) (κ j) = none) :
    (κ.next g i j).Singleton x.castSucc := by
  intro k hk
  induction k using Fin.lastCases with
  | last => simp [PartialState.mask, hz] at hk
  | cast k =>
    simp only [PartialState.mask, PartialState.next_old] at hk
    exact congrArg Fin.castSucc (h k hk)

theorem PartialState.singleton_next_thin {n : Nat} (κ : PartialState n) (Γ : History n)
    (x : Fin n) (g : Table) (i j : Fin n) (h : κ.Singleton x) (hx : Γ x = none) :
    (κ.next g i j).Thin (Γ.extend g i j) := by
  have hm : (g.partial (κ i) (κ j)).isSome = true → i = x ∨ j = x := by
    intro hz
    have hb := (g.partial_mark_bounds (κ i) (κ j)).1 hz
    change (κ.mask i || κ.mask j) = true at hb
    rcases Bool.or_eq_true_iff.mp hb with hi | hj
    · exact Or.inl (h i hi)
    · exact Or.inr (h j hj)
  have edge (a : Fin n) (ha : κ.mask a = true)
      (hz : (g.partial (κ i) (κ j)).isSome = true) :
      (Γ.extend g i j).TriangleAt a.castSucc (Fin.last n) := by
    have ha' := h a ha
    subst a
    left
    refine ⟨by simp [hx], ⟨g, i.castSucc, j.castSucc⟩, by simp, ?_⟩
    rcases hm hz with hi | hj
    · exact Or.inl (congrArg Fin.castSucc hi)
    · exact Or.inr (congrArg Fin.castSucc hj)
  intro a b hab ha hb
  induction a using Fin.lastCases with
  | last =>
    simp only [PartialState.mask, PartialState.next_last] at ha
    induction b using Fin.lastCases with
    | last => exact False.elim (hab rfl)
    | cast b =>
      simp only [PartialState.mask, PartialState.next_old] at hb
      exact History.triangle_symm _ _ _ (edge b hb ha)
  | cast a =>
    simp only [PartialState.mask, PartialState.next_old] at ha
    induction b using Fin.lastCases with
    | last =>
      simp only [PartialState.mask, PartialState.next_last] at hb
      exact edge a ha hb
    | cast b =>
      simp only [PartialState.mask, PartialState.next_old] at hb
      exact False.elim (hab (congrArg Fin.castSucc ((h a ha).trans (h b hb).symm)))

namespace OpenCircuit

def propagationConstants : {n : Nat} → OpenCircuit n → PartialState n → Nat
  | _, .output _, _ => 0
  | _, .gate g i j rest, κ =>
      indicator (g.partial (κ i) (κ j)).isSome + rest.propagationConstants (κ.next g i j)

theorem thin_gate_birth {n : Nat} (κ : PartialState n) (Γ : History n) (g : Table)
    (i j : Fin n) (hk : κ.Thin Γ) (hij : i ≠ j) (ht : ¬ Γ.TriangleAt i j) :
    (Bool.xor (κ.mask i) (κ.mask j) && (g.partial (κ i) (κ j)).isSome) =
      (g.partial (κ i) (κ j)).isSome := by
  have hn : ¬ (κ.mask i = true ∧ κ.mask j = true) := fun h => ht (hk i j hij h.1 h.2)
  have hb := (g.partial_mark_bounds (κ i) (κ j)).1
  change ((g.partial (κ i) (κ j)).isSome = true → (κ.mask i || κ.mask j) = true) at hb
  cases hi : κ.mask i <;> cases hj : κ.mask j <;>
    cases hz : (g.partial (κ i) (κ j)).isSome <;> simp_all

theorem thin_zero_births {n : Nat} (C : OpenCircuit n) (κ : PartialState n) (Γ : History n)
    (hr : C.Reduced) (ht : C.NoInputTriangles Γ) (hk : κ.Thin Γ)
    (hz : C.propagationBirths κ = 0) : C.propagationConstants κ = 0 := by
  induction C with
  | output => rfl
  | gate g i j rest ih =>
    have he := thin_gate_birth κ Γ g i j hk hr.2.1 ht.1
    simp only [propagationBirths, he] at hz
    have hn : g.partial (κ i) (κ j) = none := by
      cases hv : g.partial (κ i) (κ j)
      · rfl
      · simp [hv, indicator] at hz
    have htail : rest.propagationBirths (κ.next g i j) = 0 := by omega
    have hrec := ih (κ.next g i j) (Γ.extend g i j) hr.2.2.2 ht.2
      (κ.thin_next_none Γ g i j hk hn) htail
    simp [propagationConstants, hn, hrec, indicator]

/-- With a single fixed input, two constant gate outputs require at least two
single-predecessor births unless there are already two such births. -/
theorem singleton_births_bound {n : Nat} (C : OpenCircuit n) (κ : PartialState n)
    (Γ : History n) (x : Fin n) (hr : C.Reduced) (ht : C.NoInputTriangles Γ)
    (hk : κ.Singleton x) (hx : Γ x = none) :
    C.propagationConstants κ ≤ C.propagationBirths κ ∨ 2 ≤ C.propagationBirths κ := by
  induction C with
  | output => exact Or.inl (Nat.le_refl 0)
  | gate g i j rest ih =>
    have he := thin_gate_birth κ Γ g i j (κ.singleton_thin x hk Γ) hr.2.1 ht.1
    simp only [propagationBirths, propagationConstants, he]
    cases hn : g.partial (κ i) (κ j) with
    | none =>
      have hrec := ih (κ.next g i j) (Γ.extend g i j) x.castSucc hr.2.2.2 ht.2
        (κ.singleton_next_none x g i j hk hn) (by simp [hx])
      simpa only [Option.isSome_none, indicator, Bool.false_eq_true, ↓reduceIte, Nat.zero_add]
        using hrec
    | some b =>
      by_cases hb : rest.propagationBirths (κ.next g i j) = 0
      · have hc := rest.thin_zero_births (κ.next g i j) (Γ.extend g i j) hr.2.2.2 ht.2
          (κ.singleton_next_thin Γ x g i j hk hx) hb
        left
        simp [hb, hc]
      · right
        simp only [Option.isSome_some, indicator, ↓reduceIte]
        omega

end OpenCircuit
end SatLowerBound
