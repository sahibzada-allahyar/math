import SatLowerBound.Closure

namespace SatLowerBound

theorem simplifyGate_binary_essential {n : Nat} (g h : Table) (s t : Signal n)
    (i j : Fin n) (hs : simplifyGate g s t = .binary h i j) : h.essential = true := by
  cases s with
  | constant a => cases t <;> simp [simplifyGate] at hs
  | wire k a =>
    cases t with
    | constant b => simp [simplifyGate] at hs
    | wire l b =>
      simp only [simplifyGate] at hs
      split at hs
      · contradiction
      · exact GateStep.classify_binary_essential _ _ _ _ _ _ hs

namespace OpenCircuit

theorem restrict_essential {n m : Nat} (C : OpenCircuit n) (σ : Fin n → Signal m) :
    (C.restrict σ).EssentialGates := by
  induction C generalizing m with
  | output => trivial
  | gate g i j rest ih =>
    simp only [restrict]
    split
    · exact ih _
    · rename_i h k l hs
      exact ⟨simplifyGate_binary_essential g h _ _ k l hs, ih _⟩

theorem eval_eq_of_zero_usage {n : Nat} (C : OpenCircuit n) (p : Fin n → Nat)
    (hu : C.usage p = 0) (x y : Fin n → Bool)
    (hxy : ∀ i, p i = 0 → x i = y i) : C.eval x = C.eval y := by
  induction C with
  | output s =>
    cases s with
    | constant b => rfl
    | wire i b => exact congrArg (fun v => Bool.xor v b) (hxy i hu)
  | gate g i j rest ih =>
    change p i + p j + rest.usage (appendValue p 0) = 0 at hu
    have hi : p i = 0 := by omega
    have hj : p j = 0 := by omega
    have hr : rest.usage (appendValue p 0) = 0 := by omega
    have hg : g.eval (x i) (x j) = g.eval (y i) (y j) := by rw [hxy i hi, hxy j hj]
    apply ih _ hr
    intro k hk
    simp only [appendValue] at hk
    simp only [extend]
    split at hk
    · rename_i h
      simp only [h, ↓reduceDIte]
      exact hxy _ hk
    · rename_i h
      simp only [h, ↓reduceDIte]
      exact hg

theorem eval_unused_last {n : Nat} (C : OpenCircuit (n + 1)) (h : C.lastUses = 0)
    (x : Fin n → Bool) (a b : Bool) : C.eval (extend x a) = C.eval (extend x b) := by
  apply eval_eq_of_zero_usage C _ h
  intro i hi
  simp only [appendValue] at hi
  simp only [extend]
  split at hi
  · rename_i hh
    simp only [hh, ↓reduceDIte]
  · contradiction

def identitySubst (n : Nat) : Fin n → Signal n := fun i => .wire i false

theorem identity_eval (n : Nat) (x : Fin n → Bool) :
    (fun i => (identitySubst n i).eval x) = x := by
  funext i
  simp [identitySubst, Signal.eval]

def dropLast (n : Nat) : Fin (n + 1) → Signal n :=
  extendSubst (identitySubst n) (.constant false)

theorem dropLast_eval {n : Nat} (C : OpenCircuit (n + 1)) (x : Fin n → Bool) :
    (C.restrict (dropLast n)).eval x = C.eval (extend x false) := by
  rw [restrict_eval, dropLast, eval_extendSubst, identity_eval]
  rfl

/-- Pruning is proved by strong induction on the number of actual instructions.
It preserves semantics, essential gates, and both resources. -/
theorem exists_live_essential {n : Nat} (C : OpenCircuit n) (he : C.EssentialGates) :
    ∃ D : OpenCircuit n,
      D.Live ∧ D.EssentialGates ∧ D.size ≤ C.size ∧ D.weight ≤ C.weight ∧
      ∀ x, D.eval x = C.eval x := by
  generalize hs : C.size = s
  induction s using Nat.strongRecOn generalizing n with
  | ind s ih =>
    cases C with
    | output a => exact ⟨.output a, trivial, trivial, Nat.zero_le _, Nat.le_refl _, fun _ => rfl⟩
    | gate g i j rest =>
      obtain ⟨hg, hrest⟩ := he
      have hrsize : rest.size < s := by simp only [size] at hs; omega
      obtain ⟨R, hlR, heR, hsR, hwR, hvR⟩ := ih rest.size hrsize rest hrest rfl
      by_cases hu : 0 < R.lastUses
      · refine ⟨.gate g i j R, ⟨hu, hlR⟩, ⟨hg, heR⟩, ?_, ?_, ?_⟩
        · rw [← hs]
          exact Nat.add_le_add_right hsR 1
        · exact Nat.add_le_add_left hwR _
        · intro x
          exact hvR _
      · have hu0 : R.lastUses = 0 := by omega
        let T := R.restrict (dropLast n)
        have hTsize : T.size < s := Nat.lt_of_le_of_lt
          (Nat.le_trans (restrict_size_le R _) hsR) hrsize
        obtain ⟨D, hlD, heD, hsD, hwD, hvD⟩ :=
          ih T.size hTsize T (restrict_essential R _) rfl
        refine ⟨D, hlD, heD, ?_, ?_, ?_⟩
        · rw [← hs]
          change D.size ≤ rest.size + 1
          exact Nat.le_trans hsD (Nat.le_trans (restrict_size_le R _) (Nat.le_trans hsR (Nat.le_succ _)))
        · change D.weight ≤ g.weight + rest.weight
          exact Nat.le_trans hwD (Nat.le_trans (restrict_weight_le R _)
            (Nat.le_trans hwR (Nat.le_add_left _ _)))
        · intro x
          rw [hvD]
          change (R.restrict (dropLast n)).eval x = rest.eval (extend x (g.eval (x i) (x j)))
          rw [dropLast_eval, eval_unused_last R hu0 x false (g.eval (x i) (x j)), hvR]

/-- Every ordinary circuit admits an equivalent live, essential-gate circuit.
This does not yet impose the additional triangle-free property. -/
theorem normalize_basic {n : Nat} (C : Circuit n) :
    ∃ D : OpenCircuit n,
      D.Live ∧ D.EssentialGates ∧ D.size ≤ C.size ∧ D.weight ≤ C.weight ∧
      ∀ x, D.eval x = C.eval x := by
  let R := (ofCircuit C).restrict (identitySubst n)
  obtain ⟨D, hl, he, hs, hw, hv⟩ := exists_live_essential R (restrict_essential _ _)
  refine ⟨D, hl, he, ?_, ?_, ?_⟩
  · exact Nat.le_trans hs (by simpa only [ofCircuit_size] using restrict_size_le (ofCircuit C) (identitySubst n))
  · exact Nat.le_trans hw (by simpa only [ofCircuit_weight] using restrict_weight_le (ofCircuit C) (identitySubst n))
  · intro x
    rw [hv]
    change ((ofCircuit C).restrict (identitySubst n)).eval x = C.eval x
    rw [restrict_eval, identity_eval, ofCircuit_eval]

end OpenCircuit
end SatLowerBound
