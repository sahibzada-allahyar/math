import SatLowerBound.RootOfUnity
import SatLowerBound.Mod3Degree
import Mathlib.Algebra.CharP.Two
import Mathlib.Algebra.BigOperators.Fin

namespace SatLowerBound

abbrev FourField := GaloisField 2 2

/-- A genuine four-element field supplies the omega in the manuscript. -/
theorem fourField_root_exists : ∃ z : FourField, z ^ 3 = 1 ∧ 1 + z + z ^ 2 = 0 := by
  classical
  let : Fintype FourField := Fintype.ofFinite _
  have hcard : Fintype.card FourField = 4 := by
    rw [← Nat.card_eq_fintype_card]
    exact GaloisField.card 2 2 (by decide : 2 ≠ 0)
  have hlt : ({0, 1} : Finset FourField).card < (Finset.univ : Finset FourField).card := by
    simp [hcard]
  obtain ⟨z, _, hz⟩ := Finset.exists_mem_notMem_of_card_lt_card hlt
  have hzpair : z ≠ 0 ∧ z ≠ 1 := by simpa using hz
  have hz0 := hzpair.1
  have hz1 := hzpair.2
  have hp : z ^ 3 = 1 := by
    simpa [hcard] using FiniteField.pow_card_sub_one_eq_one z hz0
  have hmul : (z - 1) * (1 + z + z ^ 2) = 0 := by linear_combination hp
  exact ⟨z, hp, (mul_eq_zero.mp hmul).resolve_left (sub_ne_zero.mpr hz1)⟩

def fieldBit {R : Type*} [Zero R] [One R] (b : Bool) : R := if b then 1 else 0

theorem fieldBit_xor {R : Type*} [CommRing R] [CharP R 2] (a b : Bool) :
    fieldBit (R := R) (Bool.xor a b) = fieldBit a + fieldBit b := by
  cases a <;> cases b <;> simp [fieldBit, CharTwo.add_self_eq_zero]

theorem product_of_bits {R : Type*} [CommMonoid R] (n : Nat) (a : R) (v : Fin n → Bool) :
    (∏ i : Fin n, if v i then a else 1) = a ^ ones n v := by
  induction n with
  | zero => simp [ones]
  | succ n ih =>
      rw [Fin.prod_univ_succ, ih]
      simp only [ones, pow_add]
      cases v 0 <;> simp

/-- The displayed F4 product identity, as equality in the algebra of Boolean-cube functions. -/
theorem mod3_field_product (z : FourField) (hz : z ^ 3 = 1)
    (hs : 1 + z + z ^ 2 = 0) (n : Nat) (t : Fin 3) (v : Fin n → Bool) :
    fieldBit (R := FourField) (mod3 n t v) =
      1 + z ^ (3 - t.val) * Finset.univ.prod (fun i : Fin n => 1 + z ^ 2 * fieldBit (v i)) +
        z ^ (2 * (3 - t.val)) * Finset.univ.prod (fun i : Fin n => 1 + z * fieldBit (v i)) := by
  have h1 : 1 + z = z ^ 2 := by
    rw [← CharTwo.neg_eq (z ^ 2)]
    exact eq_neg_of_add_eq_zero_left hs
  have h2 : 1 + z ^ 2 = z := by
    have he := CharTwo.neg_eq z
    linear_combination hs + he
  have hp1 : Finset.univ.prod (fun i : Fin n => 1 + z ^ 2 * fieldBit (v i)) = z ^ ones n v := by
    rw [← product_of_bits]
    apply Finset.prod_congr rfl
    intro i _
    cases v i <;> simp [fieldBit, h2]
  have hp2 : Finset.univ.prod (fun i : Fin n => 1 + z * fieldBit (v i)) = (z ^ 2) ^ ones n v := by
    rw [← product_of_bits]
    apply Finset.prod_congr rfl
    intro i _
    cases v i <;> simp [fieldBit, h1]
  rw [hp1, hp2, ← pow_mul, ← pow_add, ← pow_add]
  have he : 2 * (3 - t.val) + 2 * ones n v = 2 * (3 - t.val + ones n v) := by omega
  rw [he, cubic_root_filter z hz hs]
  have ht := t.isLt
  have hm : (3 - t.val + ones n v) % 3 = 0 ↔ ones n v % 3 = t.val := by omega
  have h3 : (3 : FourField) = 1 := by
    have h2 := CharTwo.two_eq_zero (R := FourField)
    linear_combination h2
  simp only [fieldBit, mod3, decide_eq_true_eq, hm, h3]

theorem field_factor_product (a b : FourField) (hab : 1 + a = b) (n : Nat) (v : Fin n → Bool) :
    Finset.univ.prod (fun i : Fin n => 1 + a * fieldBit (v i)) = b ^ ones n v := by
  rw [← product_of_bits]
  apply Finset.prod_congr rfl
  intro i _
  cases v i <;> simp [fieldBit, hab]

theorem mod3_field_filter (z : FourField) (hz : z ^ 3 = 1)
    (hs : 1 + z + z ^ 2 = 0) (n : Nat) (t : Fin 3) (v : Fin n → Bool) :
    fieldBit (R := FourField) (mod3 n t v) =
      1 + z ^ (3 - t.val) * z ^ ones n v +
        z ^ (2 * (3 - t.val)) * (z ^ 2) ^ ones n v := by
  have h1 : 1 + z = z ^ 2 := by
    rw [← CharTwo.neg_eq (z ^ 2)]
    exact eq_neg_of_add_eq_zero_left hs
  have h2 : 1 + z ^ 2 = z := by
    have he := CharTwo.neg_eq z
    linear_combination hs + he
  rw [mod3_field_product z hz hs, field_factor_product _ _ h2, field_factor_product _ _ h1]

theorem shifted_field_filter (z : FourField) (hz : z ^ 3 = 1)
    (hs : 1 + z + z ^ 2 = 0) (n : Nat) (t : Fin 3) (v : Fin n → Bool) :
    fieldBit (R := FourField) (shiftedFunction n t.val v) =
      1 + z ^ (n + 3 - t.val) * z ^ ones n v +
        z ^ (2 * (n + 3 - t.val)) * (z ^ 2) ^ ones n v := by
  let u : Fin 3 := ⟨(t.val + 3 - n % 3) % 3, Nat.mod_lt _ (by omega)⟩
  have ht := t.isLt
  have he : shiftedFunction n t.val v = mod3 n u v := by
    simp only [shiftedFunction, mod3, decide_eq_decide]
    dsimp [u]
    omega
  rw [he, mod3_field_filter z hz hs]
  have ha : (3 - u.val) % 3 = (n + 3 - t.val) % 3 := by dsimp [u]; omega
  have hb : (2 * (3 - u.val)) % 3 = (2 * (n + 3 - t.val)) % 3 := by dsimp [u]; omega
  rw [pow_eq_pow_mod (3 - u.val) hz, pow_eq_pow_mod (n + 3 - t.val) hz,
    pow_eq_pow_mod (2 * (3 - u.val)) hz, pow_eq_pow_mod (2 * (n + 3 - t.val)) hz, ha, hb]

def lastCubeSum {R : Type*} [AddCommMonoid R] : (n : Nat) → ((Fin n → Bool) → R) → R
  | 0, f => f (fun i => Fin.elim0 i)
  | n + 1, f => lastCubeSum n (fun v => f (extend v false)) +
      lastCubeSum n (fun v => f (extend v true))

theorem lastCubeSum_add {R : Type*} [AddCommMonoid R] (n : Nat)
    (f g : (Fin n → Bool) → R) :
    lastCubeSum n (fun v => f v + g v) = lastCubeSum n f + lastCubeSum n g := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [lastCubeSum, ih]; ac_rfl

theorem lastCubeSum_const {R : Type*} [CommRing R] (n : Nat) (a : R) :
    lastCubeSum n (fun _ => a) = 2 ^ n * a := by
  induction n with
  | zero => simp [lastCubeSum]
  | succ n ih => simp only [lastCubeSum, ih, pow_succ]; ring

theorem lastCubeSum_mul {R : Type*} [CommRing R] (n : Nat)
    (a : R) (f : (Fin n → Bool) → R) :
    lastCubeSum n (fun v => a * f v) = a * lastCubeSum n f := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [lastCubeSum, ih, mul_add]

theorem lastCubeSum_pow_ones {R : Type*} [CommRing R] (n : Nat) (a : R) :
    lastCubeSum n (fun v => a ^ ones n v) = (1 + a) ^ n := by
  induction n with
  | zero => simp [lastCubeSum, ones]
  | succ n ih =>
      simp only [lastCubeSum, ones_extend, Bool.false_eq_true, ↓reduceIte,
        Nat.add_zero, pow_succ, ih]
      have he : (fun v => a ^ ones n v * a) = (fun v => a * a ^ ones n v) := by
        funext v; ring
      rw [he, lastCubeSum_mul, ih]
      ring

/-- A multilinear top coefficient is the characteristic-two sum of Boolean values. -/
theorem topCoefficient_field_sum {R : Type*} [CommRing R] [CharP R 2]
    (n : Nat) (f : (Fin n → Bool) → Bool) :
    fieldBit (R := R) (BPoly.ofFunction n f).topCoefficient =
      lastCubeSum n (fun v => fieldBit (f v)) := by
  induction n with
  | zero => rfl
  | succ n ih =>
      rw [BPoly.top_function_step, fieldBit_xor, ih, ih]
      rfl

theorem last_cubic_filter {R : Type*} [CommRing R] (z : R)
    (hz : z ^ 3 = 1) (hs : 1 + z + z ^ 2 = 0) (n a : Nat) :
    lastCubeSum n (fun v => if (a + ones n v) % 3 = 0 then (3 : R) else 0) =
      2 ^ n + z ^ a * (1 + z) ^ n + z ^ (2 * a) * (1 + z ^ 2) ^ n := by
  have hf : (fun v => if (a + ones n v) % 3 = 0 then (3 : R) else 0) =
      (fun v => 1 + z ^ a * z ^ ones n v + z ^ (2 * a) * (z ^ 2) ^ ones n v) := by
    funext v
    rw [← cubic_root_filter z hz hs]
    simp only [pow_add, Nat.mul_add, pow_mul]
  rw [hf, lastCubeSum_add, lastCubeSum_add, lastCubeSum_const, lastCubeSum_mul,
    lastCubeSum_mul, lastCubeSum_pow_ones, lastCubeSum_pow_ones, mul_one]

/-- The finite-field root filter gives the TeX top-coefficient criterion. -/
theorem shifted_top_via_fourField (n : Nat) (hn : 0 < n) (t : Fin 3) :
    (BPoly.ofFunction n (shiftedFunction n t.val)).topCoefficient = decide (t.val ≠ 0) := by
  obtain ⟨z, hz, hs⟩ := fourField_root_exists
  let a := n + 3 - t.val
  have ht := t.isLt
  have h : fieldBit (R := FourField) (BPoly.ofFunction n (shiftedFunction n t.val)).topCoefficient =
      2 ^ n + z ^ a * (1 + z) ^ n + z ^ (2 * a) * (1 + z ^ 2) ^ n := by
    rw [topCoefficient_field_sum]
    simp_rw [shifted_field_filter z hz hs n t]
    rw [lastCubeSum_add, lastCubeSum_add, lastCubeSum_const, lastCubeSum_mul,
      lastCubeSum_mul, lastCubeSum_pow_ones, lastCubeSum_pow_ones, mul_one]
  have h1 : 1 + z = z ^ 2 := by
    have he : -(z ^ 2) = z ^ 2 := CharTwo.neg_eq _
    rw [← he]
    exact eq_neg_of_add_eq_zero_left hs
  have h2 : 1 + z ^ 2 = z := by
    have he : -z = z := CharTwo.neg_eq _
    rw [← he]
    linear_combination hs
  rw [CharTwo.two_eq_zero (R := FourField), zero_pow (by omega : n ≠ 0), zero_add, h1, h2,
    ← pow_mul, ← pow_add, ← pow_add] at h
  rw [pow_eq_pow_mod (a + 2 * n) hz, pow_eq_pow_mod (2 * a + n) hz] at h
  have hcases : t.val = 0 ∨ t.val = 1 ∨ t.val = 2 := by omega
  have hinj : Function.Injective (fieldBit (R := FourField)) := by
    intro b c he
    cases b <;> cases c <;> simp_all [fieldBit]
  apply hinj
  rw [h]
  rcases hcases with ht0 | ht1 | ht2
  · have ha : (a + 2 * n) % 3 = 0 := by dsimp [a]; omega
    have hb : (2 * a + n) % 3 = 0 := by dsimp [a]; omega
    simp [ha, hb, ht0, fieldBit, CharTwo.add_self_eq_zero]
  · have ha : (a + 2 * n) % 3 = 2 := by dsimp [a]; omega
    have hb : (2 * a + n) % 3 = 1 := by dsimp [a]; omega
    simp only [ha, hb, ht1, pow_one, ne_eq, Nat.one_ne_zero, not_false_eq_true,
      decide_true, fieldBit, ↓reduceIte]
    have he := CharTwo.neg_eq (1 : FourField)
    linear_combination hs + he
  · have ha : (a + 2 * n) % 3 = 1 := by dsimp [a]; omega
    have hb : (2 * a + n) % 3 = 2 := by dsimp [a]; omega
    simp only [ha, hb, ht2, pow_one, ne_eq, Nat.reduceEqDiff, not_false_eq_true,
      decide_true, fieldBit, ↓reduceIte]
    have he := CharTwo.neg_eq (1 : FourField)
    linear_combination hs + he

theorem helperBlock_full_degree_fourField (n : Nat) :
    (BPoly.ofFunction (n + 1) (helperBlock (n + 1))).topCoefficient = true := by
  unfold helperBlock
  rw [BPoly.ofFunction_not, BPoly.top_add, BPoly.top_one, Bool.false_xor]
  exact shifted_top_via_fourField (n + 1) (by omega) 1

end SatLowerBound
