import SatLowerBound.ModularBlocks

namespace SatLowerBound

theorem tally_setPair {n : Nat} (S : Finset (Fin n)) (x y : Fin n)
    (hxy : x ≠ y) (hx : x ∈ S) (hy : y ∈ S) (a b : Bool) (v : Fin n → Bool) :
    tally S (setPair v x y a b) = indicator a + indicator b + tally ((S.erase x).erase y) v := by
  have hy' : y ∈ S.erase x := Finset.mem_erase.mpr ⟨Ne.symm hxy, hy⟩
  change tally S (fixBit x a (fixBit y b v)) = _
  rw [tally_fixBit S x hx, tally_fixBit (S.erase x) y hy']
  omega

set_option maxRecDepth 4096 in
theorem response_tests_injective (a b t : Fin 3) (c : Bool)
    (h0 : Bool.xor (decide (a.val % 3 = t.val)) c = Bool.xor (decide (b.val % 3 = t.val)) c)
    (h1 : Bool.xor (decide ((a.val + 1) % 3 = t.val)) c = Bool.xor (decide ((b.val + 1) % 3 = t.val)) c) :
    a = b := by
  revert a b t c
  decide

theorem modularBlock_rows_ne {n : Nat} (S : Finset (Fin n)) (t : Fin 3) (c : Bool)
    (hS : 3 ≤ S.card) (x y : Fin n) (hxy : x ≠ y) (hx : x ∈ S) (hy : y ∈ S)
    (p q : Bool × Bool) (hpq : indicator p.1 + indicator p.2 ≠ indicator q.1 + indicator q.2) :
    PairRow (fun a b v => modularBlock S t c (setPair v x y a b)) p ≠
      PairRow (fun a b v => modularBlock S t c (setPair v x y a b)) q := by
  intro he
  have hy' : y ∈ S.erase x := Finset.mem_erase.mpr ⟨Ne.symm hxy, hy⟩
  have hcard : 1 ≤ ((S.erase x).erase y).card := by
    rw [Finset.card_erase_of_mem hy', Finset.card_erase_of_mem hx]
    omega
  obtain ⟨u, hu⟩ := tally_realize ((S.erase x).erase y) 0 (Nat.zero_le _)
  obtain ⟨v, hv⟩ := tally_realize ((S.erase x).erase y) 1 hcard
  have bound (r : Bool × Bool) : indicator r.1 + indicator r.2 < 3 := by
    rcases r with ⟨a, b⟩
    cases a <;> cases b <;> decide
  let a : Fin 3 := ⟨indicator p.1 + indicator p.2, bound p⟩
  let b : Fin 3 := ⟨indicator q.1 + indicator q.2, bound q⟩
  have h0 := congrFun he u
  have h1 := congrFun he v
  simp only [PairRow, modularBlock, tally_setPair S x y hxy hx hy, hu, Nat.add_zero] at h0
  simp only [PairRow, modularBlock, tally_setPair S x y hxy hx hy, hv] at h1
  exact hpq (congrArg Fin.val (response_tests_injective a b t c h0 h1))

theorem modularBlock_pairSeparated {n : Nat} (S : Finset (Fin n)) (t : Fin 3) (c : Bool)
    (hS : 3 ≤ S.card) (x y : Fin n) (hxy : x ≠ y) (hx : x ∈ S) (hy : y ∈ S) :
    PairSeparated (modularBlock S t c) x y := by
  refine ⟨(false, false), (false, true), (true, true), ?_, ?_, ?_⟩
  · exact modularBlock_rows_ne S t c hS x y hxy hx hy _ _ (by decide)
  · exact modularBlock_rows_ne S t c hS x y hxy hx hy _ _ (by decide)
  · exact modularBlock_rows_ne S t c hS x y hxy hx hy _ _ (by decide)

end SatLowerBound
