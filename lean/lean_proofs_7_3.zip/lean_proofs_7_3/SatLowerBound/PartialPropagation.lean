import SatLowerBound.TriangleNormalization

namespace SatLowerBound

/-- Propagate constants through a truth table, including a blocking cofactor. -/
def Table.partial (g : Table) : Option Bool → Option Bool → Option Bool
  | some a, some b => some (g.eval a b)
  | some a, none => if g.eval a false = g.eval a true then some (g.eval a false) else none
  | none, some b => if g.eval false b = g.eval true b then some (g.eval false b) else none
  | none, none => none

theorem Table.partial_mark_bounds (g : Table) (a b : Option Bool) :
    ((g.partial a b).isSome = true → (a.isSome || b.isSome) = true) ∧
    ((a.isSome && b.isSome) = true → (g.partial a b).isSome = true) := by
  cases a <;> cases b <;> simp [Table.partial]

theorem Table.essential_weight_parity (g : Table) (h : g.essential = true) :
    g.weight = 2 + indicator g.parity := by
  revert h
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

abbrev PartialState (n : Nat) := Fin n → Option Bool

def PartialState.mask {n : Nat} (κ : PartialState n) : Fin n → Bool := fun i => (κ i).isSome

def PartialState.next {n : Nat} (κ : PartialState n) (g : Table) (i j : Fin n) :
    PartialState (n + 1) := OpenCircuit.appendValue κ (g.partial (κ i) (κ j))

theorem PartialState.mask_next {n : Nat} (κ : PartialState n) (g : Table) (i j : Fin n) :
    (κ.next g i j).mask = extend κ.mask (g.partial (κ i) (κ j)).isSome := by
  funext k
  simp only [PartialState.mask, PartialState.next, OpenCircuit.appendValue, extend]
  split <;> rfl

namespace OpenCircuit

def propagatedOutput : {n : Nat} → OpenCircuit n → PartialState n → Bool
  | _, .output (.constant _), _ => true
  | _, .output (.wire i _), κ => (κ i).isSome
  | _, .gate g i j rest, κ => propagatedOutput rest (κ.next g i j)

def propagationLoss : {n : Nat} → OpenCircuit n → PartialState n → Nat
  | _, .output _, _ => 0
  | _, .gate g i j rest, κ =>
      indicator (κ.mask i || κ.mask j) + propagationLoss rest (κ.next g i j)

/-- A new constant produced with exactly one constant predecessor. -/
def propagationBirths : {n : Nat} → OpenCircuit n → PartialState n → Nat
  | _, .output _, _ => 0
  | _, .gate g i j rest, κ =>
      indicator (Bool.xor (κ.mask i) (κ.mask j) && (g.partial (κ i) (κ j)).isSome) +
        propagationBirths rest (κ.next g i j)

def propagationParity : {n : Nat} → OpenCircuit n → PartialState n → Nat
  | _, .output _, _ => 0
  | _, .gate g i j rest, κ =>
      indicator ((κ.mask i || κ.mask j) && g.parity) + propagationParity rest (κ.next g i j)

/-- Each one-predecessor constant birth pays for one additional deleted gate.
This is the strengthened constant-closure count used by weighted elimination. -/
theorem propagationLoss_ge_uses_births {n : Nat} (C : OpenCircuit n) (κ : PartialState n)
    (hl : C.Live) (ho : C.propagatedOutput κ = false) :
    C.markedUses κ.mask + C.propagationBirths κ ≤ C.propagationLoss κ := by
  induction C with
  | output s =>
    cases s with
    | constant b => contradiction
    | wire i b =>
      change (κ i).isSome = false at ho
      simp [markedUses, usage, propagationBirths, propagationLoss, PartialState.mask, ho, indicator]
  | gate g i j rest ih =>
    have hr := ih (κ.next g i j) hl.2 ho
    rw [PartialState.mask_next] at hr
    have hb := g.partial_mark_bounds (κ i) (κ j)
    have hpos := hl.1
    rw [markedUses_gate]
    simp only [propagationBirths, propagationLoss]
    change (((g.partial (κ i) (κ j)).isSome = true → (κ.mask i || κ.mask j) = true) ∧
      ((κ.mask i && κ.mask j) = true → (g.partial (κ i) (κ j)).isSome = true)) at hb
    cases hi : κ.mask i <;> cases hj : κ.mask j <;>
      cases hz : (g.partial (κ i) (κ j)).isSome <;>
      simp only [hi, hj, hz, Bool.false_and, Bool.true_and, Bool.false_or, Bool.true_or,
        Bool.false_xor, Bool.true_xor, Bool.not_true, Bool.not_false,
        indicator, Bool.false_eq_true, ↓reduceIte] at hr hb ⊢
    all_goals first | contradiction | omega | (rw [markedUses_extend_true] at hr; omega)

/-- The partial evaluator's certified constants agree with the compiler substitution. -/
def PartialMatches {n m : Nat} (κ : PartialState n) (σ : Fin n → Signal m) : Prop :=
  ∀ i b, κ i = some b → σ i = .constant b

theorem partial_alias_constant {m : Nat} (g : Table) (a b : Option Bool)
    (s t : Signal m) (ha : ∀ v, a = some v → s = .constant v)
    (hb : ∀ v, b = some v → t = .constant v)
    (v : Bool) (hv : g.partial a b = some v) :
    simplifyGate g s t = .alias (.constant v) := by
  cases a with
  | none =>
    cases b with
    | none => contradiction
    | some b =>
      have ht := hb b rfl
      subst t
      simp only [Table.partial] at hv
      split at hv
      · rename_i hg
        cases hv
        cases s with
        | constant a => cases a <;> simp_all [simplifyGate]
        | wire i c =>
          cases c <;> simp_all [simplifyGate, Signal.unary]
      · contradiction
  | some a =>
    have hs := ha a rfl
    subst s
    cases b with
    | none =>
      simp only [Table.partial] at hv
      split at hv
      · rename_i hg
        cases hv
        cases t with
        | constant b => cases b <;> simp_all [simplifyGate]
        | wire j c =>
          cases c <;> simp_all [simplifyGate, Signal.unary]
      · contradiction
    | some b =>
      have ht := hb b rfl
      subst t
      cases hv
      rfl

theorem partial_binary_unmarked {n m : Nat} (κ : PartialState n) (σ : Fin n → Signal m)
    (hm : PartialMatches κ σ) (g h : Table) (i j : Fin n) (k l : Fin m)
    (hs : simplifyGate g (σ i) (σ j) = .binary h k l) :
    κ.mask i = false ∧ κ.mask j = false ∧ g.partial (κ i) (κ j) = none := by
  have hi : κ i = none := by
    cases hki : κ i with
    | none => rfl
    | some b =>
      rw [hm i b hki] at hs
      cases hsj : σ j <;> simp [simplifyGate, hsj] at hs
  have hj : κ j = none := by
    cases hkj : κ j with
    | none => rfl
    | some b =>
      rw [hm j b hkj] at hs
      cases hsi : σ i <;> simp [simplifyGate, hsi] at hs
  simp [PartialState.mask, hi, hj, Table.partial]

theorem partial_matches_alias {n m : Nat} (κ : PartialState n) (σ : Fin n → Signal m)
    (hm : PartialMatches κ σ) (g : Table) (i j : Fin n) (s : Signal m)
    (hs : simplifyGate g (σ i) (σ j) = .alias s) :
    PartialMatches (κ.next g i j) (extendSubst σ s) := by
  intro k b hk
  simp only [PartialState.next, appendValue] at hk
  simp only [extendSubst]
  split at hk
  · rename_i hkn
    simp only [hkn, ↓reduceDIte]
    exact hm _ b hk
  · rename_i hkn
    simp only [hkn, ↓reduceDIte]
    have hc := partial_alias_constant g _ _ _ _ (hm i) (hm j) b hk
    rw [hs] at hc
    exact GateStep.alias.inj hc

theorem partial_matches_lift {n m : Nat} (κ : PartialState n) (σ : Fin n → Signal m)
    (hm : PartialMatches κ σ) (g : Table) (i j : Fin n)
    (hn : g.partial (κ i) (κ j) = none) :
    PartialMatches (κ.next g i j) (liftSubst σ) := by
  intro k b hk
  simp only [PartialState.next, appendValue, hn] at hk
  simp only [liftSubst, extendSubst]
  split at hk
  · rename_i hkn
    simp only [hkn, ↓reduceDIte, hm _ b hk, Signal.rename]
  · contradiction

theorem propagation_weight_loss {n m : Nat} (C : OpenCircuit n) (κ : PartialState n)
    (σ : Fin n → Signal m) (hm : PartialMatches κ σ) (he : C.EssentialGates) :
    (C.restrict σ).weight + 2 * C.propagationLoss κ + C.propagationParity κ ≤ C.weight := by
  induction C generalizing m with
  | output => exact Nat.le_refl 0
  | gate g i j rest ih =>
    simp only [restrict]
    split
    · rename_i s hs
      have hr := ih (κ.next g i j) (extendSubst σ s) (partial_matches_alias κ σ hm g i j s hs) he.2
      have hg := g.essential_weight_parity he.1
      unfold indicator at hg
      simp only [weight, propagationLoss, propagationParity]
      cases hb : (κ.mask i || κ.mask j) <;>
        simp only [Bool.false_and, Bool.true_and, indicator, Bool.false_eq_true, ↓reduceIte] <;>
        omega
    · rename_i h k l hs
      obtain ⟨hi, hj, hn⟩ := partial_binary_unmarked κ σ hm g h i j k l hs
      have hr := ih (κ.next g i j) (liftSubst σ) (partial_matches_lift κ σ hm g i j hn) he.2
      have hg := simplifyGate_weight g (σ i) (σ j)
      rw [hs] at hg
      change h.weight ≤ g.weight at hg
      simp only [weight, propagationLoss, propagationParity, hi, hj, Bool.false_or,
        Bool.false_and, indicator, Bool.false_eq_true, ↓reduceIte]
      omega

theorem propagation_weight_gain {n m : Nat} (C : OpenCircuit n) (κ : PartialState n)
    (σ : Fin n → Signal m) (hm : PartialMatches κ σ)
    (hl : C.Live) (he : C.EssentialGates) (ho : C.propagatedOutput κ = false) :
    (C.restrict σ).weight + 2 * C.markedUses κ.mask + 2 * C.propagationBirths κ +
      C.propagationParity κ ≤ C.weight := by
  have hc := C.propagationLoss_ge_uses_births κ hl ho
  have hw := C.propagation_weight_loss κ σ hm he
  omega

end OpenCircuit
end SatLowerBound
