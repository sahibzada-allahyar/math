import SatLowerBound.Pruning
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Data.Fintype.Fin
import Mathlib.Algebra.BigOperators.Group.Finset.Piecewise
import Mathlib.Algebra.Order.BigOperators.Group.Finset

namespace SatLowerBound

def Nonconstant {n : Nat} (f : (Fin n → Bool) → Bool) : Prop :=
  ∃ x y, f x ≠ f y

def Essential {n : Nat} (f : (Fin n → Bool) → Bool) (i : Fin n) : Prop :=
  ∃ x y, (∀ j, j ≠ i → x j = y j) ∧ f x ≠ f y

namespace OpenCircuit

theorem eval_eq_of_closure {n : Nat} (C : OpenCircuit n) (p : Fin n → Bool)
    (x y : Fin n → Bool) (hxy : ∀ i, p i = true → x i = y i)
    (ho : C.closureOutput p = true) : C.eval x = C.eval y := by
  induction C with
  | output s =>
    cases s with
    | constant b => rfl
    | wire i b => exact congrArg (fun v => Bool.xor v b) (hxy i ho)
  | gate g i j rest ih =>
    apply ih (extend p (p i && p j)) _ _ _ ho
    intro k hk
    simp only [extend] at hk ⊢
    split at hk
    · rename_i h
      simp only [h, ↓reduceDIte]
      exact hxy _ hk
    · rename_i h
      simp only [h, ↓reduceDIte]
      have hi : p i = true := by cases hh : p i <;> simp_all
      have hj : p j = true := by cases hh : p j <;> simp_all
      rw [hxy i hi, hxy j hj]

theorem closureOutput_false {n m : Nat} (C : OpenCircuit n) (p : Fin n → Bool)
    (σ : Fin n → Signal m) (hm : MarksConstants p σ)
    (hn : Nonconstant (C.restrict σ).eval) : C.closureOutput p = false := by
  cases ho : C.closureOutput p
  · rfl
  · obtain ⟨x, y, hxy⟩ := hn
    apply False.elim
    apply hxy
    rw [restrict_eval, restrict_eval]
    apply eval_eq_of_closure C p _ _ _ ho
    intro i hi
    obtain ⟨b, hb⟩ := hm i hi
    rw [hb]
    rfl

def singleUse {n : Nat} (i : Fin n) : Fin n → Nat := fun j => if j = i then 1 else 0

theorem essential_has_use {n : Nat} (C : OpenCircuit n) (i : Fin n)
    (he : Essential C.eval i) : 0 < C.usage (singleUse i) := by
  by_contra h
  have hu : C.usage (singleUse i) = 0 := Nat.eq_zero_of_not_pos h
  obtain ⟨x, y, hsame, hdiff⟩ := he
  apply hdiff
  apply eval_eq_of_zero_usage C _ hu
  intro j hj
  have hji : j ≠ i := by
    intro heq
    simp [singleUse, heq] at hj
  exact hsame j hji

theorem usage_sum {n : Nat} {α : Type} (C : OpenCircuit n) (s : Finset α)
    (f : α → Fin n → Nat) :
    C.usage (fun i => ∑ a ∈ s, f a i) = ∑ a ∈ s, C.usage (f a) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [usage_zero]
  | @insert a s ha ih => simp only [Finset.sum_insert ha, usage_add, ih]

theorem markedUses_eq_sum {n : Nat} (C : OpenCircuit n) (p : Fin n → Bool) :
    C.markedUses p = ∑ i : Fin n, if p i then C.usage (singleUse i) else 0 := by
  have hfun : (fun i => indicator (p i)) =
      (fun i => ∑ a : Fin n, if i = a then indicator (p a) else 0) := by
    funext i
    simp
  unfold markedUses
  rw [hfun, usage_sum]
  apply Finset.sum_congr rfl
  intro i _
  cases hi : p i
  · simp [indicator, usage_zero]
  · simp only [indicator, ↓reduceIte]
    rfl

theorem markedCount_le_uses {n : Nat} (C : OpenCircuit n) (p : Fin n → Bool)
    (he : ∀ i, Essential C.eval i) :
    (∑ i : Fin n, indicator (p i)) ≤ C.markedUses p := by
  rw [markedUses_eq_sum]
  apply Finset.sum_le_sum
  intro i _
  cases hi : p i
  · simp [indicator]
  · simpa only [indicator, ↓reduceIte] using Nat.succ_le_of_lt (C.essential_has_use i (he i))

/-- The restriction transfer used in the SAT embedding: every fixed essential
input pays for a removed gate in one shared circuit. -/
theorem restriction_transfer {n m : Nat} (C : OpenCircuit n)
    (p : Fin n → Bool) (σ : Fin n → Signal m)
    (hm : MarksConstants p σ) (hl : C.Live)
    (he : ∀ i, Essential C.eval i) (hn : Nonconstant (C.restrict σ).eval) :
    (C.restrict σ).size + (∑ i : Fin n, indicator (p i)) ≤ C.size := by
  have hc := C.constant_closure_deletion p σ hm hl (closureOutput_false C p σ hm hn)
  exact Nat.le_trans (Nat.add_le_add_left (markedCount_le_uses C p he) _) hc

end OpenCircuit
end SatLowerBound
