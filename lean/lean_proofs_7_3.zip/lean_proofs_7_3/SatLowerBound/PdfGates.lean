import SatLowerBound.Restriction
import Mathlib.Data.Fintype.Prod
import Mathlib.Data.Fintype.Card

namespace SatLowerBound
namespace Table

/-- PDF Proposition 2.4: the nonlinear class is exactly AND with input/output complements. -/
theorem nonlinear_iff (g : Table) : g.nonlinear = true ↔
    ∃ a b c : Bool, ∀ x y : Bool,
      g.eval x y = Bool.xor (Bool.xor x a && Bool.xor y b) c := by
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

instance : Fintype Table := Fintype.ofEquiv (Bool × Bool × Bool × Bool)
  { toFun := fun p => ⟨p.1, p.2.1, p.2.2.1, p.2.2.2⟩
    invFun := fun g => (g.ff, g.ft, g.tf, g.tt)
    left_inv := fun _ => rfl
    right_inv := fun _ => rfl }

theorem card_all : Fintype.card Table = 16 := by decide
theorem card_parity : (Finset.univ.filter (fun g : Table => g.parity)).card = 2 := by decide
theorem card_nonlinear : (Finset.univ.filter (fun g : Table => g.nonlinear)).card = 8 := by decide
theorem essential_classification (g : Table) :
    g.essential = true ↔ (g.parity = true ∨ g.nonlinear = true) := by
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide
theorem classes_disjoint (g : Table) : ¬ (g.parity = true ∧ g.nonlinear = true) := by
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide
theorem complement_classes (g : Table) :
    g.complement.parity = g.parity ∧ g.complement.nonlinear = g.nonlinear := by
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide
theorem twist_classes (g : Table) (a b : Bool) :
    (twist g a b).parity = g.parity ∧ (twist g a b).nonlinear = g.nonlinear := by
  rcases g with ⟨c, d, e, f⟩
  cases a <;> cases b <;> cases c <;> cases d <;> cases e <;> cases f <;> decide

end Table
end SatLowerBound
