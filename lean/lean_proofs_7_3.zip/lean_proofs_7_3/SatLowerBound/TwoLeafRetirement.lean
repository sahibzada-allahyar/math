import SatLowerBound.ContextRetirement
import SatLowerBound.AmbientTerminal

namespace SatLowerBound
namespace ModularContext

theorem pair_retire_eval {n : Nat} (K : ModularContext n) (S : Finset (Fin n))
    (hf : K.Fits 3 S) (R : ModularTree n) (hr : K.retire = some R)
    (x y : Fin n) (hx : x ∈ S) (hy : y ∈ S) (t : Fin 3) (c a b : Bool)
    (hv : ∀ v, modularBlock {x, y} t c (setPair v x y a b) = K.neutral)
    (v : Fin n → Bool) :
    (K.plug (.leaf {x, y} t c)).eval (setPair v x y a b) = R.eval v := by
  rw [K.retire_eval R (.leaf {x, y} t c) hr (setPair v x y a b) (hv v)]
  have hs := (K.retire_stats R hr).1
  have hdis := K.fits_disjoint S hf
  have hxt : x ∉ R.support := by rw [hs]; exact fun hh => Finset.disjoint_left.mp hdis hx hh
  have hyt : y ∉ R.support := by rw [hs]; exact fun hh => Finset.disjoint_left.mp hdis hy hh
  rw [R.supported.pair_right x y hxt, R.supported.fixBit_outside y hyt]

theorem pair_parity_slice {n : Nat} (K : ModularContext n) (S : Finset (Fin n))
    (hf : K.Fits 3 S) (x y : Fin n) (hxy : x ≠ y) (hx : x ∈ S) (hy : y ∈ S) (c : Bool) :
    PairParitySlice (K.plug (.leaf {x, y} 1 c)).eval x y := by
  obtain ⟨v, hv⟩ := K.expose S (hf.mono (by omega))
  have hd := K.fits_disjoint S hf
  have hxt : x ∉ K.support := fun hh => Finset.disjoint_left.mp hd hx hh
  have hyt : y ∉ K.support := fun hh => Finset.disjoint_left.mp hd hy hh
  refine ⟨v, c, ?_⟩
  intro a b
  rw [K.plug_eval]
  change K.evalHole (modularBlock {x, y} 1 c (setPair v x y a b)) (setPair v x y a b) = _
  rw [modularBlock_pair_parity x y hxy, (K.evalHole_supported _).pair_right x y hxt,
    (K.evalHole_supported _).fixBit_outside y hyt, hv]

theorem pair_neutral_assignment {n : Nat} (K : ModularContext n) (x y : Fin n)
    (hxy : x ≠ y) (t : Fin 3) (c : Bool) :
    ∃ a b, ∀ v, modularBlock {x, y} t c (setPair v x y a b) = K.neutral := by
  have hc : ({x, y} : Finset (Fin n)).card = 2 := by simp [hxy]
  obtain ⟨u, hu⟩ := (modularBlock_nonconstant {x, y} t c (by omega)).has_value K.neutral
  refine ⟨u x, u y, ?_⟩
  intro v
  rw [← hu]
  apply modularBlock_supported
  intro i hi
  simp only [Finset.mem_insert, Finset.mem_singleton] at hi
  rcases hi with hi | hi
  · subst i; simp
  · subst i; exact setPair_right v x y (u x) (u y) hxy

theorem retire_two_inputs {n : Nat} (K : ModularContext n) (S : Finset (Fin n))
    (hf : K.Fits 3 S) (R : ModularTree n) (hr : K.retire = some R)
    (x y : Fin n) (hxy : x ≠ y) (hx : x ∈ S) (hy : y ∈ S) (t : Fin 3) (c : Bool)
    (C : OpenCircuit n) (hc : ∀ v, C.eval v = (K.plug (.leaf {x, y} t c)).eval v) :
    ∃ D : OpenCircuit n, (∀ v, D.eval v = R.eval v) ∧ D.weight + 4 ≤ C.weight := by
  obtain ⟨E, he, _, _, hw, hev⟩ := C.normalize_full_open
  have hE (v : Fin n → Bool) : E.eval v = (K.plug (.leaf {x, y} t c)).eval v := (hev v).trans (hc v)
  have hfun := funext hE
  have hvalid : (K.plug (.leaf {x, y} t c)).Valid 2 := by
    apply K.plug_valid S (hf.mono (by omega))
    · change 2 ≤ ({x, y} : Finset (Fin n)).card
      simp [hxy]
    · intro i hi
      simp only [ModularTree.support, Finset.mem_insert, Finset.mem_singleton] at hi
      rcases hi with rfl | rfl <;> assumption
  have hxe : Essential E.eval x := by
    rw [hfun]
    apply ModularTree.essential _ hvalid
    rw [plug_support]
    simp [ModularTree.support]
  have hye : Essential E.eval y := by
    rw [hfun]
    apply ModularTree.essential _ hvalid
    rw [plug_support]
    simp [ModularTree.support]
  obtain ⟨a, b, hab⟩ := K.pair_neutral_assignment x y hxy t c
  have hret (v : Fin n → Bool) : E.eval (setPair v x y a b) = R.eval v := by
    rw [hE]
    exact K.pair_retire_eval S hf R hr x y hx hy t c a b hab v
  have hn : Nonconstant (fun v => E.eval (setPair v x y a b)) := by
    have hR := R.nonconstant ((K.retire_valid S hf R hr).mono (by omega))
    simpa only [Nonconstant, hret] using hR
  have hdrop := E.two_input_retirement x y a b hxy he hxe hye hn
  refine ⟨E.restrict (pairSubst x y a b), ?_, by omega⟩
  intro v
  rw [OpenCircuit.restrict_pair_eval, hret]

theorem retire_parity_inputs {n : Nat} (K : ModularContext n) (S : Finset (Fin n))
    (hf : K.Fits 3 S) (R : ModularTree n) (hr : K.retire = some R)
    (x y : Fin n) (hxy : x ≠ y) (hx : x ∈ S) (hy : y ∈ S) (c : Bool)
    (C : OpenCircuit n) (hc : ∀ v, C.eval v = (K.plug (.leaf {x, y} 1 c)).eval v) :
    ∃ D : OpenCircuit n, (∀ v, D.eval v = R.eval v) ∧ D.weight + 5 ≤ C.weight := by
  obtain ⟨E, he, _, _, hw, hev⟩ := C.normalize_full_open
  have hE (v : Fin n → Bool) : E.eval v = (K.plug (.leaf {x, y} 1 c)).eval v := (hev v).trans (hc v)
  have hfun := funext hE
  have hs : PairParitySlice E.eval x y := by
    rw [hfun]
    exact K.pair_parity_slice S hf x y hxy hx hy c
  let s := Bool.xor K.neutral c
  have hab (a : Bool) (v : Fin n → Bool) :
      modularBlock {x, y} 1 c (setPair v x y a (Bool.xor a s)) = K.neutral := by
    rw [modularBlock_pair_parity x y hxy]
    simp only [s]
    cases a <;> cases c <;> cases K.neutral <;> rfl
  have hret (a : Bool) (v : Fin n → Bool) : E.eval (setPair v x y a (Bool.xor a s)) = R.eval v := by
    rw [hE]
    exact K.pair_retire_eval S hf R hr x y hx hy 1 c a (Bool.xor a s) (hab a) v
  have hn (a : Bool) : Nonconstant (fun v => E.eval (setPair v x y a (Bool.xor a s))) := by
    have hR := R.nonconstant ((K.retire_valid S hf R hr).mono (by omega))
    simpa only [Nonconstant, hret] using hR
  obtain ⟨a, hdrop⟩ := E.parity_retirement x y s hxy he hs hn
  refine ⟨E.restrict (pairSubst x y a (Bool.xor a s)), ?_, by omega⟩
  intro v
  rw [OpenCircuit.restrict_pair_eval, hret]

end ModularContext
end SatLowerBound
