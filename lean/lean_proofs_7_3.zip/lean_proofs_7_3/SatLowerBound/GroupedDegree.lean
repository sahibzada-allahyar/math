import SatLowerBound.CompositionDegree
import SatLowerBound.FiniteFieldDegree
import SatLowerBound.SparseRestriction

namespace SatLowerBound

def groupedAll (k n : Nat) (f : (Fin n → Bool) → Bool) (x : Fin (k * n) → Bool) : Bool :=
  decide (∀ c : Fin k, f (fun b => x (pairIndex c b)) = true)

def groupedAny (k n : Nat) (f : (Fin n → Bool) → Bool) (x : Fin (k * n) → Bool) : Bool :=
  decide (∃ c : Fin k, f (fun b => x (pairIndex c b)) = true)

theorem top_function_cast {n m : Nat} (h : n = m) (f : (Fin m → Bool) → Bool) :
    (BPoly.ofFunction n (fun x => f (fun i => x (Fin.cast h.symm i)))).topCoefficient =
      (BPoly.ofFunction m f).topCoefficient := by
  subst m
  rfl

theorem groupedAll_step (k n : Nat) (f : (Fin n → Bool) → Bool)
    (x : Fin (k * n + n) → Bool) :
    groupedAll (k + 1) n f (fun i => x (Fin.cast (Nat.succ_mul k n) i)) =
      (groupedAll k n f (leftBits x) && f (rightBits x)) := by
  apply Bool.eq_iff_iff.mpr
  simp only [groupedAll, decide_eq_true_eq, Bool.and_eq_true]
  constructor
  · intro h
    exact ⟨fun c => h c.castSucc, h (Fin.last k)⟩
  · rintro ⟨hl, hr⟩ c
    exact Fin.lastCases hr (fun j => hl j) c

theorem groupedAny_step (k n : Nat) (f : (Fin n → Bool) → Bool)
    (x : Fin (k * n + n) → Bool) :
    groupedAny (k + 1) n f (fun i => x (Fin.cast (Nat.succ_mul k n) i)) =
      (groupedAny k n f (leftBits x) || f (rightBits x)) := by
  apply Bool.eq_iff_iff.mpr
  simp only [groupedAny, decide_eq_true_eq, Bool.or_eq_true]
  constructor
  · rintro ⟨c, hc⟩
    by_cases hck : c.val < k
    · exact Or.inl ⟨⟨c.val, hck⟩, hc⟩
    · have he : c = Fin.last k := Fin.ext (by change c.val = k; have := c.isLt; omega)
      subst c
      exact Or.inr hc
  · intro h
    rcases h with ⟨c, hc⟩ | hr
    · exact ⟨c.castSucc, hc⟩
    · exact ⟨Fin.last k, hr⟩

theorem groupedAll_full_degree (k n : Nat) (f : (Fin n → Bool) → Bool)
    (hf : (BPoly.ofFunction n f).topCoefficient = true) :
    (BPoly.ofFunction (k * n) (groupedAll k n f)).topCoefficient = true := by
  induction k with
  | zero =>
    rw [← top_function_cast (Nat.zero_mul n).symm (groupedAll 0 n f)]
    simp only [BPoly.ofFunction, BPoly.topCoefficient, groupedAll, decide_eq_true_eq]
    intro c
    exact Fin.elim0 c
  | succ k ih =>
    rw [← top_function_cast (Nat.succ_mul k n).symm (groupedAll (k + 1) n f)]
    have he := funext (groupedAll_step k n f)
    rw [he]
    exact BPoly.full_degree_and _ _ ih hf

theorem groupedAny_full_degree (k n : Nat) (hk : 0 < k) (hn : 0 < n)
    (f : (Fin n → Bool) → Bool)
    (hf : (BPoly.ofFunction n f).topCoefficient = true) :
    (BPoly.ofFunction (k * n) (groupedAny k n f)).topCoefficient = true := by
  cases k with
  | zero => omega
  | succ k =>
    induction k with
    | zero =>
      rw [← top_function_cast (Nat.one_mul n).symm (groupedAny 1 n f)]
      have he : (fun x => groupedAny 1 n f (fun i => x (Fin.cast (Nat.one_mul n) i))) = f := by
        funext x
        apply Bool.eq_iff_iff.mpr
        simp only [groupedAny, decide_eq_true_eq]
        have hzero : (fun b : Fin n => x (Fin.cast (Nat.one_mul n) (pairIndex (0 : Fin 1) b))) = x := by
          funext b
          congr 1
          apply Fin.ext
          simp [pairIndex]
        constructor
        · rintro ⟨c, hc⟩
          have he : c = 0 := Fin.ext (by have := c.isLt; omega)
          subst c
          rw [hzero] at hc
          exact hc
        · intro h
          exact ⟨0, by rw [hzero]; exact h⟩
      rw [he]
      exact hf
    | succ k ih =>
      rw [← top_function_cast (Nat.succ_mul (k + 1) n).symm (groupedAny (k + 2) n f)]
      have he := funext (groupedAny_step (k + 1) n f)
      rw [he]
      exact BPoly.full_degree_or _ _ (Nat.mul_pos (by omega) hn) hn (ih (by omega)) hf

theorem sparseFunction_grouped (w r : Nat) (x : Fin (freeBits w r) → Bool) :
    sparseFunction w r x = groupedAll (remainingClauses w r) (3 * r)
      (groupedAny 3 r (helperBlock r))
      (fun i => x (Fin.cast (Nat.mul_assoc (remainingClauses w r) 3 r).symm i)) := by
  classical
  apply Bool.eq_iff_iff.mpr
  simp only [sparseFunction, groupedAll, groupedAny, decide_eq_true_eq]
  have hidx (c : Fin (remainingClauses w r)) (s : Fin 3) (b : Fin r) :
      Fin.cast (Nat.mul_assoc (remainingClauses w r) 3 r).symm (pairIndex c (pairIndex s b)) =
      freeBitIndex c s b := by
    apply Fin.ext
    simp only [Fin.val_cast, pairIndex, freeBitIndex, Nat.add_mul, Nat.mul_assoc, Nat.add_assoc]
  simp only [hidx]
  rfl

theorem sparseFunction_full_degree (w r : Nat) (hr0 : 0 < r) :
    (BPoly.ofFunction (freeBits w r) (sparseFunction w r)).topCoefficient = true := by
  have hb : (BPoly.ofFunction r (helperBlock r)).topCoefficient = true := by
    obtain ⟨k, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hr0)
    exact helperBlock_full_degree k
  have hc := groupedAny_full_degree 3 r (by decide) hr0 (helperBlock r) hb
  have ha := groupedAll_full_degree (remainingClauses w r) (3 * r) _ hc
  have he := funext (sparseFunction_grouped w r)
  rw [he, top_function_cast (Nat.mul_assoc (remainingClauses w r) 3 r)]
  exact ha

end SatLowerBound
