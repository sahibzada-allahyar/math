import SatLowerBound.LeafSteps
import SatLowerBound.DegreeCorrespondence

namespace SatLowerBound

/-- The degree-sensitive weighted lower bound for every disjoint read-once
composition of MOD-3 blocks of length at least three. -/
theorem weighted_modular_composition {n : Nat} (T : ModularTree n) (hT : T.Valid 3) : WeightedTree T := by
  suffices main : ∀ l, ∀ U : ModularTree n, U.inputs = l → U.Valid 3 → WeightedTree U from
    main T.inputs T rfl hT
  intro l
  induction l using Nat.strong_induction_on with
  | h l ih =>
    intro U hU hvalid C hc
    obtain ⟨R, _, _, _, hRw, hRe⟩ := OpenCircuit.normalize_by_descent C
    obtain ⟨D, hD, _⟩ := OpenCircuit.exists_minimal R
    have hfun : R.eval = U.eval := funext (fun v => (hRe v).trans (hc v))
    rw [hfun] at hD
    have hweight : D.weight ≤ C.weight := Nat.le_trans hD.1 hRw
    obtain ⟨x, hx, hdel⟩ := U.six_or_seven hvalid D R.weight hD
    obtain ⟨K, S, t, c, hplug, hxs⟩ := U.locate x hx
    subst U
    obtain ⟨hSmin, hK⟩ := K.fits_of_plug (.leaf S t c) hvalid
    change 3 ≤ S.card at hSmin
    have hcomp : ∀ v, D.eval v = (K.plug (.leaf S t c)).eval v := hD.2.1
    have hcharge : DeletionAt D x := hdel
    by_cases hSlong : 4 ≤ S.card
    · have hnext (b : Bool) : WeightedTree (K.plug (.leaf (S.erase x) (lowerResidue t b) c)) := by
        refine ih _ ?_ _ rfl ?_
        · rw [← hU, K.plug_inputs, K.plug_inputs]
          simp only [ModularTree.inputs, Finset.card_erase_of_mem hxs]
          omega
        · apply K.plug_valid S hK
          · change 3 ≤ (S.erase x).card
            rw [Finset.card_erase_of_mem hxs]
            omega
          · exact Finset.erase_subset x S
      have hbound := K.long_leaf_step S hK t c x hxs hSlong D hcomp hcharge hnext
      exact Nat.le_trans hbound (by omega)
    · have hS : S.card = 3 := by omega
      cases hr : K.retire with
      | none =>
        have hk := K.retire_none.mp hr
        subst K
        have hbase := final_three_leaf S t c x hxs hS D hcomp hcharge
        change 6 * S.card ≤ C.weight + 7 * 1 + residueDefect S.card t + 2
        rw [hS]
        omega
      | some R =>
        have hRvalid := K.retire_valid S hK R hr
        obtain ⟨_, hRi, hRb, hRd⟩ := K.retire_stats R hr
        have hRsmall : R.inputs < l := by
          rw [hRi, ← hU, K.plug_inputs]
          simp only [ModularTree.inputs, hS]
          omega
        obtain ⟨E, hE, hdrop⟩ := K.retire_three_leaf S hK R hr t c x hxs hS D hcomp hcharge
        have hbound := ih R.inputs hRsmall R rfl hRvalid E hE
        simp only [K.plug_inputs, K.plug_blocks, K.plug_defects, ModularTree.inputs,
          ModularTree.blocks, ModularTree.defects, hS]
        change 6 * (3 + K.inputs) ≤ C.weight + 7 * (1 + K.blocks) + (residueDefect 3 t + K.defects) + 2
        change 6 * R.inputs ≤ E.weight + 7 * R.blocks + R.defects + 2 at hbound
        rw [hRi, hRb, hRd] at hbound
        omega

/-- TeX weighted theorem with delta defined by actual algebraic deficiency. -/
theorem weighted_modular_composition_algebraic_open {n : Nat} (T : ModularTree n)
    (hT : T.Valid 3) (C : OpenCircuit n) (hc : ∀ v, C.eval v = T.eval v) :
    6 * T.inputs ≤ C.weight + 7 * T.blocks + T.algebraicDefects + 2 := by
  have h := weighted_modular_composition T hT C hc
  simpa only [T.defects_eq_algebraicDefects (hT.mono (by omega))] using h

/-- The same weighted theorem for the original full-B2 circuit model. -/
theorem weighted_modular_composition_algebraic {n : Nat} (T : ModularTree n)
    (hT : T.Valid 3) (C : Circuit n) (hc : C.Computes T.eval) :
    6 * T.inputs ≤ C.weight + 7 * T.blocks + T.algebraicDefects + 2 := by
  have h := weighted_modular_composition T hT (OpenCircuit.ofCircuit C)
    (fun v => (OpenCircuit.ofCircuit_eval C v).trans (hc v))
  simpa only [OpenCircuit.ofCircuit_weight,
    T.defects_eq_algebraicDefects (hT.mono (by omega))] using h

end SatLowerBound
