import SatLowerBound.Counting
import SatLowerBound.Mod3Degree
import SatLowerBound.Encoding
import Mathlib.Data.List.Sort
import Mathlib.Data.List.Nodup

namespace SatLowerBound

/-- An explicit enumeration of the Boolean cube; no finite-search oracle. -/
def cubeList : (n : Nat) → List (Fin n → Bool)
  | 0 => [fun i => Fin.elim0 i]
  | n + 1 => (cubeList n).map (prepend false) ++ (cubeList n).map (prepend true)

theorem prepend_reconstruct {n : Nat} (x : Fin (n + 1) → Bool) :
    prepend (x 0) (fun i => x i.succ) = x := by
  funext i
  exact Fin.cases rfl (fun _ => rfl) i

theorem mem_cubeList (n : Nat) (x : Fin n → Bool) : x ∈ cubeList n := by
  induction n with
  | zero =>
    have hx : x = (fun i => Fin.elim0 i) := by funext i; exact Fin.elim0 i
    simp [cubeList, hx]
  | succ n ih =>
    have ht := ih (fun i => x i.succ)
    have hx := prepend_reconstruct x
    cases hb : x 0
    · apply List.mem_append_left
      apply List.mem_map.mpr
      exact ⟨_, ht, by simpa only [hb] using hx⟩
    · apply List.mem_append_right
      apply List.mem_map.mpr
      exact ⟨_, ht, by simpa only [hb] using hx⟩

theorem cubeList_filter_length (n : Nat) (p : (Fin n → Bool) → Bool) :
    ((cubeList n).filter p).length = cubeCount n p := by
  induction n with
  | zero => simp only [cubeList, cubeCount, List.filter_cons, List.filter_nil]; split <;> rfl
  | succ n ih =>
    simp only [cubeList, List.filter_append, List.length_append, List.filter_map,
      List.length_map, ih, cubeCount, Function.comp_def]

/-- The cube enumeration contains every assignment exactly once. -/
theorem cubeList_nodup (n : Nat) : (cubeList n).Nodup := by
  induction n with
  | zero => simp [cubeList]
  | succ n ih =>
      have hi (b : Bool) : Function.Injective (prepend (n := n) b) := by
        intro x y h
        funext i
        exact congrFun h i.succ
      apply List.nodup_append.mpr
      refine ⟨ih.map (hi false), ih.map (hi true), ?_⟩
      intro x hx y hy he
      obtain ⟨a, _, rfl⟩ := List.mem_map.mp hx
      obtain ⟨b, _, rfl⟩ := List.mem_map.mp hy
      have h := congrFun he 0
      contradiction

/-- PDF Definition 9.3: helpers occur in increasing numeric identifier order. -/
def forbiddenSuffixes (r : Nat) : List (Fin r → Bool) :=
  ((cubeList r).filter (shiftedFunction r 1)).mergeSort
    (fun x y => binaryValue r x ≤ binaryValue r y)

theorem forbiddenSuffixes_length (r : Nat) :
    (forbiddenSuffixes r).length = forbiddenCount r := by
  rw [forbiddenSuffixes, List.length_mergeSort, cubeList_filter_length, ← helper_count_exact]
  rfl

theorem mem_forbiddenSuffixes (r : Nat) (x : Fin r → Bool) :
    x ∈ forbiddenSuffixes r ↔ shiftedFunction r 1 x = true := by
  simp [forbiddenSuffixes, mem_cubeList]

theorem forbiddenSuffixes_nodup (r : Nat) : (forbiddenSuffixes r).Nodup := by
  exact (List.mergeSort_perm _ _).nodup_iff.mpr ((cubeList_nodup r).filter _)

theorem forbiddenSuffixes_sorted (r : Nat) :
    (forbiddenSuffixes r).Pairwise (fun x y => binaryValue r x ≤ binaryValue r y) := by
  simpa only [decide_eq_true_eq, forbiddenSuffixes] using List.pairwise_mergeSort
    (le := fun x y => decide (binaryValue r x ≤ binaryValue r y))
    (fun a b c h₁ h₂ => by simp only [decide_eq_true_eq] at *; omega)
    (fun a b => by simp only [Bool.or_eq_true, decide_eq_true_eq]; omega)
    ((cubeList r).filter (shiftedFunction r 1))

/-- Helper number i carries its explicitly enumerated forbidden suffix. -/
def forbiddenSuffix (r : Nat) (i : Fin (forbiddenCount r)) : Fin r → Bool :=
  (forbiddenSuffixes r).get ⟨i.val, by rw [forbiddenSuffixes_length]; exact i.isLt⟩

theorem forbiddenSuffix_strictMono (r : Nat) :
    StrictMono (fun i : Fin (forbiddenCount r) => binaryValue r (forbiddenSuffix r i)) := by
  intro i j hij
  have hi : i.val < (forbiddenSuffixes r).length := by rw [forbiddenSuffixes_length]; exact i.isLt
  have hj : j.val < (forbiddenSuffixes r).length := by rw [forbiddenSuffixes_length]; exact j.isLt
  have hle := (forbiddenSuffixes_sorted r).rel_getElem_of_lt hi hj hij
  have hne : forbiddenSuffix r i ≠ forbiddenSuffix r j := by
    intro h
    have he := (forbiddenSuffixes_nodup r).get_inj_iff.mp h
    have hv := congrArg Fin.val he
    exact (Nat.ne_of_lt hij) hv
  exact lt_of_le_of_ne hle (fun h => hne (binaryValue_injective r _ _ h))

theorem forbiddenSuffix_spec (r : Nat) (i : Fin (forbiddenCount r)) :
    shiftedFunction r 1 (forbiddenSuffix r i) = true := by
  apply (mem_forbiddenSuffixes r _).mp
  exact List.get_mem _ _

theorem forbiddenSuffix_complete (r : Nat) (x : Fin r → Bool)
    (h : shiftedFunction r 1 x = true) :
    ∃ i, forbiddenSuffix r i = x := by
  have hm := (mem_forbiddenSuffixes r x).mpr h
  obtain ⟨i, hi⟩ := List.mem_iff_get.mp hm
  refine ⟨⟨i.val, by rw [← forbiddenSuffixes_length]; exact i.isLt⟩, ?_⟩
  exact hi

end SatLowerBound
