import SatLowerBound.RestrictionCount
import SatLowerBound.CompositionDegree
import SatLowerBound.FiniteFieldDegree
import SatLowerBound.TexEssential

namespace SatLowerBound

theorem full_degree_nonconstant {n : Nat} (hn : 0 < n) (f : (Fin n → Bool) → Bool)
    (hf : (BPoly.ofFunction n f).topCoefficient = true) : Nonconstant f := by
  classical
  by_contra hc
  have he (x : Fin n → Bool) : f x = f (fun _ => false) := by
    by_contra hx
    exact hc ⟨x, fun _ => false, hx⟩
  have hp : BPoly.ofFunction n f =
      BPoly.select (f (fun _ => false)) (BPoly.one n) := by
    apply BPoly.ext
    intro x
    simp only [BPoly.eval_ofFunction, BPoly.eval_select, BPoly.eval_one, Bool.and_true]
    exact he x
  obtain ⟨k, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hn)
  rw [hp, BPoly.top_select, BPoly.top_one, Bool.and_false] at hf
  contradiction

theorem nonconstant_values {n : Nat} (f : (Fin n → Bool) → Bool) (hf : Nonconstant f) :
    (∃ x, f x = false) ∧ (∃ x, f x = true) := by
  obtain ⟨x, y, h⟩ := hf
  cases hx : f x <;> cases hy : f y
  · exact False.elim (h (hx.trans hy.symm))
  · exact ⟨⟨x, hx⟩, ⟨y, hy⟩⟩
  · exact ⟨⟨y, hy⟩, ⟨x, hx⟩⟩
  · exact False.elim (h (hx.trans hy.symm))

theorem remainingClauses_pos (w r : Nat) (hr : r < w) (hr0 : 0 < r) :
    0 < remainingClauses w r := by
  have hc := helper_count_le r
  have hp : 2 ^ (r + 1) ≤ 2 ^ w := Nat.pow_le_pow_right (by decide) hr
  have hp0 : 1 < 2 ^ r := Nat.one_lt_two_pow (Nat.ne_of_gt hr0)
  rw [Nat.pow_succ] at hp
  unfold remainingClauses variableCount
  omega

def flattenSuffixes (w r : Nat) (hr0 : 0 < r) (x : SuffixAssignment w r) :
    Fin (freeBits w r) → Bool := fun i =>
  let a := unpairIndex hr0 i
  let cs := unpairIndex (by decide : 0 < 3) a.1
  x cs.1 cs.2 a.2

theorem suffixAssignment_flatten (w r : Nat) (hr0 : 0 < r) (x : SuffixAssignment w r) :
    suffixAssignmentOf (flattenSuffixes w r hr0 x) = x := by
  funext c s b
  simp only [suffixAssignmentOf, flattenSuffixes, freeBitIndex, unpair_pair]

theorem sparseFunction_nonconstant (w r : Nat) (hr : r < w) (hr0 : 0 < r) :
    Nonconstant (sparseFunction w r) := by
  have hblock : Nonconstant (helperBlock r) := by
    apply full_degree_nonconstant hr0
    obtain ⟨k, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hr0)
    exact helperBlock_full_degree k
  obtain ⟨⟨u, hu⟩, ⟨v, hv⟩⟩ := nonconstant_values _ hblock
  let x := flattenSuffixes w r hr0 (fun _ _ => u)
  let y := flattenSuffixes w r hr0 (fun _ _ => v)
  have hx : sparseFunction w r x = false := by
    classical
    simp only [sparseFunction, x, suffixAssignment_flatten, hu, Bool.false_eq_true,
      exists_false, decide_eq_false_iff_not]
    intro h
    exact h ⟨0, remainingClauses_pos w r hr hr0⟩
  have hy : sparseFunction w r y = true := by
    classical
    simp only [sparseFunction, y, suffixAssignment_flatten, hv, decide_eq_true_eq]
    intro j
    exact ⟨0, True.intro⟩
  exact ⟨x, y, by rw [hx, hy]; decide⟩

/-- An actual shared residual circuit, with exactly n-L paid deletions.
All hypotheses concern the original SAT circuit and the numerical parameters. -/
theorem sat_sparse_transfer (w r : Nat) (hw : 2 ≤ w) (hr : r < w) (hr0 : 0 < r)
    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    ∃ D : OpenCircuit (freeBits w r),
      (∀ x, D.eval x = sparseFunction w r x) ∧
      D.size + (inputBits w - freeBits w r) ≤ C.size := by
  obtain ⟨N, hl, hg, hs, hweight, heval⟩ := OpenCircuit.normalize_basic C
  let D := N.restrict (sparseRestriction w r)
  have he (x : Fin (freeBits w r) → Bool) : D.eval x = sparseFunction w r x := by
    rw [OpenCircuit.restrict_eval, heval, hc, sparseRestriction_sat w r hr x]
  have hN : N.eval = satFunction w := by
    funext x
    exact (heval x).trans (hc x)
  have hnc : Nonconstant D.eval := by
    have heq : D.eval = sparseFunction w r := funext he
    rw [heq]
    exact sparseFunction_nonconstant w r hr hr0
  have hdel := N.restriction_transfer (fixedMask w r) (sparseRestriction w r)
    (sparseRestriction_marks w r) hl
    (by rw [hN]; exact tex_every_encoding_bit_essential w hw) hnc
  rw [fixed_coordinate_count w r hr hr0] at hdel
  exact ⟨D, he, Nat.le_trans hdel hs⟩

end SatLowerBound
