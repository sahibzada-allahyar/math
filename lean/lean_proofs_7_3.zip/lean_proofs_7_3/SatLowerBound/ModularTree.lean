import SatLowerBound.DisjointFunctions

namespace SatLowerBound

/-- A read-once AND/OR composition of MOD-3 blocks in one fixed ambient cube.
The `Valid` predicate certifies disjoint supports and the minimum leaf size. -/
inductive ModularTree (n : Nat) where
  | leaf (support : Finset (Fin n)) (residue : Fin 3) (complemented : Bool)
  | branch (isOr : Bool) (left right : ModularTree n)

namespace ModularTree

def eval {n : Nat} : ModularTree n → (Fin n → Bool) → Bool
  | .leaf S t c, v => modularBlock S t c v
  | .branch p a b, v => combine p (a.eval v) (b.eval v)

def support {n : Nat} : ModularTree n → Finset (Fin n)
  | .leaf S _ _ => S
  | .branch _ a b => a.support ∪ b.support

def inputs {n : Nat} : ModularTree n → Nat
  | .leaf S _ _ => S.card
  | .branch _ a b => a.inputs + b.inputs

def blocks {n : Nat} : ModularTree n → Nat
  | .leaf _ _ _ => 1
  | .branch _ a b => a.blocks + b.blocks

def defects {n : Nat} : ModularTree n → Nat
  | .leaf S t _ => indicator (decide ((S.card + t.val) % 3 = 0))
  | .branch _ a b => a.defects + b.defects

def Valid {n : Nat} (k : Nat) : ModularTree n → Prop
  | .leaf S _ _ => k ≤ S.card
  | .branch _ a b => a.Valid k ∧ b.Valid k ∧ Disjoint a.support b.support

theorem Valid.mono {n k l : Nat} {T : ModularTree n} (h : T.Valid k) (hl : l ≤ k) : T.Valid l := by
  induction T with
  | leaf S t c => exact Nat.le_trans hl h
  | branch p a b iha ihb => exact ⟨iha h.1, ihb h.2.1, h.2.2⟩

theorem supported {n : Nat} (T : ModularTree n) : Supported T.eval T.support := by
  induction T with
  | leaf S t c => exact modularBlock_supported S t c
  | branch p a b iha ihb => exact supported_combine p a.eval b.eval a.support b.support iha ihb

theorem nonconstant {n : Nat} (T : ModularTree n) (h : T.Valid 2) : Nonconstant T.eval := by
  induction T with
  | leaf S t c => exact modularBlock_nonconstant S t c h
  | branch p a b iha ihb =>
    exact combine_nonconstant p a.eval b.eval a.support b.support a.supported b.supported
      h.2.2 (iha h.1) (ihb h.2.1)

theorem essential {n : Nat} (T : ModularTree n) (h : T.Valid 2) (x : Fin n)
    (hx : x ∈ T.support) : Essential T.eval x := by
  induction T with
  | leaf S t c => exact modularBlock_essential S t c h x hx
  | branch p a b iha ihb =>
    rcases Finset.mem_union.mp hx with ha | hb
    · exact combine_essential_left p a.eval b.eval a.support b.support a.supported b.supported
        h.2.2 (b.nonconstant h.2.1) x (iha h.1 ha)
    · exact combine_essential_right p a.eval b.eval a.support b.support a.supported b.supported
        h.2.2 (a.nonconstant h.1) x (ihb h.2.1 hb)

theorem essential_iff {n : Nat} (T : ModularTree n) (h : T.Valid 2) (x : Fin n) :
    Essential T.eval x ↔ x ∈ T.support :=
  ⟨T.supported.essential_mem x, T.essential h x⟩

theorem inputs_eq_card {n : Nat} (T : ModularTree n) (h : T.Valid 0) : T.inputs = T.support.card := by
  induction T with
  | leaf S t c => rfl
  | branch p a b iha ihb =>
    simp only [inputs, support, Finset.card_union_of_disjoint h.2.2, iha h.1, ihb h.2.1]

theorem blocks_positive {n : Nat} (T : ModularTree n) : 0 < T.blocks := by
  induction T with
  | leaf S t c => exact Nat.zero_lt_succ 0
  | branch p a b iha ihb => simp only [blocks]; omega

def restrict {n : Nat} (T : ModularTree n) (x : Fin n) (b : Bool) : ModularTree n :=
  match T with
  | .leaf S t c => .leaf (S.erase x) (if x ∈ S then lowerResidue t b else t) c
  | .branch p L R => .branch p (L.restrict x b) (R.restrict x b)

theorem restrict_eval {n : Nat} (T : ModularTree n) (x : Fin n) (b : Bool) (v : Fin n → Bool) :
    (T.restrict x b).eval v = T.eval (fixBit x b v) := by
  induction T with
  | leaf S t c =>
    by_cases hx : x ∈ S
    · simpa only [restrict, eval, hx, ↓reduceIte] using (modularBlock_cofactor S t c x hx b v).symm
    · simp only [restrict, eval, hx, ↓reduceIte, Finset.erase_eq_of_notMem hx]
      exact ((modularBlock_supported S t c).fixBit_outside x hx b v).symm
  | branch p a d iha ihd => simp only [restrict, eval, iha, ihd]

theorem restrict_support {n : Nat} (T : ModularTree n) (x : Fin n) (b : Bool) :
    (T.restrict x b).support = T.support.erase x := by
  induction T with
  | leaf S t c => rfl
  | branch p a d iha ihd =>
    simp only [restrict, support, iha, ihd]
    ext i
    simp only [Finset.mem_union, Finset.mem_erase]
    tauto

theorem restrict_valid {n k : Nat} (T : ModularTree n) (x : Fin n) (b : Bool) (h : T.Valid (k + 1)) :
    (T.restrict x b).Valid k := by
  induction T with
  | leaf S t c =>
    change k ≤ (S.erase x).card
    by_cases hx : x ∈ S
    · rw [Finset.card_erase_of_mem hx]
      change k + 1 ≤ S.card at h
      omega
    · rw [Finset.erase_eq_of_notMem hx]
      exact Nat.le_trans (Nat.le_succ k) h
  | branch p a d iha ihd =>
    refine ⟨iha h.1, ihd h.2.1, ?_⟩
    rw [restrict_support, restrict_support]
    apply Finset.disjoint_left.mpr
    intro i hi hj
    exact Finset.disjoint_left.mp h.2.2 (Finset.mem_erase.mp hi).2 (Finset.mem_erase.mp hj).2

theorem cofactor_nonconstant {n : Nat} (T : ModularTree n) (h : T.Valid 3) (x : Fin n) (b : Bool) :
    Nonconstant (fun v => T.eval (fixBit x b v)) := by
  have hn := (T.restrict x b).nonconstant (T.restrict_valid x b h)
  simpa only [Nonconstant, restrict_eval] using hn

theorem restrict_blocks {n : Nat} (T : ModularTree n) (x : Fin n) (b : Bool) :
    (T.restrict x b).blocks = T.blocks := by
  induction T with
  | leaf S t c => rfl
  | branch p a d iha ihd => simp only [restrict, blocks, iha, ihd]

end ModularTree
end SatLowerBound
