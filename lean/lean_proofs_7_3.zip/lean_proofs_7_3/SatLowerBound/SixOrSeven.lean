import SatLowerBound.DirectSuccessors
import SatLowerBound.FirstGate

namespace SatLowerBound

def fixBit {n : Nat} (x : Fin n) (b : Bool) (v : Fin n → Bool) : Fin n → Bool :=
  fun i => if i = x then b else v i

def singlePartial {n : Nat} (x : Fin n) (b : Bool) : PartialState n :=
  fun i => if i = x then some b else none

def singleSubst {n : Nat} (x : Fin n) (b : Bool) : Fin n → Signal n :=
  fun i => if i = x then .constant b else .wire i false

theorem singlePartial_singleton {n : Nat} (x : Fin n) (b : Bool) :
    (singlePartial x b).Singleton x := by
  intro i hi
  by_contra h
  simp [singlePartial, PartialState.mask, h] at hi

namespace OpenCircuit

theorem singlePartial_matches {n : Nat} (x : Fin n) (b : Bool) :
    PartialMatches (singlePartial x b) (singleSubst x b) := by
  intro i v hi
  by_cases h : i = x
  · subst i
    simp only [singlePartial, ↓reduceIte, Option.some.injEq] at hi
    simp [singleSubst, hi]
  · simp [singlePartial, h] at hi

theorem singlePartial_uses {n : Nat} (C : OpenCircuit n) (x : Fin n) (b : Bool) :
    C.markedUses (singlePartial x b).mask = C.usage (singleUse x) := by
  unfold markedUses
  congr 1
  funext i
  by_cases hi : i = x <;> simp [PartialState.mask, singlePartial, singleUse, hi, indicator]

theorem restrict_single_eval {n : Nat} (C : OpenCircuit n) (x : Fin n) (b : Bool)
    (v : Fin n → Bool) : (C.restrict (singleSubst x b)).eval v = C.eval (fixBit x b v) := by
  rw [restrict_eval]
  congr 1
  funext i
  by_cases hi : i = x <;> simp [singleSubst, fixBit, hi, Signal.eval]

theorem single_deletion_data {n : Nat} (C : OpenCircuit n) (x : Fin n) (b : Bool)
    (hr : C.Reduced) (ht : C.NoInputTriangles (fun _ => none))
    (hn : Nonconstant (fun v => C.eval (fixBit x b v))) :
    (C.restrict (singleSubst x b)).weight + 2 * C.usage (singleUse x) +
        2 * C.propagationBirths (singlePartial x b) + C.directParity x ≤ C.weight ∧
      (C.directBlocked x b ≤ C.propagationBirths (singlePartial x b) ∨
        2 ≤ C.propagationBirths (singlePartial x b)) ∧ C.directOutput x = 0 := by
  have hnon : Nonconstant (C.restrict (singleSubst x b)).eval := by
    simpa only [Nonconstant, restrict_single_eval] using hn
  have hm := singlePartial_matches x b
  have hx : singlePartial x b x = some b := by simp [singlePartial]
  have ho := C.propagatedOutput_false (singlePartial x b) (singleSubst x b) hm hnon
  have hw := C.propagation_weight_gain (singlePartial x b) (singleSubst x b) hm
    (C.reduced_live hr) (C.reduced_essential hr) ho
  rw [singlePartial_uses] at hw
  have hp := C.directParity_le (singlePartial x b) x b hx
  have hc := C.directBlocked_le (singlePartial x b) x b hx
  have hb := C.singleton_births_bound (singlePartial x b) (fun _ => none) x hr ht
    (singlePartial_singleton x b) rfl
  refine ⟨by omega, ?_, C.directOutput_zero (singlePartial x b) x b hx ho⟩
  rcases hb with hb | hb
  · exact Or.inl (Nat.le_trans hc hb)
  · exact Or.inr hb

/-- The quantitative dichotomy for any multiple-use primary input of a fully
normalized circuit whose two cofactors remain nonconstant. -/
theorem six_or_seven_at {n : Nat} (C : OpenCircuit n) (x : Fin n)
    (hr : C.Reduced) (ht : C.NoInputTriangles (fun _ => none))
    (hu : 2 ≤ C.usage (singleUse x))
    (hn : ∀ b, Nonconstant (fun v => C.eval (fixBit x b v))) :
    (∀ b, (C.restrict (singleSubst x b)).weight + 6 ≤ C.weight) ∨
      (∃ b, (C.restrict (singleSubst x b)).weight + 7 ≤ C.weight) := by
  obtain ⟨hw0, hb0, ho⟩ := C.single_deletion_data x false hr ht (hn false)
  obtain ⟨hw1, hb1, _⟩ := C.single_deletion_data x true hr ht (hn true)
  have hp := C.direct_partition x hr
  rw [ho] at hp
  by_cases h0 : (C.restrict (singleSubst x false)).weight + 6 ≤ C.weight
  · by_cases h1 : (C.restrict (singleSubst x true)).weight + 6 ≤ C.weight
    · left
      intro b
      cases b
      · exact h0
      · exact h1
    · right
      refine ⟨false, ?_⟩
      rcases hb0 with hb0 | hb0 <;> rcases hb1 with hb1 | hb1 <;> omega
  · right
    refine ⟨true, ?_⟩
    rcases hb0 with hb0 | hb0 <;> rcases hb1 with hb1 | hb1 <;> omega

theorem output_not_pairSeparated {n : Nat} (s : Signal n) (i j : Fin n) (hij : i ≠ j) :
    ¬ PairSeparated (OpenCircuit.output s).eval i j := by
  intro hs
  apply no_single_signal _ hs
  cases s with
  | constant c => exact ⟨fun _ _ => false, fun _ _ => c, fun _ _ _ => rfl⟩
  | wire k c =>
    by_cases hki : k = i
    · subst k
      refine ⟨fun a _ => a, fun a _ => Bool.xor a c, ?_⟩
      intro a b v
      simp [eval, Signal.eval, setPair]
    · by_cases hkj : k = j
      · subst k
        refine ⟨fun _ b => b, fun b _ => Bool.xor b c, ?_⟩
        intro a b v
        simp [eval, Signal.eval, setPair, Ne.symm hij]
      · refine ⟨fun _ _ => false, fun _ v => Bool.xor (v k) c, ?_⟩
        intro a b v
        simp [eval, Signal.eval, setPair, hki, hkj]

/-- The first gate and three-cofactor separation supply a multiple-use input. -/
theorem separated_multiple_use {n : Nat} (C : OpenCircuit n) (hn : 2 ≤ n)
    (hr : C.Reduced) (hs : ∀ i j, i ≠ j → PairSeparated C.eval i j) :
    ∃ x, 2 ≤ C.usage (singleUse x) := by
  cases C with
  | output s =>
    let i : Fin n := ⟨0, by omega⟩
    let j : Fin n := ⟨1, by omega⟩
    have hij : i ≠ j := by intro he; have hv := congrArg Fin.val he; contradiction
    exact False.elim (output_not_pairSeparated s i j hij (hs i j hij))
  | gate g i j rest =>
    rcases first_gate_multiple_use g i j rest hr.2.1 (hs i j hr.2.1) with hi | hj
    · exact ⟨i, hi⟩
    · exact ⟨j, hj⟩

theorem six_or_seven {n : Nat} (C : OpenCircuit n) (hn : 2 ≤ n)
    (hr : C.Reduced) (ht : C.NoInputTriangles (fun _ => none))
    (hs : ∀ i j, i ≠ j → PairSeparated C.eval i j)
    (hc : ∀ x b, Nonconstant (fun v => C.eval (fixBit x b v))) :
    ∃ x, (∀ b, (C.restrict (singleSubst x b)).weight + 6 ≤ C.weight) ∨
      (∃ b, (C.restrict (singleSubst x b)).weight + 7 ≤ C.weight) := by
  obtain ⟨x, hu⟩ := C.separated_multiple_use hn hr hs
  exact ⟨x, C.six_or_seven_at x hr ht hu (hc x)⟩

end OpenCircuit
end SatLowerBound
