import SatLowerBound.Formula
import SatLowerBound.HelperEnumeration
import SatLowerBound.EncodingEssential

namespace SatLowerBound

/-- Low r suffix bits, fixed zero middle bits, and fixed leading one. -/
def suffixIdentifierBits (w r : Nat) (x : Fin r → Bool) : Fin w → Bool :=
  fun j => if h : j.val < r then x ⟨j.val, h⟩ else decide (j.val + 1 = w)

theorem suffixIdentifier_pos (w r : Nat) (hr : r < w) (x : Fin r → Bool) :
    0 < binaryValue w (suffixIdentifierBits w r x) := by
  apply binaryValue_pos_of_bit w _ ⟨w - 1, by omega⟩
  have h : ¬ w - 1 < r := by omega
  simp [suffixIdentifierBits, h, Nat.sub_add_cancel (by omega : 1 ≤ w)]

def suffixVariable (w r : Nat) (hr : r < w) (x : Fin r → Bool) : Fin (variableCount w) :=
  ⟨binaryValue w (suffixIdentifierBits w r x) - 1, by
    have hp := suffixIdentifier_pos w r hr x
    have hu := binaryValue_lt w (suffixIdentifierBits w r x)
    unfold variableCount
    omega⟩

theorem suffixVariable_injective (w r : Nat) (hr : r < w)
    (x y : Fin r → Bool) (h : suffixVariable w r hr x = suffixVariable w r hr y) : x = y := by
  have hv := congrArg Fin.val h
  have hx := suffixIdentifier_pos w r hr x
  have hy := suffixIdentifier_pos w r hr y
  change binaryValue w (suffixIdentifierBits w r x) - 1 =
    binaryValue w (suffixIdentifierBits w r y) - 1 at hv
  have hid : binaryValue w (suffixIdentifierBits w r x) =
      binaryValue w (suffixIdentifierBits w r y) := by omega
  have he := binaryValue_injective w _ _ hid
  funext j
  have hjw : j.val < w := Nat.lt_trans j.isLt hr
  have hj := congrFun he ⟨j.val, hjw⟩
  simpa only [suffixIdentifierBits, j.isLt, ↓reduceDIte] using hj

theorem helper_count_fits (w r : Nat) (hr : r < w) : forbiddenCount r ≤ variableCount w := by
  have hc := helper_count_le r
  have hp : 2 ^ (r + 1) ≤ 2 ^ w := Nat.pow_le_pow_right (by decide) hr
  rw [Nat.pow_succ] at hp
  have hpos := Nat.two_pow_pos r
  unfold variableCount
  omega

abbrev SuffixAssignment (w r : Nat) :=
  Fin (variableCount w - forbiddenCount r) → Fin 3 → Fin r → Bool

/-- Exactly m clause records and m variable positions. The first Z_r records
are negative units; the remaining M_r records each have three free suffixes. -/
def sparseFormula (w r : Nat) (hr : r < w) (x : SuffixAssignment w r) :
    Formula (variableCount w) := fun c s =>
  if h : c.val < forbiddenCount r then
    ⟨suffixVariable w r hr (forbiddenSuffix r ⟨c.val, h⟩), true⟩
  else
    ⟨suffixVariable w r hr (x ⟨c.val - forbiddenCount r, by have := c.isLt; omega⟩ s), false⟩

def helperClause (w r : Nat) (hr : r < w) (i : Fin (forbiddenCount r)) :
    Fin (variableCount w) := ⟨i.val, Nat.lt_of_lt_of_le i.isLt (helper_count_fits w r hr)⟩

def freeClause (w r : Nat) (j : Fin (variableCount w - forbiddenCount r)) :
    Fin (variableCount w) := ⟨forbiddenCount r + j.val, by have := j.isLt; omega⟩

theorem sparseFormula_helper (w r : Nat) (hr : r < w) (x : SuffixAssignment w r)
    (i : Fin (forbiddenCount r)) (s : Fin 3) :
    sparseFormula w r hr x (helperClause w r hr i) s =
      ⟨suffixVariable w r hr (forbiddenSuffix r i), true⟩ := by
  simp only [sparseFormula, helperClause, i.isLt, ↓reduceDIte]

theorem sparseFormula_free (w r : Nat) (hr : r < w) (x : SuffixAssignment w r)
    (j : Fin (variableCount w - forbiddenCount r)) (s : Fin 3) :
    sparseFormula w r hr x (freeClause w r j) s = ⟨suffixVariable w r hr (x j s), false⟩ := by
  have h : ¬ forbiddenCount r + j.val < forbiddenCount r := by omega
  simp only [sparseFormula, freeClause, h, ↓reduceDIte, Nat.add_sub_cancel_left]

/-- The concrete sparse formula is satisfiable exactly when every free clause
has a suffix outside the MOD-3 helper set. -/
theorem sparseFormula_sat_iff (w r : Nat) (hr : r < w) (x : SuffixAssignment w r) :
    (sparseFormula w r hr x).SAT ↔ ∀ j, ∃ s, helperBlock r (x j s) = true := by
  classical
  constructor
  · rintro ⟨a, ha⟩
    have forced (i : Fin (forbiddenCount r)) :
        a (suffixVariable w r hr (forbiddenSuffix r i)) = false := by
      obtain ⟨s, hs⟩ := ha (helperClause w r hr i)
      rw [sparseFormula_helper] at hs
      simpa [Literal.eval] using hs
    intro j
    obtain ⟨s, hs⟩ := ha (freeClause w r j)
    rw [sparseFormula_free] at hs
    change a (suffixVariable w r hr (x j s)) = true at hs
    refine ⟨s, ?_⟩
    cases hb : shiftedFunction r 1 (x j s)
    · simp only [helperBlock, hb, Bool.not_false]
    · obtain ⟨i, hi⟩ := forbiddenSuffix_complete r _ hb
      have hf := forced i
      rw [hi, hs] at hf
      contradiction
  · intro hx
    let a : Fin (variableCount w) → Bool := fun v =>
      decide (∀ i : Fin (forbiddenCount r), v ≠ suffixVariable w r hr (forbiddenSuffix r i))
    refine ⟨a, ?_⟩
    intro c
    by_cases hc : c.val < forbiddenCount r
    · refine ⟨0, ?_⟩
      simp only [sparseFormula, hc, ↓reduceDIte, Literal.eval, ↓reduceIte]
      have hf : a (suffixVariable w r hr (forbiddenSuffix r ⟨c.val, hc⟩)) = false := by
        simp only [a, decide_eq_false_iff_not]
        intro hh
        exact hh ⟨c.val, hc⟩ rfl
      rw [hf]
      rfl
    · let j : Fin (variableCount w - forbiddenCount r) :=
        ⟨c.val - forbiddenCount r, by have := c.isLt; omega⟩
      obtain ⟨s, hs⟩ := hx j
      refine ⟨s, ?_⟩
      simp only [sparseFormula, hc, ↓reduceDIte, Literal.eval, Bool.false_eq_true, ↓reduceIte]
      change a (suffixVariable w r hr (x j s)) = true
      apply decide_eq_true_iff.mpr
      intro i he
      have hi := suffixVariable_injective w r hr _ _ he
      have hf := forbiddenSuffix_spec r i
      rw [← hi] at hf
      simp only [helperBlock, hf, Bool.not_true] at hs
      contradiction

theorem encoded_sparse_sat_iff (w r : Nat) (hr : r < w) (x : SuffixAssignment w r) :
    satFunction w (encodeFormula w (sparseFormula w r hr x)) = true ↔
      ∀ j, ∃ s, helperBlock r (x j s) = true := by
  rw [encodeFormula_correct, sparseFormula_sat_iff]

end SatLowerBound
