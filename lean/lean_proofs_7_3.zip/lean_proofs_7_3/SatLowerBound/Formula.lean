import SatLowerBound.Encoding

namespace SatLowerBound

structure Literal (m : Nat) where
  varIndex : Fin m
  negated : Bool

/-- A conventional 3-CNF with m clauses over exactly m variable positions. -/
abbrev Formula (m : Nat) := Fin m → Fin 3 → Literal m

def Literal.eval {m : Nat} (l : Literal m) (a : Fin m → Bool) : Bool :=
  if l.negated then !(a l.varIndex) else a l.varIndex

def Formula.Satisfies {m : Nat} (f : Formula m) (a : Fin m → Bool) : Prop :=
  ∀ c, ∃ s, (f c s).eval a = true

def Formula.SAT {m : Nat} (f : Formula m) : Prop := ∃ a, f.Satisfies a

/-- Encode the conventional formula into exactly 3*m*(w+1) input bits. -/
def encodeFormula (w : Nat) (f : Formula (variableCount w)) : Input w :=
  encodeBits w fun c s b =>
    if h : b.val < w then binaryDigits w ((f c s).varIndex.val + 1) ⟨b.val, h⟩
    else (f c s).negated

theorem encodeFormula_identifier (w : Nat) (f : Formula (variableCount w))
    (c : Fin (clauseCount w)) (s : Fin 3) :
    identifier w (encodeFormula w f) c s = (f c s).varIndex.val + 1 := by
  unfold identifier encodeFormula
  simp only [encode_coordinate, Fin.val_castSucc, Fin.isLt, ↓reduceDIte]
  apply binaryValue_digits
  have h := (f c s).varIndex.isLt
  unfold variableCount at h
  omega

theorem encodeFormula_negative (w : Nat) (f : Formula (variableCount w))
    (c : Fin (clauseCount w)) (s : Fin 3) :
    negative w (encodeFormula w f) c s = (f c s).negated := by
  simp [negative, encodeFormula]

theorem encodeFormula_valid (w : Nat) (f : Formula (variableCount w)) :
    Valid w (encodeFormula w f) := by
  intro c s
  rw [encodeFormula_identifier]
  exact Nat.zero_lt_succ _

theorem encodeFormula_literal (w : Nat) (f : Formula (variableCount w))
    (a : Assignment w) (c : Fin (clauseCount w)) (s : Fin 3) :
    literalValue w (encodeFormula w f) a c s = (f c s).eval a := by
  have hi := (f c s).varIndex.isLt
  simp only [literalValue, encodeFormula_identifier, Nat.zero_lt_succ, true_and]
  simp only [Nat.succ_le_iff.mpr hi, ↓reduceDIte, Nat.add_sub_cancel,
    encodeFormula_negative, Literal.eval]

/-- Exact semantic agreement with ordinary 3-CNF satisfiability. -/
theorem encodeFormula_correct (w : Nat) (f : Formula (variableCount w)) :
    satFunction w (encodeFormula w f) = true ↔ f.SAT := by
  rw [satFunction_eq_true_iff]
  change Valid w (encodeFormula w f) ∧
      (∃ a, ∀ c, ∃ s, literalValue w (encodeFormula w f) a c s = true) ↔ f.SAT
  simp only [encodeFormula_valid, true_and, encodeFormula_literal]
  rfl

/-- The semantic part of the sparse-helper embedding. Helpers force exactly
the designated variables false; the remaining clauses contain only positives. -/
theorem sparse_helpers_sat_iff {m : Nat} (f : Formula m)
    (helper : Fin m → Bool) (forbidden : Fin m → Bool)
    (hhelper : ∀ c, helper c = true →
      ∀ s, (f c s).negated = true ∧ forbidden (f c s).varIndex = true)
    (hforce : ∀ v, forbidden v = true →
      ∃ c, helper c = true ∧ ∀ s, (f c s).varIndex = v)
    (hpositive : ∀ c, helper c = false → ∀ s, (f c s).negated = false) :
    f.SAT ↔ ∀ c, helper c = false → ∃ s, forbidden (f c s).varIndex = false := by
  constructor
  · rintro ⟨a, ha⟩
    have forced (v : Fin m) (hv : forbidden v = true) : a v = false := by
      rcases hforce v hv with ⟨c, hc, hall⟩
      rcases ha c with ⟨s, hs⟩
      have hn := (hhelper c hc s).1
      simp only [Literal.eval, hn, ↓reduceIte, hall s] at hs
      cases hv : a v <;> simp_all
    intro c hc
    rcases ha c with ⟨s, hs⟩
    refine ⟨s, ?_⟩
    have hn := hpositive c hc s
    simp only [Literal.eval, hn, Bool.false_eq_true, ↓reduceIte] at hs
    cases hf : forbidden (f c s).varIndex
    · rfl
    · have hh := forced (f c s).varIndex hf; rw [hh] at hs; contradiction
  · intro h
    refine ⟨fun v => !(forbidden v), ?_⟩
    intro c
    cases hc : helper c
    · rcases h c hc with ⟨s, hs⟩
      refine ⟨s, ?_⟩
      simp [Literal.eval, hpositive c hc s, hs]
    · refine ⟨0, ?_⟩
      rcases hhelper c hc 0 with ⟨hn, hv⟩
      simp [Literal.eval, hn, hv]

end SatLowerBound
