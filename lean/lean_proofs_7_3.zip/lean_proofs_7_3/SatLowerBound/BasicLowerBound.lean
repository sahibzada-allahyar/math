import SatLowerBound.EncodingEssential

namespace SatLowerBound
namespace OpenCircuit

theorem usage_ones_le {n : Nat} (C : OpenCircuit n) (hl : C.Live) :
    C.usage (fun _ => 1) ≤ C.size + 1 := by
  induction C with
  | output s => cases s <;> simp [usage, size]
  | @gate n g i j rest ih =>
    have hr := ih hl.2
    have he : (fun _ : Fin (n + 1) => 1) =
        (fun k => appendValue (fun _ => 1) 0 k + appendValue (fun _ => 0) 1 k) := by
      funext k
      simp only [appendValue]
      split <;> rfl
    rw [he, usage_add] at hr
    change rest.usage (appendValue (fun _ => 1) 0) + rest.lastUses ≤ rest.size + 1 at hr
    have hp := hl.1
    simp only [usage, size]
    omega

theorem essential_inputs_bound {n : Nat} (C : OpenCircuit n) (hl : C.Live)
    (he : ∀ i, Essential C.eval i) : n ≤ C.size + 1 := by
  have hm := markedCount_le_uses C (fun _ => true) he
  simp [indicator, markedUses] at hm
  exact Nat.le_trans hm (usage_ones_le C hl)

end OpenCircuit

/-- The unrestricted circuit model has no hidden essentiality assumption:
the exact SAT function supplies witnesses for every one of its n inputs. -/
theorem sat_linear_lower_bound (w : Nat) (hw : 2 ≤ w) (C : Circuit (inputBits w))
    (hc : C.Computes (satFunction w)) : inputBits w ≤ C.size + 1 := by
  obtain ⟨D, hD, hess, hsize, hweight, heval⟩ := OpenCircuit.normalize_basic C
  have hf : D.eval = satFunction w := by
    funext x
    exact (heval x).trans (hc x)
  have h := D.essential_inputs_bound hD (by rw [hf]; exact every_encoding_bit_essential w hw)
  omega

end SatLowerBound
