import SatLowerBound.Circuit

/-! Canonical multilinear polynomials over F₂ in recursive coefficient form.
`node p q` means p + X_last*q. Thus no variable has exponent greater than one.
All polynomial operations below are proved correct on Boolean assignments. -/
namespace SatLowerBound

inductive BPoly : Nat → Type where
  | constant (b : Bool) : BPoly 0
  | node {n : Nat} (lo hi : BPoly n) : BPoly (n + 1)

namespace BPoly

def zero : (n : Nat) → BPoly n
  | 0 => .constant false
  | n + 1 => .node (zero n) (zero n)

def one : (n : Nat) → BPoly n
  | 0 => .constant true
  | n + 1 => .node (one n) (zero n)

def eval : {n : Nat} → BPoly n → (Fin n → Bool) → Bool
  | 0, .constant b, _ => b
  | n + 1, .node p q, x =>
      Bool.xor (p.eval (fun i => x i.castSucc))
        (x (Fin.last n) && q.eval (fun i => x i.castSucc))

theorem eval_node_extend {n : Nat} (p q : BPoly n) (x : Fin n → Bool) (b : Bool) :
    (BPoly.node p q).eval (extend x b) = Bool.xor (p.eval x) (b && q.eval x) := by
  simp only [eval, extend_old, extend_last]

@[simp] theorem eval_zero (n : Nat) (x : Fin n → Bool) : (zero n).eval x = false := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [zero, eval, ih, Bool.and_false, Bool.xor_false]

@[simp] theorem eval_one (n : Nat) (x : Fin n → Bool) : (one n).eval x = true := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [one, eval, ih, eval_zero, Bool.and_false, Bool.xor_false]

def add : {n : Nat} → BPoly n → BPoly n → BPoly n
  | 0, .constant a, .constant b => .constant (Bool.xor a b)
  | _ + 1, .node a b, .node c d => .node (add a c) (add b d)

private theorem bool_add_node (a b c d x : Bool) :
    Bool.xor (Bool.xor a c) (x && Bool.xor b d) =
      Bool.xor (Bool.xor a (x && b)) (Bool.xor c (x && d)) := by
  revert a b c d x
  decide

theorem eval_add {n : Nat} (p q : BPoly n) (x : Fin n → Bool) :
    (p.add q).eval x = Bool.xor (p.eval x) (q.eval x) := by
  induction p with
  | constant a => cases q; rfl
  | node a b iha ihb =>
    cases q with
    | node c d =>
      simp only [add, eval, iha, ihb]
      exact bool_add_node _ _ _ _ _

def mul : {n : Nat} → BPoly n → BPoly n → BPoly n
  | 0, .constant a, .constant b => .constant (a && b)
  | _ + 1, .node a b, .node c d =>
      .node (mul a c) (add (add (mul a d) (mul b c)) (mul b d))

private theorem bool_mul_node (a b c d x : Bool) :
    Bool.xor (a && c) (x && Bool.xor (Bool.xor (a && d) (b && c)) (b && d)) =
      (Bool.xor a (x && b) && Bool.xor c (x && d)) := by
  revert a b c d x
  decide

theorem eval_mul {n : Nat} (p q : BPoly n) (x : Fin n → Bool) :
    (p.mul q).eval x = (p.eval x && q.eval x) := by
  induction p with
  | constant a => cases q; rfl
  | node a b iha ihb =>
    cases q with
    | node c d =>
      simp only [mul, eval, eval_add, iha, ihb]
      exact bool_mul_node _ _ _ _ _

/-- Semantic equality implies equality of the canonical coefficient arrays. -/
theorem ext {n : Nat} (p q : BPoly n) (h : ∀ x, p.eval x = q.eval x) : p = q := by
  induction p with
  | constant a =>
    cases q with
    | constant b => exact congrArg BPoly.constant (h (fun i => Fin.elim0 i))
  | node a b iha ihb =>
    cases q with
    | node c d =>
      have hac : a = c := by
        apply iha
        intro x
        have hx := h (extend x false)
        simpa only [eval_node_extend, Bool.false_and, Bool.xor_false] using hx
      have hbd : b = d := by
        apply ihb
        intro x
        have hx := h (extend x true)
        simp only [eval_node_extend, Bool.true_and, hac] at hx
        cases hc : c.eval x <;> cases hb : b.eval x <;> cases hd : d.eval x <;> simp_all
      rw [hac, hbd]

theorem add_zero {n : Nat} (p : BPoly n) : p.add (zero n) = p := by
  apply ext
  intro x
  simp only [eval_add, eval_zero, Bool.xor_false]

theorem zero_mul {n : Nat} (p : BPoly n) : (zero n).mul p = zero n := by
  apply ext
  intro x
  simp only [eval_mul, eval_zero, Bool.false_and]

theorem mul_zero {n : Nat} (p : BPoly n) : p.mul (zero n) = zero n := by
  apply ext
  intro x
  simp only [eval_mul, eval_zero, Bool.and_false]

/-- Every nonzero coefficient has degree strictly less than d.
At d=0 this means that the polynomial is identically zero. -/
def DegreeLT : {n : Nat} → BPoly n → Nat → Prop
  | 0, .constant b, d => b = false ∨ 0 < d
  | _ + 1, .node p q, d => p.DegreeLT d ∧ q.DegreeLT (d - 1)

theorem zero_degree (n d : Nat) : (zero n).DegreeLT d := by
  induction n generalizing d with
  | zero => exact Or.inl rfl
  | succ n ih => exact ⟨ih d, ih (d - 1)⟩

theorem degree_zero_iff {n : Nat} (p : BPoly n) : p.DegreeLT 0 ↔ p = zero n := by
  induction p with
  | constant b => cases b <;> simp [DegreeLT, zero]
  | node p q ihp ihq => simp [DegreeLT, ihp, ihq, zero]

theorem degree_mono {n : Nat} (p : BPoly n) {d e : Nat}
    (h : p.DegreeLT d) (hde : d ≤ e) : p.DegreeLT e := by
  induction p generalizing d e with
  | constant b =>
    change b = false ∨ 0 < d at h
    change b = false ∨ 0 < e
    rcases h with h | h
    · exact Or.inl h
    · exact Or.inr (Nat.lt_of_lt_of_le h hde)
  | node p q ihp ihq =>
    exact ⟨ihp h.1 hde, ihq h.2 (Nat.sub_le_sub_right hde 1)⟩

theorem degree_add {n d : Nat} (p q : BPoly n)
    (hp : p.DegreeLT d) (hq : q.DegreeLT d) : (p.add q).DegreeLT d := by
  induction p generalizing d with
  | constant a =>
    cases q with
    | constant b => cases a <;> cases b <;> simp_all [DegreeLT, add]
  | node a b iha ihb =>
    cases q with
    | node c e => exact ⟨iha c hp.1 hq.1, ihb e hp.2 hq.2⟩

theorem degree_mul {n d e : Nat} (p q : BPoly n)
    (hp : p.DegreeLT (d + 1)) (hq : q.DegreeLT (e + 1)) :
    (p.mul q).DegreeLT (d + e + 1) := by
  induction p generalizing d e with
  | constant a =>
    cases q with
    | constant b => exact Or.inr (Nat.zero_lt_succ _)
  | node a b iha ihb =>
    cases q with
    | node c f =>
      obtain ⟨ha, hb⟩ := hp
      obtain ⟨hc, hf⟩ := hq
      change b.DegreeLT d at hb
      change f.DegreeLT e at hf
      refine ⟨iha c ha hc, ?_⟩
      change ((a.mul f).add (b.mul c) |>.add (b.mul f)).DegreeLT (d + e)
      apply degree_add
      · apply degree_add
        · cases e with
          | zero => rw [(degree_zero_iff _).mp hf, mul_zero]; exact zero_degree _ _
          | succ e => simpa only [Nat.add_assoc] using iha f ha hf
        · cases d with
          | zero => rw [(degree_zero_iff _).mp hb, zero_mul]; exact zero_degree _ _
          | succ d =>
            have h := ihb c hb hc
            simpa only [Nat.add_right_comm d 1 e] using h
      · cases d with
        | zero => rw [(degree_zero_iff _).mp hb, zero_mul]; exact zero_degree _ _
        | succ d =>
          have hf' := degree_mono f hf (Nat.le_succ e)
          have h := ihb f hb hf'
          simpa only [Nat.add_right_comm d 1 e] using h

theorem one_degree (n : Nat) : (one n).DegreeLT 1 := by
  induction n with
  | zero => exact Or.inr (by decide)
  | succ n ih => exact ⟨ih, zero_degree n 0⟩

def ofFunction : (n : Nat) → ((Fin n → Bool) → Bool) → BPoly n
  | 0, f => .constant (f (fun i => Fin.elim0 i))
  | n + 1, f =>
      .node (ofFunction n (fun x => f (extend x false)))
        (ofFunction n (fun x => Bool.xor (f (extend x false)) (f (extend x true))))

theorem extend_reconstruct {n : Nat} (x : Fin (n + 1) → Bool) :
    extend (fun i => x i.castSucc) (x (Fin.last n)) = x := by
  funext i
  unfold extend
  split
  · rfl
  · rename_i h
    have hi : i = Fin.last n := Fin.ext (by change i.val = n; have := i.isLt; omega)
    rw [hi]

theorem eval_ofFunction (n : Nat) (f : (Fin n → Bool) → Bool) (x : Fin n → Bool) :
    (ofFunction n f).eval x = f x := by
  induction n with
  | zero =>
    have hx : x = (fun i => Fin.elim0 i) := by funext i; exact Fin.elim0 i
    rw [hx]
    rfl
  | succ n ih =>
    simp only [ofFunction, eval, ih]
    have hx := extend_reconstruct x
    cases hb : x (Fin.last n)
    · simp only [Bool.false_and, Bool.xor_false]
      rw [hb] at hx
      rw [hx]
    · simp only [Bool.true_and]
      rw [hb] at hx
      rw [hx]
      cases h0 : f (extend (fun i => x i.castSucc) false) <;> cases h1 : f x <;> rfl

end BPoly
end SatLowerBound
