import SatLowerBound.Cofactors

namespace SatLowerBound

def prepend {n : Nat} (b : Bool) (x : Fin n → Bool) : Fin (n + 1) → Bool :=
  Fin.cases b x

def ones : (n : Nat) → (Fin n → Bool) → Nat
  | 0, _ => 0
  | n + 1, x => (if x 0 then 1 else 0) + ones n (fun i => x i.succ)

@[simp] theorem ones_prepend (n : Nat) (b : Bool) (x : Fin n → Bool) :
    ones (n + 1) (prepend b x) = (if b then 1 else 0) + ones n x := rfl

@[simp] theorem ones_zero (n : Nat) : ones n (fun _ => false) = 0 := by
  induction n with
  | zero => rfl
  | succ n ih => simp [ones, ih]

def mod3 (n : Nat) (t : Fin 3) (x : Fin n → Bool) : Bool :=
  decide (ones n x % 3 = t.val)

theorem mod3_cofactor (n : Nat) (t : Fin 3) (b : Bool) (x : Fin n → Bool) :
    mod3 (n + 1) t (prepend b x) =
      decide (((if b then 1 else 0) + ones n x) % 3 = t.val) := rfl

theorem complementary_pair (n : Nat) (t : Fin 3) (b : Bool) (x : Fin n → Bool) :
    mod3 (n + 2) t (prepend b (prepend (!b) x)) =
      decide ((1 + ones n x) % 3 = t.val) := by
  cases b <;> simp [mod3]

def response (n : Nat) (t : Fin 3) (shift : Nat) : (Fin n → Bool) → Bool :=
  fun x => decide ((shift + ones n x) % 3 = t.val)

theorem response_distinct (n : Nat) (t : Fin 3) (a b : Fin 3) (hab : a ≠ b) :
    response (n + 1) t a.val ≠ response (n + 1) t b.val := by
  intro h
  have h0 := congrFun h (fun _ => false)
  have h1 := congrFun h (prepend true (fun _ => false))
  simp only [response, ones_zero, ones_prepend] at h0 h1
  have ht := t.isLt
  have ha := a.isLt
  have hb := b.isLt
  have hab' : a.val ≠ b.val := fun he => hab (Fin.ext he)
  have ta : t.val = 0 ∨ t.val = 1 ∨ t.val = 2 := by omega
  have aa : a.val = 0 ∨ a.val = 1 ∨ a.val = 2 := by omega
  have ba : b.val = 0 ∨ b.val = 1 ∨ b.val = 2 := by omega
  rcases ta with ht0 | ht1 | ht2 <;>
    rcases aa with ha0 | ha1 | ha2 <;>
    rcases ba with hb0 | hb1 | hb2 <;> simp_all

theorem mod3_three_rows (n : Nat) (t : Fin 3) :
    ThreeRows (fun a b x => mod3 (n + 3) t (prepend a (prepend b x))) := by
  refine ⟨(false, false), (false, true), (true, true), ?_, ?_, ?_⟩
  · have h := response_distinct n t 0 1 (by decide)
    unfold response at h
    simpa [PairRow, mod3] using h
  · have h := response_distinct n t 0 2 (by decide)
    unfold response at h
    simpa [PairRow, mod3, ← Nat.add_assoc] using h
  · have h := response_distinct n t 1 2 (by decide)
    unfold response at h
    simpa [PairRow, mod3, ← Nat.add_assoc] using h

theorem mod3_no_single_signal (n : Nat) (t : Fin 3) :
    ¬ ∃ (g : Bool → Bool → Bool) (H : Bool → (Fin (n + 1) → Bool) → Bool),
      ∀ a b x, mod3 (n + 3) t (prepend a (prepend b x)) = H (g a b) x :=
  no_single_signal _ (mod3_three_rows n t)

end SatLowerBound
