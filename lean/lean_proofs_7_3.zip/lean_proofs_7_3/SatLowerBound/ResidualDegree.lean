import SatLowerBound.NonlinearDegree
import SatLowerBound.Restriction

namespace SatLowerBound
namespace Signal

def polynomial {n : Nat} : Signal n → BPoly n
  | .constant b => BPoly.select b (BPoly.one n)
  | .wire i b => if b then (BPoly.one n).add (BPoly.varPoly n i) else BPoly.varPoly n i

theorem polynomial_eval {n : Nat} (s : Signal n) (x : Fin n → Bool) :
    s.polynomial.eval x = s.eval x := by
  cases s with
  | constant b => cases b <;> simp [polynomial, eval, BPoly.eval_select]
  | wire i b =>
    cases b <;> simp only [polynomial, eval, Bool.false_eq_true, ↓reduceIte,
      BPoly.eval_add, BPoly.eval_one, BPoly.eval_varPoly]
    · exact (Bool.xor_false _).symm
    · cases x i <;> rfl

theorem polynomial_degree {n : Nat} (s : Signal n) : s.polynomial.DegreeLT 2 := by
  cases s with
  | constant b =>
    exact BPoly.degree_select b _ (BPoly.degree_mono _ (BPoly.one_degree n) (by decide))
  | wire i b =>
    cases b
    · exact BPoly.degree_varPoly n i
    · exact BPoly.degree_add _ _ (BPoly.degree_mono _ (BPoly.one_degree n) (by decide))
        (BPoly.degree_varPoly n i)

end Signal
namespace OpenCircuit

def nonlinearCount : {n : Nat} → OpenCircuit n → Nat
  | _, .output _ => 0
  | _, .gate g _ _ rest => g.nonlinearCount + rest.nonlinearCount

theorem resource_le {n : Nat} (C : OpenCircuit n) :
    C.weight + C.nonlinearCount ≤ 3 * C.size := by
  induction C with
  | output => exact Nat.le_refl 0
  | gate g i j rest ih =>
    simp only [weight, nonlinearCount, size]
    have hg := g.resource_le
    omega

def polynomial : {n : Nat} → OpenCircuit n → BPoly n
  | _, .output s => s.polynomial
  | _, .gate g i j rest =>
      match polynomial rest with
      | .node p q => p.add ((BPoly.gatePoly g i j).mul q)

theorem polynomial_eval {n : Nat} (C : OpenCircuit n) (x : Fin n → Bool) :
    C.polynomial.eval x = C.eval x := by
  induction C with
  | output s => exact Signal.polynomial_eval _ _
  | gate g i j rest ih =>
    cases hp : rest.polynomial with
    | node p q =>
      simp only [polynomial, hp, BPoly.eval_add, BPoly.eval_mul, BPoly.eval_gatePoly]
      have he := ih (extend x (g.eval (x i) (x j)))
      rw [hp, BPoly.eval_node_extend] at he
      exact he

theorem polynomial_degree {n : Nat} (C : OpenCircuit n) :
    C.polynomial.DegreeLT (C.nonlinearCount + 2) := by
  induction C with
  | output s => exact Signal.polynomial_degree _
  | gate g i j rest ih =>
    cases hp : rest.polynomial with
    | node p q =>
      rw [hp] at ih
      obtain ⟨hpdeg, hqdeg⟩ := ih
      change q.DegreeLT (rest.nonlinearCount + 1) at hqdeg
      simp only [polynomial, hp, nonlinearCount]
      apply BPoly.degree_add
      · exact BPoly.degree_mono _ hpdeg (by omega)
      · have h := BPoly.degree_mul _ _ (BPoly.degree_gatePoly g i j) hqdeg
        simpa only [Nat.add_right_comm g.nonlinearCount 1 rest.nonlinearCount,
          Nat.add_assoc] using h

theorem nonlinear_lower_bound {n : Nat} (C : OpenCircuit n) (f : (Fin n → Bool) → Bool)
    (hc : ∀ x, C.eval x = f x) (hf : (BPoly.ofFunction n f).topCoefficient = true) :
    n ≤ C.nonlinearCount + 1 := by
  have he : C.polynomial = BPoly.ofFunction n f := by
    apply BPoly.ext
    intro x
    rw [polynomial_eval, BPoly.eval_ofFunction, hc]
  have hd := polynomial_degree C
  rw [he] at hd
  have hn := BPoly.degree_of_topCoefficient _ hf hd
  omega

end OpenCircuit
end SatLowerBound
