import SatLowerBound.Gates

namespace SatLowerBound

abbrev PairRow {α : Type} (f : Bool → Bool → α → Bool) (p : Bool × Bool) : α → Bool :=
  f p.1 p.2

def ThreeRows {α : Type} (f : Bool → Bool → α → Bool) : Prop :=
  ∃ p q r : Bool × Bool,
    PairRow f p ≠ PairRow f q ∧ PairRow f p ≠ PairRow f r ∧ PairRow f q ≠ PairRow f r

/-- Three distinct cofactor responses cannot pass through one Boolean signal. -/
theorem no_single_signal {α : Type} (f : Bool → Bool → α → Bool)
    (h : ThreeRows f) :
    ¬ ∃ (g : Bool → Bool → Bool) (H : Bool → α → Bool),
      ∀ x y z, f x y z = H (g x y) z := by
  rintro ⟨g, H, hfac⟩
  rcases h with ⟨p, q, r, hpq, hpr, hqr⟩
  have heq (a b : Bool × Bool) (hab : g a.1 a.2 = g b.1 b.2) :
      PairRow f a = PairRow f b := by
    funext z
    exact (hfac _ _ _).trans ((congrArg (fun v => H v z) hab).trans (hfac _ _ _).symm)
  have hpq' : g p.1 p.2 ≠ g q.1 q.2 := fun hab => hpq (heq p q hab)
  have hpr' : g p.1 p.2 ≠ g r.1 r.2 := fun hab => hpr (heq p r hab)
  have hqr' : g q.1 q.2 ≠ g r.1 r.2 := fun hab => hqr (heq q r hab)
  cases hgp : g p.1 p.2 <;> cases hgq : g q.1 q.2 <;>
    cases hgr : g r.1 r.2 <;> simp_all

end SatLowerBound
