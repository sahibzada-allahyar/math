import SatLowerBound.Dependence

namespace SatLowerBound

theorem twist_false_false (g : Table) : twist g false false = g := by
  rcases g with ⟨a, b, c, d⟩
  rfl

theorem simplifyGate_plain_binary {n : Nat} (g h : Table) (i j k l : Fin n)
    (hs : simplifyGate g (.wire i false) (.wire j false) = .binary h k l) :
    g.essential = true ∧ i ≠ j := by
  simp only [simplifyGate, twist_false_false] at hs
  split at hs
  · contradiction
  · rename_i hij
    have he := GateStep.classify_binary_essential g h i j k l hs
    unfold GateStep.classify at hs
    split at hs
    · contradiction
    · split at hs
      · contradiction
      · cases hs
        exact ⟨he, hij⟩

namespace OpenCircuit

/-- Every retained instruction is essential with distinct predecessors and a later user. -/
def Reduced : {n : Nat} → OpenCircuit n → Prop
  | _, .output _ => True
  | _, .gate g i j rest => g.essential = true ∧ i ≠ j ∧ 0 < rest.lastUses ∧ rest.Reduced

theorem reduced_live {n : Nat} (C : OpenCircuit n) (h : C.Reduced) : C.Live := by
  induction C with
  | output => trivial
  | gate g i j rest ih => exact ⟨h.2.2.1, ih h.2.2.2⟩

theorem reduced_essential {n : Nat} (C : OpenCircuit n) (h : C.Reduced) : C.EssentialGates := by
  induction C with
  | output => trivial
  | gate g i j rest ih => exact ⟨h.1, ih h.2.2.2⟩

theorem drop_head_alias {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (s : Signal n) (hs : ∀ x, s.eval x = g.eval (x i) (x j)) :
    ∃ D : OpenCircuit n, D.size < (gate g i j rest).size ∧
      D.weight ≤ (gate g i j rest).weight ∧ ∀ x, D.eval x = (gate g i j rest).eval x := by
  let D := rest.restrict (extendSubst (identitySubst n) s)
  refine ⟨D, ?_, ?_, ?_⟩
  · exact Nat.lt_succ_of_le (restrict_size_le rest _)
  · exact Nat.le_trans (restrict_weight_le rest _) (Nat.le_add_left _ _)
  · intro x
    rw [restrict_eval, eval_extendSubst, identity_eval, hs]
    rfl

theorem smaller_of_not_reduced {n : Nat} (C : OpenCircuit n) (h : ¬ C.Reduced) :
    ∃ D : OpenCircuit n, D.size < C.size ∧ D.weight ≤ C.weight ∧ ∀ x, D.eval x = C.eval x := by
  induction C with
  | output s => exact False.elim (h True.intro)
  | @gate n g i j rest ih =>
    by_cases hhead : g.essential = true ∧ i ≠ j
    · by_cases hu : 0 < rest.lastUses
      · have hr : ¬ rest.Reduced := fun hh => h ⟨hhead.1, hhead.2, hu, hh⟩
        obtain ⟨R, hs, hw, he⟩ := ih hr
        exact ⟨.gate g i j R, Nat.add_lt_add_right hs 1,
          Nat.add_le_add_left hw _, fun x => he _⟩
      · have hu0 : rest.lastUses = 0 := by omega
        refine ⟨rest.restrict (dropLast n), Nat.lt_succ_of_le (restrict_size_le rest _),
          Nat.le_trans (restrict_weight_le rest _) (Nat.le_add_left _ _), ?_⟩
        intro x
        rw [dropLast_eval, eval_unused_last rest hu0 x false (g.eval (x i) (x j))]
        rfl
    · cases hs : simplifyGate g (.wire i false) (.wire j false) with
      | «alias» s =>
        apply drop_head_alias g i j rest s
        intro x
        have hh := simplifyGate_eval g (.wire i false) (.wire j false) x
        rw [hs] at hh
        simpa only [GateStep.eval, Signal.eval, Bool.xor_false] using hh
      | binary f k l => exact False.elim (hhead (simplifyGate_plain_binary g f i j k l hs))

/-- Sum of predecessor positions, using the fixed topological instruction order. -/
def predecessorSum : {n : Nat} → OpenCircuit n → Nat
  | _, .output _ => 0
  | _, .gate _ i j rest => i.val + j.val + rest.predecessorSum

/-- Size is minimized first; predecessor positions break ties. The domain contains
all equivalent circuits within the original weight bound, not just normalized ones. -/
def Minimal {n : Nat} (f : (Fin n → Bool) → Bool) (W : Nat) (C : OpenCircuit n) : Prop :=
  C.weight ≤ W ∧ (∀ x, C.eval x = f x) ∧
    ∀ D : OpenCircuit n, D.weight ≤ W → (∀ x, D.eval x = f x) →
      C.size ≤ D.size ∧ (D.size = C.size → C.predecessorSum ≤ D.predecessorSum)

theorem exists_minimal {n : Nat} (C : OpenCircuit n) :
    ∃ D : OpenCircuit n, Minimal C.eval C.weight D ∧ D.size ≤ C.size := by
  classical
  let P : Nat → Prop := fun s => ∃ D : OpenCircuit n,
    D.weight ≤ C.weight ∧ (∀ x, D.eval x = C.eval x) ∧ D.size = s
  have hp : ∃ s, P s := ⟨C.size, C, Nat.le_refl _, fun _ => rfl, rfl⟩
  let s := Nat.find hp
  obtain ⟨D, hwD, heD, hsD⟩ := Nat.find_spec hp
  let Q : Nat → Prop := fun t => ∃ E : OpenCircuit n,
    E.weight ≤ C.weight ∧ (∀ x, E.eval x = C.eval x) ∧ E.size = s ∧ E.predecessorSum = t
  have hq : ∃ t, Q t := ⟨D.predecessorSum, D, hwD, heD, hsD, rfl⟩
  obtain ⟨E, hwE, heE, hsE, htE⟩ := Nat.find_spec hq
  refine ⟨E, ⟨hwE, heE, ?_⟩, ?_⟩
  · intro F hwF heF
    have hsize : E.size ≤ F.size := by
      rw [hsE]
      exact Nat.find_min' hp ⟨F, hwF, heF, rfl⟩
    refine ⟨hsize, ?_⟩
    intro hsF
    rw [htE]
    exact Nat.find_min' hq ⟨F, hwF, heF, hsF.trans hsE, rfl⟩
  · rw [hsE]
    exact Nat.find_min' hp ⟨C, Nat.le_refl _, fun _ => rfl, rfl⟩

theorem minimal_reduced {n : Nat} (f : (Fin n → Bool) → Bool) (W : Nat)
    (C : OpenCircuit n) (h : Minimal f W C) : C.Reduced := by
  by_contra hn
  obtain ⟨D, hs, hw, he⟩ := smaller_of_not_reduced C hn
  have hmin := h.2.2 D (Nat.le_trans hw h.1) (fun x => (he x).trans (h.2.1 x))
  omega

end OpenCircuit
end SatLowerBound
