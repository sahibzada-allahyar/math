import SatLowerBound.Mod3
import Mathlib.RingTheory.RootsOfUnity.Complex
import Mathlib.FieldTheory.Finite.GaloisField
import Mathlib.Tactic.Ring

namespace SatLowerBound

/-- Sum a function over the Boolean cube, splitting on the first coordinate. -/
def cubeSum {R : Type*} [AddCommMonoid R] : (n : Nat) → ((Fin n → Bool) → R) → R
  | 0, f => f (fun i => Fin.elim0 i)
  | n + 1, f => cubeSum n (fun v => f (prepend false v)) +
      cubeSum n (fun v => f (prepend true v))

theorem cubeSum_add {R : Type*} [AddCommMonoid R] (n : Nat)
    (f g : (Fin n → Bool) → R) :
    cubeSum n (fun v => f v + g v) = cubeSum n f + cubeSum n g := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [cubeSum, ih]; ac_rfl

theorem cubeSum_const {R : Type*} [CommRing R] (n : Nat) (a : R) :
    cubeSum n (fun _ => a) = 2 ^ n * a := by
  induction n with
  | zero => simp [cubeSum]
  | succ n ih => simp only [cubeSum, ih, pow_succ]; ring

theorem cubeSum_mul {R : Type*} [CommRing R] (n : Nat)
    (a : R) (f : (Fin n → Bool) → R) :
    cubeSum n (fun v => a * f v) = a * cubeSum n f := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [cubeSum, ih, mul_add]

theorem cubeSum_pow_ones {R : Type*} [CommRing R] (n : Nat) (a : R) :
    cubeSum n (fun v => a ^ ones n v) = (1 + a) ^ n := by
  induction n with
  | zero => simp [cubeSum, ones]
  | succ n ih =>
      simp only [cubeSum, ones_prepend, Bool.false_eq_true, ↓reduceIte,
        Nat.zero_add, pow_add, cubeSum_mul, ih, pow_succ]
      ring

/-- The three-residue root-of-unity filter, before division by three. -/
theorem cubic_root_filter {R : Type*} [CommRing R] (z : R)
    (hz : z ^ 3 = 1) (hs : 1 + z + z ^ 2 = 0) (a : Nat) :
    1 + z ^ a + z ^ (2 * a) = if a % 3 = 0 then 3 else 0 := by
  rw [pow_eq_pow_mod a hz, pow_eq_pow_mod (2 * a) hz]
  have hm : (2 * a) % 3 = (2 * (a % 3)) % 3 := by omega
  rw [hm]
  have ha : a % 3 = 0 ∨ a % 3 = 1 ∨ a % 3 = 2 := by omega
  rcases ha with ha | ha | ha
  · norm_num [ha]
  · simpa [ha] using hs
  · simpa [ha, add_comm, add_left_comm, add_assoc] using hs

/-- Summing the filter produces the product expression used in the manuscript. -/
theorem cubic_filter_cube_sum {R : Type*} [CommRing R] (z : R)
    (hz : z ^ 3 = 1) (hs : 1 + z + z ^ 2 = 0) (n a : Nat) :
    cubeSum n (fun v => if (a + ones n v) % 3 = 0 then (3 : R) else 0) =
      2 ^ n + z ^ a * (1 + z) ^ n + z ^ (2 * a) * (1 + z ^ 2) ^ n := by
  have hf : (fun v => if (a + ones n v) % 3 = 0 then (3 : R) else 0) =
      (fun v => 1 + z ^ a * z ^ ones n v + z ^ (2 * a) * (z ^ 2) ^ ones n v) := by
    funext v
    rw [← cubic_root_filter z hz hs]
    simp only [pow_add, Nat.mul_add, pow_mul]
  rw [hf, cubeSum_add, cubeSum_add, cubeSum_const, cubeSum_mul, cubeSum_mul,
    cubeSum_pow_ones, cubeSum_pow_ones, mul_one]

noncomputable def cubicRoot : ℂ := Complex.exp (2 * Real.pi * Complex.I / 3)

theorem cubicRoot_primitive : IsPrimitiveRoot cubicRoot 3 :=
  Complex.isPrimitiveRoot_exp 3 (by decide)

theorem cubicRoot_sum : 1 + cubicRoot + cubicRoot ^ 2 = 0 := by
  have h := cubicRoot_primitive.geom_sum_eq_zero (by decide : 1 < 3)
  simpa [Finset.sum_range_succ, add_assoc] using h

/-- Evaluate the two nontrivial filter terms at the selected residue tau=1-n. -/
theorem cubic_filter_selected {R : Type*} [CommRing R] (z : R)
    (hz : z ^ 3 = 1) (hs : 1 + z + z ^ 2 = 0) (n : Nat) :
    z ^ (n + 2) * (1 + z) ^ n + z ^ (2 * (n + 2)) * (1 + z ^ 2) ^ n =
      -((-1 : R) ^ n) := by
  have h1 : 1 + z = -z ^ 2 := eq_neg_of_add_eq_zero_left hs
  have h2 : 1 + z ^ 2 = -z := by linear_combination hs
  have hp1 : (-(z ^ 2)) ^ n = (-1 : R) ^ n * z ^ (2 * n) := by
    rw [neg_pow, ← pow_mul]
  have hp2 : (-z) ^ n = (-1 : R) ^ n * z ^ n := neg_pow z n
  rw [h1, h2, hp1, hp2]
  have he1 : z ^ (n + 2) * ((-1 : R) ^ n * z ^ (2 * n)) = (-1 : R) ^ n * z ^ 2 := by
    rw [mul_left_comm, ← pow_add, pow_eq_pow_mod _ hz]
    have hmod : (n + 2 + 2 * n) % 3 = 2 := by omega
    rw [hmod]
  have he2 : z ^ (2 * (n + 2)) * ((-1 : R) ^ n * z ^ n) = (-1 : R) ^ n * z := by
    rw [mul_left_comm, ← pow_add, pow_eq_pow_mod _ hz]
    have hmod : (2 * (n + 2) + n) % 3 = 1 := by omega
    rw [hmod, pow_one]
  rw [he1, he2, ← mul_add]
  have hsum : z ^ 2 + z = -1 := by linear_combination hs
  rw [hsum, mul_neg_one]

end SatLowerBound
