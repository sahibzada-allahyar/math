import SatLowerBound.Circuit

/-! A verified compiler for restrictions. Signed references and constant outputs
are internal bookkeeping; the public theorem continues to use `Circuit`.
Every retained binary instruction is counted. -/
namespace SatLowerBound

inductive Signal (n : Nat) where
  | constant (value : Bool)
  | wire (index : Fin n) (negated : Bool)
  deriving DecidableEq

namespace Signal

def eval {n : Nat} (s : Signal n) (x : Fin n → Bool) : Bool :=
  match s with
  | .constant b => b
  | .wire i b => Bool.xor (x i) b

def negate {n : Nat} : Signal n → Signal n
  | .constant b => .constant (!b)
  | .wire i b => .wire i (!b)

@[simp] theorem eval_negate {n : Nat} (s : Signal n) (x : Fin n → Bool) :
    s.negate.eval x = !(s.eval x) := by
  cases s with
  | constant b => rfl
  | wire i b => cases b <;> cases hx : x i <;> simp [negate, eval, hx]

def rename {n m : Nat} (f : Fin n → Fin m) : Signal n → Signal m
  | .constant b => .constant b
  | .wire i b => .wire (f i) b

@[simp] theorem eval_rename {n m : Nat} (f : Fin n → Fin m)
    (s : Signal n) (x : Fin m → Bool) :
    (s.rename f).eval x = s.eval (fun i => x (f i)) := by cases s <;> rfl

def subst {n m : Nat} (σ : Fin n → Signal m) : Signal n → Signal m
  | .constant b => .constant b
  | .wire i b => if b then (σ i).negate else σ i

@[simp] theorem eval_subst {n m : Nat} (σ : Fin n → Signal m)
    (s : Signal n) (x : Fin m → Bool) :
    (s.subst σ).eval x = s.eval (fun i => (σ i).eval x) := by
  cases s with
  | constant b => rfl
  | wire i b =>
    cases b
    · simp [subst, eval]
    · change (σ i).negate.eval x = Bool.xor ((σ i).eval x) true
      rw [eval_negate, Bool.xor_true]

/-- A one-input truth table is represented by a constant or signed reference. -/
def unary {n : Nat} (f : Bool → Bool) (i : Fin n) : Signal n :=
  if f false = f true then .constant (f false) else .wire i (f false)

theorem eval_unary {n : Nat} (f : Bool → Bool) (i : Fin n) (x : Fin n → Bool) :
    (unary f i).eval x = f (x i) := by
  cases h0 : f false <;> cases h1 : f true <;> cases hx : x i <;>
    simp [unary, eval, h0, h1, hx]

end Signal

inductive GateStep (n : Nat) where
  | alias (signal : Signal n)
  | binary (table : Table) (left right : Fin n)

namespace GateStep

def eval {n : Nat} (s : GateStep n) (x : Fin n → Bool) : Bool :=
  match s with
  | .alias a => a.eval x
  | .binary g i j => g.eval (x i) (x j)

def weight {n : Nat} : GateStep n → Nat
  | .alias _ => 0
  | .binary g _ _ => g.weight

def size {n : Nat} : GateStep n → Nat
  | .alias _ => 0
  | .binary _ _ _ => 1

/-- Remove every nonessential truth table. -/
def classify {n : Nat} (g : Table) (i j : Fin n) : GateStep n :=
  if g.ff = g.tf ∧ g.ft = g.tt then
    .alias (Signal.unary (fun b => g.eval false b) j)
  else if g.ff = g.ft ∧ g.tf = g.tt then
    .alias (Signal.unary (fun a => g.eval a false) i)
  else .binary g i j

theorem eval_classify {n : Nat} (g : Table) (i j : Fin n) (x : Fin n → Bool) :
    (classify g i j).eval x = g.eval (x i) (x j) := by
  unfold classify
  split
  · rename_i h
    simp only [eval, Signal.eval_unary]
    cases hi : x i <;> cases hj : x j <;> simp_all [Table.eval]
  · split
    · rename_i h
      simp only [eval, Signal.eval_unary]
      cases hi : x i <;> cases hj : x j <;> simp_all [Table.eval]
    · rfl

theorem weight_classify {n : Nat} (g : Table) (i j : Fin n) :
    (classify g i j).weight ≤ g.weight := by
  unfold classify
  split
  · exact Nat.zero_le _
  · split
    · exact Nat.zero_le _
    · exact Nat.le_refl _

theorem classify_binary_essential {n : Nat} (g h : Table) (i j k l : Fin n)
    (hs : classify g i j = .binary h k l) : h.essential = true := by
  unfold classify at hs
  split at hs
  · contradiction
  · split at hs
    · contradiction
    · cases hs
      rcases g with ⟨a, b, c, d⟩
      cases a <;> cases b <;> cases c <;> cases d <;> simp_all [Table.essential]

end GateStep

def twist (g : Table) (a b : Bool) : Table :=
  Table.ofFunction (fun x y => g.eval (Bool.xor x a) (Bool.xor y b))

theorem twist_weight (g : Table) (a b : Bool) : (twist g a b).weight = g.weight := by
  rcases g with ⟨c, d, e, f⟩
  cases a <;> cases b <;> cases c <;> cases d <;> cases e <;> cases f <;> decide

/-- Specialize a binary instruction to its two substituted signals. -/
def simplifyGate {n : Nat} (g : Table) : Signal n → Signal n → GateStep n
  | .constant a, .constant b => .alias (.constant (g.eval a b))
  | .constant a, .wire j b =>
      .alias (Signal.unary (fun y => g.eval a (Bool.xor y b)) j)
  | .wire i a, .constant b =>
      .alias (Signal.unary (fun x => g.eval (Bool.xor x a) b) i)
  | .wire i a, .wire j b =>
      if i = j then
        .alias (Signal.unary (fun x => g.eval (Bool.xor x a) (Bool.xor x b)) i)
      else GateStep.classify (twist g a b) i j

theorem simplifyGate_eval {n : Nat} (g : Table) (s t : Signal n) (x : Fin n → Bool) :
    (simplifyGate g s t).eval x = g.eval (s.eval x) (t.eval x) := by
  cases s with
  | constant a =>
    cases t with
    | constant b => rfl
    | wire j b => exact Signal.eval_unary _ _ _
  | wire i a =>
    cases t with
    | constant b => exact Signal.eval_unary _ _ _
    | wire j b =>
      simp only [simplifyGate]
      split
      · rename_i h
        subst j
        exact Signal.eval_unary _ _ _
      · simp only [GateStep.eval_classify, twist, Table.eval_ofFunction, Signal.eval]

theorem simplifyGate_weight {n : Nat} (g : Table) (s t : Signal n) :
    (simplifyGate g s t).weight ≤ g.weight := by
  cases s with
  | constant a => cases t <;> exact Nat.zero_le _
  | wire i a =>
    cases t with
    | constant b => exact Nat.zero_le _
    | wire j b =>
      simp only [simplifyGate]
      split
      · exact Nat.zero_le _
      · simpa only [twist_weight] using GateStep.weight_classify (twist g a b) i j

theorem simplifyGate_const_left {n : Nat} (g : Table) (b : Bool) (t : Signal n) :
    (simplifyGate g (.constant b) t).size = 0 := by cases t <;> rfl

theorem simplifyGate_const_right {n : Nat} (g : Table) (s : Signal n) (b : Bool) :
    (simplifyGate g s (.constant b)).size = 0 := by cases s <;> rfl

inductive OpenCircuit : Nat → Type where
  | output {n : Nat} (s : Signal n) : OpenCircuit n
  | gate {n : Nat} (g : Table) (left right : Fin n)
      (rest : OpenCircuit (n + 1)) : OpenCircuit n

namespace OpenCircuit

def eval : {n : Nat} → OpenCircuit n → (Fin n → Bool) → Bool
  | _, .output s, x => s.eval x
  | _, .gate g i j rest, x => rest.eval (extend x (g.eval (x i) (x j)))

def size : {n : Nat} → OpenCircuit n → Nat
  | _, .output _ => 0
  | _, .gate _ _ _ rest => rest.size + 1

def weight : {n : Nat} → OpenCircuit n → Nat
  | _, .output _ => 0
  | _, .gate g _ _ rest => g.weight + rest.weight

def ofCircuit : {n : Nat} → Circuit n → OpenCircuit n
  | _, .output i => .output (.wire i false)
  | _, .gate g i j rest => .gate g i j (ofCircuit rest)

theorem ofCircuit_eval {n : Nat} (C : Circuit n) (x : Fin n → Bool) :
    (ofCircuit C).eval x = C.eval x := by
  induction C with
  | output i => simp [ofCircuit, eval, Circuit.eval, Signal.eval]
  | gate g i j rest ih => exact ih _

theorem ofCircuit_size {n : Nat} (C : Circuit n) : (ofCircuit C).size = C.size := by
  induction C with
  | output => rfl
  | gate g i j rest ih => simp only [ofCircuit, size, Circuit.size, ih]

theorem ofCircuit_weight {n : Nat} (C : Circuit n) : (ofCircuit C).weight = C.weight := by
  induction C with
  | output => rfl
  | gate g i j rest ih => simp only [ofCircuit, weight, Circuit.weight, ih]

/-- Extend a substitution after an instruction that was bypassed. -/
def extendSubst {n m : Nat} (σ : Fin n → Signal m) (s : Signal m) :
    Fin (n + 1) → Signal m :=
  fun i => if h : i.val < n then σ ⟨i.val, h⟩ else s

theorem eval_extendSubst {n m : Nat} (σ : Fin n → Signal m) (s : Signal m)
    (x : Fin m → Bool) :
    (fun i => (extendSubst σ s i).eval x) =
      extend (fun i => (σ i).eval x) (s.eval x) := by
  funext i
  unfold extendSubst extend
  split <;> rfl

/-- Extend a substitution after an instruction retained in the residual circuit. -/
def liftSubst {n m : Nat} (σ : Fin n → Signal m) : Fin (n + 1) → Signal (m + 1) :=
  extendSubst (fun i => (σ i).rename Fin.castSucc) (.wire (Fin.last m) false)

theorem eval_liftSubst {n m : Nat} (σ : Fin n → Signal m) (b : Bool)
    (x : Fin m → Bool) :
    (fun i => (liftSubst σ i).eval (extend x b)) =
      extend (fun i => (σ i).eval x) b := by
  rw [liftSubst, eval_extendSubst]
  have hr : (fun i => ((σ i).rename Fin.castSucc).eval (extend x b)) =
      (fun i => (σ i).eval x) := by
    funext i
    rw [Signal.eval_rename]
    simp only [extend_old]
  rw [hr]
  simp only [Signal.eval, extend_last, Bool.xor_false]

def restrict : {n m : Nat} → OpenCircuit n → (Fin n → Signal m) → OpenCircuit m
  | _, _, .output s, σ => .output (s.subst σ)
  | _, _, .gate g i j rest, σ =>
      match simplifyGate g (σ i) (σ j) with
      | .alias s => restrict rest (extendSubst σ s)
      | .binary h k l => .gate h k l (restrict rest (liftSubst σ))

theorem restrict_eval {n m : Nat} (C : OpenCircuit n) (σ : Fin n → Signal m)
    (x : Fin m → Bool) :
    (C.restrict σ).eval x = C.eval (fun i => (σ i).eval x) := by
  induction C generalizing m with
  | output s => exact Signal.eval_subst _ _ _
  | gate g i j rest ih =>
    simp only [restrict]
    split
    · rename_i s hs
      rw [ih, eval_extendSubst]
      have he := simplifyGate_eval g (σ i) (σ j) x
      rw [hs] at he
      exact congrArg (fun b => rest.eval (extend (fun i => (σ i).eval x) b)) he
    · rename_i h k l hs
      simp only [eval, ih, eval_liftSubst]
      have he := simplifyGate_eval g (σ i) (σ j) x
      rw [hs] at he
      exact congrArg (fun b => rest.eval (extend (fun i => (σ i).eval x) b)) he

theorem restrict_size_le {n m : Nat} (C : OpenCircuit n) (σ : Fin n → Signal m) :
    (C.restrict σ).size ≤ C.size := by
  induction C generalizing m with
  | output => exact Nat.le_refl 0
  | gate g i j rest ih =>
    simp only [restrict]
    split
    · exact Nat.le_trans (ih _) (Nat.le_succ _)
    · exact Nat.add_le_add_right (ih _) 1

theorem restrict_weight_le {n m : Nat} (C : OpenCircuit n) (σ : Fin n → Signal m) :
    (C.restrict σ).weight ≤ C.weight := by
  induction C generalizing m with
  | output => exact Nat.le_refl 0
  | gate g i j rest ih =>
    simp only [restrict]
    split
    · exact Nat.le_trans (ih _) (Nat.le_add_left _ _)
    · rename_i h k l hs
      have hw := simplifyGate_weight g (σ i) (σ j)
      rw [hs] at hw
      exact Nat.add_le_add hw (ih _)

end OpenCircuit
end SatLowerBound
