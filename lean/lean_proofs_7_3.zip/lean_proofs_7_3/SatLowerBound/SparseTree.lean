import SatLowerBound.TreeFamily
import SatLowerBound.WeightedComposition

namespace SatLowerBound

def helperResidue (r : Nat) : Fin 3 := ⟨(4 - r % 3) % 3, Nat.mod_lt _ (by omega)⟩

theorem helperResidue_sum (r : Nat) : (r + (helperResidue r).val) % 3 = 1 := by
  have hr : r % 3 = 0 ∨ r % 3 = 1 ∨ r % 3 = 2 := by have := Nat.mod_lt r (by omega : 0 < 3); omega
  rcases hr with hr | hr | hr <;> simp [helperResidue, Nat.add_mod, hr]

theorem helperResidue_equiv (r q : Nat) : q % 3 = (helperResidue r).val ↔ (r + q) % 3 = 1 := by
  have hr : r % 3 = 0 ∨ r % 3 = 1 ∨ r % 3 = 2 := by have := Nat.mod_lt r (by omega : 0 < 3); omega
  have hq : q % 3 = 0 ∨ q % 3 = 1 ∨ q % 3 = 2 := by have := Nat.mod_lt q (by omega : 0 < 3); omega
  rcases hr with hr | hr | hr <;> rcases hq with hq | hq | hq <;>
    simp [helperResidue, Nat.add_mod, hr, hq]

def blockSupport (k r : Nat) (c : Fin k) (s : Fin 3) : Finset (Fin (k * 3 * r)) :=
  Finset.univ.image (fun b : Fin r => pairIndex (pairIndex c s) b)

theorem packed_block_injective {k r : Nat} (hr : 0 < r) (c d : Fin k) (s t : Fin 3) (b e : Fin r)
    (h : pairIndex (pairIndex c s) b = pairIndex (pairIndex d t) e) : c = d ∧ s = t ∧ b = e := by
  have hu := congrArg (unpairIndex hr) h
  rw [unpair_pair, unpair_pair] at hu
  have hb := congrArg Prod.snd hu
  have hc := congrArg (unpairIndex (by decide : 0 < 3)) (congrArg Prod.fst hu)
  rw [unpair_pair, unpair_pair] at hc
  exact ⟨congrArg Prod.fst hc, congrArg Prod.snd hc, hb⟩

theorem blockSupport_card (k r : Nat) (hr : 0 < r) (c : Fin k) (s : Fin 3) :
    (blockSupport k r c s).card = r := by
  have hi : Function.Injective (fun b : Fin r => pairIndex (pairIndex c s) b) :=
    fun _ _ h => (packed_block_injective hr c c s s _ _ h).2.2
  simp [blockSupport, Finset.card_image_of_injective _ hi]

theorem blockSupport_disjoint (k r : Nat) (hr : 0 < r) (c d : Fin k) (s t : Fin 3)
    (hne : c ≠ d ∨ s ≠ t) : Disjoint (blockSupport k r c s) (blockSupport k r d t) := by
  apply Finset.disjoint_left.mpr
  intro i hi hj
  obtain ⟨b, _, hb⟩ := Finset.mem_image.mp hi
  obtain ⟨e, _, he⟩ := Finset.mem_image.mp hj
  have h := packed_block_injective hr c d s t b e (hb.trans he.symm)
  rcases hne with hn | hn
  · exact hn h.1
  · exact hn h.2.1

theorem blockSupport_tally (k r : Nat) (hr : 0 < r) (c : Fin k) (s : Fin 3)
    (v : Fin (k * 3 * r) → Bool) :
    tally (blockSupport k r c s) v = ones r (fun b => v (pairIndex (pairIndex c s) b)) := by
  unfold tally blockSupport
  rw [Finset.sum_image]
  · exact (ones_eq_sum r _).symm
  · intro a _ b _ he
    exact (packed_block_injective hr c c s s a b he).2.2

def sparseLeaf (k r : Nat) (c : Fin k) (s : Fin 3) : ModularTree (k * 3 * r) :=
  .leaf (blockSupport k r c s) (helperResidue r) true

theorem sparseLeaf_eval (k r : Nat) (hr : 0 < r) (c : Fin k) (s : Fin 3)
    (v : Fin (k * 3 * r) → Bool) :
    (sparseLeaf k r c s).eval v = helperBlock r (fun b => v (pairIndex (pairIndex c s) b)) := by
  simp only [sparseLeaf, ModularTree.eval, modularBlock, blockSupport_tally k r hr,
    Bool.xor_true, helperBlock, shiftedFunction, Nat.one_mod]
  congr 1
  apply Bool.eq_iff_iff.mpr
  simpa only [decide_eq_true_eq] using helperResidue_equiv r (ones r (fun b => v (pairIndex (pairIndex c s) b)))

theorem sparseLeaf_valid (k r : Nat) (hr : 3 ≤ r) (c : Fin k) (s : Fin 3) :
    (sparseLeaf k r c s).Valid 3 := by
  change 3 ≤ (blockSupport k r c s).card
  rw [blockSupport_card k r (by omega)]
  exact hr

theorem sparseLeaf_inputs (k r : Nat) (hr : 0 < r) (c : Fin k) (s : Fin 3) :
    (sparseLeaf k r c s).inputs = r := blockSupport_card k r hr c s

theorem sparseLeaf_defects (k r : Nat) (hr : 0 < r) (c : Fin k) (s : Fin 3) :
    (sparseLeaf k r c s).defects = 0 := by
  simp [sparseLeaf, ModularTree.defects, blockSupport_card k r hr, helperResidue_sum, indicator]

def sparseClauseTree (k r : Nat) (c : Fin k) : ModularTree (k * 3 * r) :=
  joinTrees true 2 (fun s => sparseLeaf k r c s)

def sparseTree (k r : Nat) : ModularTree ((k + 1) * 3 * r) :=
  joinTrees false k (fun c => sparseClauseTree (k + 1) r c)

theorem sparseClauseTree_valid (k r : Nat) (hr : 3 ≤ r) (c : Fin k) :
    (sparseClauseTree k r c).Valid 3 := by
  apply joinTrees_valid
  · exact sparseLeaf_valid k r hr c
  · intro s t hst
    exact blockSupport_disjoint k r (by omega) c c s t (Or.inr hst)

theorem sparseClauses_disjoint (k r : Nat) (hr : 0 < r) (c d : Fin k) (hcd : c ≠ d) :
    Disjoint (sparseClauseTree k r c).support (sparseClauseTree k r d).support := by
  apply Finset.disjoint_left.mpr
  intro i hi hj
  obtain ⟨s, hs⟩ := (joinTrees_mem true 2 (fun s => sparseLeaf k r c s) i).mp hi
  obtain ⟨t, ht⟩ := (joinTrees_mem true 2 (fun t => sparseLeaf k r d t) i).mp hj
  exact Finset.disjoint_left.mp (blockSupport_disjoint k r hr c d s t (Or.inl hcd)) hs ht

theorem sparseTree_valid (k r : Nat) (hr : 3 ≤ r) : (sparseTree k r).Valid 3 := by
  apply joinTrees_valid
  · exact sparseClauseTree_valid (k + 1) r hr
  · exact sparseClauses_disjoint (k + 1) r (by omega)

theorem sparseTree_inputs (k r : Nat) (hr : 0 < r) :
    (sparseTree k r).inputs = (k + 1) * 3 * r := by
  simp [sparseTree, sparseClauseTree, joinTrees_inputs, sparseLeaf_inputs _ _ hr, Nat.mul_assoc]

theorem sparseTree_blocks (k r : Nat) : (sparseTree k r).blocks = (k + 1) * 3 := by
  simp [sparseTree, sparseClauseTree, joinTrees_blocks, sparseLeaf, ModularTree.blocks]

theorem sparseTree_defects (k r : Nat) (hr : 0 < r) : (sparseTree k r).defects = 0 := by
  simp [sparseTree, sparseClauseTree, joinTrees_defects, sparseLeaf_defects _ _ hr]

theorem sparseTree_eval (k r : Nat) (hr : 0 < r) (v : Fin ((k + 1) * 3 * r) → Bool) :
    (sparseTree k r).eval v = decide (∀ c : Fin (k + 1), ∃ s : Fin 3,
      helperBlock r (fun b => v (pairIndex (pairIndex c s) b)) = true) := by
  apply Bool.eq_iff_iff.mpr
  simp only [sparseTree, joinTrees_all, sparseClauseTree, joinTrees_any, sparseLeaf_eval _ _ hr,
    decide_eq_true_eq]

end SatLowerBound
