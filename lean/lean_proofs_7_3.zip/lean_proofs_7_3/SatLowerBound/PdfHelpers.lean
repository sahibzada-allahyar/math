import SatLowerBound.SparseFormula

namespace SatLowerBound

theorem binaryValue_highBit (w : Nat) :
    binaryValue (w + 1) (fun i => decide (i.val = w)) = 2 ^ w := by
  induction w with
  | zero => rfl
  | succ w ih =>
      have he : (fun i : Fin (w + 1) => decide (i.succ.val = w + 1)) =
          (fun i => decide (i.val = w)) := by funext i; simp
      rw [binaryValue, he, ih]
      simp [Nat.pow_succ, Nat.mul_comm]

/-- PDF Definition 9.1: the selected identifier is exactly 2^(w-1)+a. -/
theorem suffixIdentifier_value (w r : Nat) (hr : r < w) (x : Fin r → Bool) :
    binaryValue w (suffixIdentifierBits w r x) = 2 ^ (w - 1) + binaryValue r x := by
  induction w generalizing r with
  | zero => omega
  | succ w ih =>
      cases r with
      | zero =>
          have he : suffixIdentifierBits (w + 1) 0 x = fun i => decide (i.val = w) := by
            funext i
            simp [suffixIdentifierBits]
          rw [he, binaryValue_highBit]
          rfl
      | succ r =>
          have he : (fun i : Fin w => suffixIdentifierBits (w + 1) (r + 1) x i.succ) =
              suffixIdentifierBits w r (fun i => x i.succ) := by
            funext i
            simp only [suffixIdentifierBits, Fin.val_succ, Nat.add_lt_add_iff_right]
            split
            · rfl
            · simp
          have h0 : suffixIdentifierBits (w + 1) (r + 1) x 0 = x 0 := by
            simp [suffixIdentifierBits]
          rw [binaryValue, h0, he, ih r (by omega)]
          have hp : 2 ^ w = 2 * 2 ^ (w - 1) := by
            conv_lhs => rw [← Nat.sub_add_cancel (show 1 ≤ w by omega), Nat.pow_succ]
            omega
          simp only [Nat.add_sub_cancel, binaryValue]
          rw [hp]
          omega

/-- The actual helper clauses follow increasing numeric identifier order. -/
theorem helper_identifiers_strictMono (w r : Nat) (hr : r < w) :
    StrictMono (fun i : Fin (forbiddenCount r) =>
      (suffixVariable w r hr (forbiddenSuffix r i)).val + 1) := by
  intro i j hij
  have hpos (k : Fin (forbiddenCount r)) := suffixIdentifier_pos w r hr (forbiddenSuffix r k)
  simp only [suffixVariable]
  rw [Nat.sub_add_cancel (hpos i), Nat.sub_add_cancel (hpos j),
    suffixIdentifier_value w r hr, suffixIdentifier_value w r hr]
  exact Nat.add_lt_add_left (forbiddenSuffix_strictMono r hij) _

end SatLowerBound
