import SatLowerBound.SparseTree
import SatLowerBound.CertificateAssembly

namespace SatLowerBound

theorem weighted_sparse_layout (k r : Nat) (hk : 0 < k) (hr : 3 ≤ r)
    (C : OpenCircuit (k * 3 * r))
    (hc : ∀ v, C.eval v = decide (∀ c : Fin k, ∃ s : Fin 3,
      helperBlock r (fun b => v (pairIndex (pairIndex c s) b)) = true)) :
    6 * (k * 3 * r) ≤ C.weight + 7 * (3 * k) + 2 := by
  obtain ⟨j, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hk)
  have hcomp (v : Fin ((j + 1) * 3 * r) → Bool) : C.eval v = (sparseTree j r).eval v := by
    rw [sparseTree_eval j r (by omega)]
    exact hc v
  have hvalid := sparseTree_valid j r hr
  have h := weighted_modular_composition_algebraic_open (sparseTree j r) hvalid C hcomp
  have hdefects : (sparseTree j r).algebraicDefects = 0 := by
    rw [← (sparseTree j r).defects_eq_algebraicDefects (hvalid.mono (by omega)),
      sparseTree_defects j r (by omega)]
  simpa only [sparseTree_inputs j r (by omega), sparseTree_blocks, hdefects,
    Nat.add_zero, Nat.mul_comm (j + 1) 3] using h

theorem weighted_sparse_bound (w r : Nat) (hr : 3 ≤ r) (hrw : r < w) : WeightedSparseBound w r := by
  intro C hc
  have hk := remainingClauses_pos w r hrw (by omega)
  apply weighted_sparse_layout (remainingClauses w r) r hk hr C
  intro v
  exact hc v

/-- Exact unconditional finite certificate for the stated total binary 3-SAT
encoding, all sixteen binary gates, and shared acyclic circuits. -/
theorem main_lower_bound : ExactCertificate := by
  apply exactCertificate_of_weighted
  intro w r _ hr hrw
  exact weighted_sparse_bound w r hr hrw

end SatLowerBound
