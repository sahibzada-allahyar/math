import SatLowerBound.SixOrSeven

namespace SatLowerBound

def pairPartial {n : Nat} (x y : Fin n) (a b : Bool) : PartialState n :=
  fun i => if i = x then some a else if i = y then some b else none

def pairSubst {n : Nat} (x y : Fin n) (a b : Bool) : Fin n → Signal n :=
  fun i => if i = x then .constant a else if i = y then .constant b else .wire i false

@[simp] theorem setPair_left {n : Nat} (v : Fin n → Bool) (x y : Fin n) (a b : Bool) :
    setPair v x y a b x = a := by simp [setPair]

@[simp] theorem setPair_right {n : Nat} (v : Fin n → Bool) (x y : Fin n) (a b : Bool)
    (hxy : x ≠ y) : setPair v x y a b y = b := by simp [setPair, Ne.symm hxy]

theorem setPair_symm {n : Nat} (v : Fin n → Bool) (x y : Fin n) (a b : Bool) (hxy : x ≠ y) :
    setPair v x y a b = setPair v y x b a := by
  funext k
  by_cases hx : k = x
  · subst k
    simp [setPair, hxy]
  · by_cases hy : k = y
    · subst k; simp [setPair, hx]
    · simp [setPair, hx, hy]

def PairParitySlice {n : Nat} (f : (Fin n → Bool) → Bool) (x y : Fin n) : Prop :=
  ∃ v c, ∀ a b, f (setPair v x y a b) = Bool.xor (Bool.xor a b) c

theorem PairParitySlice.symm {n : Nat} {f : (Fin n → Bool) → Bool} {x y : Fin n}
    (h : PairParitySlice f x y) (hxy : x ≠ y) : PairParitySlice f y x := by
  obtain ⟨v, c, hv⟩ := h
  refine ⟨v, c, ?_⟩
  intro a b
  rw [setPair_symm v y x a b (Ne.symm hxy), hv, Bool.xor_comm b a]

theorem PairParitySlice.essential_left {n : Nat} {f : (Fin n → Bool) → Bool} {x y : Fin n}
    (h : PairParitySlice f x y) (_hxy : x ≠ y) : Essential f x := by
  obtain ⟨v, c, hv⟩ := h
  refine ⟨setPair v x y false false, setPair v x y true false, ?_, ?_⟩
  · intro k hk
    simp [setPair, hk]
  · rw [hv, hv]
    cases c <;> decide

theorem PairParitySlice.essential_right {n : Nat} {f : (Fin n → Bool) → Bool} {x y : Fin n}
    (h : PairParitySlice f x y) (hxy : x ≠ y) : Essential f y :=
  (h.symm hxy).essential_left (Ne.symm hxy)

namespace OpenCircuit

theorem pairPartial_matches {n : Nat} (x y : Fin n) (a b : Bool) :
    PartialMatches (pairPartial x y a b) (pairSubst x y a b) := by
  intro i v hi
  by_cases hx : i = x
  · subst i
    simp only [pairPartial, ↓reduceIte, Option.some.injEq] at hi
    simp [pairSubst, hi]
  · by_cases hy : i = y
    · subst i
      simp only [pairPartial, hx, ↓reduceIte, Option.some.injEq] at hi
      simp [pairSubst, hx, hi]
    · simp [pairPartial, hx, hy] at hi

theorem pairPartial_uses {n : Nat} (C : OpenCircuit n) (x y : Fin n) (a b : Bool) (hxy : x ≠ y) :
    C.markedUses (pairPartial x y a b).mask = C.usage (singleUse x) + C.usage (singleUse y) := by
  rw [← usage_add]
  unfold markedUses
  congr 1
  funext k
  by_cases hx : k = x
  · subst k
    simp [PartialState.mask, pairPartial, singleUse, hxy, indicator]
  · by_cases hy : k = y
    · subst k; simp [PartialState.mask, pairPartial, singleUse, hx, indicator]
    · simp [PartialState.mask, pairPartial, singleUse, hx, hy, indicator]

theorem restrict_pair_eval {n : Nat} (C : OpenCircuit n) (x y : Fin n) (a b : Bool)
    (v : Fin n → Bool) : (C.restrict (pairSubst x y a b)).eval v = C.eval (setPair v x y a b) := by
  rw [restrict_eval]
  congr 1
  funext k
  by_cases hx : k = x
  · simp [pairSubst, setPair, hx, Signal.eval]
  · by_cases hy : k = y
    · subst k; simp [pairSubst, setPair, hx, Signal.eval]
    · simp [pairSubst, setPair, hx, hy, Signal.eval]

theorem pair_deletion_data {n : Nat} (C : OpenCircuit n) (x y : Fin n) (a b : Bool)
    (hxy : x ≠ y) (hr : C.Reduced) (hn : Nonconstant (fun v => C.eval (setPair v x y a b))) :
    (C.restrict (pairSubst x y a b)).weight +
      2 * (C.usage (singleUse x) + C.usage (singleUse y)) +
      2 * C.propagationBirths (pairPartial x y a b) + C.propagationParity (pairPartial x y a b) ≤
      C.weight := by
  have hnon : Nonconstant (C.restrict (pairSubst x y a b)).eval := by
    simpa only [Nonconstant, restrict_pair_eval] using hn
  have hw := C.propagation_weight_gain_nonconstant (pairPartial x y a b) (pairSubst x y a b)
    (pairPartial_matches x y a b) (C.reduced_live hr) (C.reduced_essential hr) hnon
  rwa [pairPartial_uses C x y a b hxy] at hw

/-- Fixing two essential inputs while preserving a nonconstant target costs at
least four units of weight, in the actual residual shared circuit. -/
theorem two_input_retirement {n : Nat} (C : OpenCircuit n) (x y : Fin n) (a b : Bool)
    (hxy : x ≠ y) (hr : C.Reduced) (hx : Essential C.eval x) (hy : Essential C.eval y)
    (hn : Nonconstant (fun v => C.eval (setPair v x y a b))) :
    (C.restrict (pairSubst x y a b)).weight + 4 ≤ C.weight := by
  have hw := C.pair_deletion_data x y a b hxy hr hn
  have hu := C.essential_has_use x hx
  have hv := C.essential_has_use y hy
  omega

end OpenCircuit
end SatLowerBound
