import SatLowerBound.Restriction
import SatLowerBound.Counting

namespace SatLowerBound
namespace OpenCircuit

def appendValue {α : Type} {n : Nat} (x : Fin n → α) (v : α) : Fin (n + 1) → α :=
  fun i => if h : i.val < n then x ⟨i.val, h⟩ else v

theorem appendValue_add {n : Nat} (p q : Fin n → Nat) (a b : Nat) :
    appendValue (fun i => p i + q i) (a + b) =
      (fun i => appendValue p a i + appendValue q b i) := by
  funext i
  unfold appendValue
  split <;> rfl

/-- Weighted count of all references to the initial signals, including output.
Newly created gate signals have initial weight zero. -/
def usage : {n : Nat} → OpenCircuit n → (Fin n → Nat) → Nat
  | _, .output (.constant _), _ => 0
  | _, .output (.wire i _), p => p i
  | _, .gate _ i j rest, p => p i + p j + rest.usage (appendValue p 0)

theorem usage_add {n : Nat} (C : OpenCircuit n) (p q : Fin n → Nat) :
    C.usage (fun i => p i + q i) = C.usage p + C.usage q := by
  induction C with
  | output s => cases s <;> rfl
  | gate g i j rest ih =>
    simp only [usage]
    rw [appendValue_add p q 0 0, ih]
    omega

theorem usage_zero {n : Nat} (C : OpenCircuit n) : C.usage (fun _ => 0) = 0 := by
  have h := C.usage_add (fun _ => 0) (fun _ => 0)
  change C.usage (fun _ => 0) = C.usage (fun _ => 0) + C.usage (fun _ => 0) at h
  omega

def markedUses {n : Nat} (C : OpenCircuit n) (p : Fin n → Bool) : Nat :=
  C.usage (fun i => indicator (p i))

def lastUses {n : Nat} (C : OpenCircuit (n + 1)) : Nat :=
  C.usage (appendValue (fun _ => 0) 1)

theorem markedUses_gate {n : Nat} (g : Table) (i j : Fin n)
    (C : OpenCircuit (n + 1)) (p : Fin n → Bool) :
    (OpenCircuit.gate g i j C).markedUses p =
      indicator (p i) + indicator (p j) + C.markedUses (extend p false) := by
  have h : appendValue (fun i => indicator (p i)) 0 =
      (fun i => indicator (extend p false i)) := by
    funext k
    simp only [appendValue, extend]
    split <;> rfl
  change indicator (p i) + indicator (p j) + C.usage _ =
    indicator (p i) + indicator (p j) + C.usage _
  rw [h]

theorem markedUses_extend_true {n : Nat} (C : OpenCircuit (n + 1)) (p : Fin n → Bool) :
    C.markedUses (extend p true) = C.markedUses (extend p false) + C.lastUses := by
  unfold markedUses lastUses
  rw [← usage_add]
  congr 1
  funext i
  simp only [extend, appendValue]
  split <;> simp [indicator]

/-- Every gate output has at least one later user (possibly the final output). -/
def Live : {n : Nat} → OpenCircuit n → Prop
  | _, .output _ => True
  | _, .gate _ _ _ rest => 0 < rest.lastUses ∧ rest.Live

/-- Two-predecessor closure: a gate becomes marked when both predecessors are marked. -/
def closureOutput : {n : Nat} → OpenCircuit n → (Fin n → Bool) → Bool
  | _, .output (.constant _), _ => true
  | _, .output (.wire i _), p => p i
  | _, .gate _ i j rest, p => rest.closureOutput (extend p (p i && p j))

/-- Closure gates and their boundary gates are counted exactly once. -/
def closureCount : {n : Nat} → OpenCircuit n → (Fin n → Bool) → Nat
  | _, .output _, _ => 0
  | _, .gate _ i j rest, p =>
      indicator (p i || p j) + rest.closureCount (extend p (p i && p j))

/-- The constant-closure edge count, with no disjoint-subcircuit assumption. -/
theorem closureCount_ge_uses {n : Nat} (C : OpenCircuit n) (p : Fin n → Bool)
    (hlive : C.Live) (hout : C.closureOutput p = false) :
    C.markedUses p ≤ C.closureCount p := by
  induction C with
  | output s =>
    cases s with
    | constant b => simp [closureOutput] at hout
    | wire i b =>
      change p i = false at hout
      simp [markedUses, usage, closureCount, indicator, hout]
  | gate g i j rest ih =>
    obtain ⟨hpos, hlive⟩ := hlive
    have hr := ih (extend p (p i && p j)) hlive hout
    rw [markedUses_gate]
    simp only [closureCount]
    cases hi : p i <;> cases hj : p j <;>
      simp only [hi, hj, Bool.false_and, Bool.true_and, Bool.false_or,
        Bool.true_or, indicator, Bool.false_eq_true, ↓reduceIte] at hr ⊢
    · omega
    · omega
    · omega
    · rw [markedUses_extend_true] at hr
      omega

/-- Soundness invariant connecting graph closure to the restriction compiler. -/
def MarksConstants {n m : Nat} (p : Fin n → Bool) (σ : Fin n → Signal m) : Prop :=
  ∀ i, p i = true → ∃ b, σ i = .constant b

theorem marks_extend_alias {n m : Nat} (p : Fin n → Bool) (σ : Fin n → Signal m)
    (hm : MarksConstants p σ) (s : Signal m) (b : Bool)
    (hs : b = true → ∃ v, s = .constant v) :
    MarksConstants (extend p b) (extendSubst σ s) := by
  intro i hi
  simp only [extend, extendSubst] at hi ⊢
  split at hi
  · rename_i h
    simp only [h, ↓reduceDIte]
    exact hm _ hi
  · rename_i h
    simp only [h, ↓reduceDIte]
    exact hs hi

theorem marks_lift {n m : Nat} (p : Fin n → Bool) (σ : Fin n → Signal m)
    (hm : MarksConstants p σ) : MarksConstants (extend p false) (liftSubst σ) := by
  apply marks_extend_alias
  · intro i hi
    rcases hm i hi with ⟨b, hb⟩
    exact ⟨b, by simp [hb, Signal.rename]⟩
  · intro h
    contradiction

theorem simplifyGate_binary_unmarked {n m : Nat} (p : Fin n → Bool)
    (σ : Fin n → Signal m) (hm : MarksConstants p σ)
    (g h : Table) (i j : Fin n) (k l : Fin m)
    (hs : simplifyGate g (σ i) (σ j) = .binary h k l) :
    p i = false ∧ p j = false := by
  constructor
  · cases hi : p i
    · rfl
    · rcases hm i hi with ⟨b, hb⟩
      rw [hb] at hs
      cases hj : σ j <;> simp [simplifyGate, hj] at hs
  · cases hj : p j
    · rfl
    · rcases hm j hj with ⟨b, hb⟩
      rw [hb] at hs
      cases hi : σ i <;> simp [simplifyGate, hi] at hs

theorem simplifyGate_alias_marked {n m : Nat} (p : Fin n → Bool)
    (σ : Fin n → Signal m) (hm : MarksConstants p σ)
    (g : Table) (i j : Fin n) (s : Signal m)
    (hs : simplifyGate g (σ i) (σ j) = .alias s) :
    (p i && p j) = true → ∃ b, s = .constant b := by
  intro h
  have hi : p i = true := by cases hh : p i <;> simp_all
  have hj : p j = true := by cases hh : p j <;> simp_all
  rcases hm i hi with ⟨a, ha⟩
  rcases hm j hj with ⟨b, hb⟩
  rw [ha, hb] at hs
  simp only [simplifyGate, GateStep.alias.injEq] at hs
  exact ⟨g.eval a b, hs.symm⟩

/-- An actual residual circuit loses at least the certified closure count. -/
theorem restrict_size_closure {n m : Nat} (C : OpenCircuit n)
    (p : Fin n → Bool) (σ : Fin n → Signal m) (hm : MarksConstants p σ) :
    (C.restrict σ).size + C.closureCount p ≤ C.size := by
  induction C generalizing m with
  | output => exact Nat.le_refl 0
  | gate g i j rest ih =>
    simp only [restrict]
    split
    · rename_i s hs
      have hmark := marks_extend_alias p σ hm s (p i && p j)
        (simplifyGate_alias_marked p σ hm g i j s hs)
      have hr := ih _ _ hmark
      simp only [size, closureCount]
      have hb : indicator (p i || p j) ≤ 1 := by unfold indicator; split <;> decide
      omega
    · rename_i h k l hs
      obtain ⟨hi, hj⟩ := simplifyGate_binary_unmarked p σ hm g h i j k l hs
      have hr := ih (extend p false) (liftSubst σ) (marks_lift p σ hm)
      simp only [size, closureCount, hi, hj, Bool.false_or, Bool.false_and,
        indicator, Bool.false_eq_true, ↓reduceIte]
      omega

def EssentialGates : {n : Nat} → OpenCircuit n → Prop
  | _, .output _ => True
  | _, .gate g _ _ rest => g.essential = true ∧ rest.EssentialGates

theorem restrict_weight_closure {n m : Nat} (C : OpenCircuit n)
    (p : Fin n → Bool) (σ : Fin n → Signal m) (hm : MarksConstants p σ)
    (he : C.EssentialGates) :
    (C.restrict σ).weight + 2 * C.closureCount p ≤ C.weight := by
  induction C generalizing m with
  | output => exact Nat.le_refl 0
  | gate g i j rest ih =>
    obtain ⟨hg, he⟩ := he
    simp only [restrict]
    split
    · rename_i s hs
      have hmark := marks_extend_alias p σ hm s (p i && p j)
        (simplifyGate_alias_marked p σ hm g i j s hs)
      have hr := ih _ _ hmark he
      have hw := g.essential_weight hg
      have hb : indicator (p i || p j) ≤ 1 := by unfold indicator; split <;> decide
      simp only [weight, closureCount]
      omega
    · rename_i h k l hs
      obtain ⟨hi, hj⟩ := simplifyGate_binary_unmarked p σ hm g h i j k l hs
      have hr := ih (extend p false) (liftSubst σ) (marks_lift p σ hm) he
      have hw := simplifyGate_weight g (σ i) (σ j)
      rw [hs] at hw
      change h.weight ≤ g.weight at hw
      simp only [weight, closureCount, hi, hj, Bool.false_or, Bool.false_and,
        indicator, Bool.false_eq_true, ↓reduceIte]
      omega

theorem constant_closure_deletion {n m : Nat} (C : OpenCircuit n)
    (p : Fin n → Bool) (σ : Fin n → Signal m)
    (hm : MarksConstants p σ) (hl : C.Live) (ho : C.closureOutput p = false) :
    (C.restrict σ).size + C.markedUses p ≤ C.size :=
  Nat.le_trans (Nat.add_le_add_left (closureCount_ge_uses C p hl ho) _)
    (restrict_size_closure C p σ hm)

theorem constant_closure_weight {n m : Nat} (C : OpenCircuit n)
    (p : Fin n → Bool) (σ : Fin n → Signal m)
    (hm : MarksConstants p σ) (hl : C.Live) (ho : C.closureOutput p = false)
    (he : C.EssentialGates) :
    (C.restrict σ).weight + 2 * C.markedUses p ≤ C.weight :=
  Nat.le_trans (Nat.add_le_add_left (Nat.mul_le_mul_left 2 (closureCount_ge_uses C p hl ho)) _)
    (restrict_weight_closure C p σ hm he)

end OpenCircuit
end SatLowerBound
