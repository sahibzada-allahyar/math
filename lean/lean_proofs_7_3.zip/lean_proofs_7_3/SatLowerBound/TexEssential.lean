import SatLowerBound.EncodingEssential
import SatLowerBound.Formula

namespace SatLowerBound

theorem two_other_clauses {m : Nat} (hm : 3 ≤ m) (c : Fin m) :
    ∃ d e : Fin m, d ≠ c ∧ e ≠ c ∧ e ≠ d := by
  classical
  obtain ⟨d, _, hd⟩ := Finset.exists_mem_notMem_of_card_lt_card
    (show ({c} : Finset (Fin m)).card < (Finset.univ : Finset (Fin m)).card by simp; omega)
  have hdc : d ≠ c := by simpa using hd
  obtain ⟨e, _, he⟩ := Finset.exists_mem_notMem_of_card_lt_card
    (show ({c, d} : Finset (Fin m)).card < (Finset.univ : Finset (Fin m)).card by
      simp [Ne.symm hdc]; omega)
  exact ⟨d, e, hdc, by simpa using he⟩

theorem encoded_sign_change (w : Nat) (f g : Formula (variableCount w))
    (c : Fin (clauseCount w)) (s : Fin 3)
    (hv : ∀ d t, (f d t).varIndex = (g d t).varIndex)
    (hn : ∀ d t, d ≠ c ∨ t ≠ s → (f d t).negated = (g d t).negated) :
    ∀ i, i ≠ coordinate w c s (Fin.last w) → encodeFormula w f i = encodeFormula w g i := by
  apply encoded_agree_except
  intro d t b hb
  split
  · rw [hv]
  · rename_i h
    have hbw : b = Fin.last w := Fin.ext (by have := b.isLt; simp only [Fin.val_last]; omega)
    apply hn
    by_cases hd : d = c
    · right
      intro ht
      exact hb (by rw [hd, ht, hbw])
    · exact Or.inl hd

/-- Exactly the sign witness in the TeX: X2 in the selected slot, X1 companions,
two negative units, and tautologies in all other records. -/
def texSignFormula (m : Nat) (hm : 3 ≤ m) (c d e : Fin m) (s : Fin 3)
    (flip : Bool) : Formula m := fun q t =>
  if q = c then
    if t = s then ⟨⟨1, by omega⟩, flip⟩ else ⟨⟨0, by omega⟩, false⟩
  else if q = d then ⟨⟨0, by omega⟩, true⟩
  else if q = e then ⟨⟨1, by omega⟩, true⟩
  else ⟨⟨0, by omega⟩, decide (t = 1)⟩

theorem texSignFormula_unsat (m : Nat) (hm : 3 ≤ m) (c d e : Fin m) (s : Fin 3)
    (hdc : d ≠ c) (hec : e ≠ c) (hed : e ≠ d) :
    ¬ (texSignFormula m hm c d e s false).SAT := by
  rintro ⟨a, ha⟩
  obtain ⟨u, hu⟩ := ha d
  obtain ⟨v, hv⟩ := ha e
  have h0 : a ⟨0, by omega⟩ = false := by
    simpa [texSignFormula, hdc, Literal.eval] using hu
  have h1 : a ⟨1, by omega⟩ = false := by
    simpa [texSignFormula, hec, hed, Literal.eval] using hv
  obtain ⟨t, ht⟩ := ha c
  by_cases hts : t = s <;> simp [texSignFormula, hts, Literal.eval, h0, h1] at ht

theorem texSignFormula_sat (m : Nat) (hm : 3 ≤ m) (c d e : Fin m) (s : Fin 3) :
    (texSignFormula m hm c d e s true).SAT := by
  refine ⟨fun _ => false, ?_⟩
  intro q
  by_cases hq : q = c
  · refine ⟨s, ?_⟩
    simp [texSignFormula, hq, Literal.eval]
  · refine ⟨1, ?_⟩
    simp only [texSignFormula, ite_eq_right hq]
    split
    · rfl
    · split <;> rfl

theorem tex_sign_bit_essential (w : Nat) (hm : 3 ≤ variableCount w)
    (c : Fin (clauseCount w)) (s : Fin 3) :
    Essential (satFunction w) (coordinate w c s (Fin.last w)) := by
  obtain ⟨d, e, hdc, hec, hed⟩ := two_other_clauses hm c
  let f := texSignFormula (variableCount w) hm c d e s false
  let g := texSignFormula (variableCount w) hm c d e s true
  have hf : satFunction w (encodeFormula w f) = false := by
    have hn := texSignFormula_unsat _ hm c d e s hdc hec hed
    cases h : satFunction w (encodeFormula w f)
    · rfl
    · exact False.elim (hn ((encodeFormula_correct w f).mp h))
  have hg : satFunction w (encodeFormula w g) = true :=
    (encodeFormula_correct w g).mpr (texSignFormula_sat _ hm c d e s)
  refine ⟨encodeFormula w f, encodeFormula w g, ?_, by rw [hf, hg]; decide⟩
  apply encoded_sign_change
  · intro q t
    dsimp [f, g, texSignFormula]
    split
    · split <;> rfl
    · rfl
  · intro q t hqt
    rcases hqt with hq | ht
    · simp [f, g, texSignFormula, hq]
    · simp [f, g, texSignFormula, ht]

theorem binaryValue_all_true (w : Nat) : binaryValue w (fun _ => true) = 2 ^ w - 1 := by
  induction w with
  | zero => rfl
  | succ w ih =>
      simp only [binaryValue, ↓reduceIte, ih, Nat.pow_succ]
      have hp := Nat.two_pow_pos w
      omega

theorem binaryValue_drop_bit (w : Nat) (j : Fin w) :
    binaryValue w (fun i => decide (i ≠ j)) + 2 ^ j.val = 2 ^ w - 1 := by
  induction w with
  | zero => exact Fin.elim0 j
  | succ w ih =>
      induction j using Fin.cases with
      | zero =>
          have he : (fun i : Fin w => decide (i.succ ≠ 0)) = fun _ => true := by simp
          simp only [binaryValue, ne_eq, not_true_eq_false, decide_false, Bool.false_eq_true,
            ↓reduceIte, he, binaryValue_all_true, Fin.val_zero, pow_zero, Nat.pow_succ]
          have hp := Nat.two_pow_pos w


          omega
      | succ j =>
          have he : (fun i : Fin w => decide (i.succ ≠ j.succ)) = fun i => decide (i ≠ j) := by simp
          have h := ih j
          simp only [ne_eq] at h
          have hz : (0 : Fin (w + 1)) ≠ j.succ := Ne.symm (Fin.succ_ne_zero j)
          simp only [binaryValue, ne_eq, hz,
            not_false_eq_true, decide_true, ↓reduceIte, he, Fin.val_succ, Nat.pow_succ]
          have hp := Nat.two_pow_pos w

          omega

theorem tex_identifier_value (w : Nat) (j : Fin w) :
    binaryValue w (fun i => decide (i ≠ j)) = variableCount w - 2 ^ j.val := by
  have h := binaryValue_drop_bit w j
  exact Nat.eq_sub_of_add_eq h

/-- The identifier witness uses Xm, the negative unit for Xm, and tautologies. -/
def texIdFormula {m : Nat} (hm : 0 < m) (c d : Fin m) (s : Fin 3)
    (old new : Fin m) (flip : Bool) : Formula m := fun q t =>
  if q = c then ⟨if t = s ∧ flip = true then new else old, false⟩
  else if q = d then ⟨old, true⟩
  else ⟨⟨0, hm⟩, decide (t = 1)⟩

theorem texIdFormula_unsat {m : Nat} (hm : 0 < m) (c d : Fin m) (s : Fin 3)
    (old new : Fin m) (hdc : d ≠ c) : ¬ (texIdFormula hm c d s old new false).SAT := by
  rintro ⟨a, ha⟩
  obtain ⟨u, hu⟩ := ha d
  obtain ⟨v, hv⟩ := ha c
  have h0 : a old = false := by simpa [texIdFormula, hdc, Literal.eval] using hu
  simp [texIdFormula, Literal.eval, h0] at hv

theorem texIdFormula_sat {m : Nat} (hm : 0 < m) (c d : Fin m) (s : Fin 3)
    (old new : Fin m) (hne : new ≠ old) : (texIdFormula hm c d s old new true).SAT := by
  refine ⟨fun v => decide (v ≠ old), ?_⟩
  intro q
  by_cases hc : q = c
  · exact ⟨s, by simp [texIdFormula, hc, Literal.eval, hne]⟩
  · by_cases hd : q = d
    · refine ⟨0, ?_⟩
      simp only [texIdFormula, ite_eq_right hc, ite_eq_left hd, Literal.eval]
      simp
    · by_cases h0 : (⟨0, hm⟩ : Fin m) = old
      · exact ⟨1, by simp [texIdFormula, hc, hd, Literal.eval, h0]⟩
      · exact ⟨0, by simp [texIdFormula, hc, hd, Literal.eval, h0]⟩

/-- Both encodings are valid, and differ only in the chosen identifier bit,
exactly as in the manuscript's Xm versus Xm-2^j construction. -/
theorem tex_identifier_bit_essential (w : Nat) (hw : 2 ≤ w)
    (c : Fin (clauseCount w)) (s : Fin 3) (j : Fin w) :
    Essential (satFunction w) (coordinate w c s j.castSucc) := by
  have hm : 3 ≤ variableCount w := by
    have hp := Nat.pow_le_pow_right (n := 2) (by decide) hw
    unfold variableCount
    omega
  have hm0 : 0 < variableCount w := by omega
  obtain ⟨d, _, hdc, _, _⟩ := two_other_clauses hm c
  let bits : Fin w → Bool := fun b => decide (b ≠ j)
  let other : Fin w := if j.val = 0 then ⟨1, by omega⟩ else ⟨0, by omega⟩
  have hother : other ≠ j := by
    intro he
    have hv := congrArg Fin.val he
    dsimp [other] at hv
    split at hv
    · change 1 = j.val at hv
      omega
    · change 0 = j.val at hv
      omega
  have hpos : 0 < binaryValue w bits := binaryValue_pos_of_bit w bits other (by simp [bits, hother])
  let old : Fin (variableCount w) := ⟨variableCount w - 1, by omega⟩
  let new : Fin (variableCount w) := ⟨binaryValue w bits - 1, by
    have hp := binaryValue_lt w bits
    unfold variableCount
    omega⟩
  have hold : old.val + 1 = variableCount w := Nat.sub_add_cancel hm0
  have hnew : new.val + 1 = binaryValue w bits := Nat.sub_add_cancel hpos
  have hne : new ≠ old := by
    intro he
    have hv : binaryValue w bits = binaryValue w (fun _ => true) := by
      rw [binaryValue_all_true]
      change binaryValue w bits = variableCount w
      rw [← hnew, he, hold]
    have hh := congrFun (binaryValue_injective w _ _ hv) j
    simp [bits] at hh
  have holdbits : binaryDigits w (old.val + 1) = (fun _ => true) := by
    rw [hold]
    change binaryDigits w (2 ^ w - 1) = _
    rw [← binaryValue_all_true, binaryDigits_value]
  have hnewbits : binaryDigits w (new.val + 1) = bits := by
    rw [hnew, binaryDigits_value]
  let f := texIdFormula hm0 c d s old new false
  let g := texIdFormula hm0 c d s old new true
  have hf : satFunction w (encodeFormula w f) = false := by
    cases h : satFunction w (encodeFormula w f)
    · rfl
    · exact False.elim (texIdFormula_unsat hm0 c d s old new hdc ((encodeFormula_correct w f).mp h))
  have hg : satFunction w (encodeFormula w g) = true :=
    (encodeFormula_correct w g).mpr (texIdFormula_sat hm0 c d s old new hne)
  refine ⟨encodeFormula w f, encodeFormula w g, ?_, by rw [hf, hg]; decide⟩
  apply encoded_agree_except
  intro q t b hb
  split
  · rename_i hbw
    by_cases hq : q = c
    · by_cases ht : t = s
      · have hj : (⟨b.val, hbw⟩ : Fin w) ≠ j := by
          intro he
          have hv : b.val = j.val := congrArg (fun k : Fin w => k.val) he
          have he' : b = j.castSucc := Fin.ext hv
          exact hb (by rw [hq, ht, he'])
        simp [f, g, texIdFormula, hq, ht, holdbits, hnewbits, bits, hj]
      · simp [f, g, texIdFormula, hq, ht]
    · simp [f, g, texIdFormula, hq]
  · by_cases hq : q = c <;> simp [f, g, texIdFormula, hq]

theorem tex_every_encoding_bit_essential (w : Nat) (hw : 2 ≤ w) :
    ∀ i : Fin (inputBits w), Essential (satFunction w) i := by
  have hm : 3 ≤ variableCount w := by
    have hp := Nat.pow_le_pow_right (n := 2) (by decide) hw
    unfold variableCount
    omega
  intro i
  obtain ⟨c, s, b, rfl⟩ := coordinate_surjective w i
  by_cases hb : b.val < w
  · have he : b = (⟨b.val, hb⟩ : Fin w).castSucc := rfl
    rw [he]
    exact tex_identifier_bit_essential w hw c s _
  · have he : b = Fin.last w := Fin.ext (by have := b.isLt; simp only [Fin.val_last]; omega)
    rw [he]
    exact tex_sign_bit_essential w hm c s

end SatLowerBound
