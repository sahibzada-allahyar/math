import SatLowerBound.ModularBlocks
import SatLowerBound.SatTransfer

namespace SatLowerBound

def Supported {n : Nat} (f : (Fin n → Bool) → Bool) (S : Finset (Fin n)) : Prop :=
  ∀ u v, (∀ i ∈ S, u i = v i) → f u = f v

def patchValues {n : Nat} (S : Finset (Fin n)) (u v : Fin n → Bool) : Fin n → Bool :=
  fun i => if i ∈ S then u i else v i

theorem Supported.patch_left {n : Nat} {f : (Fin n → Bool) → Bool} {S : Finset (Fin n)}
    (h : Supported f S) (u v : Fin n → Bool) : f (patchValues S u v) = f u := by
  apply h
  intro i hi
  simp [patchValues, hi]

theorem Supported.patch_right {n : Nat} {f : (Fin n → Bool) → Bool} {S T : Finset (Fin n)}
    (h : Supported f T) (hd : Disjoint S T) (u v : Fin n → Bool) : f (patchValues S u v) = f v := by
  apply h
  intro i hi
  have hn : i ∉ S := fun hs => Finset.disjoint_left.mp hd hs hi
  simp [patchValues, hn]

theorem Supported.cofactor {n : Nat} {f : (Fin n → Bool) → Bool} {S : Finset (Fin n)}
    (h : Supported f S) (x : Fin n) (b : Bool) : Supported (fun v => f (fixBit x b v)) S := by
  intro u v huv
  apply h
  intro i hi
  by_cases hx : i = x <;> simp [fixBit, hx, huv i hi]

theorem Supported.fixBit_outside {n : Nat} {f : (Fin n → Bool) → Bool} {S : Finset (Fin n)}
    (h : Supported f S) (x : Fin n) (hx : x ∉ S) (b : Bool) (v : Fin n → Bool) :
    f (fixBit x b v) = f v := by
  apply h
  intro i hi
  have hix : i ≠ x := fun he => hx (he ▸ hi)
  simp [fixBit, hix]

theorem Supported.essential_mem {n : Nat} {f : (Fin n → Bool) → Bool} {S : Finset (Fin n)}
    (h : Supported f S) (x : Fin n) (hx : Essential f x) : x ∈ S := by
  by_contra hnot
  obtain ⟨u, v, huv, hne⟩ := hx
  exact hne (h u v (fun i hi => huv i (fun he => hnot (he ▸ hi))))

theorem modularBlock_supported {n : Nat} (S : Finset (Fin n)) (t : Fin 3) (c : Bool) :
    Supported (modularBlock S t c) S := by
  intro u v huv
  simp only [modularBlock, tally_congr S u v huv]

def combine (isOr a b : Bool) : Bool := if isOr then a || b else a && b

theorem combine_comm (p a b : Bool) : combine p a b = combine p b a := by
  cases p <;> cases a <;> cases b <;> rfl

@[simp] theorem combine_neutral (p a : Bool) : combine p a (!p) = a := by
  cases p <;> cases a <;> rfl

@[simp] theorem combine_same (p a : Bool) : combine p a a = a := by
  cases p <;> cases a <;> rfl

theorem supported_combine {n : Nat} (p : Bool) (f g : (Fin n → Bool) → Bool)
    (S T : Finset (Fin n)) (hf : Supported f S) (hg : Supported g T) :
    Supported (fun v => combine p (f v) (g v)) (S ∪ T) := by
  intro u v huv
  change combine p (f u) (g u) = combine p (f v) (g v)
  rw [hf u v (fun i hi => huv i (Finset.mem_union_left _ hi)),
    hg u v (fun i hi => huv i (Finset.mem_union_right _ hi))]

theorem Nonconstant.has_value {n : Nat} {f : (Fin n → Bool) → Bool} (h : Nonconstant f) (b : Bool) :
    ∃ v, f v = b := by
  cases b
  · exact (nonconstant_values f h).1
  · exact (nonconstant_values f h).2

theorem combine_nonconstant {n : Nat} (p : Bool) (f g : (Fin n → Bool) → Bool)
    (S T : Finset (Fin n)) (hf : Supported f S) (hg : Supported g T) (hd : Disjoint S T)
    (hfn : Nonconstant f) (hgn : Nonconstant g) : Nonconstant (fun v => combine p (f v) (g v)) := by
  obtain ⟨u0, hu0⟩ := hfn.has_value false
  obtain ⟨u1, hu1⟩ := hfn.has_value true
  obtain ⟨v0, hv0⟩ := hgn.has_value false
  obtain ⟨v1, hv1⟩ := hgn.has_value true
  refine ⟨patchValues S u0 v0, patchValues S u1 v1, ?_⟩
  simp only [hf.patch_left, hg.patch_right hd, hu0, hu1, hv0, hv1, combine_same]
  decide

theorem combine_essential_left {n : Nat} (p : Bool) (f g : (Fin n → Bool) → Bool)
    (S T : Finset (Fin n)) (hf : Supported f S) (hg : Supported g T) (hd : Disjoint S T)
    (hgn : Nonconstant g) (x : Fin n) (he : Essential f x) :
    Essential (fun v => combine p (f v) (g v)) x := by
  obtain ⟨u, v, huv, hne⟩ := he
  obtain ⟨z, hz⟩ := hgn.has_value (!p)
  refine ⟨patchValues S u z, patchValues S v z, ?_, ?_⟩
  · intro i hi
    by_cases hs : i ∈ S <;> simp [patchValues, hs, huv i hi]
  · simpa only [hf.patch_left, hg.patch_right hd, hz, combine_neutral] using hne

theorem combine_essential_right {n : Nat} (p : Bool) (f g : (Fin n → Bool) → Bool)
    (S T : Finset (Fin n)) (hf : Supported f S) (hg : Supported g T) (hd : Disjoint S T)
    (hfn : Nonconstant f) (x : Fin n) (he : Essential g x) :
    Essential (fun v => combine p (f v) (g v)) x := by
  have h := combine_essential_left p g f T S hg hf hd.symm hfn x he
  simpa only [combine_comm p (g _) (f _)] using h

theorem essential_cofactors_distinct {n : Nat} (f : (Fin n → Bool) → Bool) (x : Fin n)
    (hx : Essential f x) : (fun v => f (fixBit x false v)) ≠ (fun v => f (fixBit x true v)) := by
  intro he
  obtain ⟨u, v, huv, hne⟩ := hx
  have same : fixBit x false u = fixBit x false v := by
    funext i
    by_cases hi : i = x
    · simp [fixBit, hi]
    · simp [fixBit, hi, huv i hi]
  have fixed (z : Fin n → Bool) : f z = f (fixBit x false z) := by
    have hid : fixBit x (z x) z = z := by
      funext i
      by_cases hi : i = x <;> simp [fixBit, hi]
    cases hz : z x
    · rw [hz] at hid
      rw [hid]
    · rw [hz] at hid
      rw [congrFun he z, hid]
  exact hne ((fixed u).trans ((congrArg f same).trans (fixed v).symm))

end SatLowerBound
