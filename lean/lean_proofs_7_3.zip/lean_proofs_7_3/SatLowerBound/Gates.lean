import Std

namespace SatLowerBound

/-- The full B₂ basis: all sixteen two-input Boolean truth tables. -/
structure Table where
  ff : Bool
  ft : Bool
  tf : Bool
  tt : Bool
  deriving DecidableEq, Repr

namespace Table

def eval (g : Table) (a b : Bool) : Bool :=
  match a, b with
  | false, false => g.ff
  | false, true => g.ft
  | true, false => g.tf
  | true, true => g.tt

def ofFunction (f : Bool → Bool → Bool) : Table :=
  ⟨f false false, f false true, f true false, f true true⟩

theorem eval_ofFunction (f : Bool → Bool → Bool) (a b : Bool) :
    (ofFunction f).eval a b = f a b := by cases a <;> cases b <;> rfl

def essential (g : Table) : Bool :=
  ((g.ff != g.tf) || (g.ft != g.tt)) && ((g.ff != g.ft) || (g.tf != g.tt))

def parity (g : Table) : Bool :=
  (g.ff == g.tt) && (g.ft == g.tf) && (g.ff != g.ft)

def nonlinear (g : Table) : Bool := g.essential && !g.parity

def weight (g : Table) : Nat :=
  if g.essential then if g.parity then 3 else 2 else 0

def nonlinearCount (g : Table) : Nat := if g.nonlinear then 1 else 0

def parityCount (g : Table) : Nat := if g.parity then 1 else 0

theorem weight_eq (g : Table) :
    g.weight = 3 * g.parityCount + 2 * g.nonlinearCount := by
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem resource_le (g : Table) : g.weight + g.nonlinearCount ≤ 3 := by
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem essential_weight (g : Table) (h : g.essential = true) : 2 ≤ g.weight := by
  simp only [weight, h, ↓reduceIte]
  split <;> decide

theorem essential_iff (g : Table) : g.essential = true ↔
    (∃ b, g.eval false b ≠ g.eval true b) ∧
    (∃ a, g.eval a false ≠ g.eval a true) := by
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem parity_iff (g : Table) : g.parity = true ↔
    ∃ c : Bool, ∀ a b : Bool, g.eval a b = Bool.xor (Bool.xor a b) c := by
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem nonlinear_blocks_left (g : Table) (h : g.nonlinear = true) :
    ∃ a : Bool, ∀ b : Bool, g.eval a b = g.eval a false := by
  revert h
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem nonlinear_blocks_right (g : Table) (h : g.nonlinear = true) :
    ∃ b : Bool, ∀ a : Bool, g.eval a b = g.eval false b := by
  revert h
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

def complement (g : Table) : Table := ofFunction (fun a b => !(g.eval a b))

theorem complement_weight (g : Table) : g.complement.weight = g.weight := by
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

/-- The local input-triangle rewrite q(x,p(x,y)). -/
def triangle (p q : Table) : Table := ofFunction (fun x y => q.eval x (p.eval x y))

theorem triangle_eval (p q : Table) (x y : Bool) :
    (triangle p q).eval x y = q.eval x (p.eval x y) := eval_ofFunction _ _ _

set_option maxRecDepth 4096 in
theorem triangle_weight (p q : Table) (hq : q.essential = true) :
    (triangle p q).weight ≤ q.weight := by
  revert hq
  rcases p with ⟨a, b, c, d⟩
  rcases q with ⟨e, f, g, h⟩
  cases a <;> cases b <;> cases c <;> cases d <;>
    cases e <;> cases f <;> cases g <;> cases h <;> decide

end Table
end SatLowerBound
