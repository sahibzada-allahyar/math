import Std

/-! The exact total binary encoding used by the manuscript.
There are m clauses AND m propositional variables, where m = 2^w - 1.
Only the n = 3*m*(w+1) encoding bits are circuit inputs.
-/
namespace SatLowerBound

def variableCount (w : Nat) : Nat := 2 ^ w - 1

abbrev clauseCount (w : Nat) : Nat := variableCount w

def inputBits (w : Nat) : Nat := 3 * variableCount w * (w + 1)

abbrev Input (w : Nat) := Fin (inputBits w) → Bool
abbrev Assignment (w : Nat) := Fin (variableCount w) → Bool

theorem clauses_eq_variables (w : Nat) : clauseCount w = variableCount w := rfl

theorem inputBits_eq (w : Nat) :
    inputBits w = 3 * (2 ^ w - 1) * (w + 1) := rfl

/-- Row-major packing; no coordinate is reduced modulo the input length. -/
def pairIndex {a b : Nat} (i : Fin a) (j : Fin b) : Fin (a * b) :=
  ⟨i.val * b + j.val, by
    calc
      i.val * b + j.val < i.val * b + b := Nat.add_lt_add_left j.isLt _
      _ = (i.val + 1) * b := (Nat.succ_mul i.val b).symm
      _ ≤ a * b := Nat.mul_le_mul_right b (Nat.succ_le_of_lt i.isLt)⟩

/-- Clause, literal slot, then bit position. The sign occupies position w. -/
def coordinate (w : Nat) (c : Fin (clauseCount w)) (s : Fin 3)
    (b : Fin (w + 1)) : Fin (inputBits w) :=
  let i := pairIndex (pairIndex c s) b
  ⟨i.val, by
    have hi := i.isLt
    simp [inputBits, clauseCount, Nat.mul_comm 3 (variableCount w)]⟩

def unpairIndex {a b : Nat} (h : 0 < b) (i : Fin (a * b)) : Fin a × Fin b :=
  (⟨i.val / b, (Nat.div_lt_iff_lt_mul h).mpr i.isLt⟩,
   ⟨i.val % b, Nat.mod_lt _ h⟩)

theorem unpair_pair {a b : Nat} (h : 0 < b) (i : Fin a) (j : Fin b) :
    unpairIndex h (pairIndex i j) = (i, j) := by
  apply Prod.ext
  · apply Fin.ext
    simp [unpairIndex, pairIndex, Nat.mul_comm i.val b,
      Nat.mul_add_div h, Nat.div_eq_of_lt j.isLt]
  · apply Fin.ext
    simp [unpairIndex, pairIndex, Nat.mod_eq_of_lt j.isLt]

theorem pair_unpair {a b : Nat} (h : 0 < b) (i : Fin (a * b)) :
    pairIndex (unpairIndex h i).1 (unpairIndex h i).2 = i := by
  apply Fin.ext
  exact Nat.div_add_mod' i.val b

abbrev StructuredInput (w : Nat) :=
  Fin (clauseCount w) → Fin 3 → Fin (w + 1) → Bool

def decodeBits (w : Nat) (x : Input w) : StructuredInput w :=
  fun c s b => x (coordinate w c s b)

def encodeBits (w : Nat) (x : StructuredInput w) : Input w := fun i =>
  let i' : Fin ((clauseCount w * 3) * (w + 1)) :=
    ⟨i.val, by simpa [inputBits, clauseCount, Nat.mul_comm 3 (variableCount w)] using i.isLt⟩
  let a := unpairIndex (Nat.zero_lt_succ w) i'
  let cs := unpairIndex (by decide : 0 < 3) a.1
  x cs.1 cs.2 a.2

theorem decode_encode (w : Nat) (x : StructuredInput w) :
    decodeBits w (encodeBits w x) = x := by
  funext c s b
  change x (unpairIndex (by decide : 0 < 3)
    (unpairIndex (Nat.zero_lt_succ w) (pairIndex (pairIndex c s) b)).1).1
    (unpairIndex (by decide : 0 < 3)
    (unpairIndex (Nat.zero_lt_succ w) (pairIndex (pairIndex c s) b)).1).2
    (unpairIndex (Nat.zero_lt_succ w) (pairIndex (pairIndex c s) b)).2 = x c s b
  rw [unpair_pair, unpair_pair]

@[simp] theorem encode_coordinate (w : Nat) (x : StructuredInput w)
    (c : Fin (clauseCount w)) (s : Fin 3) (b : Fin (w + 1)) :
    encodeBits w x (coordinate w c s b) = x c s b :=
  congrFun (congrFun (congrFun (decode_encode w x) c) s) b

theorem encode_decode (w : Nat) (x : Input w) :
    encodeBits w (decodeBits w x) = x := by
  funext i
  unfold encodeBits decodeBits coordinate
  dsimp
  congr 1
  apply Fin.ext
  dsimp [pairIndex, unpairIndex]
  rw [Nat.div_add_mod', Nat.div_add_mod']

theorem coordinate_injective (w : Nat)
    (c d : Fin (clauseCount w)) (s t : Fin 3) (b e : Fin (w + 1))
    (h : coordinate w c s b = coordinate w d t e) : c = d ∧ s = t ∧ b = e := by
  have hv := congrArg (fun i : Fin (inputBits w) => i.val) h
  have h' : pairIndex (pairIndex c s) b = pairIndex (pairIndex d t) e :=
    Fin.ext hv
  have hu := congrArg (unpairIndex (Nat.zero_lt_succ w)) h'
  rw [unpair_pair, unpair_pair] at hu
  have hb := congrArg Prod.snd hu
  have hc := congrArg (unpairIndex (by decide : 0 < 3)) (congrArg Prod.fst hu)
  rw [unpair_pair, unpair_pair] at hc
  exact ⟨congrArg Prod.fst hc, congrArg Prod.snd hc, hb⟩

/-- Little-endian binary interpretation, defined structurally on the width. -/
def binaryValue : (w : Nat) → (Fin w → Bool) → Nat
  | 0, _ => 0
  | w + 1, bits =>
      (if bits 0 then 1 else 0) + 2 * binaryValue w (fun i => bits i.succ)

theorem binaryValue_lt (w : Nat) (bits : Fin w → Bool) :
    binaryValue w bits < 2 ^ w := by
  induction w with
  | zero => simp [binaryValue]
  | succ w ih =>
    have h := ih (fun i => bits i.succ)
    simp only [binaryValue, Nat.pow_succ]
    split <;> omega

@[simp] theorem binaryValue_zero (w : Nat) : binaryValue w (fun _ => false) = 0 := by
  induction w with
  | zero => rfl
  | succ w ih => simp [binaryValue, ih]

theorem binaryValue_one (w : Nat) (hw : 0 < w) :
    binaryValue w (fun b => decide (b.val = 0)) = 1 := by
  cases w with
  | zero => omega
  | succ w => simp [binaryValue]

/-- The inverse little-endian encoder, using exactly w bits. -/
def binaryDigits : (w : Nat) → Nat → Fin w → Bool
  | 0, _ => fun i => Fin.elim0 i
  | w + 1, v => Fin.cases (decide (v % 2 = 1)) (binaryDigits w (v / 2))

theorem binaryValue_digits (w v : Nat) (hv : v < 2 ^ w) :
    binaryValue w (binaryDigits w v) = v := by
  induction w generalizing v with
  | zero =>
    simp only [Nat.pow_zero] at hv
    have : v = 0 := by omega
    subst v
    rfl
  | succ w ih =>
    have hdiv : v / 2 < 2 ^ w := by
      apply (Nat.div_lt_iff_lt_mul (by decide : 0 < 2)).mpr
      simpa only [Nat.pow_succ] using hv
    simp only [binaryDigits, binaryValue, Fin.cases_zero, Fin.cases_succ,
      decide_eq_true_eq, ih (v / 2) hdiv]
    split <;> omega

theorem binaryValue_injective (w : Nat) (x y : Fin w → Bool)
    (h : binaryValue w x = binaryValue w y) : x = y := by
  induction w with
  | zero => funext i; exact Fin.elim0 i
  | succ w ih =>
    simp only [binaryValue] at h
    have hx : x 0 = y 0 := by
      cases h0 : x 0 <;> cases h1 : y 0 <;> simp_all <;> omega
    have ht : binaryValue w (fun i => x i.succ) = binaryValue w (fun i => y i.succ) := by
      rw [hx] at h
      omega
    have he := ih (fun i => x i.succ) (fun i => y i.succ) ht
    funext i
    exact Fin.cases hx (fun j => congrFun he j) i

theorem binaryDigits_value (w : Nat) (x : Fin w → Bool) :
    binaryDigits w (binaryValue w x) = x :=
  binaryValue_injective w _ _ (binaryValue_digits w _ (binaryValue_lt w x))

def identifier (w : Nat) (x : Input w) (c : Fin (clauseCount w)) (s : Fin 3) : Nat :=
  binaryValue w (fun b => x (coordinate w c s b.castSucc))

/-- false means positive; true means negated. -/
def negative (w : Nat) (x : Input w) (c : Fin (clauseCount w)) (s : Fin 3) : Bool :=
  x (coordinate w c s (Fin.last w))

def Valid (w : Nat) (x : Input w) : Prop :=
  ∀ c s, 0 < identifier w x c s

theorem identifier_le (w : Nat) (x : Input w) (c : Fin (clauseCount w)) (s : Fin 3) :
    identifier w x c s ≤ variableCount w := by
  have h := binaryValue_lt w (fun b => x (coordinate w c s b.castSucc))
  unfold identifier variableCount
  omega

/-- Zero is invalid; legal ID v names variable X_v (index v-1 in Fin m). -/
def literalValue (w : Nat) (x : Input w) (a : Assignment w)
    (c : Fin (clauseCount w)) (s : Fin 3) : Bool :=
  if h : 0 < identifier w x c s ∧ identifier w x c s ≤ variableCount w then
    let v : Fin (variableCount w) := ⟨identifier w x c s - 1, by omega⟩
    if negative w x c s then !(a v) else a v
  else false

def Satisfies (w : Nat) (x : Input w) (a : Assignment w) : Prop :=
  ∀ c : Fin (clauseCount w), ∃ s : Fin 3, literalValue w x a c s = true

def SAT (w : Nat) (x : Input w) : Prop :=
  Valid w x ∧ ∃ a : Assignment w, Satisfies w x a

/-- A total Boolean function on exactly n encoding bits. -/
noncomputable def satFunction (w : Nat) (x : Input w) : Bool := by
  classical
  exact decide (SAT w x)

theorem satFunction_eq_true_iff (w : Nat) (x : Input w) :
    satFunction w x = true ↔
      (∀ c s, 0 < identifier w x c s) ∧
      ∃ a : Fin (2 ^ w - 1) → Bool,
        ∀ c : Fin (2 ^ w - 1), ∃ s : Fin 3, literalValue w x a c s = true := by
  classical
  change decide (SAT w x) = true ↔ SAT w x
  exact decide_eq_true_iff

theorem invalid_eq_false (w : Nat) (x : Input w)
    (c : Fin (clauseCount w)) (s : Fin 3) (h : identifier w x c s = 0) :
    satFunction w x = false := by
  classical
  have hn : ¬ SAT w x := by
    intro hs
    have hp := hs.1 c s
    omega
  simp [satFunction, hn]

/-- A concrete valid instance: all m clauses are (X₁ ∨ X₁ ∨ X₁). -/
def repeatedPositiveOne (w : Nat) : Input w :=
  encodeBits w (fun _ _ b => decide (b.val = 0))

theorem repeatedPositiveOne_identifier (w : Nat) (hw : 0 < w)
    (c : Fin (clauseCount w)) (s : Fin 3) :
    identifier w (repeatedPositiveOne w) c s = 1 := by
  simp only [identifier, repeatedPositiveOne, encode_coordinate, Fin.val_castSucc]
  exact binaryValue_one w hw

theorem repeatedPositiveOne_sign (w : Nat) (hw : 0 < w)
    (c : Fin (clauseCount w)) (s : Fin 3) :
    negative w (repeatedPositiveOne w) c s = false := by
  simp [negative, repeatedPositiveOne, Nat.ne_of_gt hw]

theorem repeatedPositiveOne_sat (w : Nat) (hw : 0 < w) :
    satFunction w (repeatedPositiveOne w) = true := by
  apply (satFunction_eq_true_iff w _).mpr
  constructor
  · intro c s
    rw [repeatedPositiveOne_identifier w hw]
    decide
  · refine ⟨fun _ => true, ?_⟩
    intro c
    refine ⟨0, ?_⟩
    have hi := identifier_le w (repeatedPositiveOne w) c 0
    rw [repeatedPositiveOne_identifier w hw c 0] at hi
    simp [literalValue, repeatedPositiveOne_identifier w hw c 0,
      repeatedPositiveOne_sign w hw c 0, hi]

theorem allZero_unsat (w : Nat) (hw : 0 < w) :
    satFunction w (fun _ => false) = false := by
  have hm : 0 < clauseCount w := by
    unfold clauseCount variableCount
    have hp : 1 < 2 ^ w := Nat.one_lt_two_pow (Nat.ne_of_gt hw)
    omega
  apply invalid_eq_false w _ ⟨0, hm⟩ 0
  simp [identifier]

end SatLowerBound
