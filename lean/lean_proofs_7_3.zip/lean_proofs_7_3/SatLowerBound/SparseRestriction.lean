import SatLowerBound.SparseFormula

namespace SatLowerBound

/-- Field packing for arbitrary data, using the same coordinates as the SAT encoding. -/
def packFields {α : Type} (w : Nat)
    (x : Fin (clauseCount w) → Fin 3 → Fin (w + 1) → α) : Fin (inputBits w) → α := fun i =>
  let i' : Fin ((clauseCount w * 3) * (w + 1)) :=
    ⟨i.val, by simpa [inputBits, clauseCount, Nat.mul_comm 3 (variableCount w)] using i.isLt⟩
  let a := unpairIndex (Nat.zero_lt_succ w) i'
  let cs := unpairIndex (by decide : 0 < 3) a.1
  x cs.1 cs.2 a.2

theorem packFields_coordinate {α : Type} (w : Nat)
    (x : Fin (clauseCount w) → Fin 3 → Fin (w + 1) → α)
    (c : Fin (clauseCount w)) (s : Fin 3) (b : Fin (w + 1)) :
    packFields w x (coordinate w c s b) = x c s b := by
  change x (unpairIndex (by decide : 0 < 3)
    (unpairIndex (Nat.zero_lt_succ w) (pairIndex (pairIndex c s) b)).1).1
    (unpairIndex (by decide : 0 < 3)
    (unpairIndex (Nat.zero_lt_succ w) (pairIndex (pairIndex c s) b)).1).2
    (unpairIndex (Nat.zero_lt_succ w) (pairIndex (pairIndex c s) b)).2 = x c s b
  rw [unpair_pair, unpair_pair]

abbrev remainingClauses (w r : Nat) : Nat := variableCount w - forbiddenCount r
abbrev freeBits (w r : Nat) : Nat := remainingClauses w r * 3 * r

theorem freeBits_eq (w r : Nat) : freeBits w r = 3 * (variableCount w - forbiddenCount r) * r := by
  simp only [freeBits, remainingClauses, Nat.mul_comm (variableCount w - forbiddenCount r) 3]

def freeBitIndex {w r : Nat} (c : Fin (remainingClauses w r)) (s : Fin 3) (b : Fin r) :
    Fin (freeBits w r) := pairIndex (pairIndex c s) b

def suffixAssignmentOf {w r : Nat} (x : Fin (freeBits w r) → Bool) : SuffixAssignment w r :=
  fun c s b => x (freeBitIndex c s b)

theorem suffixVariable_digits (w r : Nat) (hr : r < w) (x : Fin r → Bool) :
    binaryDigits w ((suffixVariable w r hr x).val + 1) = suffixIdentifierBits w r x := by
  have hp := suffixIdentifier_pos w r hr x
  change binaryDigits w (binaryValue w (suffixIdentifierBits w r x) - 1 + 1) = _
  rw [Nat.sub_add_cancel (Nat.succ_le_of_lt hp), binaryDigits_value]

def sparseFieldSignal (w r : Nat) (c : Fin (clauseCount w)) (s : Fin 3)
    (b : Fin (w + 1)) : Signal (freeBits w r) :=
  if hc : c.val < forbiddenCount r then
    .constant (if hb : b.val < w then
      suffixIdentifierBits w r (forbiddenSuffix r ⟨c.val, hc⟩) ⟨b.val, hb⟩ else true)
  else if hb : b.val < r then
    .wire (freeBitIndex ⟨c.val - forbiddenCount r, by
      have := c.isLt; change c.val < variableCount w at this
      unfold remainingClauses; omega⟩ s ⟨b.val, hb⟩) false
  else .constant (decide (b.val + 1 = w))

/-- Every original bit is either a literal constant or one named free input. -/
def sparseRestriction (w r : Nat) : Fin (inputBits w) → Signal (freeBits w r) :=
  packFields w (sparseFieldSignal w r)

theorem sparseRestriction_correct (w r : Nat) (hr : r < w)
    (x : Fin (freeBits w r) → Bool) :
    (fun i => (sparseRestriction w r i).eval x) =
      encodeFormula w (sparseFormula w r hr (suffixAssignmentOf x)) := by
  funext i
  obtain ⟨c, s, b, rfl⟩ := coordinate_surjective w i
  simp only [sparseRestriction, packFields_coordinate, encodeFormula, encode_coordinate]
  by_cases hc : c.val < forbiddenCount r
  · simp only [sparseFieldSignal, sparseFormula, hc, ↓reduceDIte, Signal.eval,
      suffixVariable_digits]
  · simp only [sparseFieldSignal, sparseFormula, hc, ↓reduceDIte]
    by_cases hb : b.val < r
    · have hbw : b.val < w := Nat.lt_trans hb hr
      simp only [hb, hbw, ↓reduceDIte, suffixVariable_digits, suffixIdentifierBits,
        Signal.eval, Bool.xor_false, suffixAssignmentOf]
    · simp only [hb, ↓reduceDIte, Signal.eval]
      by_cases hbw : b.val < w
      · simp only [hbw, ↓reduceDIte, suffixVariable_digits, suffixIdentifierBits, hb]
      · have hbw' : b.val = w := by have := b.isLt; omega
        simp only [hbw', Nat.lt_irrefl, ↓reduceDIte, Nat.add_one_ne_self, decide_false]

noncomputable def sparseFunction (w r : Nat) (x : Fin (freeBits w r) → Bool) : Bool := by
  classical
  exact decide (∀ j : Fin (remainingClauses w r), ∃ s : Fin 3,
    helperBlock r (suffixAssignmentOf x j s) = true)

theorem sparseRestriction_sat (w r : Nat) (hr : r < w)
    (x : Fin (freeBits w r) → Bool) :
    satFunction w (fun i => (sparseRestriction w r i).eval x) = sparseFunction w r x := by
  rw [sparseRestriction_correct w r hr x]
  apply Bool.eq_iff_iff.mpr
  rw [encoded_sparse_sat_iff w r hr (suffixAssignmentOf x)]
  classical
  simp only [sparseFunction, decide_eq_true_eq]

theorem sparseRestriction_free_coordinate (w r : Nat) (hr : r < w)
    (j : Fin (remainingClauses w r)) (s : Fin 3) (b : Fin r) :
    sparseRestriction w r (coordinate w (freeClause w r j) s
      ⟨b.val, by have := b.isLt; omega⟩) = .wire (freeBitIndex j s b) false := by
  have hc : ¬ forbiddenCount r + j.val < forbiddenCount r := by omega
  simp only [sparseRestriction, packFields_coordinate, sparseFieldSignal, freeClause,
    hc, ↓reduceDIte, b.isLt, Nat.add_sub_cancel_left]

end SatLowerBound
