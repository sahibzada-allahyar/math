import SatLowerBound.Gates

namespace SatLowerBound

/-- Append one computed signal to the currently available signals. -/
def extend {n : Nat} (x : Fin n → Bool) (b : Bool) : Fin (n + 1) → Bool :=
  fun i => if h : i.val < n then x ⟨i.val, h⟩ else b

@[simp] theorem extend_old {n : Nat} (x : Fin n → Bool) (b : Bool) (i : Fin n) :
    extend x b i.castSucc = x i := by simp [extend, i.isLt]

@[simp] theorem extend_last {n : Nat} (x : Fin n → Bool) (b : Bool) :
    extend x b (Fin.last n) = b := by simp [extend]

/-- A topologically ordered straight-line circuit. A gate can read any two
available signals, including the same signal; users of each signal are unrestricted.
`output` adds no gate; every `gate` adds exactly one gate, including unary/constant tables.
-/
inductive Circuit : Nat → Type where
  | output {n : Nat} (i : Fin n) : Circuit n
  | gate {n : Nat} (g : Table) (left right : Fin n) (rest : Circuit (n + 1)) : Circuit n

namespace Circuit

def size : {n : Nat} → Circuit n → Nat
  | _, .output _ => 0
  | _, .gate _ _ _ rest => rest.size + 1

def eval : {n : Nat} → Circuit n → (Fin n → Bool) → Bool
  | _, .output i, x => x i
  | _, .gate g l r rest, x => rest.eval (extend x (g.eval (x l) (x r)))

def Computes {n : Nat} (C : Circuit n) (f : (Fin n → Bool) → Bool) : Prop :=
  ∀ x, C.eval x = f x

def weight : {n : Nat} → Circuit n → Nat
  | _, .output _ => 0
  | _, .gate g _ _ rest => g.weight + rest.weight

def nonlinearCount : {n : Nat} → Circuit n → Nat
  | _, .output _ => 0
  | _, .gate g _ _ rest => g.nonlinearCount + rest.nonlinearCount

def parityCount : {n : Nat} → Circuit n → Nat
  | _, .output _ => 0
  | _, .gate g _ _ rest => g.parityCount + rest.parityCount

theorem weight_eq {n : Nat} (C : Circuit n) :
    C.weight = 3 * C.parityCount + 2 * C.nonlinearCount := by
  induction C with
  | output => rfl
  | gate g l r rest ih =>
    simp only [weight, parityCount, nonlinearCount]
    have hg := g.weight_eq
    omega

theorem resource_le {n : Nat} (C : Circuit n) :
    C.weight + C.nonlinearCount ≤ 3 * C.size := by
  induction C with
  | output => exact Nat.le_refl 0
  | gate g l r rest ih =>
    simp only [weight, nonlinearCount, size]
    have hg := g.resource_le
    omega

/-- Extends a signal renaming by sending the newly computed signal to itself. -/
def liftMap {n m : Nat} (f : Fin n → Fin m) : Fin (n + 1) → Fin (m + 1) :=
  fun i => if h : i.val < n then (f ⟨i.val, h⟩).castSucc else Fin.last m

theorem extend_liftMap {n m : Nat} (f : Fin n → Fin m)
    (x : Fin m → Bool) (b : Bool) :
    (fun i => extend x b (liftMap f i)) = extend (fun i => x (f i)) b := by
  funext i
  simp only [liftMap, extend]
  split <;> simp_all

def rename : {n m : Nat} → (Fin n → Fin m) → Circuit n → Circuit m
  | _, _, f, .output i => .output (f i)
  | _, _, f, .gate g l r rest => .gate g (f l) (f r) (rename (liftMap f) rest)

theorem rename_size {n m : Nat} (f : Fin n → Fin m) (C : Circuit n) :
    (C.rename f).size = C.size := by
  induction C generalizing m with
  | output => rfl
  | gate g l r rest ih => simp only [rename, size, ih]

theorem rename_eval {n m : Nat} (f : Fin n → Fin m) (C : Circuit n) (x : Fin m → Bool) :
    (C.rename f).eval x = C.eval (fun i => x (f i)) := by
  induction C generalizing m with
  | output => rfl
  | gate g l r rest ih =>
    simp only [rename, eval, ih, extend_liftMap]

end Circuit
end SatLowerBound
