import SatLowerBound.Asymptotic
import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity

namespace SatLowerBound

/-- The manuscript's choice k = ceil(log_2 w), r = w-k+2. -/
def logarithmicOffset (w : Nat) : Nat := Nat.clog 2 w

theorem logarithmicOffset_eq_ceiling (w : Nat) :
    logarithmicOffset w = ⌈Real.logb 2 w⌉₊ :=
  (Real.natCeil_logb_natCast 2 w).symm

theorem logarithmic_parameters (w : Nat) (hw : 8 ≤ w) :
    3 ≤ logarithmicOffset w ∧ logarithmicOffset w ≤ w - 1 ∧
    3 ≤ w - logarithmicOffset w + 2 ∧ w - logarithmicOffset w + 2 < w := by
  have hlo := Nat.clog_mono_right 2 hw
  have h8 : Nat.clog 2 8 = 3 := by decide
  rw [h8] at hlo
  have hp : w - 1 + 1 ≤ 2 ^ (w - 1) := Nat.lt_two_pow_self
  have hhi : Nat.clog 2 w ≤ w - 1 := Nat.clog_le_of_le_pow (by omega)
  unfold logarithmicOffset
  omega

theorem square_le_twice_power (k : Nat) : k * k ≤ 2 ^ (k + 1) := by
  induction k with
  | zero => decide
  | succ k ih =>
      by_cases hk : k < 3
      · have hcases : k = 0 ∨ k = 1 ∨ k = 2 := by omega
        rcases hcases with rfl | rfl | rfl <;> decide
      · have hk3 : 3 ≤ k := by omega
        have hmul := Nat.mul_le_mul_right k hk3
        rw [Nat.pow_succ]
        nlinarith

theorem logarithmic_offset_square (w : Nat) (hw : 8 ≤ w) :
    logarithmicOffset w * logarithmicOffset w ≤ 4 * w := by
  have hk := (logarithmic_parameters w hw).1
  have hp := Nat.pow_pred_clog_lt_self (b := 2) (by decide) (x := w) (by omega)
  have hs := square_le_twice_power (logarithmicOffset w)
  have he : logarithmicOffset w + 1 = (logarithmicOffset w - 1) + 2 := by omega
  rw [he, Nat.pow_add] at hs
  change 2 ^ (logarithmicOffset w - 1) < w at hp
  norm_num at hs
  omega

/-- The sparse helper cost after the exact parameter choice in the manuscript. -/
theorem logarithmic_helper_budget (w : Nat) (hw : 8 ≤ w) :
    w * forbiddenCount (w - logarithmicOffset w + 2) ≤ 5 * variableCount w := by
  have hk := (logarithmic_parameters w hw).2.1
  have hpow := Nat.le_pow_clog (b := 2) (by decide) w
  have hc := helper_count_le (w - logarithmicOffset w + 2)
  have hm : 4 ≤ variableCount w := by
    have hp := Nat.pow_le_pow_right (n := 2) (by decide) hw
    norm_num at hp
    unfold variableCount
    omega
  have he : logarithmicOffset w + (w - logarithmicOffset w + 2) = w + 2 := by omega
  have hmul := Nat.mul_le_mul_right (2 ^ (w - logarithmicOffset w + 2)) hpow
  change w * 2 ^ (w - logarithmicOffset w + 2) ≤
    2 ^ logarithmicOffset w * 2 ^ (w - logarithmicOffset w + 2) at hmul
  rw [← Nat.pow_add, he] at hmul
  have hpw : 2 ^ (w + 2) = 2 ^ w * 4 := by rw [Nat.pow_add]
  rw [hpw] at hmul
  have hcost := Nat.mul_le_mul_left w hc
  unfold variableCount at hm ⊢
  omega

/-- Integer form of 7n/3 - 4m ceil(log_2 w) - 24m. -/
theorem logarithmic_integer_bound (w : Nat) (hw : 8 ≤ w)
    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    7 * inputBits w ≤ 3 * C.size +
      12 * variableCount w * logarithmicOffset w + 72 * variableCount w := by
  let k := logarithmicOffset w
  let r := w - k + 2
  obtain ⟨hk3, hkw, hr3, hrw⟩ := logarithmic_parameters w hw
  have hb := main_lower_bound w r hw hr3 hrw C hc
  have hz := logarithmic_helper_budget w hw
  have hfit := helper_count_fits w r hrw
  have hrem : remainingClauses w r + forbiddenCount r = variableCount w :=
    Nat.sub_add_cancel hfit
  have hcoef : 4 * r - 7 + 7 = 4 * r := Nat.sub_add_cancel (by omega)
  have hwr : r + k = w + 2 := by dsimp [r, k]; omega
  have hm : 1 ≤ variableCount w := by
    have hp : 1 < 2 ^ w := Nat.one_lt_two_pow (by omega)
    unfold variableCount
    omega
  have hcoefBound : 4 * r - 7 ≤ 4 * w := by omega
  have hcost := Nat.mul_le_mul_right (forbiddenCount r) hcoefBound
  change w * forbiddenCount r ≤ 5 * variableCount w at hz
  have hprod := congrArg (fun a => a * variableCount w) hcoef
  have hprod2 := congrArg (fun a => (4 * r - 7) * a) hrem
  have hprod3 := congrArg (fun a => 4 * variableCount w * a) hwr
  change 7 * (3 * variableCount w * (w + 1)) ≤ _
  change 3 * variableCount w * (w + 1) + _ ≤ _ at hb
  change 7 * (3 * variableCount w * (w + 1)) ≤
    3 * C.size + 12 * variableCount w * k + 72 * variableCount w
  nlinarith

/-- Elementary bounds on q = log_2 n, avoiding an implicit change of scale. -/
theorem encoded_log_bounds (w : Nat) (hw : 8 ≤ w) :
    (w : ℝ) ≤ Real.logb 2 (inputBits w) ∧
    Real.logb 2 (inputBits w) ≤ (w : ℝ) + logarithmicOffset w + 3 := by
  have hm : 1 ≤ variableCount w := by
    have hp : 1 < 2 ^ w := Nat.one_lt_two_pow (by omega)
    unfold variableCount
    omega
  have hpow : 2 ^ w = variableCount w + 1 := by
    have hp := Nat.one_le_two_pow (n := w)
    unfold variableCount
    omega
  have hlow : 2 ^ w ≤ inputBits w := by
    have hmul := Nat.mul_le_mul_left (3 * variableCount w) (show 1 ≤ w + 1 by omega)
    unfold inputBits
    nlinarith
  have hwk := Nat.le_pow_clog (b := 2) (by decide) w
  have hupper : inputBits w ≤ 2 ^ (w + logarithmicOffset w + 3) := by
    calc
      inputBits w = 3 * variableCount w * (w + 1) := rfl
      _ ≤ (4 * 2 ^ w) * (2 * 2 ^ logarithmicOffset w) := by
        apply Nat.mul_le_mul
        · exact Nat.mul_le_mul (by decide) (Nat.sub_le _ _)
        · change w + 1 ≤ 2 * 2 ^ Nat.clog 2 w
          omega
      _ = 2 ^ (w + logarithmicOffset w + 3) := by
        simp only [Nat.pow_add]
        ring
  have hlo := Real.logb_le_logb_of_le (b := 2) (by norm_num)
    (show 0 < (2 : ℝ) ^ w by positivity) (show (2 : ℝ) ^ w ≤ inputBits w by exact_mod_cast hlow)
  have hhi := Real.logb_le_logb_of_le (b := 2) (by norm_num)
    (show 0 < (inputBits w : ℝ) by
      have : 0 < inputBits w := lt_of_lt_of_le (Nat.two_pow_pos w) hlow
      exact_mod_cast this)
    (show (inputBits w : ℝ) ≤ (2 : ℝ) ^ (w + logarithmicOffset w + 3) by exact_mod_cast hupper)
  norm_num only [Real.logb_pow, Real.logb_self_eq_one (by norm_num : (1 : ℝ) < 2),
    mul_one, Nat.cast_add, Nat.cast_ofNat] at hlo hhi
  exact ⟨hlo, hhi⟩

theorem offset_le_nested_log (w : Nat) (hw : 8 ≤ w) :
    (logarithmicOffset w : ℝ) - 1 ≤ Real.logb 2 (Real.logb 2 (inputBits w)) := by
  have hk := (logarithmic_parameters w hw).1
  have hp := Nat.pow_pred_clog_lt_self (b := 2) (by decide) (x := w) (by omega)
  have hlo := Real.logb_le_logb_of_le (b := 2) (by norm_num)
    (show 0 < (2 : ℝ) ^ (logarithmicOffset w - 1) by positivity)
    (show (2 : ℝ) ^ (logarithmicOffset w - 1) ≤ (w : ℝ) by exact_mod_cast hp.le)
  have hhi := Real.logb_le_logb_of_le (b := 2) (by norm_num)
    (show 0 < (w : ℝ) by exact_mod_cast (show 0 < w by omega)) (encoded_log_bounds w hw).1
  norm_num only [Real.logb_pow, Real.logb_self_eq_one (by norm_num : (1 : ℝ) < 2), mul_one] at hlo
  rw [Nat.cast_sub (by omega : 1 ≤ logarithmicOffset w), Nat.cast_one] at hlo
  exact le_trans hlo hhi

/-- A concrete version of the manuscript's logarithmic asymptotic remainder. -/
def LogarithmicCertificate : Prop :=
  ∀ w : Nat, 8 ≤ w → ∀ C : Circuit (inputBits w), C.Computes (satFunction w) →
    (7 / 3 : ℝ) * inputBits w -
      (4 / 3 : ℝ) * inputBits w * Real.logb 2 (Real.logb 2 (inputBits w)) /
        Real.logb 2 (inputBits w) -
      32 * inputBits w / Real.logb 2 (inputBits w) ≤ (C.size : ℝ)

/-- The full 7/3 bound, including the coefficient 4/3 of the logarithmic loss,
with explicit remainder constant 32, valid for every w >= 8. -/
theorem logarithmic_lower_bound : LogarithmicCertificate := by
  intro w hw C hc
  let k : ℝ := logarithmicOffset w
  let q : ℝ := Real.logb 2 (inputBits w)
  let h : ℝ := Real.logb 2 q
  have hw0 : (0 : ℝ) < w := by exact_mod_cast (show 0 < w by omega)
  have hk0 : 0 ≤ k := Nat.cast_nonneg _
  have hkw : k ≤ (w : ℝ) := by
    have := (logarithmic_parameters w hw).2.1
    dsimp [k]
    exact_mod_cast (show logarithmicOffset w ≤ w by omega)
  have hksq : k * k ≤ 4 * (w : ℝ) := by
    dsimp [k]
    exact_mod_cast logarithmic_offset_square w hw
  obtain ⟨hqlow, hqup⟩ := encoded_log_bounds w hw
  change (w : ℝ) ≤ q at hqlow
  change q ≤ (w : ℝ) + k + 3 at hqup
  have hq : 0 < q := lt_of_lt_of_le hw0 hqlow
  have hh : k - 1 ≤ h := offset_le_nested_log w hw
  have hratio : (4 * k + 24) * q ≤ 4 * ((w : ℝ) + 1) * h + 96 * ((w : ℝ) + 1) := by
    have h1 := mul_le_mul_of_nonneg_left hqup (show 0 ≤ 4 * k + 24 by positivity)
    have h2 := mul_le_mul_of_nonneg_left hh (show 0 ≤ 4 * ((w : ℝ) + 1) by positivity)
    nlinarith
  let m : ℝ := variableCount w
  let n : ℝ := inputBits w
  have hm : 0 ≤ m := Nat.cast_nonneg _
  have hn : n = 3 * m * ((w : ℝ) + 1) := by
    dsimp [n, m, inputBits]
    push_cast
    rfl
  have hbudget : (4 * m * k + 24 * m) * q ≤ (4 / 3 : ℝ) * n * h + 32 * n := by
    have hb := mul_le_mul_of_nonneg_left hratio hm
    rw [hn]
    nlinarith
  have hint : 7 * n ≤ 3 * (C.size : ℝ) + 12 * m * k + 72 * m := by
    dsimp [n, m, k]
    exact_mod_cast logarithmic_integer_bound w hw C hc
  have hdiv : 4 * m * k + 24 * m ≤ ((4 / 3 : ℝ) * n * h + 32 * n) / q :=
    (le_div_iff₀ hq).mpr hbudget
  change (7 / 3 : ℝ) * n - (4 / 3 : ℝ) * n * h / q - 32 * n / q ≤ (C.size : ℝ)
  rw [add_div] at hdiv
  linarith

/-- The explicit remainder, in the same scale as the manuscript's O-term. -/
noncomputable def logarithmicError (w : Nat) : ℝ :=
  32 * inputBits w / Real.logb 2 (inputBits w)

theorem logarithmic_error_isBigO :
    Asymptotics.IsBigO Filter.atTop logarithmicError
      (fun w : Nat => (inputBits w : ℝ) / Real.logb 2 (inputBits w)) := by
  apply Asymptotics.isBigO_iff.mpr
  refine ⟨32, Filter.Eventually.of_forall ?_⟩
  intro w
  simp only [logarithmicError, mul_div_assoc, norm_mul]
  norm_num

/-- The TeX asymptotic claim, with standard mathlib Big-O along the encoded widths. -/
def LogarithmicAsymptoticCertificate : Prop :=
  ∃ E : Nat → ℝ,
    Asymptotics.IsBigO Filter.atTop E
      (fun w : Nat => (inputBits w : ℝ) / Real.logb 2 (inputBits w)) ∧
    ∀ᶠ w in Filter.atTop, ∀ C : Circuit (inputBits w), C.Computes (satFunction w) →
      (7 / 3 : ℝ) * inputBits w -
        (4 / 3 : ℝ) * inputBits w * Real.logb 2 (Real.logb 2 (inputBits w)) /
          Real.logb 2 (inputBits w) - E w ≤ (C.size : ℝ)

theorem logarithmic_asymptotic : LogarithmicAsymptoticCertificate := by
  refine ⟨logarithmicError, logarithmic_error_isBigO, ?_⟩
  filter_upwards [Filter.eventually_ge_atTop (8 : Nat)] with w hw
  intro C hc
  exact logarithmic_lower_bound w hw C hc

end SatLowerBound
