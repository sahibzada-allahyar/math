import SatLowerBound.TriangleNormalization

namespace SatLowerBound

theorem Table.complement_essential (g : Table) : g.complement.essential = g.essential := by
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

namespace OpenCircuit

/-- Absorb the signed output into the final live gate, preserving every resource
and every predecessor. This closes the auxiliary representation in the PDF model. -/
theorem close_reduced {n : Nat} (C : OpenCircuit n) (hC : C.Reduced) (hpos : 0 < C.size) :
    ∃ D : Circuit n, D.size = C.size ∧ D.weight = C.weight ∧
      (∀ v, D.eval v = C.eval v) ∧
      (∀ p, (ofCircuit D).usage p = C.usage p) ∧
      (ofCircuit D).Reduced ∧
      (∀ Γ, NoInputTriangles Γ (ofCircuit D) ↔ NoInputTriangles Γ C) := by
  induction C with
  | output s => simp [size] at hpos
  | @gate n g i j rest ih =>
      cases rest with
      | output s =>
          have hu := hC.2.2.1
          cases s with
          | constant b => simp [lastUses, usage] at hu
          | wire k b =>
              have hk : k = Fin.last n := by
                have hn : ¬ k.val < n := by
                  intro h
                  simp [lastUses, usage, appendValue, h] at hu
                apply Fin.ext
                have := k.isLt
                simp only [Fin.val_last]
                omega
              subst k
              let f := if b then g.complement else g
              have hf : f.weight = g.weight := by cases b <;> simp [f, Table.complement_weight]
              have he : f.essential = g.essential := by cases b <;> simp [f, Table.complement_essential]
              refine ⟨.gate f i j (.output (Fin.last n)), rfl, ?_, ?_, ?_, ?_, ?_⟩
              · simp only [Circuit.weight, weight, hf]
              · intro v
                simp only [Circuit.eval, eval, Signal.eval, extend_last]
                cases b <;> simp [f, Table.complement, Table.eval_ofFunction]
              · intro p
                rfl
              · exact ⟨he.trans hC.1, hC.2.1, by simp [ofCircuit, lastUses, usage, appendValue], trivial⟩
              · intro Γ
                rfl
      | gate f k l tail =>
          obtain ⟨D, hs, hw, he, hu, hr, ht⟩ := ih hC.2.2.2 (by simp [size])
          refine ⟨.gate g i j D, ?_, ?_, ?_, ?_, ?_, ?_⟩
          · simp only [Circuit.size, size, hs]
          · simp only [Circuit.weight, weight, hw]
          · intro v
            exact he _
          · intro p
            simp only [ofCircuit, usage, hu]
          · refine ⟨hC.1, hC.2.1, ?_, hr⟩
            simpa only [lastUses, hu] using hC.2.2.1
          · intro Γ
            exact and_congr Iff.rfl (ht _)

theorem positive_size_of_two_essential {n : Nat} (C : OpenCircuit n)
    (x y : Fin n) (hxy : x ≠ y) (hx : Essential C.eval x) (hy : Essential C.eval y) :
    0 < C.size := by
  cases C with
  | gate => simp [size]
  | output s =>
      cases s with
      | constant b =>
          obtain ⟨a, c, _, h⟩ := hx
          exact False.elim (h rfl)
      | wire i b =>
          have hi (z : Fin n) (hz : Essential (output (.wire i b)).eval z) : i = z := by
            by_contra hn
            obtain ⟨a, c, hagree, hdiff⟩ := hz
            exact hdiff (congrArg (fun v => Bool.xor v b) (hagree i hn))
          exact False.elim (hxy ((hi x hx).symm.trans (hi y hy)))

end OpenCircuit

/-- PDF Lemma 3.1 in the original ordinary-circuit model, including output absorption. -/
theorem Circuit.normalize_pdf {n : Nat} (C : Circuit n) (x y : Fin n)
    (hxy : x ≠ y) (hx : Essential C.eval x) (hy : Essential C.eval y) :
    ∃ D : Circuit n, D.size ≤ C.size ∧ D.weight ≤ C.weight ∧
      D.Computes C.eval ∧ (OpenCircuit.ofCircuit D).Reduced ∧
      OpenCircuit.NoInputTriangles (fun _ => none) (OpenCircuit.ofCircuit D) := by
  obtain ⟨R, hr, ht, hs, hw, he⟩ := OpenCircuit.normalize_full C
  have hev : R.eval = C.eval := funext he
  have hp := R.positive_size_of_two_essential x y hxy (by rwa [hev]) (by rwa [hev])
  obtain ⟨D, hDs, hDw, hDe, _, hDr, hDt⟩ := R.close_reduced hr hp
  exact ⟨D, hDs ▸ hs, hDw ▸ hw, fun v => (hDe v).trans (he v), hDr, (hDt _).mpr ht⟩

end SatLowerBound
