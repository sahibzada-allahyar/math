import SatLowerBound.PairRestriction
import Mathlib.Data.Finset.Card

namespace SatLowerBound

def tally {n : Nat} (S : Finset (Fin n)) (v : Fin n → Bool) : Nat :=
  ∑ i ∈ S, indicator (v i)

def modularBlock {n : Nat} (S : Finset (Fin n)) (t : Fin 3) (c : Bool)
    (v : Fin n → Bool) : Bool := Bool.xor (decide (tally S v % 3 = t.val)) c

theorem tally_congr {n : Nat} (S : Finset (Fin n)) (v u : Fin n → Bool)
    (h : ∀ i ∈ S, v i = u i) : tally S v = tally S u := by
  apply Finset.sum_congr rfl
  intro i hi
  rw [h i hi]

theorem tally_fixBit {n : Nat} (S : Finset (Fin n)) (x : Fin n) (hx : x ∈ S)
    (b : Bool) (v : Fin n → Bool) :
    tally S (fixBit x b v) = indicator b + tally (S.erase x) v := by
  have hsum := Finset.sum_erase_add S (fun i => indicator (fixBit x b v i)) hx
  have hr : tally (S.erase x) (fixBit x b v) = tally (S.erase x) v := by
    apply tally_congr
    intro i hi
    simp [fixBit, (Finset.mem_erase.mp hi).1]
  change tally (S.erase x) (fixBit x b v) + indicator (fixBit x b v x) =
    tally S (fixBit x b v) at hsum
  rw [hr] at hsum
  simp only [fixBit, ↓reduceIte] at hsum
  omega

theorem tally_realize {n : Nat} (S : Finset (Fin n)) (k : Nat) (hk : k ≤ S.card) :
    ∃ v : Fin n → Bool, tally S v = k := by
  obtain ⟨T, hT, hcard⟩ := Finset.exists_subset_card_eq hk
  refine ⟨fun i => decide (i ∈ T), ?_⟩
  simp [tally, indicator, Finset.inter_eq_right.mpr hT, hcard]

theorem modularBlock_nonconstant {n : Nat} (S : Finset (Fin n)) (t : Fin 3) (c : Bool)
    (hS : 2 ≤ S.card) : Nonconstant (modularBlock S t c) := by
  obtain ⟨u, hu⟩ := tally_realize S t.val (by have := t.isLt; omega)
  obtain ⟨v, hv⟩ := tally_realize S ((t.val + 1) % 3) (by have := Nat.mod_lt (t.val + 1) (by omega : 0 < 3); omega)
  refine ⟨u, v, ?_⟩
  have ht : t.val % 3 = t.val := Nat.mod_eq_of_lt t.isLt
  have hne : (t.val + 1) % 3 ≠ t.val := by have := t.isLt; omega
  simp only [modularBlock, hu, hv, ht, Nat.mod_mod, hne, decide_false, decide_true]
  cases c <;> decide

theorem modularBlock_essential {n : Nat} (S : Finset (Fin n)) (t : Fin 3) (c : Bool)
    (hS : 2 ≤ S.card) (x : Fin n) (hx : x ∈ S) : Essential (modularBlock S t c) x := by
  let k : Nat := if t.val = 2 then 1 else 0
  have hk : k ≤ (S.erase x).card := by rw [Finset.card_erase_of_mem hx]; simp only [k]; split <;> omega
  obtain ⟨v, hv⟩ := tally_realize (S.erase x) k hk
  refine ⟨fixBit x false v, fixBit x true v, ?_, ?_⟩
  · intro i hi
    simp [fixBit, hi]
  · simp only [modularBlock, tally_fixBit S x hx, hv]
    have ht : t.val = 0 ∨ t.val = 1 ∨ t.val = 2 := by have := t.isLt; omega
    rcases ht with ht | ht | ht <;> cases c <;> simp [k, ht, indicator]

theorem modularBlock_support {n : Nat} (S : Finset (Fin n)) (t : Fin 3) (c : Bool)
    (x : Fin n) (hx : Essential (modularBlock S t c) x) : x ∈ S := by
  by_contra hnot
  obtain ⟨u, v, hagree, hne⟩ := hx
  have ht : tally S u = tally S v := by
    apply tally_congr
    intro i hi
    exact hagree i (fun he => hnot (he ▸ hi))
  exact hne (by simp only [modularBlock, ht])

def lowerResidue (t : Fin 3) (b : Bool) : Fin 3 :=
  ⟨(t.val + 3 - indicator b) % 3, Nat.mod_lt _ (by omega)⟩

theorem modularBlock_cofactor {n : Nat} (S : Finset (Fin n)) (t : Fin 3) (c : Bool)
    (x : Fin n) (hx : x ∈ S) (b : Bool) (v : Fin n → Bool) :
    modularBlock S t c (fixBit x b v) = modularBlock (S.erase x) (lowerResidue t b) c v := by
  simp only [modularBlock, tally_fixBit S x hx]
  congr 2
  apply propext
  have ht := t.isLt
  have hk := Nat.mod_lt (tally (S.erase x) v) (by omega : 0 < 3)
  cases b <;> simp only [lowerResidue, indicator, Bool.false_eq_true, ↓reduceIte,
    Nat.zero_add, Nat.add_mod, Nat.mod_mod, Nat.one_mod]
  all_goals omega

end SatLowerBound
