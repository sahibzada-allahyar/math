import SatLowerBound.MinimalNormal

namespace SatLowerBound

structure GateRecipe (n : Nat) where
  table : Table
  left : Fin n
  right : Fin n

def GateRecipe.lift {n : Nat} (p : GateRecipe n) : GateRecipe (n + 1) :=
  ⟨p.table, p.left.castSucc, p.right.castSucc⟩

abbrev History (n : Nat) := Fin n → Option (GateRecipe n)

def History.Sorted {n : Nat} (Γ : History n) : Prop :=
  ∀ k p, Γ k = some p → p.left.val < k.val ∧ p.right.val < k.val

def History.Valid {n : Nat} (Γ : History n) (x : Fin n → Bool) : Prop :=
  ∀ k p, Γ k = some p → x k = p.table.eval (x p.left) (x p.right)

def History.extend {n : Nat} (Γ : History n) (g : Table) (i j : Fin n) : History (n + 1) :=
  fun k => if hk : k.val < n then (Γ ⟨k.val, hk⟩).map GateRecipe.lift
    else some ⟨g, i.castSucc, j.castSucc⟩

@[simp] theorem History.extend_old {n : Nat} (Γ : History n) (g : Table) (i j k : Fin n) :
    Γ.extend g i j k.castSucc = (Γ k).map GateRecipe.lift := by
  simp [History.extend, k.isLt]

@[simp] theorem History.extend_last {n : Nat} (Γ : History n) (g : Table) (i j : Fin n) :
    Γ.extend g i j (Fin.last n) = some ⟨g, i.castSucc, j.castSucc⟩ := by
  simp [History.extend]

theorem History.sorted_extend {n : Nat} (Γ : History n) (hΓ : Γ.Sorted)
    (g : Table) (i j : Fin n) : (Γ.extend g i j).Sorted := by
  intro k p hp
  induction k using Fin.lastCases with
  | last =>
    rw [History.extend_last] at hp
    cases hp
    exact ⟨i.isLt, j.isLt⟩
  | cast k =>
    rw [History.extend_old] at hp
    cases hk : Γ k with
    | none => simp [hk] at hp
    | some q =>
      rw [hk] at hp
      cases hp
      exact hΓ k q hk

theorem History.valid_extend {n : Nat} (Γ : History n) (x : Fin n → Bool) (hx : Γ.Valid x)
    (g : Table) (i j : Fin n) :
    (Γ.extend g i j).Valid (SatLowerBound.extend x (g.eval (x i) (x j))) := by
  intro k p hp
  induction k using Fin.lastCases with
  | last =>
    rw [History.extend_last] at hp
    cases hp
    simp only [SatLowerBound.extend_last, SatLowerBound.extend_old]
  | cast k =>
    rw [History.extend_old] at hp
    cases hk : Γ k with
    | none => simp [hk] at hp
    | some q =>
      rw [hk] at hp
      cases hp
      simpa only [GateRecipe.lift, SatLowerBound.extend_old] using hx k q hk

def Table.swap (g : Table) : Table := Table.ofFunction (fun x y => g.eval y x)

theorem Table.swap_eval (g : Table) (x y : Bool) : g.swap.eval x y = g.eval y x :=
  Table.eval_ofFunction _ _ _

theorem Table.swap_weight (g : Table) : g.swap.weight = g.weight := by
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> rfl

theorem Table.swap_essential (g : Table) : g.swap.essential = g.essential := by
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> rfl

/-- A primary input and one of its own direct gate successors feed one instruction. -/
def History.TriangleAt {n : Nat} (Γ : History n) (i j : Fin n) : Prop :=
  (Γ i = none ∧ ∃ p, Γ j = some p ∧ (p.left = i ∨ p.right = i)) ∨
  (Γ j = none ∧ ∃ p, Γ i = some p ∧ (p.left = j ∨ p.right = j))

theorem History.rewrite_left {n : Nat} (Γ : History n) (hΓ : Γ.Sorted)
    (g : Table) (hg : g.essential = true) (i j : Fin n)
    (p : GateRecipe n) (hp : Γ j = some p) (hpi : p.left = i ∨ p.right = i) :
    ∃ (h : Table) (k l : Fin n),
      h.weight ≤ g.weight ∧ k.val + l.val < i.val + j.val ∧
      ∀ x, Γ.Valid x → h.eval (x k) (x l) = g.eval (x i) (x j) := by
  have hs := hΓ j p hp
  rcases hpi with hi | hi
  · refine ⟨p.table.triangle g, i, p.right, Table.triangle_weight _ _ hg, ?_, ?_⟩
    · omega
    · intro x hx
      rw [Table.triangle_eval, hx j p hp, hi]
  · refine ⟨p.table.swap.triangle g, i, p.left, Table.triangle_weight _ _ hg, ?_, ?_⟩
    · omega
    · intro x hx
      rw [Table.triangle_eval, Table.swap_eval, hx j p hp, hi]

/-- The rewrite preserves semantics on every valuation compatible with the earlier
instructions, never increases weight, and strictly lowers predecessor positions. -/
theorem History.rewrite_triangle {n : Nat} (Γ : History n) (hΓ : Γ.Sorted)
    (g : Table) (hg : g.essential = true) (i j : Fin n) (ht : Γ.TriangleAt i j) :
    ∃ (h : Table) (k l : Fin n),
      h.weight ≤ g.weight ∧ k.val + l.val < i.val + j.val ∧
      ∀ x, Γ.Valid x → h.eval (x k) (x l) = g.eval (x i) (x j) := by
  rcases ht with ⟨_, p, hp, hpi⟩ | ⟨_, p, hp, hpj⟩
  · exact Γ.rewrite_left hΓ g hg i j p hp hpi
  · obtain ⟨h, k, l, hw, hs, he⟩ :=
      Γ.rewrite_left hΓ g.swap (by rw [Table.swap_essential]; exact hg) j i p hp hpj
    refine ⟨h, k, l, ?_, ?_, ?_⟩
    · simpa only [Table.swap_weight] using hw
    · omega
    · intro x hx
      rw [he x hx, Table.swap_eval]

end SatLowerBound
