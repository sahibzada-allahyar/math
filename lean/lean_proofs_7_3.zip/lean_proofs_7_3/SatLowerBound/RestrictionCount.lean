import SatLowerBound.SparseRestriction
import Mathlib.Data.Finset.Card

namespace SatLowerBound

def Signal.isConstant {n : Nat} : Signal n → Bool
  | .constant _ => true
  | .wire _ _ => false

def fixedMask (w r : Nat) (i : Fin (inputBits w)) : Bool :=
  (sparseRestriction w r i).isConstant

def freeEmbedding (w r : Nat) (hr : r < w) (hr0 : 0 < r)
    (i : Fin (freeBits w r)) : Fin (inputBits w) :=
  let a := unpairIndex hr0 i
  let cs := unpairIndex (by decide : 0 < 3) a.1
  coordinate w (freeClause w r cs.1) cs.2
    ⟨a.2.val, by have := a.2.isLt; omega⟩

theorem freeEmbedding_freeBitIndex (w r : Nat) (hr : r < w) (hr0 : 0 < r)
    (c : Fin (remainingClauses w r)) (s : Fin 3) (b : Fin r) :
    freeEmbedding w r hr hr0 (freeBitIndex c s b) =
      coordinate w (freeClause w r c) s ⟨b.val, by have := b.isLt; omega⟩ := by
  simp only [freeEmbedding, freeBitIndex, unpair_pair]

theorem sparseRestriction_freeEmbedding (w r : Nat) (hr : r < w) (hr0 : 0 < r)
    (i : Fin (freeBits w r)) :
    sparseRestriction w r (freeEmbedding w r hr hr0 i) = .wire i false := by
  unfold freeEmbedding
  rw [sparseRestriction_free_coordinate w r hr]
  unfold freeBitIndex
  rw [pair_unpair, pair_unpair]

theorem freeEmbedding_injective (w r : Nat) (hr : r < w) (hr0 : 0 < r) :
    Function.Injective (freeEmbedding w r hr hr0) := by
  intro i j h
  have he := congrArg (sparseRestriction w r) h
  rw [sparseRestriction_freeEmbedding, sparseRestriction_freeEmbedding] at he
  exact (Signal.wire.inj he).1

theorem fixedMask_false_iff (w r : Nat) (hr : r < w) (hr0 : 0 < r)
    (i : Fin (inputBits w)) :
    fixedMask w r i = false ↔ ∃ j, freeEmbedding w r hr hr0 j = i := by
  constructor
  · intro h
    obtain ⟨c, s, b, rfl⟩ := coordinate_surjective w i
    simp only [fixedMask, sparseRestriction, packFields_coordinate, sparseFieldSignal] at h
    split at h
    · contradiction
    · rename_i hc
      split at h
      · rename_i hb
        let d : Fin (remainingClauses w r) := ⟨c.val - forbiddenCount r, by
          have hh := c.isLt; change c.val < variableCount w at hh
          unfold remainingClauses; omega⟩
        refine ⟨freeBitIndex d s ⟨b.val, hb⟩, ?_⟩
        rw [freeEmbedding_freeBitIndex]
        have hd : freeClause w r d = c := by
          apply Fin.ext
          change forbiddenCount r + (c.val - forbiddenCount r) = c.val
          omega
        rw [hd]
      · contradiction
  · rintro ⟨j, rfl⟩
    unfold fixedMask
    rw [sparseRestriction_freeEmbedding]
    rfl

theorem free_coordinate_count (w r : Nat) (hr : r < w) (hr0 : 0 < r) :
    (Finset.univ.filter (fun i : Fin (inputBits w) => fixedMask w r i = false)).card =
      freeBits w r := by
  have he : Finset.univ.filter (fun i : Fin (inputBits w) => fixedMask w r i = false) =
      Finset.univ.image (freeEmbedding w r hr hr0) := by
    ext i
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_image,
      fixedMask_false_iff w r hr hr0]
  rw [he, Finset.card_image_of_injective _ (freeEmbedding_injective w r hr hr0),
    Finset.card_univ, Fintype.card_fin]

/-- Exactly n-L coordinates are fixed by the explicit sparse-helper restriction. -/
theorem fixed_coordinate_count (w r : Nat) (hr : r < w) (hr0 : 0 < r) :
    (∑ i : Fin (inputBits w), indicator (fixedMask w r i)) = inputBits w - freeBits w r := by
  have htotal := Finset.card_filter_add_card_filter_not
    (s := Finset.univ) (fun i : Fin (inputBits w) => fixedMask w r i = true)
  have hcomp (i : Fin (inputBits w)) : (¬ fixedMask w r i = true) ↔
      fixedMask w r i = false := by cases fixedMask w r i <;> simp
  simp only [hcomp, free_coordinate_count w r hr hr0, Finset.card_univ, Fintype.card_fin] at htotal
  rw [Finset.card_filter] at htotal
  change (∑ i : Fin (inputBits w), indicator (fixedMask w r i)) + freeBits w r = inputBits w at htotal
  omega

theorem sparseRestriction_marks (w r : Nat) :
    OpenCircuit.MarksConstants (fixedMask w r) (sparseRestriction w r) := by
  intro i hi
  cases hs : sparseRestriction w r i with
  | constant b => exact ⟨b, rfl⟩
  | wire j b => simp [fixedMask, hs, Signal.isConstant] at hi

end SatLowerBound
