import SatLowerBound.CircuitHistory

namespace SatLowerBound
namespace OpenCircuit

def NoInputTriangles : {n : Nat} → History n → OpenCircuit n → Prop
  | _, _, .output _ => True
  | _, Γ, .gate g i j rest => ¬ Γ.TriangleAt i j ∧ NoInputTriangles (Γ.extend g i j) rest

theorem triangle_improvement {n : Nat} (C : OpenCircuit n) (he : C.EssentialGates)
    (Γ : History n) (hΓ : Γ.Sorted) (hbad : ¬ NoInputTriangles Γ C) :
    ∃ D : OpenCircuit n, D.size = C.size ∧ D.weight ≤ C.weight ∧
      D.predecessorSum < C.predecessorSum ∧ ∀ x, Γ.Valid x → D.eval x = C.eval x := by
  induction C with
  | output s => exact False.elim (hbad True.intro)
  | gate g i j rest ih =>
    by_cases ht : Γ.TriangleAt i j
    · obtain ⟨f, k, l, hw, hs, hv⟩ := Γ.rewrite_triangle hΓ g he.1 i j ht
      refine ⟨.gate f k l rest, rfl, Nat.add_le_add_right hw _,
        Nat.add_lt_add_right hs _, ?_⟩
      intro x hx
      simp only [eval, hv x hx]
    · have hr : ¬ NoInputTriangles (Γ.extend g i j) rest := fun h => hbad ⟨ht, h⟩
      obtain ⟨R, hs, hw, hp, hv⟩ := ih he.2 (Γ.extend g i j) (Γ.sorted_extend hΓ g i j) hr
      refine ⟨.gate g i j R, congrArg (fun t => t + 1) hs,
        Nat.add_le_add_left hw _, Nat.add_lt_add_left hp _, ?_⟩
      intro x hx
      exact hv _ (Γ.valid_extend x hx g i j)

theorem empty_history_sorted (n : Nat) : History.Sorted (fun _ : Fin n => none) := by
  intro k p h
  contradiction

theorem empty_history_valid {n : Nat} (x : Fin n → Bool) :
    History.Valid (fun _ : Fin n => none) x := by
  intro k p h
  contradiction

theorem minimal_no_triangles {n : Nat} (f : (Fin n → Bool) → Bool) (W : Nat)
    (C : OpenCircuit n) (h : Minimal f W C) : NoInputTriangles (fun _ => none) C := by
  by_contra hn
  have hr := C.minimal_reduced f W h
  obtain ⟨D, hs, hw, hp, hv⟩ := C.triangle_improvement (C.reduced_essential hr)
    (fun _ => none) (empty_history_sorted n) hn
  have he (x : Fin n → Bool) : D.eval x = f x :=
    (hv x (empty_history_valid x)).trans (h.2.1 x)
  have hmin := (h.2.2 D (Nat.le_trans hw h.1) he).2 hs
  omega

/-- The manuscript's terminating rewrite argument: size decreases on simplification;
at fixed size, the sum of predecessor indices decreases on triangle rewriting. -/
theorem normalize_by_descent {n : Nat} (C : OpenCircuit n) :
    ∃ D : OpenCircuit n, D.Reduced ∧ NoInputTriangles (fun _ => none) D ∧
      D.size ≤ C.size ∧ D.weight ≤ C.weight ∧ ∀ x, D.eval x = C.eval x := by
  suffices h : ∀ s p, ∀ C : OpenCircuit n, C.size = s → C.predecessorSum = p →
      ∃ D : OpenCircuit n, D.Reduced ∧ NoInputTriangles (fun _ => none) D ∧
        D.size ≤ C.size ∧ D.weight ≤ C.weight ∧ ∀ x, D.eval x = C.eval x from
    h C.size C.predecessorSum C rfl rfl
  intro s
  induction s using Nat.strong_induction_on with
  | h s ihs =>
    intro p
    induction p using Nat.strong_induction_on with
    | h p ihp =>
      intro C hs hp
      by_cases hr : C.Reduced
      · by_cases ht : NoInputTriangles (fun _ => none) C
        · exact ⟨C, hr, ht, Nat.le_refl _, Nat.le_refl _, fun _ => rfl⟩
        · obtain ⟨E, hsize, hweight, hpred, heval⟩ := C.triangle_improvement
            (C.reduced_essential hr) (fun _ => none) (empty_history_sorted n) ht
          obtain ⟨D, hD, htri, hDs, hDw, hDe⟩ := ihp E.predecessorSum
            (by omega) E (hsize.trans hs) rfl
          exact ⟨D, hD, htri, by omega, Nat.le_trans hDw hweight,
            fun x => (hDe x).trans (heval x (empty_history_valid x))⟩
      · obtain ⟨E, hsize, hweight, heval⟩ := smaller_of_not_reduced C hr
        obtain ⟨D, hD, htri, hDs, hDw, hDe⟩ := ihs E.size (by omega)
          E.predecessorSum E rfl rfl
        exact ⟨D, hD, htri, by omega, Nat.le_trans hDw hweight,
          fun x => (hDe x).trans (heval x)⟩

/-- Full shared-circuit normalization, including the input-triangle condition.
Both resources are bounded by those of the given circuit. -/
theorem normalize_full_open {n : Nat} (C : OpenCircuit n) :
    ∃ D : OpenCircuit n, D.Reduced ∧ NoInputTriangles (fun _ => none) D ∧
      D.size ≤ C.size ∧ D.weight ≤ C.weight ∧ ∀ x, D.eval x = C.eval x := by
  exact normalize_by_descent C

theorem normalize_full {n : Nat} (C : Circuit n) :
    ∃ D : OpenCircuit n, D.Reduced ∧ NoInputTriangles (fun _ => none) D ∧
      D.size ≤ C.size ∧ D.weight ≤ C.weight ∧ ∀ x, D.eval x = C.eval x := by
  obtain ⟨D, hr, ht, hs, hw, he⟩ := normalize_full_open (ofCircuit C)
  refine ⟨D, hr, ht, ?_, ?_, ?_⟩
  · simpa only [ofCircuit_size] using hs
  · simpa only [ofCircuit_weight] using hw
  · intro x
    exact (he x).trans (ofCircuit_eval C x)

end OpenCircuit
end SatLowerBound
