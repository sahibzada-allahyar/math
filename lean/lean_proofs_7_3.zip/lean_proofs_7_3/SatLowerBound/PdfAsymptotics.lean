import SatLowerBound.Logarithmic

namespace SatLowerBound
namespace PdfAsymptotics

noncomputable def q (w : Nat) : ℝ := Real.logb 2 (inputBits w)

theorem log_two_lower : (1 / 2 : ℝ) ≤ Real.log 2 := by
  have h := Real.one_sub_inv_le_log_of_pos (show (0 : ℝ) < 2 by norm_num)
  norm_num at h ⊢
  exact h

theorem logb_one_sub_bound (u : ℝ) (hu : 0 ≤ u) (hu2 : u ≤ 1 / 2) :
    |Real.logb 2 (1 - u)| ≤ 4 * u := by
  have hp : 0 < 1 - u := by linarith
  have hi : (1 - u)⁻¹ ≤ 1 + 2 * u := by
    rw [inv_eq_one_div]
    apply (div_le_iff₀ hp).mpr
    nlinarith
  have hlo := Real.one_sub_inv_le_log_of_pos hp
  have hhi : Real.log (1 - u) ≤ 0 := Real.log_nonpos (by linarith) (by linarith)
  have h2 := log_two_lower
  have h2p : 0 < Real.log 2 := by linarith
  have hd : Real.logb 2 (1 - u) * Real.log 2 = Real.log (1 - u) := by
    simp only [Real.logb, div_mul_cancel₀ _ (ne_of_gt h2p)]
  have hbn : Real.logb 2 (1 - u) ≤ 0 := div_nonpos_of_nonpos_of_nonneg hhi h2p.le
  rw [abs_of_nonpos hbn]
  nlinarith

theorem inverse_power_bounds (w : Nat) (hw : 1 ≤ w) :
    0 < ((2 : ℝ) ^ w)⁻¹ ∧ ((2 : ℝ) ^ w)⁻¹ ≤ 1 / 2 := by
  have hp : (2 : ℝ) ≤ 2 ^ w := by
    exact_mod_cast Nat.pow_le_pow_right (n := 2) (by decide) hw
  constructor
  · positivity
  · rw [inv_eq_one_div]
    apply (div_le_iff₀ (by positivity : (0 : ℝ) < 2 ^ w)).mpr
    linarith

/-- PDF equation (32), with its exponentially small error displayed exactly. -/
theorem q_exact (w : Nat) (hw : 1 ≤ w) :
    q w = (w : ℝ) + Real.logb 2 ((w : ℝ) + 1) + Real.logb 2 3 +
      Real.logb 2 (1 - ((2 : ℝ) ^ w)⁻¹) := by
  have hp : (0 : ℝ) < 2 ^ w := by positivity
  have hu := inverse_power_bounds w hw
  have hs : 0 < 1 - ((2 : ℝ) ^ w)⁻¹ := by linarith [hu.2]
  have hn : (inputBits w : ℝ) = 3 * (2 : ℝ) ^ w *
      (1 - ((2 : ℝ) ^ w)⁻¹) * ((w : ℝ) + 1) := by
    simp only [inputBits, variableCount, Nat.cast_mul, Nat.cast_ofNat,
      Nat.cast_sub (Nat.one_le_two_pow), Nat.cast_pow, Nat.cast_one, Nat.cast_add]
    field_simp
  unfold q
  rw [hn]
  rw [Real.logb_mul (by positivity) (by positivity),
    Real.logb_mul (by positivity) (ne_of_gt hs), Real.logb_mul (by norm_num) (ne_of_gt hp)]
  rw [Real.logb_pow, Real.logb_self_eq_one (by norm_num : (1 : ℝ) < 2), mul_one]
  ring

theorem q_expansion_bound (w : Nat) (hw : 1 ≤ w) :
    |q w - ((w : ℝ) + Real.logb 2 ((w : ℝ) + 1) + Real.logb 2 3)| ≤
      4 * ((2 : ℝ) ^ w)⁻¹ := by
  rw [q_exact w hw]
  have he : (w : ℝ) + Real.logb 2 ((w : ℝ) + 1) + Real.logb 2 3 +
      Real.logb 2 (1 - ((2 : ℝ) ^ w)⁻¹) -
      ((w : ℝ) + Real.logb 2 ((w : ℝ) + 1) + Real.logb 2 3) =
      Real.logb 2 (1 - ((2 : ℝ) ^ w)⁻¹) := by ring
  rw [he]
  exact logb_one_sub_bound _ (inverse_power_bounds w hw).1.le (inverse_power_bounds w hw).2

theorem q_expansion_bigO :
    Asymptotics.IsBigO Filter.atTop
      (fun w : Nat => q w - ((w : ℝ) + Real.logb 2 ((w : ℝ) + 1) + Real.logb 2 3))
      (fun w : Nat => ((2 : ℝ) ^ w)⁻¹) := by
  apply Asymptotics.isBigO_iff.mpr
  refine ⟨4, ?_⟩
  filter_upwards [Filter.eventually_ge_atTop (1 : Nat)] with w hw
  simpa only [Real.norm_eq_abs, abs_of_pos (inverse_power_bounds w hw).1] using q_expansion_bound w hw

theorem logb_three_bounds : 0 ≤ Real.logb 2 3 ∧ Real.logb 2 3 ≤ 2 := by
  constructor
  · exact div_nonneg (Real.log_nonneg (by norm_num)) (Real.log_nonneg (by norm_num))
  · have h := Real.logb_le_logb_of_le (b := 2) (by norm_num)
      (show (0 : ℝ) < 3 by norm_num) (show (3 : ℝ) ≤ 2 ^ 2 by norm_num)
    change Real.logb 2 3 ≤ Real.logb 2 ((2 : ℝ) ^ 2) at h
    rw [Real.logb_pow, Real.logb_self_eq_one (by norm_num : (1 : ℝ) < 2), mul_one] at h
    exact h

theorem log_successor_bounds (w : Nat) (hw : 1 ≤ w) :
    Real.logb 2 (w : ℝ) ≤ Real.logb 2 ((w : ℝ) + 1) ∧
    Real.logb 2 ((w : ℝ) + 1) ≤ Real.logb 2 (w : ℝ) + 1 := by
  have hw1 : (1 : ℝ) ≤ w := by exact_mod_cast hw
  constructor
  · exact Real.logb_le_logb_of_le (by norm_num) (by linarith) (by linarith)
  · have h := Real.logb_le_logb_of_le (b := 2) (by norm_num)
      (show (0 : ℝ) < (w : ℝ) + 1 by positivity) (show (w : ℝ) + 1 ≤ 2 * w by linarith)
    rw [Real.logb_mul (by norm_num) (by linarith), Real.logb_self_eq_one (by norm_num : (1 : ℝ) < 2)] at h
    linarith

theorem q_comparison (w : Nat) (hw : 8 ≤ w) :
    (w : ℝ) ≤ q w ∧ q w ≤ 3 * w := by
  obtain ⟨hl, hu⟩ := encoded_log_bounds w hw
  have hk : (logarithmicOffset w : ℝ) ≤ (w : ℝ) - 1 := by
    have h := (logarithmic_parameters w hw).2.1
    have hn : logarithmicOffset w + 1 ≤ w := by omega
    have hnR : (logarithmicOffset w : ℝ) + 1 ≤ w := by exact_mod_cast hn
    linarith
  have hw8 : (8 : ℝ) ≤ w := by exact_mod_cast hw
  exact ⟨hl, by dsimp [q]; linarith⟩

theorem log_q_comparison (w : Nat) (hw : 8 ≤ w) :
    1 ≤ Real.logb 2 (w : ℝ) ∧
    Real.logb 2 (w : ℝ) ≤ Real.logb 2 (q w) ∧
    Real.logb 2 (q w) ≤ Real.logb 2 (w : ℝ) + 2 := by
  have hw8 : (8 : ℝ) ≤ w := by exact_mod_cast hw
  have hq := q_comparison w hw
  have hlo := Real.logb_le_logb_of_le (b := 2) (by norm_num)
    (show (0 : ℝ) < 2 by norm_num) (show (2 : ℝ) ≤ w by linarith)
  rw [Real.logb_self_eq_one (by norm_num : (1 : ℝ) < 2)] at hlo
  refine ⟨hlo, Real.logb_le_logb_of_le (by norm_num) (by linarith) hq.1, ?_⟩
  have hu := Real.logb_le_logb_of_le (b := 2) (by norm_num)
    (show 0 < q w by linarith [hq.1]) (show q w ≤ 2 ^ 2 * (w : ℝ) by linarith [hq.2])
  rw [Real.logb_mul (by norm_num) (by linarith), Real.logb_pow,
    Real.logb_self_eq_one (by norm_num : (1 : ℝ) < 2)] at hu
  norm_num at hu
  linarith

theorem q_minus_w_log_bound (w : Nat) (hw : 8 ≤ w) :
    |q w - (w : ℝ) - Real.logb 2 (w : ℝ)| ≤ 5 := by
  have he := q_expansion_bound w (by omega)
  have hi := (inverse_power_bounds w (by omega)).2
  have hl := log_successor_bounds w (by omega)
  have h3 := logb_three_bounds
  rw [abs_le] at he ⊢
  constructor <;> linarith

/-- PDF equation (32): q=w+O(log_2 w). -/
theorem q_minus_w_bigO :
    Asymptotics.IsBigO Filter.atTop (fun w : Nat => q w - (w : ℝ))
      (fun w : Nat => Real.logb 2 (w : ℝ)) := by
  apply Asymptotics.isBigO_iff.mpr
  refine ⟨6, ?_⟩
  filter_upwards [Filter.eventually_ge_atTop (8 : Nat)] with w hw
  have he := q_minus_w_log_bound w hw
  have hl := (log_q_comparison w hw).1
  have hq := (q_comparison w hw).1
  rw [Real.norm_eq_abs, Real.norm_eq_abs, abs_of_nonneg (by linarith : 0 ≤ q w - (w : ℝ)),
    abs_of_nonneg (by linarith : 0 ≤ Real.logb 2 (w : ℝ))]
  rw [abs_le] at he
  linarith

/-- The inversion immediately following PDF equation (32). -/
theorem inverse_log_expansion_bound (w : Nat) (hw : 8 ≤ w) :
    |(w : ℝ) - q w + Real.logb 2 (q w)| ≤ 7 := by
  have he := q_minus_w_log_bound w hw
  have hl := log_q_comparison w hw
  rw [abs_le] at he ⊢
  constructor <;> linarith

theorem inverse_log_expansion_bigO :
    Asymptotics.IsBigO Filter.atTop
      (fun w : Nat => (w : ℝ) - q w + Real.logb 2 (q w)) (fun _ => (1 : ℝ)) := by
  apply Asymptotics.isBigO_iff.mpr
  refine ⟨7, ?_⟩
  filter_upwards [Filter.eventually_ge_atTop (8 : Nat)] with w hw
  simpa only [Real.norm_eq_abs, abs_one, mul_one] using inverse_log_expansion_bound w hw

theorem log_q_difference (w : Nat) (hw : 8 ≤ w) :
    (Real.logb 2 (q w) - Real.logb 2 (w : ℝ)) * w ≤ 2 * (q w - w) := by
  have hw8 : (8 : ℝ) ≤ w := by exact_mod_cast hw
  have hq := q_comparison w hw
  have hl := log_q_comparison w hw
  have hw0 : (0 : ℝ) < w := by linarith
  have hq0 : 0 < q w := by linarith [hq.1]
  have hlog := Real.log_le_sub_one_of_pos (div_pos hq0 hw0)
  rw [Real.log_div (ne_of_gt hq0) (ne_of_gt hw0)] at hlog
  have hb : (Real.log (q w) - Real.log w + 1) * w ≤ q w :=
    (le_div_iff₀ hw0).mp (by linarith)
  have h2 := log_two_lower
  have h2p : 0 < Real.log 2 := by linarith
  have he : (Real.logb 2 (q w) - Real.logb 2 (w : ℝ)) * Real.log 2 =
      Real.log (q w) - Real.log w := by
    simp only [Real.logb]
    field_simp
  have hnon : 0 ≤ (Real.logb 2 (q w) - Real.logb 2 (w : ℝ)) * w := by
    exact mul_nonneg (by linarith [hl.2.1]) hw0.le
  have hscale := mul_le_mul_of_nonneg_left h2 hnon
  have hew := congrArg (fun x : ℝ => x * w) he
  nlinarith

/-- The first, sharper error estimate in PDF equation (33). -/
theorem ratio_expansion_bound (w : Nat) (hw : 8 ≤ w) :
    |Real.logb 2 (w : ℝ) / ((w : ℝ) + 1) - Real.logb 2 (q w) / q w| ≤
      39 * (Real.logb 2 (q w)) ^ 2 / (q w) ^ 2 := by
  let W : ℝ := w
  let Q := q w
  let H := Real.logb 2 Q
  let L := Real.logb 2 W
  have hw8 : 8 ≤ W := by dsimp [W]; exact_mod_cast hw
  have hq : W ≤ Q ∧ Q ≤ 3 * W := q_comparison w hw
  have hl : 1 ≤ L ∧ L ≤ H ∧ H ≤ L + 2 := log_q_comparison w hw
  have hd : (H - L) * W ≤ 2 * (Q - W) := log_q_difference w hw
  have hg := q_minus_w_log_bound w hw
  change |Q - W - L| ≤ 5 at hg
  rw [abs_le] at hg
  have hgap : Q - W ≤ 6 * H := by linarith
  have hm := mul_le_mul_of_nonneg_left hgap (by linarith : 0 ≤ H)
  have hm2 := mul_le_mul_of_nonneg_right hl.2.1 (by linarith : 0 ≤ Q - W)
  have hs : H ≤ H ^ 2 := by nlinarith
  have hnum : |L * Q - H * (W + 1)| ≤ 13 * H ^ 2 := by
    rw [abs_le]
    constructor <;> nlinarith
  have hQ0 : 0 < Q := by linarith
  have hW0 : 0 < W + 1 := by linarith
  have he : |L / (W + 1) - H / Q| = |L * Q - H * (W + 1)| / ((W + 1) * Q) := by
    rw [div_sub_div _ _ (ne_of_gt hW0) (ne_of_gt hQ0), abs_div,
      abs_of_pos (mul_pos hW0 hQ0), mul_comm (W + 1) H]
  change |L / (W + 1) - H / Q| ≤ 39 * H ^ 2 / Q ^ 2
  rw [he]
  apply le_trans (div_le_div_of_nonneg_right hnum (mul_pos hW0 hQ0).le)
  apply (div_le_div_iff₀ (mul_pos hW0 hQ0) (sq_pos_of_pos hQ0)).mpr
  have hscale := mul_le_mul_of_nonneg_left (show Q ≤ 3 * (W + 1) by linarith)
    (show 0 ≤ 13 * H ^ 2 * Q by positivity)
  nlinarith

theorem ratio_expansion_bigO :
    Asymptotics.IsBigO Filter.atTop
      (fun w : Nat => Real.logb 2 (w : ℝ) / ((w : ℝ) + 1) - Real.logb 2 (q w) / q w)
      (fun w : Nat => (Real.logb 2 (q w)) ^ 2 / (q w) ^ 2) := by
  apply Asymptotics.isBigO_iff.mpr
  refine ⟨39, ?_⟩
  filter_upwards [Filter.eventually_ge_atTop (8 : Nat)] with w hw
  have h := ratio_expansion_bound w hw
  rw [Real.norm_eq_abs, Real.norm_eq_abs,
    abs_of_nonneg (div_nonneg (sq_nonneg (Real.logb 2 (q w))) (sq_nonneg (q w)))]
  simpa only [mul_div_assoc] using h

theorem log_q_square_bound (w : Nat) (hw : 8 ≤ w) :
    (Real.logb 2 (q w)) ^ 2 ≤ 9 * q w := by
  have hw8 : (8 : ℝ) ≤ w := by exact_mod_cast hw
  have hq := q_comparison w hw
  have hl := log_q_comparison w hw
  have hk : Real.logb 2 (w : ℝ) ≤ logarithmicOffset w := by
    rw [logarithmicOffset_eq_ceiling]
    exact Nat.le_ceil _
  have hs : (logarithmicOffset w : ℝ) * logarithmicOffset w ≤ 4 * w := by
    exact_mod_cast logarithmic_offset_square w hw
  have hk0 : (0 : ℝ) ≤ logarithmicOffset w := Nat.cast_nonneg _
  have hH0 : 0 ≤ Real.logb 2 (q w) := by linarith [hl.1, hl.2.1]
  nlinarith [sq_nonneg ((logarithmicOffset w : ℝ) - 2)]

theorem ratio_coarse_bound (w : Nat) (hw : 8 ≤ w) :
    |Real.logb 2 (w : ℝ) / ((w : ℝ) + 1) - Real.logb 2 (q w) / q w| ≤ 351 / q w := by
  have hq : 0 < q w := by
    have hw8 : (8 : ℝ) ≤ w := by exact_mod_cast hw
    linarith [(q_comparison w hw).1]
  apply le_trans (ratio_expansion_bound w hw)
  apply (div_le_div_iff₀ (sq_pos_of_pos hq) hq).mpr
  have h := mul_le_mul_of_nonneg_right (log_q_square_bound w hw) hq.le
  nlinarith

/-- The O(1/q) simplification in PDF equation (33). -/
theorem ratio_coarse_bigO :
    Asymptotics.IsBigO Filter.atTop
      (fun w : Nat => Real.logb 2 (w : ℝ) / ((w : ℝ) + 1) - Real.logb 2 (q w) / q w)
      (fun w : Nat => 1 / q w) := by
  apply Asymptotics.isBigO_iff.mpr
  refine ⟨351, ?_⟩
  filter_upwards [Filter.eventually_ge_atTop (8 : Nat)] with w hw
  have hq : 0 < q w := by
    have hw8 : (8 : ℝ) ≤ w := by exact_mod_cast hw
    linarith [(q_comparison w hw).1]
  simpa only [Real.norm_eq_abs, abs_of_pos (one_div_pos.mpr hq), mul_one_div]
    using ratio_coarse_bound w hw

theorem real_length (w : Nat) : (inputBits w : ℝ) =
    3 * (variableCount w : ℝ) * ((w : ℝ) + 1) := by
  simp only [inputBits, Nat.cast_mul, Nat.cast_ofNat, Nat.cast_add, Nat.cast_one]

/-- The first error term in PDF equation (34), with an explicit constant. -/
theorem scaled_log_expansion_bound (w : Nat) (hw : 8 ≤ w) :
    |4 * (variableCount w : ℝ) * Real.logb 2 (w : ℝ) -
      (4 / 3 : ℝ) * inputBits w * Real.logb 2 (q w) / q w| ≤ 468 * inputBits w / q w := by
  have hw0 : (0 : ℝ) < (w : ℝ) + 1 := by positivity
  have he : 4 * (variableCount w : ℝ) * Real.logb 2 (w : ℝ) -
      (4 / 3 : ℝ) * inputBits w * Real.logb 2 (q w) / q w =
      (4 / 3 : ℝ) * inputBits w *
        (Real.logb 2 (w : ℝ) / ((w : ℝ) + 1) - Real.logb 2 (q w) / q w) := by
    rw [real_length]
    field_simp
  rw [he, abs_mul, abs_of_nonneg (by positivity : (0 : ℝ) ≤ (4 / 3 : ℝ) * inputBits w)]
  have h := mul_le_mul_of_nonneg_left (ratio_coarse_bound w hw)
    (show (0 : ℝ) ≤ (4 / 3 : ℝ) * inputBits w by positivity)
  convert h using 1
  ring

theorem scaled_log_expansion_bigO :
    Asymptotics.IsBigO Filter.atTop
      (fun w : Nat => 4 * (variableCount w : ℝ) * Real.logb 2 (w : ℝ) -
        (4 / 3 : ℝ) * inputBits w * Real.logb 2 (q w) / q w)
      (fun w : Nat => (inputBits w : ℝ) / q w) := by
  apply Asymptotics.isBigO_iff.mpr
  refine ⟨468, ?_⟩
  filter_upwards [Filter.eventually_ge_atTop (8 : Nat)] with w hw
  have hq : 0 < q w := by
    have hw8 : (8 : ℝ) ≤ w := by exact_mod_cast hw
    linarith [(q_comparison w hw).1]
  simpa only [Real.norm_eq_abs, abs_of_nonneg (div_nonneg (Nat.cast_nonneg _) hq.le),
    mul_div_assoc] using scaled_log_expansion_bound w hw

theorem variable_count_scale (w : Nat) (hw : 8 ≤ w) :
    (variableCount w : ℝ) ≤ (inputBits w : ℝ) / q w := by
  have hq := q_comparison w hw
  have hw8 : (8 : ℝ) ≤ w := by exact_mod_cast hw
  apply (le_div_iff₀ (by linarith [hq.1] : 0 < q w)).mpr
  rw [real_length]
  have h := mul_le_mul_of_nonneg_left hq.2 (Nat.cast_nonneg (variableCount w) : (0 : ℝ) ≤ _)
  have hm0 : (0 : ℝ) ≤ variableCount w := Nat.cast_nonneg _
  nlinarith

/-- The second error conversion in PDF equation (34). -/
theorem variable_count_bigO :
    Asymptotics.IsBigO Filter.atTop (fun w : Nat => (variableCount w : ℝ))
      (fun w : Nat => (inputBits w : ℝ) / q w) := by
  apply Asymptotics.isBigO_iff.mpr
  refine ⟨1, ?_⟩
  filter_upwards [Filter.eventually_ge_atTop (8 : Nat)] with w hw
  have hq : 0 < q w := by
    have hw8 : (8 : ℝ) ≤ w := by exact_mod_cast hw
    linarith [(q_comparison w hw).1]
  simpa only [Real.norm_eq_abs, abs_of_nonneg (show (0 : ℝ) ≤ variableCount w from Nat.cast_nonneg _),
    abs_of_nonneg (div_nonneg (Nat.cast_nonneg _) hq.le), one_mul] using variable_count_scale w hw

theorem offset_bounds (w : Nat) (hw : 8 ≤ w) :
    Real.logb 2 (w : ℝ) ≤ logarithmicOffset w ∧
    (logarithmicOffset w : ℝ) ≤ Real.logb 2 (w : ℝ) + 1 := by
  rw [logarithmicOffset_eq_ceiling]
  exact ⟨Nat.le_ceil _, (Nat.ceil_lt_add_one (by linarith [(log_q_comparison w hw).1])).le⟩

/-- PDF equation (31), with its O(m) loss made explicit. -/
theorem width_lower_bound (w : Nat) (hw : 8 ≤ w)
    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    (7 / 3 : ℝ) * inputBits w - 4 * variableCount w * Real.logb 2 (w : ℝ) -
      28 * variableCount w ≤ (C.size : ℝ) := by
  have hint : 7 * (inputBits w : ℝ) ≤ 3 * C.size +
      12 * (variableCount w : ℝ) * logarithmicOffset w + 72 * variableCount w := by
    exact_mod_cast logarithmic_integer_bound w hw C hc
  have hk := mul_le_mul_of_nonneg_left (offset_bounds w hw).2
    (show (0 : ℝ) ≤ 12 * (variableCount w : ℝ) by positivity)
  nlinarith

/-- The PDF's derivation through equations (31), (33), and (34). -/
theorem pdf_logarithmic_lower_bound (w : Nat) (hw : 8 ≤ w)
    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    (7 / 3 : ℝ) * inputBits w -
      (4 / 3 : ℝ) * inputBits w * Real.logb 2 (q w) / q w -
      496 * inputBits w / q w ≤ (C.size : ℝ) := by
  have hwid := width_lower_bound w hw C hc
  have herr := scaled_log_expansion_bound w hw
  have hm := variable_count_scale w hw
  rw [abs_le] at herr
  simp only [mul_div_assoc] at herr ⊢
  linarith

def radius (w : Nat) : Nat := w - logarithmicOffset w + 2

theorem radius_real (w : Nat) (hw : 8 ≤ w) :
    (radius w : ℝ) = (w : ℝ) - logarithmicOffset w + 2 := by
  have hk : logarithmicOffset w ≤ w := by have := (logarithmic_parameters w hw).2.1; omega
  simp only [radius, Nat.cast_add, Nat.cast_sub hk, Nat.cast_ofNat]

theorem radius_error_bound (w : Nat) (hw : 8 ≤ w) :
    |(radius w : ℝ) - ((w : ℝ) - Real.logb 2 (w : ℝ))| ≤ 2 := by
  rw [radius_real w hw, abs_le]
  have h := offset_bounds w hw
  constructor <;> linarith

/-- The parameter choice in PDF equation (30). -/
theorem radius_expansion_bigO :
    Asymptotics.IsBigO Filter.atTop
      (fun w : Nat => (radius w : ℝ) - ((w : ℝ) - Real.logb 2 (w : ℝ)))
      (fun _ => (1 : ℝ)) := by
  apply Asymptotics.isBigO_iff.mpr
  refine ⟨2, ?_⟩
  filter_upwards [Filter.eventually_ge_atTop (8 : Nat)] with w hw
  simpa only [Real.norm_eq_abs, abs_one, mul_one] using radius_error_bound w hw

theorem radius_power_bound (w : Nat) (hw : 8 ≤ w) :
    (2 : ℝ) ^ radius w ≤ 4 * ((2 : ℝ) ^ w / w) := by
  have hk := (logarithmic_parameters w hw).2.1
  have he : logarithmicOffset w + radius w = w + 2 := by unfold radius; omega
  have h := Nat.mul_le_mul_right (2 ^ radius w) (Nat.le_pow_clog (b := 2) (by decide) w)
  change w * 2 ^ radius w ≤ 2 ^ logarithmicOffset w * 2 ^ radius w at h
  rw [← Nat.pow_add, he, Nat.pow_add] at h
  have hR : (w : ℝ) * 2 ^ radius w ≤ (2 : ℝ) ^ w * 4 := by exact_mod_cast h
  have hw0 : (0 : ℝ) < w := by exact_mod_cast (by omega : 0 < w)
  rw [← mul_div_assoc]
  apply (le_div_iff₀ hw0).mpr
  nlinarith

theorem radius_power_bigO :
    Asymptotics.IsBigO Filter.atTop (fun w : Nat => (2 : ℝ) ^ radius w)
      (fun w : Nat => (2 : ℝ) ^ w / w) := by
  apply Asymptotics.isBigO_iff.mpr
  refine ⟨4, ?_⟩
  filter_upwards [Filter.eventually_ge_atTop (8 : Nat)] with w hw
  have hw0 : (0 : ℝ) < w := by exact_mod_cast (by omega : 0 < w)
  simpa only [Real.norm_eq_abs, abs_of_pos (pow_pos (by norm_num : (0 : ℝ) < 2) (radius w)),
    abs_of_pos (div_pos (pow_pos (by norm_num : (0 : ℝ) < 2) w) hw0)] using radius_power_bound w hw

theorem radius_helper_bound (w : Nat) (hw : 8 ≤ w) :
    (forbiddenCount (radius w) : ℝ) ≤ 5 * ((variableCount w : ℝ) / w) := by
  have h : (w : ℝ) * forbiddenCount (radius w) ≤ 5 * (variableCount w : ℝ) := by
    exact_mod_cast logarithmic_helper_budget w hw
  have hw0 : (0 : ℝ) < w := by exact_mod_cast (by omega : 0 < w)
  rw [← mul_div_assoc]
  apply (le_div_iff₀ hw0).mpr
  nlinarith

theorem radius_helper_bigO :
    Asymptotics.IsBigO Filter.atTop (fun w : Nat => (forbiddenCount (radius w) : ℝ))
      (fun w : Nat => (variableCount w : ℝ) / w) := by
  apply Asymptotics.isBigO_iff.mpr
  refine ⟨5, ?_⟩
  filter_upwards [Filter.eventually_ge_atTop (8 : Nat)] with w hw
  simpa only [Real.norm_eq_abs,
    abs_of_nonneg (show (0 : ℝ) ≤ forbiddenCount (radius w) from Nat.cast_nonneg _),
    abs_of_nonneg (show (0 : ℝ) ≤ (variableCount w : ℝ) / w from
      div_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _))]
    using radius_helper_bound w hw

noncomputable def pdfError (w : Nat) : ℝ := 496 * inputBits w / q w

theorem pdf_error_bigO : Asymptotics.IsBigO Filter.atTop pdfError
    (fun w : Nat => (inputBits w : ℝ) / Real.logb 2 (inputBits w)) := by
  apply Asymptotics.isBigO_iff.mpr
  refine ⟨496, Filter.Eventually.of_forall ?_⟩
  intro w
  simp only [pdfError, q, mul_div_assoc, norm_mul]
  norm_num

/-- The PDF asymptotic theorem obtained through its displayed expansions (30)--(34). -/
theorem pdf_logarithmic_asymptotic : LogarithmicAsymptoticCertificate := by
  refine ⟨pdfError, pdf_error_bigO, ?_⟩
  filter_upwards [Filter.eventually_ge_atTop (8 : Nat)] with w hw
  intro C hc
  exact pdf_logarithmic_lower_bound w hw C hc

end PdfAsymptotics
end SatLowerBound
