import SatLowerBound.Mod3Degree
import SatLowerBound.ResidualDegree

namespace SatLowerBound

def leftBits {n m : Nat} (x : Fin (n + m) → Bool) : Fin n → Bool :=
  fun i => x ⟨i.val, Nat.lt_of_lt_of_le i.isLt (Nat.le_add_right n m)⟩

def rightBits {n m : Nat} (x : Fin (n + m) → Bool) : Fin m → Bool :=
  fun i => x ⟨n + i.val, Nat.add_lt_add_left i.isLt n⟩

namespace BPoly

/-- Multiplication on disjoint variable sets, with the left variables first. -/
def tensor {n : Nat} (p : BPoly n) : {m : Nat} → BPoly m → BPoly (n + m)
  | 0, .constant b => select b p
  | _ + 1, .node q s => .node (tensor p q) (tensor p s)

theorem eval_tensor {n m : Nat} (p : BPoly n) (q : BPoly m)
    (x : Fin (n + m) → Bool) :
    (p.tensor q).eval x = (p.eval (leftBits x) && q.eval (rightBits x)) := by
  induction q with
  | constant b =>
    simp only [tensor, eval_select, eval]
    have h : leftBits x = x := rfl
    rw [h, Bool.and_comm]
  | @node m q s ihq ihs =>
    simp only [tensor, eval, ihq, ihs]
    have hl : leftBits (fun i : Fin (n + m) => x i.castSucc) = leftBits x := rfl
    have hr : rightBits (fun i : Fin (n + m) => x i.castSucc) =
        (fun i : Fin m => rightBits x i.castSucc) := rfl
    have ht : rightBits x (Fin.last m) = x (Fin.last (n + m)) := rfl
    rw [hl, hr, ht]
    cases p.eval (leftBits x) <;>
      cases q.eval (fun i => rightBits x i.castSucc) <;>
      cases s.eval (fun i => rightBits x i.castSucc) <;>
      cases x (Fin.last (n + m)) <;> rfl

theorem top_select {n : Nat} (b : Bool) (p : BPoly n) :
    (select b p).topCoefficient = (b && p.topCoefficient) := by
  cases b <;> simp [select, top_zero]

theorem top_tensor {n m : Nat} (p : BPoly n) (q : BPoly m) :
    (p.tensor q).topCoefficient = (p.topCoefficient && q.topCoefficient) := by
  induction q with
  | constant b => simp only [tensor, top_select, topCoefficient, Bool.and_comm]
  | node q s ihq ihs => exact ihs

def disjointOr {n m : Nat} (p : BPoly n) (q : BPoly m) : BPoly (n + m) :=
  ((p.tensor (one m)).add ((one n).tensor q)).add (p.tensor q)

theorem eval_disjointOr {n m : Nat} (p : BPoly n) (q : BPoly m)
    (x : Fin (n + m) → Bool) :
    (p.disjointOr q).eval x = (p.eval (leftBits x) || q.eval (rightBits x)) := by
  simp only [disjointOr, eval_add, eval_tensor, eval_one, Bool.and_true, Bool.true_and]
  cases p.eval (leftBits x) <;> cases q.eval (rightBits x) <;> rfl

theorem top_disjointOr {n m : Nat} (p : BPoly n) (q : BPoly m)
    (hn : 0 < n) (hm : 0 < m) :
    (p.disjointOr q).topCoefficient = (p.topCoefficient && q.topCoefficient) := by
  obtain ⟨n, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hn)
  obtain ⟨m, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (Nat.ne_of_gt hm)
  simp only [disjointOr, top_add, top_tensor, top_one, Bool.and_false, Bool.false_and,
    Bool.false_xor]

theorem full_degree_and {n m : Nat} (f : (Fin n → Bool) → Bool)
    (g : (Fin m → Bool) → Bool)
    (hf : (ofFunction n f).topCoefficient = true)
    (hg : (ofFunction m g).topCoefficient = true) :
    (ofFunction (n + m) (fun x => f (leftBits x) && g (rightBits x))).topCoefficient = true := by
  have he : ofFunction (n + m) (fun x => f (leftBits x) && g (rightBits x)) =
      (ofFunction n f).tensor (ofFunction m g) := by
    apply ext
    intro x
    simp only [eval_ofFunction, eval_tensor]
  rw [he, top_tensor, hf, hg]
  rfl

theorem full_degree_or {n m : Nat} (f : (Fin n → Bool) → Bool)
    (g : (Fin m → Bool) → Bool) (hn : 0 < n) (hm : 0 < m)
    (hf : (ofFunction n f).topCoefficient = true)
    (hg : (ofFunction m g).topCoefficient = true) :
    (ofFunction (n + m) (fun x => f (leftBits x) || g (rightBits x))).topCoefficient = true := by
  have he : ofFunction (n + m) (fun x => f (leftBits x) || g (rightBits x)) =
      (ofFunction n f).disjointOr (ofFunction m g) := by
    apply ext
    intro x
    simp only [eval_ofFunction, eval_disjointOr]
  rw [he, top_disjointOr _ _ hn hm, hf, hg]
  rfl

end BPoly

/-- A genuine read-once tree: each branch partitions its input coordinates. -/
inductive ReadOnce : Nat → Type where
  | leaf {n : Nat} (f : (Fin n → Bool) → Bool) : ReadOnce n
  | branch {n m : Nat} (isOr : Bool) (left : ReadOnce n) (right : ReadOnce m) :
      ReadOnce (n + m)

namespace ReadOnce

def eval : {n : Nat} → ReadOnce n → (Fin n → Bool) → Bool
  | _, .leaf f, x => f x
  | _, .branch isOr a b, x =>
      if isOr then a.eval (leftBits x) || b.eval (rightBits x)
      else a.eval (leftBits x) && b.eval (rightBits x)

def blocks : {n : Nat} → ReadOnce n → Nat
  | _, .leaf _ => 1
  | _, .branch _ a b => a.blocks + b.blocks

def FullLeaves : {n : Nat} → ReadOnce n → Prop
  | n, .leaf f => 0 < n ∧ (BPoly.ofFunction n f).topCoefficient = true
  | _, .branch _ a b => a.FullLeaves ∧ b.FullLeaves

theorem inputs_positive {n : Nat} (T : ReadOnce n) (h : T.FullLeaves) : 0 < n := by
  induction T with
  | leaf f => exact h.1
  | branch isOr a b iha ihb => have := iha h.1; omega

theorem full_degree {n : Nat} (T : ReadOnce n) (h : T.FullLeaves) :
    (BPoly.ofFunction n T.eval).topCoefficient = true := by
  induction T with
  | leaf f => exact h.2
  | branch isOr a b iha ihb =>
    cases isOr
    · exact BPoly.full_degree_and a.eval b.eval (iha h.1) (ihb h.2)
    · exact BPoly.full_degree_or a.eval b.eval (a.inputs_positive h.1)
        (b.inputs_positive h.2) (iha h.1) (ihb h.2)

theorem nonlinear_lower_bound {n : Nat} (T : ReadOnce n) (h : T.FullLeaves)
    (C : Circuit n) (hc : C.Computes T.eval) : n ≤ C.nonlinearCount + 1 :=
  C.nonlinear_lower_bound _ hc (T.full_degree h)

end ReadOnce
end SatLowerBound
