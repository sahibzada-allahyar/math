import SatLowerBound.PropagationBirths

namespace SatLowerBound

def Table.blocksLeft (g : Table) (b : Bool) : Bool := g.eval b false == g.eval b true
def Table.blocksRight (g : Table) (b : Bool) : Bool := g.eval false b == g.eval true b

theorem Table.left_partition (g : Table) (h : g.essential = true) :
    indicator g.parity + indicator (g.blocksLeft false) + indicator (g.blocksLeft true) = 1 := by
  revert h
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem Table.right_partition (g : Table) (h : g.essential = true) :
    indicator g.parity + indicator (g.blocksRight false) + indicator (g.blocksRight true) = 1 := by
  revert h
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem Table.blocksLeft_partial (g : Table) (b : Bool) (v : Option Bool)
    (h : g.blocksLeft b = true) : (g.partial (some b) v).isSome = true := by
  have he : g.eval b false = g.eval b true := by simpa [blocksLeft] using h
  cases v with
  | none => simp [Table.partial, he]
  | some c => rfl

theorem Table.blocksRight_partial (g : Table) (b : Bool) (v : Option Bool)
    (h : g.blocksRight b = true) : (g.partial v (some b)).isSome = true := by
  have he : g.eval false b = g.eval true b := by simpa [blocksRight] using h
  cases v with
  | none => simp [Table.partial, he]
  | some c => rfl

namespace OpenCircuit

def directParity : {n : Nat} → OpenCircuit n → Fin n → Nat
  | _, .output _, _ => 0
  | _, .gate g i j rest, x =>
      indicator (((i == x) || (j == x)) && g.parity) + rest.directParity x.castSucc

def directBlocked : {n : Nat} → OpenCircuit n → Fin n → Bool → Nat
  | _, .output _, _, _ => 0
  | _, .gate g i j rest, x, b =>
      indicator (((i == x) && g.blocksLeft b) || ((j == x) && g.blocksRight b)) +
        rest.directBlocked x.castSucc b

def directOutput : {n : Nat} → OpenCircuit n → Fin n → Nat
  | _, .output (.constant _), _ => 0
  | _, .output (.wire i _), x => indicator (i == x)
  | _, .gate _ _ _ rest, x => rest.directOutput x.castSucc

theorem singleUse_append {n : Nat} (x : Fin n) :
    appendValue (singleUse x) 0 = singleUse x.castSucc := by
  funext k
  induction k using Fin.lastCases with
  | last =>
    have h : Fin.last n ≠ x.castSucc := by intro he; have hv := congrArg Fin.val he; simp at hv; omega
    simp [appendValue, singleUse, h]
  | cast k => simp [appendValue, k.isLt, singleUse]

theorem direct_partition {n : Nat} (C : OpenCircuit n) (x : Fin n) (hr : C.Reduced) :
    C.directParity x + C.directBlocked x false + C.directBlocked x true + C.directOutput x =
      C.usage (singleUse x) := by
  induction C with
  | output s => cases s <;> simp [directParity, directBlocked, directOutput, usage, singleUse, indicator]
  | gate g i j rest ih =>
    have hrec := ih x.castSucc hr.2.2.2
    have hl := g.left_partition hr.1
    have hh := g.right_partition hr.1
    simp only [directParity, directBlocked, directOutput, usage, singleUse_append]
    by_cases hi : i = x
    · subst i
      have hj : j ≠ x := Ne.symm hr.2.1
      simp only [beq_self_eq_true, beq_eq_false_iff_ne.mpr hj,
        Bool.true_and, Bool.false_and, Bool.or_false, singleUse, ↓reduceIte, hj]
      omega
    · by_cases hj : j = x
      · subst j
        simp only [beq_self_eq_true, beq_eq_false_iff_ne.mpr hi,
          Bool.false_or, Bool.true_and, Bool.false_and, singleUse, ↓reduceIte, hi]
        omega
      · simp only [beq_eq_false_iff_ne.mpr hi, beq_eq_false_iff_ne.mpr hj,
          Bool.false_or, Bool.false_and, indicator, Bool.false_eq_true, ↓reduceIte, singleUse, hi, hj]
        omega

theorem directOutput_zero {n : Nat} (C : OpenCircuit n) (κ : PartialState n) (x : Fin n)
    (b : Bool) (hx : κ x = some b) (ho : C.propagatedOutput κ = false) : C.directOutput x = 0 := by
  induction C with
  | output s =>
    cases s with
    | constant c => rfl
    | wire i c =>
      have hi : i ≠ x := by
        intro he
        subst i
        simp [propagatedOutput, hx] at ho
      simp [directOutput, hi, indicator]
  | gate g i j rest ih =>
    exact ih (κ.next g i j) x.castSucc (by simpa using hx) ho

theorem directParity_le {n : Nat} (C : OpenCircuit n) (κ : PartialState n) (x : Fin n)
    (b : Bool) (hx : κ x = some b) : C.directParity x ≤ C.propagationParity κ := by
  induction C with
  | output => exact Nat.le_refl 0
  | gate g i j rest ih =>
    have hrec := ih (κ.next g i j) x.castSucc (by simpa using hx)
    have hm : indicator (((i == x) || (j == x)) && g.parity) ≤
        indicator ((κ.mask i || κ.mask j) && g.parity) := by
      by_cases hi : i = x
      · subst i
        simp [PartialState.mask, hx]
      · by_cases hj : j = x
        · subst j
          simp [PartialState.mask, hx]
        · simp [hi, hj, indicator]
    exact Nat.add_le_add hm hrec

theorem directBlocked_le {n : Nat} (C : OpenCircuit n) (κ : PartialState n) (x : Fin n)
    (b : Bool) (hx : κ x = some b) : C.directBlocked x b ≤ C.propagationConstants κ := by
  induction C with
  | output => exact Nat.le_refl 0
  | gate g i j rest ih =>
    have hrec := ih (κ.next g i j) x.castSucc (by simpa using hx)
    have hm : indicator (((i == x) && g.blocksLeft b) || ((j == x) && g.blocksRight b)) ≤
        indicator (g.partial (κ i) (κ j)).isSome := by
      by_cases ha : (((i == x) && g.blocksLeft b) || ((j == x) && g.blocksRight b)) = true
      · have hz : (g.partial (κ i) (κ j)).isSome = true := by
          rcases Bool.or_eq_true_iff.mp ha with hl | hr
          · obtain ⟨hi, hb⟩ := Bool.and_eq_true_iff.mp hl
            have he : i = x := by simpa using hi
            rw [he, hx]
            exact g.blocksLeft_partial b (κ j) hb
          · obtain ⟨hj, hb⟩ := Bool.and_eq_true_iff.mp hr
            have he : j = x := by simpa using hj
            rw [he, hx]
            exact g.blocksRight_partial b (κ i) hb
        simp [ha, hz]
      · simp [indicator, ha]
    exact Nat.add_le_add hm hrec

end OpenCircuit
end SatLowerBound
