import SatLowerBound.PairRestriction

namespace SatLowerBound

theorem Table.parity_of_factor (g : Table) (H : Bool → Bool) (c : Bool)
    (h : ∀ a b, H (g.eval a b) = Bool.xor (Bool.xor a b) c) : g.parity = true := by
  have h00 := h false false
  have h01 := h false true
  have h10 := h true false
  have h11 := h true true
  rcases g with ⟨a, b, d, e⟩
  cases a <;> cases b <;> cases d <;> cases e <;> cases c <;>
    cases hf : H false <;> cases ht : H true <;> simp_all [Table.eval, Table.parity]

def pairTag {n : Nat} (x y k : Fin n) : Fin 3 := if k = x then 0 else if k = y then 1 else 2

def tagPartial (t : Fin 3) (a s : Bool) : Option Bool :=
  if t = 0 then some a else if t = 1 then some (Bool.xor a s) else none

theorem pairPartial_tag {n : Nat} (x y k : Fin n) (a s : Bool) :
    pairPartial x y a (Bool.xor a s) k = tagPartial (pairTag x y k) a s := by
  by_cases hx : k = x
  · simp [pairPartial, tagPartial, pairTag, hx]
  · by_cases hy : k = y
    · subst k; simp [pairPartial, tagPartial, pairTag, hx]
    · simp [pairPartial, tagPartial, pairTag, hx, hy]

set_option maxRecDepth 4096 in
set_option maxHeartbeats 800000 in
theorem Table.local_pair_gain (g : Table) (he : g.essential = true) (l r : Fin 3) (s : Bool)
    (ht : l.val < 2 ∨ r.val < 2) (hd : l.val < 2 → r.val < 2 → l ≠ r)
    (hp : l.val < 2 → r.val < 2 → g.parity = true) :
    ∃ a, 1 ≤
      2 * indicator (Bool.xor (tagPartial l a s).isSome (tagPartial r a s).isSome &&
        (g.partial (tagPartial l a s) (tagPartial r a s)).isSome) +
      indicator (((tagPartial l a s).isSome || (tagPartial r a s).isSome) && g.parity) := by
  revert he l r s
  rcases g with ⟨a, b, c, d⟩
  cases a <;> cases b <;> cases c <;> cases d <;> decide

namespace OpenCircuit

theorem parity_first_gate {n : Nat} (g : Table) (x y : Fin n) (rest : OpenCircuit (n + 1))
    (hxy : x ≠ y) (hx : (gate g x y rest).usage (singleUse x) = 1)
    (hy : (gate g x y rest).usage (singleUse y) = 1)
    (hs : PairParitySlice (gate g x y rest).eval x y) : g.parity = true := by
  obtain ⟨v, c, hv⟩ := hs
  obtain ⟨H, hH⟩ := first_gate_factor g x y rest hxy hx hy
  apply g.parity_of_factor (fun b => H b v) c
  intro a b
  exact (hH a b v).symm.trans (hv a b)

theorem output_not_paritySlice {n : Nat} (s : Signal n) (x y : Fin n) (hxy : x ≠ y) :
    ¬ PairParitySlice (OpenCircuit.output s).eval x y := by
  intro hs
  have hx := hs.essential_left hxy
  have hy := hs.essential_right hxy
  have hu := (OpenCircuit.output s).essential_has_use x hx
  have hv := (OpenCircuit.output s).essential_has_use y hy
  cases s with
  | constant c => exact Nat.not_lt_zero _ hu
  | wire k c =>
    have hkx : k = x := by by_contra h; simp [usage, singleUse, h] at hu
    have hky : k = y := by by_contra h; simp [usage, singleUse, h] at hv
    exact hxy (hkx.symm.trans hky)

theorem pairPartial_next_unrelated {n : Nat} (x y i j : Fin n) (a b : Bool) (g : Table)
    (hix : i ≠ x) (hiy : i ≠ y) (hjx : j ≠ x) (hjy : j ≠ y) :
    (pairPartial x y a b).next g i j = pairPartial x.castSucc y.castSucc a b := by
  funext k
  induction k using Fin.lastCases with
  | last =>
    have hx : Fin.last n ≠ x.castSucc := by intro he; have hv := congrArg Fin.val he; simp at hv; omega
    have hy : Fin.last n ≠ y.castSucc := by intro he; have hv := congrArg Fin.val he; simp at hv; omega
    simp [pairPartial, PartialState.next_last, hix, hiy, hjx, hjy, Table.partial, hx, hy]
  | cast k => simp [pairPartial, PartialState.next_old]

theorem paritySlice_tail_unrelated {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (x y : Fin n) (hix : i ≠ x) (hiy : i ≠ y) (hjx : j ≠ x) (hjy : j ≠ y)
    (hs : PairParitySlice (gate g i j rest).eval x y) :
    PairParitySlice rest.eval x.castSucc y.castSucc := by
  obtain ⟨v, c, hv⟩ := hs
  refine ⟨extend v (g.eval (v i) (v j)), c, ?_⟩
  intro a b
  have he : setPair (extend v (g.eval (v i) (v j))) x.castSucc y.castSucc a b =
      extend (setPair v x y a b) (g.eval (setPair v x y a b i) (setPair v x y a b j)) := by
    funext k
    induction k using Fin.lastCases with
    | last =>
      have hx : Fin.last n ≠ x.castSucc := by intro he; have hh := congrArg Fin.val he; simp at hh; omega
      have hy : Fin.last n ≠ y.castSucc := by intro he; have hh := congrArg Fin.val he; simp at hh; omega
      simp [setPair, hx, hy, hix, hiy, hjx, hjy]
    | cast k => simp [setPair]
  rw [he]
  exact hv a b

theorem pair_gate_gain {n : Nat} (g : Table) (i j x y : Fin n) (rest : OpenCircuit (n + 1))
    (s : Bool) (hxy : x ≠ y) (hr : (gate g i j rest).Reduced)
    (hx : (gate g i j rest).usage (singleUse x) = 1)
    (hy : (gate g i j rest).usage (singleUse y) = 1)
    (hs : PairParitySlice (gate g i j rest).eval x y)
    (ht : i = x ∨ i = y ∨ j = x ∨ j = y) :
    ∃ a, 1 ≤ 2 * (gate g i j rest).propagationBirths (pairPartial x y a (Bool.xor a s)) +
      (gate g i j rest).propagationParity (pairPartial x y a (Bool.xor a s)) := by
  have htouch : (pairTag x y i).val < 2 ∨ (pairTag x y j).val < 2 := by
    rcases ht with h | h | h | h <;> simp [pairTag, h, Ne.symm hxy]
  have hknown (k : Fin n) : (pairTag x y k).val < 2 → k = x ∨ k = y := by
    by_cases hkx : k = x
    · exact fun _ => Or.inl hkx
    · by_cases hky : k = y
      · exact fun _ => Or.inr hky
      · simp [pairTag, hkx, hky]
  have hdiff : (pairTag x y i).val < 2 → (pairTag x y j).val < 2 → pairTag x y i ≠ pairTag x y j := by
    intro hi hj
    rcases hknown i hi with hi | hi <;> rcases hknown j hj with hj | hj
    · exact False.elim (hr.2.1 (hi.trans hj.symm))
    · simp [pairTag, hi, hj, Ne.symm hxy]
    · simp [pairTag, hi, hj, Ne.symm hxy]
    · exact False.elim (hr.2.1 (hi.trans hj.symm))
  have hparity : (pairTag x y i).val < 2 → (pairTag x y j).val < 2 → g.parity = true := by
    intro hi hj
    rcases hknown i hi with hi | hi <;> rcases hknown j hj with hj | hj
    · exact False.elim (hr.2.1 (hi.trans hj.symm))
    · subst i; subst j
      exact parity_first_gate g x y rest hxy hx hy hs
    · subst i; subst j
      exact parity_first_gate g y x rest (Ne.symm hxy) hy hx (hs.symm hxy)
    · exact False.elim (hr.2.1 (hi.trans hj.symm))
  obtain ⟨a, ha⟩ := g.local_pair_gain hr.1 (pairTag x y i) (pairTag x y j) s htouch hdiff hparity
  refine ⟨a, ?_⟩
  simp only [propagationBirths, propagationParity, PartialState.mask, pairPartial_tag]
  omega

/-- If each selected input has one use, a parity slice forces either a deleted
parity gate or a new constant born from just one fixed predecessor. -/
theorem pair_parity_gain {n : Nat} (C : OpenCircuit n) (x y : Fin n) (s : Bool)
    (hxy : x ≠ y) (hr : C.Reduced) (hx : C.usage (singleUse x) = 1)
    (hy : C.usage (singleUse y) = 1) (hs : PairParitySlice C.eval x y) :
    ∃ a, 1 ≤ 2 * C.propagationBirths (pairPartial x y a (Bool.xor a s)) +
      C.propagationParity (pairPartial x y a (Bool.xor a s)) := by
  induction C with
  | output sig => exact False.elim (output_not_paritySlice sig x y hxy hs)
  | gate g i j rest ih =>
    by_cases ht : i = x ∨ i = y ∨ j = x ∨ j = y
    · exact pair_gate_gain g i j x y rest s hxy hr hx hy hs ht
    · have hix : i ≠ x := by tauto
      have hiy : i ≠ y := by tauto
      have hjx : j ≠ x := by tauto
      have hjy : j ≠ y := by tauto
      have hux : rest.usage (singleUse x.castSucc) = 1 := by
        simpa only [usage, singleUse_append, singleUse, hix, hjx, ↓reduceIte, Nat.zero_add] using hx
      have huy : rest.usage (singleUse y.castSucc) = 1 := by
        simpa only [usage, singleUse_append, singleUse, hiy, hjy, ↓reduceIte, Nat.zero_add] using hy
      have hslice := paritySlice_tail_unrelated g i j rest x y hix hiy hjx hjy hs
      obtain ⟨a, ha⟩ := ih x.castSucc y.castSucc (fun h => hxy (Fin.castSucc_inj.mp h))
        hr.2.2.2 hux huy hslice
      refine ⟨a, ?_⟩
      simp only [propagationBirths, propagationParity, pairPartial_next_unrelated x y i j _ _ g hix hiy hjx hjy]
      omega

theorem parity_retirement {n : Nat} (C : OpenCircuit n) (x y : Fin n) (s : Bool)
    (hxy : x ≠ y) (hr : C.Reduced) (hs : PairParitySlice C.eval x y)
    (hn : ∀ a, Nonconstant (fun v => C.eval (setPair v x y a (Bool.xor a s)))) :
    ∃ a, (C.restrict (pairSubst x y a (Bool.xor a s))).weight + 5 ≤ C.weight := by
  have hx := C.essential_has_use x (hs.essential_left hxy)
  have hy := C.essential_has_use y (hs.essential_right hxy)
  by_cases hu : 3 ≤ C.usage (singleUse x) + C.usage (singleUse y)
  · refine ⟨false, ?_⟩
    have hw := C.pair_deletion_data x y false (Bool.xor false s) hxy hr (hn false)
    omega
  · have hux : C.usage (singleUse x) = 1 := by omega
    have huy : C.usage (singleUse y) = 1 := by omega
    obtain ⟨a, ha⟩ := C.pair_parity_gain x y s hxy hr hux huy hs
    have hw := C.pair_deletion_data x y a (Bool.xor a s) hxy hr (hn a)
    exact ⟨a, by omega⟩

end OpenCircuit
end SatLowerBound
