import SatLowerBound.BasicLowerBound
import Mathlib.Data.Fintype.Pi

namespace SatLowerBound
namespace OpenCircuit

theorem weight_ge_twice_size {n : Nat} (C : OpenCircuit n) (he : C.EssentialGates) :
    2 * C.size ≤ C.weight := by
  induction C with
  | output => exact Nat.le_refl 0
  | gate g i j rest ih =>
    have hg := g.essential_weight he.1
    have hr := ih he.2
    simp only [size, weight]
    omega

def parity2 (c : Bool) (x : Fin 2 → Bool) : Bool := Bool.xor (Bool.xor (x 0) (x 1)) c

private theorem output_not_parity (s : Signal 2) (c : Bool) :
    ∃ x, s.eval x ≠ parity2 c x := by
  cases s with
  | constant b => revert b c; decide
  | wire i b => revert i b c; decide

set_option maxRecDepth 10000 in
private theorem small_gate_not_parity (g : Table) (i j : Fin 2) (s : Signal 3) (c : Bool)
    (h : g.weight < 3) :
    ∃ x, (OpenCircuit.gate g i j (.output s)).eval x ≠ parity2 c x := by
  revert h
  rcases g with ⟨a, b, d, e⟩
  cases s with
  | constant v => revert a b d e i j v c; decide
  | wire k v => revert a b d e i j k v c; decide

/-- The terminal parity cofactor costs at least three weight units. -/
theorem parity_weight_lower_bound (C : OpenCircuit 2) (c : Bool)
    (he : C.EssentialGates) (hc : ∀ x, C.eval x = parity2 c x) : 3 ≤ C.weight := by
  by_contra h
  have hs := weight_ge_twice_size C he
  cases C with
  | output s =>
    obtain ⟨x, hx⟩ := output_not_parity s c
    exact hx (hc x)
  | gate g i j rest =>
    have hsz : rest.size = 0 := by simp only [size] at hs; omega
    have hg : g.weight < 3 := by simp only [weight] at h; omega
    cases rest with
    | output s =>
      obtain ⟨x, hx⟩ := small_gate_not_parity g i j s c hg
      exact hx (hc x)
    | gate f k l tail => simp [size] at hsz

end OpenCircuit

theorem circuit_parity_weight_lower_bound (C : Circuit 2) (c : Bool)
    (hc : C.Computes (OpenCircuit.parity2 c)) : 3 ≤ C.weight := by
  obtain ⟨D, hl, he, hs, hw, hv⟩ := OpenCircuit.normalize_basic C
  have hD := D.parity_weight_lower_bound c he (fun x => (hv x).trans (hc x))
  omega

end SatLowerBound
