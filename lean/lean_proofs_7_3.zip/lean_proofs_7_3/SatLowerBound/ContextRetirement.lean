import SatLowerBound.ModularContext

namespace SatLowerBound
namespace ModularContext

def retire {n : Nat} : ModularContext n → Option (ModularTree n)
  | .hole => none
  | .left p K R => some (match K.retire with | none => R | some U => .branch p U R)
  | .right p L K => some (match K.retire with | none => L | some U => .branch p L U)

/-- The value neutral at the selected leaf's immediate parent. -/
def neutral {n : Nat} : ModularContext n → Bool
  | .hole => false
  | .left p K _ => if K.retire.isNone then !p else K.neutral
  | .right p _ K => if K.retire.isNone then !p else K.neutral

theorem retire_none {n : Nat} (K : ModularContext n) : K.retire = none ↔ K = .hole := by
  cases K <;> simp [retire]

theorem retire_stats {n : Nat} (K : ModularContext n) (R : ModularTree n) (h : K.retire = some R) :
    R.support = K.support ∧ R.inputs = K.inputs ∧ R.blocks = K.blocks ∧ R.defects = K.defects := by
  induction K generalizing R with
  | hole => contradiction
  | left p K U ih =>
    cases hk : K.retire with
    | none =>
      have he := K.retire_none.mp hk
      subst K
      simp only [retire, Option.some.injEq] at h
      subst R
      simp [support, inputs, blocks, defects]
    | some V =>
      simp only [retire, hk, Option.some.injEq] at h
      subst R
      obtain ⟨hs, hi, hb, hd⟩ := ih V hk
      simp only [support, inputs, blocks, defects, ModularTree.support, ModularTree.inputs,
        ModularTree.blocks, ModularTree.defects, hs, hi, hb, hd, and_self]
  | right p U K ih =>
    cases hk : K.retire with
    | none =>
      have he := K.retire_none.mp hk
      subst K
      simp only [retire, Option.some.injEq] at h
      subst R
      simp [support, inputs, blocks, defects]
    | some V =>
      simp only [retire, hk, Option.some.injEq] at h
      subst R
      obtain ⟨hs, hi, hb, hd⟩ := ih V hk
      simp only [support, inputs, blocks, defects, ModularTree.support, ModularTree.inputs,
        ModularTree.blocks, ModularTree.defects, hs, hi, hb, hd, and_self]

theorem retire_valid {n k : Nat} (K : ModularContext n) (S : Finset (Fin n)) (h : K.Fits k S)
    (R : ModularTree n) (hr : K.retire = some R) : R.Valid k := by
  induction K generalizing R with
  | hole => contradiction
  | left p K U ih =>
    cases hk : K.retire with
    | none =>
      simp only [retire, hk, Option.some.injEq] at hr
      subst R
      exact h.2.1
    | some V =>
      simp only [retire, hk, Option.some.injEq] at hr
      subst R
      refine ⟨ih h.1 V hk, h.2.1, ?_⟩
      rw [(K.retire_stats V hk).1]
      apply Finset.disjoint_left.mpr
      intro i hi hj
      exact Finset.disjoint_left.mp h.2.2 (Finset.mem_union_right _ hi) hj
  | right p U K ih =>
    cases hk : K.retire with
    | none =>
      simp only [retire, hk, Option.some.injEq] at hr
      subst R
      exact h.1
    | some V =>
      simp only [retire, hk, Option.some.injEq] at hr
      subst R
      refine ⟨h.1, ih h.2.1 V hk, ?_⟩
      rw [(K.retire_stats V hk).1]
      apply Finset.disjoint_left.mpr
      intro i hi hj
      exact Finset.disjoint_left.mp h.2.2 hi (Finset.mem_union_right _ hj)

theorem retire_eval {n : Nat} (K : ModularContext n) (R T : ModularTree n)
    (h : K.retire = some R) (v : Fin n → Bool) (ht : T.eval v = K.neutral) :
    (K.plug T).eval v = R.eval v := by
  induction K generalizing R with
  | hole => contradiction
  | left p K U ih =>
    cases hk : K.retire with
    | none =>
      have he := K.retire_none.mp hk
      subst K
      simp only [retire, Option.some.injEq] at h
      subst R
      simp only [neutral, retire, Option.isNone_none, ↓reduceIte] at ht
      simp only [plug, ModularTree.eval, ht]
      rw [combine_comm, combine_neutral]
    | some V =>
      simp only [retire, hk, Option.some.injEq] at h
      subst R
      simp only [neutral, hk, Option.isNone_some, Bool.false_eq_true, ↓reduceIte] at ht
      simp only [plug, ModularTree.eval, ih V hk ht]
  | right p U K ih =>
    cases hk : K.retire with
    | none =>
      have he := K.retire_none.mp hk
      subst K
      simp only [retire, Option.some.injEq] at h
      subst R
      simp only [neutral, retire, Option.isNone_none, ↓reduceIte] at ht
      simp only [plug, ModularTree.eval, ht, combine_neutral]
    | some V =>
      simp only [retire, hk, Option.some.injEq] at h
      subst R
      simp only [neutral, hk, Option.isNone_some, Bool.false_eq_true, ↓reduceIte] at ht
      simp only [plug, ModularTree.eval, ih V hk ht]

theorem Fits.mono {n k l : Nat} {K : ModularContext n} {S : Finset (Fin n)}
    (h : K.Fits k S) (hl : l ≤ k) : K.Fits l S := by
  induction K with
  | hole => trivial
  | left p K R ih => exact ⟨ih h.1, h.2.1.mono hl, h.2.2⟩
  | right p L K ih => exact ⟨h.1.mono hl, ih h.2.1, h.2.2⟩

/-- Changing a leaf changes only its Boolean output; every other block is kept. -/
theorem plug_fixBit {n k : Nat} (K : ModularContext n) (S : Finset (Fin n))
    (h : K.Fits k S) (T U : ModularTree n) (x : Fin n) (hx : x ∈ S) (b : Bool)
    (he : ∀ v, U.eval v = T.eval (fixBit x b v)) (v : Fin n → Bool) :
    (K.plug U).eval v = (K.plug T).eval (fixBit x b v) := by
  rw [plug_eval, plug_eval, he]
  have hn : x ∉ K.support := fun hk => Finset.disjoint_left.mp (K.fits_disjoint S h) hx hk
  exact ((K.evalHole_supported _).fixBit_outside x hn b v).symm

end ModularContext
end SatLowerBound
