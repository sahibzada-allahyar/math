import SatLowerBound.TreeSeparation

namespace SatLowerBound

/-- A composition tree with exactly one selected leaf replaced by a hole. -/
inductive ModularContext (n : Nat) where
  | hole
  | left (isOr : Bool) (inside : ModularContext n) (sibling : ModularTree n)
  | right (isOr : Bool) (sibling : ModularTree n) (inside : ModularContext n)

namespace ModularContext

def plug {n : Nat} : ModularContext n → ModularTree n → ModularTree n
  | .hole, T => T
  | .left p K R, T => .branch p (K.plug T) R
  | .right p L K, T => .branch p L (K.plug T)

def support {n : Nat} : ModularContext n → Finset (Fin n)
  | .hole => ∅
  | .left _ K R => K.support ∪ R.support
  | .right _ L K => L.support ∪ K.support

def inputs {n : Nat} : ModularContext n → Nat
  | .hole => 0
  | .left _ K R => K.inputs + R.inputs
  | .right _ L K => L.inputs + K.inputs

def blocks {n : Nat} : ModularContext n → Nat
  | .hole => 0
  | .left _ K R => K.blocks + R.blocks
  | .right _ L K => L.blocks + K.blocks

def defects {n : Nat} : ModularContext n → Nat
  | .hole => 0
  | .left _ K R => K.defects + R.defects
  | .right _ L K => L.defects + K.defects

theorem plug_support {n : Nat} (K : ModularContext n) (T : ModularTree n) :
    (K.plug T).support = T.support ∪ K.support := by
  induction K with
  | hole => simp [plug, support]
  | left p K R ih => simp only [plug, support, ModularTree.support, ih, Finset.union_assoc]
  | right p L K ih =>
    simp only [plug, support, ModularTree.support, ih]
    ext i
    simp only [Finset.mem_union]
    tauto

theorem plug_inputs {n : Nat} (K : ModularContext n) (T : ModularTree n) :
    (K.plug T).inputs = T.inputs + K.inputs := by
  induction K with
  | hole => simp [plug, inputs]
  | left p K R ih => simp only [plug, inputs, ModularTree.inputs, ih]; omega
  | right p L K ih => simp only [plug, inputs, ModularTree.inputs, ih]; omega

theorem plug_blocks {n : Nat} (K : ModularContext n) (T : ModularTree n) :
    (K.plug T).blocks = T.blocks + K.blocks := by
  induction K with
  | hole => simp [plug, blocks]
  | left p K R ih => simp only [plug, blocks, ModularTree.blocks, ih]; omega
  | right p L K ih => simp only [plug, blocks, ModularTree.blocks, ih]; omega

theorem plug_defects {n : Nat} (K : ModularContext n) (T : ModularTree n) :
    (K.plug T).defects = T.defects + K.defects := by
  induction K with
  | hole => simp [plug, defects]
  | left p K R ih => simp only [plug, defects, ModularTree.defects, ih]; omega
  | right p L K ih => simp only [plug, defects, ModularTree.defects, ih]; omega

def Fits {n : Nat} (k : Nat) (S : Finset (Fin n)) : ModularContext n → Prop
  | .hole => True
  | .left _ K R => K.Fits k S ∧ R.Valid k ∧ Disjoint (S ∪ K.support) R.support
  | .right _ L K => L.Valid k ∧ K.Fits k S ∧ Disjoint L.support (S ∪ K.support)

theorem fits_of_plug {n k : Nat} (K : ModularContext n) (T : ModularTree n)
    (h : (K.plug T).Valid k) : T.Valid k ∧ K.Fits k T.support := by
  induction K with
  | hole => exact ⟨h, True.intro⟩
  | left p K R ih =>
    obtain ⟨ht, hK⟩ := ih h.1
    exact ⟨ht, hK, h.2.1, by simpa only [plug_support] using h.2.2⟩
  | right p L K ih =>
    obtain ⟨ht, hK⟩ := ih h.2.1
    exact ⟨ht, h.1, hK, by simpa only [plug_support] using h.2.2⟩

theorem fits_disjoint {n k : Nat} (K : ModularContext n) (S : Finset (Fin n))
    (h : K.Fits k S) : Disjoint S K.support := by
  induction K with
  | hole => simp [support]
  | left p K R ih =>
    apply Finset.disjoint_left.mpr
    intro i hi hj
    rcases Finset.mem_union.mp hj with hK | hR
    · exact Finset.disjoint_left.mp (ih h.1) hi hK
    · exact Finset.disjoint_left.mp h.2.2 (Finset.mem_union_left _ hi) hR
  | right p L K ih =>
    apply Finset.disjoint_left.mpr
    intro i hi hj
    rcases Finset.mem_union.mp hj with hL | hK
    · exact Finset.disjoint_left.mp h.2.2 hL (Finset.mem_union_left _ hi)
    · exact Finset.disjoint_left.mp (ih h.2.1) hi hK

theorem plug_valid {n k : Nat} (K : ModularContext n) (S : Finset (Fin n))
    (h : K.Fits k S) (T : ModularTree n) (ht : T.Valid k) (hs : T.support ⊆ S) :
    (K.plug T).Valid k := by
  induction K with
  | hole => exact ht
  | left p K R ih =>
    refine ⟨ih h.1, h.2.1, ?_⟩
    rw [plug_support]
    apply Finset.disjoint_left.mpr
    intro i hi hj
    apply Finset.disjoint_left.mp h.2.2 _ hj
    rcases Finset.mem_union.mp hi with hi | hi
    · exact Finset.mem_union_left _ (hs hi)
    · exact Finset.mem_union_right _ hi
  | right p L K ih =>
    refine ⟨h.1, ih h.2.1, ?_⟩
    rw [plug_support]
    apply Finset.disjoint_left.mpr
    intro i hi hj
    apply Finset.disjoint_left.mp h.2.2 hi
    rcases Finset.mem_union.mp hj with hj | hj
    · exact Finset.mem_union_left _ (hs hj)
    · exact Finset.mem_union_right _ hj

def evalHole {n : Nat} : ModularContext n → Bool → (Fin n → Bool) → Bool
  | .hole, z, _ => z
  | .left p K R, z, v => combine p (K.evalHole z v) (R.eval v)
  | .right p L K, z, v => combine p (L.eval v) (K.evalHole z v)

theorem plug_eval {n : Nat} (K : ModularContext n) (T : ModularTree n) (v : Fin n → Bool) :
    (K.plug T).eval v = K.evalHole (T.eval v) v := by
  induction K with
  | hole => rfl
  | left p K R ih => simp only [plug, ModularTree.eval, evalHole, ih]
  | right p L K ih => simp only [plug, ModularTree.eval, evalHole, ih]

theorem evalHole_supported {n : Nat} (K : ModularContext n) (z : Bool) :
    Supported (K.evalHole z) K.support := by
  induction K with
  | hole => exact fun _ _ _ => rfl
  | left p K R ih => exact supported_combine p _ _ _ _ ih R.supported
  | right p L K ih => exact supported_combine p _ _ _ _ L.supported ih

theorem expose {n : Nat} (K : ModularContext n) (S : Finset (Fin n)) (h : K.Fits 2 S) :
    ∃ v, ∀ z, K.evalHole z v = z := by
  induction K with
  | hole => exact ⟨fun _ => false, fun _ => rfl⟩
  | left p K R ih =>
    obtain ⟨u, hu⟩ := ih h.1
    obtain ⟨v, hv⟩ := (R.nonconstant h.2.1).has_value (!p)
    have hd : Disjoint K.support R.support := Finset.disjoint_left.mpr (fun _ hi hj =>
      Finset.disjoint_left.mp h.2.2 (Finset.mem_union_right _ hi) hj)
    refine ⟨patchValues K.support u v, ?_⟩
    intro z
    simp only [evalHole, (K.evalHole_supported z).patch_left, R.supported.patch_right hd, hu, hv, combine_neutral]
  | right p L K ih =>
    obtain ⟨u, hu⟩ := ih h.2.1
    obtain ⟨v, hv⟩ := (L.nonconstant h.1).has_value (!p)
    have hd : Disjoint K.support L.support := Finset.disjoint_left.mpr (fun _ hi hj =>
      Finset.disjoint_left.mp h.2.2 hj (Finset.mem_union_right _ hi))
    refine ⟨patchValues K.support u v, ?_⟩
    intro z
    simp only [evalHole, (K.evalHole_supported z).patch_left, L.supported.patch_right hd, hu, hv]
    rw [combine_comm, combine_neutral]

end ModularContext

theorem ModularTree.locate {n : Nat} (T : ModularTree n) (x : Fin n) (hx : x ∈ T.support) :
    ∃ (K : ModularContext n) (S : Finset (Fin n)) (t : Fin 3) (c : Bool),
      T = K.plug (.leaf S t c) ∧ x ∈ S := by
  induction T with
  | leaf S t c => exact ⟨.hole, S, t, c, rfl, hx⟩
  | branch p L R ihL ihR =>
    rcases Finset.mem_union.mp hx with hL | hR
    · obtain ⟨K, S, t, c, hK, hS⟩ := ihL hL
      exact ⟨.left p K R, S, t, c, by simp only [ModularContext.plug, hK], hS⟩
    · obtain ⟨K, S, t, c, hK, hS⟩ := ihR hR
      exact ⟨.right p L K, S, t, c, by simp only [ModularContext.plug, hK], hS⟩

end SatLowerBound
