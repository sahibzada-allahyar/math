import SatLowerBound.ModularTree
import SatLowerBound.BlockSeparation
import SatLowerBound.SeparationLifting
import SatLowerBound.MinimalSupport

namespace SatLowerBound

theorem ThreeRows.swap {α : Type} {f : Bool → Bool → α → Bool} (h : ThreeRows f) :
    ThreeRows (fun a b v => f b a v) := by
  obtain ⟨p, q, r, hpq, hpr, hqr⟩ := h
  exact ⟨(p.2, p.1), (q.2, q.1), (r.2, r.1), hpq, hpr, hqr⟩

theorem PairSeparated.symm {n : Nat} {f : (Fin n → Bool) → Bool} {x y : Fin n}
    (h : PairSeparated f x y) (hxy : x ≠ y) : PairSeparated f y x := by
  have he : (fun a b v => f (setPair v y x a b)) = (fun a b v => f (setPair v x y b a)) := by
    funext a b v
    rw [setPair_symm v y x a b (Ne.symm hxy)]
  unfold PairSeparated
  rw [he]
  exact ThreeRows.swap h

namespace ModularTree

theorem pairSeparated {n : Nat} (T : ModularTree n) (h : T.Valid 3) (x y : Fin n)
    (hxy : x ≠ y) (hx : x ∈ T.support) (hy : y ∈ T.support) : PairSeparated T.eval x y := by
  induction T with
  | leaf S t c => exact modularBlock_pairSeparated S t c h x y hxy hx hy
  | branch p a b iha ihb =>
    rcases Finset.mem_union.mp hx with hxa | hxb <;>
      rcases Finset.mem_union.mp hy with hya | hyb
    · exact combine_pair_left p a.eval b.eval a.support b.support a.supported b.supported
        h.2.2 (b.nonconstant (h.2.1.mono (by omega))) x y hxa hya (iha h.1 hxa hya)
    · exact combine_pair_cross p a.eval b.eval a.support b.support a.supported b.supported
        h.2.2 x y (a.essential (h.1.mono (by omega)) x hxa) (b.essential (h.2.1.mono (by omega)) y hyb)
        (a.cofactor_nonconstant h.1 x) (b.cofactor_nonconstant h.2.1 y)
    · have hs := combine_pair_cross p a.eval b.eval a.support b.support a.supported b.supported
        h.2.2 y x (a.essential (h.1.mono (by omega)) y hya) (b.essential (h.2.1.mono (by omega)) x hxb)
        (a.cofactor_nonconstant h.1 y) (b.cofactor_nonconstant h.2.1 x)
      exact hs.symm (Ne.symm hxy)
    · exact combine_pair_right p a.eval b.eval a.support b.support a.supported b.supported
        h.2.2 (a.nonconstant (h.1.mono (by omega))) x y hxb hyb (ihb h.2.1 hxb hyb)

theorem six_or_seven {n : Nat} (T : ModularTree n) (h : T.Valid 3)
    (C : OpenCircuit n) (W : Nat) (hm : OpenCircuit.Minimal T.eval W C) :
    ∃ x ∈ T.support,
      (∀ b, (C.restrict (singleSubst x b)).weight + 6 ≤ C.weight) ∨
        (∃ b, (C.restrict (singleSubst x b)).weight + 7 ≤ C.weight) := by
  obtain ⟨x, hx, hd⟩ := C.minimal_six_or_seven T.eval W hm (T.nonconstant (h.mono (by omega)))
    (fun x y hx hy hxy => T.pairSeparated h x y hxy (T.supported.essential_mem x hx)
      (T.supported.essential_mem y hy))
    (fun x _ b => T.cofactor_nonconstant h x b)
  exact ⟨x, T.supported.essential_mem x hx, hd⟩

end ModularTree
end SatLowerBound
