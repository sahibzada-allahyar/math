import SatLowerBound.NonlinearDegree
import SatLowerBound.Mod3

namespace SatLowerBound

theorem tail_extend (n : Nat) (x : Fin (n + 1) → Bool) (b : Bool) :
    (fun i : Fin (n + 1) => extend x b i.succ) =
      extend (fun i : Fin n => x i.succ) b := by
  funext i
  by_cases h : i.val < n
  · have hh : i.succ.val < n + 1 := by simpa using Nat.succ_lt_succ h
    simp only [extend, hh, h, ↓reduceDIte]
    rfl
  · have hh : ¬ i.succ.val < n + 1 := by simpa using h
    simp only [extend, hh, h, ↓reduceDIte]

theorem ones_extend (n : Nat) (x : Fin n → Bool) (b : Bool) :
    ones (n + 1) (extend x b) = ones n x + (if b then 1 else 0) := by
  induction n with
  | zero => simp [ones, extend]
  | succ n ih =>
    change (if extend x b 0 then 1 else 0) +
        ones (n + 1) (fun i => extend x b i.succ) =
      (if x 0 then 1 else 0) + ones n (fun i => x i.succ) + (if b then 1 else 0)
    have h0 : extend x b 0 = x 0 := by simp [extend]
    rw [h0, tail_extend, ih]
    omega

namespace BPoly

theorem top_add {n : Nat} (p q : BPoly n) :
    (p.add q).topCoefficient = Bool.xor p.topCoefficient q.topCoefficient := by
  induction p with
  | constant a => cases q; rfl
  | node a b iha ihb => cases q with | node c d => exact ihb d

theorem top_zero (n : Nat) : (zero n).topCoefficient = false := by
  induction n with
  | zero => rfl
  | succ n ih => exact ih

theorem top_one (n : Nat) : (one (n + 1)).topCoefficient = false := top_zero n

theorem ofFunction_xor (n : Nat) (f g : (Fin n → Bool) → Bool) :
    ofFunction n (fun x => Bool.xor (f x) (g x)) = (ofFunction n f).add (ofFunction n g) := by
  apply ext
  intro x
  rw [eval_add, eval_ofFunction, eval_ofFunction, eval_ofFunction]

theorem ofFunction_not (n : Nat) (f : (Fin n → Bool) → Bool) :
    ofFunction n (fun x => !(f x)) = (one n).add (ofFunction n f) := by
  apply ext
  intro x
  rw [eval_add, eval_ofFunction, eval_ofFunction, eval_one]
  cases f x <;> rfl

theorem top_function_step (n : Nat) (f : (Fin (n + 1) → Bool) → Bool) :
    (ofFunction (n + 1) f).topCoefficient =
      Bool.xor (ofFunction n (fun x => f (extend x false))).topCoefficient
        (ofFunction n (fun x => f (extend x true))).topCoefficient := by
  change (ofFunction n (fun x => Bool.xor (f (extend x false))
    (f (extend x true)))).topCoefficient = _
  rw [ofFunction_xor, top_add]

end BPoly

/-- The residue shift used by the selected full-degree helper blocks. -/
def shiftedFunction (n t : Nat) : (Fin n → Bool) → Bool :=
  fun x => decide ((n + ones n x) % 3 = t % 3)

theorem shiftedFunction_false (n t : Nat) (x : Fin n → Bool) :
    shiftedFunction (n + 1) t (extend x false) = shiftedFunction n ((t + 2) % 3) x := by
  simp only [shiftedFunction, ones_extend, Bool.false_eq_true, ↓reduceIte, Nat.add_zero]
  rw [decide_eq_decide]
  omega

theorem shiftedFunction_true (n t : Nat) (x : Fin n → Bool) :
    shiftedFunction (n + 1) t (extend x true) = shiftedFunction n ((t + 1) % 3) x := by
  simp only [shiftedFunction, ones_extend, ↓reduceIte]
  rw [decide_eq_decide]
  omega

theorem shifted_top_recurrence (n t : Nat) :
    (BPoly.ofFunction (n + 1) (shiftedFunction (n + 1) t)).topCoefficient =
      Bool.xor (BPoly.ofFunction n (shiftedFunction n ((t + 2) % 3))).topCoefficient
        (BPoly.ofFunction n (shiftedFunction n ((t + 1) % 3))).topCoefficient := by
  rw [BPoly.top_function_step]
  have hf := funext (shiftedFunction_false n t)
  have ht := funext (shiftedFunction_true n t)
  rw [hf, ht]

theorem shifted_top_coefficients (n : Nat) :
    (BPoly.ofFunction (n + 1) (shiftedFunction (n + 1) 0)).topCoefficient = false ∧
    (BPoly.ofFunction (n + 1) (shiftedFunction (n + 1) 1)).topCoefficient = true ∧
    (BPoly.ofFunction (n + 1) (shiftedFunction (n + 1) 2)).topCoefficient = true := by
  induction n with
  | zero => decide
  | succ n ih =>
    obtain ⟨h0, h1, h2⟩ := ih
    constructor
    · rw [shifted_top_recurrence]
      simp only [Nat.reduceAdd, Nat.reduceMod, h1, h2]
      rfl
    · constructor
      · rw [shifted_top_recurrence]
        simp only [Nat.reduceAdd, Nat.reduceMod, h0, h2]
        rfl
      · rw [shifted_top_recurrence]
        simp only [Nat.reduceAdd, Nat.reduceMod, h0, h1]
        rfl

def helperBlock (n : Nat) : (Fin n → Bool) → Bool := fun x => !(shiftedFunction n 1 x)

/-- The selected complemented MOD-3 block has a nonzero full monomial. -/
theorem helperBlock_full_degree (n : Nat) :
    (BPoly.ofFunction (n + 1) (helperBlock (n + 1))).topCoefficient = true := by
  unfold helperBlock
  rw [BPoly.ofFunction_not, BPoly.top_add, BPoly.top_one, Bool.false_xor]
  exact (shifted_top_coefficients n).2.1

theorem helperBlock_nonlinear_bound (n : Nat) (C : Circuit (n + 1))
    (hc : C.Computes (helperBlock (n + 1))) : n ≤ C.nonlinearCount := by
  have h := C.nonlinear_lower_bound _ hc (helperBlock_full_degree n)
  omega

end SatLowerBound
