import SatLowerBound.SatTransfer
import SatLowerBound.GroupedDegree

namespace SatLowerBound

/-- The exact finite certificate, proved unconditionally in `Main.lean`.
The only circuit hypothesis is computing the explicitly defined total SAT function. -/
def ExactCertificate : Prop :=
  ∀ (w r : Nat), 8 ≤ w → 3 ≤ r → r < w →
    ∀ C : Circuit (inputBits w), C.Computes (satFunction w) →
      inputBits w + (4 * r - 7) * remainingClauses w r ≤ C.size + 1

/-- The weighted statement for the concrete sparse target, proved in `Main.lean`. -/
def WeightedSparseBound (w r : Nat) : Prop :=
  ∀ D : OpenCircuit (freeBits w r),
    (∀ x, D.eval x = sparseFunction w r x) →
      6 * freeBits w r ≤ D.weight + 7 * (3 * remainingClauses w r) + 2

theorem freeBits_le_inputBits (w r : Nat) (hr : r < w) : freeBits w r ≤ inputBits w := by
  rw [freeBits_eq]
  exact Nat.mul_le_mul (Nat.mul_le_mul_left 3 (Nat.sub_le _ _)) (by omega)

/-- Combine a weighted bound with the already proved full-degree fact. -/
theorem sparse_size_of_weighted (w r : Nat) (hr0 : 0 < r)
    (hweighted : WeightedSparseBound w r) (D : OpenCircuit (freeBits w r))
    (hD : ∀ x, D.eval x = sparseFunction w r x) :
    7 * freeBits w r ≤ 3 * D.size + 7 * (3 * remainingClauses w r) + 3 := by
  have hmu := hweighted D hD
  have hA := D.nonlinear_lower_bound _ hD (sparseFunction_full_degree w r hr0)
  have hsize := D.resource_le
  omega

/-- Parameterized assembly; `main_lower_bound` supplies the proved weighted bound. -/
theorem certificate_of_weighted (w r : Nat) (hw : 8 ≤ w) (hr3 : 3 ≤ r) (hr : r < w)
    (hweighted : WeightedSparseBound w r)
    (C : Circuit (inputBits w)) (hc : C.Computes (satFunction w)) :
    inputBits w + (4 * r - 7) * remainingClauses w r ≤ C.size + 1 := by
  obtain ⟨D, hD, hdel⟩ := sat_sparse_transfer w r (by omega) hr (by omega) C hc
  have hsize := sparse_size_of_weighted w r (by omega) hweighted D hD
  have hL := freeBits_le_inputBits w r hr
  have hdim : freeBits w r = 3 * (r * remainingClauses w r) := by
    rw [freeBits_eq, Nat.mul_assoc, Nat.mul_comm (remainingClauses w r) r]
  have hcharge : (4 * r - 7) * remainingClauses w r + 7 * remainingClauses w r =
      4 * (r * remainingClauses w r) := by
    rw [← Nat.add_mul, Nat.sub_add_cancel (by omega : 7 ≤ 4 * r), Nat.mul_assoc]
  omega

theorem exactCertificate_of_weighted
    (h : ∀ w r, 8 ≤ w → 3 ≤ r → r < w → WeightedSparseBound w r) : ExactCertificate := by
  intro w r hw hr3 hr C hc
  exact certificate_of_weighted w r hw hr3 hr (h w r hw hr3 hr) C hc

end SatLowerBound
