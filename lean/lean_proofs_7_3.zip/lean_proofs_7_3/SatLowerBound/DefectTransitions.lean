import SatLowerBound.ModularTree

namespace SatLowerBound

def residueDefect (k : Nat) (t : Fin 3) : Nat := indicator (decide ((k + t.val) % 3 = 0))

theorem residueDefect_le_one (k : Nat) (t : Fin 3) : residueDefect k t ≤ 1 := by
  unfold residueDefect indicator
  split <;> omega

theorem cofactor_defect_sum (k : Nat) (t : Fin 3) :
    residueDefect k (lowerResidue t false) + residueDefect k (lowerResidue t true) +
      residueDefect (k + 1) t = 1 := by
  have hk : k % 3 = 0 ∨ k % 3 = 1 ∨ k % 3 = 2 := by have := Nat.mod_lt k (by omega : 0 < 3); omega
  have ht : t.val = 0 ∨ t.val = 1 ∨ t.val = 2 := by have := t.isLt; omega
  rcases hk with hk | hk | hk <;> rcases ht with ht | ht | ht <;>
    simp [residueDefect, lowerResidue, indicator, Nat.add_mod, hk, ht]

theorem exists_full_cofactor (k : Nat) (t : Fin 3) :
    ∃ b, residueDefect k (lowerResidue t b) = 0 := by
  have h := cofactor_defect_sum k t
  by_cases hf : residueDefect k (lowerResidue t false) = 0
  · exact ⟨false, hf⟩
  · exact ⟨true, by omega⟩

theorem deficient_cofactor_full (k : Nat) (t : Fin 3) (h : residueDefect (k + 1) t = 1)
    (b : Bool) : residueDefect k (lowerResidue t b) = 0 := by
  have hs := cofactor_defect_sum k t
  cases b <;> omega

theorem full_has_deficient_cofactor (k : Nat) (t : Fin 3) (h : residueDefect (k + 1) t = 0) :
    ∃ b, residueDefect k (lowerResidue t b) = 1 := by
  have hs := cofactor_defect_sum k t
  by_cases hf : residueDefect k (lowerResidue t false) = 1
  · exact ⟨false, hf⟩
  · exact ⟨true, by omega⟩

theorem two_deficient_residue (t : Fin 3) (h : residueDefect 2 t = 1) : t = 1 := by
  have ht : t.val = 0 ∨ t.val = 1 ∨ t.val = 2 := by have := t.isLt; omega
  rcases ht with ht | ht | ht
  · simp [residueDefect, indicator, ht] at h
  · exact Fin.ext ht
  · simp [residueDefect, indicator, ht] at h

end SatLowerBound
