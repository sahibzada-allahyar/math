import SatLowerBound.PartialPropagation

namespace SatLowerBound

theorem Table.partial_sound (g : Table) (a b : Option Bool) (x y v : Bool)
    (hx : ∀ u, a = some u → x = u) (hy : ∀ u, b = some u → y = u)
    (hv : g.partial a b = some v) : g.eval x y = v := by
  cases a with
  | none =>
    cases b with
    | none => contradiction
    | some b =>
      have he := hy b rfl
      subst y
      simp only [Table.partial] at hv
      split at hv
      · rename_i h
        cases hv
        cases x <;> simp_all
      · contradiction
  | some a =>
    have he := hx a rfl
    subst x
    cases b with
    | none =>
      simp only [Table.partial] at hv
      split at hv
      · rename_i h
        cases hv
        cases y <;> simp_all
      · contradiction
    | some b =>
      have he := hy b rfl
      subst y
      cases hv
      rfl

def PartialState.Agrees {n : Nat} (κ : PartialState n) (x : Fin n → Bool) : Prop :=
  ∀ i b, κ i = some b → x i = b

theorem PartialState.agrees_next {n : Nat} (κ : PartialState n) (x : Fin n → Bool)
    (hx : κ.Agrees x) (g : Table) (i j : Fin n) :
    (κ.next g i j).Agrees (extend x (g.eval (x i) (x j))) := by
  intro k b hk
  simp only [PartialState.next, OpenCircuit.appendValue] at hk
  simp only [extend]
  split at hk
  · rename_i hkn
    simp only [hkn, ↓reduceDIte]
    exact hx _ b hk
  · rename_i hkn
    simp only [hkn, ↓reduceDIte]
    exact g.partial_sound _ _ _ _ b (hx i) (hx j) hk

namespace OpenCircuit

theorem eval_eq_of_propagated {n : Nat} (C : OpenCircuit n) (κ : PartialState n)
    (x y : Fin n → Bool) (hx : κ.Agrees x) (hy : κ.Agrees y)
    (ho : C.propagatedOutput κ = true) : C.eval x = C.eval y := by
  induction C with
  | output s =>
    cases s with
    | constant b => rfl
    | wire i c =>
      cases hi : κ i with
      | none => simp [propagatedOutput, hi] at ho
      | some b =>
        simp only [eval, Signal.eval, hx i b hi, hy i b hi]
  | gate g i j rest ih =>
    exact ih (κ.next g i j) _ _ (κ.agrees_next x hx g i j) (κ.agrees_next y hy g i j) ho

theorem partialMatches_agrees {n m : Nat} (κ : PartialState n) (σ : Fin n → Signal m)
    (hm : PartialMatches κ σ) (x : Fin m → Bool) :
    κ.Agrees (fun i => (σ i).eval x) := by
  intro i b hi
  change (σ i).eval x = b
  rw [hm i b hi]
  rfl

theorem propagatedOutput_false {n m : Nat} (C : OpenCircuit n) (κ : PartialState n)
    (σ : Fin n → Signal m) (hm : PartialMatches κ σ)
    (hn : Nonconstant (C.restrict σ).eval) : C.propagatedOutput κ = false := by
  cases ho : C.propagatedOutput κ
  · rfl
  · obtain ⟨x, y, hxy⟩ := hn
    apply False.elim
    apply hxy
    rw [restrict_eval, restrict_eval]
    exact C.eval_eq_of_propagated κ _ _ (partialMatches_agrees κ σ hm x)
      (partialMatches_agrees κ σ hm y) ho

theorem propagation_weight_gain_nonconstant {n m : Nat} (C : OpenCircuit n) (κ : PartialState n)
    (σ : Fin n → Signal m) (hm : PartialMatches κ σ)
    (hl : C.Live) (he : C.EssentialGates) (hn : Nonconstant (C.restrict σ).eval) :
    (C.restrict σ).weight + 2 * C.markedUses κ.mask + 2 * C.propagationBirths κ +
      C.propagationParity κ ≤ C.weight :=
  C.propagation_weight_gain κ σ hm hl he (C.propagatedOutput_false κ σ hm hn)

end OpenCircuit
end SatLowerBound
