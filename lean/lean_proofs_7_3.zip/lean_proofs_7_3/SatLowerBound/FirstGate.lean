import SatLowerBound.Dependence
import SatLowerBound.Cofactors

namespace SatLowerBound

def setPair {n : Nat} (x : Fin n → Bool) (i j : Fin n) (a b : Bool) : Fin n → Bool :=
  fun k => if k = i then a else if k = j then b else x k

def PairSeparated {n : Nat} (f : (Fin n → Bool) → Bool) (i j : Fin n) : Prop :=
  ThreeRows (fun a b x => f (setPair x i j a b))

namespace OpenCircuit

/-- If the first gate consumes the only uses of its two inputs, their effect
on every later computation factors through its single Boolean output. -/
theorem first_gate_factor {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (hij : i ≠ j)
    (hi : (OpenCircuit.gate g i j rest).usage (singleUse i) = 1)
    (hj : (OpenCircuit.gate g i j rest).usage (singleUse j) = 1) :
    ∃ H : Bool → (Fin n → Bool) → Bool, ∀ a b x,
      (OpenCircuit.gate g i j rest).eval (setPair x i j a b) = H (g.eval a b) x := by
  have hi0 : rest.usage (appendValue (singleUse i) 0) = 0 := by
    simp only [usage, singleUse, ↓reduceIte, Ne.symm hij] at hi
    omega
  have hj0 : rest.usage (appendValue (singleUse j) 0) = 0 := by
    simp only [usage, singleUse, ↓reduceIte, hij] at hj
    omega
  let p : Fin (n + 1) → Nat := fun k =>
    appendValue (singleUse i) 0 k + appendValue (singleUse j) 0 k
  have hp : rest.usage p = 0 := by
    simp only [p, usage_add, hi0, hj0, Nat.add_zero]
  refine ⟨fun v x => rest.eval (extend x v), ?_⟩
  intro a b x
  have hai : setPair x i j a b i = a := by simp [setPair]
  have hbj : setPair x i j a b j = b := by simp [setPair, Ne.symm hij]
  simp only [eval, hai, hbj]
  apply rest.eval_eq_of_zero_usage p hp
  intro k hk
  simp only [p, appendValue] at hk
  simp only [extend]
  split at hk
  · rename_i hkn
    simp only [hkn, ↓reduceDIte]
    have hki : (⟨k.val, hkn⟩ : Fin n) ≠ i := by
      intro he
      simp [he, singleUse] at hk
    have hkj : (⟨k.val, hkn⟩ : Fin n) ≠ j := by
      intro he
      simp [he, singleUse] at hk
    simp [setPair, hki, hkj]
  · rename_i hkn
    simp only [hkn, ↓reduceDIte]

/-- Three distinct pair cofactors force a multiple-use input at the first gate. -/
theorem first_gate_multiple_use {n : Nat} (g : Table) (i j : Fin n) (rest : OpenCircuit (n + 1))
    (hij : i ≠ j) (hsep : PairSeparated (OpenCircuit.gate g i j rest).eval i j) :
    2 ≤ (OpenCircuit.gate g i j rest).usage (singleUse i) ∨
      2 ≤ (OpenCircuit.gate g i j rest).usage (singleUse j) := by
  by_contra h
  have hi1 : 1 ≤ (OpenCircuit.gate g i j rest).usage (singleUse i) := by
    simp only [usage, singleUse, ↓reduceIte]
    omega
  have hj1 : 1 ≤ (OpenCircuit.gate g i j rest).usage (singleUse j) := by
    simp only [usage, singleUse, ↓reduceIte]
    omega
  have hi : (OpenCircuit.gate g i j rest).usage (singleUse i) = 1 := by omega
  have hj : (OpenCircuit.gate g i j rest).usage (singleUse j) = 1 := by omega
  obtain ⟨H, hH⟩ := first_gate_factor g i j rest hij hi hj
  exact no_single_signal _ hsep ⟨g.eval, H, hH⟩

end OpenCircuit
end SatLowerBound
