import SatLowerBound.Mod3
import SatLowerBound.RootOfUnity

namespace SatLowerBound

/-- Exact enumeration of the Boolean cube by its two disjoint first-bit slices. -/
def cubeCount : (n : Nat) → ((Fin n → Bool) → Bool) → Nat
  | 0, p => if p (fun i => Fin.elim0 i) then 1 else 0
  | n + 1, p =>
      cubeCount n (fun x => p (prepend false x)) +
      cubeCount n (fun x => p (prepend true x))

def indicator (b : Bool) : Nat := if b then 1 else 0

theorem cubeSum_count {R : Type*} [CommRing R] (n : Nat)
    (p : (Fin n → Bool) → Bool) :
    cubeSum n (fun v => (if p v then 1 else 0 : R)) = (cubeCount n p : R) := by
  induction n with
  | zero => simp only [cubeSum, cubeCount]; split <;> simp
  | succ n ih => simp only [cubeSum, cubeCount, ih, Nat.cast_add]

theorem cubeCount_partition3 (n : Nat) (p q r : (Fin n → Bool) → Bool)
    (h : ∀ x, indicator (p x) + indicator (q x) + indicator (r x) = 1) :
    cubeCount n p + cubeCount n q + cubeCount n r = 2 ^ n := by
  induction n with
  | zero => exact h (fun i => Fin.elim0 i)
  | succ n ih =>
    have hf := ih (fun x => p (prepend false x)) (fun x => q (prepend false x))
      (fun x => r (prepend false x)) (fun x => h (prepend false x))
    have ht := ih (fun x => p (prepend true x)) (fun x => q (prepend true x))
      (fun x => r (prepend true x)) (fun x => h (prepend true x))
    simp only [cubeCount, Nat.pow_succ]
    omega

/-- Counts bit strings with |x|+n congruent to t. The helper set uses t=1. -/
def shiftedCount (n : Nat) (t : Fin 3) : Nat :=
  cubeCount n (fun x => decide ((n + ones n x) % 3 = t.val))

/-- The complex root-of-unity filter in the TeX helper-count proof. -/
theorem helper_count_root_filter (r : Nat) :
    3 * (shiftedCount r 1 : ℂ) = (2 : ℂ) ^ r - (-1 : ℂ) ^ r := by
  have h := cubic_filter_cube_sum cubicRoot cubicRoot_primitive.pow_eq_one cubicRoot_sum r (r + 2)
  have hf : (fun v => if (r + 2 + ones r v) % 3 = 0 then (3 : ℂ) else 0) =
      (fun v => 3 * (if decide ((r + ones r v) % 3 = 1) then (1 : ℂ) else 0)) := by
    funext v
    have he : (r + 2 + ones r v) % 3 = 0 ↔ (r + ones r v) % 3 = 1 := by omega
    simp only [he, decide_eq_true_eq]
    split <;> norm_num
  rw [hf, cubeSum_mul, cubeSum_count] at h
  change 3 * (shiftedCount r 1 : ℂ) = _ at h
  have hs := cubic_filter_selected cubicRoot cubicRoot_primitive.pow_eq_one cubicRoot_sum r
  linear_combination h + hs

theorem shiftedCount_balance_roots (r : Nat) :
    if r % 2 = 0 then 3 * shiftedCount r 1 + 1 = 2 ^ r
    else 3 * shiftedCount r 1 = 2 ^ r + 1 := by
  have h := helper_count_root_filter r
  rw [neg_one_pow_eq_pow_mod_two] at h
  split
  · rename_i hr
    rw [hr] at h
    have he : 3 * (shiftedCount r 1 : ℂ) + 1 = (2 : ℂ) ^ r := by
      simpa using (eq_sub_iff_add_eq.mp h)
    exact_mod_cast he
  · rename_i hr
    have hr1 : r % 2 = 1 := by omega
    rw [hr1] at h
    have he : 3 * (shiftedCount r 1 : ℂ) = (2 : ℂ) ^ r + 1 := by simpa using h
    exact_mod_cast he

theorem shiftedCount_step (n : Nat) (t : Fin 3) :
    shiftedCount (n + 1) t + shiftedCount n t = 2 ^ n := by
  unfold shiftedCount
  rw [cubeCount]
  apply cubeCount_partition3
  intro x
  simp only [ones_prepend, Bool.false_eq_true, ↓reduceIte, Nat.zero_add,
    indicator, decide_eq_true_eq]
  have ht := t.isLt
  split <;> split <;> split <;> omega

/-- Natural-number form of (2^r - (-1)^r)/3. -/
def forbiddenCount (r : Nat) : Nat :=
  if r % 2 = 0 then (2 ^ r - 1) / 3 else (2 ^ r + 1) / 3

theorem shiftedCount_balance (r : Nat) :
    if r % 2 = 0 then 3 * shiftedCount r 1 + 1 = 2 ^ r
    else 3 * shiftedCount r 1 = 2 ^ r + 1 := by
  induction r with
  | zero => decide
  | succ r ih =>
    have hs := shiftedCount_step r 1
    have hr : r % 2 = 0 ∨ r % 2 = 1 := by omega
    rcases hr with hr | hr
    · have hn : (r + 1) % 2 ≠ 0 := by omega
      simp only [hr, ↓reduceIte] at ih
      simp only [hn, ↓reduceIte, Nat.pow_succ]
      omega
    · have hn : (r + 1) % 2 = 0 := by omega
      simp only [hr, Nat.reduceEqDiff, ↓reduceIte] at ih
      simp only [hn, ↓reduceIte, Nat.pow_succ]
      omega

/-- The manuscript's exact helper count, proved by counting all assignments. -/
theorem helper_count_exact (r : Nat) : shiftedCount r 1 = forbiddenCount r := by
  have h := shiftedCount_balance r
  unfold forbiddenCount
  split <;> simp_all <;> omega

theorem helper_count_le (r : Nat) : forbiddenCount r ≤ 2 ^ r := by
  rw [← helper_count_exact]
  have h := shiftedCount_balance r
  have hp : 0 < 2 ^ r := Nat.two_pow_pos r
  split at h <;> omega

end SatLowerBound
