import SatLowerBound.ModularTree
import Mathlib.Algebra.BigOperators.Fin

namespace SatLowerBound

/-- A nonempty finite family of trees joined by the indicated Boolean operation. -/
def joinTrees {n : Nat} (p : Bool) : (k : Nat) → (Fin (k + 1) → ModularTree n) → ModularTree n
  | 0, f => f 0
  | k + 1, f => .branch p (f 0) (joinTrees p k (fun i => f i.succ))

theorem joinTrees_mem {n : Nat} (p : Bool) (k : Nat) (f : Fin (k + 1) → ModularTree n) (x : Fin n) :
    x ∈ (joinTrees p k f).support ↔ ∃ i, x ∈ (f i).support := by
  induction k with
  | zero =>
    constructor
    · exact fun h => ⟨0, h⟩
    · rintro ⟨i, hi⟩
      have he : i = 0 := Fin.ext (by have := i.isLt; omega)
      simpa only [joinTrees, he] using hi
  | succ k ih =>
    simp only [joinTrees, ModularTree.support, Finset.mem_union, ih]
    constructor
    · rintro (h | ⟨i, hi⟩)
      · exact ⟨0, h⟩
      · exact ⟨i.succ, hi⟩
    · rintro ⟨i, hi⟩
      induction i using Fin.cases with
      | zero => exact Or.inl hi
      | succ i => exact Or.inr ⟨i, hi⟩

theorem joinTrees_valid {n : Nat} (p : Bool) (k q : Nat) (f : Fin (k + 1) → ModularTree n)
    (hv : ∀ i, (f i).Valid q) (hd : ∀ i j, i ≠ j → Disjoint (f i).support (f j).support) :
    (joinTrees p k f).Valid q := by
  induction k with
  | zero => exact hv 0
  | succ k ih =>
    refine ⟨hv 0, ih (fun i => f i.succ) (fun i => hv i.succ)
      (fun i j hij => hd i.succ j.succ (fun h => hij (Fin.succ_inj.mp h))), ?_⟩
    apply Finset.disjoint_left.mpr
    intro x hx hy
    obtain ⟨i, hi⟩ := (joinTrees_mem p k (fun i => f i.succ) x).mp hy
    exact Finset.disjoint_left.mp (hd 0 i.succ (by intro he; have hv := congrArg Fin.val he; simp at hv)) hx hi

theorem joinTrees_inputs {n : Nat} (p : Bool) (k : Nat) (f : Fin (k + 1) → ModularTree n) :
    (joinTrees p k f).inputs = ∑ i, (f i).inputs := by
  induction k with
  | zero => simp [joinTrees]
  | succ k ih =>
    rw [joinTrees, ModularTree.inputs, ih]
    exact (Fin.sum_univ_succ (fun i => (f i).inputs)).symm

theorem joinTrees_blocks {n : Nat} (p : Bool) (k : Nat) (f : Fin (k + 1) → ModularTree n) :
    (joinTrees p k f).blocks = ∑ i, (f i).blocks := by
  induction k with
  | zero => simp [joinTrees]
  | succ k ih =>
    rw [joinTrees, ModularTree.blocks, ih]
    exact (Fin.sum_univ_succ (fun i => (f i).blocks)).symm

theorem joinTrees_defects {n : Nat} (p : Bool) (k : Nat) (f : Fin (k + 1) → ModularTree n) :
    (joinTrees p k f).defects = ∑ i, (f i).defects := by
  induction k with
  | zero => simp [joinTrees]
  | succ k ih =>
    rw [joinTrees, ModularTree.defects, ih]
    exact (Fin.sum_univ_succ (fun i => (f i).defects)).symm

theorem joinTrees_all {n : Nat} (k : Nat) (f : Fin (k + 1) → ModularTree n) (v : Fin n → Bool) :
    (joinTrees false k f).eval v = true ↔ ∀ i, (f i).eval v = true := by
  induction k with
  | zero =>
    constructor
    · intro h i
      have he : i = 0 := Fin.ext (by have := i.isLt; omega)
      simpa only [joinTrees, he] using h
    · exact fun h => h 0
  | succ k ih =>
    simp only [joinTrees, ModularTree.eval, combine, Bool.false_eq_true, ↓reduceIte, Bool.and_eq_true, ih]
    constructor
    · rintro ⟨h0, hs⟩ i
      exact Fin.cases h0 hs i
    · intro h
      exact ⟨h 0, fun i => h i.succ⟩

theorem joinTrees_any {n : Nat} (k : Nat) (f : Fin (k + 1) → ModularTree n) (v : Fin n → Bool) :
    (joinTrees true k f).eval v = true ↔ ∃ i, (f i).eval v = true := by
  induction k with
  | zero =>
    constructor
    · exact fun h => ⟨0, h⟩
    · rintro ⟨i, hi⟩
      have he : i = 0 := Fin.ext (by have := i.isLt; omega)
      simpa only [joinTrees, he] using hi
  | succ k ih =>
    simp only [joinTrees, ModularTree.eval, combine, ↓reduceIte, Bool.or_eq_true, ih]
    constructor
    · rintro (h | ⟨i, hi⟩)
      · exact ⟨0, h⟩
      · exact ⟨i.succ, hi⟩
    · rintro ⟨i, hi⟩
      induction i using Fin.cases with
      | zero => exact Or.inl hi
      | succ i => exact Or.inr ⟨i, hi⟩

end SatLowerBound
